#include "dobby/dobby_internal.h"
#include "TrampolineBridge/ClosureTrampolineBridge/common_bridge_handler.h"
#include "InterceptRouting/InstrumentRouting.h"
#include "logging/logging.h"

void instrument_forward_handler(Interceptor::Entry *entry, DobbyRegisterContext *ctx);

#if defined(__arm64__) || defined(__aarch64__)
static inline void fixup_arm64_instrument_lr(DobbyRegisterContext *ctx) {
  if (!ctx || !ctx->sp) {
    return;
  }

  // closure_trampoline_arm64 saves the caller's original x30 at [original_sp - 8].
  // closure_bridge_arm64 itself is entered via BLR, so the x30 saved into ctx->lr
  // points back into Dobby's trampoline. Restore the LR visible to the hooked code.
  uintptr_t saved_lr = *(uintptr_t *)(ctx->sp - sizeof(uintptr_t));
  features::apple::arm64e_pac_strip(saved_lr);
  ctx->lr = saved_lr;
}
#endif

extern "C" void instrument_routing_dispatch(Interceptor::Entry *entry, DobbyRegisterContext *ctx) {
  // __FUNC_CALL_TRACE__();
#if defined(__arm64__) || defined(__aarch64__)
  fixup_arm64_instrument_lr(ctx);
#endif

  auto instrument_callback_fn = (dobby_instrument_callback_t)entry->pre_handler;
  if (instrument_callback_fn) {
    instrument_callback_fn((void *)entry->addr, ctx);
  }

  // set TMP_REG_0 to next hop
  set_routing_bridge_next_hop(ctx, (void *)entry->relocated.addr());
}
