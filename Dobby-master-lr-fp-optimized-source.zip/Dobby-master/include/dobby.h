#ifndef dobby_h
#define dobby_h

#ifdef __cplusplus
extern "C" {
#endif

#include <stdbool.h>
#include <stdint.h>
#include <sys/types.h>

typedef uintptr_t addr_t;
typedef uint32_t addr32_t;
typedef uint64_t addr64_t;

typedef void *asm_func_t;

#if defined(__arm__)
typedef struct {
  uint32_t dummy_0;
  uint32_t dummy_1;

  uint32_t dummy_2;
  uint32_t sp;

  union {
    uint32_t r[13];
    struct {
      uint32_t r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12;
    } regs;
  } general;

  uint32_t lr;
} DobbyRegisterContext;
#elif defined(__arm64__) || defined(__aarch64__)
#define ARM64_TMP_REG_NDX_0 17

typedef union _FPReg {
  __int128_t q;
  struct {
    double d1;
    double d2;
  } d;
  struct {
    float f1;
    float f2;
    float f3;
    float f4;
  } f;
} FPReg;

// The AArch64 SIMD/floating-point register file is saved as 128-bit Q registers.
// Dn/Sn are the low 64-bit/32-bit lanes of Qn. These aliases make common
// instrument callbacks straightforward, for example:
//   double d0 = DobbyRegisterContextGetD(ctx, 0);
//   float  s1 = DobbyRegisterContextGetS(ctx, 1);
typedef struct _DobbyArm64FPDRegisterAliases {
#define DOBBY_ARM64_D_ALIAS(n) double d##n; uint64_t __d##n##_padding
  DOBBY_ARM64_D_ALIAS(0); DOBBY_ARM64_D_ALIAS(1); DOBBY_ARM64_D_ALIAS(2); DOBBY_ARM64_D_ALIAS(3);
  DOBBY_ARM64_D_ALIAS(4); DOBBY_ARM64_D_ALIAS(5); DOBBY_ARM64_D_ALIAS(6); DOBBY_ARM64_D_ALIAS(7);
  DOBBY_ARM64_D_ALIAS(8); DOBBY_ARM64_D_ALIAS(9); DOBBY_ARM64_D_ALIAS(10); DOBBY_ARM64_D_ALIAS(11);
  DOBBY_ARM64_D_ALIAS(12); DOBBY_ARM64_D_ALIAS(13); DOBBY_ARM64_D_ALIAS(14); DOBBY_ARM64_D_ALIAS(15);
  DOBBY_ARM64_D_ALIAS(16); DOBBY_ARM64_D_ALIAS(17); DOBBY_ARM64_D_ALIAS(18); DOBBY_ARM64_D_ALIAS(19);
  DOBBY_ARM64_D_ALIAS(20); DOBBY_ARM64_D_ALIAS(21); DOBBY_ARM64_D_ALIAS(22); DOBBY_ARM64_D_ALIAS(23);
  DOBBY_ARM64_D_ALIAS(24); DOBBY_ARM64_D_ALIAS(25); DOBBY_ARM64_D_ALIAS(26); DOBBY_ARM64_D_ALIAS(27);
  DOBBY_ARM64_D_ALIAS(28); DOBBY_ARM64_D_ALIAS(29); DOBBY_ARM64_D_ALIAS(30); DOBBY_ARM64_D_ALIAS(31);
#undef DOBBY_ARM64_D_ALIAS
} DobbyArm64FPDRegisterAliases;

typedef struct _DobbyArm64FPSRegisterAliases {
#define DOBBY_ARM64_S_ALIAS(n) float s##n; float __s##n##_padding[3]
  DOBBY_ARM64_S_ALIAS(0); DOBBY_ARM64_S_ALIAS(1); DOBBY_ARM64_S_ALIAS(2); DOBBY_ARM64_S_ALIAS(3);
  DOBBY_ARM64_S_ALIAS(4); DOBBY_ARM64_S_ALIAS(5); DOBBY_ARM64_S_ALIAS(6); DOBBY_ARM64_S_ALIAS(7);
  DOBBY_ARM64_S_ALIAS(8); DOBBY_ARM64_S_ALIAS(9); DOBBY_ARM64_S_ALIAS(10); DOBBY_ARM64_S_ALIAS(11);
  DOBBY_ARM64_S_ALIAS(12); DOBBY_ARM64_S_ALIAS(13); DOBBY_ARM64_S_ALIAS(14); DOBBY_ARM64_S_ALIAS(15);
  DOBBY_ARM64_S_ALIAS(16); DOBBY_ARM64_S_ALIAS(17); DOBBY_ARM64_S_ALIAS(18); DOBBY_ARM64_S_ALIAS(19);
  DOBBY_ARM64_S_ALIAS(20); DOBBY_ARM64_S_ALIAS(21); DOBBY_ARM64_S_ALIAS(22); DOBBY_ARM64_S_ALIAS(23);
  DOBBY_ARM64_S_ALIAS(24); DOBBY_ARM64_S_ALIAS(25); DOBBY_ARM64_S_ALIAS(26); DOBBY_ARM64_S_ALIAS(27);
  DOBBY_ARM64_S_ALIAS(28); DOBBY_ARM64_S_ALIAS(29); DOBBY_ARM64_S_ALIAS(30); DOBBY_ARM64_S_ALIAS(31);
#undef DOBBY_ARM64_S_ALIAS
} DobbyArm64FPSRegisterAliases;

// register context
typedef struct {
  uint64_t dmmpy_0; // dummy placeholder
  uint64_t sp;

  uint64_t dmmpy_1; // dummy placeholder
  union {
    uint64_t x[29];
    struct {
      uint64_t x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21, x22,
          x23, x24, x25, x26, x27, x28;
    } regs;
  } general;

  uint64_t fp;
  uint64_t lr;

  union {
    FPReg q[32];
    DobbyArm64FPDRegisterAliases d; // Dn low 64-bit lane aliases: ctx->floating.d.d0, ctx->floating.d.d1, ...
    DobbyArm64FPSRegisterAliases s; // Sn low 32-bit lane aliases: ctx->floating.s.s0, ctx->floating.s.s1, ...
    struct {
      FPReg q0, q1, q2, q3, q4, q5, q6, q7;
      // [!!! READ ME !!!]
      // for Arm64, can't access q8 - q31, unless you enable full floating-point register pack
      FPReg q8, q9, q10, q11, q12, q13, q14, q15, q16, q17, q18, q19, q20, q21, q22, q23, q24, q25, q26, q27, q28, q29,
          q30, q31;
    } regs;
  } floating;
} DobbyRegisterContext;

static inline double DobbyRegisterContextGetD(DobbyRegisterContext *ctx, int index) {
  return ctx->floating.q[index].d.d1;
}

static inline float DobbyRegisterContextGetS(DobbyRegisterContext *ctx, int index) {
  return ctx->floating.q[index].f.f1;
}
#elif defined(_M_IX86) || defined(__i386__)
typedef struct _RegisterContext {
  uint32_t dummy_0;
  uint32_t esp;

  uint32_t dummy_1;
  uint32_t flags;

  union {
    struct {
      uint32_t eax, ebx, ecx, edx, ebp, esp, edi, esi;
    } regs;
  } general;

} DobbyRegisterContext;
#elif defined(_M_X64) || defined(__x86_64__)
typedef struct {
  union {
    struct {
      uint64_t rax, rbx, rcx, rdx, rbp, rsp, rdi, rsi, r8, r9, r10, r11, r12, r13, r14, r15;
    } regs;
  } general;

  uint64_t dummy_0;
  uint64_t flags;
  uint64_t ret;
} DobbyRegisterContext;
#endif

#define install_hook_name(name, fn_ret_t, fn_args_t...)                                                                \
  static fn_ret_t fake_##name(fn_args_t);                                                                              \
  static fn_ret_t (*orig_##name)(fn_args_t);                                                                           \
  /* __attribute__((constructor)) */ static void install_hook_##name(void *sym_addr) {                                 \
    DobbyHook(sym_addr, (void *)fake_##name, (void **)&orig_##name);                                                   \
    return;                                                                                                            \
  }                                                                                                                    \
  fn_ret_t fake_##name(fn_args_t)

// memory code patch
int DobbyCodePatch(void *address, uint8_t *buffer, uint32_t buffer_size);

// function inline hook
int DobbyHook(void *address, void *fake_func, void **out_origin_func);

// dynamic binary instruction instrument
// for Arm64, can't access q8 - q31, unless enable full floating-point register pack
typedef void (*dobby_instrument_callback_t)(void *address, DobbyRegisterContext *ctx);
int DobbyInstrument(void *address, dobby_instrument_callback_t pre_handler);

// destroy and restore code patch
int DobbyDestroy(void *address);

const char *DobbyGetVersion();

// symbol resolver
void *DobbySymbolResolver(const char *image_name, const char *symbol_name);

// import table replace
int DobbyImportTableReplace(char *image_name, char *symbol_name, void *fake_func, void **orig_func);

// for arm, Arm64, try use b xxx instead of ldr absolute indirect branch
// for x86, x64, always use absolute indirect jump
void dobby_set_near_trampoline(bool enable);

// register callback for alloc near code block
typedef addr_t (*dobby_alloc_near_code_callback_t)(uint32_t size, addr_t pos, size_t range);
void dobby_register_alloc_near_code_callback(dobby_alloc_near_code_callback_t handler);

void dobby_set_options(bool enable_near_trampoline, dobby_alloc_near_code_callback_t alloc_near_code_callback);

#ifdef __cplusplus
}
#endif

#endif
