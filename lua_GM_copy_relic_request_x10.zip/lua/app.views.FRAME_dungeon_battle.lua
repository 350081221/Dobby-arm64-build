import("..lib.BEZ")

local UI_base = import(".UI_base")
local FRAME_dungeon_battle = class("FRAME_dungeon_battle", UI_base)

function FRAME_dungeon_battle:ctor()
	FRAME_dungeon_battle.super.ctor(self, "frame_dungeon_battle")
	self:init()
end

function FRAME_dungeon_battle:init()
	self:initUI()

	local notifyFlag = self:getFlagByTag("flag_notify")

	if notifyFlag then
		local popNotify = POP_notify.new(notifyFlag, {
			0
		})
		self.popNotify = popNotify

		display.getRunningScene():addChild(popNotify, LayerConfig.notify)
	end

	local popCaution = POP_caution.new()

	self:addChild(popCaution)
	self:initModao()

	if OnlineCamp.isOnlineStage() then
		notify.safeRegister(self, "dps_changed", function ()
			self:refreshDpsUI()
		end)
		self:refreshDpsUI()
	end

	self:refreshLiuhai()
	notify.safeRegister(self, "liuhai_change", function ()
		self:refreshLiuhai()
	end)
end

function FRAME_dungeon_battle:refreshLiuhai()
	if self:battleItem() then
		local bt_speedup_no = self.bottomUI:getComponentByTag("bt_speedup_no")
		local bt_speedup_yes = self.bottomUI:getComponentByTag("bt_speedup_yes")

		if UIManager.getLiuhai() == "right" then
			for i, slotUI in ipairs(self.skillSlots) do
				slotUI:setPositionX(slotUI.initX - UIManager.LIUHAI_WIDTH)

				local bg = self.bottomUI:getComponentByTag("skill_bg_" .. i)

				bg:setPositionX(bg.initX - UIManager.LIUHAI_WIDTH)
			end

			bt_speedup_yes:setPositionX(bt_speedup_yes.initX - UIManager.LIUHAI_WIDTH)
			bt_speedup_no:setPositionX(bt_speedup_no.initX - UIManager.LIUHAI_WIDTH)
		else
			for i, slotUI in ipairs(self.skillSlots) do
				slotUI:setPositionX(slotUI.initX)

				local bg = self.bottomUI:getComponentByTag("skill_bg_" .. i)

				bg:setPositionX(bg.initX)
			end

			bt_speedup_yes:setPositionX(bt_speedup_yes.initX)
			bt_speedup_no:setPositionX(bt_speedup_no.initX)
		end
	end
end

function FRAME_dungeon_battle:refreshDpsUI()
	if not self.dpsList then
		self.dpsList = self.bottomUI:createListOnFlag("flag_dps", LIST_dps)
	end

	local eventIndexArr = WarMachine.getEventIndexArr()
	local items = OnlineCamp.getDpsList(eventIndexArr)

	self.dpsList:setItems(items)
end

function FRAME_dungeon_battle:ready()
	self:updateModaoMax()
	self:refreshSpeedup()
	self.headUI:ready()

	if self.popNotify then
		self.popNotify:setActive(true)
	end

	self:refreshBardPosition()
end

function FRAME_dungeon_battle:out()
	self:removeEnterFrame("checkSkillSelectionLoop")
	self:removeEnterFrame("wave_list_time_looper")
	self:removeEnterFrame("update_modao_mp")
	self:clearModaoBlock()

	if self.popNotify then
		self.popNotify:setActive(false)
	end

	self:removeEnterFrame("battle_retry_loop")
end

function FRAME_dungeon_battle:onBattleReady()
	self.isBattle = true
	local customMusic = Sound.getBattleMusic()

	if empty(customMusic) then
		local maxClass = WarMachine.getMaxClass()

		if maxClass > 10 then
			local terrainCSV = InfoDungeon.getTerrainCSV()

			if terrainCSV then
				if maxClass == 11 then
					Sound.playMusic(terrainCSV.bgm_battle_elite)
				elseif maxClass == 12 then
					Sound.playMusic(terrainCSV.bgm_battle_boss)
				end
			end
		end
	else
		Sound.playMusic(customMusic)
		Sound.clearBattleMusic()
	end

	InfoModao.initDungeon(true)
	InfoDungeon.prepareRune()
	self:refreshSkillAndruneSlots()
	self:refreshModaoSlots()
	self:initMonsterBar()
	self:updateModaoMana()
	self:stopTimecount()
	self.headUI:resetPet()

	local showRetry = not OnlineCamp.isOnlineStage() and InfoGuide.isFin() and InfoFunction.checkFuncOpen(10400)

	if showRetry then
		local startTime = Time.time()
		self.retryStartTime = startTime
		local battle_retry_wait = CsvParser.getCsvData("config", "battle_retry_wait").value

		local function battle_retry_loop()
			local percent = math.min(1, math.max(0, (Time.time() - startTime) / battle_retry_wait))

			self:setRetryPercent(1 - percent)

			if percent >= 1 then
				self:removeEnterFrame("battle_retry_loop")
			end
		end

		self:addEnterFrame("battle_retry_loop", battle_retry_loop)
	end
end

function FRAME_dungeon_battle:startTimecount()
	Looper.startLoop(self, self.timecountLoop)
	self:timecountLoop()
end

function FRAME_dungeon_battle:stopTimecount()
	Looper.stopLoop(self, self.timecountLoop)
	self.mainUI:removeLabelOnFlag("flag_timecount")
end

function FRAME_dungeon_battle:timecountLoop()
	local timeleft = math.floor(WarMachine.getTimeLeft() / 60)

	if timeleft ~= self.preTimeleft then
		self.preTimeleft = timeleft

		self.mainUI:replaceLabelOnFlag("flag_timecount", nil, Localization.getSrcText("连接倒计时"), Time.formatMinite(timeleft))
	end
end

function FRAME_dungeon_battle:battleItem()
	return InfoFunction.checkFuncOpen(10170) and InfoDungeon.getType() ~= InfoDungeon.TYPE.CORE
end

function FRAME_dungeon_battle:getBottomUiName()
	if self:battleItem() then
		return "frame_dungeon_battle_item"
	else
		return "frame_dungeon_battle_noitem"
	end
end

function FRAME_dungeon_battle:initUI()
	self.mainUI = UIManager.getUI("frame_dungeon_battle_main", UIManager.BIG_TYPE.BOTTOM)

	self:addChild(self.mainUI)

	self.monsterUI = UIManager.getUI("frame_dungeon_battle_monster", UIManager.BIG_TYPE.TOP)

	self:addChild(self.monsterUI)

	self.headUI = FRAME_main_head.new(true)

	self:addChild(self.headUI)

	local bottomUI = UIManager.getUI(self:getBottomUiName(), UIManager.BIG_TYPE.BOTTOM)

	self:addChild(bottomUI)

	self.bottomUI = bottomUI

	if self:battleItem() then
		self.runeSlots = {}

		for i = 1, GameConfig.rune_num do
			local slotUI = DungeonSlot.new(self.bottomUI:getRectByFlag("flag_rune_" .. i))

			self.bottomUI:addChild(slotUI, 100)
			table.insert(self.runeSlots, slotUI)
			slotUI:toTouchable()
			slotUI:addTouch(function (event, x, y)
				if not SkillManager.isLocked() then
					self:onItemSlotTouch(slotUI, i, event, x, y)
				end
			end)
		end
	end

	self.skillSlots = {}

	for i = 1, GameConfig.hero_team_num do
		local slotUI = DungeonSlot.new(self.bottomUI:getRectByFlag("flag_skill_" .. i))

		self.bottomUI:addChild(slotUI, 100)
		table.insert(self.skillSlots, slotUI)
		slotUI:toTouchable()
		slotUI:addTouch(function (event, x, y)
			if not SkillManager.isLocked() then
				self:onSlotTouch(slotUI, i, event, x, y)
			end
		end)

		slotUI.initX = slotUI:getPositionX()
		local bg = self.bottomUI:getComponentByTag("skill_bg_" .. i)
		bg.initX = bg:getPositionX()
	end

	notify.safeRegister(self, "battle_over", function ()
		self.isBattle = false

		self:clearBattleFreeze()

		for i, slotUI in ipairs(self.skillSlots) do
			slotUI:reset()
		end

		if self.modaoSlots then
			for i, slotUI in ipairs(self.modaoSlots) do
				slotUI:reset()
			end
		end

		self:removeHead()
		self:clearMonsterBar()
		self:stopTimecount()
	end)
	notify.safeRegister(self, "battle_timecount_start", function (event)
		self:startTimecount(event)
	end)
	notify.safeRegister(self, "battle_timecount_stop", function (event)
		self:stopTimecount()
	end)

	self.waveNode = display.newNode()

	self.monsterUI:addChild(self.waveNode)

	local barFlag = self.monsterUI:getFlagByTag("flag_monster_bar")
	local waveflag = self.monsterUI:getFlagByTag("flag_wave_list")
	local waveY = barFlag.originalY - (waveflag.originalY + waveflag.originalHeight)

	self.waveNode:setPositionY(display.height - waveY)

	local comboFlag = self.mainUI:getFlagByTag("flag_combo")
	self.popCombo = POP_combo.new(self.mainUI:getRectByFlag("flag_combo"))

	self.mainUI:addChild(self.popCombo)
	self.popCombo:setPosition(comboFlag.x + comboFlag.width / 2, comboFlag.y + comboFlag.height / 2)

	local attrButton = self.mainUI:getComponentByTag("bt_attr")
	local pauseButton = self.mainUI:getComponentByTag("bt_pause")
	local isShow = (device.platform == "windows" or global.shuxing) and DEV_MODE

	attrButton:setVisible(isShow)
	pauseButton:setVisible(isShow)

	if isShow then
		attrButton:toTouchable()
		attrButton:addTap(function ()
			MapFrameManager.pause("attr_debug")
			FRAME_attr_debug.open()
		end)
		pauseButton:toTouchable()
		pauseButton:addTap(function ()
			if not self.isPaused then
				MapFrameManager.pause("attr_pause")

				self.isPaused = true

				pauseButton:addLabel("继续")
			else
				MapFrameManager.resume("attr_pause")
				pauseButton:addLabel("暂停")

				self.isPaused = nil
			end
		end)
	end

	local bt_speedup_no = self.bottomUI:getComponentByTag("bt_speedup_no")
	local bt_speedup_yes = self.bottomUI:getComponentByTag("bt_speedup_yes")

	if InfoDungeon.isSpeedup() then
		bt_speedup_no:toTouchable()
		bt_speedup_no:setTapGroup("button_click")
		bt_speedup_no:addTap(function ()
			Cookie.set("speedup_ban", nil, true)
			global.map:refreshSpeedup()
			self:refreshSpeedup()
		end)
		bt_speedup_yes:toTouchable()
		bt_speedup_yes:setTapGroup("button_click")
		bt_speedup_yes:addTap(function ()
			Cookie.set("speedup_ban", true, true)
			global.map:refreshSpeedup()
			self:refreshSpeedup()
		end)
	else
		bt_speedup_no:setVisible(false)
		bt_speedup_yes:setVisible(false)
	end

	bt_speedup_yes.initX = bt_speedup_yes:getPositionX()
	bt_speedup_no.initX = bt_speedup_no:getPositionX()
	local bt_retry = self.bottomUI:getComponentByTag("bt_retry")
	local retry_cd = self.bottomUI:getFlagByTag("retry_cd")

	if InfoDungeon.isSpeedup() then
		bt_retry:setPos(bt_retry.x - 80)

		retry_cd.x = retry_cd.x - 80
	end

	local showRetry = not OnlineCamp.isOnlineStage() and InfoGuide.isFin() and InfoFunction.checkFuncOpen(10400)

	if showRetry then
		bt_retry:setVisible(true)
		bt_retry:toTouchable()
		bt_retry:setTapGroup("button_click")
		bt_retry:addTap(function ()
			if not self.retryStartTime then
				return
			end

			local battle_retry_wait = CsvParser.getCsvData("config", "battle_retry_wait").value

			if battle_retry_wait > Time.time() - self.retryStartTime then
				return
			end

			if not WarMachine.on then
				return
			end

			MapFrameManager.pause("bt_retry")

			if InfoDungeon.getType() == InfoDungeon.TYPE.CORE then
				POP_notice.open(Localization.getSrcText("要从第一轮重新开始吗？"), function ()
					InfoCore.retry()
				end, function ()
					MapFrameManager.resume("bt_retry")
				end)
			else
				POP_notice.open(Localization.getSrcText("要回到战斗开始前吗？"), function ()
					InfoDungeon.retry()
				end, function ()
					MapFrameManager.resume("bt_retry")
				end)
			end
		end)

		local iconFlag = self.bottomUI:getFlagByTag("retry_cd")
		self.polygonPoints = {
			{
				0,
				iconFlag.height / 2
			},
			{
				-iconFlag.width / 2,
				iconFlag.height / 2
			},
			{
				-iconFlag.width / 2,
				-iconFlag.height / 2
			},
			{
				iconFlag.width / 2,
				-iconFlag.height / 2
			},
			{
				iconFlag.width / 2,
				iconFlag.height / 2
			},
			{
				0,
				iconFlag.height / 2
			}
		}
	else
		bt_retry:setVisible(false)
	end

	if InfoDungeon.getType() == InfoDungeon.TYPE.STAGE then
		local stageType, stageID = InfoDungeon.getStage()

		if stageType == InfoDungeon.STAGE_TYPE.ACTV then
			local actvStageCSV = CsvParser.getCsvData("actv_stage", stageID)

			if actvStageCSV and actvStageCSV.type == 3 then
				local function updateTimeUsed()
					local str1 = Localization.getSrcText("用时")
					local isNewRecord = InfoActvStage.checkNewRecord(stageID)

					if isNewRecord then
						str1 = Localization.getSrcText("新纪录")
					end

					local timeUsed = nil

					if InfoDungeon.isPassed() then
						local data = InfoActvStage.getData(InfoActvStage.getActvID(stageID))
						timeUsed = data.level_time_mark
					else
						timeUsed = InfoDungeon.getTimeUsed()
					end

					local str2 = Time.showSec(timeUsed)

					if str1 ~= self.timeUsedStr1 or str2 ~= self.timeUsedStr2 then
						self.timeUsedStr1 = str1
						self.timeUsedStr2 = str2
						local style1 = {
							color = isNewRecord and Style.golden or Style.font1
						}
						local style2 = {
							color = Style.font3
						}

						self.bottomUI:createLabelGroupOnFlag("flag_time_used", {
							str1,
							str2
						}, {
							style1,
							style2
						})
					end
				end

				self:addEnterFrame("updateTimeUsed", updateTimeUsed)
			end
		end
	end

	if InfoDungeon.getType() == InfoDungeon.TYPE.CORE then
		local ui = FRAME_core_battle.new()

		self:addChild(ui, 100)
	end
end

function FRAME_dungeon_battle:setRetryPercent(percent)
	local retry_cd = self.bottomUI:getFlagByTag("retry_cd")
	local bt_retry = self.bottomUI:getComponentByTag("bt_retry")
	local polygonPoints = self.polygonPoints

	if percent > 0 then
		local nodeNum = math.floor((percent + 0.125) * 4) + 1
		local pts = {
			{
				0,
				0
			}
		}

		for i = 1, nodeNum do
			table.insert(pts, polygonPoints[i])
		end

		local ipt = polygonPoints[nodeNum]
		local ipt2 = polygonPoints[nodeNum + 1]
		local iangle = math.atan2(ipt2[2] - ipt[2], ipt2[1] - ipt[1])
		local ix, iy = GeomPlane.intersect(0, 0, math.pi * 2 * (percent + 0.25), ipt[1], ipt[2], iangle)

		table.insert(pts, {
			ix,
			iy
		})
		table.insert(pts, {
			0,
			0
		})

		local newPolygon = self.cdPolygon == nil

		if self.cdPolygon then
			self.cdPolygon:setVisible(true)
			self.cdPolygon:clear()
		end

		self.cdPolygon = display.newPolygon(pts, {
			borderWidth = 0,
			fillColor = cc.c4f(0, 0, 0, 0.8)
		}, self.cdPolygon)

		if newPolygon then
			self.cdPolygon:setPosition(retry_cd.x + retry_cd.width / 2, retry_cd.y + retry_cd.height / 2)
			self.bottomUI:addChild(self.cdPolygon, 800)
		end
	elseif self.cdPolygon then
		self.cdPolygon:setVisible(false)
	end
end

function FRAME_dungeon_battle:refreshRuneNum(index)
	local itemInfo = InfoDungeon.getRune(index)
	local slotUI = self.runeSlots[index]

	slotUI:setNum(itemInfo.num)
	slotUI:setSkillEnabled(itemInfo.num > 0)
end

function FRAME_dungeon_battle:refreshSpeedup()
	if InfoDungeon.isSpeedup() then
		local bt_speedup_no = self.bottomUI:getComponentByTag("bt_speedup_no")
		local bt_speedup_yes = self.bottomUI:getComponentByTag("bt_speedup_yes")

		bt_speedup_no:setVisible(Cookie.get("speedup_ban"))
		bt_speedup_yes:setVisible(not Cookie.get("speedup_ban"))
	end
end

function FRAME_dungeon_battle:removeHead()
end

function FRAME_dungeon_battle:refreshSkillAndruneSlots()
	local bottomX = nil
	local units = TeamManager.getTeam()

	for i, slotUI in ipairs(self.skillSlots) do
		local unit = units[i]

		if unit then
			local skillInfo = unit:getActiveSkill()

			slotUI:setContent(unit, DropManager.TYPE.SKILL, skillInfo)
			slotUI:setVisible(true)
			unit:refreshAutoSkill()
			slotUI:setAuto(unit:isAutoSkill())
		else
			slotUI:setVisible(false)
		end

		local x = slotUI:getPositionX()

		if not bottomX or x < bottomX then
			bottomX = x
		end
	end

	if self:battleItem() then
		local itemMap = InfoDungeon.getRuneList()

		for i, slotUI in ipairs(self.runeSlots) do
			local itemInfo = itemMap[i]

			if itemInfo then
				slotUI:setContent(global.modao, DropManager.TYPE.ITEM, itemInfo)
				slotUI:setVisible(true)
			else
				slotUI:setVisible(false)
			end

			local x = slotUI:getPositionX()

			if not bottomX or x < bottomX then
				bottomX = x
			end
		end
	end

	self.bottomX = bottomX

	self:refreshBardPosition()
end

function FRAME_dungeon_battle:refreshBardPosition()
	if global.main_bard then
		global.main_bard:refreshPosition(self.bottomX)
	end
end

function FRAME_dungeon_battle:refreshModaoSlots()
	if InfoModao.enabled() then
		global.modao:initBattle(math.random(1, 65535))

		for i, slotUI in ipairs(self.modaoSlots) do
			if global.modaoHidden then
				slotUI:setVisible(false)
			else
				local skillPack = global.modao:getActiveSkill(i)

				slotUI:setVisible(skillPack ~= nil)
				slotUI:setContent(global.modao, DropManager.TYPE.SKILL, skillPack)

				if skillPack then
					local skillData = skillPack.data
					local blockNum = skillData.mp / MiscConfig.MP_BLOCK

					slotUI:setMp(blockNum)
				else
					slotUI:clearMp()
				end
			end
		end
	end
end

function FRAME_dungeon_battle:prepareNextWave()
	self:removeEnterFrame("wave_list_time_looper")

	if self.waveUIMap then
		local bestIndex, bestUI = nil

		for index, ui in pairs(self.waveUIMap) do
			if not bestIndex or index < bestIndex then
				bestIndex = index
				bestUI = ui
			end
		end

		if bestUI then
			local flag = self.monsterUI:getFlagByTag("flag_wave_list")
			local labelFlag = bestUI:getFlagByTag("flag_time")
			labelFlag.width = labelFlag.originalWidth + 20

			bestUI:createLabelOnFlag("flag_time", Localization.getSrcText("即将"))
			transition.moveTo(bestUI, {
				time = 0.2,
				easing = "sineOut",
				x = flag.x - 20
			})
		end
	end
end

function FRAME_dungeon_battle:refreshWaveList(waveList)
	self:removeEnterFrame("wave_list_time_looper")

	local flag = self.monsterUI:getFlagByTag("flag_wave_list")

	if self.waveUIMap then
		for index, ui in pairs(self.waveUIMap) do
			ui:removeSelf()
		end
	end

	self.waveUIMap = {}
	local ySpace = flag.height

	for i, waveData in ipairs(waveList) do
		local monsterData = CsvParser.getCsvData("monster", waveData.monsterID)
		local ui = UIManager.getUI("com_wave_list")
		local mugshotRect = ui:getRectByFlag("flag_mugshot")
		local portrait = PortraitManager.getMonsterMugshot(waveData.monsterID, mugshotRect, 3)

		portrait:setPosition(mugshotRect.x + mugshotRect.width / 2, mugshotRect.y + mugshotRect.height / 2)
		ui:addChild(portrait, 100)
		ui:setPosition(flag.x, -ui.height - ySpace * (i - 1))
		self.waveNode:addChild(ui)

		self.waveUIMap[waveData.index] = ui

		if waveData.time then
			ui:createLabelOnFlag("flag_time", math.ceil(waveData.time / 60))

			if i == 1 then
				local endTime = WarMachine.frame + waveData.time
				local preTimeLeftStr = nil

				local function refreshTimeLooper()
					local timeLeft = math.ceil(math.max(0, endTime - WarMachine.frame) / 60)
					local timeLeftStr = tostring(timeLeft)

					if timeLeftStr ~= preTimeLeftStr then
						preTimeLeftStr = timeLeftStr
						local label = ui:createLabelOnFlag("flag_time", timeLeftStr)

						if timeLeft <= 3 then
							Style.beat(label)
						end
					end
				end

				self:addEnterFrame("wave_list_time_looper", refreshTimeLooper)
			end
		end
	end
end

local cols = 6

function FRAME_dungeon_battle:initMonsterBar()
	local monsters = WarMachine.getUnitsByCamp(2)

	for i, monster in ipairs(monsters) do
		if monster.data.class and monster.data.class > 10 then
			self:addMonsterBar(monster, true)
		end
	end

	self:arrangeMonsterBar()

	self.warmachine_addunitHandler = notify.safeRegister(self, "warmachine_addunit_2", function (unit)
		if unit.data.class and unit.data.class > 10 then
			self:addMonsterBar(unit)
		end
	end)
	self.warmachine_removeunitHandler = notify.safeRegister(self, "warmachine_removeunit_2", function (unit)
		if unit.data.class and unit.data.class > 10 then
			self:removeMonsterBar(unit)
		end
	end)
end

function FRAME_dungeon_battle:clearMonsterBar()
	if self.monsterBarMap then
		for monster, obj in pairs(self.monsterBarMap) do
			obj.bar:removeSelf()
		end

		self.monsterBarMap = nil
	end

	notify.unregister("warmachine_addunit_2", self.warmachine_addunitHandler)
	notify.unregister("warmachine_removeunit_2", self.warmachine_removeunitHandler)
end

function FRAME_dungeon_battle:addMonsterBar(monster, noArrange)
	if not self.monsterBarMap then
		self.monsterBarMap = {}
		self.monsterBarIndex = 1
	end

	local barFlag = self.monsterUI:getFlagByTag("flag_monster_bar")
	local barWidth = barFlag.width / cols
	local barGrid = 1

	if monster.data.class > 1 then
		barGrid = 2
	end

	local barW = barWidth * barGrid
	local monsterBar = BattleHead.new("com_monster_bar")

	self.monsterUI:addChild(monsterBar)
	monsterBar:setUnit(monster)
	monsterBar:setBattleEventEnabled(true)

	self.monsterBarMap[monster] = {
		bar = monsterBar,
		grid = barGrid,
		index = self.monsterBarIndex
	}
	self.monsterBarIndex = self.monsterBarIndex + 1

	if not noArrange then
		self:arrangeMonsterBar()
	end
end

function FRAME_dungeon_battle:removeMonsterBar(monster)
	if not self.monsterBarMap then
		return
	end

	if self.monsterBarMap[monster] then
		local obj = self.monsterBarMap[monster]

		obj.bar:removeSelf()

		self.monsterBarMap[monster] = nil

		self:arrangeMonsterBar()
	end
end

function FRAME_dungeon_battle:arrangeMonsterBar()
	if not self.monsterBarMap then
		return
	end

	local barFlag = self.monsterUI:getFlagByTag("flag_monster_bar")
	local barWidth = barFlag.width / cols
	local barHeight = 50
	local monsterBarArr = {}

	for monster, obj in pairs(self.monsterBarMap) do
		table.insert(monsterBarArr, obj)
	end

	table.sort(monsterBarArr, function (a, b)
		if a.grid == b.grid then
			return a.index < b.index
		else
			return b.grid < a.grid
		end
	end)

	local matrix = {}
	local minY = display.height

	for i, obj in ipairs(monsterBarArr) do
		local row = 0

		while true do
			if not matrix[row] then
				matrix[row] = 0
			end

			if obj.grid <= cols - matrix[row] then
				local col = matrix[row]
				matrix[row] = col + obj.grid
				local y = barFlag.y + barFlag.height - row * barHeight

				obj.bar:setPosition(barFlag.x + col * barWidth, y)

				minY = math.min(minY, y)

				break
			else
				row = row + 1
			end
		end
	end

	minY = math.min(minY, barFlag.y + barFlag.height)
	local waveflag = self.monsterUI:getFlagByTag("flag_wave_list")
	local waveY = barFlag.originalY - (waveflag.originalY + waveflag.originalHeight)

	self.waveNode:setPositionY(minY - barHeight - waveY)
end

local leftSelectConfig = {
	xScale = 2,
	z = 20,
	cancelFlag = "flag_cancel_left",
	x = 0,
	yScale = 2,
	y = display.height / 4
}
local rightSelectConfig = {
	xScale = 2,
	z = 20,
	cancelFlag = "flag_cancel_right",
	yScale = 2,
	x = display.width,
	y = display.height / 4
}
local selectConfig, selectionArrow, skillCancelUI = nil
local enabledTilesMap = {}
local disabledTilesMap = {}
local selectedTilesMap = {}
local selectedUnitsMap = {}
local selectedTarget = nil
local loneTapTimeEnd = 1.2
local loneTapTimeStart = 0.5
local tapDistanceThrehold = 30
local TOUCH_STATE = {
	DRAG = 4,
	LONG_TAP = 3,
	LONG_READY = 2,
	TAP = 1,
	NONE = 0
}
local SKILL_TYPE = SkillManager.SKILL_TYPE
local selectedSkillType, selectedSkillIndex, skillSelectUnit, skillSelectPack = nil

function FRAME_dungeon_battle.clearOnScene()
	selectConfig = nil
	selectionArrow = nil
	skillCancelUI = nil
	selectedTarget = nil
	enabledTilesMap = {}
	disabledTilesMap = {}
	selectedTilesMap = {}
	selectedUnitsMap = {}
	selectedSkillType = nil
	selectedSkillIndex = nil
	skillSelectUnit = nil
	skillSelectPack = nil
end

function FRAME_dungeon_battle:checkTouchTap()
	local slot = self.touchData.slot

	if self.touchData.state == TOUCH_STATE.TAP or self.touchData.state == TOUCH_STATE.LONG_READY then
		local distanceOffset = math.sqrt(math.pow(self.touchData.beganX - self.touchData.x, 2) + math.pow(self.touchData.beganY - self.touchData.y, 2))

		if tapDistanceThrehold < distanceOffset then
			POP_read.close()

			if not self.touchData.isAuto and slot:isTouchEnabledTag() then
				self.touchData.state = TOUCH_STATE.DRAG

				MapFrameManager.pause("battle_touch_freeze")
				notify.dispatch("battle_freeze", true)

				self.touchData.isFreezed = true
				local itemIconPath = nil

				if selectedSkillType == SKILL_TYPE.ITEM then
					local itemInfo = InfoDungeon.getRune(self.touchData.index)
					itemIconPath = IconManager.getItemIcon(itemInfo.base_id)
					local itemData = CsvParser.getCsvData("item", itemInfo.base_id)

					POP_control_tip.open(itemData.use_tip)
				end

				self:createSkillSelection(self.touchData.x, self.touchData.y, itemIconPath)
			else
				self.touchData.state = TOUCH_STATE.NONE
			end
		end
	end

	if selectedSkillType == SKILL_TYPE.HERO then
		local heroIndex = self.touchData.index
		local hero = TeamManager.getHeroByIndex(heroIndex)

		if SkillManager.autoEnabled() and not SkillManager.isGuide() and hero and not hero:isSwitchSkill() then
			if self.touchData.state == TOUCH_STATE.TAP then
				local timeOffset = Time.time() - self.touchData.beganTime

				if loneTapTimeStart < timeOffset then
					self.touchData.state = TOUCH_STATE.LONG_READY

					print("$$$ hero", heroIndex, hero)

					if hero then
						POP_read.open(hero:isAutoSkill() and Localization.getSrcText("自动指挥系统取消") or Localization.getSrcText("自动指挥系统加载中"))
					end

					MapFrameManager.pause("battle_touch_freeze")
					notify.dispatch("battle_freeze", true)

					self.touchData.isFreezed = true
				end
			end

			if self.touchData.state == TOUCH_STATE.LONG_READY then
				local timeOffset = Time.time() - self.touchData.beganTime

				if timeOffset < loneTapTimeEnd then
					POP_read.setPercent(math.min(1, (timeOffset - loneTapTimeStart) / (loneTapTimeEnd - loneTapTimeStart)))
				else
					self.touchData.state = TOUCH_STATE.LONG_TAP

					POP_read.close()

					if hero then
						hero:setAutoSkill(not hero:isAutoSkill())
						self.touchData.slot:setAuto(hero:isAutoSkill())
					end
				end
			end
		end
	end
end

function FRAME_dungeon_battle:startSelectionLoop()
	local function checkSkillSelectionLoop()
		self:checkTouchTap()

		local distance = math.sqrt(math.pow(self.touchData.pos[1].y - self.touchData.y, 2) + math.pow(self.touchData.pos[1].x - self.touchData.x, 2))
		self.touchData.speed = self.touchData.speed * 0.5 + distance * 0.5

		table.insert(self.touchData.pos, {
			x = self.touchData.x,
			y = self.touchData.y
		})

		if #self.touchData.pos > 5 then
			table.remove(self.touchData.pos, 1)
		end

		local mapX1, mapY1 = self:fingerToMap(self.touchData.pos[1].x, self.touchData.pos[1].y)
		local mapX2, mapY2 = self:fingerToMap(self.touchData.x, self.touchData.y)
		self.touchData.angle = math.atan2(mapY2 - mapY1, mapX2 - mapX1)
	end

	self:addEnterFrame("checkSkillSelectionLoop", checkSkillSelectionLoop)
end

function FRAME_dungeon_battle:stopSelectionLoop()
	self:removeEnterFrame("checkSkillSelectionLoop")
end

function FRAME_dungeon_battle:refreshSelectArea(tiles, skillData)
	local newSelectTiles = {}
	local newSelectUnits = {}

	for i = 1, #tiles do
		local tile = tiles[i]
		local tag = tile:getTag()

		if tile:getVisible() then
			if not selectedTilesMap[tag] then
				local newSprite = tile:openAsset("skill_select")

				if newSprite then
					newSprite:setScale(0)
					transition.scaleTo(newSprite, {
						time = 0.1,
						scale = 1,
						easing = "sineOut"
					})
				end
			end

			selectedTilesMap[tag] = nil
		end

		newSelectTiles[tag] = tile
		local units, friendUnits = self:getAffectUnits(skillData, tile)

		for j, unit in ipairs(units) do
			if not unit.noEntity and not newSelectUnits[unit.id] then
				if not selectedUnitsMap[unit.id] then
					unit:openSkillSelect()
				end

				selectedUnitsMap[unit.id] = nil
				newSelectUnits[unit.id] = unit
			end
		end

		for j, unit in ipairs(friendUnits) do
			if not unit.noEntity and not newSelectUnits[unit.id] then
				if not selectedUnitsMap[unit.id] then
					unit:openSkillSelect(nil, true)
				end

				selectedUnitsMap[unit.id] = nil
				newSelectUnits[unit.id] = unit
			end
		end
	end

	for k, tile in pairs(selectedTilesMap) do
		tile:closeAsset("skill_select")
	end

	for k, unit in pairs(selectedUnitsMap) do
		unit:closeSkillSelect()
	end

	selectedTilesMap = newSelectTiles
	selectedUnitsMap = newSelectUnits
end

function FRAME_dungeon_battle:getAffectUnits(skillData, tile)
	local camp = 2

	if skillData.friend == 1 then
		camp = 1
	end

	local friendCamp = nil

	if skillData.friend == 3 then
		friendCamp = 1
	end

	local units = {}
	local friendUnits = {}

	for unitID, unit in pairs(tile.unitMap) do
		if unit.battleData then
			if unit.battleData.camp == camp then
				table.insert(units, unit)
			elseif unit.battleData.camp == friendCamp then
				table.insert(friendUnits, unit)
			end
		end
	end

	return units, friendUnits
end

function FRAME_dungeon_battle:clearSelectArea()
	for k, tile in pairs(selectedTilesMap) do
		tile:closeAsset("skill_select")
	end

	for k, unit in pairs(selectedUnitsMap) do
		unit:closeSkillSelect()
	end

	selectedTilesMap = {}
	selectedUnitsMap = {}
end

function FRAME_dungeon_battle:clearRangeArea()
	for k, tile in pairs(enabledTilesMap) do
		tile:closeAsset("skill_range")
	end

	for k, tile in pairs(disabledTilesMap) do
		tile:closeAsset("skill_range_disable")
	end

	enabledTilesMap = {}
	disabledTilesMap = {}
end

function FRAME_dungeon_battle:isTileWalkable(tile, unit)
	local walkLevel = 1
	local preBlock = nil
	local size = 1

	if unit then
		walkLevel = unit.walkLevel
		preBlock = unit.isBlock
		unit.isBlock = false
		size = unit.size
	end

	local result = false

	if size == 1 then
		result = tile:getWalkable(walkLevel)
	else
		for i = 0, size - 1 do
			for j = 0, size - 1 do
				local tempTile = global.map:getTile(tile.x + i, tile.y + j)

				if tempTile ~= nil and not tile:getWalkable(walkLevel) then
					result = false
				end
			end
		end

		result = true
	end

	if unit then
		unit.isBlock = preBlock
	end

	return result
end

function FRAME_dungeon_battle:getSkillSlot(index)
	return self.skillSlots[index]
end

function FRAME_dungeon_battle:onSlotTouch(slot, skillIndex, event, x, y)
	local unit = TeamManager.getUnit(skillIndex)

	if unit then
		local skillInfo = unit:getActiveSkill()

		if skillInfo then
			self:touchSlot(slot, SKILL_TYPE.HERO, skillIndex, event, x, y)
		end
	end
end

function FRAME_dungeon_battle:onItemSlotTouch(slot, skillIndex, event, x, y)
	local itemInfo = InfoDungeon.getRune(skillIndex)

	if itemInfo.num > 0 then
		self:touchSlot(slot, SKILL_TYPE.ITEM, skillIndex, event, x, y)
	end
end

function FRAME_dungeon_battle:onModaoSlotTouch(slot, skillIndex, event, x, y)
	local skillInfo = global.modao:getActiveSkill(skillIndex)

	if skillInfo then
		self:touchSlot(slot, SKILL_TYPE.MODAO, skillIndex, event, x, y)
	end
end

function FRAME_dungeon_battle:checkTouchFlyout()
	if self.touchData then
		return self.touchData.speed > 30
	else
		return false
	end
end

function FRAME_dungeon_battle:checkCancelUI(x, y)
	if skillCancelUI then
		local bigScale = self.bottomUI:getBigScale()
		x = x / bigScale
		y = y / bigScale
		local centerX, centerY = self.bottomUI:getFlagCenterByTag(selectConfig.cancelFlag)
		local distance = math.sqrt(math.pow(x - centerX, 2) + math.pow(y - centerY, 2))

		return distance <= 150
	end
end

function FRAME_dungeon_battle:touchSlot(slot, skillType, skillIndex, event, x, y)
	selectedSkillType = skillType
	selectedSkillIndex = skillIndex

	if WarMachine.on then
		if event == "began" then
			if selectedSkillType == SKILL_TYPE.HERO then
				selectConfig = rightSelectConfig
			elseif selectedSkillType == SKILL_TYPE.ITEM then
				selectConfig = rightSelectConfig
			elseif selectedSkillType == SKILL_TYPE.MODAO then
				selectConfig = leftSelectConfig
			end

			local isAuto = false
			local isHero = false

			if skillType == SKILL_TYPE.HERO then
				local hero = TeamManager.getHeroByIndex(skillIndex)

				if hero then
					isHero = true

					if hero:isAutoSkill() then
						isAuto = true
					end
				end
			end

			self.touchData = {
				angle = 0,
				speed = 0,
				beganX = x,
				beganY = y,
				x = x,
				y = y,
				pos = {
					{
						x = x,
						y = y
					}
				},
				beganTime = Time.time(),
				state = TOUCH_STATE.TAP,
				index = skillIndex,
				slot = slot,
				isAuto = isAuto
			}

			self:startSelectionLoop()
			self:clearSkillSelection(x, y)
		elseif event == "moved" then
			if not self.touchData then
				return
			end

			self.touchData.x = x
			self.touchData.y = y

			self:checkTouchTap()

			if self.touchData.state == TOUCH_STATE.DRAG then
				self:refreshSkillSelection(x, y)
			end
		elseif event == "ended" then
			if not self.touchData then
				return
			end

			self:stopSelectionLoop()
			POP_read.close()

			if self.touchData.state == TOUCH_STATE.TAP then
				if not self.touchData.isAuto and slot:isTouchEnabledTag() and skillType == SKILL_TYPE.HERO then
					local hero = TeamManager.getHeroByIndex(skillIndex)

					if hero then
						if hero:isSwitchSkill() then
							hero:switchSkill()
						elseif not hero:isAutoSkill() then
							hero:quickCast()
						end
					end
				end
			elseif self.touchData.state ~= TOUCH_STATE.LONG_READY then
				if self.touchData.state == TOUCH_STATE.LONG_TAP then
					-- Nothing
				elseif self.touchData.state == TOUCH_STATE.DRAG then
					local isCast = not self.castDisabled
					local isFlyout = false

					if self:checkTouchFlyout() then
						isCast = false
						isFlyout = true
						local mapX, mapY = self:fingerToMap(x, y)

						self:skillSelectArrowFlyout(mapX, mapY, self.touchData.speed, self.touchData.angle)
					end

					if isCast and skillCancelUI and self:checkCancelUI(x, y) then
						isCast = false
					end

					if isCast and skillType == SKILL_TYPE.HERO then
						local hero = TeamManager.getHeroByIndex(skillIndex)

						if hero and hero:isSwitchSkill() then
							hero:switchSkill()

							isCast = false
						end
					end

					self:clearSkillSelection(x, y, isCast, isFlyout)
				end
			end

			if self.touchData.isFreezed then
				MapFrameManager.resume("battle_touch_freeze")
				notify.dispatch("battle_freeze", false)
			end

			self.touchData = nil

			POP_control_tip.close()
		end
	end
end

function FRAME_dungeon_battle:clearBattleFreeze()
	if self.touchData then
		MapFrameManager.resume("battle_touch_freeze")
		POP_read.close()

		self.touchData.state = TOUCH_STATE.NONE
	end
end

function FRAME_dungeon_battle:fingerToMap(x, y)
	local emuMode = Cookie.get("emuMode") or 0
	local screenX, screenY = nil

	if emuMode == 1 then
		screenX = x
		screenY = y
	else
		screenX = (x - selectConfig.x) * selectConfig.xScale + selectConfig.x
		screenY = (y - selectConfig.y) * selectConfig.yScale + selectConfig.y
	end

	local mapX, mapY = global.map:screenToMap(screenX, screenY)

	return mapX, mapY
end

function FRAME_dungeon_battle:mapToFinger(x, y)
	local emuMode = Cookie.get("emuMode") or 0
	local screenX, screenY = global.map:mapToScreen(x, y)
	local fingerX, fingerY = nil

	if emuMode == 1 then
		fingerX = screenX
		fingerY = screenY
	else
		fingerX = (screenX - selectConfig.x) / selectConfig.xScale + selectConfig.x
		fingerY = (screenY - selectConfig.y) / selectConfig.yScale + selectConfig.y
	end

	return fingerX, fingerY
end

function FRAME_dungeon_battle:startSelectionEffect()
	local units = TeamManager.getTeam()

	for i, unit in ipairs(units) do
		if skillSelectUnit ~= unit then
			unit:setForceLight(64)
		end
	end
end

function FRAME_dungeon_battle:endSelectionEffect()
	local units = TeamManager.getTeam()

	for i, unit in ipairs(units) do
		unit:clearForceLight()
	end
end

function FRAME_dungeon_battle:setCancelDisabled(b)
	self.cancelDisabled = b
end

function FRAME_dungeon_battle:createSkillSelection(x, y, customItemIconPath)
	if selectedSkillType == SKILL_TYPE.HERO then
		local units = TeamManager.getTeam()
		skillSelectUnit = units[selectedSkillIndex]
		skillSelectPack = skillSelectUnit:getActiveSkill()
	elseif selectedSkillType == SKILL_TYPE.MODAO then
		skillSelectPack = global.modao:getActiveSkill(selectedSkillIndex)
		skillSelectUnit = skillSelectPack.caster

		global.modao:onPause(skillSelectPack.modaoID)
	elseif selectedSkillType == SKILL_TYPE.ITEM then
		local itemInfo = InfoDungeon.getRune(selectedSkillIndex)
		skillSelectPack = global.modao:getItemSkillPack(itemInfo.base_id)
		skillSelectUnit = skillSelectPack.caster

		global.modao:onPause(skillSelectPack.modaoID)
	end

	if not skillSelectPack then
		return
	end

	selectionArrow = Effect.new()

	if customItemIconPath then
		selectionArrow:loadPic(customItemIconPath)
	else
		selectionArrow:load(MiscConfig.battle_arrow)
	end

	selectionArrow.alwaysVisible = true
	selectionArrow.layer = 2

	selectionArrow:display(global.map)
	selectionArrow:selfUpdate()

	local skillData = skillSelectPack.data

	self:refreshRangeArea(skillSelectUnit, skillData)
	self:refreshSkillSelection(x, y)
	self:startSelectionEffect()

	if not self.cancelDisabled then
		local centerX, centerY = self.bottomUI:getFlagCenterByTag(selectConfig.cancelFlag)
		skillCancelUI = UIManager.getUI("com_skill_cancel")

		skillCancelUI:setPosition(centerX, centerY)
		self.bottomUI:addChild(skillCancelUI, 1000)

		local bg = skillCancelUI:getComponentByTag("bg")

		bg:setScale(0)
		skillCancelUI:setOpacity(0)
		transition.scaleTo(bg, {
			scale = 3,
			time = 0.2,
			easing = "sineOut"
		})
		transition.fadeTo(skillCancelUI, {
			time = 0.2,
			easing = "sineOut",
			opacity = 150
		})
	end
end

function FRAME_dungeon_battle:refreshSkillSelection(x, y)
	if not skillSelectPack then
		return
	end

	local mapX, mapY = self:fingerToMap(x, y)

	if selectionArrow and not tolua.isnull(selectionArrow) then
		selectionArrow:draw(mapX, mapY, true)
		selectionArrow:clearRefreshVisibleFrame()
		selectionArrow:retile()
	end

	local skillData = skillSelectPack.data

	self:refreshSkillArea(mapX, mapY, skillData)

	if skillCancelUI then
		local cancelIn = self:checkCancelUI(x, y)

		if cancelIn ~= skillCancelUI.cancelIn then
			skillCancelUI.cancelIn = cancelIn

			transition.stopTarget(skillCancelUI)

			if cancelIn then
				transition.fadeTo(skillCancelUI, {
					time = 0.1,
					easing = "sineOut",
					opacity = 255
				})
			else
				transition.fadeTo(skillCancelUI, {
					time = 0.1,
					easing = "sineOut",
					opacity = 150
				})
			end
		end
	end
end

function FRAME_dungeon_battle:refreshSkillArea(mapX, mapY, skillData)
	local affectCamp = nil
	affectCamp = skillData.friend == 0 and 3 - (skillSelectUnit.battleData.camp or 1) or skillSelectUnit.battleData.camp or 1
	local finalTarget = nil
	local affectUnits = WarMachine.getUnitsByCamp(affectCamp)

	if skillData.select_type == 0 then
		local x, y = global.map:tileToMap(skillSelectUnit.tile)
		selectedTarget = {
			x = x,
			y = y
		}

		self:refreshSelectArea(SkillManager.getAffectTiles(skillSelectUnit, skillData, skillSelectUnit.tile), skillData)
	elseif skillData.select_type == 1 then
		local bestUnit, bestDistance = nil

		for i = 1, #affectUnits do
			local affectUnit = affectUnits[i]

			if not affectUnit.battleData.die then
				local distance = math.sqrt(math.pow(affectUnit.y - mapY, 2) + math.pow(affectUnit.x - mapX, 2))
				local rangeTestOK = skillData.range < 0

				if not rangeTestOK then
					local mhdRange = math.abs(skillSelectUnit.tile.x - affectUnit.tile.x) + math.abs(skillSelectUnit.tile.y - affectUnit.tile.y)
					rangeTestOK = mhdRange <= skillData.range
				end

				if rangeTestOK and (bestDistance == nil or distance < bestDistance) then
					bestDistance = distance
					bestUnit = affectUnit
				end
			end
		end

		if bestUnit ~= selectedTarget then
			if selectedTarget then
				selectedTarget:closeSkillSelect()
			end

			selectedTarget = bestUnit

			if selectedTarget then
				selectedTarget:openSkillSelect()
			end
		end

		if selectedTarget then
			finalTarget = cc.p(selectedTarget.x, selectedTarget.y)
		end
	elseif skillData.select_type == 2 or skillData.select_type == 10 then
		local tile = global.map:mapToTile(mapX, mapY)

		if tile and not enabledTilesMap[tile:getTag()] then
			local bestTile, bestScore = nil
			local range = skillData.range

			for tag, inTile in pairs(enabledTilesMap) do
				local inTileX, inTileY = global.map:tileToMap(inTile)
				local range = math.sqrt(math.pow(mapY - inTileY, 2) + math.pow(mapX - inTileX, 2))
				local score = range

				if bestTile == nil or score < bestScore then
					bestTile = inTile
					bestScore = score
				end
			end

			tile = bestTile
		end

		if skillData.select_type == 10 then
			-- Nothing
		end

		if tile then
			local x, y = global.map:tileToMap(tile)
			selectedTarget = {
				x = x,
				y = y
			}
			local affectTiles = SkillManager.getAffectTiles(skillSelectUnit, skillData, tile)

			if #affectTiles == 0 then
				affectTiles = {
					tile
				}
			end

			self:refreshSelectArea(affectTiles, skillData)

			finalTarget = cc.p(selectedTarget.x, selectedTarget.y)
		end
	elseif skillData.select_type == 3 then
		local tile = global.map:mapToTile(mapX, mapY)

		if tile then
			selectedTarget = {
				x = mapX,
				y = mapY
			}

			self:refreshSelectArea(SkillManager.getAffectTiles(skillSelectUnit, skillData, tile), skillData)

			finalTarget = cc.p(selectedTarget.x, selectedTarget.y)
		end
	end

	if finalTarget and selectedSkillType == SKILL_TYPE.HERO and (self.skillArcTarget == nil or finalTarget.x ~= self.skillArcTarget.x or finalTarget.y ~= self.skillArcTarget.y) then
		if not self.skillArcNode then
			self.skillArcNode = display.newDrawNode()
			self.skillPointNode = display.newDrawNode()

			display.getRunningScene():addChild(self.skillArcNode)
			display.getRunningScene():addChild(self.skillPointNode)
		end

		self.skillArcNode:clear()
		self.skillPointNode:clear()

		if self.arcLoop then
			Looper.stopLoop(self, self.arcLoop)
		end

		local unitX = skillSelectUnit.x
		local unitY = skillSelectUnit.y
		local targetX = finalTarget.x
		local targetY = finalTarget.y
		local distance = math.sqrt(math.pow(targetY - unitY, 2) + math.pow(targetX - unitX, 2))
		local angle = math.atan2(targetY - unitY, targetX - unitX) + math.pi / 2
		local bezPoints = {}

		table.insert(bezPoints, cc.p(0, 0))
		table.insert(bezPoints, cc.p(distance / 2, math.pow(distance / 4, 0.7) * 5))
		table.insert(bezPoints, cc.p(distance, 0))

		local function getWingPoints(percent, w)
			local h = P_BEZ(percent, bezPoints).y
			local x = (targetX - unitX) * percent + unitX
			local y = (targetY - unitY) * percent + unitY
			local xWing = math.cos(angle) * w
			local yWing = math.sin(angle) * w
			local leftPtX, leftPtY = global.map:mapToScreen(x - xWing, y - yWing)
			local rightPtX, rightPtY = global.map:mapToScreen(x + xWing, y + yWing)

			return {
				leftPtX,
				leftPtY + h
			}, {
				rightPtX,
				rightPtY + h
			}
		end

		local function getCenterPoint(percent)
			local h = P_BEZ(percent, bezPoints).y
			local x = (targetX - unitX) * percent + unitX
			local y = (targetY - unitY) * percent + unitY
			local centerPtX, centerPtY = global.map:mapToScreen(x, y)

			return {
				centerPtX,
				centerPtY + h
			}
		end

		self.radiusStep = self.radiusStep or 0
		local radiusCycle = 30
		local maxRadius = 32
		local minRadius = 8

		local function arcLoop()
			self.skillPointNode:clear()

			local circlePoints = {}
			local centerX, centerY = global.map:mapToScreen(targetX, targetY)
			local alpha = 0.4
			local radius = maxRadius
			local radiusStep = self.radiusStep % radiusCycle

			if radiusStep > radiusCycle / 2 then
				alpha = (radiusCycle - radiusStep) / (radiusCycle / 2) * alpha
			else
				radius = radiusStep / (radiusCycle / 2) * (maxRadius - minRadius) + minRadius
			end

			self.radiusStep = self.radiusStep + 1

			for i = 1, 16 do
				local x = centerX + math.cos(angle + i / 16 * math.pi * 2) * radius
				local y = centerY + math.sin(angle + i / 16 * math.pi * 2) * radius / 2

				table.insert(circlePoints, {
					x,
					y
				})
			end

			display.newPolygon(circlePoints, {
				borderWidth = 0,
				fillColor = cc.c4f(1, 1, 1, alpha)
			}, self.skillPointNode)

			circlePoints = {}

			for i = 1, 16 do
				local x = centerX + math.cos(angle + i / 16 * math.pi * 2) * minRadius
				local y = centerY + math.sin(angle + i / 16 * math.pi * 2) * minRadius / 2

				table.insert(circlePoints, {
					x,
					y
				})
			end

			display.newPolygon(circlePoints, {
				borderWidth = 0,
				fillColor = cc.c4f(1, 1, 1, 0.6)
			}, self.skillPointNode)
		end

		self.arcLoop = arcLoop

		Looper.startLoop(self, self.arcLoop)

		local preLeftPt, preRightPt, preCenterPt = nil
		local segment = 16
		local segmentStart = 2
		local segmentTotal = segment - segmentStart

		for i = segmentStart, segment do
			local color = cc.c4f(1, 1, 1, 0.8 * math.min(1, (i - segmentStart) / 6))

			if i < segment then
				local centerPt = getCenterPoint((i + 0.5) / segment)
				local leftPt, rightPt = getWingPoints(i / segment, math.pow((segmentTotal - (i - segmentStart)) / segmentTotal, 3) * 30 + 0)

				if preLeftPt and preRightPt then
					display.newPolygon({
						leftPt,
						centerPt,
						rightPt,
						preRightPt,
						preCenterPt,
						preLeftPt
					}, {
						borderWidth = 0,
						fillColor = color
					}, self.skillArcNode)
				end

				preCenterPt = centerPt
				preLeftPt = leftPt
				preRightPt = rightPt
			else
				local centerPt = getCenterPoint(1)

				display.newPolygon({
					centerPt,
					preRightPt,
					preCenterPt,
					preLeftPt
				}, {
					borderWidth = 0,
					fillColor = color
				}, self.skillArcNode)
			end
		end
	end
end

function FRAME_dungeon_battle:clearSkillSelection(x, y, isCast, isFlyout)
	if self.skillArcNode then
		self.skillArcNode:clear()
		self.skillPointNode:clear()
		Looper.stopLoop(self, self.arcLoop)
	end

	if selectedTarget and selectedTarget.closeSkillSelect then
		selectedTarget:closeSkillSelect()
	end

	self:clearSelection(isFlyout)

	if isCast and selectedTarget then
		local fullFrameTime = WarMachine.getFrame()

		if skillSelectPack and (not skillSelectPack.opCD or skillSelectPack.opCD < fullFrameTime) then
			local skillData = skillSelectPack.data

			if skillData.cd ~= 0 then
				skillSelectPack.opCD = fullFrameTime + MiscConfig.castCD
			end

			if selectedSkillType == SKILL_TYPE.HERO then
				if skillSelectUnit.castHandSkill then
					skillSelectUnit:castHandSkill(skillSelectPack, selectedTarget)
				end
			elseif selectedSkillType == SKILL_TYPE.ITEM then
				local itemInfo = InfoDungeon.getRune(selectedSkillIndex)

				if itemInfo.num > 0 then
					global.modao:castSkill(skillSelectPack, selectedTarget, true)
					InfoDungeon.useRuneBattle(selectedSkillIndex)
				end
			elseif selectedSkillType == SKILL_TYPE.MODAO then
				global.modao:castSkill(skillSelectPack, selectedTarget)
			end
		end
	end

	if skillSelectPack and (selectedSkillType == SKILL_TYPE.MODAO or selectedSkillType == SKILL_TYPE.ITEM) then
		global.modao:onResume(skillSelectPack.modaoID)
	end

	selectedTarget = nil
	skillSelectUnit = nil
	skillSelectPack = nil

	self:endSelectionEffect()

	if selectedSkillType == SKILL_TYPE.ITEM then
		self:refreshRuneNum(selectedSkillIndex)
	end
end

function FRAME_dungeon_battle:clearSelection(isFlyout)
	self:clearRangeArea()
	self:clearSelectArea()

	if selectionArrow and not tolua.isnull(selectionArrow) then
		if not isFlyout then
			selectionArrow:removeSelf()
		end

		selectionArrow = nil
	end

	if skillCancelUI then
		local ui = skillCancelUI
		local bg = ui:getComponentByTag("bg")

		transition.stopTarget(ui)
		transition.stopTarget(bg)
		transition.scaleTo(bg, {
			scale = 0,
			time = 0.2,
			easing = "sineOut"
		})
		transition.fadeTo(ui, {
			time = 0.2,
			easing = "sineOut",
			opacity = 0,
			onComplete = function ()
				ui:removeSelf()
			end
		})

		skillCancelUI = nil
	end
end

function FRAME_dungeon_battle:skillSelectArrowFlyout(x, y, speed, angle)
	if not selectionArrow then
		return
	end

	if selectionArrow and not tolua.isnull(selectionArrow) then
		local arrow = selectionArrow
		selectionArrow = nil
		arrow.x = x
		arrow.y = y
		local arrowMoveLoop = nil

		function arrowMoveLoop(obj, frame, passed, sharp)
			local x = arrow.x + math.cos(angle) * speed * passed
			local y = arrow.y + math.sin(angle) * speed * passed
			local tile = global.map:mapToTile(x, y)

			if not tile or not tile:getVisible() then
				Looper.stopLoop(arrow, arrowMoveLoop)
				arrow:removeSelf()
			else
				arrow.x = x
				arrow.y = y

				arrow:draw()
			end
		end

		Looper.startLoop(arrow, arrowMoveLoop)
	end
end

function FRAME_dungeon_battle:refreshRangeArea(caster, skillData)
	local tiles, disabledTiles = SkillManager.getRangeArea(caster, skillData)

	for i, tile in ipairs(tiles) do
		enabledTilesMap[tile.tag] = tile

		tile:openAsset("skill_range")
	end

	for i, tile in ipairs(disabledTiles) do
		disabledTilesMap[tile.tag] = tile

		tile:openAsset("skill_range_disable")
	end
end

function FRAME_dungeon_battle:setToLeft()
	selectConfig = leftSelectConfig
end

function FRAME_dungeon_battle:setToRight()
	selectConfig = rightSelectConfig
end

function FRAME_dungeon_battle:setSkillSelectUnit(unit)
	skillSelectUnit = unit
end

function FRAME_dungeon_battle:initModao()
	if InfoModao.enabled() then
		self.modaoSlots = {}

		for i = 1, GameConfig.modao_skill_num do
			local slotUI = DungeonSlot.new(self.bottomUI:getRectByFlag("flag_modao_" .. i))

			self.bottomUI:addChild(slotUI, 100)
			table.insert(self.modaoSlots, slotUI)
			slotUI:toTouchable()
			slotUI:addTouch(function (event, x, y)
				if not SkillManager.isLocked() then
					self:onModaoSlotTouch(slotUI, i, event, x, y)
				end
			end)
		end

		notify.safeRegister(self, "modao_mana_max", function (mana)
			self:updateModaoMax()
		end)
		notify.safeRegister(self, "modao_mana", function (mana)
			self:updateModaoMana(mana)
		end)
		notify.safeRegister(self, "modao_hidden", function ()
			self:refreshModaoSlots()
		end)

		self.currentMp = nil

		MapFrameManager.startLoop(self, self.updateModaoManaLoop)
	else
		self:hideModaoUI()
	end
end

function FRAME_dungeon_battle:updateModaoManaLoop()
	if self.isBattle then
		local currentMp = InfoModao.getMp()
		local sharpCurrentMp = math.floor(currentMp)

		if self.sharpCurrentMp ~= sharpCurrentMp then
			self.sharpCurrentMp = sharpCurrentMp

			self:updateModaoMana(currentMp)
		end
	end
end

function FRAME_dungeon_battle:clearModaoBlock()
	self.bottomUI:clearDuplicated("mana_block")
	self.bottomUI:clearDuplicated("mana_shadow")
	self.bottomUI:clearDuplicated("mana_light")

	self.manaBlocks = nil
	self.manaLights = nil

	MapFrameManager.stopLoop(self, updateModaoManaLoop)
end

function FRAME_dungeon_battle:hideModaoUI()
	self:clearModaoBlock()
	self.bottomUI:removeComponentByTag("mana_bg")
	self.bottomUI:removeComponentByTag("mana_block")
	self.bottomUI:removeComponentByTag("mana_shadow")
	self.bottomUI:removeComponentByTag("mana_light")
	self.bottomUI:removeComponentByTag("mana_left")
	self.bottomUI:removeComponentByTag("mana_right")
	self.bottomUI:removeComponentByTag("mana_hightlight")

	for i = 1, GameConfig.modao_skill_num do
		local slotBg = self.bottomUI:getComponentByTag("modao_bg_" .. i)

		slotBg:setVisible(false)
	end
end

function FRAME_dungeon_battle:updateModaoMax()
	if InfoModao.enabled() then
		self:clearModaoBlock()

		local mana_left = self.bottomUI:getComponentByTag("mana_left")
		local mana_right = self.bottomUI:getComponentByTag("mana_right")

		mana_right:setScaleX(-1)

		local mana_hightlight = self.bottomUI:getComponentByTag("mana_hightlight")

		mana_hightlight:setVisible(false)
		mana_hightlight:setLocalZOrder(1000)

		local manaBg = self.bottomUI:getComponentByTag("mana_bg")
		local manaFlag = self.bottomUI:getFlagByTag("flag_mana")
		local maxMp = InfoModao.getMpMax()
		local blockSpaceX = 2
		local blockSpaceY = 20
		local blockPerLine = 5
		local manaBlock = self.bottomUI:getComponentByTag("mana_block")
		local manaShadow = self.bottomUI:getComponentByTag("mana_shadow")
		local manaLight = self.bottomUI:getComponentByTag("mana_light")
		local blockWidth = (manaFlag.width - blockSpaceX * (blockPerLine - 1)) / blockPerLine
		local manaBlockNum = math.ceil(maxMp / MiscConfig.MP_BLOCK)
		local lines = math.ceil(manaBlockNum / blockPerLine)
		self.manaBlocks = self.bottomUI:duplicateComponent("mana_block", manaBlockNum - 1, 0, 0)
		self.manaLights = self.bottomUI:duplicateComponent("mana_light", manaBlockNum - 1, 0, 0)
		local manaShadows = self.bottomUI:duplicateComponent("mana_shadow", manaBlockNum - 1, 0, 0)
		local bgHeight = blockSpaceY * (lines - 1)

		manaBg:setSize(nil, manaBg.originalHeight + bgHeight)
		mana_left:setPos(nil, mana_left.originalY + bgHeight / 2)
		mana_right:setPos(nil, mana_right.originalY + bgHeight / 2)

		for i = 1, manaBlockNum do
			local blockX = (i - 1) % blockPerLine
			local blockY = math.floor((i - 1) / blockPerLine)
			local block = self.manaBlocks[i]
			local light = self.manaLights[i]
			local shadow = manaShadows[i]
			local x = manaFlag.x - blockWidth / 2 + blockX * (blockWidth + blockSpaceX)

			block:setSize(blockWidth - 6)
			block:setAnchorPoint(cc.p(0, 0.5))
			block:setLocalZOrder(100)
			block:setPos(x + 6, manaBlock.y + blockY * blockSpaceY)
			light:setSize(blockWidth + 14)
			light:setAnchorPoint(cc.p(0, 0.5))
			light:setLocalZOrder(100)
			light:setPos(x - 14, manaLight.y + blockY * blockSpaceY)
			shadow:setSize(blockWidth)
			shadow:setAnchorPoint(cc.p(0, 0.5))
			shadow:setLocalZOrder(90)
			shadow:setPos(x, manaShadow.y + blockY * blockSpaceY)

			if maxMp < i * MiscConfig.MP_BLOCK then
				shadow:setScaleX((maxMp - MiscConfig.MP_BLOCK * (i - 1)) / MiscConfig.MP_BLOCK)
			end
		end
	end
end

function FRAME_dungeon_battle:updateModaoMana(mana)
	if InfoModao.enabled() then
		local currentMp = nil

		if mana then
			currentMp = mana
		else
			currentMp = InfoModao.getMp()
		end

		local mana_hightlight = self.bottomUI:getComponentByTag("mana_hightlight")

		mana_hightlight:setVisible(false)

		local absMana = math.abs(currentMp)

		if self.manaBlocks then
			for i, block in ipairs(self.manaBlocks) do
				local block = self.manaBlocks[i]
				local light = self.manaLights[i]

				if absMana <= (i - 1) * MiscConfig.MP_BLOCK then
					block:setVisible(false)
					light:setVisible(false)
				else
					block:setVisible(true)

					if absMana >= i * MiscConfig.MP_BLOCK then
						light:setVisible(true)
						block:setScaleX(1)
					else
						light:setVisible(false)

						local scaleX = (absMana - (i - 1) * MiscConfig.MP_BLOCK) / MiscConfig.MP_BLOCK

						block:setScaleX(scaleX)
						mana_hightlight:setVisible(true)

						local x, y = block:getPosition()

						mana_hightlight:setPosition(x + scaleX * block.width, y)
					end
				end
			end
		end

		for i, slotUI in ipairs(self.modaoSlots) do
			slotUI:onModaoManaChanged(currentMp)
		end
	end
end

function FRAME_dungeon_battle:coutDmg(total, dmg)
	local str = nil

	if total == 0 then
		str = 0
	else
		str = math.round(dmg / total * 100)
	end

	self.mainUI:createLabelOnFlag("flag_count_dmg", "mdskill " .. str .. "%")
end

function FRAME_dungeon_battle:startCount()
	self.mainUI:createLabelOnFlag("flag_count_dmg", "mdskill 0%")

	local function loop()
		local time = math.floor(WarMachine.getFrame() / 6) / 10

		self.mainUI:createLabelOnFlag("flag_count_time", "time: " .. time .. "s")
	end

	self:addEnterFrame("battle_count", loop)
	loop()
end

function FRAME_dungeon_battle:stopCount()
	self:removeEnterFrame("battle_count")
end

function FRAME_dungeon_battle:guideSetSkillEnabled(index, enabled)
	self.skillSlots[index]:setSkillEnabled(enabled)
end

function FRAME_dungeon_battle:setCastDisabled(b)
	self.castDisabled = b
end

function FRAME_dungeon_battle:onExit()
	FRAME_dungeon_battle.super.onExit(self)
	TeamManager.clearUnitChangeListener()
end

return FRAME_dungeon_battle
