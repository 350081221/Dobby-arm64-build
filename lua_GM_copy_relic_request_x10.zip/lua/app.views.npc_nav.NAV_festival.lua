local NAV_base = import(".NAV_base")
local NAV_fesitval = class("NAV_fesitval", NAV_base)

function NAV_fesitval.open(npc)
	local ui = NAV_fesitval.new(npc)

	return ui
end

function NAV_fesitval:ctor(npc)
	NAV_fesitval.super.ctor(self, npc, "nav_festival")
end

function NAV_fesitval:init()
	NAV_fesitval.super.init(self)

	local festivalData = InfoFestival.getDataForNPC(self.npc.baseID)
	self.festival_id = festivalData.id
	local gachaArr = InfoGacha.getList(self.festival_id)

	if #gachaArr == 0 then
		self:setButtonVisible(3, false)
	else
		local gachaData = gachaArr[1]
		local ui = self.buttons[3].ui

		self:setButtonName(ui, gachaData.button_name)
	end
end

function NAV_fesitval:onTap(index)
	NAV_fesitval.super.onTap(self, index)

	if index == 1 then
		local opening, actv_id = InfoFestival.checkShopOpening(self.festival_id)

		if opening then
			InfoFestival.setShopActvID(actv_id)
			FRAME_big_shop.open(InfoFestival, self.npc)
		else
			Alert.open(Localization.getSrcText("兑换已结束"))
		end
	elseif index == 2 then
		FRAME_festival_preview.open(self.festival_id)
	elseif index == 3 then
		if InfoFestival.checkOpening(self.festival_id) then
			FRAME_gacha.open(self.npc, self.festival_id)
		else
			Alert.open(Localization.getSrcText("活动已结束"))
		end
	end
end

return NAV_fesitval
