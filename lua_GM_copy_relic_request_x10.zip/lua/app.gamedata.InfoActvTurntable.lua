local InfoActvTurntable = {}
local dataMap = {}

function InfoActvTurntable.init()
	Connection.listen("actv_turntable_sync", InfoActvTurntable.sync)
end

app:addToAppEnterCall(InfoActvTurntable.init)

function InfoActvTurntable.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoActvTurntable.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("actv_turntable_query", callback)
end

function InfoActvTurntable.onQuery(rcvData)
	dump(rcvData, "actv_turntable_query", 10)

	dataMap = {}

	for i, v in ipairs(rcvData.list) do
		dataMap[v.actv_id] = v
	end

	dump(dataMap, "$$$ dataMap")
end

function InfoActvTurntable.sync(data)
	dump(data, "InfoActvTurntable.sync", 10)

	if data.list then
		for i, syncData in ipairs(data.list) do
			if dataMap[syncData.actv_id] then
				for k, v in pairs(syncData) do
					dataMap[syncData.actv_id][k] = v
				end
			else
				dataMap[syncData.actv_id] = syncData
			end
		end
	end

	notify.dispatch("actv_redot")
	ManagerInfo.dataChange("actv_turntable")
end

function InfoActvTurntable.roll(actv_id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("actv_turntable_roll", {
		actv_id = actv_id
	}, callback)
end

function InfoActvTurntable.reset(actv_id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "actv_turntable_reset")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("actv_turntable_reset", {
		actv_id = actv_id
	}, callback)
end

function InfoActvTurntable.checkOpening(actv_id)
	local opening = InfoActv.checkBindOpening(actv_id, GameConfig.ACTV_TYPE.turntable)

	return opening, actv_id
end

function InfoActvTurntable.checkShopOpening(actv_id)
	local opening = InfoActv.checkBindShopOpening(actv_id, GameConfig.ACTV_TYPE.turntable)

	return opening, actv_id
end

function InfoActvTurntable.getRecord(record, index)
	return BitUtil.getBitByIndex(record, index)
end

function InfoActvTurntable.checkRewarded(actv_id, index)
	local data = dataMap[actv_id]

	if data then
		return InfoActvTurntable.getRecord(data.turn_data, index) > 0
	end

	return false
end

local maxTurnCache = nil

function InfoActvTurntable.getCSV(data)
	if not maxTurnCache then
		maxTurnCache = {}
		local csvRaw = CsvParser.getCsvRaw("turntable_group")

		for _, csv in pairs(csvRaw) do
			if not maxTurnCache[csv.group] or maxTurnCache[csv.group] < csv.turn then
				maxTurnCache[csv.group] = csv.turn
			end
		end
	end

	local group = data.config_id
	local turn = math.min(data.curr_turn, maxTurnCache[group])

	return CsvParser.getFilteredData("turntable_group", {
		group = group,
		turn = turn
	})
end

function InfoActvTurntable.countRedot(actv_id)
	local redotCount = 0
	local opening = InfoActvTurntable.checkOpening(actv_id)

	if opening then
		local data = InfoActvTurntable.getData(actv_id)

		if data then
			local csv = InfoActvTurntable.getCSV(data)
			local groupCSV = CsvParser.getCsvData("turntable", csv.group)

			if groupCSV.cost_num <= InfoItem.getNum(groupCSV.cost_id) then
				redotCount = redotCount + 1
			end
		end
	end

	return redotCount
end

function InfoActvTurntable.getData(actv_id)
	return dataMap[actv_id]
end

return InfoActvTurntable
