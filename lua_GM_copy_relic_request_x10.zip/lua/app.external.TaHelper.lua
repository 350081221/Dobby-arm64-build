local json = require("framework.json")
local TaHelper = {}

function TaHelper.taLogin(id)
	if device.platform == "android" then
		TaHelper.taLoginAndroid(id)
	elseif device.platform == "ios" then
		TaHelper.taLoginIos(id)
	end
end

function TaHelper.taLoginAndroid(id)
	local javaClassName = "com.gasura.general.LuaBridge"
	local javaMethodName = "taLogin"
	local javaParams = {
		id
	}
	local javaMethodSig = "(Ljava/lang/String;)V"

	luaj.callStaticMethod(javaClassName, javaMethodName, javaParams, javaMethodSig)
end

function TaHelper.taLoginIos(id)
	local methodName = "taLogin"
	local params = {
		id = id
	}
	local ok, ret = luaoc.callStaticMethod("AppController", methodName, params)

	if ok then
		print("$$$ LuaBridge.callIos ok", methodName)
	else
		print(string.format("LuaBridge %s - call API failure, error code: %s", methodName, tostring(ret)))
	end
end

function TaHelper.taLogout()
	if device.platform == "android" then
		TaHelper.taLogoutAndroid()
	elseif device.platform == "ios" then
		TaHelper.taLogoutIos()
	end
end

function TaHelper.taLogoutAndroid()
	local javaClassName = "com.gasura.general.LuaBridge"
	local javaMethodName = "taLogout"
	local javaParams = {}
	local javaMethodSig = "()V"

	luaj.callStaticMethod(javaClassName, javaMethodName, javaParams, javaMethodSig)
end

function TaHelper.taLogoutIos()
	local methodName = "taLogout"
	local params = {}
	local ok, ret = luaoc.callStaticMethod("AppController", methodName, params)

	if ok then
		print("$$$ LuaBridge.callIos ok", methodName)
	else
		print(string.format("LuaBridge %s - call API failure, error code: %s", methodName, tostring(ret)))
	end
end

function TaHelper.taSetSuperProperties(params)
	params = params or {}

	if device.platform == "android" then
		TaHelper.taSetSuperPropertiesAndroid(params)
	elseif device.platform == "ios" then
		TaHelper.taSetSuperPropertiesIos(params)
	end
end

function TaHelper.taSetSuperPropertiesAndroid(params)
	local javaClassName = "com.gasura.general.LuaBridge"
	local javaMethodName = "taSetSuperProperties"

	if type(params) == "table" then
		params = json.encode(params)
	elseif type(params) == "number" then
		params = tostring(params)
	end

	local javaParams = {
		params
	}
	local javaMethodSig = "(Ljava/lang/String;)V"

	luaj.callStaticMethod(javaClassName, javaMethodName, javaParams, javaMethodSig)
end

function TaHelper.taSetSuperPropertiesIos(params)
	local methodName = "taSetSuperProperties"
	local ok, ret = luaoc.callStaticMethod("AppController", methodName, params)

	if ok then
		print("$$$ LuaBridge.callIos ok", methodName)
	else
		print(string.format("LuaBridge %s - call API failure, error code: %s", methodName, tostring(ret)))
	end
end

function TaHelper.getTaID()
	local originalID = InfoUser.getOriginalID()
	local taID = nil

	if empty(originalID) then
		taID = InfoUser.getID() .. "@server_" .. global.server_id
	else
		taID = InfoUser.getOriginalID() .. "@server_" .. InfoUser.getServerID()
	end

	return taID
end

local detailGuideAlreadyMap = {}

function TaHelper.taGuideDetail(id, isFinal)
	if not CONFIG.is_ta then
		return
	end

	if InfoGuide.isFin() and not isFinal then
		return
	end

	local csv = CsvParser.getCsvData("ta_guide_detail", id)

	if not csv then
		return
	end

	local maxLayer = InfoDungeon.getAbyssMaxLayer()

	if maxLayer ~= csv.max_layer then
		return
	end

	if detailGuideAlreadyMap[id] then
		return
	end

	detailGuideAlreadyMap[id] = true
	local data = {
		id = id,
		["#first_check_id"] = TaHelper.getTaID()
	}

	TaHelper.taTrack("guide_detail", data)
	Log.debug("$$$$$$$$$$$$$$$$$$ taGuideDetail", id, TaHelper.getTaID())
end

function TaHelper.warnTeamScore(level, score)
	local warnValue = 0
	local monster_base_num = CsvParser.getCsvData("monster_base_num", level)

	if monster_base_num and not empty(monster_base_num.safe_score) and score < monster_base_num.safe_score then
		warnValue = math.floor((1 - score / monster_base_num.safe_score) * 10000)
	end

	return warnValue
end

function TaHelper.taTrack(trackName, params)
	Log.debug("$$$ taTrack", trackName, json.encode(params))

	params = params or {}
	params.version = version

	if global then
		params.server_id = tostring(global.server_id)
		params.sub_channel = global.channel_type or 0
	end

	params.channel = CONFIG.qudao_code
	params.sys_lang = CONFIG.lang_sys
	params.sys_country = CONFIG.country_sys
	params.lang = Localization.getLang()

	if InfoUser then
		params.nick_name = InfoUser.getNickName()
	end

	if InfoOrder then
		params.acc_pay = InfoOrder.getTotalPay()
	end

	params.pack_tag = PACK_TAG or ""

	if InfoArena then
		local data = InfoArena.getData()

		if data then
			local division = InfoArena.getDivision(data.points, InfoArena.getMyArea())
			params.arena_level = division.id
		end
	end

	if InfoHero then
		params.total_power = InfoHero.getTeamScore()
	end

	if InfoDungeon then
		params.max_dungeon_level = InfoDungeon.getAbyssMaxLevel()
	end

	if InfoItem then
		params.gold = InfoItem.getNum(GameConfig.coin_item)
		params.diamond = InfoItem.getNum(GameConfig.zuan_item)
	end

	if device.platform == "android" then
		TaHelper.taTrackAndroid(trackName, params)
	elseif device.platform == "ios" then
		TaHelper.taTrackIos(trackName, params)
	end
end

function TaHelper.taTrackAndroid(trackName, params)
	local javaClassName = "com.gasura.general.LuaBridge"
	local javaMethodName = "taTrack"

	if type(params) == "table" then
		params = json.encode(params)
	elseif type(params) == "number" then
		params = tostring(params)
	end

	local javaParams = {
		trackName,
		params
	}
	local javaMethodSig = "(Ljava/lang/String;Ljava/lang/String;)V"

	luaj.callStaticMethod(javaClassName, javaMethodName, javaParams, javaMethodSig)
end

function TaHelper.taTrackIos(trackName, params)
	local methodName = "taTrack"
	params.trackName = trackName
	local ok, ret = luaoc.callStaticMethod("AppController", methodName, params)

	if ok then
		print("$$$ LuaBridge.callIos ok", methodName)
	else
		print(string.format("LuaBridge %s - call API failure, error code: %s", methodName, tostring(ret)))
	end
end

function TaHelper.taUserSet(isOnce, params)
	Log.debug("$$$ taUserSet", isOnce, json.encode(params))

	params = params or {}

	if global then
		params.sub_channel = global.channel_type or 0
	end

	params.channel = CONFIG.qudao_code
	params.sys_lang = CONFIG.lang_sys
	params.sys_country = CONFIG.country_sys
	params.lang = Localization.getLang()

	if InfoUser then
		params.nick_name = InfoUser.getNickName()
	end

	if InfoOrder then
		params.acc_pay = InfoOrder.getTotalPay()
	end

	params.pack_tag = PACK_TAG or ""

	dump(params, "$$$ taUserSet params", 10)

	if device.platform == "android" then
		TaHelper.taUserSetAndroid(isOnce, params)
	elseif device.platform == "ios" then
		TaHelper.taUserSetIos(isOnce, params)
	end
end

function TaHelper.taUserSetAndroid(isOnce, params)
	local javaClassName = "com.gasura.general.LuaBridge"
	local javaMethodName = "taUserSet"

	if isOnce then
		javaMethodName = "taUserSetOnce"
	end

	if type(params) == "table" then
		params = json.encode(params)
	elseif type(params) == "number" then
		params = tostring(params)
	end

	local javaParams = {
		params
	}
	local javaMethodSig = "(Ljava/lang/String;)V"

	luaj.callStaticMethod(javaClassName, javaMethodName, javaParams, javaMethodSig)
end

function TaHelper.taUserSetIos(isOnce, params)
	local methodName = "taUserSet"

	if isOnce then
		methodName = "taUserSetOnce"
	end

	local ok, ret = luaoc.callStaticMethod("AppController", methodName, params)

	if ok then
		print("$$$ LuaBridge.callIos ok", methodName)
	else
		print(string.format("LuaBridge %s - call API failure, error code: %s", methodName, tostring(ret)))
	end
end

function TaHelper.getHeroInfo(heroInfo)
	if device.platform == "ios" then
		return ""
	end

	local taInfo = {
		id = heroInfo.id,
		base_id = heroInfo.base_id,
		quality = heroInfo.quality,
		level = heroInfo.level,
		equips = {}
	}
	local equips = InfoEquip.getEquipListOnHero(heroInfo.id)

	for i, equipInfo in ipairs(equips) do
		table.insert(taInfo.equips, equipInfo.id)
	end

	return taInfo
end

function TaHelper.getHeroInfoAll()
	local heros = InfoHero.getTeam()
	local arr = {}

	for i, heroInfo in ipairs(heros) do
		table.insert(arr, TaHelper.getHeroInfo(heroInfo))
	end

	return arr
end

local taAssetsMap = nil

local function checkItem(itemID)
	if not taAssetsMap then
		taAssetsMap = {}
		local csvRaw = CsvParser.getCsvRaw("ta_asset_item")

		for k, csv in pairs(csvRaw) do
			taAssetsMap[csv.id] = true
		end
	end

	return taAssetsMap[itemID]
end

local assetID, assetName, assetStackMap = nil

function TaHelper.startAsset(id)
	assetID = id
	local csv = CsvParser.getCsvData("ta_asset", id, nil, true)

	if csv then
		assetName = csv.name
	else
		assetName = nil
	end

	assetStackMap = {}
end

function TaHelper.endAsset()
	if assetStackMap then
		local getArr = {}
		local costArr = {}
		local ckeckOK = false

		for base_id, num in pairs(assetStackMap) do
			if num > 0 then
				table.insert(getArr, {
					asset_id = base_id,
					change_num = num,
					change_cmd = assetID,
					change_reason = assetName or "",
					after_num = InfoItem.getNum(base_id)
				})
			elseif num < 0 then
				table.insert(costArr, {
					asset_id = base_id,
					change_num = -num,
					change_cmd = assetID,
					change_reason = assetName or "",
					after_num = InfoItem.getNum(base_id)
				})
			end

			if checkItem(base_id) then
				ckeckOK = true
			end
		end

		if ckeckOK then
			if #getArr > 0 then
				TaHelper.taTrack("asset_get", {
					asset_info = getArr
				})
			end

			if #costArr > 0 then
				TaHelper.taTrack("asset_cost", {
					asset_info = costArr
				})
			end
		end
	end

	assetName = nil
	assetStackMap = nil
end

function TaHelper.onItemSync(changedMap)
	if assetStackMap then
		for base_id, num in pairs(changedMap) do
			if not assetStackMap[base_id] then
				assetStackMap[base_id] = num
			else
				assetStackMap[base_id] = assetStackMap[base_id] + num
			end
		end
	end
end

function TaHelper.onOrderDone(data)
	if not data then
		return
	end

	local taData = {
		amount_100 = data.amount_100,
		currency = data.currency,
		order_id = data.order_id,
		currency = data.currency,
		asset_info = {}
	}

	if data.rewards then
		for i, v in ipairs(data.rewards) do
			if not taData.asset_info then
				taData.asset_info = {}
			end

			table.insert(taData.asset_info, v)
		end
	end

	TaHelper.taTrack("order_done", taData)
end

function TaHelper.clearOnReconnect()
	detailGuideAlreadyMap = {}
end

return TaHelper
