local UI_base = import("..UI_base")
local BattleHead = class("BattleHead", UI_base)
local revive_color = cc.c3b(255, 255, 255)
local shieldbar_color = cc.c3b(57, 230, 255)
local shieldbar_restore_color = cc.c3b(215, 14, 47)

function BattleHead:ctor(uiName, unit)
	BattleHead.super.ctor(self, uiName)

	if unit then
		self:setUnit(unit)
	end
end

function BattleHead:init()
	self:initUI()

	if self.equipUpSlots then
		for k, v in pairs(self.equipUpSlots) do
			v:removeSelf()
		end

		self.equipUpSlots = nil
	end
end

function BattleHead:initUI()
	if self:getComponentByTag("hp_bar") and not self:getBarByTag("hp_bar") then
		self:createBarByTag("hp_bar", Style.green)
	end

	if self:getComponentByTag("heal_bar") and not self:getBarByTag("heal_bar") then
		self:createBarByTag("heal_bar", Style.blue)
		self:getBarByTag("heal_bar"):setVisible(false)
	end

	if self:getComponentByTag("touch") then
		self:getComponentByTag("touch"):setOpacity(0)
	end

	if self:getComponentByTag("leader") then
		self:getComponentByTag("leader"):setVisible(false)
	end

	local cdFlash = self:getComponentByTag("cd_flash")

	if cdFlash then
		cdFlash:setVisible(false)
		cdFlash:setLocalZOrder(900)
	end

	local locker = self:getComponentByTag("locker")

	if locker then
		locker:setVisible(false)
		locker:setLocalZOrder(100)
	end

	local cdFlag = self:getFlagByTag("flag_cd")

	if cdFlag then
		self.polygonPoints = {
			{
				0,
				cdFlag.height / 2
			},
			{
				-cdFlag.width / 2,
				cdFlag.height / 2
			},
			{
				-cdFlag.width / 2,
				-cdFlag.height / 2
			},
			{
				cdFlag.width / 2,
				-cdFlag.height / 2
			},
			{
				cdFlag.width / 2,
				cdFlag.height / 2
			},
			{
				0,
				cdFlag.height / 2
			}
		}
	end
end

function BattleHead:inBattleMap()
	return InfoDungeon.inNoSafe() or app.sceneName == "ArenaScene"
end

function BattleHead:refreshEquipUp()
	local heroInfo = self.unit.info

	if InfoDungeon.isCampHome() then
		self:removeEnterFrame("delayRefreshCardUp")

		local delay = 10

		self:addEnterFrame("delayRefreshCardUp", function (dt)
			if delay <= 0 then
				self:delayRefreshCardUp()
			else
				delay = delay - dt * 60
			end
		end)

		return
	end

	self:removeEnterFrame("delayRefreshEquipUp")

	local delay = 10

	self:addEnterFrame("delayRefreshEquipUp", function (dt)
		if delay <= 0 then
			self:delayRefreshEquipUp()
		else
			delay = delay - dt * 60
		end
	end)
end

function BattleHead:delayRefreshCardUp()
	self:removeEnterFrame("delayRefreshCardUp")

	local heroInfo = self.unit.info
	local heroData = CsvParser.getCsvData("hero", heroInfo.base_id)
	local cardInfo = InfoCard.getCardOnHero(heroInfo, 1)
	local hasUp = false
	local openJobLevel = InfoHero.getCardOpenJobLevel(heroInfo, 1)

	if openJobLevel and openJobLevel <= heroData.job_level and not cardInfo then
		local function filterFunc(data)
			if data.type == DropManager.TYPE.CARD then
				return InfoCard.checkCardForHero(heroInfo, data.info)
			end
		end

		local bagItems = InfoCard.getWareList(filterFunc)

		if #bagItems > 0 then
			hasUp = true
		end
	end

	if hasUp then
		if not self.cardUpSlot then
			local ui = UIManager.getUI("com_battle_head_card")
			local bg = ui:getComponentByTag("bg")
			local icon = ui:getComponentByTag("icon")

			icon:setOpacity(200)

			local flag = self:getFlagByTag("flag_card")

			ui:setScale(flag.width / bg.width)
			ui:setPosition(flag.x + flag.width / 2, flag.y + flag.height / 2)
			self:addChild(ui, 1000)

			self.cardUpSlot = ui

			for i = 1, 3 do
				local up = ui:getComponentByTag("up" .. i)

				transition.stopTarget(up)
				up:setScale(1.2)
				up:setLocalZOrder(200)
				Style.makeShining(up, 50, nil, 0.2, 1.3, 0.2 * (i - 1))
			end
		end
	elseif self.cardUpSlot then
		self.cardUpSlot:removeSelf()

		self.cardUpSlot = nil
	end
end

function BattleHead:delayRefreshEquipUp()
	self:removeEnterFrame("delayRefreshEquipUp")

	local heroInfo = self.unit.info
	local rawData = InfoBag.getRaw()
	local scoreMap = {}

	for bag_index, data in pairs(rawData) do
		local tempData = nil

		if data.type == DropManager.TYPE.EQUIP then
			local equipInfo = InfoEquip.getInfo(data.equip_id)

			if InfoEquip.checkEquipForHero(heroInfo, equipInfo) then
				local equipCSV = CsvParser.getCsvData("equip", equipInfo.base_id)
				local equip_pos = equipCSV.equip_pos

				if equip_pos >= 1 and equip_pos <= 4 then
					local score = InfoEquip.getScore(equipInfo)
					scoreMap[equip_pos] = math.max(score, scoreMap[equip_pos] or 0)
				end
			end
		end
	end

	for pos = 1, 4 do
		local currentScore = 0
		local currentEquip = InfoEquip.getEquipOnHero(heroInfo, pos)

		if currentEquip then
			currentScore = InfoEquip.getScore(currentEquip)
		end

		local score = scoreMap[pos] or 0
		local upPercent = 0

		if score > 0 then
			if currentScore > 0 then
				upPercent = (score - currentScore) / currentScore
			else
				upPercent = 1
			end
		end

		self.equipUpSlots = self.equipUpSlots or {}

		if upPercent > 0 then
			if not self.equipUpSlots[pos] then
				local ui = UIManager.getUI("com_battle_head_equip_" .. pos)
				local flag = self:getFlagByTag("equip_" .. pos)

				ui:setScale(flag.width / 64)
				ui:setPosition(flag.x + flag.width / 2, flag.y + flag.height / 2)
				self:addChild(ui)

				self.equipUpSlots[pos] = ui
			end

			local ui = self.equipUpSlots[pos]

			if pos == 1 then
				local icon = ui:getComponentByTag("icon")
				local heroData = CsvParser.getCsvData("hero", heroInfo.base_id)

				icon:setFrame(heroData.class)
			end

			local max = math.min(3, math.ceil(upPercent / MiscConfig.UP_PERCENT))

			for i = 1, 3 do
				local up = ui:getComponentByTag("up" .. i)
				local isVisible = upPercent > (i - 1) * MiscConfig.UP_PERCENT

				transition.stopTarget(up)
				up:setVisible(isVisible)

				if isVisible then
					up:setScale(1.2)
					up:setLocalZOrder(200)

					local posY = ui:getComponentByTag("up" .. i + 3 - max).originalY

					up:setPos(nil, posY)
					Style.makeShining(up, 50, nil, 0.2, 1.3, 0.2 * (i - 1))
				end
			end
		elseif self.equipUpSlots[pos] then
			self.equipUpSlots[pos]:removeSelf()

			self.equipUpSlots[pos] = nil
		end
	end
end

function BattleHead:addTap(handler)
	local touchCom = self:getComponentByTag("touch")

	if touchCom then
		touchCom:toTouchable()
		touchCom:addTap(handler)
		touchCom:setTapGroup("button_click")
	end
end

function BattleHead:addTouch(handler)
	local touchCom = self:getComponentByTag("touch")

	if touchCom then
		touchCom:toTouchable()
		touchCom:addTouch(handler)
		touchCom:setTapGroup("button_click")
	end
end

function BattleHead:getTouchOver(x, y)
	local touchCom = self:getComponentByTag("touch")

	if touchCom then
		return touchCom:getTouchOver(x, y)
	end
end

function BattleHead:clearListen(isAll)
	if self.unit and not tolua.isnull(self.unit) then
		if self.hpHandler then
			self.unit:removeEventListener("hp_changed", self.hpHandler)

			self.hpHandler = nil
		end

		if self.dieHandler then
			self.unit:removeEventListener("die", self.dieHandler)

			self.dieHandler = nil
		end

		if self.reviveHandler then
			self.unit:removeEventListener("revive_changed", self.reviveHandler)

			self.reviveHandler = nil
		end

		if self.shieldHandler then
			self.unit:removeEventListener("shield_changed", self.shieldHandler)

			self.shieldHandler = nil
		end

		if self.expHandler then
			self.unit:removeEventListener("exp_changed", self.expHandler)

			self.expHandler = nil
		end

		if self.levelHandler then
			self.unit:removeEventListener("level_changed", self.levelHandler)

			self.levelHandler = nil
		end

		if self.selectHandler then
			self.unit:removeEventListener("select", self.selectHandler)

			self.selectHandler = nil
		end

		if self.hurtHandler then
			self.unit:removeEventListener("hurt", self.hurtHandler)

			self.hurtHandler = nil
		end

		if self.hpLoseHandler then
			self.unit:removeEventListener("hp_lose", self.hpLoseHandler)

			self.hpLoseHandler = nil
		end

		if self.equipUpHandler then
			notify.unregister("equip_up_change", self.equipUpHandler)

			self.equipUpHandler = nil
		end

		if isAll and self.infoHandler then
			self.unit:removeEventListener("info_set", self.infoHandler)

			self.infoHandler = nil
		end
	end
end

function BattleHead:setPetInfo(petInfo)
	self:init()
	self:clearListen(true)

	local slot = self:getComponentByTag("slot")

	if slot then
		local portraitScale = math.floor(slot.width / 25 * 10) / 10
		local icon = PortraitManager.getPetMugshot(petInfo.base_id, slot, portraitScale)

		slot:setIcon(icon, false)
	end

	local petCSV = CsvParser.getCsvData("pet", petInfo.base_id)
	local quality = petInfo.quality

	if self:getFlagByTag("flag_name") then
		self:createLabelOnFlag("flag_name", InfoPet.getName(petInfo), {
			color = InfoHero.getQualityColor(quality)
		})
	end

	if self:getFlagByTag("flag_level") then
		local exp, expUpg, level, maxLevel, displayLevel, displayMaxLevel, jobMaxLevel = InfoPet.getExp(petInfo)

		self:createLabelOnFlag("flag_level", displayLevel)
	end

	if self:getComponentByTag("quality_border") then
		local border = self:getComponentByTag("quality_border")

		border:setColor(InfoHero.getQualityColor(quality))
	end

	local locker = self:getComponentByTag("locker")

	if locker then
		locker:setVisible(petInfo.locked == 1)
	end
end

function BattleHead:setUnit(unit)
	self:init()
	self:clearListen(true)

	self.unit = unit
	self.infoHandler = unit:addEventListener("info_set", function ()
		self:clearListen()
		self:refreshUnit()
	end)

	self:refreshUnit()
end

function BattleHead:refreshUnit()
	local unit = self.unit
	local slot = self:getComponentByTag("slot")

	if slot then
		local portraitScale = math.floor(slot.width / 25 * 10) / 10
		local icon = PortraitManager.getUnitMugshot(self.unit, slot, portraitScale, nil, cc.p(0, -1))

		slot:setIcon(icon, false)
	end

	local quality = unit.info.quality

	if self:getFlagByTag("flag_name") then
		if self.unit.type == "hero" then
			self:createLabelOnFlag("flag_name", InfoHero.getName(self.unit.info), {
				color = InfoHero.getQualityColor(quality)
			})
		elseif self.unit.type == "hero_copy" then
			local nameStr = InfoHero.getName(self.unit.info)
			nameStr = nameStr or self.unit:getBattleName()

			self:createLabelOnFlag("flag_name", tostring(nameStr), {
				color = InfoHero.getQualityColor(quality)
			})
		else
			self:createLabelOnFlag("flag_name", self.unit:getBattleName(), {
				color = InfoHero.getQualityColor(quality)
			})
		end
	end

	local locker = self:getComponentByTag("locker")

	if locker then
		locker:setVisible(unit.info.locked == 1)
	end

	if self:getFlagByTag("flag_name_level") then
		self:refreshNameLevel()

		self.levelHandler = self.unit:addEventListener("level_changed", function ()
			self:refreshNameLevel()
		end)
	elseif self:getFlagByTag("flag_level") then
		self:refreshLevel()

		self.levelHandler = self.unit:addEventListener("level_changed", function ()
			self:refreshLevel()
		end)
	elseif self:getFlagByTag("flag_job_level") then
		self:refreshJobLevel()

		self.levelHandler = self.unit:addEventListener("level_changed", function ()
			self:refreshJobLevel()
		end)
	end

	if self:getComponentByTag("hp_bar") or self:getFlagByTag("flag_hp") then
		self:refreshHp()

		self.hpHandler = self.unit:addEventListener("hp_changed", function ()
			self:refreshHp()
		end)
		self.dieHandler = self.unit:addEventListener("die", function ()
			self:refreshHp()
		end)
		self.reviveHandler = self.unit:addEventListener("revive_changed", function (event)
			self:refreshRevive(event.count, event.total)
		end)
	end

	if not self.unit.isTemplete and (self:getComponentByTag("exp_bar") or self:getFlagByTag("flag_exp")) then
		if self:getComponentByTag("exp_bar") then
			self:createBarByTag("exp_bar")
		end

		self:refreshExp()

		self.expHandler = self.unit:addEventListener("exp_changed", function ()
			self:refreshExp()
		end)
	end

	if self.selectEnabled then
		self.selectHandler = self.unit:addEventListener("select", function (event)
			local selected = self:getComponentByTag("selected")

			selected:setVisible(event.value)
			self:onSelectEvent(event.value, event.params)
		end)
		self.hurtHandler = self.unit:addEventListener("hurt", function (event)
			self:hurtAnimation(event.isCritical)
		end)
	end

	if self:getComponentByTag("quality_border") then
		local border = self:getComponentByTag("quality_border")

		border:setColor(InfoHero.getQualityColor(quality))
	end

	if self:getComponentByTag("lose_line") then
		self:refreshHpLose()

		self.hpLoseHandler = self.unit:addEventListener("hp_lose", function ()
			self:refreshHpLose()
		end)
	end

	if unit.type == "hero" and self:getFlagByTag("equip_1") then
		self:refreshEquipUp()

		self.equipUpHandler = notify.safeRegister(self, "equip_up_change", function ()
			self:refreshEquipUp()
		end)
	end
end

function BattleHead:refreshNameLevel()
	if self:getFlagByTag("flag_name_level") then
		self:createLabelOnFlag("flag_name_level", self.unit:getBattleName() .. " lv." .. self.unit.info.level)
	end
end

function BattleHead:refreshLevel()
	if self:getFlagByTag("flag_level") then
		if self.unit.type == "pet" then
			local exp, expUpg, level, maxLevel, displayLevel, displayMaxLevel, jobMaxLevel = InfoPet.getExp(self.unit.info)

			self:createLabelOnFlag("flag_level", displayLevel)
		elseif self.unit.type == "hero" or self.unit.type == "hero_copy" then
			local exp, expUpg, level, maxLevel, displayLevel, displayMaxLevel = InfoHero.getExp(self.unit.info)

			self:createLabelOnFlag("flag_level", displayLevel)
		end
	end
end

function BattleHead:refreshJobLevel()
	if self:getFlagByTag("flag_job_level") then
		self:createLabelOnFlag("flag_job_level", self.unit.data.job_name .. " lv." .. self.unit.info.level)
	end
end

function BattleHead:refreshExp()
	if self.unit.type == "hero" then
		local exp, expUpg = InfoHero.getExp(self.unit.info)

		if self:getComponentByTag("exp_bar") then
			local percent = math.max(0, math.min(exp / expUpg, 1))

			self:setBarProgressByTag("exp_bar", percent)
		end

		if self:getFlagByTag("flag_exp") then
			self:createLabelOnFlag("flag_exp", "EXP:" .. exp .. "/" .. expUpg)
		end
	end
end

function BattleHead:refillHp()
	self:setBarProgressByTag("hp_bar", 1)
	self:setBarColorByTag("hp_bar", cc.c3b(0, 255, 0))
end

function BattleHead:refreshHp()
	self:addEnterFrame("delayRefreshHp", function ()
		self:delayRefreshHp()
	end)
end

function BattleHead:delayRefreshHp()
	self:removeEnterFrame("delayRefreshHp")

	local hp = self.unit.battleData.hp

	if self.unit.battleData.die then
		hp = 0
	end

	local hpMax = self.unit.attrs.hp
	local hero_id = self.unit.info.id

	if self:inBattleMap() then
		local trueHpMax = math.floor(hpMax * (1 - InfoDungeon.getHeroHPLose(hero_id) / 100))
		hp = math.min(trueHpMax, math.max(hp, 0))
	else
		hp = hpMax
	end

	if self:getComponentByTag("hp_bar") then
		local percent = math.max(0, math.min(hp / hpMax, 1))
		local color = InfoHero.getHpColor(percent)

		self:setBarProgressByTag("hp_bar", percent)
		self:setBarColorByTag("hp_bar", color)
	end

	if self:getFlagByTag("flag_hp") then
		local style = nil

		if hp == 0 then
			style = {
				color = Style.red
			}
		end

		self:createLabelOnFlag("flag_hp", hp .. "/" .. hpMax, style)
	end
end

function BattleHead:refreshHpLose()
	local hero_id = self.unit.info.id
	local hpLose = InfoDungeon.getHeroHPLose(hero_id)
	local lose_line = self:getComponentByTag("lose_line")

	if lose_line then
		if self:inBattleMap() and hpLose > 0 then
			local hp_bar = self:getComponentByTag("hp_bar")

			lose_line:setVisible(true)
			lose_line:setPos(hp_bar.x + hp_bar.width * (1 - hpLose / 100) - 2)
		else
			lose_line:setVisible(false)
		end
	end
end

function BattleHead:refreshShield()
end

function BattleHead:refreshRevive(count, total)
	if self:getComponentByTag("hp_bar") then
		local percent = math.max(0, math.min(count / total, 1))

		self:setBarProgressByTag("hp_bar", percent)
		self:setBarColorByTag("hp_bar", revive_color)
	end

	if self:getFlagByTag("flag_hp") then
		self:createLabelOnFlag("flag_hp", total - count .. "S")
	end
end

function BattleHead:setBattleEventEnabled(enabled)
	if enabled then
		self.selectEnabled = true
		local selected = self:getComponentByTag("selected")

		if selected and not self.selectHandler then
			selected:setVisible(false)

			if self.unit then
				self.selectHandler = self.unit:addEventListener("select", function (event)
					selected:setVisible(event.value)
					self:onSelectEvent(event.value, event.params)
				end)
				self.hurtHandler = self.unit:addEventListener("hurt", function (event)
					self:hurtAnimation(event.isCritical)
				end)
			end
		end

		return
	end

	local selected = self:getComponentByTag("selected")

	if selected then
		selected:setVisible(false)
	end

	if self.selectHandler then
		if self.unit and self.unit.removeEventListener then
			self.unit:removeEventListener("select", self.selectHandler)
		end

		self.selectHandler = nil
	end

	if self.hurtHandler then
		if self.unit and self.unit.removeEventListener then
			self.unit:removeEventListener("hurt", self.hurtHandler)
		end

		self.hurtHandler = nil
	end
end

function BattleHead:hurtAnimation(isCritical)
	self:setScale(0.8)
	transition.scaleTo(self, {
		time = 0.05,
		easing = "sineOut",
		scale = 1
	})
end

function BattleHead:onSelectEvent(selected, params)
	if selected then
		if params and params.type == "use_item" then
			local itemData = params.itemData

			if itemData.use_type == 1 and self:getBarByTag("heal_bar") then
				local hp = self.unit.battleData.hp + itemData.use_value1
				local hpMax = self.unit.attrs.hp

				if self:inBattleMap() then
					local hero_id = self.unit.info.id
					hp = math.min(hp, hpMax * (1 - InfoDungeon.getHeroHPLose(hero_id) / 100))
				end

				local percent = math.max(0, math.min(hp / hpMax, 1))

				self:getBarByTag("heal_bar"):setVisible(true)
				self:setBarProgressByTag("heal_bar", percent)
				self:setBarColorByTag("heal_bar", cc.c3b(218, 68, 68))
			end
		end
	elseif self:getBarByTag("heal_bar") then
		self:getBarByTag("heal_bar"):setVisible(false)
	end
end

function BattleHead:setTouchEnabledTag(tag, enabled)
	if enabled then
		if not self._touchEnabledStateMap then
			self._touchEnabledStateMap = {}
		end

		self._touchEnabledStateMap[tag] = 1
	else
		if self._touchEnabledStateMap then
			self._touchEnabledStateMap[tag] = nil
		end

		if self._touchEnabledStateMap and table.nums(self._touchEnabledStateMap) == 0 then
			self._touchEnabledStateMap = nil
		end
	end
end

function BattleHead:isTouchEnabledTag()
	return self._touchEnabledStateMap == nil
end

function BattleHead:startCD(cdOverTime, cdMax)
	local fullFrameTime = WarMachine.getFrame()
	local bg = self:getComponentByTag("bg")
	local cdFlash = self:getComponentByTag("cd_flash")
	local cdLeft = cdOverTime - fullFrameTime
	local fadeStep = 1

	self:setTouchEnabledTag("cd", true)

	local cdLoop = nil

	function cdLoop(obj, frame, passed, sharp)
		if tolua.isnull(self) then
			MapFrameManager.stopLoop(self, cdLoop)

			return
		end

		local secStr = nil

		if cdLeft > 60 then
			secStr = math.ceil(cdLeft / 60)
		else
			secStr = math.ceil(cdLeft * 10 / 60) / 10
		end

		if secStr ~= self.preSec then
			self.preSec = secStr
		end

		cdLeft = cdLeft - passed

		if fadeStep == 1 and cdLeft <= 12 then
			fadeStep = 2
			local tweenObj = {
				opacity = 0
			}

			cdFlash:setOpacity(0)
			cdFlash:setVisible(true)

			return MapFrameManager.tween(3, tweenObj, {
				opacity = 255
			}, "outQuad", nil, function ()
				if tolua.isnull(self) then
					return
				end

				cdFlash:setOpacity(tweenObj.opacity)
			end)
		elseif fadeStep == 2 and cdLeft <= 9 then
			fadeStep = 3
			local tweenObj = {
				opacity = 255
			}

			if cdLeft > 0 then
				return MapFrameManager.tween(cdLeft, tweenObj, {
					opacity = 0
				}, "inQuad", function ()
					if tolua.isnull(self) then
						return
					end

					cdFlash:setVisible(false)
				end, function ()
					if tolua.isnull(self) then
						return
					end

					cdFlash:setOpacity(tweenObj.opacity)
				end)
			end
		end

		if cdLeft <= 0 then
			self:setPercent(0)
			self:setTouchEnabledTag("cd", false)
			MapFrameManager.stopLoop(self, cdLoop)

			self.cdLoop = nil
		else
			self:setPercent(math.min(1, cdLeft / cdMax))
		end
	end

	self.cdLoop = cdLoop

	MapFrameManager.startLoop(self, cdLoop)
end

function BattleHead:onAddSkillCD(event)
	local bg = self:getComponentByTag("bg")

	self:setPercent(event.times / event.maxTimes)

	if event.times <= 0 then
		self:setTouchEnabledTag("cd", false)
	else
		self:setTouchEnabledTag("cd", true)
	end
end

function BattleHead:resetCD()
	self.preSec = nil
	local cdFlash = self:getComponentByTag("cd_flash")

	cdFlash:setVisible(false)
	cdFlash:setOpacity(0)

	local bg = self:getComponentByTag("bg")

	self:setPercent(0)
	self:setTouchEnabledTag("cd", false)

	if self.cdLoop then
		MapFrameManager.stopLoop(self, self.cdLoop)

		self.cdLoop = nil
	end

	if self.cdPolygon then
		self.cdPolygon:removeSelf()

		self.cdPolygon = nil
	end
end

function BattleHead:setPercent(percent)
	local cdFlag = self:getFlagByTag("flag_cd")
	local polygonPoints = self.polygonPoints

	if not polygonPoints then
		return
	end

	if percent > 0 then
		local nodeNum = math.floor((percent + 0.125) * 4) + 1
		local pts = {
			{
				0,
				0
			}
		}

		for i = 1, nodeNum do
			table.insert(pts, polygonPoints[i])
		end

		local ipt = polygonPoints[nodeNum]
		local ipt2 = polygonPoints[nodeNum + 1]
		local iangle = math.atan2(ipt2[2] - ipt[2], ipt2[1] - ipt[1])
		local ix, iy = GeomPlane.intersect(0, 0, math.pi * 2 * (percent + 0.25), ipt[1], ipt[2], iangle)

		table.insert(pts, {
			ix,
			iy
		})
		table.insert(pts, {
			0,
			0
		})

		local newPolygon = self.cdPolygon == nil

		if self.cdPolygon then
			self.cdPolygon:setVisible(true)
			self.cdPolygon:clear()
		end

		self.cdPolygon = display.newPolygon(pts, {
			borderWidth = 0,
			fillColor = cc.c4f(0, 0, 0, 0.8)
		}, self.cdPolygon)

		if newPolygon then
			self.cdPolygon:setPosition(cdFlag.width / 2 + cdFlag.x, cdFlag.height / 2 + cdFlag.y)
			self:addChild(self.cdPolygon, 800)
		end
	elseif self.cdPolygon then
		self.cdPolygon:setVisible(false)
	end
end

function BattleHead:onExit()
	self:clearListen(true)
	BattleHead.super.onExit(self)
end

return BattleHead
