local UI_base = import("..UI_base")
local Resource = class("Resource", UI_base)

function Resource:ctor(itemID, uiName, locked, fixedWidth, loopPercent)
	Resource.super.ctor(self, uiName)

	self.itemID = itemID
	self.refreshLocked = locked
	self.fixedWidth = fixedWidth
	self.loopPercent = loopPercent

	self:init()
end

function Resource:init()
	self:initUI()

	local rmbButton = self:getComponentByTag("bt_rmb")

	rmbButton:setVisible(self.itemID == GameConfig.zuan_item)

	if self.itemID == GameConfig.zuan_item then
		rmbButton:toTouchable()
		rmbButton:addTap(function ()
			FRAME_rmb_shop.open()
		end)
		rmbButton:setTapGroup("button_click")

		local flag_num = self:getFlagByTag("flag_num")
		flag_num.x = flag_num.x - 10
	end

	self:refreshNum()
	ManagerInfo.onDataChange(self, "item", self.itemID, function ()
		if not FRAME_main_resource.allLocked and not self.refreshLocked then
			self:refreshNum()
		end
	end)

	if self.loopPercent and (self.itemID == GameConfig.coin_item or self.itemID == GameConfig.farm_item or InfoItem.isGrowth(self.itemID)) then
		local count = math.floor(self.loopPercent * 60)

		self:addEnterFrame("refresh_loop", function ()
			if count <= 0 then
				if not FRAME_main_resource.allLocked and not self.refreshLocked then
					self:refreshNum()
				end

				count = 60
			else
				count = count - 1
			end
		end)
	end
end

function Resource:initUI()
	self.icon = self:createIconOnFlag("flag_icon", IconManager.getItemIcon(self.itemID), 100, true)
	self.iconHighlight = self:createIconOnFlag("flag_icon", IconManager.getItemIcon(self.itemID), 100, true, nil, true)

	self.iconHighlight:setVisible(false)
	Shader.custom(self.iconHighlight, "add_1")

	self.iconScale = math.min(self.icon:getScaleX(), self.icon:getScaleY())
	local bg1 = self:getComponentByTag("bg1")

	bg1:toTouchable()
	bg1:addTap(function ()
		local x, y = self:getPosition()

		ResourceHint.open(cc.p(x + self.width, y), self.itemID)
	end)
	bg1:setTapGroup("button_click")
	bg1:setOpacity(0)

	local widthOffset = nil

	if self.fixedWidth >= 150 then
		widthOffset = 210 - self.fixedWidth
	else
		widthOffset = 205 - self.fixedWidth
	end

	local bg = self:getComponentByTag("bg")
	local bg1 = self:getComponentByTag("bg1")
	local rmbButton = self:getComponentByTag("bt_rmb")
	local flag_num = self:getFlagByTag("flag_num")
	local bar = self:getComponentByTag("bar")

	bg:setSize(bg.width - widthOffset)
	bg1:setSize(bg1.width - widthOffset)
	rmbButton:setPos(rmbButton.x - widthOffset)

	flag_num.x = flag_num.x - widthOffset / 2

	bar:setSize(bar.width - widthOffset)
	self:createBarByTag("bar")
end

function Resource:setRefreshLocked(b)
	if b then
		self.refreshLocked = true
	else
		self.refreshLocked = nil
	end
end

function Resource:refreshNum()
	local num = InfoItem.getNum(self.itemID)
	local changed = false

	if self.itemNum ~= num then
		changed = true
		self.itemNum = num

		self:createLabelOnFlag("flag_num", StringUtil.simplifyNumber(num))
	end

	local bar = self:getComponentByTag("bar")

	if self.itemID == GameConfig.coin_item and InfoBuilding.getBuildingLevel(InfoBuilding.TAG.FURNACE) > 0 then
		local cash, cashMax = InfoFurnace.getCash()
		local percent = math.min(1, math.max(0, cash / cashMax))

		self:setBarProgressByTag("bar", percent)
		bar:setColor(NAV_base.COLOR.HIGH)
		bar:setOpacity(50 + 100 * percent)
	elseif self.itemID == GameConfig.farm_item and InfoBuilding.getBuildingLevel(InfoBuilding.TAG.FARM) > 0 then
		local cash, cashMax = InfoFarm.countHarvest()
		local percent = 0

		if cashMax > 0 then
			percent = math.min(1, math.max(0, cash / cashMax))
		end

		self:setBarProgressByTag("bar", percent)
		bar:setColor(NAV_base.COLOR.HIGH)
		bar:setOpacity(50 + 100 * percent)
	elseif InfoItem.isGrowth(self.itemID) then
		local _num, growth, growth_time = InfoItem.getGrowth(self.itemID)
		local growthMax = InfoItem.getGrowthMax(self.itemID)

		if growth > 0 and growthMax > 0 then
			bar:setVisible(true)

			local growthPercent = math.max(0, math.min(1, num / growthMax))

			self:setBarProgressByTag("bar", growthPercent)

			local percent, progressArr = InfoBuilding.getProgressByMat(self.itemID)

			if percent >= 1 then
				bar:setColor(NAV_base.COLOR.READY)
				bar:setOpacity(150)
			else
				bar:setColor(NAV_base.COLOR.PROGRESS)
				bar:setOpacity(50)
			end
		else
			bar:setVisible(false)
		end
	else
		bar:setVisible(false)
	end
end

function Resource:addNum(num)
	local trueNum = InfoItem.getNum(self.itemID)
	self.itemNum = math.min(trueNum, self.itemNum + num)

	self:createLabelOnFlag("flag_num", StringUtil.simplifyNumber(self.itemNum))
	self.icon:setScale(self.iconScale * 1.2)
	transition.stopTarget(self.icon)
	transition.scaleTo(self.icon, {
		easing = "sineOut",
		time = 0.1,
		scale = self.iconScale
	})
	self.iconHighlight:setScale(self.iconScale * 1.2)
	transition.stopTarget(self.iconHighlight)
	transition.scaleTo(self.iconHighlight, {
		easing = "sineOut",
		time = 0.1,
		scale = self.iconScale
	})
	self.iconHighlight:setVisible(true)
	self.iconHighlight:setOpacity(255)
	transition.fadeTo(self.iconHighlight, {
		opacity = 0,
		easing = "sineOut",
		time = 0.1,
		onComplete = function ()
			self.iconHighlight:setVisible(false)
		end
	})
end

return Resource
