local POP_control_tip = class("POP_control_tip", UI_base)
local instance = nil

function POP_control_tip.open(text)
	if instance and not instance.closing and instance.text == text then
		return
	end

	if not instance then
		instance = POP_control_tip.new()

		display.getRunningScene():addChild(instance, LayerConfig.pop)
	end

	instance:show(text)
end

function POP_control_tip.close()
	if instance then
		instance:fadeOut()
	end
end

function POP_control_tip:ctor()
	POP_control_tip.super.ctor(self, "pop_control_tip", UIManager.BIG_TYPE.TOP)
	self:init()
end

function POP_control_tip:init()
	self:initUI()
end

function POP_control_tip:initUI()
	local textFlag = self:getFlagByTag("flag_text")
	local bg = self:getComponentByTag("bg")
	self.bgSpaceX = bg.x + bg.width - (textFlag.x + textFlag.width)
	self.bgSpaceY = bg.y + bg.height - (textFlag.y + textFlag.height)
end

function POP_control_tip:show(text)
	self.text = text
	local label, labelWidth, labelHeight = self:createLabelOnFlag("flag_text", text)
	local textFlag = self:getFlagByTag("flag_text")
	local bg = self:getComponentByTag("bg")

	if textFlag.originalWidth < labelWidth then
		label, labelWidth, labelHeight = self:createLabelOnFlag("flag_text", text, {
			wrap = true
		})

		bg:setSize(textFlag.x + labelWidth + self.bgSpaceX - bg.x, textFlag.y + labelHeight + self.bgSpaceY - bg.y)
		bg:setPos(nil, display.height / self:getBigScale() - bg.height)

		self.width = textFlag.x + labelWidth + self.bgSpaceX
		self.height = display.height / self:getBigScale() - bg.y
	else
		bg:setSize(textFlag.x + labelWidth + self.bgSpaceX - bg.x)

		self.width = textFlag.x + labelWidth + self.bgSpaceX
		self.height = display.height / self:getBigScale() - bg.y
	end

	self:fadeIn()
end

function POP_control_tip:fadeIn()
	self.closing = nil

	self:setPositionY(self.height)
	transition.stopTarget(self)
	transition.moveTo(self, {
		y = 0,
		easing = "sineOut",
		time = 0.1
	})
end

function POP_control_tip:fadeOut()
	self.closing = true

	transition.stopTarget(self)
	transition.moveTo(self, {
		easing = "sineOut",
		time = 0.1,
		y = self.height,
		onComplete = function ()
			self:removeSelf()

			instance = nil
		end
	})
end

return POP_control_tip
