local UI_base = import(".UI_base")
local FRAME_main_task = class("FRAME_main_task", UI_base)
local HERO_HEAD_HEIGHT = 64
local PET_HEAD_HEIGHT = 50
local TYPE = {
	CAMP = 1,
	UNION = 2
}
FRAME_main_task.TYPE = TYPE

function FRAME_main_task:ctor(type)
	local uiName = "frame_main_task"

	if type == TYPE.UNION then
		uiName = "frame_main_task_union"
	end

	FRAME_main_task.super.ctor(self, uiName, UIManager.BIG_TYPE.TOP)

	self.type = type

	self:init()
end

function FRAME_main_task:init()
	self:initUI()

	if self.type == TYPE.CAMP then
		self:refresh()
		notify.safeRegister(self, "InfoTaskQuest_snapshot", function ()
			self:refresh()
		end)
		self:refreshActv()
		ManagerInfo.onDataChange(self, "actv", nil, function ()
			self:refreshActv()
		end)
		self:refreshActvRedot()
		notify.safeRegister(self, "actv_redot", function ()
			self:refreshActvRedot()
		end)
		self:refreshCampaign()
		notify.safeRegister(self, "campaign_changed", function ()
			self:refreshCampaign()
		end)
		ManagerInfo.onDataChange(self, "main_guide", nil, function ()
			self:refreshCampaign()
		end)

		local dataChangeArr = {
			"travel",
			"achieve",
			"kanban",
			"likes",
			"pet_hatch",
			"arena",
			"abyss_gift",
			"item",
			"farm",
			"delay_item",
			"building",
			"core"
		}

		ManagerInfo.onDataChange(self, dataChangeArr, nil, function ()
			self:refreshLead()
		end)
		self:refreshSurvey()
		ManagerInfo.onDataChange(self, "params", nil, function ()
			self:refreshSurvey()
			self:refreshCampaign()
		end)
		self:refreshLiuhai()
		notify.safeRegister(self, "liuhai_change", function ()
			self:refreshLiuhai()
		end)
	end

	self:refreshLead()
end

function FRAME_main_task:refreshLiuhai()
	if UIManager.getLiuhai() == "right" then
		self:setPositionX(-UIManager.LIUHAI_WIDTH)
	else
		self:setPositionX(0)
	end
end

function FRAME_main_task:initUI()
	if self.type == TYPE.CAMP then
		local campaignButton = self:getComponentByTag("bt_campaign")

		campaignButton:toTouchable()
		campaignButton:setTapGroup("button_click")
		campaignButton:addTap(function ()
			FRAME_campaign.open()
		end)

		local bt_record_first = self:getComponentByTag("bt_record_first")

		bt_record_first:toTouchable()
		bt_record_first:setTapGroup("button_click")
		bt_record_first:addTap(function ()
			local giftArr = InfoOrder.getNewgiftList(nil, global.newgiftSeason)

			if #giftArr > 0 then
				FRAME_newgift.open(nil, , global.newgiftSeason)
			end
		end)

		local bt_daily_order = self:getComponentByTag("bt_daily_order")

		bt_daily_order:toTouchable()
		bt_daily_order:setTapGroup("button_click")
		bt_daily_order:addTap(function ()
			FRAME_welfare.open()
		end)

		local bt_mygift = self:getComponentByTag("bt_mygift")

		bt_mygift:toTouchable()
		bt_mygift:setTapGroup("button_click")
		bt_mygift:addTap(function ()
			FRAME_mygift_all.open()
		end)

		local bt_first = self:getComponentByTag("bt_first")

		bt_first:toTouchable()
		bt_first:setTapGroup("button_click")
		bt_first:addTap(function ()
			FRAME_first_achieve.open()
		end)

		if InfoFirstAchieve.isOpening() then
			local preFirstDay = nil

			local function refreshFirstTime()
				local day = InfoFirstAchieve.getTargetDayLeft()

				if day ~= preFirstDay then
					if bt_first.timeLabel then
						bt_first.timeLabel:removeSelf()

						bt_first.timeLabel = nil
					end

					if InfoFirstAchieve.isOpening() then
						preFirstDay = day
						local str = Localization.getSrcText("剩余{1}天")
						local labelStyle = self:getStyleByTag("flag_first_day")
						local label = UIManager.createLabel(0, -10, bt_first.width, bt_first.height, StringUtil.replace(str, day), labelStyle)

						bt_first:addChild(label)

						bt_first.timeLabel = label
					else
						self:removeEnterFrame("refreshFirstTime")
						self:refreshCampaign()
					end
				end
			end

			refreshFirstTime()
			self:addEnterFrame("refreshFirstTime", refreshFirstTime)
		end

		local bt_union_war = self:getComponentByTag("bt_union_war")

		bt_union_war:toTouchable()
		bt_union_war:setTapGroup("button_click")
		bt_union_war:addTap(function ()
			if InfoUnion.inWarSeason() then
				local step = InfoUnion.checkUnionWarSeason()

				if step == InfoUnion.UNION_WAR_STEP.ENROLL then
					Alert.open(Localization.getSrcText("联盟会战报名中，等待开启"))
				else
					FRAME_union_war_zone.open(0)
				end
			else
				Alert.open(Localization.getSrcText("不在联盟会战赛季中"))
			end
		end)

		local bt_union_pve = self:getComponentByTag("bt_union_pve")

		bt_union_pve:toTouchable()
		bt_union_pve:setTapGroup("button_click")
		bt_union_pve:addTap(function ()
			if InfoUnion.checkPveOpen() then
				FRAME_union_pve.open()
			else
				Alert.open(Localization.getSrcText("猩红之月未开启"))
			end
		end)

		if Localization.isAlphabet() then
			local label = bt_union_pve.label

			if label then
				label:setLineHeight(18)
			end
		end

		local bt_survey = self:getComponentByTag("bt_survey")

		bt_survey:toTouchable()
		bt_survey:setTapGroup("button_click")
		bt_survey:addTap(function ()
			local survey_url = InfoParams.getValue("survey_url")

			if not empty(survey_url) then
				print("$$$ survey_url", survey_url)
				LuaBridge.call("luaOpenURL", survey_url)
			end
		end)
		bt_survey:setVisible(false)

		local bt_actv = self:getComponentByTag("bt_actv")

		bt_actv:toTouchable()
		bt_actv:setTapGroup("bg_click")
		bt_actv:addTap(function ()
			print("$$$ self.actvId", self.actvId)
			FRAME_actv.open(self.actvId)
		end)

		local bt_bp = self:getComponentByTag("bt_bp")

		bt_bp:toTouchable()
		bt_bp:setTapGroup("button_click")
		bt_bp:addTap(function ()
			FRAME_bp.open()
		end)

		local bt_back = self:getComponentByTag("bt_back")

		bt_back:toTouchable()
		bt_back:setTapGroup("button_click")
		bt_back:addTap(function ()
			local data = InfoBack.getCurrent()

			FRAME_back.open(data)
		end)

		local currentBack = InfoBack.getCurrent()

		if currentBack ~= nil then
			local preBackDay = nil

			local function refreshBackTime()
				local opening, day = InfoBack.checkOpening(currentBack.id)

				if day ~= preBackDay then
					if bt_back.timeLabel then
						bt_back.timeLabel:removeSelf()

						bt_back.timeLabel = nil
					end

					if opening then
						preBackDay = day
						local str = Localization.getSrcText("剩余{1}天")
						local labelStyle = self:getStyleByTag("flag_first_day")
						local label = UIManager.createLabel(0, -10, bt_back.width, bt_back.height, StringUtil.replace(str, day), labelStyle)

						bt_back:addChild(label)

						bt_back.timeLabel = label
					else
						self:removeEnterFrame("refreshBackTime")
						self:refreshCampaign()
					end
				end
			end

			refreshBackTime()
			self:addEnterFrame("refreshBackTime", refreshBackTime)
		end

		local navArr = {}

		table.insert(navArr, {
			button = "bt_mygift",
			openCheck = function ()
				return #InfoMygift.getTabList() > 0
			end
		})
		table.insert(navArr, {
			button = "bt_daily_order",
			new = "new_daily_order",
			redot = "redot_daily_order",
			openCheck = function ()
				return true
			end,
			countRedot = function ()
				local items = InfoPaygift.getItems(102)
				local notSoldoutCount = InfoPaygift.countNotSoldout(items)

				return notSoldoutCount + InfoOrder.countRedotDailyOrderReward()
			end,
			checkNew = function ()
				return InfoPaygift.isNewList(101)
			end
		})
		table.insert(navArr, {
			button = "bt_record_first",
			shade = "bt_record_first_shade",
			new = "new_record_first",
			openCheck = function ()
				local giftArr = InfoOrder.getNewgiftList(nil, global.newgiftSeason)

				return #giftArr > 0
			end,
			checkNew = function ()
				return InfoOrder.isNewgiftNewAll(nil, global.newgiftSeason)
			end
		})
		table.insert(navArr, {
			button = "bt_first",
			redot = "redot_first",
			openCheck = function ()
				return InfoFirstAchieve.isOpening()
			end,
			countRedot = function ()
				return InfoFirstAchieve.countRedot()
			end
		})
		table.insert(navArr, {
			button = "bt_bp",
			redot = "redot_bp",
			openCheck = function ()
				local bpData = InfoBp.getCurrent()

				return bpData ~= nil
			end,
			openRefresh = function (button)
				if button.icon then
					button.icon:removeSelf()

					button.icon = nil
				end

				local bpData = InfoBp.getCurrent()

				if bpData then
					local icon = display.newSprite(IconManager.getBpIcon(bpData.base_id))

					icon:setScale(0.625)
					icon:setPosition(button.width / 2, button.height / 2)
					button:addChild(icon, -100)

					button.icon = icon
				end
			end,
			countRedot = function ()
				return FRAME_bp.countRedot()
			end
		})
		table.insert(navArr, {
			button = "bt_back",
			redot = "redot_back",
			openCheck = function ()
				return InfoBack.getCurrent() ~= nil
			end,
			countRedot = function ()
				local backData = InfoBack.getCurrent()

				if backData then
					return InfoBack.countRedot(backData)
				end

				return 0
			end
		})
		table.insert(navArr, {
			button = "bt_union_war",
			openCheck = function ()
				return InfoParams.getValue("union_gwar") == 1 and InfoUnion.inWarSeason()
			end
		})
		table.insert(navArr, {
			button = "bt_union_pve",
			redot = "redot_union_pve",
			openCheck = function ()
				if InfoParams.getValue("union_pve") == 1 then
					return InfoUnion.checkPveOpen()
				end

				return false
			end,
			countRedot = function ()
				if InfoParams.getValue("union_pve") == 1 and InfoUnion.checkPveOpen() then
					return InfoUnion.countRedotPve()
				end

				return 0
			end
		})
		table.insert(navArr, {
			button = "bt_survey",
			openCheck = function ()
				local survey_on = InfoParams.getValue("survey_on")
				local survey_url = InfoParams.getValue("survey_url")

				return survey_on == 1 and not empty(survey_url)
			end
		})

		self.navArr = navArr
	end
end

function FRAME_main_task:refreshSurvey()
	local survey_on = InfoParams.getValue("survey_on")
	local survey_url = InfoParams.getValue("survey_url")
	local bt_survey = self:getComponentByTag("bt_survey")

	if InfoGuide.isFin() then
		if survey_on == 1 and not empty(survey_url) then
			bt_survey:setVisible(true)
		else
			bt_survey:setVisible(false)
		end
	else
		bt_survey:setVisible(false)
	end
end

function FRAME_main_task:refreshActvRedot()
	local isGuideFin = InfoGuide.isFin()
	local redot_actv = self:getComponentByTag("redot_actv")

	redot_actv:setVisible(isGuideFin and FRAME_actv.countRedot() > 0)
end

function FRAME_main_task:refreshActv()
	self:removeEnterFrame("refreshActv_checkLoop")

	local isGuideFin = InfoGuide.isFin()
	local bt_actv = self:getComponentByTag("bt_actv")
	local actv_mask = self:getComponentByTag("actv_mask")

	bt_actv:setVisible(false)
	actv_mask:setVisible(false)
	self:removePicOnFlag("actv_mask")

	if isGuideFin then
		local actvList = InfoActv.getViewList()
		local minShopTime = 0
		local actvArr = {}

		for i, actvData in ipairs(actvList) do
			local banner = Localization.getTextByLang(actvData.banner)

			if not empty(banner) then
				table.insert(actvArr, {
					pic = banner,
					id = actvData.id
				})

				if minShopTime == 0 or actvData.shop_time < minShopTime then
					minShopTime = actvData.shop_time
				end
			end
		end

		if #actvArr > 0 then
			bt_actv:setVisible(true)
			actv_mask:setVisible(true)
			self:createScrollOnFlag(actvArr, nil, , function (index)
				self.actvId = actvArr[index].id
			end)

			if minShopTime > 0 then
				self:addEnterFrame("refreshActv_checkLoop", function ()
					if minShopTime < Time.now() then
						self:refreshActv()
					end
				end)
			end
		end
	end
end

function FRAME_main_task:createScrollOnFlag(actvArr, scrollInterval, scrollTime, scrollCallback)
	if self.actvNode then
		self.actvNode:removeSelf()

		self.actvNode = nil
	end

	local actv_mask = self:getComponentByTag("actv_mask")
	local container = display.newNode()

	container:setCascadeOpacityEnabled(true)

	local tempArr = {}

	for i, data in ipairs(actvArr) do
		table.insert(tempArr, data)
	end

	table.insert(tempArr, actvArr[1])

	for i, data in ipairs(tempArr) do
		local addX = actv_mask.width * (i - 1)
		local ui = UIManager.getUI("actv_banner")

		ui:setPosition(addX + actv_mask.x, actv_mask.y)

		local actvData = InfoActv.get(data.id)
		local label = ui:createLabelOnFlag("flag_name", Localization.getTextByLang(actvData.title), {
			wrap = true,
			valign = Style.vcenter
		})

		label:setLineHeight(22)

		local mask = ui:getComponentByTag("mask")

		mask:setVisible(false)
		PicLoader.load(data.pic, function (path)
			if ui.createPicOnFlag then
				mask:setVisible(true)
				ui:createPicOnFlag("mask", path, 1000, UILayout.SCALE_TYPE.LARGE)
			end
		end)
		container:addChild(ui)
	end

	if #actvArr > 1 then
		scrollInterval = scrollInterval or 3
		scrollTime = scrollTime or 0.2
		local scrollIndex = 1
		local scrollNext = nil

		function scrollNext()
			if scrollIndex > #actvArr then
				scrollIndex = 2

				container:setPositionX(0)
			else
				scrollIndex = scrollIndex + 1
			end

			if scrollCallback then
				scrollCallback(scrollIndex - 1)
			end

			container:performWithDelay(function ()
				transition.moveTo(container, {
					easing = "sineOut",
					time = scrollTime,
					x = -actv_mask.width * (scrollIndex - 1),
					onComplete = scrollNext
				})
			end, scrollInterval)
		end

		scrollNext()
	end

	actv_mask:setOpacity(5)

	local actvNode = cc.ClippingNode:create()

	actvNode:setStencil(actv_mask)
	actvNode:setAlphaThreshold(0.0001)
	actvNode:addChild(container)
	actvNode:setCascadeOpacityEnabled(true)

	actvNode.x = actv_mask.x
	actvNode.y = actv_mask.y
	actvNode.width = actv_mask.width
	actvNode.height = actv_mask.height

	self:addChild(actvNode, actv_mask:getLocalZOrder())

	self.actvNode = actvNode

	return actvNode
end

function FRAME_main_task:refreshCampaign()
	local isGuideFin = InfoGuide.isFin()
	local campaignButton = self:getComponentByTag("bt_campaign")

	campaignButton:setVisible(isGuideFin)

	local redot_campaign = self:getComponentByTag("redot_campaign")

	redot_campaign:setVisible(isGuideFin and FRAME_campaign.countRedot() > 0)

	local flag = self:getFlagByTag("flag_nav")
	local addX = flag.x
	local spaceX = 80

	for i, v in ipairs(self.navArr) do
		local openCheck = isGuideFin and v.openCheck()

		if openCheck then
			local button = self:getComponentByTag(v.button)

			button:setVisible(true)
			button:setPositionX(addX)

			if v.openRefresh then
				v.openRefresh(button)
			end

			if v.shade then
				local shade = self:getComponentByTag(v.shade)

				shade:setVisible(true)

				local xOffset = shade.originalX + shade.originalWidth / 2 - (button.originalX + button.originalWidth / 2)

				shade:setPositionX(button:getPositionX() + xOffset)
				transition.stopTarget(shade)
				Style.makeShining(shade, 32, 160, 0.5, 0.5, nil, , "sineInOut", "sineInOut")
			end

			local isRedot = false

			if v.redot then
				local redot = self:getComponentByTag(v.redot)
				local countRedot = v.countRedot()

				if countRedot > 0 then
					redot:setVisible(true)

					local xOffset = redot.originalX + redot.originalWidth / 2 - (button.originalX + button.originalWidth / 2)

					redot:setPositionX(button:getPositionX() + xOffset)

					isRedot = true
				else
					redot:setVisible(false)
				end
			end

			if v.new then
				local new = self:getComponentByTag(v.new)
				local checkNew = not isRedot and v.checkNew()

				if checkNew then
					new:setVisible(true)
					new:setFrame(Localization.getNewFrame())

					local xOffset = new.originalX + new.originalWidth / 2 - (button.originalX + button.originalWidth / 2)

					new:setPositionX(button:getPositionX() + xOffset)
				else
					new:setVisible(false)
				end
			end

			addX = addX - spaceX
		else
			local button = self:getComponentByTag(v.button)

			button:setVisible(false)

			if v.redot then
				local redot = self:getComponentByTag(v.redot)

				redot:setVisible(false)
			end

			if v.new then
				local new = self:getComponentByTag(v.new)

				new:setVisible(false)
			end

			if v.shade then
				local shade = self:getComponentByTag(v.shade)

				shade:setVisible(false)
			end
		end
	end
end

function FRAME_main_task:setNpcHead(headView, npcID)
	headView:removeIconOnFlag("flag_icon")

	local npcData = CsvParser.getCsvData("npc", npcID)
	local headPath = nil

	if not empty(npcData.icon) then
		headPath = IconManager.getHeadPic(npcData.icon)
	end

	if not empty(headPath) then
		headView:createIconOnFlag("flag_icon", headPath, 100, true)
	else
		local iconFlag = headView:getFlagByTag("flag_icon")
		local npcIcon = PortraitManager.getNpcMugshot(npcID, iconFlag, 2.5, nil, {
			y = -1,
			x = 0
		})

		npcIcon:setScaleX(-1)
		headView:addChild(npcIcon, 100)
		headView:setComponentToTag("flag_icon", npcIcon)
	end
end

local LEAD = {
	{
		npc = 10010,
		checkFunc = function ()
			if InfoBuilding.getBuildingLevel(InfoBuilding.TAG.FURNACE) > 0 then
				local cash, cashMax = InfoFurnace.getCash()

				return cashMax <= cash
			end
		end
	},
	{
		npc = 10301,
		checkFunc = function ()
			if InfoBuilding.getBuildingLevel(InfoBuilding.TAG.FARM) > 0 then
				local cash, cashMax = InfoFarm.countHarvest()

				return cashMax <= cash
			end
		end
	},
	{
		npc = 10302,
		checkFunc = function ()
			if InfoBuilding.getBuildingLevel(InfoBuilding.TAG.FARM) > 0 then
				local newSeed = InfoFarm.getNewSeed()

				return newSeed ~= nil
			end
		end
	},
	{
		npc = 10102,
		checkFunc = function ()
			return InfoAbyssGift.countRedot() > 0
		end
	},
	{
		npc = 10024,
		checkFunc = function ()
			return InfoTravel.countRedot() > 0
		end
	},
	{
		npc = 10101,
		checkFunc = function ()
			return InfoKanban.countRedot() > 0
		end
	},
	{
		npc = 10025,
		checkFunc = function ()
			return InfoLikes.countRedot() > 0
		end
	},
	{
		npc = 30002023,
		checkFunc = function ()
			return InfoPetHatch.countRedot() > 0
		end
	},
	{
		npc = 10020,
		checkFunc = function ()
			return InfoArena.countRedot() > 0
		end
	},
	{
		npc = 30007,
		checkFunc = function ()
			return InfoGacha.countRedot() > 0
		end
	},
	{
		npc = 10030,
		checkFunc = function ()
			return InfoDelayItem.countReady(InfoHome.DELAY_TYPES) > 0
		end
	},
	{
		npc = 10035,
		checkFunc = function ()
			if InfoParams.getValue("artifact") == 1 then
				local funcCSV = InfoFunction.checkFuncOpen(10700)

				if funcCSV then
					return InfoCore.countRedot() > 0
				end
			end

			return false
		end
	}
}

function FRAME_main_task:refreshLead()
	if not self.leadHeads then
		self.leadHeads = {}
	end

	local leadArr = {}
	local buildArr = InfoBuilding.getNewBuildList()

	if InfoGuide.isFin() then
		for i, tag in ipairs(buildArr) do
			local id = CampUtils.findBuldingNpc(tag)
			local id0 = CampUtils.findBulding0Npc(tag)
			local npcID = id0
			npcID = npcID or id
			local showID = id
			showID = showID or id0

			if npcID and showID then
				table.insert(leadArr, {
					isBuild = true,
					npc = npcID,
					showNpc = showID
				})
			end
		end
	end

	if self.type == TYPE.CAMP then
		for i, v in ipairs(LEAD) do
			if v.checkFunc() then
				table.insert(leadArr, v)
			end
		end
	elseif self.type == TYPE.UNION then
		-- Nothing
	end

	for i, data in ipairs(leadArr) do
		if i > 6 then
			break
		end

		local headView = self.leadHeads[i]

		if not headView then
			headView = UIManager.getUI("com_lead_head")
			self.leadHeads[i] = headView
			local headFlag = self:getFlagByTag("flag_lead_" .. i)

			headView:setPosition(headFlag.x + headFlag.width / 2, headFlag.y + headFlag.height / 2)
			self:addChild(headView, 100)

			local border = headView:getComponentByTag("border")

			border:setLocalZOrder(200)
			border:toTouchable()
			border:setOpacity(200)

			local redot = headView:getComponentByTag("redot")

			redot:setLocalZOrder(300)

			local build = headView:getComponentByTag("build")

			build:setLocalZOrder(300)
		end

		local redot = headView:getComponentByTag("redot")
		local build = headView:getComponentByTag("build")

		if not data.isUnion then
			local showNpc = data.showNpc or data.npc
			local goNpc = data.npc
			local border = headView:getComponentByTag("border")

			border:addTap(function ()
				CampUtils.goNpc(goNpc)
			end)
			border:setTapGroup("button_click")
			self:setNpcHead(headView, showNpc)
			redot:setVisible(not data.isBuild)
			build:setVisible(data.isBuild)
		end
	end

	for i = #leadArr + 1, #self.leadHeads do
		self.leadHeads[i]:removeSelf()

		self.leadHeads[i] = nil
	end
end

function FRAME_main_task:refresh()
	if not self.heads then
		self.heads = {}
	end

	local taskArr = InfoTaskQuest.getList()

	for i, data in ipairs(taskArr) do
		if i > 3 then
			break
		end

		local headView = self.heads[i]

		if not headView then
			headView = UIManager.getUI("com_task_head")
			self.heads[i] = headView
			local headFlag = self:getFlagByTag("flag_head_" .. i)

			headView:setPosition(headFlag.x + headFlag.width / 2, headFlag.y + headFlag.height / 2)
			self:addChild(headView, 100)

			local border = headView:getComponentByTag("border")

			border:setLocalZOrder(200)
			border:toTouchable()
			border:setOpacity(200)
		end

		local border = headView:getComponentByTag("border")

		border:addTap(function ()
			local taskCSV = CsvParser.getCsvData("task", data.base_id)
			local npcID = taskCSV.npc

			CampUtils.goNpc(npcID)
		end)
		border:setTapGroup("button_click")

		local iconName = InfoTaskQuest.getIconName(data)

		if iconName ~= headView.iconName then
			if headView.icon then
				headView.icon:removeSelf()

				headView.icon = nil
			end

			local icon = Animation.new()

			icon:load(InfoTaskQuest.getIconName(data))

			local iconFlag = headView:getFlagByTag("flag_task_icon")

			icon:setPosition(iconFlag.x + iconFlag.width / 2, iconFlag.y + iconFlag.height / 2)
			icon:setLooper(Looper.core)
			icon:setLastFrameFreeze(function ()
				return math.random(25, 30)
			end)
			icon:randomizeFrame()
			icon:setRotation(-10)
			headView:addChild(icon, 300)

			headView.icon = icon
			headView.iconName = iconName
		end

		local taskCSV = CsvParser.getCsvData("task", data.base_id)
		local npcID = taskCSV.npc

		self:setNpcHead(headView, npcID)
	end

	for i = #taskArr + 1, #self.heads do
		self.heads[i]:removeSelf()

		self.heads[i] = nil
	end
end

return FRAME_main_task
