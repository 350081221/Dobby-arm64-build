local UserCookie = {}
local kvMap = {}
local userId = nil

function UserCookie.init(_userId)
	userId = _userId
	local path = cc.FileUtils:getInstance():getWritablePath() .. "game_usercookies_" .. userId .. ".txt"

	if io.exists(path) then
		local contents = io.readfile(path)
		local obj = json.decode(contents)

		if obj ~= nil then
			kvMap = obj
		end
	end
end

function UserCookie.set(key, value, doFlush)
	if not userId then
		Log.warn("UserCookie need userId")

		return
	end

	kvMap[key] = value

	if doFlush then
		UserCookie.flush()
	end
end

function UserCookie.get(key)
	if not userId then
		Log.warn("UserCookie need userId")

		return
	end

	return kvMap[key]
end

function UserCookie.flush()
	if not userId then
		Log.warn("UserCookie need userId")

		return
	end

	local path = cc.FileUtils:getInstance():getWritablePath() .. "game_usercookies_" .. userId .. ".txt"
	local str = json.encode(kvMap)

	if str then
		io.writefile(path, str)
	end
end

return UserCookie
