local ClipOnMap = import(".ClipOnMap")
local Effect = class("Effect", ClipOnMap)

function Effect.getEffect(modelName)
	local instanceList = ClipOnMap.getUnitList("effect")

	for i, instance in ipairs(instanceList) do
		if instance.modelName == modelName then
			return instance
		end
	end
end

function Effect:ctor(type)
	Effect.super.ctor(self, type or "effect")
end

function Effect:load(modelName, afterBornCallback)
	Effect.super.load(self, modelName)

	if self:hasAction("born") then
		self:setAction("born", 1, function ()
			self:setAction("idle")

			if afterBornCallback then
				afterBornCallback()
			end
		end)
	elseif afterBornCallback then
		afterBornCallback(self)
	end
end

function Effect:destroy()
	if self:hasAction("die") then
		self:setAction("die", 1, function ()
			self:removeSelf()
		end)
	else
		self:removeSelf()
	end
end

function Effect:delayRemove()
	MapFrameManager.setTimeout(function ()
		self:removeSelf()
	end, 1, self)
end

return Effect
