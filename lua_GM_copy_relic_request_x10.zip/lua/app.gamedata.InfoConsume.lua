local InfoConsume = {}
local rawData = nil

function InfoConsume.init()
	Connection.listen("consume_sync", InfoConsume.sync)
end

app:addToAppEnterCall(InfoConsume.init)

function InfoConsume.query(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "consume_query")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			InfoConsume.onQuery(rcvData)

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("consume_query", callback)
end

function InfoConsume.onQuery(rcvData)
	rawData = rcvData
end

function InfoConsume.sync(data)
	dump(data, "$$$ InfoConsume.sync")

	for k, v in pairs(data) do
		rawData[k] = v
	end

	ManagerInfo.dataChange("consume", data)
end

function InfoConsume.bagUnlock(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("consume_bag_unlock", callback)
end

function InfoConsume.armoryUnlock(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("consume_armory_unlock", callback)
end

function InfoConsume.getBagAmount()
	return CsvParser.getCsvData("bag_unlock", rawData.bag_unlock)
end

function InfoConsume.getArmoryAmount()
	return CsvParser.getCsvData("armory_unlock", rawData.armory_unlock)
end

return InfoConsume
