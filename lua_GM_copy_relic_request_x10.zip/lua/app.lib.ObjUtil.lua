local ObjUtil = {}

function ObjUtil.readonly(t, deep)
	if deep then
		for k, v in pairs(t) do
			if type(v) == "table" then
				t[k] = ObjUtil.readonly(v, deep)
			end
		end
	end

	local meta = {
		__index = t,
		__newindex = function ()
			print("$$$ readonly", debug.traceback())

			if DEV_MODE then
				assert(false, "table is readonly\n")
			end
		end
	}
	local locked = {}

	setmetatable(locked, meta)

	return locked
end

local function fcomp_default(a, b)
	return a < b
end

function ObjUtil.binInsert(t, value, fcomp)
	local fcomp = fcomp or fcomp_default
	local iStart = 1
	local iEnd = #t
	local iMid = 1
	local iState = 0

	while iStart <= iEnd do
		iMid = math.floor((iStart + iEnd) / 2)

		if fcomp(value, t[iMid]) then
			iState = 0
			iEnd = iMid - 1
		else
			iState = 1
			iStart = iMid + 1
		end
	end

	table.insert(t, iMid + iState, value)

	return iMid + iState
end

local function default_fcompval(value)
	return value
end

local function fcompf(a, b)
	return a < b
end

local function fcompr(a, b)
	return b < a
end

function ObjUtil.binSearch(tbl, value, fcompval, reversed)
	local fcompval = fcompval or default_fcompval
	local fcomp = reversed and fcompr or fcompf
	local iStart = 1
	local iEnd = #tbl
	local iMid = 0

	while iStart <= iEnd do
		iMid = math.floor((iStart + iEnd) / 2)
		local value2 = fcompval(tbl[iMid])

		if value == value2 then
			local tfound = {
				iMid,
				iMid
			}
			local num = iMid - 1

			while value == fcompval(tbl[num]) do
				num = num - 1
				tfound[1] = num
			end

			num = iMid + 1

			while value == fcompval(tbl[num]) do
				num = num + 1
				tfound[2] = num
			end

			return tfound
		elseif fcomp(value, value2) then
			iEnd = iMid - 1
		else
			iStart = iMid + 1
		end
	end
end

function ObjUtil.compare(obj1, obj2)
	for k, v in pairs(obj1) do
		if obj2[k] ~= v then
			return false
		end
	end

	return true
end

function ObjUtil.copy(resObj, destObj)
	destObj = destObj or {}

	for k, v in pairs(resObj) do
		destObj[k] = v
	end

	return destObj
end

function ObjUtil.clone(resObj, destObj)
	destObj = destObj or {}

	for k, v in pairs(resObj) do
		if type(v) == "table" then
			destObj[k] = {}

			ObjUtil.clone(v, destObj[k])
		else
			destObj[k] = v
		end
	end

	return destObj
end

function ObjUtil.deepCoverValue(resObj, destObj)
	for k, v in pairs(resObj) do
		if type(v) == "table" then
			if destObj[k] and type(destObj[k]) == "table" then
				ObjUtil.deepCoverValue(v, destObj[k])
			end
		elseif destObj[k] and type(destObj[k]) ~= "table" then
			destObj[k] = tonumber(v) or v
		end
	end
end

function ObjUtil.deepObjToKV(obj, separator, keyStr, map)
	map = map or {}
	separator = separator or "_"
	keyStr = keyStr or ""

	for k, v in pairs(obj) do
		local tempKey = keyStr

		if tempKey ~= "" then
			tempKey = tempKey .. separator
		end

		tempKey = tempKey .. k

		if type(v) == "table" then
			ObjUtil.deepObjToKV(v, separator, tempKey, map)
		else
			map[tempKey] = v
		end
	end

	return map
end

function ObjUtil.getIndexUpFrom(value, arr, sortKey)
	local startIndex = 1
	local endIndex = #arr
	local centerIndex = 0

	if value < arr[startIndex][sortKey] then
		centerIndex = 0
	elseif arr[endIndex][sortKey] <= value then
		centerIndex = endIndex
	else
		while true do
			centerIndex = math.floor((startIndex + endIndex) / 2)

			if value < arr[centerIndex][sortKey] then
				if arr[centerIndex - 1][sortKey] <= value then
					centerIndex = centerIndex - 1

					break
				end

				endIndex = centerIndex
			else
				if value < arr[centerIndex + 1][sortKey] then
					break
				end

				startIndex = centerIndex
			end
		end
	end

	return centerIndex
end

return ObjUtil
