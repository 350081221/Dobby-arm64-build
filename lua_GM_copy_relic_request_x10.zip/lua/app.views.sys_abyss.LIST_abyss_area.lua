local List = import("...ui.List")
local LIST_abyss_area = class("LIST_abyss_area", List)

function LIST_abyss_area:ctor(rect)
	LIST_abyss_area.super.ctor(self, rect)
	self:setCellName("cell_abyss_area")
	self:setSpace(5, 5)
	self:setCellSize(cc.size(self.touchRect.width, 220))
	self:setSelectEnabled(true)
end

function LIST_abyss_area:onCellInit(ui, csv, index)
	local nameLabel = ui:createLabelOnFlag("flag_name", csv.name)
	local icon = ui:createIconOnFlag("flag_icon", IconManager.getAbyssAreaIcon(csv.id), 100, true)
	local icon_map = ui:getComponentByTag("icon_map")

	icon_map:setLocalZOrder(190)

	local icon_mine = ui:getComponentByTag("icon_mine")

	icon_mine:setLocalZOrder(190)

	local mapCount, mapAlready, mineCount, mineAlready = InfoDungeon.getAreaInfo(csv.id)

	if mapCount == 0 and mineCount == 0 then
		nameLabel:setPositionY(nameLabel:getPositionY() - 14)
	end

	if mineCount > 0 then
		local style = {}

		if mapCount <= mapAlready then
			style.color = Style.enableColor
		end

		ui:replaceLabelOnFlag("flag_map", style, mapAlready, mapCount)
		icon_map:setVisible(true)
	else
		ui:removeLabelOnFlag("flag_map")
		icon_map:setVisible(false)
	end

	if mineCount > 0 then
		local style = {}

		if mineCount <= mineAlready then
			style.color = Style.enableColor
		end

		ui:replaceLabelOnFlag("flag_mine", style, mineAlready, mineCount)
		icon_mine:setVisible(true)
	else
		ui:removeLabelOnFlag("flag_mine")
		icon_mine:setVisible(false)
	end

	local bg1 = ui:getComponentByTag("bg1")

	bg1:setLocalZOrder(180)

	local _selected = ui:getComponentByTag("selected")

	_selected:setLocalZOrder(200)
	self:onCellSelected(ui, data, self.selectedIndex == index, true)
end

function LIST_abyss_area:onCellSelected(ui, csv, selected, isInit)
	local _selected = ui:getComponentByTag("selected")

	_selected:setVisible(selected)

	if isInit then
		if selected then
			ui:setOpacity(255)
		else
			ui:setOpacity(150)
		end
	elseif selected then
		transition.stopTarget(ui)
		transition.fadeTo(ui, {
			opacity = 255,
			time = 0.2
		})
	else
		transition.stopTarget(ui)
		transition.fadeTo(ui, {
			opacity = 150,
			time = 0.2
		})
	end
end

return LIST_abyss_area
