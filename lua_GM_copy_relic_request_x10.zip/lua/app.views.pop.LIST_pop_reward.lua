local List = import("...ui.List")
local LIST_pop_reward = class("LIST_pop_reward", List)

function LIST_pop_reward:ctor(rect, cols)
	LIST_pop_reward.super.ctor(self, rect)
	self:setCols(cols or 6)
	self:setSpace(20, 20)
	self:setCellName("cell_pop_reward")
	self:setCellSize(cc.size(self.touchRect.width, 144))
end

function LIST_pop_reward:onCellInit(ui, data)
	if not ui.slot then
		ui.slot = DropSlot.new(ui:getFlagByTag("flag_slot"), "slot_02")

		ui:addChild(ui.slot, 100)
	end

	ui.slot:setDrop(data.type, data.info)
end

return LIST_pop_reward
