local NAV_base = import(".NAV_base")
local NAV_storage = class("NAV_storage", NAV_base)

function NAV_storage.open(npc)
	local ui = NAV_storage.new(npc)

	return ui
end

function NAV_storage:ctor(npc)
	NAV_storage.super.ctor(self, npc, "nav_storage")
end

function NAV_storage:init()
	NAV_storage.super.init(self)

	local index = 2
	local funcCSV = InfoFunction.checkFuncOpen(10110)

	if funcCSV then
		self:setButtonVisible(index, true)

		local ui = self.buttons[index].ui

		self:setButtonName(ui, funcCSV.name)
		self:setBuildingLvupIndex(2)
	else
		self:setButtonVisible(index, false)
	end
end

function NAV_storage:onTap(index)
	NAV_storage.super.onTap(self, index)

	if index == 1 then
		FRAME_ware.open()
	end
end

return NAV_storage
