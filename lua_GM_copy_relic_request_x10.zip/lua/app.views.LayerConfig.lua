local LayerConfig = {
	notice_exit = 3000,
	conn_alert = 2500,
	pickCell = 2000,
	alert = 1600,
	notice = 1500,
	consoleKey = 5200,
	consoleSheet = 1100,
	console = 1000,
	transition = 900,
	marquee = 700,
	notify = 600,
	drama = 550,
	aside = 500,
	finger = 450,
	dialog = 400,
	lock = 360,
	hint = 350,
	focus = 300,
	mask = 200,
	curtain = 150,
	pop = 140,
	nav = 130,
	read = 355,
	resource = 110,
	sys = 100,
	mainUI = 90,
	battleResult = 80
}
local poplocks = nil

function LayerConfig.setPopLocked(tag, locked)
	if locked then
		poplocks = poplocks or {}
		poplocks[tag] = true
	elseif poplocks then
		poplocks[tag] = nil
	end

	if poplocks then
		if table.nums(poplocks) == 0 then
			poplocks = nil

			notify.dispatch("pop_clear")
		end
	else
		notify.dispatch("pop_clear")
	end
end

function LayerConfig.clearPopLocked()
	poplocks = nil
end

function LayerConfig.isPopLocked()
	return poplocks ~= nil
end

local uiExists = nil

function LayerConfig.setUiExist(tag, exist)
	if exist then
		uiExists = uiExists or {}
		uiExists[tag] = true
	elseif uiExists then
		uiExists[tag] = nil
	end

	if uiExists then
		if table.nums(uiExists) == 0 then
			uiExists = nil

			notify.dispatch("ui_clear")
		end
	else
		notify.dispatch("ui_clear")
	end
end

function LayerConfig.clearUiExist()
	uiExists = nil
end

function LayerConfig.isUiExist()
	return uiExists ~= nil
end

return LayerConfig
