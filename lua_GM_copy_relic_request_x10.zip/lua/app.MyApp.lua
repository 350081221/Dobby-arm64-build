require("config")
require("cocos.init")
require("framework.init")
require("app_info")

local Scheduler = cc.Director:getInstance():getScheduler()
local AppBase = require("framework.AppBase")
local MyApp = class("MyApp", AppBase)
tween = import(".lib.tween")
json = require("framework.json")
Cookie = import(".lib.Cookie")
Style = import(".ui.Style")
Localization = import(".core.Localization")
UIManager = import(".ui.UIManager")
UILayout = import(".ui.UILayout")
PopManager = import(".ui.PopManager")
ConfParser = import(".lib.ConfParser")
CsvParser = import(".lib.CsvParser")
JsonParser = import(".lib.JsonParser")
StringUtil = import(".lib.StringUtil")
Console = import(".views.system.Console")
Time = import(".lib.Time")

function isINF(value)
	return value == math.huge or value == -math.huge
end

function isNAN(value)
	return value ~= value
end

global = {}
globalScene = {}

function MyApp:ctor()
	MyApp.super.ctor(self)
end

local appEnterCallStack = {}

function MyApp:addToAppEnterCall(func)
	table.insert(appEnterCallStack, func)
end

function MyApp:initUICallback()
	UIManager.setTapCallback("button_click", function (uiCom, isManual, onManualComplete)
		Sound.playSound("ui_click")

		if uiCom and isManual then
			uiCom:setScale(0.95)
			uiCom:performWithDelay(function ()
				uiCom:setScale(1)

				if onManualComplete then
					onManualComplete()
				end
			end, 0.1)
		end
	end, function (uiCom, event)
		if uiCom and not tolua.isnull(uiCom) then
			if event == "began" then
				uiCom:setScale(0.95)
			elseif event == "ended" then
				uiCom:setScale(1)
			end
		end
	end)
	UIManager.setTapCallback("slot_click", function (uiCom, isManual, onManualComplete)
		Sound.playSound("ui_click")

		if uiCom and isManual then
			uiCom:setScale(0.96)

			local x, y = uiCom:getPosition()
			uiCom._touchStartRect = cc.p(x, y)

			uiCom:setPosition(x + uiCom.width * 0.02, y + uiCom.height * 0.02)

			uiCom._touchStartCom = uiCom

			uiCom:performWithDelay(function ()
				uiCom:setScale(1)

				if uiCom._touchStartRect then
					uiCom:setPosition(uiCom._touchStartRect.x, uiCom._touchStartRect.y)
				end

				if onManualComplete then
					onManualComplete()
				end
			end, 0.1)
		end
	end, function (uiCom, event)
		if uiCom and not tolua.isnull(uiCom) then
			if event == "began" then
				uiCom:setScale(0.96)

				local x, y = uiCom:getPosition()
				uiCom._touchStartRect = cc.p(x, y)

				uiCom:setPosition(x + uiCom.width * 0.02, y + uiCom.height * 0.02)

				uiCom._touchStartCom = uiCom
			elseif event == "ended" then
				uiCom:setScale(1)

				if uiCom._touchStartRect then
					uiCom:setPosition(uiCom._touchStartRect.x, uiCom._touchStartRect.y)
				end
			end
		end
	end)
	UIManager.setTapCallback("bg_click", function (uiCom)
		Sound.playSound("ui_click")
	end)
	UIManager.setTapCallback("list_click", function (uiCom)
		Sound.playSound("ui_click")
	end, function (uiCom, event, container)
		if event == "began" then
			if uiCom and not tolua.isnull(uiCom) and container and not tolua.isnull(container) then
				uiCom:setScale(0.96)

				local x, y = uiCom:getPosition()
				uiCom._touchStartRect = cc.p(x, y)

				uiCom:setPosition(x + uiCom.width * 0.02, y + uiCom.height * 0.02)

				container._touchStartCom = uiCom
			end
		elseif (event == "ended" or event == "cancelled") and container and not tolua.isnull(container) then
			uiCom = container._touchStartCom

			if uiCom and not tolua.isnull(uiCom) then
				uiCom:setScale(1)

				if uiCom._touchStartRect then
					uiCom:setPosition(uiCom._touchStartRect.x, uiCom._touchStartRect.y)
				end
			end
		end
	end)
	UIManager.setTapCallback("list_click_mute", function (uiCom)
	end, function (uiCom, event, container)
		if event == "began" then
			if uiCom and not tolua.isnull(uiCom) and container and not tolua.isnull(container) then
				uiCom:setScale(0.96)

				local x, y = uiCom:getPosition()
				uiCom._touchStartRect = cc.p(x, y)

				uiCom:setPosition(x + uiCom.width * 0.02, y + uiCom.height * 0.02)

				container._touchStartCom = uiCom
			end
		elseif (event == "ended" or event == "cancelled") and container and not tolua.isnull(container) then
			uiCom = container._touchStartCom

			if uiCom and not tolua.isnull(uiCom) then
				uiCom:setScale(1)

				if uiCom._touchStartRect then
					uiCom:setPosition(uiCom._touchStartRect.x, uiCom._touchStartRect.y)
				end
			end
		end
	end)
end

function MyApp:resetScene()
	UIManager.init()

	if global.loginFrameOver then
		if InfoDungeon.inDungeon() then
			Log.debug("重构场景 副本")
			InfoDungeon.retry()
		elseif InfoUnion.inMap() then
			Log.debug("重构场景 公会")
			InfoUnion.enterMap()
		elseif InfoDungeon.isHome() then
			Log.debug("重构场景 家园")
			InfoHome.resetMap()
		else
			Log.debug("重构场景 营地")
			InfoDungeon.enterCamp()
		end
	elseif self.sceneName == "LoginScene" then
		self:enterScene("LoginScene", {
			isResetScene = true
		})
	end
end

function MyApp:run()
	math.randomseed(socket.gettime())

	self.inScene = true
	global.rancode = math.floor(socket.gettime()) .. "_" .. math.random(1, 65535)

	cc.FileUtils:getInstance():addSearchPath("res/")
	Time.init()
	Localization.init(2)
	UIManager.init()
	self:initUICallback()
	require("app.GlobalImport")
	Cookie.init()
	Sound.init()
	SkillManager.init()
	Style.init()

	for i = 1, #appEnterCallStack do
		appEnterCallStack[i]()
	end

	if CONFIG.isBench then
		BenchHelper.init()
	end

	LuaBridge.register("log", function (result)
		Log.warn("[system]" .. result.msg)
	end)
	print("监听SDK刘海")
	LuaBridge.register("liuhai_callback", function (result)
		UIManager.setLiuhai(result.liuhai, result.width)
	end)

	if device.platform == "android" then
		local sharedDirector = cc.Director:getInstance()
		local glview = sharedDirector:getOpenGLView()
		local glviewSize = glview:getFrameSize()
		local currWidth = glviewSize.width
		local currHeight = glviewSize.height
		local originalWidth = glviewSize.width
		local originalHeight = glviewSize.height

		local function callback(dt)
			LuaBridge.call("luaGetSize", {}, function (sizeObj)
				local width = sizeObj.width
				local height = sizeObj.height

				if width < height / 1.5 then
					return
				end

				if math.abs(width - originalWidth) / originalWidth <= 0.1 and math.abs(height - originalHeight) / originalHeight <= 0.1 then
					width = originalWidth
					height = originalHeight
				end

				if math.abs(width - currWidth) / currWidth > 0.1 or math.abs(height - currHeight) / currHeight > 0.1 then
					currWidth = width
					currHeight = height
					display.width = currWidth / currHeight * display.height

					Log.debug("重构场景", display.width, display.height, global.loginFrameOver)
					glview:setFrameSize(currWidth, currHeight)
					glview:setDesignResolutionSize(display.width, display.height, cc.ResolutionPolicy.NO_BORDER)
					self:resetScene()
				end
			end)
		end

		local callbackEntry = Scheduler:scheduleScriptFunc(callback, 0.5, false)
	end

	Log.debug("$$$ SERVER_HOST, SERVER_PORT", SERVER_HOST, SERVER_PORT)

	if QUICK_TEST_SCENE then
		self:enterScene(QUICK_TEST_SCENE)
		Connection.init(SERVER_HOST, SERVER_PORT)
	elseif CONFIG.dafu or CONFIG.shijie then
		self:enterScene("LoginScene")
	else
		Connection.init(SERVER_HOST, SERVER_PORT)
		self:enterScene("LoginScene")
	end

	local __g = _G

	setmetatable(__g, {
		__newindex = function (_, name, value)
			local msg = "USE 'global.%s = value' INSTEAD OF SET GLOBAL VARIABLE"

			error(string.format(msg, name), 0)
		end
	})
end

local sceneEnterCallStack = {}
local sceneExitCallStack = {}

function MyApp:enterScene(sceneName, sceneData)
	self.preSceneName = self.sceneName
	self.sceneName = sceneName
	self.sceneData = sceneData

	if self.preSceneName then
		Transition.leave(function ()
			MyApp.super.enterScene(self, "TransitionScene")
		end)
	else
		Transition.leave(function ()
			Transition.clear()
			Log.verbose("MyApp:enterScene resume", sceneName)

			self.sceneChanging = true

			MyApp.super.enterScene(self, sceneName)
		end)
	end
end

function MyApp:resumeScene(scene)
	self:gcInfo("resumeScene before")
	display.removeUnusedSpriteFrames()
	cc.SpriteFrameCache:getInstance():removeSpriteFrames()
	cc.Director:getInstance():getTextureCache():removeAllTextures()
	collectgarbage("collect")
	self:gcInfo("resumeScene after")

	local sceneName = self.sceneName
	local sceneData = self.sceneData

	print("$$$ resumeScene", sceneName, sceneData)
	MyApp.super.enterScene(self, sceneName)
	Transition.enter()
end

function MyApp:clearScene(scene)
	globalScene = {}

	LayerConfig.clearPopLocked()
	LayerConfig.clearUiExist()
	PopManager.clear()
	ManagerInfo.clear()
	Looper.clear()
	MapFrameManager.clear()
	Console.clear()
	Alert.clear()
	UIManager.clear()
	HintManager.clear()
	POP_dialog.clear()
	POP_curtain.clear()
	POP_drama.clear()
	DramaManager.clear()
	Clip.clear()
	List.clearCellPool()
	MapFont.clearCellPool()
	Transition.clear()

	Monster.noCheckBattle = nil

	WarMachine.clear()
	TeamManager.clear()
	GuideManager.clear()
	Sound.clear()
	InfoFarm.clear()
	InfoExchange.clear()
	InfoFishing.clear()
	InfoHero.clear()
	InfoUnion.clearOnScene()
	WarMachine.clearOnScene()
	OnlineCamp.clearOnScene()
	OnlineChat.clearOnScene()
	CampUtils.clearOnScene()

	if FestivalUtils and FestivalUtils.clearOnScene then
		FestivalUtils.clearOnScene()
	end

	RefreshManager.clearCache()
	LinesManager.clearCache()
	InfoOrder.clearCache()
	InfoDungeon.clearCache()
	InfoArena.clearOnScene()
	PortraitManager.clearOnScene()
	Rantile.clearOnScene()
	MapUtils.clearOnScene()
	FRAME_dungeon_battle.clearOnScene()
end

function MyApp:gcInfo(msg)
	if msg then
		print(msg)
	end

	if DEV_MODE or device.platform == "windows" then
		printInfo("---------------------------------------------------")

		local sharedTextureCache = cc.Director:getInstance():getTextureCache()
		local str = sharedTextureCache:getCachedTextureInfo()
		local lines = str:split("\n")

		if lines[#lines - 1] then
			print(lines[#lines - 1])
		end

		local k = collectgarbage("count")
		local m = math.ceil(k / 1024 * 10) / 10

		printInfo(string.format("LUA VM MEMORY USED: %0.2f KB (%0.2f MB)", k, m))
		printInfo("---------------------------------------------------")
	end
end

function MyApp:onSceneEnter(scene, waitForOpen, openingTime)
	if not self.preSceneName then
		display.removeUnusedSpriteFrames()
		cc.SpriteFrameCache:getInstance():removeSpriteFrames()
	end

	Transition.enter(waitForOpen, openingTime)
	Looper.setOwner(scene)

	for i = 1, #sceneEnterCallStack do
		sceneEnterCallStack[i]()
	end

	sceneEnterCallStack = {}

	if device.platform == "android" then
		scene:performWithDelay(function ()
			local layer = display.newLayer()

			layer:setTouchSwallowEnabled(false)
			layer:setKeypadEnabled(true)
			layer:addNodeEventListener(cc.KEYPAD_EVENT, function (event)
				if event.type == "Released" and event.key == "back" then
					MyApp.onKeyBack()
				end
			end)
			scene:addChild(layer)
		end, 0.5)
	elseif device.platform == "windows" then
		scene:performWithDelay(function ()
			local layer = display.newLayer()

			layer:setTouchSwallowEnabled(false)
			layer:setKeypadEnabled(true)
			layer:addNodeEventListener(cc.KEYPAD_EVENT, function (event)
				if event.type == "Released" and DEV_MODE then
					if event.code == 7 then
						MyApp.onKeyBack()
					elseif event.code == 123 then
						local history = Cookie.get("console_command_history")

						if history and #history > 0 then
							local cmd = history[#history]
							local success = Console.cmd(cmd)
						end
					end
				end
			end)
			scene:addChild(layer)
		end, 0.5)
	end

	if DEV_MODE then
		Console.keyboard()
	end

	POP_marquee.new()

	self.sceneChanging = nil
end

local keyBackCallback = nil

function MyApp:setKeyBackCallback(callback)
	keyBackCallback = callback
end

function MyApp:clearKeyBackCallback()
	keyBackCallback = nil
end

local isSdkExit = nil

function MyApp.onKeyBack()
	if keyBackCallback then
		keyBackCallback()

		return
	end

	if PopManager.count() > 0 then
		PopManager.closeAll(true)

		return
	end

	local function doLogout()
		if isSdkExit == 1 then
			LuaBridge.call("luaExit")
		else
			Notice.exit()
		end
	end

	if CONFIG.is_sdk_exit then
		if isSdkExit ~= nil then
			doLogout()
		else
			LuaBridge.call("luaIsShowExit", {}, function (result)
				if result.isShowExit then
					isSdkExit = 1
				else
					isSdkExit = 2
				end

				doLogout()
			end)
		end
	else
		doLogout()
	end
end

function MyApp:onSceneExit(scene)
	for i = 1, #sceneExitCallStack do
		sceneExitCallStack[i]()
	end

	sceneExitCallStack = {}

	self:clearScene(scene)
end

function MyApp:addToSceneEnterCall(func)
	table.insert(sceneEnterCallStack, func)
end

function MyApp:addToSceneExitCall(func)
	table.insert(sceneExitCallStack, func)
end

function MyApp:checkRunning(scene)
	if display.getRunningScene() == scene then
		return true
	else
		return false
	end
end

local originalTraceback = __G__TRACKBACK__

function __G__TRACKBACK__(errorMessage)
	if originalTraceback then
		originalTraceback(errorMessage)
	end

	local tracebackMsg = debug.traceback("", 2)

	InfoGM.sendError("trackback", tostring(errorMessage) .. "\n" .. tracebackMsg)

	if DEV_MODE then
		Console.markError()
		Console.logError("----------------------------------------\n" .. "LUA ERROR: " .. tostring(errorMessage) .. "\n" .. tracebackMsg .. "\n----------------------------------------")
	end
end

return MyApp
