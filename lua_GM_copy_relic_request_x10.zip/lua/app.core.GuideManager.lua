local GuideManager = {}
local alreadyGuideRelic = nil

function GuideManager.guideRelic()
end

function GuideManager.guideSetLeader()
end

function GuideManager.guidePopDrop(dropList)
	local function checkDropID(id)
		for i, drop in ipairs(dropList) do
			if tostring(drop.info.base_id) == tostring(id) then
				return true
			end
		end

		return false
	end
end

local preNpcUIStack = nil

function GuideManager.checkNpcUI(npcUIStack)
end

function GuideManager.setModaoHidden(hidden)
	global.modaoHidden = hidden

	notify.dispatch("modao_hidden", hidden)
end

local guideIndex, guideBattleHero, onGuideBattleComplete, guideHintArr = nil

function GuideManager.startGuideBattle(hero, onComplete, hintStr)
	guideBattleHero = hero
	onGuideBattleComplete = onComplete
	guideHintArr = string.split(hintStr, ",")

	Looper.startLoop(guideBattleHero, GuideManager.checkGuideBattleLoop)
	TaHelper.taGuideDetail(11300)
end

function GuideManager.startGuideCancel(hero, onComplete, hintStr)
	guideBattleHero = hero
	onGuideBattleComplete = onComplete
	guideHintArr = string.split(hintStr, ",")

	Looper.startLoop(guideBattleHero, GuideManager.checkGuideCancelLoop)
end

function GuideManager.startGuideModao(id, onComplete, hintStr)
	local pos = InfoModao.getPosBySkill(id)

	if global.player and pos and pos > 0 then
		guideIndex = pos
		guideBattleHero = global.player
		onGuideBattleComplete = onComplete
		guideHintArr = string.split(hintStr, ",")

		Looper.startLoop(guideBattleHero, GuideManager.checkGuideModaoLoop)
	end
end

function GuideManager.startGuideItem(onComplete, hintStr)
	if global.player then
		guideBattleHero = global.player
		onGuideBattleComplete = onComplete
		guideHintArr = string.split(hintStr, ",")

		Looper.startLoop(guideBattleHero, GuideManager.checkGuideItemLoop)
	end
end

function GuideManager.stopGuideBattle()
	if guideBattleHero then
		Looper.stopLoop(guideBattleHero, GuideManager.checkGuideBattleLoop)
		Looper.stopLoop(guideBattleHero, GuideManager.checkGuideCancelLoop)
		Looper.stopLoop(guideBattleHero, GuideManager.checkGuideItemLoop)
		Looper.stopLoop(guideBattleHero, GuideManager.checkGuideModaoLoop)

		guideBattleHero = nil
	end
end

function GuideManager.checkGuideModaoLoop()
	if not WarMachine.on then
		Looper.stopLoop(guideBattleHero, GuideManager.checkGuideModaoLoop)

		return
	end

	local ready, skillPack, castTarget = GuideManager.checkGuideModao(guideIndex)

	if ready then
		local skillData = skillPack.data

		Looper.stopLoop(guideBattleHero, GuideManager.checkGuideModaoLoop)
		MapFrameManager.pause("new_guide")

		local monsters = WarMachine.getUnitsByCamp(2)

		for i, monster in ipairs(monsters) do
			monster:setUndeadable(true)
		end

		local guideUI = nil

		local function onHintTouch(event, x, y)
			if not guideUI then
				guideUI = GUIDE_cast.new(global.ui)

				global.ui:addChild(guideUI, 120)
				guideUI:initCast(skillData.id, guideIndex, castTarget, function ()
					MapFrameManager.pause("new_guide")
					HintManager.close()
					HintManager.open(guideHintArr[2], function ()
						MapFrameManager.resume("new_guide")

						local monsters = WarMachine.getUnitsByCamp(2)

						for i, monster in ipairs(monsters) do
							monster:setUndeadable(false)
						end

						if onGuideBattleComplete then
							onGuideBattleComplete()
						end
					end)
				end, function (result)
					HintManager.close()
					HintManager.open(guideHintArr[3])
				end, true)
			end

			if event == "began" then
				POP_hint.close()
				POP_focus.hide()
			end

			guideUI:forceTouch(event, x, y)
		end

		HintManager.open(guideHintArr[1], nil, , function (event, x, y)
			onHintTouch(event, x, y)
		end, {
			guideIndex
		})
	end
end

function GuideManager.checkGuideBattleLoop()
	if not WarMachine.on then
		Looper.stopLoop(guideBattleHero, GuideManager.checkGuideBattleLoop)

		return
	end

	local skillData = InfoHero.getSkill(guideBattleHero.info)

	if not skillData then
		Looper.stopLoop(guideBattleHero, GuideManager.checkGuideBattleLoop)

		return
	end

	local skillID = skillData.id
	local ready, skillPack, castTarget = GuideManager.checkGuideBattle(skillID)

	if ready then
		Looper.stopLoop(guideBattleHero, GuideManager.checkGuideBattleLoop)
		MapFrameManager.pause("new_guide")

		local monsters = WarMachine.getUnitsByCamp(2)

		for i, monster in ipairs(monsters) do
			monster:setUndeadable(true)
		end

		local heroPos = guideBattleHero.info.pos
		local guideUI = nil

		local function onHintTouch(event, x, y)
			if not guideUI then
				guideUI = GUIDE_cast.new(global.ui)

				global.ui:addChild(guideUI, 120)
				guideUI:initCast(skillID, heroPos, castTarget, function ()
					MapFrameManager.pause("new_guide")
					HintManager.close()
					HintManager.open(guideHintArr[2], function ()
						MapFrameManager.resume("new_guide")

						local monsters = WarMachine.getUnitsByCamp(2)

						for i, monster in ipairs(monsters) do
							monster:setUndeadable(false)
						end

						TaHelper.taGuideDetail(11400)

						if onGuideBattleComplete then
							onGuideBattleComplete()
						end
					end)
				end, function (result)
					HintManager.close()

					if result == 1 then
						HintManager.open(guideHintArr[3])
					else
						HintManager.open(guideHintArr[4])
					end
				end)
			end

			if event == "began" then
				POP_hint.close()
				POP_focus.hide()
			end

			guideUI:forceTouch(event, x, y)
		end

		HintManager.open(guideHintArr[1], nil, , function (event, x, y)
			onHintTouch(event, x, y)
		end)
	end
end

function GuideManager.checkGuideCancelLoop()
	if not WarMachine.on then
		Looper.stopLoop(guideBattleHero, GuideManager.checkGuideCancelLoop)

		return
	end

	local skillData = InfoHero.getSkill(guideBattleHero.info)

	if not skillData then
		Looper.stopLoop(guideBattleHero, GuideManager.checkGuideCancelLoop)

		return
	end

	local skillID = skillData.id
	local ready, skillPack = GuideManager.checkGuideBattle(skillID, true)

	if ready and guideBattleHero:isSkillFree() then
		Looper.stopLoop(guideBattleHero, GuideManager.checkGuideCancelLoop)
		MapFrameManager.pause("new_guide")

		local heroPos = guideBattleHero.info.pos
		local guideUI = nil

		local function onHintTouch(event, x, y)
			if not guideUI then
				guideUI = GUIDE_cast.new(global.ui)

				global.ui:addChild(guideUI, 1000)

				local battleCenter = WarMachine.getCenterPosition()

				guideUI:initCancel(heroPos, battleCenter, function ()
					MapFrameManager.pause("new_guide")
					HintManager.close()
					HintManager.open(guideHintArr[2], function ()
						MapFrameManager.resume("new_guide")

						local monsters = WarMachine.getUnitsByCamp(2)

						for i, monster in ipairs(monsters) do
							monster:setUndeadable(false)
						end

						TaHelper.taGuideDetail(11500)

						if onGuideBattleComplete then
							onGuideBattleComplete()
						end
					end)
				end, function ()
					HintManager.close()
					HintManager.open(guideHintArr[3])
				end)
			end

			if event == "began" then
				POP_hint.close()
				POP_focus.hide()
			end

			guideUI:forceTouch(event, x, y)
		end

		HintManager.open(guideHintArr[1], nil, , function (event, x, y)
			onHintTouch(event, x, y)
		end)
	end
end

function GuideManager.checkGuideItemLoop()
	if WarMachine.on then
		Looper.stopLoop(guideBattleHero, GuideManager.checkGuideItemLoop)

		return
	end

	local hintPointerReplace = DramaManager.getHintReplace()

	if not hintPointerReplace or not hintPointerReplace[1] then
		return
	end

	local reviveQuickIndex = hintPointerReplace[1]
	local itemID = InfoQuickSlots.get(reviveQuickIndex)
	local dieHero = TeamManager.getDieHero()

	if dieHero then
		Looper.stopLoop(guideBattleHero, GuideManager.checkGuideItemLoop)
		MapFrameManager.pause("new_guide")

		local guideUI = nil

		local function onHintTouch(event, x, y)
			if not guideUI then
				guideUI = GUIDE_cast.new(global.ui)

				global.ui:addChild(guideUI, 120)
				guideUI:initItem(itemID, dieHero, function ()
					MapFrameManager.resume("new_guide")
					Looper.setTimeout(function ()
						global.map:tweenFov(global.player.x, global.player.y, 60)
						global.map:tweenToUnit(global.player, 60)
					end, 60)
					Looper.setTimeout(function ()
						HintManager.close()
						HintManager.open(guideHintArr[2], function ()
							if onGuideBattleComplete then
								onGuideBattleComplete()
							end
						end)
					end, 125)
				end, function (result)
					HintManager.close()
					HintManager.open(guideHintArr[3])
				end, true)
			end

			if event == "began" then
				POP_hint.close()
				POP_focus.hide()
			end

			guideUI:forceTouch(event, x, y)
		end

		HintManager.open(guideHintArr[1], nil, , function (event, x, y)
			onHintTouch(event, x, y)
		end, hintPointerReplace)
	end
end

function GuideManager.checkGuideModao(index)
	if global.modao then
		local skillPack = global.modao:getActiveSkill(index)

		if skillPack then
			local fullFrameTime = WarMachine.getFrame()

			if skillPack.cd <= fullFrameTime then
				local skillData = skillPack.data

				if InfoModao.checkMp(skillData.mp) then
					local isReady, castTarget = SkillManager.findAutoSkillTarget(guideBattleHero, skillData, guideBattleHero.battleData.target)

					if isReady then
						return true, skillPack, castTarget
					end
				end
			end
		end
	end

	return false
end

function GuideManager.checkGuideBattle(skillID, isCancel)
	local skillPack = guideBattleHero:getSkillPack(skillID)

	if skillPack then
		local fullFrameTime = WarMachine.getFrame()

		if skillPack.cd <= fullFrameTime and SkillManager.checkPower(skillPack, fullFrameTime) then
			local triggerOK = skillPack.trigger

			if triggerOK then
				if isCancel then
					return true, skillPack
				else
					local skillData = SkillManager.getSkillData(guideBattleHero, skillPack)
					local isReady, castTarget = SkillManager.findAutoSkillTarget(guideBattleHero, skillData, guideBattleHero.battleData.target)

					if isReady then
						return true, skillPack, castTarget
					end
				end
			end
		end
	end

	return false
end

function GuideManager.checkPlayerTile(area)
	local checkMap = {}

	for x = area.x, area.x + area.w - 1 do
		for y = area.y, area.y + area.h - 1 do
			local tile = global.map:getTile(x, y)
			checkMap[tile.tag] = true
		end
	end

	local tile = global.player.tile

	return checkMap[tile.tag]
end

function GuideManager.tryGuideRantile()
	if global.map.mapType ~= Map.TYPE.FIXTILE then
		return
	end

	local markCount = 0
	local teleportArr = {}
	local nextArr = {}

	MapUtils.spreadFind(global.map, global.player.tile, function (tile)
		local events = MapEventManager.getEventsByTile(tile.x, tile.y)

		if events then
			for i, event in ipairs(events) do
				if event.tag == "monster" or event.tag == "shrine" or event.tag == "gather" then
					local eventInfo = InfoDungeon.getEventInfo(event.index)

					if eventInfo.fin == 0 then
						markCount = markCount + 1
					end
				elseif event.tag == "teleport" then
					table.insert(teleportArr, tile)
				elseif event.tag == "go_next" then
					local sortArr = {}

					for _x = tile.x, tile.x + event.w - 1 do
						for _y = tile.y, tile.y + event.h - 1 do
							local _tile = global.map:getTile(_x, _y)

							if _tile then
								local distance = math.sqrt(math.pow(_tile.x - global.player.tile.x, 2) + math.pow(_tile.y - global.player.tile.y, 2))

								table.insert(sortArr, {
									tile = _tile,
									distance = distance
								})
							end
						end
					end

					if #sortArr > 0 then
						table.sort(sortArr, function (a, b)
							return a.distance < b.distance
						end)
						table.insert(nextArr, sortArr[1].tile)
					else
						table.insert(nextArr, tile)
					end
				end
			end
		end

		if tile.unitMap then
			for k, unit in pairs(tile.unitMap) do
				if unit.type == "npc" and unit.npcType == Npc.TYPE.RELIC and not unit:isHidden() then
					markCount = markCount + 1
				end
			end

			for k, unit in pairs(tile.otherMap) do
				if unit.type == "dropItem" then
					markCount = markCount + 1
				end
			end
		end
	end)
	GuideManager.removeGuideMove()

	if #teleportArr > 0 then
		local enterEvent = MapEventManager.getEventByTagOne("enter")

		table.sort(teleportArr, function (a, b)
			local distanceA = math.abs(a.x - enterEvent.x) + math.abs(a.y - enterEvent.y)
			local distanceB = math.abs(b.x - enterEvent.x) + math.abs(b.y - enterEvent.y)

			return distanceA > distanceB
		end)
	end

	if markCount == 0 then
		local targetTile = nextArr[1] or teleportArr[1]

		if targetTile then
			GuideManager.guideMove(targetTile.x, targetTile.y, nil, , , 150)
		end
	end
end

local guideMoveOBj = nil

function GuideManager.guideMove(tileX, tileY, onComplete, area, noRemove, opacity)
	GuideManager.removeGuideMove()

	local mapX, mapY = global.map:tileToMap(tileX, tileY)
	local targetTile = global.map:getTile(tileX, tileY)
	local model = MiscConfig.guide_move_aura_effect
	local checkMap = {}

	if area then
		for x = area.x, area.x + area.w - 1 do
			for y = area.y, area.y + area.h - 1 do
				local tile = global.map:getTile(x, y)
				checkMap[tile.tag] = true
			end
		end
	else
		checkMap[targetTile.tag] = true
	end

	local guideArrowLoop, guideArrow = nil

	if global.player and not empty(model) then
		guideArrow = global.player:addAura(model)

		guideArrow.bmp:setOpacity(0)
		transition.fadeIn(guideArrow.bmp, {
			time = 0.5
		})

		function guideArrowLoop()
			local angle = math.atan2(targetTile.y - global.player.tile.y, targetTile.x - global.player.tile.x)

			if guideArrow.currentAngle then
				guideArrow.currentAngle = (angle - guideArrow.currentAngle) / 5 + guideArrow.currentAngle
			else
				guideArrow.currentAngle = angle
			end

			guideArrow:setRotation(guideArrow.currentAngle * 180 / math.pi - 45)
		end

		guideArrowLoop()
		MapFrameManager.startLoop(guideArrow, guideArrowLoop)
	end

	local pathEffects = {}

	local function refreshPath()
		local newEffects = {}
		local oldEffects = {}
		local pre_NO_UNIT_BLOCK = Map.NO_UNIT_BLOCK
		Map.NO_UNIT_BLOCK = true
		Map.walkOnVislble = false
		local path = global.map:findPath(global.player.tile, targetTile)
		Map.walkOnVislble = true
		Map.NO_UNIT_BLOCK = pre_NO_UNIT_BLOCK
		local preTile = targetTile

		for i, v in ipairs(path) do
			local tile = path[#path - i + 1]

			if i < #path and (i - 1) % 2 == 0 then
				local x, y = global.map:tileToMap(tile)
				local code = tile.x .. "_" .. tile.y

				if pathEffects[code] then
					oldEffects[code] = pathEffects[code]
					pathEffects[code] = nil
				else
					local effect = Unit.new()
					effect.isBlock = false
					effect.alwaysVisible = true

					effect:load("empty")

					effect.zorderOffset = 100

					effect:display(global.map, x, y)

					newEffects[code] = effect
					local effectName = MiscConfig.guide_move_arrow
					local effectScale = 2

					if i == 1 then
						effectName = MiscConfig.guide_move_aim
						effectScale = 1.5
					end

					local guideArrow = effect:addAura(effectName, 100, effectScale, global.map.lowLayer)
					guideArrow.zorderOffset = 100
					guideArrow.syncFrame = true

					guideArrow:setOpacity(opacity or 200)

					local angle = math.atan2(preTile.y - tile.y, preTile.x - tile.x)

					guideArrow:setRotation(angle * 180 / math.pi + 45)
				end

				preTile = tile
			end
		end

		for k, v in pairs(pathEffects) do
			local effect = pathEffects[k]
			pathEffects[k] = nil

			effect:removeSelf()
		end

		for k, v in pairs(oldEffects) do
			pathEffects[k] = v
		end

		for k, v in pairs(newEffects) do
			pathEffects[k] = v
		end
	end

	refreshPath()

	local function checkPlayerTile()
		local tile = global.player.tile

		refreshPath()

		if checkMap[tile.tag] then
			if onComplete then
				onComplete()
			end

			if not noRemove then
				GuideManager.removeGuideMove()
			end
		end
	end

	local handlerID1 = notify.safeRegister(global.player, "player_retile", checkPlayerTile)
	local handlerID2 = nil

	if InfoDungeon.isCamp() then
		handlerID2 = notify.safeRegister(global.player, "drama_freeze", function (freezing)
			if not freezing and not noRemove then
				GuideManager.removeGuideMove()
			end
		end)
	end

	guideMoveOBj = {
		model = model,
		handlerID1 = handlerID1,
		handlerID2 = handlerID2,
		guideArrowLoop = guideArrowLoop,
		guideArrow = guideArrow,
		pathEffects = pathEffects
	}

	checkPlayerTile()
end

function GuideManager.isGuideMove()
	return guideMoveOBj ~= nil
end

function GuideManager.removeGuideMove()
	if guideMoveOBj then
		local model = guideMoveOBj.model
		local handlerID1 = guideMoveOBj.handlerID1
		local handlerID2 = guideMoveOBj.handlerID2
		local guideArrowLoop = guideMoveOBj.guideArrowLoop
		local guideArrow = guideMoveOBj.guideArrow
		local pathEffects = guideMoveOBj.pathEffects

		notify.unregister("player_retile", handlerID1)

		if handlerID2 then
			notify.unregister("drama_freeze", handlerID2)
		end

		if guideArrowLoop then
			MapFrameManager.stopLoop(guideArrow, guideArrowLoop)
			transition.fadeOut(guideArrow.bmp, {
				time = 0.5,
				onComplete = function ()
					global.player:removeAura(model)
				end
			})
		end

		for k, effect in pairs(pathEffects) do
			effect:removeSelf()
		end

		guideMoveOBj = nil
	end
end

local uiGuiding = nil

function GuideManager.uiGuide(guideStr)
	local guideArr = string.split(guideStr, ";")
	local index = 1
	local doNext = nil

	function doNext()
		local breakCount = 60
		local findLoop = nil

		function findLoop()
			local pairStr = guideArr[index]
			local pairArr = string.split(pairStr, "|")
			local uiStr = pairArr[1]
			local hintText = pairArr[2]
			local component = UIManager.findComponent(uiStr)

			if component then
				POP_focus.openOnNode(component, 200, nil, function ()
					index = index + 1

					if index <= #guideArr then
						doNext()
					end
				end)

				if not empty(hintText) then
					POP_hint.openOnNode(component, hintText)
				end

				Looper.stopLoop(GuideManager, findLoop)

				uiGuiding = nil
			else
				breakCount = breakCount - 1

				if breakCount <= 0 then
					Looper.stopLoop(GuideManager, findLoop)

					uiGuiding = nil
				end
			end
		end

		Looper.startLoop(GuideManager, findLoop)
	end

	uiGuiding = true

	doNext()
end

function GuideManager.isUiGuide()
	return uiGuiding
end

local guideLoopCount = nil
local guideLoopCountMax = 10
local guideCSV = nil

function GuideManager.goPointNpc(guideCSV, onGuideMoveComplete)
	local tile, area = nil

	if guideCSV.point_type == 3 or guideCSV.point_type == 4 then
		local pointArr = string.split(guideCSV.point_value, ",")
		local tileX = tonumber(pointArr[1])
		local tileY = tonumber(pointArr[2])
		tile = global.map:getTile(tileX, tileY)
		area = {
			w = 1,
			h = 1,
			x = tileX,
			y = tileY
		}
	else
		local npcID = guideCSV.point_value

		if guideCSV.point_type == 5 then
			npcID = CampUtils.findBuldingNpc(guideCSV.point_value)
		elseif guideCSV.point_type == 1 then
			npcID = CampUtils.findBuldingNpc(InfoBuilding.TAG.ABYSS) or npcID
		end

		if empty(npcID) then
			return
		end

		local mapX, mapY = CampUtils.getNpcGo(npcID)

		if not mapX then
			return
		end

		local npcTile = global.map:mapToTile(mapX, mapY)
		local path = MapUtils.getPathClose(mapX, mapY)
		tile = path[#path]
		area = {
			w = 3,
			h = 3,
			x = npcTile.x - 1,
			y = npcTile.y - 1
		}
	end

	GuideManager.guideMove(tile.x, tile.y, onGuideMoveComplete, area, true)

	return area
end

local changeHeroStep = 0

function GuideManager.startChangeHero(csv)
	guideLoopCount = 0
	guideCSV = csv
	changeHeroStep = 0

	Looper.startLoop(GuideManager, GuideManager.changeHeroLoop)
end

function GuideManager.stopChangeHero()
	Looper.stopLoop(GuideManager, GuideManager.changeHeroLoop)
end

function GuideManager.changeHeroLoop(obj, frame, passed, sharp, isFirst)
	if HintManager.opening then
		return
	end

	if DramaManager.opening then
		return
	end

	local class = guideCSV.change_hero

	if guideLoopCount <= 0 then
		local moveGuiding = false
		guideLoopCount = guideLoopCountMax
		local inTeamHero = InfoHero.findGuideHero(class, 2, true)

		if inTeamHero then
			TaHelper.taGuideDetail(13200)
			GuideManager.fingerDragStop()

			local oldHero = InfoHero.findGuideHero(class, 1, false)

			if oldHero then
				local ui = UIManager.findComponent("frame_team.bg")

				if ui then
					if changeHeroStep ~= 3 then
						changeHeroStep = 3

						PopManager.closeBefore(ui.uiLayout)

						local pointerReplace = {}
						local heroArr = FRAME_team.getHeroList()

						for i, v in ipairs(heroArr) do
							if v.id == oldHero.id then
								pointerReplace[1] = i

								break
							end
						end

						HintManager.open(guideCSV.hint_3, function ()
						end, nil, , pointerReplace)
					end
				else
					PopManager.closeAll()
					HintManager.open(guideCSV.hint_1, function ()
						changeHeroStep = 0
					end)
				end
			else
				local bagItems = InfoItem.getWareList(3)
				local exp, expUpg, level, maxLevel = InfoHero.getExp(inTeamHero)
				local foodID = 300401
				local foodIndex = nil

				if #bagItems > 0 then
					for i, v in ipairs(bagItems) do
						print("$$$ v.info.base_id==foodID", v.info.base_id, foodID, v.info.base_id == foodID)

						if v.info.base_id == foodID then
							foodIndex = i

							break
						end
					end
				end

				if foodIndex and level < maxLevel then
					local ui = UIManager.findComponent("frame_team.bg")

					if ui then
						if changeHeroStep ~= 4 then
							changeHeroStep = 4

							PopManager.closeBefore(ui.uiLayout)

							local pointerReplace = {
								inTeamHero.pos,
								foodIndex
							}

							HintManager.open(guideCSV.hint_4, function ()
							end, nil, , pointerReplace)
						end
					else
						PopManager.closeAll()
						HintManager.open(guideCSV.hint_1, function ()
							changeHeroStep = 0
						end)
					end
				else
					TaHelper.taGuideDetail(13400)

					local bagItems = {}
					local currentEquip1 = InfoEquip.getEquipOnHero(inTeamHero, 1)

					if not currentEquip1 then
						local function filterFunc(data)
							if data.type == DropManager.TYPE.EQUIP then
								local equipCSV = CsvParser.getCsvData("equip", data.info.base_id)

								if equipCSV.equip_pos <= 4 then
									local currentEquip = InfoEquip.getEquipOnHero(inTeamHero, equipCSV.equip_pos)

									if currentEquip then
										return false
									end

									local checkOK = InfoEquip.checkEquipForHero(inTeamHero, data.info)

									return checkOK
								else
									return false
								end
							end
						end

						bagItems = InfoEquip.getWareList(filterFunc)
					end

					if #bagItems > 0 then
						local ui = UIManager.findComponent("frame_team.bg")

						if ui then
							if changeHeroStep ~= 5 then
								changeHeroStep = 5

								PopManager.closeBefore(ui.uiLayout)

								local pointerReplace = {
									inTeamHero.pos
								}

								HintManager.open(guideCSV.hint_5, function ()
								end, nil, , pointerReplace)
							end
						else
							PopManager.closeAll()
							HintManager.open(guideCSV.hint_1, function ()
								changeHeroStep = 0
							end)
						end
					else
						local guideID = InfoGuide.getCurrent()

						InfoGuide.finish(guideCSV.id, function ()
							GuideManager.stopChangeHero()
							PopManager.closeAll()
							HintManager.open(guideCSV.hint_6, function ()
							end)
						end)
					end
				end
			end
		else
			local outTeamHero = InfoHero.findGuideHero(class, 2, false)

			if outTeamHero then
				local ui = UIManager.findComponent("frame_team.bg")

				if ui then
					local pointerReplace = {}
					local heroArr = FRAME_team.getHeroList()

					for i, v in ipairs(heroArr) do
						if v.id == outTeamHero.id then
							pointerReplace[1] = i

							break
						end
					end

					local oldHero = InfoHero.findGuideHero(class, 1, true)

					if oldHero then
						pointerReplace[2] = oldHero.pos
					end

					if changeHeroStep ~= 2 then
						changeHeroStep = 2

						ui.uiLayout:setGuide()
						PopManager.closeBefore(ui.uiLayout)
						HintManager.open(guideCSV.hint_2, function ()
							GuideManager.fingerDrag(guideCSV.hint_2)
						end, nil, , pointerReplace)
					end
				else
					GuideManager.fingerDragStop()
					PopManager.closeAll()
					HintManager.open(guideCSV.hint_1, function ()
						changeHeroStep = 0
					end)
				end
			end
		end

		if not moveGuiding then
			GuideManager.removeGuideMove()
		end

		return
	end

	guideLoopCount = guideLoopCount - passed
end

local onEasyComplete = nil

function GuideManager.startEasy(csv, onComplete)
	dump(csv, "$$$ startEasy")

	guideLoopCount = 0
	guideCSV = csv
	onEasyComplete = onComplete

	Looper.startLoop(GuideManager, GuideManager.easyLoop)
end

function GuideManager.stopEasy()
	Looper.stopLoop(GuideManager, GuideManager.easyLoop)
end

function GuideManager.easyLoop(obj, frame, passed, sharp, isFirst)
	if HintManager.opening then
		return
	end

	if DramaManager.opening then
		return
	end

	if not PopManager.isPopClear() then
		return
	end

	if guideLoopCount <= 0 then
		guideLoopCount = guideLoopCountMax

		HintManager.open(guideCSV.hint_1, function ()
			if guideCSV.fin_type == 1 then
				InfoGuide.finish(guideCSV.id)
			end

			if onEasyComplete then
				onEasyComplete()
			end
		end, nil, , DramaManager.getHintReplace())
		GuideManager.stopEasy()
	else
		guideLoopCount = guideLoopCount - passed
	end
end

function GuideManager.startBuilding(csv, onComplete)
	guideLoopCount = 0
	guideCSV = csv
	onEasyComplete = onComplete

	if csv.point_type == 4 and global.player then
		global.player:setNpcNavDisabled(true)
	end

	Looper.startLoop(GuideManager, GuideManager.buildingLoop)
end

function GuideManager.stopBuilding()
	Looper.stopLoop(GuideManager, GuideManager.buildingLoop)
end

function GuideManager.buildingLoop(obj, frame, passed, sharp, isFirst)
	if HintManager.opening then
		return
	end

	if DramaManager.opening then
		return
	end

	if not PopManager.isPopClear() then
		return
	end

	if guideLoopCount <= 0 then
		guideLoopCount = guideLoopCountMax

		local function onGuideMoveComplete()
			global.player:stop()

			if global.ui and global.ui.stopControl then
				global.ui:stopControl()
			end

			HintManager.open(guideCSV.hint_1, function ()
				if onEasyComplete then
					onEasyComplete()
				end
			end)
			GuideManager.stopBuilding()

			if guideCSV.point_type == 4 and global.player then
				global.player:setNpcNavDisabled(false)
			end
		end

		if not GuideManager.isGuideMove() then
			GuideManager.goPointNpc(guideCSV, onGuideMoveComplete)
		end
	else
		guideLoopCount = guideLoopCount - passed
	end
end

function GuideManager.startEquipEnhance(csv)
	guideLoopCount = 0
	guideCSV = csv

	Looper.startLoop(GuideManager, GuideManager.equipEnhanceLoop)
end

function GuideManager.stopEquipEnhance()
	Looper.stopLoop(GuideManager, GuideManager.equipEnhanceLoop)
end

function GuideManager.equipEnhanceLoop(obj, frame, passed, sharp, isFirst)
	if HintManager.opening then
		return
	end

	if DramaManager.opening then
		return
	end

	if guideLoopCount <= 0 then
		guideLoopCount = guideLoopCountMax

		local function onGuideMoveComplete()
			global.player:stop()

			if global.ui and global.ui.stopControl then
				global.ui:stopControl()
			end

			local pointerReplace = {}
			local equips = InfoEquip.getEnhanceList()
			local equipIndex = 1
			local equipID = nil

			for i, item in ipairs(equips) do
				if item.type == DropManager.TYPE.EQUIP then
					equipID = item.info.id

					break
				else
					equipIndex = equipIndex + 1
				end
			end

			local stoneIndex = 1

			for i, item in ipairs(equips) do
				if item.type == DropManager.TYPE.EQUIP then
					if equipID ~= item.info.id then
						stoneIndex = stoneIndex + 1
					end
				elseif item.type == DropManager.TYPE.ITEM then
					break
				end
			end

			pointerReplace[1] = equipIndex
			pointerReplace[2] = stoneIndex

			print("$$$ equipIndex", equipIndex, stoneIndex)
			HintManager.open(guideCSV.hint_1, function ()
			end, nil, , pointerReplace)
			GuideManager.stopEquipEnhance()
		end

		if not GuideManager.isGuideMove() then
			GuideManager.goPointNpc(guideCSV, onGuideMoveComplete)
		end
	else
		guideLoopCount = guideLoopCount - passed
	end
end

function GuideManager.startHeroTransfer(csv)
	guideLoopCount = 0
	guideCSV = csv

	Looper.startLoop(GuideManager, GuideManager.heroTransferLoop)
end

function GuideManager.stopHeroTransfer()
	Looper.stopLoop(GuideManager, GuideManager.heroTransferLoop)
end

function GuideManager.heroTransferLoop(obj, frame, passed, sharp, isFirst)
	if HintManager.opening then
		return
	end

	if DramaManager.opening then
		return
	end

	if not PopManager.isPopClear() then
		return
	end

	if guideLoopCount <= 0 then
		guideLoopCount = guideLoopCountMax

		local function onGuideMoveComplete()
			global.player:stop()

			if global.ui and global.ui.stopControl then
				global.ui:stopControl()
			end

			local pointerReplace = {
				1
			}
			local heroReady = FRAME_hero_transfer.getHeroReady()

			for i, heroInfo in ipairs(heroReady) do
				if heroInfo.quality >= 2 then
					local heroData = CsvParser.getCsvData("hero", heroInfo.base_id)
					local level = heroInfo.level
					local need_level = heroData.lv_max

					if need_level <= level then
						pointerReplace[1] = i

						break
					end
				end
			end

			HintManager.open(guideCSV.hint_1, function ()
			end, nil, , pointerReplace)
			GuideManager.stopHeroTransfer()
		end

		if not GuideManager.isGuideMove() then
			GuideManager.goPointNpc(guideCSV, onGuideMoveComplete)
		end
	else
		guideLoopCount = guideLoopCount - passed
	end
end

function GuideManager.startMirror(csv)
	guideLoopCount = 0
	guideCSV = csv

	Looper.startLoop(GuideManager, GuideManager.mirrorLoop)
end

function GuideManager.stopMirror()
	Looper.stopLoop(GuideManager, GuideManager.mirrorLoop)
end

function GuideManager.mirrorLoop(obj, frame, passed, sharp, isFirst)
	if HintManager.opening then
		return
	end

	if DramaManager.opening then
		return
	end

	if guideLoopCount <= 0 then
		guideLoopCount = guideLoopCountMax

		local function onGuideMoveComplete()
			local function stopPlayer()
				global.player:stop()

				if global.ui and global.ui.stopControl then
					global.ui:stopControl()
				end
			end

			local checkNext = nil

			function checkNext()
				local items = InfoMirror.getList()
				local index = nil

				for i, data in ipairs(items) do
					local level = InfoMirror.getLevel(data.type)

					if level == 0 then
						index = i

						break
					end
				end

				if not index or index > 4 then
					GuideManager.stopMirror()

					return
				end

				local ui = UIManager.findComponent("frame_mirror.bg")

				if ui then
					ui.uiLayout:setGuide()
					stopPlayer()
					HintManager.open(guideCSV["hint_" .. index + 1], function ()
						global.player:performWithDelay(checkNext, 0.2)
					end)
				else
					stopPlayer()
					HintManager.open(guideCSV.hint_1, function ()
						global.player:performWithDelay(checkNext, 0.5)
					end)
				end
			end

			checkNext()
		end

		if not GuideManager.isGuideMove() then
			GuideManager.goPointNpc(guideCSV, onGuideMoveComplete)
		end
	else
		guideLoopCount = guideLoopCount - passed
	end
end

function GuideManager.startCardOn(csv)
	guideLoopCount = 0
	guideCSV = csv

	Looper.startLoop(GuideManager, GuideManager.cardOnLoop)
end

function GuideManager.stopCardOn()
	Looper.stopLoop(GuideManager, GuideManager.cardOnLoop)
end

function GuideManager.cardOnLoop(obj, frame, passed, sharp, isFirst)
	if HintManager.opening then
		return
	end

	if DramaManager.opening then
		return
	end

	if not PopManager.isPopClear() then
		return
	end

	if guideLoopCount <= 0 then
		guideLoopCount = guideLoopCountMax
		local pointerReplace = {
			1
		}
		local heroReady = FRAME_hero_transfer.getHeroReady()

		for i, heroInfo in ipairs(heroReady) do
			if heroInfo.quality >= 2 then
				local heroData = CsvParser.getCsvData("hero", heroInfo.base_id)

				if heroData.job_level >= 0 then
					pointerReplace[1] = i

					break
				end
			end
		end

		local function onHintComplete()
			GuideManager.fingerDrag(guideCSV.hint_1, 4)
		end

		HintManager.open(guideCSV.hint_1, onHintComplete, nil, , pointerReplace)
		GuideManager.stopCardOn()
	else
		guideLoopCount = guideLoopCount - passed
	end
end

local wildStep = nil

function GuideManager.startWild(csv)
	guideLoopCount = 0
	guideCSV = csv
	wildStep = 0

	Looper.startLoop(GuideManager, GuideManager.wildLoop)
end

function GuideManager.stopWild()
	Looper.stopLoop(GuideManager, GuideManager.wildLoop)
end

function GuideManager.wildLoop(obj, frame, passed, sharp, isFirst)
	if HintManager.opening then
		return
	end

	if DramaManager.opening then
		return
	end

	if guideLoopCount <= 0 then
		local ui = FRAME_wild.ui

		if not ui then
			if not PopManager.isPopClear() then
				return
			end

			if wildStep == 0 then
				HintManager.open(guideCSV.hint_1, function ()
					wildStep = 1
				end)
			end
		else
			local map = ui.map

			if wildStep == 0 then
				wildStep = 1
			end

			if wildStep == 1 then
				HintManager.open(guideCSV.hint_2, function ()
					wildStep = 2
				end)
			elseif wildStep == 2 then
				local tagData = map:getIconData("wood_1")

				ui:onSpotTap(tagData)
				HintManager.open(guideCSV.hint_3, function ()
					wildStep = 3
				end)
				GuideManager.stopWild()
			end
		end
	else
		guideLoopCount = guideLoopCount - passed
	end
end

function GuideManager.free20()
	local guideID = 20

	if InfoGuide.getFreeRecord(guideID) > 0 then
		return
	end

	local guideCSV = CsvParser.getCsvData("guide_free", guideID)
	local team = InfoHero.getTeam()
	local heroIndex = nil

	for i, heroInfo in ipairs(team) do
		local function filterFunc(data)
			if data.type == DropManager.TYPE.EQUIP then
				local equipCSV = CsvParser.getCsvData("equip", data.info.base_id)

				if equipCSV.equip_pos <= 4 then
					local currentEquip = InfoEquip.getEquipOnHero(heroInfo, equipCSV.equip_pos)

					if currentEquip then
						return false
					end

					local checkOK = InfoEquip.checkEquipForHero(heroInfo, data.info)

					return checkOK
				else
					return false
				end
			end
		end

		local bagItems = InfoBag.getAll(filterFunc)

		if #bagItems > 0 then
			heroIndex = i

			break
		end
	end

	if heroIndex then
		local pointerReplace = {
			heroIndex
		}

		HintManager.open(guideCSV.hint_1, function ()
			InfoGuide.finishFree(guideID)
		end, nil, , pointerReplace)
	end
end

function GuideManager.free28()
	local dieHero = TeamManager.getDieHero()

	if dieHero then
		local function filterFunc(data)
			if data.type == DropManager.TYPE.ITEM then
				local itemData = CsvParser.getCsvData("item", data.info.base_id)

				return itemData.use_type == 7
			end
		end

		local bagItems = InfoBag.getAll(filterFunc)

		if #bagItems > 0 then
			local reviveItem = bagItems[1].info.base_id
			local reviveQuickIndex = InfoQuickSlots.findItem(reviveItem)

			local function filterFunc(data)
				if data.type == DropManager.TYPE.ITEM then
					local itemData = CsvParser.getCsvData("item", data.info.base_id)

					return itemData.use_type == 1
				end
			end

			local bagItems = InfoBag.getAll(filterFunc)

			if #bagItems > 0 then
				local healItem = bagItems[1].info.base_id
				local healQuickIndex = InfoQuickSlots.findItem(healItem)

				print("$$$ free28", dieHero, reviveQuickIndex, healQuickIndex)
				DramaManager.presetUnit(dieHero)
				DramaManager.presetHintReplace({
					reviveQuickIndex,
					healQuickIndex
				})
				InfoGuide.triggerFree(28)
			end
		end
	end
end

local fingerMoveGuideUI = nil

function GuideManager.fingerMove()
	if fingerMoveGuideUI then
		fingerMoveGuideUI:removeSelf()

		fingerMoveGuideUI = nil
	end

	local guideUI = GUIDE_finger.new()

	global.ui:addChild(guideUI, LayerConfig.finger)
	guideUI:startMove()

	fingerMoveGuideUI = guideUI
end

function GuideManager.fingerMoveStop()
	if fingerMoveGuideUI then
		fingerMoveGuideUI:removeSelf()

		fingerMoveGuideUI = nil
	end
end

local fingerMoveGuideUI = nil

function GuideManager.fingerMove()
	if fingerMoveGuideUI then
		fingerMoveGuideUI:removeSelf()

		fingerMoveGuideUI = nil
	end

	local guideUI = GUIDE_finger.new()

	global.ui:addChild(guideUI, LayerConfig.finger)
	guideUI:startMove()

	fingerMoveGuideUI = guideUI
end

function GuideManager.fingerMoveStop()
	if fingerMoveGuideUI then
		fingerMoveGuideUI:removeSelf()

		fingerMoveGuideUI = nil
	end
end

local fingerDragGuideUI = nil

function GuideManager.fingerDrag(hintID, hintIndex)
	if fingerDragGuideUI then
		fingerDragGuideUI:removeSelf()

		fingerDragGuideUI = nil
	end

	hintIndex = hintIndex or 1
	local index = 1
	local csvArr = {}
	local csv = CsvParser.getCsvData("hint", hintID)

	while #csvArr < 2 do
		if hintIndex <= index then
			table.insert(csvArr, csv)
		end

		if empty(csv.next) then
			break
		end

		csv = CsvParser.getCsvData("hint", csv.next)
		index = index + 1
	end

	if #csvArr < 2 then
		return
	end

	local hintCSV = CsvParser.getCsvData("hint", hintID)
	local nextCSV = CsvParser.getCsvData("hint", hintCSV.next)
	local guideUI = GUIDE_finger.new()

	display.getRunningScene():addChild(guideUI, LayerConfig.finger)

	local uiStr1 = csvArr[1].ui_pointer
	local uiStr2 = csvArr[2].ui_pointer

	if HintManager.pointerReplace then
		uiStr1 = StringUtil.replace(uiStr1, unpack(HintManager.pointerReplace))
		uiStr2 = StringUtil.replace(uiStr2, unpack(HintManager.pointerReplace))
	end

	guideUI:startDrag(uiStr1, uiStr2)

	fingerDragGuideUI = guideUI
end

function GuideManager.fingerDragUI(uiStr1, uiStr2, loop)
	local guideUI = GUIDE_finger.new()

	display.getRunningScene():addChild(guideUI, LayerConfig.finger)
	guideUI:startDrag(uiStr1, uiStr2, loop)

	fingerDragGuideUI = guideUI
end

function GuideManager.fingerDragStop()
	if fingerDragGuideUI then
		fingerDragGuideUI:removeSelf()

		fingerDragGuideUI = nil
	end
end

function GuideManager.clear()
	guideMoveOBj = nil
	fingerMoveGuideUI = nil
	fingerDragGuideUI = nil
end

return GuideManager
