local s2c = [[
    
heartbeat 1 {
	request {
		time 0 : integer
	}
}


#登陆验证
auth_ready 101 {
	request {
		dev_mode 0 : integer
		server_id 2 : integer
		need_active 3 : integer
		pay_open 4 : integer
		currency 5 : string
		fixed_currency 6 : string
	}
}

#登陆验证成功
auth_ok 102 {}

#加载模块成功
load_ok 103 {}

#同步玩家信息
user_sync 110 {
	request {
		nickname 1 : string
		nicklang 2 : string
		head 5 : integer
		head_frame 6 : integer
		mute_time 7 : integer
		mute_type 8 : integer     # 1 手动（解）禁  2自动（解）禁
		credit_100 9 : integer
		ban_credit 10 : integer
	}
}

#被踢
user_kick 111 {
	request {
		reason 0 : string
		ban_type 1 : integer
	}
}

#充值代金券
user_credit 112 {
	request {
		amount_100 0 : integer
	}
}


#佣兵数据同步
hero_sync 201 {
	request {
		list 0 : *HeroData
	}
}

#佣兵移除
hero_sync_remove 202 {
	request {
		list 0 : *integer
	}
}

#佣兵经验值增加
hero_add_exp 203 {
	request {
		id 0 : integer
		exp_add 1 : integer
		pre_level 2 : integer
		level 3 : integer
		max_type 4 : integer
	}
}

#佣兵掉落
hero_drop_random 204 {
	request {
		id 0 : integer
	}
}






#道具数据同步
item_sync 301 {
	request {
		list 0 : *ItemData
	}
}

#道具移除
item_sync_remove 302 {
	request {
		list 0 : *integer
	}
}


#装备数据同步
equip_sync 401 {
	request {
		list 0 : *EquipData
	}
}

#装备移除
equip_sync_remove 402 {
	request {
		list 0 : *integer
	}
}


#佣兵血量同步
dungeon_sync_hero_hp 601 {
	request {
		hero_hp_1 0 : integer
		hero_hp_2 1 : integer
		hero_hp_3 2 : integer
		hero_hp_lose_1 3 : integer
		hero_hp_lose_2 4 : integer
		hero_hp_lose_3 5 : integer
		modao_mp 6 : integer
		modao_max 7 : integer
	}
}

#佣兵血量同步（陷阱）
dungeon_trap_hp 602 {
	request {
		hero_hp_1 0 : integer
		hero_hp_2 1 : integer
		hero_hp_3 2 : integer
		hero_hp_lose_1 3 : integer
		hero_hp_lose_2 4 : integer
		hero_hp_lose_3 5 : integer
	}
}

#副本事件完成
dungeon_event_fin 603 {
	request {
		.EventData {
			index 0 : integer
			fin 1 : integer
		}
		list 0 : *EventData
	}
}

#副本加速耗尽
dungeon_clear_speedup 604 {
	request {

	}
}

#副本成为安全层
dungeon_layer_safe 605 {
	request {
		layer_safe 0 : integer
	}
}

#更新副本最大层和等级
dungeon_abyss_max_layer 606 {
	request {
		abyss_max_layer 0 : integer
		abyss_max_level 1 : integer
	}
}

#副本神龛同步
dungeon_shrine_sync 607 {
	request {
		shrine 0 : *ShrineData
	}
}

#更新潜行状态
dungeon_sneak_sync 608 {
	request {
		sneak_point 0 : integer
		sneak_buff_id 1 : integer
		sneak_buff_time 2 : integer
	}
}

#同步战利品完成
dungeon_relic_fin 609 {
	request {
		map_index 0 : integer
		event_index 1 : integer
		relic_index 2 : integer
	}
}

#战利品添加
dungeon_relic_add 610 {
	request {
		map_index 0 : integer
		event_index 1 : integer
		relic 2 : RelicData
	}
}

#重进副本
dungeon_reload 611 {
	request {
		reason 0 : string
	}
}

#地城通用同步
dungeon_sync 612 {
	request {
		autopick_time 0 : integer
	}
}




#看板任务同步
quest_sync 701 {
	request {
		list 0 : *QuestData
	}
}

#看板任务移除
quest_sync_remove 702 {
	request {
		list 0 : *integer
	}
}




#酒馆同步
tavern_sync 801 {
	request {
		list 0 : *TavernHeroData
		refresh_time 1 : integer
		refresh_count 2 : integer
		refresh_count_time 3 : integer
		count 4 : integer
		target_quality 5 : integer
	}
}




#背包同步
bag_sync 901 {
	request {
		list 0 : *BagData
	}
}

#背包移除
bag_sync_remove 902 {
	request {
		.BagIndexData {
			bag_index 0 : integer
		}
		list 0 : *BagIndexData
	}
}


#看板同步
kanban_sync 1001 {
	request {
		refresh_time 0 : integer
		refresh_count 1 : integer
		refresh_count_time 2 : integer
		level 3 : integer
		points 4 : integer
		act_count 5 : integer
		act_time 6 : integer
		reward_record 7 : integer
		target_reward_time 8 : integer
	}
}


#建筑同步
building_sync 1101 {
	request {
		list 0 : *BuildingData
	}
}

#建筑插件同步
building_plus_push 1102 {
	request {
		tag 0 : integer
		index 1 : integer
		item_id 2 : integer
		pre_item_id 3 : integer
	}
}


#魔晶炉同步
furnace_sync 1201 {
	request {
		cash 0 : integer
		cash_time 1 : integer
		mine_num 2 : integer
		record_1 3 : integer
		record_2 4 : integer
		record_3 5 : integer
		record_4 6 : integer
		record_5 7 : integer
		record_6 8 : integer
		record_7 9 : integer
		record_8 10 : integer
		record_9 11 : integer
		record_10 12 : integer
	}
}


#商店同步
shop_sync 1301 {
	request {
		refresh_time_1 0 : integer
		refresh_count_1 1 : integer
		refresh_count_time_1 2 : integer
		refresh_time_2 3 : integer
		refresh_count_2 4 : integer
		refresh_count_time_2 5 : integer
		opening_3 6 : integer
	}
}



#魔导技同步
modao_sync 1401 {
	request {
		.ModaoData {
			base_id 0 : integer
			level 1 : integer
			pos 2 : integer
		}
		list 0 : *ModaoData
	}
}


#怪物卡同步
card_sync 1501 {
	request {
		list 0 : *CardData
	}
}

#怪物卡移除
card_sync_remove 1502 {
	request {
		list 0 : *integer
	}
}

#邮件同步
mail_sync 1601 {
	request {
		list 0 : *MailData
	}
}

#宠物孵化同步
pet_hatch_sync 1701 {
	request {
		list 0 : *PetHatchData
	}
}


#宠物同步
pet_sync 1801 {
	request {
		list 0 : *PetData
	}
}

#宠物移除
pet_sync_remove 1802 {
	request {
		list 0 : *integer
	}
}

#宠物经验增加
pet_add_exp 1803 {
	request {
		id 0 : integer
		exp_add 1 : integer
		pre_level 2 : integer
		level 3 : integer
		max_type 4 : integer
	}
}

#宠物诞生
pet_born 1804 {
	request {
		id 1 : integer
	}
}




#引导同步
guide_sync 1901 {
	request {
		guide_id 0 : integer
		free_1 1 : integer
		free_2 2 : integer
		free_3 3 : integer
		free_4 4 : integer
		free_5 5 : integer
		pet_state 6 : integer
		pet_time 7 : integer
	}
}

#快捷道具栏同步
quick_slots_sync 2001 {
	request {
		slot_1 0 : integer
		slot_2 1 : integer
		slot_3 2 : integer
		slot_4 3 : integer
		pet_index 4 : integer
		rune_1 5 : integer
		rune_2 6 : integer
		rune_3 7 : integer
		rune_4 8 : integer
	}
}

#采集品同步
gather_sync 2101 {
	request {
		list 0 : *GatherData
	}
}

#支付信息同步
order_sync 2301 {
	request {
		first_1 0 : integer
		first_2 1 : integer
		first_3 2 : integer
		first_4 3 : integer
		first_5 4 : integer
		first_6 5 : integer
		mooncard_day 6 : integer
		mooncard_zuan_day 7 : integer
		seasoncard_day 8 : integer
		total_pay_100 9 : integer
		first_pay_time 10 : integer
		last_pay_time 11 : integer
		daily_order_time 12 : integer
		daily_order_reward_time 13 : integer
		gift_record 14 : integer
		free_gacha_day 15 : integer
		safe_return_used 16 : integer
		safe_return_day 17 : integer
		once_1 18 : integer
		once_2 19 : integer
		once_3 20 : integer
		once_4 21 : integer
		once_5 22 : integer
		once_6 23 : integer
		daily_1 24 : integer
		daily_2 25 : integer
		daily_3 26 : integer
		daily_4 27 : integer
		daily_5 28 : integer
		daily_6 29 : integer
		daily_level 30 : integer
		daily_level_time 31 : integer
	}
}

#支付完成
order_done 2302 {
	request {
		rewards 0 : *RewardData
		purchase_id 1 : string
		token 2 : string
		order_id 3 : string
		amount_100 4 : integer
		currency 5 : string
		goods_id 6 : string
		mygift_id 7 : integer
	}
}

#主线同步
mission_sync 2401 {
	request {
		record_1 1 : integer
		record_2 2 : integer
		record_3 3 : integer
		record_4 4 : integer
		record_5 5 : integer
		record_6 6 : integer
		record_7 7 : integer
		record_8 8 : integer
		record_9 9 : integer
		record_10 10 : integer

		record_11 11 : integer
		record_12 12 : integer
		record_13 13 : integer
		record_14 14 : integer
		record_15 15 : integer
		record_16 16 : integer
		record_17 17 : integer
		record_18 18 : integer
		record_19 19 : integer
		record_20 20 : integer

		record_21 21 : integer
		record_22 22 : integer
		record_23 23 : integer
		record_24 24 : integer
		record_25 25 : integer
		record_26 26 : integer
		record_27 27 : integer
		record_28 28 : integer
		record_29 29 : integer
		record_30 30 : integer

		record_31 31 : integer
		record_32 32 : integer
		record_33 33 : integer
		record_34 34 : integer
		record_35 35 : integer
		record_36 36 : integer
		record_37 37 : integer
		record_38 38 : integer
		record_39 39 : integer
		record_40 40 : integer

		record_41 41 : integer
		record_42 42 : integer
		record_43 43 : integer
		record_44 44 : integer
		record_45 45 : integer
		record_46 46 : integer
		record_47 47 : integer
		record_48 48 : integer
		record_49 49 : integer
		record_50 50 : integer

		record_51 51 : integer
		record_52 52 : integer
		record_53 53 : integer
		record_54 54 : integer
		record_55 55 : integer
		record_56 56 : integer
		record_57 57 : integer
		record_58 58 : integer
		record_59 59 : integer
		record_60 60 : integer

		record_61 61 : integer
		record_62 62 : integer
		record_63 63 : integer
		record_64 64 : integer
		record_65 65 : integer
		record_66 66 : integer
		record_67 67 : integer
		record_68 68 : integer
		record_69 69 : integer
		record_70 70 : integer

		record_71 71 : integer
		record_72 72 : integer
		record_73 73 : integer
		record_74 74 : integer
		record_75 75 : integer
		record_76 76 : integer
		record_77 77 : integer
		record_78 78 : integer
		record_79 79 : integer
		record_80 80 : integer

		record_81 81 : integer
		record_82 82 : integer
		record_83 83 : integer
		record_84 84 : integer
		record_85 85 : integer
		record_86 86 : integer
		record_87 87 : integer
		record_88 88 : integer
		record_89 89 : integer
		record_90 90 : integer

		record_91 91 : integer
		record_92 92 : integer
		record_93 93 : integer
		record_94 94 : integer
		record_95 95 : integer
		record_96 96 : integer
		record_97 97 : integer
		record_98 98 : integer
		record_99 99 : integer
		record_100 100 : integer
	}
}


#npc任务同步
task_quest_sync 2501 {
	request {
		list 0 : *TaskQuestData
	}
}

#npc任务移除
task_quest_sync_remove 2502 {
	request {
		list 0 : *integer
	}
}

#调律同步
mirror_sync 2701 {
	request {
		list 0 : *MirrorData
	}
}

#功能开启同步
function_sync 2801 {
	request {
		list 0 : *FunctionData
	}
}


#派遣同步
travel_sync 2901 {
	request {
		list 0 : *TravelData
		hour_used 1 : integer
		refresh_time 2 : integer
	}
}



#竞技场同步
arena_sync 3001 {
	request {
		season_id 0 : integer
		season_time 1 : integer
		actived 2 : integer

		season 10 : integer
		season_battle 11 : integer
		points 12 : integer
		score 13 : integer
		combo 14 : integer
		combo_season 15 : integer
		battle_index_start 16 : integer
		battle_index_over 17 : integer
		vs_points 18 : integer

		refresh_time 20 : integer
		refresh_count 21 : integer
		refresh_count_time 22 : integer
		battle_count 23 : integer
		battle_time 24 : integer
		reward_already 25 : integer
		reward_time 26 : integer
		week_reward_already 27 : integer
		week_reward_time 28 : integer
		battle_buy_count 29 : integer
		battle_buy_time 30 : integer

		shop_refresh_time 31 : integer
		ranking_level 32 : integer  					# 1,2,3 对应 a,b,c 三个档次的排行榜
		max_ranking_level 33 : integer
	}
}





#成就同步
achieve_sync 3201 {
	request {
		list 0 : *AchieveData
	}
}

#（失效）
invest_sync 3301 {
	request {
	
		star1 1 : integer
		star2 2 : integer
		star3 3 : integer
		reward1_time 4 : integer
		reward2_time 5 : integer
		reward3_time 6 : integer
		reward1_already 7 : integer
		reward2_already 8 : integer
		reward3_already 9 : integer

		.Record {
			invest_id 0 : integer
			life_left 1 : integer
		}
		record 10 : *Record

	}
}


#签到同步
record_fest_sync 3401 {
	request {
		.RecordFest {
			type 0 : integer
			start_time 1 : integer
			login_time 2 : integer
			login_days 3 : integer
			reward_record 4 : integer
		}
		list 0 : *RecordFest
	}
}



#商城同步
paygift_sync 3501 {
	request {
		refresh_time_1 0 : integer
		refresh_time_2 1 : integer
		refresh_time_3 2 : integer

		list 3 : *ShopItem
	}
}

#商城配置同步
paygift_open_sync 3502 {
	request {
		.OpenData {
			id 0 : integer
			open 1 : integer
		}
		open_list 4 : *OpenData
		open_101_list 5 : *OpenData
	}
}



#点赞同步
likes_sync 3601 {
	request {
		likes 0 : integer
		likes_offline 1 : integer
		like_time 2 : integer
		like_count 3 : integer
		daily_reward_count 4 : integer
		daily_reward_time 5 : integer
	}
}


#（失效）
abyss_call_sync 3901 {
	request {
		list 0 : *AbyssCallData
	}
}


#农场同步
farm_sync 4001 {
	request {
		sort_seed 0 : integer
		sort_arr 1 : string
		tile_num 2 : integer
		cash 3 : integer
		cash_time 4 : integer
		speedup_time 5 : integer
		farm_seed 6 : integer

		shop_refresh_time 7 : integer
	}
}


#交易所同步
exchange_sync 4101 {
	request {
		list 0 : *ExchangeData
	}
}



#个人邮件同步
mail_person_sync 4201 {
	request {
		list 0 : *PersonMailData
	}
}


#章节同步
chapter_sync 4301 {
	request {
		chapter_id 0 : integer
		max_id 1 : integer
	}
}

#世界关卡同步
wild_sync 4401 {
	request {
		list 0 : *WildData
	}
}


#抽卡同步
gacha_sync 4501 {
	request {
		shop_refresh_time 0 : integer
		.ScoreData {
			group 0 : integer
			score 1 : integer
		}
		score_group 1 : *ScoreData
	}
}


#gacha配置同步
gacha_open_sync 4502 {
	request {
		.OpenData {
			id 0 : integer
			open 1 : integer
		}
		list 2 : *OpenData
		shop_list 3 : *OpenData
	}
}


#怪物图鉴同步
manual_monster_sync 4601 {
	request {
		list 0 : *ManualMonsterData
	}
}

#钓鱼同步
fishing_sync 4701 {
	request {
		shop_refresh_time 0 : integer
		rod_id 1 : integer
		list 2 : *FishingData
		ponds 3 : *FishingPondData
	}
}

#轮回奖励同步
abyss_gift_sync 4801 {
	request {
		progress 0 : integer
		reward_time 1 : integer
		shop_refresh_time 2 : integer
	}
}

#排行榜同步
ranking_sync 4901 {
	request {
		list 0 : *RankingData
	}
}

#付费开启同步
consume_sync 5001 {
	request {
		bag_unlock 0 : integer
		armory_unlock 1 : integer
	}
}

#月签到同步
record_month_sync 5201 {
	request {
		turn 0 : integer
		login_time 1 : integer
		login_days 2 : integer
		reward_record 3 : integer
		reward_time 4 : integer
	}
}

#武器幻化同步
illusion_sync 5301 {
	request {
		list 0 : *integer
	}
}

#节日同步
festival_sync 5401 {
	request {
		.Festival {
			actv_id 0 : integer
			base_id 1 : integer
		}
		list 1 : *Festival
		current_list 2 : *Festival
	}
}

#概率提升同步
probup_sync 5501 {
	request {
		list 0 : *ProbupData
	}
}

#累充同步
charge_sync 5601 {
	request {
		list 0 : *ChargeData
	}
}

#篝火同步
campfire_sync 5701 {
	request {
		season_id 0 : integer
		season_time 1 : integer
		base_id 2 : integer

		season 10 : integer
		score 11 : integer
		exp_times 12 : integer
		exp_time 13 : integer 
	}
}



#聊天推送消息
chat_push_msg 5801 {
	request {
		data 0 : ChatData
	}
}

#聊天切磋剩余次数更新
chat_battle_count 5802 {
	request {
		index 0 : integer
		count 1 : integer
		channel 2 : integer   					#1世界，2公会
	}
}





#联机副本同步
tower_sync 5901 {
	request {
		list 1 : *TowerData
	}
}

#战令同步
abyss_pass_sync 6001 {
	request {
		free_record_1 1 : integer
		free_record_2 2 : integer
		free_record_3 3 : integer
		free_record_4 4 : integer
		free_record_5 5 : integer
		free_record_6 6 : integer
		free_record_7 7 : integer
		free_record_8 8 : integer
		free_record_9 9 : integer
		free_record_10 10 : integer
		free_record_11 11 : integer
		free_record_12 12 : integer
		free_record_13 13 : integer
		free_record_14 14 : integer
		free_record_15 15 : integer
		free_record_16 16 : integer
		free_record_17 17 : integer
		free_record_18 18 : integer
		free_record_19 19 : integer
		free_record_20 20 : integer

		pay_record_1 21 : integer
		pay_record_2 22 : integer
		pay_record_3 23 : integer
		pay_record_4 24 : integer
		pay_record_5 25 : integer
		pay_record_6 26 : integer
		pay_record_7 27 : integer
		pay_record_8 28 : integer
		pay_record_9 29 : integer
		pay_record_10 30 : integer
		pay_record_11 31 : integer
		pay_record_12 32 : integer
		pay_record_13 33 : integer
		pay_record_14 34 : integer
		pay_record_15 35 : integer
		pay_record_16 36 : integer
		pay_record_17 37 : integer
		pay_record_18 38 : integer
		pay_record_19 39 : integer
		pay_record_20 40 : integer

		paid_1 41 : integer
		paid_2 42 : integer
		paid_3 43 : integer
		paid_4 44 : integer
		paid_5 45 : integer
		paid_6 46 : integer
		paid_7 47 : integer
		paid_8 48 : integer
		paid_9 49 : integer
		paid_10 50 : integer
	}
}


#sp佣兵同步
hero_sp_sync 6101 {
	request {
		.HeroSpData {
			base_id 0 : integer
			story_id 1 : integer
		}
		list 1 : *HeroSpData
	}
}

#故事书同步
book_sync 6201 {
	request {
		.BookData {
			base_id 0 : integer
			create_time 1 : integer
			update_time 2 : integer
			reward_already 3 : integer
			seed 4 : integer
			read_count 5 : integer
			record_1 11 : integer
			record_2 12 : integer
			record_3 13 : integer
			record_4 14 : integer
		}

		list 1 : *BookData
	}
}


#浅层深渊奖励同步
abyss_reward_sync 6301 {
	request {
		already_id 1 : integer
		area_id 2 : integer
	}
}


#地城商店同步
item_shop_sync 6401 {
	request {
		data 0 : ItemShop
	}
}

#玛露卡每日奖励同步
maruka_sync 6501 {
	request {
		reward_time_1 0 : integer
	}
}

#玩家展示同步
user_show_sync 6601 {
	request {
		.UserShowData {
			type 0 : integer
			index 1 : integer
			id 2 : integer
		}
		list 1 : *UserShowData
	}
}

#永劫同步
naraka_sync 6701 {
	request {
		reward_count 0 : integer
		reward_time 1 : integer
		mode_arr 2 : string

		shop_refresh_time 10 : integer
	}
}

#图鉴奖励同步
manual_reward_sync 6801 {
	request {
		record_1 0 : integer
		record_2 1 : integer
	}
}


#家园同步
home_sync 6901 {
	request {
		map_id 0 : integer
		is_public 1 : integer
		visiting_user 2 : integer

		shop_refresh_time 10 : integer
	}
}

#家园工坊商店同步
home_craft_shop_sync 6902 {
	request {
		item 0 : ShopItem
	}
}

#家园炼金商店同步
home_alchemy_shop_sync 6903 {
	request {
		item 0 : ShopItem
	}
}

#家园工坊同步
home_workshop_shop_sync 6904 {
	request {
		item 0 : ShopItem
	}
}



#道具制作同步
delay_item_sync 7001 {
	request {
		.DelayItemData {
			id 0 : integer
			type 1 : integer
			start_time 2 : integer
			end_time 3 : integer
			item_id 4 : integer
			item_num 5 : integer
		}
		list 0 : *DelayItemData
	}
}

#道具制作移除
delay_item_sync_remove 7002 {
	request {
		list 0 : *integer
	}
}

#客服反馈同步
service_feedback_sync 7101 {
	request {
		id 0 : integer
		text 1 : string
		reply 2 : string
		is_read 3 : integer
	}
}

#好评奖励同步
service_review_reward_sync 7102 {
	request {
		review_reward 2 : integer
	}
}

#物品掉落限量同步
item_limit_sync 7201 {
	request {
		list 1 : *ItemLimitData
	}
}

#深渊领域同步
abyss_area_sync 7301 {
	request {
		list 1 : *AbyssAreaData
	}
}

#装备库同步
armory_sync 7401 {
	request {
		list 0 : *ArmoryData
	}
}


#全局参数同步
world_sync 7601 {
	request {
		.World {
			id 0 : string
			value 1 : integer
		}
		list 1 : *World
	}
}

#全局变量同步
params_sync 7701 {
	request {
		.Param {
			code 0 : string
			value 1 : integer
			value_str 2 : string
		}
		list 1 : *Param
	}
}

#sp佣兵图鉴同步
manual_sync 7801 {
	request {
		list 0 : *ManualData
	}
}

#特殊武器图鉴同步
#manual_weapon_sync 7901 {
#	request {
#		list 0 : *ManualWeaponData
#	}
#}

#自定义礼包同步
mygift_sync 8001 {
	request {
		list 0 : *MygiftData
		is_all 1 : integer
	}
}

#活动同步
actv_sync 8101 {
	request {
		list 0 : *ActvData
		bind_list 1 : *ActvBindData
		is_all 2 : integer
	}
}

#活动每日目标同步
actv_achieve_sync 8201 {
	request {
		list 1 : *ActvAchieveData

		config_day 2 : *ActvAchieveConfig
		config_full 3 : *ActvAchieveConfig
	}
}

#活动怪物同步
actv_monster_sync 8301 {
	request {
		list 1 : *ActvMonsterData
		config_list 2 : *ActvMonsterConfig
	}
}


#活动副本同步
actv_stage_sync 8401 {
	request {
		list 0 : *ActvStageData
	}
}

#（失效）
lang_sync 8501 {
	request {
		.Lang {
			id 0 : string
			open 1 : integer
		}
		list 1 : *Lang
	}
}

#成长任务同步
first_achieve_sync 8601 {
	request {
		.FirstAchieveData {
			base_id 0 : integer
			count 1 : integer
			step 2 : integer
			rewarded 3 : integer
		}
		list 1 : *FirstAchieveData

		start_time 2 : integer
		reward_record 3 : integer
		paid 4 : integer
		paid_reward_record 5 : integer
	}
}

#尘封同步
dust_sync 8701 {
	request {
		list 1 : *DustData
		gm_list 2 : *DustGM
	}
}

#尘封委托同步
dust_achieve_sync 8801 {
	request {
		list 1 : *DustAchieveData

		day_refresh 2 : integer
		day_rewarded 3 : integer
		day_rewarded_time 4 : integer
		week_refresh 5 : integer
		week_rewarded 6 : integer
		week_rewarded_time 7 : integer
	}
}

#尘封委托移除
dust_achieve_sync_remove 8802 {
	request {
		list 0 : *integer
	}
}

#尘封战令同步
dust_pass_sync 8901 {
	request {
		free_record_1 1 : integer
		free_record_2 2 : integer
		free_record_3 3 : integer
		free_record_4 4 : integer
		free_record_5 5 : integer
		free_record_6 6 : integer
		free_record_7 7 : integer
		free_record_8 8 : integer
		free_record_9 9 : integer
		free_record_10 10 : integer
		free_record_11 11 : integer
		free_record_12 12 : integer
		free_record_13 13 : integer
		free_record_14 14 : integer
		free_record_15 15 : integer
		free_record_16 16 : integer
		free_record_17 17 : integer
		free_record_18 18 : integer
		free_record_19 19 : integer
		free_record_20 20 : integer

		pay_record_1 21 : integer
		pay_record_2 22 : integer
		pay_record_3 23 : integer
		pay_record_4 24 : integer
		pay_record_5 25 : integer
		pay_record_6 26 : integer
		pay_record_7 27 : integer
		pay_record_8 28 : integer
		pay_record_9 29 : integer
		pay_record_10 30 : integer
		pay_record_11 31 : integer
		pay_record_12 32 : integer
		pay_record_13 33 : integer
		pay_record_14 34 : integer
		pay_record_15 35 : integer
		pay_record_16 36 : integer
		pay_record_17 37 : integer
		pay_record_18 38 : integer
		pay_record_19 39 : integer
		pay_record_20 40 : integer

		paid_1 41 : integer
		paid_2 42 : integer
		paid_3 43 : integer
		paid_4 44 : integer
		paid_5 45 : integer
		paid_6 46 : integer
		paid_7 47 : integer
		paid_8 48 : integer
		paid_9 49 : integer
		paid_10 50 : integer
	}
}

#尘封属性图鉴同步
dust_attr_manual_sync 9001 {
	request {
		.AttrManualData {
			base_id 0 : integer
			rewarded 1 : integer
		}
		list 1 : *AttrManualData
	}
}


#活动签到同步
actv_record_sync 9101 {
	request {
		list 0 : *ActvRecordData
	}
}


#战令同步
bp_overall_sync 9201 {
	request {
		pre_session 0 : integer
		heat 1 : integer
	}
}

bp_sync 9211 {
	request {
		list 0 : *BpData
		is_all 1 : integer
	}
}



#战令任务同步
bp_achieve_sync 9301 {
	request {
		list 1 : *BpAchieveData

		bp_id 2 : integer
		day_refresh 3 : integer
		week_refresh 4 : integer
	}
}

#尘封委托移除
bp_achieve_sync_remove 9302 {
	request {
		list 0 : *integer
	}
}


#魔纹数据同步
sigil_sync 9401 {
	request {
		list 0 : *SigilData
	}
}

#魔纹移除
sigil_sync_remove 9402 {
	request {
		list 0 : *integer
	}
}


#轮盘活动推数(所有轮盘)
actv_turntable_sync 9501 {
	request {
		list 0 : *ActvTurntableData
	}
}

# 回归同步
back_sync 9601 {
	request {
		list 0 : *BackData
		is_all 1 : integer
	}
}

#回归签到同步
back_record_sync 9611 {
	request {
		list 0 : *BackRecordData
	}
}

#回归成就同步
back_achieve_sync 9621 {
	request {
		list 0 : *BackAchieveData
	}
}

#投喂同步
pet_feed_sync 9701 {
	request {
		list 0 : *PetFeedData
	}
}

#神器数据同步
artifact_sync 9801 {
	request {
		list 0 : *ArtifactData
	}
}

#神器移除
artifact_sync_remove 9802 {
	request {
		list 0 : *integer
	}
}

#守护核心数据同步
core_sync 30101 {
	request {
		list 0 : *CoreData
	}
}








#进入联机地图
camp_enter 10101 {
	request {
		user_info  0 : UserInfo
		x 1 : integer
		y 2 : integer
		appear 3 : string
		abyss_level 4 : integer
		medals 5 : *integer
		
		.UserUnionInfo {
			union_id 0 : integer				#公会ID
			union_icon 1 : UnionIcon			#公会头像
		}
		union_info  6 : UserUnionInfo
	}
}

#联机地图离开
camp_exit 10102 {
	request {
		user_id  0 : integer
	}
}

#联机地图召回
camp_summon 10103 {
	request {
		index  0 : integer
		total  1 : integer
	}
}

#联机地图移动广播
camp_move 10111 {
	request {
		user_id  0 : integer
		x 1 : integer
		y 2 : integer
	}
}

#联机地图表情广播
camp_emoji 10112 {
	request {
		user_id  0 : integer
		id 1 : integer
	}
}

#联机地图外观更新
camp_appear_update 10114 {
	request {
		user_id 0 : integer
		hero_id  1 : integer
		appear 2 : string
	}
}

#（失效）
camp_play_song 10115 {
	request {
		username 0 : string
		id 1 : integer
	}
}

#联机地图做动作
camp_action 10116 {
	request {
		user_id 0 : integer
		id 1 : integer
		params 2 : string
	}
}

#联机地图徽章更新
camp_medals_update 10117 {
	request {
		user_id 0 : integer
		medals 2 : *integer
	}
}



#联机地图战斗开始
camp_battle_start 10121 {
	request {
		user_id  0 : integer
		map_index 1 : integer
		event_index 2 : integer
	}
}

#联机地图战斗结束
camp_battle_over 10122 {
	request {
		user_id  0 : integer
	}
}

#联机地图同步血量
camp_sync_hp 10123 {
	request {
		.MonsterHP {
			map_index 0 : integer
			event_index 1 : integer
			index 2 : integer
			hp 3 : integer
		}
		hp_monster 0 : *MonsterHP

		.HeroHP {
			user_id 0 : integer
			pos 1 : integer
			hp 2 : integer
		}
		hp_hero 1 : *HeroHP

		.Dps {
			map_index 0 : integer
			event_index 1 : integer
			user_id 2 : integer
			dps 3 : integer
		}
		dps_map 2 : *Dps
	}
}

#联机地图目标达成广播
camp_sync_pass 10124 {
	request {
		pass_count 0 : integer
		pass_total 1 : integer
	}
}










#组队房间玩家进入广播
room_enter 10201 {
	request {
		user_id 0 : integer
		time 1 : integer
		nickname 2 : string
		nicklang 3 : string
		head 4 : integer
		head_frame 5 : integer
		is_ready 6 : integer
	}
}

#组队房间玩家离开广播
room_exit 10202 {
	request {
		user_id 0 : integer
	}
}

#组队房间倒计时广播
room_countdown_start 10203 {
	request {
		time 0 : integer
	}
}

#组队房间倒计时离开广播
room_countdown_cancel 10204 {
	request {
	}
}

#组队房间准备广播
room_ready 10205 {
	request {
		user_id 0 : integer
		is_ready 1 : integer
	}
}

#组队房间关闭
room_clear 10206 {
	request {
	}
}




#组队房间创建
room_create 10211 {
	request {
		id 0 : integer
		name 1 : string
		room_id 2 : integer
		nickname 3 : string
		nicklang 4 : string
		count 5 : integer
		time 6 : integer
	}
}

#组队房间更新人数
room_update 10212 {
	request {
		id 0 : integer
		count 4 : integer
	}
}

#组队房间关闭
room_kill 10213 {
	request {
		id 0 : integer
	}
}


#短消息推送
notify_push 20101 {
	request {
		notice_id 0 : integer
		replace 1 : *string
		time 2 : integer
	}
}

#跑马灯推送
marquee_push 20201 {
	request {
		msg 1 : string
		time 2 : integer
	}
}

#系统跑马灯推送
marquee_fixed_push 20202 {
	request {
		id 0 : integer
		replace 1 : *string
	}
}

#服务器即时推送的跑马灯（服务器会根据GM后台设置的inteval来推送)
marquee_instant_push 20203 {
	request {
		msg 1 : string
		time 2 : integer   #这条跑马灯的interval
	}
}

# 返利推送
rebate_push 20250 {
	request {
		rebate_num 0 : integer      #返利条目数量
	}
}

# ---------------------公会推送-----------------------------

# 公会基础信息同步
union_base_info_sync 20301 {
	request {
		info 0 : UnionBaseInfo
	}
}

# 自己的工会信息发生变化
union_private_info_sync 20302 {
	request {
		user_id 0 : integer
		union_id 1 : integer				# 公会ID发生变化，0表示被踢出了公会，非0表示加入了公会
		private_info 2 : UnionPrivateInfo	# 包括官衔，捐赠，上次退出公会时间等信息
	}
}



# 公会建筑信息同步
union_building_info_sync 20310 {
	request {
		info 0 : UnionBuildingInfo
	}
}

# 公会 BUFF 信息同步
union_buff_info_sync 20311 {
	request {
		info 0 : UnionBuffInfo
	}
}


# 公会 shop 信息同步
union_shop_sync 20320 {
	request {
		shop_refresh_time 0 : integer
	}
}

# 公会 PVE 信息的推送
union_pve_info_sync 20330 {
	request {
		stage_id 1 : integer 					#挑战的普通副关卡的ID (gwar_stage表的id)
		active_point 2 : integer				#活跃点数
		active_reward_flag 3 : integer			#活跃度奖励领取情况（二进制标识）
		support_point 4 : integer				#为公会贡献的支援点数
		
		challenge_times 5 : integer 			#已挑战普通副本的的次数
		last_challenge_time 6 : integer			#最后一次挑战普通副本的时间
		union_support_point 7 : integer			#公会当前的支援点数
		
		challenge_boss_times 20 : integer 		#已挑战boss副本的的次数
		challenge_boss_time 21 : integer 		#最后一次挑战boss副本的时间
	}
}




]]

return s2c
