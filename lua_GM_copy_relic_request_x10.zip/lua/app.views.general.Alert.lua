local UI_base = import("..UI_base")
local Alert = class("Alert", UI_base)
local instance = nil

function Alert.open(msg, time)
	time = time or 1

	if not instance then
		instance = Alert.new()

		display.getRunningScene():addChild(instance, LayerConfig.alert)
	end

	instance:show(msg, time)
end

function Alert.clear()
	if instance then
		transition.stopTarget(instance)

		instance = nil
	end
end

function Alert:ctor()
	Alert.super.ctor(self, "com_alert", UIManager.BIG_TYPE.POP)
end

function Alert:show(msg, time)
	local fontSize = math.min(32, math.max(24, math.floor(600 / string.utf8len(msg))))
	local label, labelWidth = self:createLabelOnFlag("flag_msg", msg, {
		size = fontSize
	})
	local bg = self:getComponentByTag("bg")

	if not bg.startX then
		bg.startX = bg.x
	end

	local wOffset = labelWidth - bg.originalWidth + 20

	if wOffset > 0 then
		bg:setSize(bg.originalWidth + wOffset)
		bg:setPos(bg.startX - wOffset / 2)
	end

	transition.stopTarget(self)
	self:setPositionY(-100)
	self:setVisible(true)
	self:setOpacity(0)
	transition.fadeIn(self, {
		time = 0.1
	})
	transition.moveTo(self, {
		easing = "backOut",
		time = 0.2,
		y = 0
	})
	transition.moveTo(self, {
		easing = "backIn",
		time = 0.2,
		y = 100,
		delay = time
	})
	transition.fadeOut(self, {
		time = 0.1,
		delay = time,
		onComplete = function ()
			self:removeSelf()

			instance = nil
		end
	})
end

return Alert
