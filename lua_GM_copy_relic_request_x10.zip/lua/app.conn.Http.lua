local Http = {}

local function save_http_error(content)
	if device.platform == "windows" then
		local path = cc.FileUtils:getInstance():getWritablePath() .. "http_error/" .. os.date("%Y-%m-%d %H-%M-%S") .. ".html"

		io.writefile(path, content)
	else
		local path = cc.FileUtils:getInstance():getWritablePath() .. "http_error.html"

		io.writefile(path, content)
	end
end

local function json_error(content)
	Log.debug("json_error")
	save_http_error(content)
end

local function print_debug(debug_stack)
	dump(debug_stack, "print_debug", 10)
end

local syncCallbackMap = {}

local function idToNum(v)
	local newV = {}

	for k1, v1 in pairs(v) do
		if tonumber(k1) then
			newV[tonumber(k1)] = v1
		else
			newV[k1] = v1
		end
	end

	return newV
end

local function sync_data(data)
	for k, v in pairs(data) do
		local syncCallback = syncCallbackMap[k]

		if syncCallback then
			syncCallback(idToNum(v))
		end
	end
end

function Http.listenSync(key, callback)
	syncCallbackMap[key] = callback
end

local ignore_errs = {
	"login_fail_password"
}
local ignore_err_map = {}

for i, v in ipairs(ignore_errs) do
	ignore_err_map[v] = true
end

local retrying = false
local requestSession = 0
local sessionCancelMap = {}

function Http.retry(url, params, callback, mode, onFailure, tryCount, session)
	print("$$$ Http.retry", tryCount, url, session)
	Looper.setTimeout(function ()
		print("$$$ Http.retry callback")
		Http.request(url, params, callback, mode, onFailure, tryCount, session)
	end, 30)
end

function Http.cancelRetry(session)
	sessionCancelMap[session] = true
end

function Http.cancelPreRetry()
	Http.cancelRetry(requestSession)
end

function Http.request(url, params, callback, mode, onFailure, tryCount, session)
	tryCount = tryCount or 0
	local startTime = Time.time()

	if not session then
		requestSession = requestSession + 1
		session = requestSession
	end

	if DEV_MODE then
		print("$$$ Http.request", tryCount, url, session)
	end

	if type(params) == "function" then
		onFailure = mode
		mode = callback
		callback = params
		params = nil
	end

	local function onResponse(event)
		local request = event.request

		if event.name ~= "completed" then
			if callback then
				if event.name == "progress" then
					if Time.time() - startTime > 3 then
						if not sessionCancelMap[session] then
							Http.retry(url, params, callback, mode, onFailure, nil, session)
						end

						callback = nil
					end
				elseif event.name == "failed" then
					if tryCount < 300 then
						if not sessionCancelMap[session] then
							Http.retry(url, params, callback, mode, onFailure, tryCount + 1, session)
						end

						callback = nil
					else
						Log.debug("request:getErrorCode(), request:getErrorMessage() ", request:getErrorCode(), request:getErrorMessage(), event.name)

						if onFailure then
							onFailure(1)
						end
					end
				end
			end

			return
		end

		if DEV_MODE then
			print("$$$ callback", callback, url, Time.time() - startTime)
		end

		local code = request:getResponseStatusCode()

		if code ~= 200 then
			Log.debug("code ", code)

			local responseString = request:getResponseString()
			local startIndex = string.find(responseString, "<textarea id=\"clipboard\">", 1, true)

			if startIndex then
				startIndex = startIndex + 25
				local endIndex = string.find(responseString, "</textarea>", startIndex, true)

				if endIndex then
					local errorMessage = string.sub(responseString, startIndex, endIndex - 1)

					Console.logError("----------------------------------------\n" .. "HTTP ERROR: " .. tostring(errorMessage) .. "\n" .. debug.traceback("", 2) .. "\n----------------------------------------")
					InfoGM.sendError("http", errorMessage)
				end
			end

			save_http_error(responseString)

			if onFailure then
				onFailure(2)
			end

			return
		end

		local strResponse = string.trim(request:getResponseString())
		local data = json.decode(strResponse)

		if data then
			if data.debug then
				print_debug(data.debug)

				data.debug = nil
			end

			if data.sync_remove then
				sync_data(data.sync_remove)

				data.sync_remove = nil
			end

			if data.sync then
				sync_data(data.sync)

				data.sync = nil
			end

			if data.err then
				Log.warn("ERR:" .. data.err)

				if not ignore_err_map[data.err] then
					ErrCode.onErr(data.err)
				end
			end

			if callback then
				callback(data)
			end

			callback = nil
		else
			json_error(strResponse)
		end
	end

	local request = network.createHTTPRequest(onResponse, url, mode or "POST")

	if params then
		for key, value in pairs(params) do
			request:addPOSTValue(key, value)
		end
	end

	request:setTimeout(30)
	request:start()
end

function Http.testRequest()
	print("$$$ Http.testRequest")

	local function onResponse(event)
		local request = event.request

		if event.name ~= "completed" then
			if event.name ~= "progress" then
				Log.debug("request:getErrorCode(), request:getErrorMessage() ", request:getErrorCode(), request:getErrorMessage(), event.name)
			end

			return
		end

		local code = request:getResponseStatusCode()

		print("$$$ onResponse", code)
	end

	print("$$$ Connection.host", Connection.host)

	local url = "192.168.10.167:8001"
	local request = network.createHTTPRequest(onResponse, url .. "/test", "POST")
	local data = {
		param1 = "test1",
		param2 = "test2",
		param3 = "test3"
	}

	request:addPOSTValue("data", json.encode(data))
	request:setTimeout(30)
	request:start()
end

return Http
