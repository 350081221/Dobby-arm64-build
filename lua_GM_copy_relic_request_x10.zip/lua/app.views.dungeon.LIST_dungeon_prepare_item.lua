local List = import("...ui.List")
local LIST_dungeon_prepare_item = class("LIST_dungeon_prepare_item", List)

function LIST_dungeon_prepare_item:ctor(rect)
	LIST_dungeon_prepare_item.super.ctor(self, rect)
	self:setCols(3)
	self:setCellName("cell_dungeon_prepare_item")
	self:setSpace(5, 5)
	self:setCellSize(cc.size(self.touchRect.width, 120))
end

function LIST_dungeon_prepare_item:onCellInit(ui, data)
	if not ui.slot then
		ui.slot = DropSlot.new(ui:getFlagByTag("flag_slot"), "slot_01")

		ui:addChild(ui.slot, 100)
		ui.slot:setAlwaysShowNumber(true)
	end

	ui.slot:setDrop(data.type, data.info)
end

function LIST_dungeon_prepare_item:getPickNode(cell)
	if cell then
		return cell.slot
	end
end

return LIST_dungeon_prepare_item
