local InfoDustPass = {}
local rawData = nil

function InfoDustPass.init()
	Connection.listen("dust_pass_sync", InfoDustPass.sync)
end

app:addToAppEnterCall(InfoDustPass.init)

function InfoDustPass.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoDustPass.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("dust_pass_query", callback)
end

function InfoDustPass.onQuery(rcvData)
	dump(rcvData, "dust_pass_query")

	rawData = rcvData
end

function InfoDustPass.sync(syncData)
	for k, v in pairs(syncData) do
		rawData[k] = v
	end

	notify.dispatch("campaign_changed")
	ManagerInfo.dataChange("dust_pass")
end

function InfoDustPass.getReward(id, is_pay, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("dust_pass_get_reward", {
		id = id,
		is_pay = is_pay
	}, callback)
end

function InfoDustPass.getRewardAll(passID, onSuccess, onFailure)
	local arr = {}
	local dustLevel = InfoDust.getPassLevel(passID)
	local csvList = InfoDustPass.getGiftList(passID)

	for i, v in ipairs(csvList) do
		if v.pass_level <= dustLevel then
			local reward_arr = SheetUtil.getColumnList(v, {
				"free_reward_",
				"free_num_"
			}, {
				"base_id",
				"num"
			})
			local hasFree = #reward_arr > 0
			local reward_arr = SheetUtil.getColumnList(v, {
				"pay_reward_",
				"pay_num_"
			}, {
				"base_id",
				"num"
			})
			local hasPay = #reward_arr > 0

			if hasFree and InfoDustPass.getRecord(v.id) == 0 then
				table.insert(arr, {
					is_pay = 0,
					id = v.id
				})
			end

			if hasPay and InfoDustPass.getRecord(v.id, true) == 0 and InfoDustPass.isPaid(v.pass_id) then
				table.insert(arr, {
					is_pay = 1,
					id = v.id
				})
			end
		else
			break
		end
	end

	if #arr > 0 then
		local function callback(rcvData)
			if rcvData.err then
				if onFailure then
					onFailure(rcvData.err)
				end
			elseif onSuccess then
				onSuccess(rcvData)
			end
		end

		Connection.request("dust_pass_get_reward_all", {
			list = arr
		}, callback)
	end
end

function InfoDustPass.buyExp(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("dust_pass_buy_exp", callback)
end

function InfoDustPass.getRecord(id, isPay)
	local section, position = BitUtil.split(30, id)
	local recordNum = nil

	if isPay then
		recordNum = rawData["pay_record_" .. section]
	else
		recordNum = rawData["free_record_" .. section]
	end

	return BitUtil.getBitByIndex(recordNum, position)
end

function InfoDustPass.countRedot(passID)
	local redotCount = 0
	local level = InfoDust.getPassLevel(passID)
	local csvList = InfoDustPass.getGiftList(passID)

	for i, v in ipairs(csvList) do
		if v.pass_level <= level then
			local reward_arr = SheetUtil.getColumnList(v, {
				"free_reward_",
				"free_num_"
			}, {
				"base_id",
				"num"
			})
			local hasFree = #reward_arr > 0
			local reward_arr = SheetUtil.getColumnList(v, {
				"pay_reward_",
				"pay_num_"
			}, {
				"base_id",
				"num"
			})
			local hasPay = #reward_arr > 0

			if hasFree and InfoDustPass.getRecord(v.id) == 0 or hasPay and InfoDustPass.getRecord(v.id, true) == 0 and InfoDustPass.isPaid(v.pass_id) then
				redotCount = redotCount + 1
			end
		else
			break
		end
	end

	return redotCount
end

function InfoDustPass.isPaid(passID)
	return rawData["paid_" .. passID] > 0
end

function InfoDustPass.getGiftList(passID)
	local csvList = CsvParser.getCsvList("dust_pass_gift", "id", {
		pass_id = passID
	})

	return csvList
end

function InfoDustPass.getNextSpReward(passID)
	local csvList = InfoDustPass.getGiftList(passID)

	for i, v in ipairs(csvList) do
		if v.pay_reward_sp == 1 and InfoDustPass.getRecord(v.id, true) == 0 then
			return v
		end
	end
end

function InfoDustPass.countGift(passID)
	local count = 0
	local csvList = InfoDustPass.getGiftList(passID)

	for i, v in ipairs(csvList) do
		local reward_arr = SheetUtil.getColumnList(v, {
			"free_reward_",
			"free_num_"
		}, {
			"base_id",
			"num"
		})
		local hasFree = #reward_arr > 0
		local reward_arr = SheetUtil.getColumnList(v, {
			"pay_reward_",
			"pay_num_"
		}, {
			"base_id",
			"num"
		})
		local hasPay = #reward_arr > 0

		if hasFree and InfoDustPass.getRecord(v.id) == 0 or hasPay and InfoDustPass.getRecord(v.id, true) == 0 then
			count = count + 1
		end
	end

	return count
end

function InfoDustPass.getPassList()
	local csvList = CsvParser.getCsvList("dust_pass")
	local max_chapter = InfoChapter.getMaxID()
	local arr = {}

	for i, v in ipairs(csvList) do
		if v.chapter_id <= max_chapter then
			if InfoDustPass.countGift(v.id) > 0 then
				table.insert(arr, v)
			end
		else
			break
		end
	end

	return arr
end

return InfoDustPass
