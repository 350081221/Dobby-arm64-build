local InfoTD = {}
local heroPrepare = {}
local prepareJson = ""

function InfoTD.init()
end

app:addToAppEnterCall(InfoTD.init)

function InfoTD.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			heroPrepare = {}

			for i = 1, GameConfig.td_hero_max do
				local heroID = rcvData["hero_" .. i]

				if not empty(heroID) then
					local heroInfo = InfoHero.getHero(heroID)

					if heroInfo then
						heroPrepare[i] = heroID
					end
				end
			end

			prepareJson = json.encode(heroPrepare)

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("td_query", callback)
end

function InfoTD.update(onSuccess, onFailure)
	local currentJson = json.encode(heroPrepare)

	if prepareJson == currentJson then
		return
	end

	local function callback(rcvData)
		dump(rcvData, "td_update")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			prepareJson = currentJson

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	local params = {}

	for i = 1, GameConfig.td_hero_max do
		params["hero_" .. i] = 0
		local heroID = heroPrepare[i]

		if not empty(heroID) then
			local heroInfo = InfoHero.getHero(heroID)

			if heroInfo then
				params["hero_" .. i] = heroID
			end
		end
	end

	Connection.request("td_update", params, callback)
end

function InfoTD.finishStage(result, onSuccess, onFailure)
	print("$$$ finishStage", result)

	local hash = ""

	local function callback(rcvData)
		dump(rcvData, "td_finish_stage", 10)

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("td_finish_stage", {
		result = result,
		hash = hash
	}, callback)
end

local deployMap = {}

function InfoTD.reset()
	deployMap = {}
end

function InfoTD.setDeploy(index, heroID)
	deployMap[index] = heroID
end

function InfoTD.getDeployMap()
	return deployMap
end

function InfoTD.getDeploy(index)
	return deployMap[index]
end

function InfoTD.removeDeploy(index)
	deployMap[index] = nil
end

function InfoTD.getHeroDeploy(heroID)
	for index, v in pairs(deployMap) do
		if v == heroID then
			return index
		end
	end
end

function InfoTD.setHeroPrepare(index, heroID)
	InfoTD.removeHeroPrepare(heroID)

	heroPrepare[index] = heroID
end

function InfoTD.getHeroPrepare(index)
	return heroPrepare[index]
end

function InfoTD.removeHeroPrepare(heroID)
	for index, v in pairs(heroPrepare) do
		if v == heroID then
			heroPrepare[index] = nil

			return true
		end
	end
end

function InfoTD.countHeroPrepare()
	local count = 0

	for index, v in pairs(heroPrepare) do
		count = count + 1
	end

	return count
end

return InfoTD
