local SkillManager = {}
local SKILL_TYPE = {
	HERO = 1,
	MODAO = 3,
	ITEM = 2
}
SkillManager.SKILL_TYPE = SKILL_TYPE
local SUMMON_TIME = {
	AFFECT = 1,
	CAST = 2
}
SkillManager.SUMMON_TIME = SUMMON_TIME

local function expandTilesBySize(tileMap, size)
	local exTiles = {}
	local existMap = {}
	local _tiles = MapUtils.tileMapToArr(tileMap)

	for i, tile in ipairs(_tiles) do
		for m = 0, size do
			for n = 0, size do
				local x = tile.x + m
				local y = tile.y + n
				local exTile = global.map:getTile(x, y)

				if exTile and not tileMap[exTile.tag] and not existMap[exTile.tag] then
					existMap[exTile.tag] = true

					table.insert(exTiles, exTile)
				end
			end
		end
	end

	for i, tile in ipairs(exTiles) do
		tileMap[tile.tag] = tile
	end
end

local function getRangeTilesDiamond(startTile, range, size)
	local tileMap = {}

	for i = startTile.x - math.ceil(range), startTile.x + math.ceil(range) do
		for j = startTile.y - math.ceil(range), startTile.y + math.ceil(range) do
			local tile = global.map:getTile(i, j)

			if tile and range >= math.abs(tile.x - startTile.x) + math.abs(tile.y - startTile.y) then
				tileMap[tile.tag] = tile
			end
		end
	end

	if size > 0 then
		expandTilesBySize(tileMap, size)
	end

	return tileMap
end

local function getRangeTilesRound(startTile, range, size)
	local tileMap = {}

	for i = startTile.x - range, startTile.x + range do
		for j = startTile.y - range, startTile.y + range do
			local tile = global.map:getTile(i, j)

			if tile then
				local distance = math.sqrt(math.pow(tile.y - startTile.y, 2) + math.pow(tile.x - startTile.x, 2))

				if math.round(distance) <= range then
					tileMap[tile.tag] = tile
				end
			end
		end
	end

	if size > 0 then
		expandTilesBySize(tileMap, size)
	end

	return tileMap
end

function SkillManager.init()
end

local isGuiding = nil

function SkillManager.setGuide(_isGuiding)
	isGuiding = _isGuiding
end

function SkillManager.isGuide()
	return isGuiding
end

local isLockeding = nil

function SkillManager.setLocked(_isLocked)
	isLockeding = _isLocked
end

function SkillManager.isLocked()
	return isLockeding
end

function SkillManager.autoEnabled()
	return InfoBuilding.getBuildingLevel(InfoBuilding.TAG.MONO) > 0
end

function SkillManager.isSummon(skillData)
	if (not empty(skillData.summon_type) or not empty(skillData.summon_id)) and not empty(skillData.summon_num) then
		return true
	end

	return false
end

function SkillManager.getSummonInfo(skillData, caster)
	local baseType, baseID = nil
	local maxLevel = 99

	if skillData.summon_type == 0 then
		baseType = "summoned"
		baseID = skillData.summon_id
		maxLevel = CsvParser.getMaxID("summoned_base_num")
	elseif skillData.summon_type == 1 then
		baseType = "monster"
		baseID = skillData.summon_id
		maxLevel = CsvParser.getMaxID("monster_base_num")
	elseif skillData.summon_type == 2 then
		baseType = "monster"
		baseID = caster.data.summon
		maxLevel = CsvParser.getMaxID("monster_base_num")
	end

	if not empty(baseID) then
		local summonedInfo = {
			base_type = baseType,
			base_id = baseID
		}
		local level = caster.info.level

		if not empty(caster.data) and not empty(caster.data.ex_level) then
			level = level + caster.data.ex_level
		end

		level = math.max(1, math.min(level, maxLevel))
		summonedInfo.level = level
		summonedInfo.summonerType = caster.info.summonerType or caster.type

		return summonedInfo
	end
end

function SkillManager.trySummon(summonTime, skillData, caster, target, onlyOne)
	local map = global.map

	if caster.type == "OnlinePlayer" then
		return
	end

	if skillData.summon_time ~= summonTime then
		return
	end

	if summonTime == SUMMON_TIME.AFFECT and skillData.select_type == 0 then
		target = target or caster
	end

	if SkillManager.isSummon(skillData) then
		local summonNum = 1

		if not onlyOne then
			summonNum = SheetUtil.getNumber(skillData.summon_num, caster.warRandom)
		end

		for i = 1, summonNum do
			local summonedInfo = SkillManager.getSummonInfo(skillData, caster)

			if summonedInfo then
				local unit = Summoned.new()
				unit.seed = caster.warRandom:getInt(1, 65535)
				unit.random = Random.new(unit.seed)

				unit:setSummoner(caster)
				unit:setInfo(summonedInfo)
				unit:display(map, target.x, target.y)
				unit:startLife()

				unit.isBlock = skillData.summon_entity == 1

				if unit.data and unit.data.no_block == 1 then
					unit.isBlock = false
				end

				unit.summonNoBlock = skillData.summon_no_block == 1
				unit.summonNoTarget = unit.data.ignore == 1
				unit.noEntity = skillData.summon_entity ~= 1
				local noCount = unit.summonNoTarget or unit.noEntity

				WarMachine.addSummoned(unit, caster, noCount)
				unit:bornEffect()

				if not caster.summonQueueMap then
					caster.summonQueueMap = {}
				end

				if not caster.summonQueueMap[skillData.id] then
					caster.summonQueueMap[skillData.id] = {}
				end

				table.insert(caster.summonQueueMap[skillData.id], unit)
			end
		end

		if not empty(skillData.summon_max) and caster.summonQueueMap and caster.summonQueueMap[skillData.id] then
			local summonQueue = caster.summonQueueMap[skillData.id]
			local summon_max = skillData.summon_max

			if caster and caster.attrs and caster.attrs.summon_limit then
				summon_max = summon_max + caster.attrs.summon_limit
			end

			local moreCount = #summonQueue - summon_max

			if moreCount > 0 then
				for i = 1, moreCount do
					local unit = summonQueue[1]

					if unit then
						unit:die()
					else
						break
					end
				end
			end
		end
	end
end

function SkillManager.skillAffect(affectPack)
	local skillData = affectPack.skillData
	local attackPack = affectPack.attackPack
	local basePosition = affectPack.basePosition
	local caster = affectPack.caster
	local map = caster.map
	local target = affectPack.target
	local affectType = skillData.affect_type
	local affectRange = skillData.affect_range
	local affectSpeed = skillData.affect_speed

	if affectSpeed == "" then
		affectSpeed = 0
	end

	if affectType == 4 or affectType == 5 or affectType == 8 then
		local affectRangeArr = string.split(affectRange, ",")
		affectRange = tonumber(affectRangeArr[1])
		local targetAngle = math.atan2(target.y - caster.y, target.x - caster.x)

		if affectType ~= 8 then
			local effectGen = caster:getEffectGen()

			if effectGen then
				effectGen:castEffect(skillData.affect_effect, {
					x = caster.x,
					y = caster.y
				}, nil, targetAngle)
			end
		end

		if not empty(skillData.fly_effect) then
			local targetX = caster.x + math.cos(targetAngle) * affectRange * map.ptPerTile
			local targetY = caster.y + math.sin(targetAngle) * affectRange * map.ptPerTile
			local effectGen = caster:getEffectGen()

			if effectGen then
				effectGen:castEffect(skillData.fly_effect, {
					x = targetX,
					y = targetY
				})

				affectPack.missle = effectGen:getCurrentMissle()
			end
		end
	else
		local effectGen = caster:getEffectGen()

		if effectGen then
			effectGen:castEffect(skillData.affect_effect, target or caster)
		end
	end

	if affectType == 0 then
		SkillManager.trySummon(SUMMON_TIME.AFFECT, skillData, affectPack.caster, affectPack.target)
	elseif affectType == 1 then
		if skillData.select_type == 0 then
			SkillManager.trySummon(SUMMON_TIME.AFFECT, skillData, affectPack.caster, affectPack.target)

			local dmgValue = nil

			if caster.beDamage and attackPack then
				dmgValue = caster:beDamage(attackPack)
			end

			SkillManager.hitEffect(caster, affectPack, dmgValue)
		elseif skillData.select_type == 1 then
			SkillManager.trySummon(SUMMON_TIME.AFFECT, skillData, affectPack.caster, affectPack.target)

			local dmgValue = nil

			if target.beDamage and attackPack then
				dmgValue = target:beDamage(attackPack)
			end

			SkillManager.hitEffect(target, affectPack, dmgValue)
		elseif skillData.select_type == 2 then
			affectPack.targetTile = map:mapToTile(target)
		end
	else
		local targetPosition = nil

		if skillData.select_type == 0 then
			targetPosition = basePosition
		elseif skillData.select_type == 1 then
			targetPosition = {
				x = target.x,
				y = target.y
			}
		elseif skillData.select_type == 2 then
			targetPosition = target
		elseif skillData.select_type == 3 then
			targetPosition = target
		end

		local targetTile = map:mapToTile(targetPosition)
		affectPack.targetTile = targetTile
	end

	SkillManager.hitCasterEffect(caster, affectPack)

	if affectPack.targetTile then
		if affectSpeed > 0 then
			affectPack.stepRange = 1
			affectPack.stepCount = 0
		else
			affectPack.stepRange = affectRange
			affectPack.stepCount = 0
		end

		if SkillManager.isSummon(skillData) and not empty(skillData.affect_type) then
			SkillManager.arrangeSummonTiles(affectPack)
		end

		SkillManager.affectMultiTargets(affectPack, nil, , , , true)

		if affectSpeed > 0 then
			MapFrameManager.startLoop(affectPack, SkillManager.affectMultiTargets)
		end
	end
end

function SkillManager.arrangeSummonTiles(affectPack)
	local skillData = affectPack.skillData
	local affectType = skillData.affect_type
	local affectRange = skillData.affect_range
	local caster = affectPack.caster
	local map = caster.map
	local targetTile = affectPack.targetTile
	local affectTiles = SkillManager.getAffectTiles(caster, skillData, targetTile, affectRange)
	affectPack.summonMap = {}
	local summonableArr = {}
	local count = 0

	for i, tile in ipairs(affectTiles) do
		if SkillManager.isTileWalkable(tile, nil, true) then
			table.insert(summonableArr, tile)
		end
	end

	local randomArr = caster.warRandom:order(summonableArr)
	local summonNum = SheetUtil.getNumber(skillData.summon_num, caster.warRandom)

	for i = 1, summonNum do
		local tile = randomArr[i]

		if not tile and #summonableArr > 0 then
			tile = summonableArr[caster.warRandom:getInt(1, #summonableArr)]
		end

		tile = tile or caster.tile
		affectPack.summonMap[tile.tag] = true
	end
end

function SkillManager.affectMultiTargets(affectPack, frame, passed, sharp, elapsedTime, isFirst)
	if sharp == 0 then
		return
	end

	passed = passed or 0
	local skillData = affectPack.skillData
	local attackPack = affectPack.attackPack
	local alreadyTargets = affectPack.alreadyTargets
	local alreadyTiles = affectPack.alreadyTiles
	local basePosition = affectPack.basePosition
	local centerPosition = affectPack.centerPosition
	local caster = affectPack.caster
	local map = caster.map
	local target = affectPack.target
	local affectType = skillData.affect_type
	local affectRange = skillData.affect_range
	local affectSpeed = skillData.affect_speed
	local targetTile = affectPack.targetTile

	if affectSpeed == "" then
		affectSpeed = 0
	end

	local camp = 3 - caster.battleData.camp

	if skillData.friend == 1 then
		camp = caster.battleData.camp
	end

	if skillData.friend == 3 or skillData.friend == 4 then
		camp = nil
	end

	if affectType == 4 or affectType == 5 or affectType == 8 then
		local affectRangeArr = string.split(affectRange, ",")
		affectRange = tonumber(affectRangeArr[1])
	end

	if affectSpeed > 0 then
		affectPack.stepRange = math.min(affectRange, affectPack.stepRange + passed * affectSpeed / map.ptPerTile)
	end

	local currTiles = {}
	local hitted = false
	local hitPosition = nil

	if affectPack.stepCount <= 0 or affectType == 8 then
		local affectTiles, affectPosition = SkillManager.getAffectTiles(caster, skillData, targetTile, affectPack.stepRange)
		hitPosition = affectPosition

		for i = 1, #affectTiles do
			local tile = affectTiles[i]

			if not affectPack.alreadyTiles[tile:getTag()] then
				local mapX, mapY = map:tileToMap(tile)

				if affectPack.summonMap and affectPack.summonMap[tile.tag] then
					SkillManager.trySummon(SUMMON_TIME.AFFECT, skillData, affectPack.caster, cc.p(mapX, mapY), true)

					affectPack.summonMap[tile.tag] = nil
				end

				table.insert(currTiles, tile)

				local _units = tile:getUnitArr()

				for j, unit in ipairs(_units) do
					if unit.battleData and not unit.battleData.die and (not camp or unit.battleData.camp == camp) and not unit.noEntity and not alreadyTargets[unit.id] then
						alreadyTargets[unit.id] = true
						local dmgValue = nil

						if unit.beDamage and attackPack then
							dmgValue = unit:beDamage(attackPack)
						end

						SkillManager.hitEffect(unit, affectPack, dmgValue)

						hitted = true
					end
				end
			end
		end
	end

	if #currTiles > 0 then
		for i = 1, #affectPack.preTiles do
			local tile = affectPack.preTiles[i]
			affectPack.alreadyTiles[tile:getTag()] = true
		end

		affectPack.preTiles = currTiles
	end

	if hitted and affectType == 8 then
		MapFrameManager.stopLoop(affectPack, SkillManager.affectMultiTargets)

		if affectPack.missle then
			local effectGen = caster:getEffectGen()

			if effectGen then
				effectGen:missleStop(affectPack.missle)
			end

			affectPack.missle = nil
		end

		local targetAngle = math.atan2(target.y - caster.y, target.x - caster.x)
		local effectGen = caster:getEffectGen()

		if effectGen then
			effectGen:castEffect(skillData.affect_effect, hitPosition, nil, targetAngle)
		end
	end

	if affectSpeed > 0 then
		if affectPack.stepCount > 0 then
			affectPack.stepCount = affectPack.stepCount - passed
		elseif affectRange <= affectPack.stepRange then
			MapFrameManager.stopLoop(affectPack, SkillManager.affectMultiTargets)
		else
			affectPack.stepCount = affectPack.stepCount + map.ptPerTile / affectSpeed
		end
	end
end

function SkillManager.hitCasterEffect(unit, affectPack)
	local skillData = affectPack.skillData
	local caster = affectPack.caster
	local affectType = skillData.affect_type

	if not empty(skillData.knock_self) then
		local isReverse = true
		local position = affectPack.castPosition
		local angle = math.atan2(affectPack.target.y - affectPack.castPosition.y, affectPack.target.x - affectPack.castPosition.x)

		SkillManager.knock(unit, skillData.knock_self, position, angle, isReverse, function ()
			unit:removeTargetTile()
		end)
	end
end

function SkillManager.hitEffect(unit, affectPack, dmgValue)
	local skillData = affectPack.skillData
	local caster = affectPack.caster
	local affectType = skillData.affect_type

	if not empty(skillData.knock) or not empty(skillData.knock_to) then
		local position = affectPack.castPosition
		local angle = nil

		if affectType == 2 or affectType == 3 or affectType == 7 then
			position = affectPack.target
		end

		if affectType == 5 or affectType == 8 then
			angle = math.atan2(affectPack.target.y - affectPack.castPosition.y, affectPack.target.x - affectPack.castPosition.x)
		end

		if not unit.noKnock and not empty(skillData.knock) then
			SkillManager.knock(unit, skillData.knock, position, angle, false, function ()
				unit:removeTargetTile()
			end)
		end

		if not unit.noKnock and not empty(skillData.knock_to) then
			local distance = math.sqrt(math.pow(unit.x - position.x, 2) + math.pow(unit.y - position.y, 2))
			local knockArr = string.split(tostring(skillData.knock_to), ",")
			local knockDis = tonumber(knockArr[1]) - distance
			local knockStr = tostring(knockDis)

			for i = 2, 3 do
				if knockArr[i] then
					knockStr = knockStr .. "," .. knockArr[i]
				end
			end

			SkillManager.knock(unit, knockStr, position, angle, false, function ()
				unit:removeTargetTile()
			end)
		end
	end

	notify.dispatch("skill_hit", caster, unit, affectPack, dmgValue)
end

function SkillManager.knock(unit, knockStr, position, angle, isReverse, onComplete)
	local knockArr = string.split(tostring(knockStr), ",")
	local knockDis = tonumber(knockArr[1])
	local knockSpeed = tonumber(knockArr[2]) or 30
	local knockHeight = tonumber(knockArr[3]) or 20
	local mapX, mapY = SkillManager.getTileForKnock(unit, position.x, position.y, angle, knockDis, isReverse)

	if mapX then
		unit:stop(14)

		local preAngle = unit.angle

		unit:jump({
			x = mapX,
			y = mapY
		}, knockSpeed, knockHeight, onComplete, nil, , true)

		unit.angle = preAngle
	end
end

function SkillManager.getTileForKnock(unit, x, y, angle, dis, isReverse)
	local x1 = unit.x
	local y1 = unit.y
	angle = angle or math.atan2(y1 - y, x1 - x)

	if isReverse then
		angle = angle + math.pi
	end

	local x2 = math.cos(angle) * dis + x1
	local y2 = math.sin(angle) * dis + y1
	local tile = unit.map:mapToTile(x2, y2)

	if tile then
		if SkillManager.checkTileWalkable(unit, tile) then
			return x2, y2
		elseif tile and unit.tile then
			local los = MapUtils.getLos(unit.map, tile, unit.tile)

			for i = 1, #los do
				local tile2 = los[i]

				if tile2 and SkillManager.checkTileWalkable(unit, tile2) then
					return unit.map:tileToMap(tile2)
				end
			end
		end
	end
end

function SkillManager.checkTileWalkable(unit, tile)
	for x = tile.x, tile.x + unit.size - 1 do
		for y = tile.y, tile.y + unit.size - 1 do
			local _tile = unit.map:getTile(x, y)

			if _tile then
				if WarMachine.on then
					if not WarMachine.checkAreaTileMap(_tile) or not _tile:getWalkable(unit.walkLevel, unit) then
						return false
					end
				elseif not _tile:getWalkable(unit.walkLevel, unit) then
					return false
				end
			else
				return false
			end
		end
	end

	return true
end

function SkillManager.getRangeArea(caster, skillData, noNeedWar, fixedAdditionalRange)
	local tiles = {}
	local disabledTiles = {}
	local centerTile = caster.tile
	local size = (caster.size or 1) - 1
	local range = SkillManager.getRange(caster, skillData)

	if range > 0 then
		range = range + (fixedAdditionalRange or caster.additionalRange)
	end

	local map = caster.map
	local tileMap = nil

	if range < 0 then
		tileMap = WarMachine.getAreaTileMap()
	else
		tileMap = getRangeTilesDiamond(centerTile, range, size)
	end

	local _tiles = MapUtils.tileMapToArr(tileMap)

	for i, tile in ipairs(_tiles) do
		if noNeedWar or WarMachine.checkAreaTileMap(tile) then
			local legalTile = true
			local isOut = false

			if not empty(skillData.is_jump) then
				if caster:checkPathLimited(tile.tag) then
					if not SkillManager.isTileWalkable(tile, caster) then
						legalTile = false
					end
				else
					legalTile = false
					isOut = true
				end
			end

			if SkillManager.isSummon(skillData) and skillData.summon_entity > 0 and skillData.summon_time == SUMMON_TIME.AFFECT and not tile:isEmptyUnit() then
				legalTile = false
			end

			if legalTile then
				table.insert(tiles, tile)
			elseif not isOut then
				table.insert(disabledTiles, tile)
			end
		end
	end

	return tiles, disabledTiles
end

function SkillManager.isTileWalkable(tile, unit, noUnitBlock)
	local walkLevel = 1
	local preBlock = nil
	local size = 1

	if unit and unit.type ~= "modao" then
		walkLevel = unit.walkLevel
		preBlock = unit.isBlock
		unit.isBlock = false
		size = unit.size
	end

	local preUnitBlock = Map.NO_UNIT_BLOCK
	Map.NO_UNIT_BLOCK = noUnitBlock
	local result = true

	if size == 1 then
		result = tile:getWalkable(walkLevel, unit, true)
	else
		for i = 0, size - 1 do
			for j = 0, size - 1 do
				local tempTile = global.map:getTile(tile.x + i, tile.y + j)

				if tempTile ~= nil and not tempTile:getWalkable(walkLevel, unit, true) then
					result = false

					break
				end
			end

			if not result then
				break
			end
		end
	end

	if unit then
		unit.isBlock = preBlock
	end

	Map.NO_UNIT_BLOCK = preUnitBlock

	return result
end

function SkillManager.getAffectTiles(caster, skillData, targetTile, forceRange, isAuto)
	local map = caster.map
	local affectType = skillData.affect_type
	local affectRange = skillData.affect_range
	local size = (caster.size or 1) - 1
	local tiles = {}
	local affectPosition, affectInangle, affectWidth = nil

	if affectType ~= 6 and not targetTile then
		return tiles
	end

	if affectType == 1 then
		if WarMachine.checkAreaTileMap(targetTile) then
			tiles = {
				targetTile
			}
		end
	elseif affectType == 2 then
		affectRange = forceRange or affectRange
		local tileMap = getRangeTilesDiamond(targetTile, affectRange, size)
		local _tiles = MapUtils.tileMapToArr(tileMap)

		for i, tile in ipairs(_tiles) do
			if WarMachine.checkAreaTileMap(tile) then
				table.insert(tiles, tile)
			end
		end
	elseif affectType == 3 then
		affectRange = forceRange or affectRange

		for i = targetTile.x - affectRange, targetTile.x + affectRange + size do
			for j = targetTile.y - affectRange, targetTile.y + affectRange + size do
				local tile = map:getTile(i, j)

				if tile and WarMachine.checkAreaTileMap(tile) then
					table.insert(tiles, tile)
				end
			end
		end
	elseif affectType == 7 then
		affectRange = forceRange or affectRange

		if targetTile then
			local tileMap = getRangeTilesRound(targetTile, affectRange, size)
			local _tiles = MapUtils.tileMapToArr(tileMap)

			for i, tile in ipairs(_tiles) do
				if WarMachine.checkAreaTileMap(tile) then
					table.insert(tiles, tile)
				end
			end
		end
	elseif affectType == 4 then
		local centerX, centerY = caster:getGridCenter()
		local centerTile = caster:getCenterTile()
		local targetX, targetY = map:tileToMap(targetTile)
		local affectRangeArr = string.split(affectRange, ",")
		affectRange = forceRange or tonumber(affectRangeArr[1])
		affectInangle = tonumber(affectRangeArr[2]) * math.pi / 180 / 2

		local function getAreaTiles(centerAngle)
			local tiles = {}

			for i = centerTile.x - math.ceil(affectRange) - 1, centerTile.x + math.ceil(affectRange) + 1 do
				for j = centerTile.y - math.ceil(affectRange) - 1, centerTile.y + math.ceil(affectRange) + 1 do
					local tile = map:getTile(i, j)

					if tile then
						local tileX, tileY = map:tileToMap(tile)
						local angle = math.atan2(tileY - centerY, tileX - centerX)
						local distance = math.sqrt(math.pow(tileY - centerY, 2) + math.pow(tileX - centerX, 2))

						if (tileX == centerX and tileY == centerY or SkillManager.getInangle(angle, centerAngle) <= affectInangle and distance <= affectRange * map.ptPerTile) and WarMachine.checkAreaTileMap(tile) then
							table.insert(tiles, tile)
						end
					end
				end
			end

			return tiles
		end

		local centerAngle = math.atan2(targetY - centerY, targetX - centerX)
		local tiles1 = getAreaTiles(centerAngle)

		if skillData.select_type == 3 and not isAuto then
			local fixedAngle = math.round(centerAngle / (math.pi / 4)) * math.pi / 4
			local tiles2 = getAreaTiles(fixedAngle)
			tiles = SkillManager.compareTilesInclude(tiles1, tiles2) and tiles2 or tiles1
		else
			tiles = tiles1
		end
	elseif affectType == 5 or affectType == 8 then
		local centerX, centerY = caster:getGridCenter()
		local targetX, targetY = map:tileToMap(targetTile)
		local centerAngle = math.atan2(targetY - centerY, targetX - centerX)
		local affectRangeArr = string.split(affectRange, ",")
		affectRange = (forceRange or tonumber(affectRangeArr[1])) * map.ptPerTile
		affectWidth = tonumber(affectRangeArr[2]) * map.ptPerTile
		local x = centerX + math.cos(centerAngle) * affectRange
		local y = centerY + math.sin(centerAngle) * affectRange
		tiles = SkillManager.getLine({
			x = centerX,
			y = centerY
		}, {
			x = x,
			y = y
		}, affectWidth)
		affectPosition = cc.p(x, y)
	elseif affectType == 6 then
		local tileMap = WarMachine.getAreaTileMap()
		local _tiles = MapUtils.tileMapToArr(tileMap)

		for i, tile in ipairs(_tiles) do
			table.insert(tiles, tile)
		end
	end

	return tiles, affectPosition
end

function SkillManager.compareTilesInclude(tiles1, tiles2)
	local existMap = {}

	for i = 1, #tiles2 do
		existMap[tiles2[i].tag] = true
	end

	local includeAll = true

	for i = 1, #tiles1 do
		if not existMap[tiles1[i].tag] then
			includeAll = false

			break
		end
	end

	return includeAll
end

function SkillManager.getLine(pt1, pt2, width)
	local angle = math.atan2(pt2.y - pt1.y, pt2.x - pt1.x)
	local w = width / 2
	angle = angle + math.pi / 2
	local corner1 = {
		x = pt1.x + math.cos(angle) * w,
		y = pt1.y + math.sin(angle) * w
	}
	local corner2 = {
		x = pt2.x + math.cos(angle) * w,
		y = pt2.y + math.sin(angle) * w
	}
	angle = math.pi + angle
	local corner4 = {
		x = pt1.x + math.cos(angle) * w,
		y = pt1.y + math.sin(angle) * w
	}
	local x1 = corner2.x - corner1.x
	local y1 = corner2.y - corner1.y
	local x2 = corner4.x - corner1.x
	local y2 = corner4.y - corner1.y
	local rotateAngle = math.atan2(y1, x1)
	x1, y1 = SkillManager.rotatePoint(x1, y1, rotateAngle)
	x2, y2 = SkillManager.rotatePoint(x2, y2, rotateAngle)
	local areaTileMap = WarMachine.getAreaTileMap()
	local resultTiles = {}

	if areaTileMap then
		local _tiles = MapUtils.tileMapToArr(areaTileMap)

		for i, tile in ipairs(_tiles) do
			local x, y = global.map:tileToMap(tile)
			x = x - corner1.x
			y = y - corner1.y
			x, y = SkillManager.rotatePoint(x, y, rotateAngle)

			if x >= 0 and x <= x1 and y <= 0 and y2 <= y and WarMachine.checkAreaTileMap(tile) then
				table.insert(resultTiles, tile)
			end
		end
	end

	return resultTiles
end

function SkillManager.rotatePoint(x, y, angle)
	local len = math.sqrt(math.pow(x, 2) + math.pow(y, 2))
	local a = math.atan2(y, x) - angle
	x = math.round(math.cos(a) * len)
	y = math.round(math.sin(a) * len)

	return x, y
end

function SkillManager.getInangle(angle1, angle2)
	local inangle = math.abs(angle1 - angle2)

	if inangle > math.pi * 2 then
		inangle = inangle - math.floor(inangle / (math.pi * 2))
	end

	if math.pi < inangle then
		inangle = math.pi * 2 - inangle
	end

	return inangle
end

function SkillManager.getRange(caster, skillData)
	local range = skillData.range

	if skillData.type == 1 and range > 0 then
		range = range + caster.attrs.range_add
	end

	return range
end

function SkillManager.findRandomTile(caster, skillData, random)
	local tileMap = WarMachine.getAreaTileMap()
	local tileArr = {}

	if tileMap and caster.tile then
		local _tiles = MapUtils.tileMapToArr(tileMap)

		for i, tile in ipairs(_tiles) do
			if tile:getWalkable(caster.walkLevel, caster) then
				if skillData.range == -1 then
					table.insert(tileArr, tile)
				elseif math.abs(tile.x - caster.tile.x) <= skillData.range and math.abs(tile.y - caster.tile.y) <= skillData.range then
					table.insert(tileArr, tile)
				end
			end
		end
	end

	if #tileArr > 0 then
		if random then
			return tileArr[random:getInt(1, #tileArr)]
		else
			return tileArr[math.random(1, #tileArr)]
		end
	end
end

function SkillManager.findAutoSkillTarget(caster, skillData, battleTarget, exceptMap, lockTargets)
	exceptMap = exceptMap or {}
	local isReady = true
	local castTarget = nil

	if skillData.select_auto == 11 then
		castTarget = {
			x = caster.x,
			y = caster.y
		}

		return isReady, castTarget
	end

	local onlyNoTarget = true
	local affectCamp = 3 - (caster.battleData.camp or 1)
	local affectUnits = WarMachine.getUnitsByCamp(affectCamp)

	if affectUnits then
		for i, unit in ipairs(affectUnits) do
			if not unit.summonNoTarget then
				onlyNoTarget = false

				break
			end
		end
	end

	if skillData.select_type == 0 then
		local affectCamp = nil
		affectCamp = (skillData.friend == 0 or skillData.friend == 3) and 3 - (caster.battleData.camp or 1) or caster.battleData.camp or 1
		local affectUnits = nil

		if (skillData.friend == 0 or skillData.friend == 3) and lockTargets then
			affectUnits = lockTargets
		else
			affectUnits = WarMachine.getUnitsByCamp(affectCamp)
		end

		local affectTileMap = {}

		for i = 1, #affectUnits do
			local unit = affectUnits[i]

			if unit.tile then
				if unit.size and unit.size > 1 then
					for _x = unit.tile.x, unit.tile.x + unit.size - 1 do
						for _y = unit.tile.y, unit.tile.y + unit.size - 1 do
							local _tile = unit.map:getTile(_x, _y)

							if _tile then
								affectTileMap[_tile.tag] = true
							end
						end
					end
				else
					affectTileMap[unit.tile.tag] = true
				end
			end
		end

		local affectTiles = SkillManager.getAffectTiles(caster, skillData, caster.tile)
		local count = 0
		local distance = 0

		for i = 1, #affectTiles do
			if affectTileMap[affectTiles[i].tag] then
				count = count + 1
			end
		end

		if skillData.select_auto == 8 then
			if count == 0 then
				return false, nil
			end
		elseif skillData.select_auto == 9 and not empty(skillData.buff_1) then
			local buffData = CsvParser.getCsvData("buff", skillData.buff_1)

			if not empty(buffData.trigger_skill) then
				local triggerSkillData = CsvParser.getCsvData("skill", buffData.trigger_skill)
				local _affectTiles = SkillManager.getAffectTiles(caster, triggerSkillData, caster.tile)
				local _count = 0

				for i = 1, #_affectTiles do
					if affectTileMap[_affectTiles[i].tag] then
						_count = count + 1
					end
				end

				if _count == 0 then
					return false, nil
				end
			end
		end

		if count > 0 then
			castTarget = battleTarget
		end

		if not castTarget and SkillManager.isSummon(skillData) then
			castTarget = battleTarget
		end

		if not castTarget then
			local buffList = SheetUtil.getColumnList(skillData, {
				"buff_",
				"buff_target_",
				"buff_prob_"
			}, {
				"buffID",
				"buffTarget",
				"buffProb"
			})

			if #buffList > 0 then
				for i, v in ipairs(buffList) do
					if v.buffTarget == 2 then
						castTarget = battleTarget

						break
					end
				end
			end
		end
	elseif skillData.select_auto == 10 then
		if skillData.select_type == 1 then
			if skillData.friend == 0 or skillData.friend == 3 then
				if not battleTarget then
					local affectCamp = 3 - (caster.battleData.camp or 1)
					local affectUnits = WarMachine.getUnitsByCamp(affectCamp)
					local inrangeUnits = {}

					for i, unit in ipairs(affectUnits) do
						if (not unit.summonNoTarget or onlyNoTarget) and not exceptMap[unit.id] and caster:checkMeleeAndRangedTile(SkillManager.getRange(caster, skillData), unit, skillData.is_jump) then
							table.insert(inrangeUnits, unit)
						end
					end

					local bestUnit, bestDistance = nil

					for i, unit in ipairs(inrangeUnits) do
						local distance = math.sqrt(math.pow(unit.x - caster.x, 2) + math.pow(unit.y - caster.y, 2))

						if not bestDistance or distance < bestDistance then
							bestDistance = distance
							bestUnit = unit
						end
					end

					battleTarget = bestUnit
				end

				if not battleTarget then
					isReady = false
				else
					if exceptMap[battleTarget.id] or not caster:checkMeleeAndRangedTile(SkillManager.getRange(caster, skillData), battleTarget, skillData.is_jump) then
						isReady = false
					end

					if isReady then
						castTarget = battleTarget
					end
				end
			else
				local affectCamp = caster.battleData.camp or 1
				local affectUnits = WarMachine.getUnitsByCamp(affectCamp)
				local inrangeUnits = {}

				for i, unit in ipairs(affectUnits) do
					if not exceptMap[unit.id] and caster:checkMeleeAndRangedTile(SkillManager.getRange(caster, skillData), unit, skillData.is_jump) and not unit.summonNoTarget then
						table.insert(inrangeUnits, unit)
					end
				end

				local bestUnit = nil

				if skillData.is_heal == 1 then
					local bestHpPer = nil

					for i, unit in ipairs(inrangeUnits) do
						if not unit.attrs.no_heal then
							local hpPer = unit.battleData.hp / unit.attrs.hp

							if hpPer < 1 and (not bestUnit or hpPer < bestHpPer) then
								bestUnit = unit
								bestHpPer = hpPer
							end
						end
					end
				end

				castTarget = bestUnit
			end

			if not castTarget and caster.speed == 0 then
				local affectCamp = nil
				affectCamp = (skillData.friend == 0 or skillData.friend == 3) and 3 - (caster.battleData.camp or 1) or caster.battleData.camp or 1
				local affectUnits = nil

				if (skillData.friend == 0 or skillData.friend == 3) and lockTargets then
					affectUnits = lockTargets
				else
					affectUnits = WarMachine.getUnitsByCamp(affectCamp)
				end

				local bestDistance = nil

				for i, unit in ipairs(affectUnits) do
					if (not unit.summonNoTarget or onlyNoTarget) and not exceptMap[unit.id] and caster:checkMeleeAndRangedTile(SkillManager.getRange(caster, skillData), unit, skillData.is_jump) then
						local distance = math.abs(unit.x - caster.x) + math.abs(unit.y - caster.y)

						if not bestDistance or distance < bestDistance then
							castTarget = unit
							bestDistance = distance
						end
					end
				end
			end
		elseif skillData.select_type == 2 then
			local affectCamp = nil
			affectCamp = (skillData.friend == 0 or skillData.friend == 3) and 3 - (caster.battleData.camp or 1) or caster.battleData.camp or 1
			local affectUnits = nil

			if (skillData.friend == 0 or skillData.friend == 3) and lockTargets then
				affectUnits = lockTargets
			else
				affectUnits = WarMachine.getUnitsByCamp(affectCamp)
			end

			local affectTileMap = {}

			for i = 1, #affectUnits do
				local unit = affectUnits[i]

				if (not unit.summonNoTarget or onlyNoTarget) and unit.tile then
					if unit.size and unit.size > 1 then
						for _x = unit.tile.x, unit.tile.x + unit.size - 1 do
							for _y = unit.tile.y, unit.tile.y + unit.size - 1 do
								local _tile = unit.map:getTile(_x, _y)

								if _tile then
									affectTileMap[_tile.tag] = (affectTileMap[_tile.tag] or 0) + 1
								end
							end
						end
					else
						affectTileMap[unit.tile.tag] = (affectTileMap[unit.tile.tag] or 0) + 1
					end
				end
			end

			local battleArea = SkillManager.getRangeArea(caster, skillData)
			local bestCount, bestDistance, bestSelfDistance = nil

			for _, tile in ipairs(battleArea) do
				if SkillManager.isTileWalkable(tile, caster, true) then
					local affectTiles = SkillManager.getAffectTiles(caster, skillData, tile)
					local count = 0
					local distance = 0

					for i = 1, #affectTiles do
						if affectTileMap[affectTiles[i].tag] then
							count = count + affectTileMap[affectTiles[i].tag]
							distance = distance + math.abs(tile.x - affectTiles[i].x) + math.abs(tile.y - affectTiles[i].y)
						end
					end

					local selfDistance = math.abs(tile.x - caster.tile.x) + math.abs(tile.y - caster.tile.y)

					if count > 0 and (not bestCount or bestCount < count or count == bestCount and distance < bestDistance or count == bestCount and distance == bestDistance and selfDistance < bestSelfDistance) then
						bestCount = count
						bestDistance = distance
						bestSelfDistance = selfDistance
						local x, y = global.map:tileToMap(tile)
						castTarget = {
							x = x,
							y = y
						}
					end
				end
			end

			if not castTarget and SkillManager.isSummon(skillData) and #battleArea > 0 then
				local tile = battleArea[caster.warRandom:getInt(1, #battleArea)]
				local x, y = global.map:tileToMap(tile)
				castTarget = {
					x = x,
					y = y
				}
			end
		elseif skillData.select_type == 3 then
			local affectCamp = nil
			affectCamp = (skillData.friend == 0 or skillData.friend == 3) and 3 - (caster.battleData.camp or 1) or caster.battleData.camp or 1
			local affectUnits = nil

			if (skillData.friend == 0 or skillData.friend == 3) and lockTargets then
				affectUnits = lockTargets
			else
				affectUnits = WarMachine.getUnitsByCamp(affectCamp)
			end

			local affectTileMap = {}

			for i = 1, #affectUnits do
				local unit = affectUnits[i]

				if (not unit.summonNoTarget or onlyNoTarget) and unit.tile then
					if unit.size and unit.size > 1 then
						for _x = unit.tile.x, unit.tile.x + unit.size - 1 do
							for _y = unit.tile.y, unit.tile.y + unit.size - 1 do
								local _tile = unit.map:getTile(_x, _y)

								if _tile then
									affectTileMap[_tile.tag] = (affectTileMap[_tile.tag] or 0) + 1
								end
							end
						end
					else
						affectTileMap[unit.tile.tag] = (affectTileMap[unit.tile.tag] or 0) + 1
					end
				end
			end

			local samplingDistance = 2
			local bestCount, bestAngle = nil

			for tx = caster.tile.x - samplingDistance, caster.tile.x + samplingDistance do
				for ty = caster.tile.y - samplingDistance, caster.tile.y + samplingDistance do
					if tx ~= caster.tile.x or ty ~= caster.tile.y then
						local tile = global.map:getTile(tx, ty)

						if tile then
							local is8 = false

							if (math.abs(tx - caster.tile.x) > 1 or math.abs(ty - caster.tile.y) > 1) and (tx == caster.tile.x or ty == caster.tile.y or math.abs(tx) == math.abs(ty)) then
								is8 = true
							end

							if not is8 then
								local affectTiles = SkillManager.getAffectTiles(caster, skillData, tile, nil, true)
								local count = 0
								local meanAngle = 0
								local centerAngle = nil

								for i, targetTile in ipairs(affectTiles) do
									if affectTileMap[targetTile.tag] then
										count = count + affectTileMap[targetTile.tag]
										centerAngle = centerAngle or math.atan2(tile.y - caster.tile.y, tile.x - caster.tile.x)
										local targetAngle = math.atan2(targetTile.y - caster.tile.y, targetTile.x - caster.tile.x)
										local angleOffset = MathUtil.angleWithinPI(centerAngle - targetAngle)
										meanAngle = meanAngle + math.abs(angleOffset)
									end
								end

								if count > 0 and (not bestCount or bestCount < count or count == bestCount and meanAngle < bestAngle) then
									bestCount = count
									bestAngle = meanAngle
									local x, y = global.map:tileToMap(tile)
									castTarget = {
										x = x,
										y = y
									}
								end
							end
						end
					end
				end
			end
		end
	else
		local bestUnit, bestTile = nil

		if skillData.select_auto == 0 then
			if not battleTarget then
				local affectCamp = 3 - (caster.battleData.camp or 1)
				local affectUnits = WarMachine.getUnitsByCamp(affectCamp)
				local inrangeUnits = {}

				for i, unit in ipairs(affectUnits) do
					if (not unit.summonNoTarget or onlyNoTarget) and not exceptMap[unit.id] and caster:checkMeleeAndRangedTile(SkillManager.getRange(caster, skillData), unit, skillData.is_jump) then
						table.insert(inrangeUnits, unit)
					end
				end

				local bestUnit, bestDistance = nil

				for i, unit in ipairs(inrangeUnits) do
					local distance = math.sqrt(math.pow(unit.x - caster.x, 2) + math.pow(unit.y - caster.y, 2))

					if not bestDistance or distance < bestDistance then
						bestDistance = distance
						bestUnit = unit
					end
				end

				battleTarget = bestUnit
			end

			if battleTarget and not exceptMap[battleTarget.id] and caster:checkMeleeAndRangedTile(SkillManager.getRange(caster, skillData), battleTarget, skillData.is_jump) then
				bestUnit = battleTarget
			end
		else
			local affectCamp = nil
			affectCamp = (skillData.friend == 0 or skillData.friend == 3) and 3 - (caster.battleData.camp or 1) or caster.battleData.camp or 1
			local affectUnits = nil

			if (skillData.friend == 0 or skillData.friend == 3) and lockTargets then
				affectUnits = lockTargets
			else
				affectUnits = WarMachine.getUnitsByCamp(affectCamp)
			end

			if skillData.is_heal == 1 then
				local newAffectUnits = {}

				for i, unit in ipairs(affectUnits) do
					if unit.attrs and not unit.attrs.no_heal then
						table.insert(newAffectUnits, unit)
					end
				end

				affectUnits = newAffectUnits
			end

			if skillData.select_auto == 1 or skillData.select_auto == 2 then
				local bestDistance = nil

				for i = 1, #affectUnits do
					local unit = affectUnits[i]

					if (not unit.summonNoTarget or onlyNoTarget) and unit.tile and not exceptMap[unit.id] and caster:checkMeleeAndRangedTile(SkillManager.getRange(caster, skillData), unit, skillData.is_jump) then
						local distance = math.sqrt(math.pow(unit.x - caster.x, 2) + math.pow(unit.y - caster.y, 2))
						local isOK = false

						if not bestDistance then
							isOK = true
						elseif skillData.select_auto == 1 then
							if distance < bestDistance then
								isOK = true
							end
						elseif skillData.select_auto == 2 and bestDistance < distance then
							isOK = true
						end

						if isOK then
							bestDistance = distance
							bestUnit = unit
						end
					end
				end
			elseif skillData.select_auto == 3 then
				local units = {}

				for i = 1, #affectUnits do
					local unit = affectUnits[i]

					if (not unit.summonNoTarget or onlyNoTarget) and unit.tile and not exceptMap[unit.id] and caster:checkMeleeAndRangedTile(SkillManager.getRange(caster, skillData), unit, skillData.is_jump) then
						table.insert(units, unit)
					end
				end

				if #units > 0 then
					bestUnit = units[caster.warRandom:getInt(1, #units)]
				end
			elseif skillData.select_auto == 4 or skillData.select_auto == 5 then
				local bestHP = nil

				for i = 1, #affectUnits do
					local unit = affectUnits[i]

					if (not unit.summonNoTarget or onlyNoTarget) and unit.tile and not exceptMap[unit.id] and caster:checkMeleeAndRangedTile(SkillManager.getRange(caster, skillData), unit, skillData.is_jump) then
						local hpPer = unit.battleData.hp / unit.attrs.hp
						local isOK = false

						if not bestHP then
							isOK = true
						elseif skillData.select_auto == 4 then
							if hpPer < bestHP then
								isOK = true
							end
						elseif skillData.select_auto == 5 and bestHP < hpPer then
							isOK = true
						end

						if isOK then
							bestHP = hpPer
							bestUnit = unit
						end
					end
				end
			elseif skillData.select_auto == 14 or skillData.select_auto == 15 then
				local bestHP = nil

				for i = 1, #affectUnits do
					local unit = affectUnits[i]

					if (not unit.summonNoTarget or onlyNoTarget) and unit.tile and not exceptMap[unit.id] and caster:checkMeleeAndRangedTile(SkillManager.getRange(caster, skillData), unit, skillData.is_jump) then
						local hpAbs = unit.battleData.hp
						local isOK = false

						if not bestHP then
							isOK = true
						elseif skillData.select_auto == 14 then
							if hpAbs < bestHP then
								isOK = true
							end
						elseif skillData.select_auto == 15 and bestHP < hpAbs then
							isOK = true
						end

						if isOK then
							bestHP = hpAbs
							bestUnit = unit
						end
					end
				end
			elseif skillData.select_auto == 6 or skillData.select_auto == 7 then
				local affectCamp = nil
				affectCamp = (skillData.friend == 0 or skillData.friend == 3) and 3 - (caster.battleData.camp or 1) or caster.battleData.camp or 1
				local affectUnits = nil

				if (skillData.friend == 0 or skillData.friend == 3) and lockTargets then
					affectUnits = lockTargets
				else
					affectUnits = WarMachine.getUnitsByCamp(affectCamp)
				end

				local targetArr = {}

				if skillData.select_type == 1 then
					for i, unit in ipairs(affectUnits) do
						if (not unit.summonNoTarget or onlyNoTarget) and unit.tile and not exceptMap[unit.id] and caster:checkMeleeAndRangedTile(SkillManager.getRange(caster, skillData), unit, skillData.is_jump) then
							table.insert(targetArr, {
								type = "unit",
								tile = unit.tile,
								unit = unit
							})
						end
					end
				elseif skillData.select_type == 2 then
					local battleArea = SkillManager.getRangeArea(caster, skillData)

					for i, v in ipairs(battleArea) do
						if SkillManager.isSummon(skillData) or v:isEmpty() then
							table.insert(targetArr, {
								type = "tile",
								tile = v
							})
						end
					end
				end

				local bestDistance, bestSelfDistance, bestObj = nil

				for _, obj in ipairs(targetArr) do
					local tile = obj.tile
					local squareSum = 0

					for i, unit in ipairs(affectUnits) do
						if unit.tile then
							squareSum = squareSum + math.pow(tile.x - unit.tile.x, 2) + math.pow(tile.y - unit.tile.y, 2)
						end
					end

					local selfDistance = math.abs(tile.x - caster.tile.x) + math.abs(tile.y - caster.tile.y)

					if skillData.select_auto == 6 then
						if not bestDistance or squareSum < bestDistance or squareSum == bestDistance and selfDistance < bestSelfDistance then
							bestDistance = squareSum
							bestSelfDistance = selfDistance
							bestObj = obj
						end
					elseif skillData.select_auto == 7 and (not bestDistance or bestDistance < squareSum or squareSum == bestDistance and selfDistance < bestSelfDistance) then
						bestDistance = squareSum
						bestSelfDistance = selfDistance
						bestObj = obj
					end
				end

				if bestObj then
					if bestObj.type == "tile" then
						bestTile = bestObj.tile
					elseif bestObj.type == "unit" then
						bestUnit = bestObj.unit
					end
				end
			end
		end

		if bestUnit then
			isReady = true

			if skillData.select_type == 1 then
				castTarget = bestUnit
			else
				local x, y = global.map:tileToMap(bestUnit.tile)
				castTarget = {
					x = x,
					y = y
				}
			end
		end

		if bestTile then
			local x, y = global.map:tileToMap(bestTile)
			castTarget = {
				x = x,
				y = y
			}
		end
	end

	if not castTarget then
		isReady = false
	end

	return isReady, castTarget
end

function SkillManager.getBuffTotalValue(skillPack)
	local skillData = affectPack.skillData
	local attackPack = affectPack.attackPack
	local basePosition = affectPack.basePosition
	local caster = affectPack.caster
	local map = caster.map
	local target = affectPack.target
	local affectType = skillData.affect_type
	local affectRange = skillData.affect_range
	local affectSpeed = skillData.affect_speed
end

function SkillManager.checkPower(skillPack, frameTime)
	local skillData = skillPack.data

	if skillData.power_type == 0 then
		return true
	elseif skillData.power_type == 1 then
		return skillPack.powerValue <= frameTime - skillPack.power
	else
		return skillPack.powerValue <= skillPack.power
	end
end

function SkillManager.resetPower(caster, skillPack, frameTime, isInit)
	local skillData = skillPack.data

	if skillData.power_type == 0 then
		-- Nothing
	elseif skillData.power_type == 1 then
		skillPack.power = frameTime
	else
		skillPack.power = 0
	end

	if isInit and not empty(skillData.power_init) then
		skillPack.power = skillData.power_init or 0
	end

	skillPack.powerValue = SheetUtil.getNumber(skillData.power_value, caster.warRandom)
end

function SkillManager.addPowerTimes(skillPack, type)
	local skillData = skillPack.data

	if skillData and skillData.power_type == type then
		skillPack.power = skillPack.power + 1
	end
end

function SkillManager.addWarning(caster, target, skillPack)
	local skillData = skillPack.data
	local affectRange = skillData.affect_range
	local affectType = skillData.affect_type
	local targetTile = global.map:mapToTile(target)

	if affectType == 0 or affectType == 1 then
		targetTile = global.map:mapToTile(target)
	end

	local affectTiles = SkillManager.getAffectTiles(caster, skillData, targetTile, affectRange)
	local assetsTag = "skill_" .. skillData.id .. "_warning_" .. caster.tag
	local result = {
		tag = assetsTag,
		tiles = {}
	}

	for i, tile in ipairs(affectTiles) do
		if WarMachine.checkAreaTileMap(tile) then
			tile:openAsset("warning", "skill_" .. skillData.id .. "_warning_" .. caster.tag)
			table.insert(result.tiles, tile)
		end
	end

	return result
end

function SkillManager.removeWarning(result)
	for i, tile in ipairs(result.tiles) do
		tile:closeAsset("warning", result.tag)
	end
end

function SkillManager.buffTriggerCD(unit, skillPack)
	local skillData = skillPack.data
	local buffMap = {}
	local buffs = nil

	if skillData.type == 1 then
		buffs = unit:triggerBuff(CombatUnit.BUFF_TIMING.ATTACK_REPLACE)
	elseif skillData.type == 2 then
		buffs = unit:triggerBuff(CombatUnit.BUFF_TIMING.SKILL_REPLACE)
	end

	if buffs then
		for i, v in ipairs(buffs) do
			buffMap[v.pack] = v
		end
	end

	buffs = nil

	if skillData.type == 1 then
		buffs = unit:triggerBuff(CombatUnit.BUFF_TIMING.ATTACK_MULTIPLE)
	elseif skillData.type == 2 then
		buffs = unit:triggerBuff(CombatUnit.BUFF_TIMING.SKILL_MULTIPLE)
	end

	if buffs then
		for i, v in ipairs(buffs) do
			buffMap[v.pack] = v
		end
	end

	buffs = unit:triggerBuff(CombatUnit.BUFF_TIMING.KNOCK)

	if buffs then
		for i, v in ipairs(buffs) do
			buffMap[v.pack] = v
		end
	end

	for k, v in pairs(buffMap) do
		local buffPack = v.pack
		local buffCSV = buffPack.data

		if not empty(buffCSV.trigger_cd) then
			local fullFrameTime = WarMachine.getFrame()
			buffPack.cd = fullFrameTime + buffCSV.trigger_cd
		end
	end
end

function SkillManager.getSkillData(unit, skillPack)
	local skillData = skillPack.data
	local buffs = nil

	if skillData.type == 1 then
		buffs = unit:triggerBuff(CombatUnit.BUFF_TIMING.ATTACK_REPLACE)
	elseif skillData.type == 2 then
		buffs = unit:triggerBuff(CombatUnit.BUFF_TIMING.SKILL_REPLACE)
	end

	if buffs then
		for i, v in ipairs(buffs) do
			local buffPack = v.pack
			local buffCSV = buffPack.data
			local skillID = buffCSV.trigger_skill
			local _skillData = CsvParser.getCsvData("skill", skillID)
			skillData = _skillData
		end
	end

	local newSkillData = nil
	buffs = nil

	if skillData.type == 1 then
		buffs = unit:triggerBuff(CombatUnit.BUFF_TIMING.ATTACK_MULTIPLE)
	elseif skillData.type == 2 then
		buffs = unit:triggerBuff(CombatUnit.BUFF_TIMING.SKILL_MULTIPLE)
	end

	if buffs then
		for i, v in ipairs(buffs) do
			local buffPack = v.pack
			local buffCSV = buffPack.data
			newSkillData = newSkillData or ObjUtil.copy(skillData)
			local value1Str = SheetUtil.getString(buffCSV.trigger_value_1, unit.warRandom)

			if empty(newSkillData.multiple) then
				newSkillData.multiple = value1Str
			else
				local valueArr = string.split(value1Str, ",")
				local multipleArr = string.split(newSkillData.multiple, ",")

				if string.find(multipleArr[1], "~") then
					local ranArr = string.split(multipleArr[1], "~")
					ranArr[1] = tonumber(ranArr[1]) * tonumber(valueArr[1])
					ranArr[2] = tonumber(ranArr[2]) * tonumber(valueArr[1])
					multipleArr[1] = ranArr[1] .. "~" .. ranArr[2]
				else
					multipleArr[1] = tonumber(multipleArr[1]) * tonumber(valueArr[1])
				end

				if multipleArr[2] then
					newSkillData.multiple = multipleArr[1] .. "," .. multipleArr[2]
				else
					newSkillData.multiple = multipleArr[1]
				end
			end
		end
	end

	buffs = nil
	buffs = unit:triggerBuff(CombatUnit.BUFF_TIMING.KNOCK)

	if buffs then
		for i, v in ipairs(buffs) do
			local buffPack = v.pack
			local buffCSV = buffPack.data
			newSkillData = newSkillData or ObjUtil.copy(skillData)
			newSkillData.knock = buffCSV.trigger_value_1
		end
	end

	if newSkillData then
		skillData = newSkillData
	end

	return skillData
end

function SkillManager.onBattleStart()
end

function SkillManager.cast(skillData, skillPack, attrs, target, caster, castPosition)
	local affectPack = {
		skillData = skillData,
		attackPack = DamageRule.generateAttackPack(caster, attrs, skillData, skillPack),
		preTiles = {},
		alreadyTiles = {},
		alreadyTargets = {},
		caster = caster,
		castPosition = castPosition
	}

	if caster and caster.x then
		affectPack.basePosition = cc.p(caster.x, caster.y)
	end

	if castPosition then
		affectPack.castPosition = castPosition
	elseif caster and caster.x then
		affectPack.castPosition = cc.p(caster.x, caster.y)
	end

	if skillData.select_type == 0 then
		affectPack.target = caster

		SkillManager.skillAffect(affectPack)
	elseif skillData.select_type == 1 then
		affectPack.target = target

		if skillData.is_fly == 1 then
			if caster and caster.getEffectGen then
				local effectGen = caster:getEffectGen()

				if effectGen then
					effectGen:castEffect(skillData.fly_effect, target, function ()
						SkillManager.skillAffect(affectPack)
					end, nil, caster)
				end
			end
		else
			SkillManager.skillAffect(affectPack)
		end
	elseif skillData.select_type == 2 then
		affectPack.target = {
			x = target.x,
			y = target.y
		}

		if skillData.is_fly == 1 then
			if caster and caster.getEffectGen then
				local effectGen = caster:getEffectGen()

				if effectGen then
					effectGen:castEffect(skillData.fly_effect, affectPack.target, function ()
						SkillManager.skillAffect(affectPack)
					end, nil, caster)
				end
			end
		else
			SkillManager.skillAffect(affectPack)
		end
	elseif skillData.select_type == 3 and caster then
		local angle = math.atan2(target.y - caster.y, target.x - caster.x)
		affectPack.target = {
			x = target.x,
			y = target.y,
			angle = angle
		}

		SkillManager.skillAffect(affectPack)
	end

	return affectPack
end

local dotFinBuffsCache = {}

function SkillManager.getDotFinBuffs(fin_buff)
	if not dotFinBuffsCache[fin_buff] then
		local arr = {}
		local fin_buff_arr = string.split(fin_buff, ",")
		local fin_buff_map = {}

		for i, fin_type in ipairs(fin_buff_arr) do
			fin_buff_map[tonumber(fin_type)] = true
		end

		local csvList = CsvParser.getCsvList("buff")

		for i, csv in ipairs(csvList) do
			if fin_buff_map[csv.dot_fin_type] then
				table.insert(arr, csv.id)
			end
		end

		dotFinBuffsCache[fin_buff] = arr

		print("$$$ dotFinBuffsCache", fin_buff, #arr)
	end

	return dotFinBuffsCache[fin_buff]
end

local noneAttrBuffCache = {}

function SkillManager.isNoneAttrBuff(buffID)
	return noneAttrBuffCache[buffID]
end

function SkillManager.markNoneAttrBuff(buffID)
	noneAttrBuffCache[buffID] = true
end

local noneAvatarBuffCache = {}

function SkillManager.isNoneAvatarBuff(buffID)
	return noneAvatarBuffCache[buffID]
end

function SkillManager.markNoneAvatarBuff(buffID)
	noneAvatarBuffCache[buffID] = true
end

local avatarBuffCache = {}

function SkillManager.isAvatarBuff(buffID)
	return avatarBuffCache[buffID]
end

function SkillManager.markAvatarBuff(buffID)
	avatarBuffCache[buffID] = true
end

return SkillManager
