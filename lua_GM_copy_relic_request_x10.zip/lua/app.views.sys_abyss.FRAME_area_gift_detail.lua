local FRAME_area_gift_detail = class("FRAME_area_gift_detail", UI_base)

function FRAME_area_gift_detail.open(areaID)
	local giftCSV, onceCSV, dayLeft = InfoAbyssArea.getGift(areaID)

	if giftCSV and InfoOrder.getOnce(onceCSV.id) == 0 then
		local ui = FRAME_area_gift_detail.new(areaID, giftCSV, onceCSV, dayLeft)

		PopManager.open(ui)
	end
end

function FRAME_area_gift_detail:ctor(areaID, giftCSV, onceCSV, dayLeft)
	FRAME_area_gift_detail.super.ctor(self, "frame_area_gift_detail", UIManager.BIG_TYPE.POP)

	self.areaID = areaID

	self:init(giftCSV, onceCSV, dayLeft)
end

function FRAME_area_gift_detail:init(giftCSV, onceCSV, dayLeft)
	self:initUI(giftCSV, onceCSV, dayLeft)
	ManagerInfo.onDataChange(self, "order", nil, function ()
		local giftCSV, onceCSV, dayLeft = InfoAbyssArea.getGift(self.areaID)

		if not giftCSV or InfoOrder.getOnce(onceCSV.id) ~= 0 then
			PopManager.closeTo(self)
		end
	end)
end

function FRAME_area_gift_detail:initUI(giftCSV, onceCSV, dayLeft)
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()
	self:createLabelOnFlag("flag_name", onceCSV.goods_name)
	self:createIconOnFlag("flag_icon", IconManager.getIcon("image/pic/item/icon/" .. giftCSV.pic .. ".png"), 100, true)
	self:replaceLabelOnFlag("flag_day_left", nil, dayLeft)

	local itemList = SheetUtil.getColumnList(onceCSV, {
		"product_id",
		"product_num"
	}, {
		"base_id",
		"num"
	})
	local flag = self:getFlagByTag("flag_list")
	flag.width = flag.width + (#itemList - 1) * 120
	flag.x = flag.x + (#itemList - 1) * 120 / 2
	local rewardList = self:createListOnFlag("flag_list", LIST_area_gift)

	rewardList:setItems(itemList)

	local bt_pay = self:getComponentByTag("bt_pay")

	bt_pay:toTouchable()
	bt_pay:setTapGroup("button_click")
	bt_pay:addTap(function ()
		InfoOrder.order(onceCSV, function ()
			PopManager.closeTo(self)
		end)
	end)

	local rmb_cost = InfoOrder.getCost(onceCSV.rmb_type, onceCSV.id)

	self:removeLabelOnFlag("flag_rmb_cost")

	if global.pay_open ~= 1 then
		self:createLabelOnFlag("flag_rmb_cost", Localization.getSrcText("暂未开放"))
		Shader.gray(bt_pay)
	else
		self:replaceLabelOnFlag("flag_rmb_cost", nil, rmb_cost, InfoOrder.getCurrencyCode())
	end
end

return FRAME_area_gift_detail
