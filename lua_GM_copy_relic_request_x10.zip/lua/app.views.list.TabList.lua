local List = import("...ui.List")
local TabList = class("TabList", List)

function TabList:ctor(rect, cellName, cellSpace, onSelect, onCellInit, datas, direction)
	TabList.super.ctor(self, rect, direction)
	self:setSelectEnabled(true)

	self.isBounc = false

	self:setCellName(cellName)

	if direction == List.DIRECTION_HORIZONTAL then
		self:setCellSize(cc.size(cellSpace, self.touchRect.height))
	else
		self:setCellSize(cc.size(self.touchRect.width, cellSpace))
	end

	self.onCellInitCustom = onCellInit
	self.onSelectCustom = onSelect

	if datas then
		self:setItems(datas)
	end
end

function TabList:onCellInit(ui, data)
	if self.onCellInitCustom then
		self.onCellInitCustom(ui, data)
	end

	self:onCellSelected(ui, data, false)
end

function TabList:onCellSelected(ui, data, selected)
	local bg = ui:getComponentByTag("bg")
	local bgSelected = ui:getComponentByTag("bg_selected")

	if bg then
		if bgSelected then
			bgSelected:setVisible(selected)
			bg:setVisible(not selected)
		else
			bg:setFrame(selected and 2 or 1)
		end
	end

	if selected and self.onSelectCustom then
		self.onSelectCustom(ui, data, self.selectedIndex)
	end

	local _selected = ui:getComponentByTag("selected")
	local _unselected = ui:getComponentByTag("unselected")

	if _selected and _unselected then
		_selected:setVisible(selected)
		_unselected:setVisible(not selected)
	end
end

return TabList
