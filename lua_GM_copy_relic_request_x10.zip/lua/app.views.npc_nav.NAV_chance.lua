local NAV_base = import(".NAV_base")
local NAV_chance = class("NAV_chance", NAV_base)

function NAV_chance.open(npc)
	local ui = NAV_chance.new(npc)

	return ui
end

function NAV_chance:ctor(npc)
	NAV_chance.super.ctor(self, npc, "nav_chance")
end

function NAV_chance:init()
	NAV_chance.super.init(self)

	local index = 1
	local ui = self.buttons[index].ui
	local button = self.buttons[index].button

	self:setButtonName(ui, self.npc.data.nav_text)

	if self.npc.data.type == 13 or self.npc.data.type == 14 then
		local eventData = self.npc.eventData
		local eventInfo = InfoDungeon.getEventInfo(eventData.index)

		if not empty(self.npc.data.read_time) and self.npc.data.read_time > 0 and eventInfo.fin == 0 then
			self:openTouch()

			self.readTime = self.npc.data.read_time
		end
	elseif not empty(self.npc.data.read_time) and self.npc.data.read_time > 0 then
		self:openTouch()
	end

	if not empty(self.npc.data.show_desc) then
		self:addButtonInfo(1, self.npc.data.show_desc)
	end
end

function NAV_chance:onTap(index)
	NAV_chance.super.onTap(self, index)

	if index == 1 then
		if self.npc.data.type == 13 or self.npc.data.type == 14 then
			local eventData = self.npc.eventData
			local eventInfo = InfoDungeon.getEventInfo(eventData.index)

			if not self.readTime or eventInfo.fin == 1 then
				if global.player then
					global.player:faceTo(self.npc)
				end

				self.npc:openChance()
			end
		elseif empty(self.npc.data.read_time) then
			if global.player then
				global.player:faceTo(self.npc)
			end

			if not self.npc:checkChance() then
				return
			end

			self.npc:openChance()
		end
	end
end

function NAV_chance:onTouch(event, index)
	NAV_chance.super.onTouch(self, event, index)

	if index == 1 then
		if self.npc.data.type == 13 or self.npc.data.type == 14 then
			local eventData = self.npc.eventData
			local eventInfo = InfoDungeon.getEventInfo(eventData.index)

			if self.readTime and eventInfo.fin == 0 then
				if event == "began" and global.player then
					global.player:faceTo(self.npc)
				end

				self:onRead(event, self.npc.data.read_msg, self.npc.data.read_sfx, self.npc.data.read_over_sfx, function ()
					if self.npc then
						self.npc:openChance()
					end
				end)
			end
		elseif not empty(self.npc.data.read_time) and self.npc.data.read_time > 0 then
			if event == "began" then
				if global.player then
					global.player:faceTo(self.npc)
				end

				if not self.npc:checkChance() then
					return
				end
			end

			self:onRead(event, self.npc.data.read_msg, self.npc.data.read_sfx, self.npc.data.read_over_sfx, function ()
				if self.npc then
					self.npc:openChance()
				end
			end)
		end
	end
end

return NAV_chance
