local POP_curtain = class("POP_curtain", UI_base)
local instance = nil

function POP_curtain.clear()
	instance = nil
end

function POP_curtain.open(dramaType)
	print("$$$ POP_curtain.open", dramaType, instance)

	if not instance then
		instance = POP_curtain.new(dramaType)

		display.getRunningScene():addChild(instance, LayerConfig.curtain)
		instance:instanceOpen()
		POP_drama.open(instance.topHeight)
	end
end

function POP_curtain.close()
	print("$$$ POP_curtain.close", instance)

	if instance then
		instance:instanceClose()

		instance = nil

		POP_drama.close()
	end
end

function POP_curtain:ctor(dramaType)
	POP_curtain.super.ctor(self, "pop_curtain")

	self.dramaType = dramaType

	self:init()
end

function POP_curtain:init()
	self:initUI()
end

function POP_curtain:initUI()
	local top = self:getComponentByTag("top")
	local bottom = self:getComponentByTag("bottom")

	top:toTouchable()
	bottom:toTouchable()

	if self.dramaType == 2 then
		top:setOpacity(0)
		bottom:setOpacity(0)
	end

	top.oY = top:getPositionY()
	bottom.oY = bottom:getPositionY()
	self.topHeight = top.height
end

function POP_curtain:instanceOpen()
	local top = self:getComponentByTag("top")
	local bottom = self:getComponentByTag("bottom")
	local topHeight = top.height
	local bottomHeight = bottom.height

	transition.moveTo(top, {
		easing = "sineOut",
		time = 0.2,
		y = top.oY - topHeight
	})
	transition.moveTo(bottom, {
		easing = "sineOut",
		time = 0.2,
		y = bottom.oY + bottomHeight
	})
end

function POP_curtain:instanceClose()
	local top = self:getComponentByTag("top")
	local bottom = self:getComponentByTag("bottom")

	transition.moveTo(top, {
		easing = "sineOut",
		time = 0.2,
		y = display.height + top.height / 2,
		onComplete = function ()
			self:removeSelf()
		end
	})
	transition.moveTo(bottom, {
		easing = "sineOut",
		time = 0.2,
		y = -bottom.height / 2
	})
end

function POP_curtain:onExit()
	POP_curtain.super.onExit(self)

	instance = nil
end

return POP_curtain
