local Tile = import(".Tile")
local Rantile = import(".Rantile")
local Astar = import("..astar.Astar")
local Astar = import("..astar.Astar")
local Map = class("Map", function ()
	local node = display.newNode()

	return node
end)
local TYPE = {
	FIXTILE = 3,
	RANTILE = 2,
	SINGLE = 1
}
Map.TYPE = TYPE
Map.TOP_90 = 0
Map.TOP_45 = 1
Map.TOP_45_Z = 2
Map.NO_UNIT_BLOCK = false
Map.NO_FORCE_WALK = false
Map.walkOnVislble = true
Map.NO_BORDER = false
Map.assets = nil

function Map:ctor(width, height, isFake)
	event_listener.extendMethods(self)
	self:setNodeEventEnabled(true)

	width = width or display.width
	height = height or display.height
	self.width = width
	self.height = height

	if isFake then
		self:initFake()
	else
		self:init()
	end
end

function Map:init()
	self.tilemap = tiled.Tilemap:new(self.width, self.height)

	self.tilemap:setTouchSwallowEnabled(false)
	self:addChild(self.tilemap)

	self.x = 0
	self.y = 0
	self.zoom = 1
	self.viewZoom = 1
	self.battleZoom = 1
	self.config = {
		light = {
			ratio = 1,
			decay = 1.5,
			radius = 1.7,
			min = 0.2,
			color_rgb = "",
			color_base = 1,
			gradual = 5
		},
		scale = {
			range = 4,
			unit = 1.4,
			battle = 1.3,
			map = 1.2
		},
		pathfinding = {
			smoothLevel = 0
		},
		engine = {
			bottom_buff = 5,
			top_buff = 0,
			side_buff = 0,
			onepiece = 0,
			fov_mode = 1,
			bottom_cut = 0
		},
		online = 0
	}
	self.gamma = 0
	self.astar = Astar.new(self)
	self.positionOffset = {
		y = 0,
		x = 0
	}
	self.fovPosition = {
		y = 0,
		x = 0
	}
	self.fovOffset = {
		y = 0,
		x = 0
	}
	self.tileLightDirty = {}

	MapFrameManager.setMap(self)
	MapEffect.setMap(self)
end

function Map:initFake()
	self.isFake = true
	self.x = 0
	self.y = 0
	self.zoom = 1
	self.viewZoom = 1
	self.config = {
		light = {
			ratio = 1,
			decay = 1.5,
			radius = 1.7,
			min = 0.2,
			color_rgb = "",
			color_base = 1,
			gradual = 5
		},
		scale = {
			battle_range = 4,
			unit = 1.4,
			battle = 1.3,
			map = 1
		},
		pathfinding = {
			smoothLevel = 1
		},
		engine = {
			bottom_buff = 5,
			top_buff = 0,
			side_buff = 0,
			onepiece = 0,
			fov_mode = 1,
			bottom_cut = 0
		},
		online = 0
	}
	self.positionOffset = {
		y = 0,
		x = 0
	}
	self.fovPosition = {
		y = 0,
		x = 0
	}
	self.fovOffset = {
		y = 0,
		x = 0
	}
	self.tileLightDirty = {}
	local log = Log.startMeter("Map:load")
	local mapObj = JsonParser.parseStr(jsonStr, true)
	self.params = {}
	self.name = ""
	self.ptPerTile = 96
	self.topType = Map.TOP_45
	self.solidW = 1
	self.solidH = 1
	self.tileW = 1
	self.tileH = 1

	if self.topType == Map.TOP_90 then
		self.scrollWidth = self.tileW * self.ptPerTile
		self.scrollHeight = self.tileH * self.ptPerTile
	elseif self.topType == Map.TOP_45 then
		self.scrollWidth = (self.tileW + self.tileH) * self.ptPerTile / 2
		self.scrollHeight = (self.tileW + self.tileH) * self.ptPerTile / 4
	else
		self.scrollWidth = self.solidW * self.ptPerTile
		self.scrollHeight = self.solidH * self.ptPerTile / 2 - self.ptPerTile / 4
	end

	self:setBorderLines({})
	self:resetArea()

	self.shadowLayer = display.newNode()

	self:addChild(self.shadowLayer)

	self.lightLayer = display.newNode()

	self:addChild(self.lightLayer)

	self.lowLayer = display.newNode()

	self:addChild(self.lowLayer)

	self.baseLayer = display.newNode()

	self:addChild(self.baseLayer)

	self.highLayer = display.newNode()

	self:addChild(self.highLayer)

	self.hudHighLayer = display.newNode()

	self:addChild(self.hudHighLayer)

	self.tileLayer = display.newNode()

	self:addChild(self.tileLayer)

	self.maskLayer = display.newNode()

	self:addChild(self.maskLayer)

	self.colorMaskMap = {}

	self:setCascadeOpacityEnabled(true)
	self.shadowLayer:setCascadeOpacityEnabled(true)
	self.lightLayer:setCascadeOpacityEnabled(true)
	self.lowLayer:setCascadeOpacityEnabled(true)
	self.baseLayer:setCascadeOpacityEnabled(true)
	self.highLayer:setCascadeOpacityEnabled(true)
	self.hudHighLayer:setCascadeOpacityEnabled(true)
	self.tileLayer:setCascadeOpacityEnabled(true)
	self.maskLayer:setCascadeOpacityEnabled(true)

	self.tiles = {}

	for x = 0, self.tileW - 1 do
		for y = 0, self.tileH - 1 do
			local tag = x .. "_" .. y
			self.tiles[tag] = Tile.new(self, x, y)
		end
	end

	log.markMeter("lua load")
	log.markMeter("init event")
	self:setZoom(self.config.scale.map)
	log.markMeter("ready")
end

function Map:initMask()
	self.mask = display.newSprite("#map_assets_map_mask")

	self.mask:setColor(cc.c3b(0, 0, 0))
	self.maskLayer:addChild(self.mask)
	self:refreshMaskConfig()
end

function Map:setMaskColor(color)
	self.mask:setColor(color)
end

function Map:setLightMask(opacity, color, srcBlend, dstBlend)
	if not self.lightMask then
		self.lightMask = display.newSprite("#map_assets_light_mask")

		self.lightMask:setScaleX(display.width / 32 * 1.2)
		self.lightMask:setScaleY(display.height / 32 * 1.2)
		self.lightMask:setPosition(display.width / 2, display.height / 2)
		self:addChild(self.lightMask, 1000)
	end

	self.lightMask:setOpacity(opacity)

	if color then
		self.lightMask:setColor(color)
	end

	self.lightMask:setBlendFunc(srcBlend or gl.DST_COLOR, dstBlend or gl.ONE)
end

function Map:clearLightMask()
	if self.lightMask then
		self.lightMask:removeSelf()

		self.lightMask = nil
	end
end

function Map:setMaskPosition(x, y)
	if self.mask then
		local drawX, drawY = self:mapToDraw(x, y)

		self.mask:setPosition(drawX, -drawY)
	end
end

function Map:refreshMaskConfig()
	if self.mask then
		local opacity = math.pow(1 - self.config.light.min, 2) * 255

		if self.gamma and self.gamma > 0 then
			opacity = opacity * (1 - self.gamma / 3)
		end

		self.mask:setOpacity(opacity)

		local scale = self.height / self.zoom * math.max(1, self.config.light.radius) / 100

		self.mask:setScaleX(scale * 2)
		self.mask:setScaleY(scale)
	end
end

function Map:addColorMask(tag, x, y, vc3b, radius, alpha)
	local mask = display.newSprite("#map_assets_color_mask")

	mask:setColor(vc3b)
	mask:setOpacity(alpha * 255 / 2)
	mask:setScale(radius)

	local drawX, drawY = self:mapToDraw(x, y)

	mask:setPosition(drawX, -drawY)
	self.lightLayer:addChild(mask, -100)
	mask:setBlendFunc(gl.DST_COLOR, gl.ONE)

	self.colorMaskMap[tag] = mask

	return mask
end

function Map:changeColorMask(tag, x, y, alpha)
	if self.colorMaskMap[tag] then
		local mask = self.colorMaskMap[tag]
		local drawX, drawY = self:mapToDraw(x, y)

		mask:setPosition(drawX, -drawY)
		mask:setOpacity(alpha * 255 / 2)
	end
end

function Map:removeColorMask(tag)
	if self.colorMaskMap[tag] then
		self.colorMaskMap[tag]:removeSelf()

		self.colorMaskMap[tag] = nil
	end
end

function Map.loadAssets()
	if Map.assets == nil then
		local texture = getFinalRes("res/map_assets/texture.png")
		local plist = getFinalRes("res/map_assets/texture.plist")

		tiled.Tilemap:loadAssets(texture, plist)

		Map.assets = {
			texture = texture,
			plist = plist
		}
	end
end

function Map:setGamma(gamma)
	self.gamma = gamma or 0

	self:recoverConfig()
	self:refreshMaskConfig()
end

function Map:setConfig(obj, time, easing)
	if empty(easing) then
		easing = "linear"
	end

	if time and time > 0 then
		local currentConfig = ObjUtil.deepObjToKV(self.config, "_", "config")
		local finalConfig = ObjUtil.deepObjToKV(obj, "_", "config")
		local startConfig = {}

		for k, v in pairs(finalConfig) do
			if type(v) ~= "string" then
				startConfig[k] = currentConfig[k]
			else
				finalConfig[k] = nil
			end
		end

		local function onComplete()
			ObjUtil.deepCoverValue(obj, self.config)

			local configMap = ObjUtil.deepObjToKV(self.config, "_", "config")

			for k, v in pairs(configMap) do
				if k == "config_light_min" and self.gamma and self.gamma > 0 then
					v = 1 - (1 - v) * (1 - self.gamma / 2)
				end

				self.tilemap:setConfig(k, v)
			end

			self:refreshMaskConfig()
		end

		local function onUpdate()
			local configMap = ObjUtil.deepObjToKV(startConfig, "_", "config")

			for k, v in pairs(configMap) do
				if k == "config_light_min" and self.gamma and self.gamma > 0 then
					v = 1 - (1 - v) * (1 - self.gamma / 2)
				end

				self.tilemap:setConfig(k, v)
			end

			self:refreshMaskConfig()
		end

		MapFrameManager.tween(time, startConfig, finalConfig, easing, onComplete, onUpdate)

		return
	end

	ObjUtil.deepCoverValue(obj, self.config)

	local configMap = ObjUtil.deepObjToKV(self.config, "_", "config")

	if self.tilemap then
		for k, v in pairs(configMap) do
			if k == "config_light_min" and self.gamma and self.gamma > 0 then
				v = 1 - (1 - v) * (1 - self.gamma / 2)
			end

			self.tilemap:setConfig(k, v)
		end
	end

	self:refreshMaskConfig()
end

function Map:recoverConfig(time, easing)
	local obj = ObjUtil.clone(self.config)

	if self.originalConfig and obj then
		ObjUtil.deepCoverValue(self.originalConfig, obj)
		self:setConfig(obj, time, easing)
	end
end

function Map.getMapData(mapName, seed)
	seed = seed or InfoDungeon.getMapSeed()

	if string.sub(mapName, 1, 1) == "#" then
		local jsonStr = Rantile.make(mapName, seed, 1)
		local mapObj = JsonParser.parseStr(jsonStr)

		return mapObj
	elseif string.sub(mapName, 1, 1) == "*" then
		local jsonStr = Rantile.makeFix(mapName)
		local mapObj = JsonParser.parseStr(jsonStr)

		return mapObj
	else
		local infoPath = "res/map/" .. mapName .. "/data.json"
		local mapObj = JsonParser.parse(infoPath, true)

		return mapObj
	end
end

function Map:load(mapName)
	self.seed = InfoDungeon.getMapSeed()

	print("$$$ Map:load", mapName, self.seed)

	if string.sub(mapName, 1, 1) == "#" then
		self:loadRantile(mapName)
	elseif string.sub(mapName, 1, 1) == "*" then
		self:loadFixtile(mapName)
	else
		self:loadSingle(mapName)
	end
end

function Map:loadRantile(mapName)
	self.mapType = TYPE.RANTILE
	self.mapName = mapName
	local jsonStr, topMap, topTileMap = Rantile.make(mapName, self.seed, 2)
	self.top = {
		map = topMap,
		tile = topTileMap,
		exTopType = {}
	}

	self:doLoad(mapName, jsonStr)

	for x = 0, self.tileW - 1 do
		for y = 0, self.tileH - 1 do
			if not topTileMap[x .. "_" .. y] then
				local tile = self:getTile(x, y)

				tile:setForceWalk("Rantile_empty", 2)
			end
		end
	end
end

function Map:loadFixtile(mapName)
	self.mapType = TYPE.FIXTILE
	self.mapName = mapName
	local jsonStr, topMap, topTileMap, isSingle = Rantile.makeFix(mapName)

	if not isSingle then
		self.top = {
			map = topMap,
			tile = topTileMap,
			exTopType = {}
		}
	end

	self:doLoad(mapName, jsonStr)

	if not isSingle then
		for x = 0, self.tileW - 1 do
			for y = 0, self.tileH - 1 do
				if not topTileMap[x .. "_" .. y] then
					local tile = self:getTile(x, y)

					if tile then
						tile:setForceWalk("Rantile_empty", 2)
					end
				end
			end
		end
	end
end

function Map:loadSingle(mapName)
	self.mapType = TYPE.SINGLE
	self.mapName = mapName
	local jsonStr = JsonParser.getJsonStr("res/map/" .. mapName .. "/data.json", true)

	self:doLoad(mapName, jsonStr)

	self.topMap = nil
end

function Map:doLoad(mapName, jsonStr)
	local log = Log.startMeter("Map:load")
	local mapObj = JsonParser.parseStr(jsonStr, true)

	if mapObj.setup and mapObj.setup.params then
		local paramStr = mapObj.setup.params
		local params = ConfParser.parse(paramStr)

		ObjUtil.deepCoverValue(params, self.config)

		self.params = params
	else
		self.params = {}
	end

	local configMap = ObjUtil.deepObjToKV(self.config, "_", "config")

	for k, v in pairs(configMap) do
		if k == "config_light_min" and self.gamma and self.gamma > 0 then
			v = 1 - (1 - v) * (1 - self.gamma / 2)
		end

		self.tilemap:setConfig(k, v)
	end

	self.originalConfig = ObjUtil.clone(self.config)

	self:refreshMaskConfig()
	Map.loadAssets()

	local mapData = mapObj.mapData
	local textureName = mapData.texture or mapName
	local texturePath = getFinalRes("res/map/" .. textureName .. "/texture.png")
	local plistPath = getFinalRes("res/map/" .. textureName .. "/texture.plist")

	log.markMeter("init data")
	self.tilemap:loadJson(jsonStr, texturePath, plistPath)
	log.markMeter("c++ load")

	self.name = mapData.name
	self.ptPerTile = mapData.ptPerTile
	self.topType = mapData.topType
	self.solidW = mapData.solidW
	self.solidH = mapData.solidH
	self.tileW = mapData.tileW
	self.tileH = mapData.tileH

	if self.topType == Map.TOP_90 then
		self.scrollWidth = self.tileW * self.ptPerTile
		self.scrollHeight = self.tileH * self.ptPerTile
	elseif self.topType == Map.TOP_45 then
		self.scrollWidth = (self.tileW + self.tileH) * self.ptPerTile / 2
		self.scrollHeight = (self.tileW + self.tileH) * self.ptPerTile / 4
	else
		self.scrollWidth = self.solidW * self.ptPerTile
		self.scrollHeight = self.solidH * self.ptPerTile / 2 - self.ptPerTile / 4
	end

	self:setBorderLines(mapData.border)
	self:resetArea()
	self:initLayers()
	self:initMask()
	self:initTiles()
	log.markMeter("lua load")
	self:loadBackground()
	MapEventManager.makeMap(self, mapObj, mapName)
	log.markMeter("init event")
	self:setZoom(self.config.scale.map)
	Looper.startLoop(self, self.refreshLightAndVisibleLoop)
	log.markMeter("ready")
end

function Map:loadBackground()
	self.bgStack = {}
	local index = 1

	while true do
		local bgPic = self.params["bg_" .. index]
		local bgRatio = self.params["bg_ratio_" .. index]
		local bgScale = self.params["bg_scale_" .. index]

		if not empty(bgPic) and not empty(bgRatio) and not empty(bgScale) then
			local mapBG = MapBackground.new(self, self.width, self.height, bgPic, bgScale, bgRatio)

			table.insert(self.bgStack, mapBG)
			self.tileLayer:addChild(mapBG, -index)

			index = index + 1
		else
			break
		end
	end
end

function Map:setEventTopType(tileTag, type, eventIndex)
	if self.top then
		local tileMap = self.top.tile
		local exTopType = self.top.exTopType
		local topIndex = tileMap[tileTag]

		if topIndex then
			exTopType[topIndex] = {
				type = type,
				eventIndex = eventIndex
			}
		end
	end
end

function Map:refreshLightAndVisibleLoop()
	for tag, tile in pairs(self.tileLightDirty) do
		tile:refreshLightSum()
	end

	self.tileLightDirty = {}
	local tileVisible = self.tilemap:getTileVisible()

	if tileVisible ~= "" then
		local changedTags = string.split(tileVisible, ",")

		for i = 2, #changedTags do
			local tag = changedTags[i]
			local tile = self:getTileByTag(tag)

			tile:refreshUnitVisible()
		end
	end
end

function Map:addTileLightDirty(tile)
	self.tileLightDirty[tile.tag] = tile
end

function Map:setBorderLines(lines)
	self.borderStack = {}

	for k, line in pairs(lines) do
		if line.y then
			local x1 = math.min(line.x1, line.x2)
			local x2 = math.max(line.x1, line.x2)
			local y = line.y

			for i = x1, x2 do
				if self.borderStack[i .. "_" .. y] == nil then
					self.borderStack[i .. "_" .. y] = {}
				end

				self.borderStack[i .. "_" .. y][0] = true
			end
		elseif line.x then
			local y1 = math.min(line.y1, line.y2)
			local y2 = math.max(line.y1, line.y2)
			local x = line.x

			for i = y1, y2 do
				if self.borderStack[x .. "_" .. i] == nil then
					self.borderStack[x .. "_" .. i] = {}
				end

				self.borderStack[x .. "_" .. i][1] = true
			end
		end
	end
end

function Map:setLightRGB(vc3b)
	local r = math.floor(vc3b.r)
	local g = math.floor(vc3b.g)
	local b = math.floor(vc3b.b)
	local obj = {
		light = {
			color_rgb = r .. "," .. g .. "," .. b
		}
	}

	self:setConfig(obj)

	if self.tiles then
		for tag, tile in pairs(self.tiles) do
			tile:refreshLightSum()
		end
	end

	local min = math.min(r, g, b)
	local ratio = 0.3
	local r1 = math.floor((r - min) * ratio)
	local g1 = math.floor((g - min) * ratio)
	local b1 = math.floor((b - min) * ratio)

	self:setMaskColor(cc.c3b(r1, g1, b1))
end

function Map:clearLightRGB()
	local obj = {
		light = {
			color_rgb = ""
		}
	}

	self:setConfig(obj)

	if self.tiles then
		for tag, tile in pairs(self.tiles) do
			tile:refreshLightSum()
		end
	end
end

function Map:getLightRGB()
	if empty(self.config.light.color_rgb) then
		return cc.c3b(255, 255, 255)
	else
		local arr = string.split(self.config.light.color_rgb, ",")

		return cc.c3b(tonumber(arr[1]), tonumber(arr[2]), tonumber(arr[3]))
	end
end

function Map:setLightConfig(obj)
	self:setConfig({
		light = {
			min = obj.min,
			radius = obj.radius
		}
	})

	if self.tiles then
		for tag, tile in pairs(self.tiles) do
			tile:refreshLightSum()
		end
	end
end

function Map:getLightConfig()
	return {
		min = self.config.light.min,
		radius = self.config.light.radius
	}
end

function Map:findPath(startTile, endTile, walkLevel, size, endTileMap, occupiedCheckUnit, clippingMode, smoothLevel)
	walkLevel = walkLevel or 0
	smoothLevel = smoothLevel or self.config.pathfinding.smoothLevel

	if self.isBattle then
		smoothLevel = 0
	end

	return self.astar:findPath(startTile, endTile, walkLevel, size, endTileMap, occupiedCheckUnit, smoothLevel, clippingMode)
end

function Map:digPath(startTile, walkLevel, size, maxStep, area, occupiedCheckUnit, clippingMode, bestFunc, random)
	return self.astar:digPath(startTile, walkLevel, size, maxStep, area, occupiedCheckUnit, self.config.pathfinding.smoothLevel, clippingMode, bestFunc, random)
end

function Map:setPathLimited(tileMap)
	self.astar:setPathLimited(tileMap)
end

function Map:clearPathLimited()
	self.astar:clearPathLimited()
end

function Map:initLayers()
	self.shadowLayer = self.tilemap:getShadowLayer()
	self.lightLayer = self.tilemap:getLightLayer()
	self.lowLayer = self.tilemap:getLowLayer()
	self.baseLayer = self.tilemap:getBaseLayer()
	self.highLayer = self.tilemap:getHighLayer()
	self.hudHighLayer = self.tilemap:getHudLayer()
	self.tileLayer = self.tilemap:getTileLayer()
	self.maskLayer = self.tilemap:getMaskLayer()
	self.colorMaskMap = {}
end

function Map:clearTiles()
	if self.tiles then
		for tag, tile in pairs(self.tiles) do
			tile:destroy()
		end
	end

	self.tiles = {}
end

function Map:initTiles()
	self:clearTiles()

	for x = 0, self.tileW - 1 do
		for y = 0, self.tileH - 1 do
			if self:isLegalTile(x, y) then
				local tag = x .. "_" .. y
				local mapTile = self.tilemap:getTile(x, y)
				self.tiles[tag] = Tile.new(self, x, y, mapTile)
			end
		end
	end
end

function Map:getTile(x, y)
	local tag = x .. "_" .. y

	return self.tiles[tag]
end

function Map:getTileByTag(tag)
	return self.tiles[tag]
end

function Map:isLegalTile(x, y)
	if x >= 0 and x < self.tileW and y >= 0 and y < self.tileH then
		if self.topType == Map.TOP_45_Z then
			if x + y < self.solidW - 1 or x + y > self.tileW + self.tileH - self.solidW - 1 or self.tileH - y + x < self.solidH or self.tileW - x + y < self.solidH then
				return false
			else
				return true
			end
		else
			return true
		end
	end

	return false
end

local scrollTweenID = nil

function Map:tweenScrollTo(x, y, frameTime, onComplete, easing, noFix, onUpdate)
	frameTime = frameTime or 10
	local tweenObj = {
		x = self.x,
		y = self.y
	}

	local function onTweenUpdate()
		self:scrollTo(tweenObj.x, tweenObj.y, nil, noFix)

		if onUpdate then
			onUpdate(tweenObj.x, tweenObj.y)
		end
	end

	if scrollTweenID then
		MapFrameManager.stopTween(scrollTweenID)
	end

	scrollTweenID = MapFrameManager.tween(frameTime, tweenObj, {
		x = x,
		y = y
	}, easing or "outQuad", onComplete, onTweenUpdate)

	return scrollTweenID
end

function Map:scrollToUnit(unit, tight, onComplete)
	tight = tight or 10
	local onScrollUpdate = nil

	function onScrollUpdate(obj, frame, passed, sharp)
		local preX = self.x
		local preY = self.y

		self:scrollTo((unit.x - self.x) / tight * passed + self.x, (unit.y - self.y) / tight * passed + self.y)

		if math.abs(unit.x - self.x) <= 1 and math.abs(unit.y - self.y) <= 1 or math.abs(preX - self.x) < 0.1 and math.abs(preY - self.y) < 0.1 then
			MapFrameManager.stopLoop(self, onScrollUpdate)

			if onComplete then
				onComplete()
			end
		end
	end

	MapFrameManager.startLoop(self, onScrollUpdate)
end

local tweenToUnitID = nil

function Map:tweenToUnit(unit, frameTime, onComplete, easing)
	frameTime = frameTime or 10
	local tweenObj = {
		frameCount = frameTime
	}
	local startX = self.x
	local startY = self.y

	local function onTweenUpdate()
		local percent = 1 - tweenObj.frameCount / frameTime

		self:scrollTo((unit.x - startX) * percent + startX, (unit.y - startY) * percent + startY)
	end

	if tweenToUnitID then
		MapFrameManager.stopTween(scrollTweenID)

		tweenToUnitID = nil
	end

	tweenToUnitID = MapFrameManager.tween(frameTime, tweenObj, {
		frameCount = 0
	}, easing or "outQuad", onComplete, onTweenUpdate)

	return tweenToUnitID
end

function Map:scrollTo(x, y, refresh, noFix)
	if self.scrollLockPosition then
		x = self.scrollLockPosition.x
		y = self.scrollLockPosition.y
	end

	if not noFix then
		local fixedX, fixedY = nil

		if self.topType == Map.TOP_90 then
			fixedX = math.max(self.width / self.zoom / self.viewZoom / 2, math.min(self.scrollWidth - self.width / self.zoom / self.viewZoom / 2, x))
			fixedY = math.max(self.height / self.zoom / self.viewZoom / 2, math.min(self.scrollHeight - self.height / self.zoom / self.viewZoom / 2 - self.config.engine.bottom_cut * self.ptPerTile, y))
		else
			local isoX = (x - y) / 2 + self.tileH * self.ptPerTile / 2
			local isoY = (x + y) / 4

			if self.topType == Map.TOP_45 then
				isoX = math.max(self.width / self.zoom / self.viewZoom / 2, math.min(self.scrollWidth - self.width / self.zoom / self.viewZoom / 2, isoX))
				isoY = math.max(self.height / self.zoom / self.viewZoom / 2, math.min(self.scrollHeight - self.height / self.zoom / self.viewZoom / 2 - self.config.engine.bottom_cut * self.ptPerTile / 2, isoY))
			else
				local xBorder = (self.tileH * self.ptPerTile - self.scrollWidth) / 2
				local yBorder = (self.tileH * self.ptPerTile / 2 - self.scrollHeight - self.ptPerTile / 4) / 2
				isoX = math.max(self.width / self.zoom / self.viewZoom / 2 + xBorder, math.min((self.tileW + self.tileH) * self.ptPerTile / 2 - xBorder - self.width / self.zoom / self.viewZoom / 2, isoX))
				isoY = math.max(self.height / self.zoom / self.viewZoom / 2 + yBorder, math.min((self.tileW + self.tileH) * self.ptPerTile / 4 - yBorder - self.height / self.zoom / self.viewZoom / 2 - self.config.engine.bottom_cut * self.ptPerTile / 2, isoY))
			end

			fixedX = isoX - self.tileH * self.ptPerTile / 2 + isoY * 2
			fixedY = isoY * 2 - (isoX - self.tileH * self.ptPerTile / 2)
		end

		x = fixedX
		y = fixedY
	end

	self.x = x
	self.y = y
	refresh = refresh or false

	if self.tilemap then
		local changedTilesStr = self.tilemap:scrollTo(x, y, refresh)

		self:changeTilesAfterScroll(changedTilesStr)
	end

	if self.bgStack and #self.bgStack > 0 then
		local drawX, drawY = self:mapToDraw(x, y)

		for i, mapBG in ipairs(self.bgStack) do
			mapBG:scrollTo(drawX, -drawY)
		end
	end

	if self.isBattlePrepare then
		local tempX = math.floor(x / self.ptPerTile)
		local tempY = math.floor(y / self.ptPerTile)
		local newAreaX = tempX - tempY + self.areaWidth / 2
		local newAreaY = tempX + tempY
		local dirtyX = newAreaX - (self.preAreaX or 0)
		local dirtyY = newAreaY - (self.preAreaY or 0)
		local isRefresh = self.preAreaX == nil
		local minX = newAreaX - self.areaWidth / 2 - self.config.engine.side_buff
		local maxX = newAreaX + self.areaWidth / 2 + self.config.engine.side_buff
		local minY = newAreaY - self.areaHeight / 2 - self.config.engine.top_buff
		local maxY = newAreaY + self.areaHeight / 2 + self.config.engine.bottom_buff
		local tileLight = self.config.light.min

		MapUtils.dirtyRect(dirtyX, dirtyY, minX, maxX, minY, maxY, function (_x, _y)
			local drawX = math.floor(_y / 2 + (_x - self.areaWidth / 2) / 2)
			local drawY = math.floor(_y / 2 - (_x - self.areaWidth / 2) / 2)
			local tile = self:getTile(drawX, drawY)

			if tile and not self.lightForceMap[tile.tag] then
				self.lightForceMap[tile.tag] = true

				table.insert(self.lightForceTile, {
					tile = tile,
					startLight = tile:getGroundLight() or self.config.light.min,
					endLight = tileLight / 2,
					objEndLight = tileLight
				})
			end
		end, isRefresh)

		self.preAreaX = newAreaX
		self.preAreaY = newAreaY
	end
end

function Map:changeTilesAfterScroll(changedTilesStr)
	local arr = string.split(changedTilesStr, "|")
	local drawedTags = string.split(arr[1], ",")
	local erasedTags = string.split(arr[2], ",")

	for i = 2, #erasedTags do
		local tag = erasedTags[i]
		local tile = self:getTileByTag(tag)

		tile:onErase()
	end

	for i = 2, #drawedTags do
		local tag = drawedTags[i]
		local tile = self:getTileByTag(tag)

		tile:onDraw()
	end
end

function Map:tweenFov(x, y, frameTime, easing)
	frameTime = frameTime or 10

	if frameTime <= 0 then
		self:setFov(x, y)

		return
	end

	local tweenObj = {
		x = self.fovPosition.x,
		y = self.fovPosition.y
	}

	local function onTweenUpdate()
		self:setFov(tweenObj.x, tweenObj.y)
	end

	return MapFrameManager.tween(frameTime, tweenObj, {
		x = x,
		y = y
	}, easing or "outQuad", onComplete, onTweenUpdate)
end

function Map:setFov(x, y, refresh, refreshLight)
	x = x or self.fovPosition.x
	y = y or self.fovPosition.y
	self.fovPosition.x = x
	self.fovPosition.y = y

	self.tilemap:setFov(x + self.fovOffset.x, y + self.fovOffset.y, refresh or false, refreshLight or false)
	self:setMaskPosition(x, y)
end

function Map:setFovOffset(x, y, refresh)
	self.fovOffset.x = x
	self.fovOffset.y = y

	self:setFov(nil, , refresh)
end

function Map:setZoom(zoom)
	local bigScale = UIManager.getBigScale()
	zoom = zoom * math.sqrt(bigScale)
	zoom = math.floor(zoom * 100) / 100
	zoom = math.max(zoom, 1)
	self.zoom = zoom

	if self.tilemap then
		self.tilemap:setZoom(zoom)
	end

	self:resetArea()
	self:refreshMaskConfig()
end

function Map:resetArea()
	if self.topType == Map.TOP_90 then
		self.areaWidth = math.ceil(self.width / self.zoom / self.ptPerTile / 2) * 2
		self.areaHeight = math.ceil(self.height / self.zoom / self.ptPerTile / 2) * 2
	else
		self.areaWidth = math.ceil(self.width / self.zoom / self.ptPerTile * 2 / 2) * 2 + 2
		self.areaHeight = math.ceil((self.height / self.zoom / self.ptPerTile * 4 + 1) / 2) * 2 + 2
	end
end

function Map:setViewZoom(viewZoom, noFix, tweening)
	self.viewZoom = viewZoom

	if self.tilemap then
		self.tilemap:setViewZoom(viewZoom)
	end

	self:scrollTo(self.x, self.y, nil, noFix)

	if not tweening and self.viewZoomTweenID then
		MapFrameManager.stopTween(self.viewZoomTweenID)

		self.viewZoomTweenID = nil
	end
end

function Map:tweenViewZoom(viewZoom, frameTime, onComplete, noFix, easing)
	frameTime = frameTime or 10
	local tweenObj = {
		viewZoom = self.viewZoom
	}

	local function onTweenUpdate()
		self:setViewZoom(tweenObj.viewZoom, noFix, true)
	end

	if self.viewZoomTweenID then
		MapFrameManager.stopTween(self.viewZoomTweenID)

		self.viewZoomTweenID = nil
	end

	self.viewZoomTweenID = MapFrameManager.tween(frameTime, tweenObj, {
		viewZoom = viewZoom
	}, easing or "outQuad", onComplete, onTweenUpdate)

	return self.viewZoomTweenID
end

function Map:tweenViewZoomLooper(viewZoom, frameTime, onComplete, noFix, easing)
	frameTime = frameTime or 10
	local tweenObj = {
		viewZoom = self.viewZoom
	}

	local function onTweenUpdate()
		self:setViewZoom(tweenObj.viewZoom, noFix)
	end

	if self.viewZoomTweenLooperID then
		Looper.stopTween(self.viewZoomTweenLooperID)

		self.viewZoomTweenLooperID = nil
	end

	self.viewZoomTweenLooperID = Looper.tween(frameTime, tweenObj, {
		viewZoom = viewZoom
	}, easing or "outQuad", onComplete, onTweenUpdate)

	return self.viewZoomTweenLooperID
end

function Map:lockScroll(x, y)
	self.scrollLockPosition = {
		x = x,
		y = y
	}
end

function Map:releaseLockScroll()
	self.scrollLockPosition = nil
end

function Map:mapToDraw(x, y)
	if self.topType == Map.TOP_90 then
		return x, y
	else
		return (x - y) / 2, (x + y) / 4
	end
end

function Map:drawToMap(x, y)
	if self.topType == Map.TOP_90 then
		return x, y
	else
		return x + y * 2, y * 2 - x
	end
end

function Map:tileToMap(x, y)
	local tempX, tempY = nil

	if y == nil then
		tempX = x.x
		tempY = x.y
	else
		tempX = x
		tempY = y
	end

	return tempX * self.ptPerTile + self.ptPerTile / 2, tempY * self.ptPerTile + self.ptPerTile / 2
end

function Map:areaToMap(x, y, width, height)
	return x * self.ptPerTile + self.ptPerTile / 2 * width, y * self.ptPerTile + self.ptPerTile / 2 * height
end

function Map:mapToTile(x, y)
	local tempX, tempY = nil

	if y == nil then
		tempX = x.x
		tempY = x.y
	else
		tempX = x
		tempY = y
	end

	return self:getTile(math.min(math.floor(tempX / self.ptPerTile), self.tileW - 1), math.min(math.floor(tempY / self.ptPerTile), self.tileH - 1))
end

function Map:screenToMap(x, y, noLimit)
	local tempX, tempY = nil

	if y == nil then
		tempX = x.x
		tempY = x.y
	else
		tempX = x
		tempY = y
	end

	tempX = tempX - self.positionOffset.x
	tempY = tempY - self.positionOffset.y

	if self.topType ~= Map.TOP_90 then
		local isoX = math.round((self.x - self.y) / 2)
		local isoY = -math.round((self.x + self.y) / 4)
		local screenX = (tempX - self.width / 2) / self.zoom / self.viewZoom + isoX
		local screenY = -((tempY - self.height / 2) / self.zoom / self.viewZoom + isoY)
		local mapX = screenX + screenY * 2
		local mapY = screenY * 2 - screenX

		if not noLimit then
			mapX = math.min(self.tileW * self.ptPerTile, math.max(0, mapX))
			mapY = math.min(self.tileH * self.ptPerTile, math.max(0, mapY))
		end

		return mapX, mapY
	end
end

function Map:mapToScreen(x, y)
	local tempX, tempY = nil

	if y == nil then
		tempX = x.x
		tempY = x.y
	else
		tempX = x
		tempY = y
	end

	if self.topType ~= Map.TOP_90 then
		local isoX = math.round((self.x - self.y) / 2)
		local isoY = -math.round((self.x + self.y) / 4)
		local screenX = (tempX - tempY) / 2
		local screenY = (tempX + tempY) / 4
		screenX = (screenX - isoX) * self.zoom * self.viewZoom + self.width / 2 + self.positionOffset.x
		screenY = (-screenY - isoY) * self.zoom * self.viewZoom + self.height / 2 + self.positionOffset.y

		return screenX, screenY
	end
end

function Map:toTileCenter(x, y)
	local tile = self:mapToTile(x, y)
	local mapX, mapY = self:tileToMap(tile)

	if y == nil then
		return {
			x = mapX,
			y = mapY
		}
	else
		return mapX, mapY
	end
end

function Map:setPositionOffset(tag, x, y)
	self.positionOffsetTagMap = self.positionOffsetTagMap or {}
	self.positionOffsetTagMap[tag] = cc.p(x, y)
	local _x = 0
	local _y = 0

	for _tag, pos in pairs(self.positionOffsetTagMap) do
		if pos.x == 0 and pos.y == 0 then
			self.positionOffsetTagMap[_tag] = nil
		else
			_x = _x + pos.x
			_y = _y + pos.y
		end
	end

	self.positionOffset.x = _x
	self.positionOffset.y = _y

	self:setPosition(_x, _y)
end

local setPositionOffsetTweenID, setPositionOffsetTweenIDLooper = nil

function Map:setPositionOffsetTween(tag, x, y, frameTime, onComplete, isLooper)
	frameTime = frameTime or 10
	local startX = 0
	local startY = 0

	if self.positionOffsetTagMap and self.positionOffsetTagMap[tag] then
		startX = self.positionOffsetTagMap[tag].x
		startY = self.positionOffsetTagMap[tag].y
	end

	local tweenObj = {
		x = startX,
		y = startY
	}

	local function onTweenUpdate()
		self:setPositionOffset(tag, tweenObj.x, tweenObj.y)
	end

	if setPositionOffsetTweenID then
		MapFrameManager.stopTween(setPositionOffsetTweenID)

		setPositionOffsetTweenID = nil
	end

	if setPositionOffsetTweenIDLooper then
		Looper.stopTween(setPositionOffsetTweenIDLooper)

		setPositionOffsetTweenIDLooper = nil
	end

	if isLooper then
		setPositionOffsetTweenIDLooper = Looper.tween(frameTime, tweenObj, {
			x = x,
			y = y
		}, easing or "outQuad", onComplete, onTweenUpdate)
	else
		setPositionOffsetTweenID = MapFrameManager.tween(frameTime, tweenObj, {
			x = x,
			y = y
		}, easing or "outQuad", onComplete, onTweenUpdate)
	end

	return setPositionOffsetTweenID
end

local touchHandlerMap = {}

function Map:clearMapTouch()
	for name, handler in pairs(touchHandlerMap) do
		self:removeNodeEventListener(handler)
	end

	touchHandlerMap = {}
end

function Map:removeMapTouch(name)
	local handler = touchHandlerMap[name]

	if handler then
		self:removeNodeEventListener(handler)

		touchHandlerMap[name] = nil
	end
end

function Map:addMapTouch(name, callback)
	self:removeMapTouch(name)

	local handler = self:addNodeEventListener(cc.NODE_TOUCH_EVENT, function (event)
		callback(event)
	end)

	self:setTouchEnabled(true)

	touchHandlerMap[name] = handler
end

function Map:refreshSpeedup()
	if self.isBattle and InfoDungeon.isSpeedup() then
		if not Cookie.get("speedup_ban") then
			local speedup_ratio = CsvParser.getCsvData("config", "speedup_ratio").value

			MapFrameManager.setSuperTimeRatio(speedup_ratio)
		else
			MapFrameManager.setSuperTimeRatio(1)
		end
	end
end

function Map:battleOn(isTD)
	Log.verbose("Map:battleOn")

	self.isBattle = true

	self:refreshSpeedup()

	if not isTD then
		self.tilemap:pauseUpdate()
	end

	TeamManager.refreshTeamSneak(true)
	notify.dispatch("battle_state_change", true)
end

function Map:cancelBattleLight()
	if not self.lightForceTile then
		return
	end

	for i, obj in ipairs(self.lightForceTile) do
		obj.tile:fadeinAssets()
		obj.tile:removeLightForce()
		obj.tile:removeForceWalk("battle")
		self:addTileLightDirty(obj.tile)
	end

	self.lightForceMap = {}
	self.preAreaX = nil
	self.preAreaY = nil
end

function Map:battleOff()
	MapFrameManager.clearSuperTimeRatio()
	Log.verbose("Map:battleOff")

	self.isBattlePrepare = nil
	self.isBattle = nil

	self.tilemap:resumeUpdate()
	self:cancelBattleLight()

	local function onTweenComplete()
		local monsters = Monster.getAllMonster()

		for i = 1, #monsters do
			monsters[i]:setActive(true)
			monsters[i]:waitForPatrol(true)
		end

		if InfoDungeon.checkGuide(3) then
			GuideManager.guideRelic()
		end
	end

	self:tweenViewZoom(1, 30, onTweenComplete)
	notify.dispatch("battle_state_change", false)
end

function Map:prepareBattle(centerTile, delay, eventData, centerMonster, additionalParams)
	if self.isBattle then
		return
	end

	Log.verbose("=BATTLE= Map:prepareBattle")

	self.isBattlePrepare = true
	self.battleCenterTile = centerTile
	delay = delay or 0
	local jumpinSpeed = 10
	local jumpinDelay = 0

	self:battleOn()

	local function start(params)
		WarMachine.start(params)
	end

	local function checkFullUnitInArea(unit, tile, areaTileMap)
		if unit.size > 0 then
			for i = 1, unit.size do
				for j = 1, unit.size do
					local _tile = self:getTile(tile.x + i - 1, tile.y + j - 1)

					if not areaTileMap[_tile.tag] then
						return false
					end
				end
			end
		end

		return true
	end

	local function ready()
		local seed = nil

		if additionalParams then
			seed = additionalParams.seed
		end

		seed = seed or eventData.seed

		WarMachine.ready(seed)

		local lightForceTile = {}
		local eventInfo = ConfParser.parse(eventData.info)
		local range = eventInfo.range or self.config.scale.range
		local pack = MapEventManager.getMonsterSetByIndex(eventData.monsterGroupID)

		if pack then
			local monsterCreateCSV = CsvParser.getCsvData("monster_create", pack.setData.id)

			if not empty(monsterCreateCSV.range) then
				range = monsterCreateCSV.range
			end
		end

		local areaTiles, outTiles, borderTiles = MapUtils.spreadArea(self, centerTile, range, 10000, 0)

		WarMachine.setAreaTileMap(areaTiles)
		WarMachine.setBorderTiles(borderTiles)

		local maxHeight = 0
		local friends = global.player:getTrainUnits()
		local random = Random.new(eventData.seed)

		WarMachine.preparePet(1, centerTile, global.player.tile, global.player.angle)

		local petInfo = InfoPet.getPetByIndex(InfoPet.getPetIndex())

		WarMachine.addPetReady(1, petInfo)

		local involvedUnits = {}
		local involvedUnitsMap = {}
		local freeTiles = {}
		local doneTileMap = {}

		for i = 1, #areaTiles do
			local tile = areaTiles[i]
			doneTileMap[tile:getTag()] = tile

			tile:setInview(true)

			local tileLight = self:getBattleTileLight(tile)

			table.insert(lightForceTile, {
				tile = tile,
				startLight = tile:getGroundLight() or self.config.light.min,
				endLight = tileLight
			})
			tile:setUnitActive(true)

			local unitCount = 0

			for unitID, unit in pairs(tile.unitMap) do
				local isDeadHero = unit.type == "hero" and unit.battleData.die

				if not isDeadHero then
					if not involvedUnitsMap[unit.id] then
						involvedUnitsMap[unit.id] = true

						table.insert(involvedUnits, unit)
					end

					unitCount = unitCount + 1
				end
			end

			if unitCount == 0 then
				table.insert(freeTiles, tile)
			end
		end

		local monsterGroupMap = {}
		local monsterIDMap = {}
		local friendIDMap = {}

		for i = 1, #involvedUnits do
			local unit = involvedUnits[i]

			if (unit.type == "hero" or unit.type == "pet") and not friendIDMap[unit.id] then
				if unit.type == "pet" then
					WarMachine.addPet(unit)
				else
					WarMachine.addUnit(unit, 1, "Map:prepareBattle-1")
				end

				friendIDMap[unit.id] = true
			end

			local battleHeight = unit.height - unit.size * self.ptPerTile / 4

			if unit.battleHeight then
				battleHeight = unit.battleHeight - unit.size * self.ptPerTile / 4
			end

			maxHeight = math.max(maxHeight, battleHeight)
		end

		for i = 1, #involvedUnits do
			local unit = involvedUnits[i]

			if unit.type == "monster" and not monsterIDMap[unit.id] then
				if unit.groupID then
					monsterGroupMap[unit.groupID] = true
				end

				if unit.size == 1 or checkFullUnitInArea(unit, unit.tile, doneTileMap) then
					WarMachine.addUnit(unit, 2, "Map:prepareBattle-2")

					monsterIDMap[unit.id] = true
				end
			end
		end

		if centerMonster then
			monsterGroupMap[centerMonster.groupID] = true
		end

		local linkedMonsterEvents = MapEventManager.findLinkAll(eventData, "monster")

		for i, eventData in ipairs(linkedMonsterEvents) do
			if Monster.getGroup(eventData.monsterGroupID) then
				monsterGroupMap[eventData.monsterGroupID] = true
			end
		end

		local moreUnits = {}

		for i = 1, #friends do
			local unit = friends[i]

			if friendIDMap[unit.id] == nil then
				table.insert(moreUnits, {
					camp = 1,
					unit = unit
				})
			end
		end

		for groupID, v in pairs(monsterGroupMap) do
			local group = Monster.getGroup(groupID)

			if group then
				for i = 1, #group do
					local unit = group[i]

					if monsterIDMap[unit.id] == nil then
						table.insert(moreUnits, {
							camp = 2,
							unit = unit
						})
					end
				end
			end
		end

		Map.NO_UNIT_BLOCK = true

		for i = 1, #moreUnits do
			local unit = moreUnits[i].unit
			local camp = moreUnits[i].camp

			if #freeTiles > 0 then
				local bestDistance, bestTile, bestTileIndex = nil

				for j = 1, #freeTiles do
					local tile = freeTiles[j]

					if checkFullUnitInArea(unit, tile, doneTileMap) then
						local distance = math.sqrt(math.pow(unit.tile.y - tile.y, 2) + math.pow(unit.tile.x - tile.x, 2))

						if bestDistance == nil or distance < bestDistance then
							bestDistance = distance
							bestTile = tile
							bestTileIndex = j
						end
					end
				end

				if bestTile ~= nil then
					local x, y = self:tileToMap(bestTile)

					unit:jump({
						x = x,
						y = y
					}, jumpinSpeed, 20)

					local distance = math.sqrt(math.pow(unit.y - y, 2) + math.pow(unit.x - x, 2))
					jumpinDelay = math.max(jumpinDelay, math.floor(distance / jumpinSpeed))

					if unit.type == "pet" then
						WarMachine.addPet(unit)
					else
						WarMachine.addUnit(unit, camp, "Map:prepareBattle-3")
					end

					table.remove(freeTiles, bestTileIndex)
				end
			end

			local battleHeight = unit.height - unit.size * self.ptPerTile / 4

			if unit.battleHeight then
				battleHeight = unit.battleHeight - unit.size * self.ptPerTile / 4
			end

			maxHeight = math.max(maxHeight, battleHeight)
		end

		Map.NO_UNIT_BLOCK = false
		local darkTiles = {}

		for i, tile in ipairs(outTiles) do
			doneTileMap[tile.tag] = tile

			tile:setForceWalk("battle", 2)
			table.insert(darkTiles, tile)
		end

		for i = 1, #darkTiles do
			local tile = darkTiles[i]

			tile:setUnitActive(false)

			local tileLight = self:getBattleTileLight(tile)

			table.insert(lightForceTile, {
				tile = tile,
				startLight = tile:getGroundLight() or self.config.light.min,
				endLight = tileLight / 2,
				objEndLight = tileLight
			})
		end

		local tweenTime = 45
		local tweenObj = {
			lightPercent = 0
		}

		local function onTweenUpdate()
			for i = 1, #lightForceTile do
				local lightObj = lightForceTile[i]
				local light = (1 - tweenObj.lightPercent) * lightObj.startLight + tweenObj.lightPercent * lightObj.endLight
				local objLight = light

				if lightObj.objEndLight then
					objLight = (1 - tweenObj.lightPercent) * lightObj.startLight + tweenObj.lightPercent * lightObj.objEndLight
				end

				lightObj.tile:setLightForce(light, objLight)
			end
		end

		self.lightForceTile = lightForceTile
		self.lightForceMap = {}

		for i, v in ipairs(lightForceTile) do
			self.lightForceMap[v.tile.tag] = true
		end

		local function onTweenComplete()
			onTweenUpdate()

			self.isBattlePrepare = nil
		end

		MapFrameManager.tween(tweenTime, tweenObj, {
			lightPercent = 1
		}, "outQuad", onTweenComplete, onTweenUpdate)

		maxHeight = maxHeight + 20
		local battleZoomin = self.height / ((range * 2 + 1) * self.ptPerTile / 2 + maxHeight)
		self.battleZoom = battleZoomin / self.config.scale.map
		local x, y = self:tileToMap(centerTile)

		self:tweenViewZoom(battleZoomin / self.config.scale.map, tweenTime, nil, true)

		local createParams = {}
		local monsterCreateID, pack = nil

		for k, v in pairs(monsterGroupMap) do
			pack = MapEventManager.getMonsterSetByIndex(k)

			if pack then
				monsterCreateID = pack.setData.id

				break
			end
		end

		if monsterCreateID then
			createParams = {
				id = monsterCreateID,
				pack = pack,
				random = random
			}
		end

		if additionalParams then
			for k, v in pairs(additionalParams) do
				createParams[k] = v
			end
		end

		local offset = maxHeight

		self:tweenScrollTo(x - offset, y - offset, tweenTime, function ()
			start(createParams)
		end, nil, true)
		self:setMaskPosition(x, y)

		if self.lightForceTile then
			for _, obj in ipairs(self.lightForceTile) do
				obj.tile:fadeoutAssets()
			end
		end

		local monsterGroups = {}

		for groupID, v in pairs(monsterGroupMap) do
			table.insert(monsterGroups, groupID)
		end

		WarMachine.setGroups(monsterGroups, createParams)

		local _everGroups = {}

		for k, v in pairs(monsterGroupMap) do
			local pack = MapEventManager.getMonsterSetByIndex(k)

			if pack then
				local monsterCreateCSV = CsvParser.getCsvData("monster_create", pack.setData.id)
				local battleList = SheetUtil.getColumnList(monsterCreateCSV, {
					"ever_battle",
					"ever_max",
					"ever_start_time",
					"ever_wait_time"
				}, {
					"drop",
					"max",
					"start_time",
					"wait_time"
				})

				for i, battle in ipairs(battleList) do
					battle.seed = random:getInt(1, 65535)
					battle.pack = pack
					battle.stop = monsterCreateCSV.ever_battle_stop

					table.insert(_everGroups, battle)
				end
			end
		end

		if additionalParams and additionalParams.id then
			local monsterCreateCSV = CsvParser.getCsvData("monster_create", additionalParams.id)
			local battleList = SheetUtil.getColumnList(monsterCreateCSV, {
				"ever_battle",
				"ever_max",
				"ever_start_time",
				"ever_wait_time"
			}, {
				"drop",
				"max",
				"start_time",
				"wait_time"
			})

			for i, battle in ipairs(battleList) do
				battle.seed = additionalParams.random:getInt(1, 65535)
				battle.pack = additionalParams.pack
				battle.stop = monsterCreateCSV.ever_battle_stop

				table.insert(_everGroups, battle)
			end
		end

		WarMachine.setEverGroups(_everGroups)
		global.ui:onBattleReady()
	end

	delay = math.max(delay, jumpinDelay)

	if delay > 0 then
		MapFrameManager.setTimeout(ready, delay)
	else
		ready()
	end

	WarMachine.startBuff()
end

function Map:prepareBattleCopy(centerTile, delay, eventData, createParams, copyMap, petIndexMap)
	if self.isBattle then
		return
	end

	Log.verbose("=BATTLE= Map:prepareBattleCopy")

	self.isBattlePrepare = true
	self.battleCenterTile = centerTile
	delay = delay or 0
	local jumpinSpeed = 10
	local jumpinDelay = 0

	self:battleOn()

	local function start(params)
		WarMachine.start(params, true)
	end

	local function checkFullUnitInArea(unit, tile, areaTileMap)
		if unit.size > 0 then
			for i = 1, unit.size do
				for j = 1, unit.size do
					local _tile = self:getTile(tile.x + i - 1, tile.y + j - 1)

					if not areaTileMap[_tile.tag] then
						return false
					end
				end
			end
		end

		return true
	end

	local function ready()
		local seed = nil

		if createParams then
			seed = createParams.seed
		end

		seed = seed or eventData.seed

		WarMachine.ready(seed)

		local lightForceTile = {}
		local eventInfo = ConfParser.parse(eventData.info)
		local range = eventInfo.range or self.config.scale.range
		local areaTiles, outTiles, borderTiles = MapUtils.spreadArea(self, centerTile, range, 10000, 0)

		WarMachine.setAreaTileMap(areaTiles)
		WarMachine.setBorderTiles(borderTiles)

		local maxHeight = 0
		local involvedUnits = {}
		local involvedUnitsMap = {}
		local freeTiles = {}
		local doneTileMap = {}

		for i = 1, #areaTiles do
			local tile = areaTiles[i]
			doneTileMap[tile:getTag()] = tile

			tile:setInview(true)

			local tileLight = self:getBattleTileLight(tile)

			table.insert(lightForceTile, {
				tile = tile,
				startLight = tile:getGroundLight() or self.config.light.min,
				endLight = tileLight
			})
			tile:setUnitActive(true)

			local unitCount = 0

			for unitID, unit in pairs(tile.unitMap) do
				if not involvedUnitsMap[unit.id] then
					involvedUnitsMap[unit.id] = true

					table.insert(involvedUnits, unit)
				end

				unitCount = unitCount + 1
			end

			if unitCount == 0 then
				table.insert(freeTiles, tile)
			end
		end

		local monsterIDMap = {}
		local friendIDMap = {}

		for i = 1, #involvedUnits do
			local unit = involvedUnits[i]

			if unit.type == "hero_copy" then
				if unit.camp == 1 then
					if not friendIDMap[unit.id] then
						WarMachine.addUnit(unit, 1, "Map:prepareBattle-3")

						friendIDMap[unit.id] = true
					end
				elseif unit.camp == 2 and not monsterIDMap[unit.id] then
					WarMachine.addUnit(unit, 2, "Map:prepareBattle-3")

					monsterIDMap[unit.id] = true
				end
			end

			maxHeight = math.max(maxHeight, unit.height - unit.size * self.ptPerTile / 4)
		end

		local darkTiles = {}

		for i, tile in ipairs(outTiles) do
			doneTileMap[tile.tag] = tile

			tile:setForceWalk("battle", 2)
			table.insert(darkTiles, tile)
		end

		for i = 1, #darkTiles do
			local tile = darkTiles[i]

			tile:setUnitActive(false)

			local tileLight = self:getBattleTileLight(tile)

			table.insert(lightForceTile, {
				tile = tile,
				startLight = tile:getGroundLight() or self.config.light.min,
				endLight = tileLight / 2,
				objEndLight = tileLight
			})
		end

		local tweenTime = 45
		local tweenObj = {
			lightPercent = 0
		}

		local function onTweenUpdate()
			for i = 1, #lightForceTile do
				local lightObj = lightForceTile[i]
				local light = (1 - tweenObj.lightPercent) * lightObj.startLight + tweenObj.lightPercent * lightObj.endLight
				local objLight = light

				if lightObj.objEndLight then
					objLight = (1 - tweenObj.lightPercent) * lightObj.startLight + tweenObj.lightPercent * lightObj.objEndLight
				end

				lightObj.tile:setLightForce(light, objLight)
			end
		end

		self.lightForceTile = lightForceTile
		self.lightForceMap = {}

		for i, v in ipairs(lightForceTile) do
			self.lightForceMap[v.tile.tag] = true
		end

		local function onTweenComplete()
			onTweenUpdate()

			self.isBattlePrepare = nil
		end

		MapFrameManager.tween(tweenTime, tweenObj, {
			lightPercent = 1
		}, "outQuad", onTweenComplete, onTweenUpdate)

		maxHeight = maxHeight + 20
		local battleZoomin = self.height / ((range * 2 + 1) * self.ptPerTile / 2 + maxHeight)
		self.battleZoom = battleZoomin / self.config.scale.map
		local x, y = self:tileToMap(centerTile)

		self:tweenViewZoom(battleZoomin / self.config.scale.map, tweenTime, nil, true)

		local offset = maxHeight

		self:tweenScrollTo(x - offset, y - offset, tweenTime, function ()
			start(createParams)
		end, nil, true)
		self:setMaskPosition(x, y)

		if self.lightForceTile then
			for _, obj in ipairs(self.lightForceTile) do
				obj.tile:fadeoutAssets()
			end
		end

		global.ui:onBattleReady()
	end

	delay = math.max(delay, jumpinDelay)

	if delay > 0 then
		MapFrameManager.setTimeout(ready, delay)
	else
		ready()
	end

	WarMachine.startBuffCopy(copyMap, petIndexMap)
end

function Map:prepareBattleEmu(centerTile, delay, eventData, createParams, copyMap, petIndexMap)
	if self.isBattle then
		return
	end

	Log.verbose("=BATTLE= Map:prepareBattleEmu")

	self.isBattlePrepare = true
	self.battleCenterTile = centerTile
	delay = delay or 0
	local jumpinSpeed = 10
	local jumpinDelay = 0

	self:battleOn()

	local function start(params)
		WarMachine.start(params, true)
	end

	local function checkFullUnitInArea(unit, tile, areaTileMap)
		if unit.size > 0 then
			for i = 1, unit.size do
				for j = 1, unit.size do
					local _tile = self:getTile(tile.x + i - 1, tile.y + j - 1)

					if not areaTileMap[_tile.tag] then
						return false
					end
				end
			end
		end

		return true
	end

	local function ready()
		local seed = nil

		if createParams then
			seed = createParams.seed
		end

		seed = seed or eventData.seed

		WarMachine.ready(seed)

		local lightForceTile = {}
		local eventInfo = ConfParser.parse(eventData.info)
		local range = eventInfo.range or self.config.scale.range
		local areaTiles, outTiles, borderTiles = MapUtils.spreadArea(self, centerTile, range, 10000, 0)

		WarMachine.setAreaTileMap(areaTiles)
		WarMachine.setBorderTiles(borderTiles)

		local maxHeight = 0
		local involvedUnits = {}
		local involvedUnitsMap = {}
		local freeTiles = {}
		local doneTileMap = {}

		for i = 1, #areaTiles do
			local tile = areaTiles[i]
			doneTileMap[tile:getTag()] = tile

			tile:setInview(true)

			local tileLight = self:getBattleTileLight(tile)

			table.insert(lightForceTile, {
				tile = tile,
				startLight = tile:getGroundLight() or self.config.light.min,
				endLight = tileLight
			})
			tile:setUnitActive(true)

			local unitCount = 0

			for unitID, unit in pairs(tile.unitMap) do
				if not involvedUnitsMap[unit.id] then
					involvedUnitsMap[unit.id] = true

					table.insert(involvedUnits, unit)
				end

				unitCount = unitCount + 1
			end

			if unitCount == 0 then
				table.insert(freeTiles, tile)
			end
		end

		local monsterIDMap = {}
		local friendIDMap = {}

		for i = 1, #involvedUnits do
			local unit = involvedUnits[i]

			if unit.type == "hero_copy" then
				if unit.camp == 1 then
					if not friendIDMap[unit.id] then
						WarMachine.addUnit(unit, 1, "Map:prepareBattle-4")

						friendIDMap[unit.id] = true
					end
				elseif unit.camp == 2 and not monsterIDMap[unit.id] then
					WarMachine.addUnit(unit, 2, "Map:prepareBattle-4")

					monsterIDMap[unit.id] = true
				end
			elseif unit.type == "monster" and not monsterIDMap[unit.id] then
				WarMachine.addUnit(unit, 2, "Map:prepareBattle-4")

				monsterIDMap[unit.id] = true
			end

			maxHeight = math.max(maxHeight, unit.height - unit.size * self.ptPerTile / 4)
		end

		local darkTiles = {}

		for i, tile in ipairs(outTiles) do
			doneTileMap[tile.tag] = tile

			tile:setForceWalk("battle", 2)
			table.insert(darkTiles, tile)
		end

		for i = 1, #darkTiles do
			local tile = darkTiles[i]

			tile:setUnitActive(false)

			local tileLight = self:getBattleTileLight(tile)

			table.insert(lightForceTile, {
				tile = tile,
				startLight = tile:getGroundLight() or self.config.light.min,
				endLight = tileLight / 2,
				objEndLight = tileLight
			})
		end

		local tweenTime = 45
		local tweenObj = {
			lightPercent = 0
		}

		local function onTweenUpdate()
			for i = 1, #lightForceTile do
				local lightObj = lightForceTile[i]
				local light = (1 - tweenObj.lightPercent) * lightObj.startLight + tweenObj.lightPercent * lightObj.endLight
				local objLight = light

				if lightObj.objEndLight then
					objLight = (1 - tweenObj.lightPercent) * lightObj.startLight + tweenObj.lightPercent * lightObj.objEndLight
				end

				lightObj.tile:setLightForce(light, objLight)
			end
		end

		self.lightForceTile = lightForceTile
		self.lightForceMap = {}

		for i, v in ipairs(lightForceTile) do
			self.lightForceMap[v.tile.tag] = true
		end

		local function onTweenComplete()
			onTweenUpdate()

			self.isBattlePrepare = nil
		end

		MapFrameManager.tween(tweenTime, tweenObj, {
			lightPercent = 1
		}, "outQuad", onTweenComplete, onTweenUpdate)

		maxHeight = maxHeight + 20
		local battleZoomin = self.height / ((range * 2 + 1) * self.ptPerTile / 2 + maxHeight)
		self.battleZoom = battleZoomin / self.config.scale.map
		local x, y = self:tileToMap(centerTile)

		self:tweenViewZoom(battleZoomin / self.config.scale.map, tweenTime, nil, true)

		local offset = maxHeight

		self:tweenScrollTo(x - offset, y - offset, tweenTime, function ()
			start(createParams)
		end, nil, true)
		self:setMaskPosition(x, y)

		if self.lightForceTile then
			for _, obj in ipairs(self.lightForceTile) do
				obj.tile:fadeoutAssets()
			end
		end

		local _everGroups = {}

		if createParams.monsterCreateID then
			local monsterCreateCSV = CsvParser.getCsvData("monster_create", createParams.monsterCreateID)
			local battleList = SheetUtil.getColumnList(monsterCreateCSV, {
				"ever_battle",
				"ever_max",
				"ever_start_time",
				"ever_wait_time"
			}, {
				"drop",
				"max",
				"start_time",
				"wait_time"
			})

			for i, battle in ipairs(battleList) do
				battle.seed = math.random(1, 65535)
				battle.pack = createParams.pack
				battle.stop = monsterCreateCSV.ever_battle_stop

				table.insert(_everGroups, battle)
			end
		end

		WarMachine.setEverGroups(_everGroups)
		global.ui:onBattleReady()
	end

	delay = math.max(delay, jumpinDelay)

	if delay > 0 then
		MapFrameManager.setTimeout(ready, delay)
	else
		ready()
	end

	WarMachine.startBuffCopy(copyMap, petIndexMap)
end

function Map:getBattleTileLight(tile)
	local distance = math.sqrt(math.pow(tile.x - self.battleCenterTile.x, 2) + math.pow(tile.y - self.battleCenterTile.y, 2))
	local tileLight = 1.1 - distance * 0.1

	if tileLight > 0 then
		tileLight = math.min(1, math.max(self.config.light.min, math.pow(tileLight, self.config.light.decay)))
	else
		tileLight = self.config.light.min
	end

	return tileLight
end

function Map:onEnter()
end

function Map:onExit()
	self:clearMapTouch()

	if not self.isFake then
		MapEffect.clear()
		Clip.clear()
		MapFrameManager.clearWithMap()
		MapEventManager.clear()
		Tile.clear()
		Monster.clear()

		Map.NO_UNIT_BLOCK = false
		Map.NO_FORCE_WALK = false
		Map.walkOnVislble = true
		Map.assets = nil
	end
end

return Map
