local POP_dialog = class("POP_dialog", UI_base)
local stack = {}
local currentInstance = nil

function POP_dialog.open(id, onComplete, isTest, testText, onTestError)
	LayerConfig.setPopLocked("POP_dialog", true)
	table.insert(stack, {
		id = id,
		onComplete = onComplete,
		isTest = isTest,
		testText = testText,
		onTestError = onTestError
	})
	POP_dialog.nextQueue()
end

function POP_dialog.getInstance()
	return currentInstance
end

function POP_dialog.isOpening()
	return currentInstance ~= nil
end

function POP_dialog.close()
	if currentInstance and not tolua.isnull(currentInstance) then
		currentInstance:removeSelf()
	end

	currentInstance = nil

	LayerConfig.setPopLocked("POP_dialog", false)
end

function POP_dialog.removeCurrent()
	currentInstance = nil

	if not POP_dialog.nextQueue() then
		LayerConfig.setPopLocked("POP_dialog", false)
	end
end

function POP_dialog.nextQueue()
	if currentInstance or #stack == 0 then
		return false
	end

	local obj = table.remove(stack, 1)
	currentInstance = POP_dialog.new(obj.isTest, obj.testText, obj.onTestError)

	currentInstance:show(obj.id, obj.onComplete)

	if currentInstance then
		display.getRunningScene():addChild(currentInstance, LayerConfig.dialog)
	end

	return true
end

function POP_dialog.clear()
	stack = {}
	currentInstance = nil
end

function POP_dialog:ctor(isTest, testText, onTestError)
	POP_dialog.super.ctor(self, "pop_dialog", UIManager.BIG_TYPE.POP)

	self.isTest = isTest
	self.testText = testText
	self.onTestError = onTestError

	self:init()
end

function POP_dialog:init()
	self:initUI()
	self:hideArrow()
end

function POP_dialog:initUI()
	local mask = self:getComponentByTag("mask")

	mask:setOpacity(0)
	mask:toTouchable()
end

function POP_dialog:show(dialogID, onComplete)
	self.onComplete = onComplete
	local data = CsvParser.getCsvData("dialog", dialogID)
	self.data = data

	if self.isTest then
		currentInstance:setScale(0.5)
	end

	local mask = self:getComponentByTag("mask")

	mask:setOpacity(math.floor((data.bg_alpha or 0) * 255))

	local dataArray = string.split(self.testText or data.text, "\n")
	self.dialogs = {}
	self.side = tonumber(data.side) or 1
	self.dialogIndex = 1
	self.stackIndex = 1

	for i = 1, #dataArray do
		local dataStr = dataArray[i]
		dataStr = StringUtil.replaceTag(dataStr, function (tag, embedded)
			return ManagerInfo.parseTag(tag, not embedded)
		end)
		local arr = string.split(dataStr, "#")
		local rawText = arr[2]
		local stack = Ubb.parseClause(rawText)

		if stack and not self:noPersonSkip(arr[1]) then
			table.insert(self.dialogs, {
				person = arr[1],
				stack = stack
			})
		end
	end

	self:next()
end

function POP_dialog:showAnswers(answers, callback)
	self:closeAnswers()

	local answerFlag = self:getFlagByTag("flag_answers")
	self.answerUiArr = {}

	for i, answer in ipairs(answers) do
		local ui = UIManager.getUI("pop_dialog_answer")

		ui:setPosition(answerFlag.x, answerFlag.y + (i - 1) * 80)
		ui:createLabelOnFlag("flag_text", answer)

		local bg = ui:getComponentByTag("bg")

		bg:toTouchable()
		bg:addTap(function ()
			if callback then
				callback(i)
			end
		end)
		self:addChild(ui, 100)
		table.insert(self.answerUiArr, ui)
	end
end

function POP_dialog:closeAnswers()
	if self.answerUiArr then
		for i, ui in ipairs(self.answerUiArr) do
			ui:removeSelf()
		end

		self.answerUiArr = nil
	end
end

function POP_dialog:nextIsQa()
	local data = self.dialogs[self.dialogIndex]

	if data then
		local stackObj = data.stack[self.stackIndex]

		if stackObj and stackObj.answers then
			return true
		end
	end
end

function POP_dialog:next()
	if self.dialogIndex <= #self.dialogs then
		local data = self.dialogs[self.dialogIndex]

		if self.stackIndex == 1 then
			self:setHead(data.person, 2 - self.dialogIndex % 2)
			self:setName(data.person)
		end

		local stackObj = data.stack[self.stackIndex]

		if stackObj then
			if stackObj.answers then
				self:showAnswers(stackObj.answers, function (index)
					self:closeAnswers()

					local qaDialogID = stackObj.stack[index]

					self:show(qaDialogID, self.onComplete)
				end)
			elseif stackObj.dialog then
				self:show(stackObj.dialog, self.onComplete)
			else
				self:setText(stackObj)

				if self.stackIndex < #data.stack then
					self.stackIndex = self.stackIndex + 1
				else
					self.dialogIndex = self.dialogIndex + 1
					self.stackIndex = 1
				end

				if self.isTest then
					if self.testTotalHeight > 100 then
						self:onTestError("tooHeight")
					else
						self:onTestError("next")
					end
				end
			end

			return
		end
	end

	if self.isTest then
		self:onTestError("over")
	end

	if self.onComplete then
		self.onComplete()
	end

	if not empty(self.data.quest) and InfoQuest.canAccept(self.data.quest) then
		InfoQuest.accept(self.data.quest)
	end

	if not empty(self.data.pet) then
		local petID = self.data.pet
		local pos = InfoPet.getFreePos()

		if pos then
			InfoPet.add(petID, pos)
		else
			FRAME_pet_replace.open(function (replacePetData)
				InfoPet.add(petID, replacePetData.pos)
			end)
		end
	end

	self:removeSelf()
	POP_dialog.removeCurrent()
end

function POP_dialog:setName(person)
	local personName = self:getPersonName(person)
	local nameBG = self:getComponentByTag("name_bg")

	if not empty(personName) then
		local label, labelWidth = self:createLabelOnFlag("flag_name", self:getPersonName(person))

		nameBG:setLocalZOrder(200)
		nameBG:setSize(labelWidth + 20)
		nameBG:setPos(label.x - nameBG.width / 2)
		nameBG:setVisible(true)
	else
		self:removeLabelOnFlag("flag_name")
		nameBG:setVisible(false)
	end
end

function POP_dialog:noPersonSkip(person)
	local personArr = string.split(person, ":")
	local personType = string.trim(personArr[1])

	if personType == "team" then
		local trimStr = string.trim(personArr[2])
		local index = tonumber(trimStr)

		if index > 1 then
			index = math.min(index, TeamManager.getTeamNum())
		end

		local unit = TeamManager.getUnit(index)

		if not unit then
			return true
		end
	end

	return false
end

function POP_dialog:getPersonName(person)
	local personArr = string.split(person, ":")
	local personType = string.trim(personArr[1])

	if personType == "player" then
		return InfoHero.getHero().name
	elseif personType == "hero" then
		local trimStr = string.trim(personArr[2])
		local pos = tonumber(trimStr)
		local heroInfo = InfoHero.getHeroByPos(pos)

		return InfoHero.getName(heroInfo)
	elseif personType == "npc" then
		local csv = CsvParser.getCsvData("npc", string.trim(personArr[2]), nil, true)

		if csv then
			return csv.name
		end
	elseif personType == "pet" then
		local csv = CsvParser.getCsvData("pet", string.trim(personArr[2]), nil, true)

		if csv then
			return csv.name
		end
	elseif personType == "monster" then
		local csv = CsvParser.getCsvData("monster", string.trim(personArr[2]), nil, true)

		if csv then
			return csv.name
		end
	elseif personType == "chance" then
		local csv = CsvParser.getCsvData("chance", string.trim(personArr[2]), nil, true)

		if csv then
			return csv.name
		end
	elseif personType == "team" then
		local trimStr = string.trim(personArr[2])
		local index = tonumber(trimStr)

		if index > 1 then
			index = math.min(index, TeamManager.getTeamNum())
		end

		local unit = TeamManager.getUnit(index)

		if unit then
			return unit.info.name
		end
	elseif personArr[1] == "hero_templete" then
		local csv = CsvParser.getCsvData("hero_templete", string.trim(personArr[2]), nil, true)

		if csv then
			return csv.name
		end
	end
end

function POP_dialog:getPersonUnit(person)
	local personArr = string.split(person, ":")
	local personType = string.trim(personArr[1])

	if personType == "player" then
		return global.player
	elseif personType == "hero" then
		local heroList = ClipOnMap.getUnitList("hero")
		local trimStr = string.trim(personArr[2])
		local pos = tonumber(trimStr)

		for i, hero in ipairs(heroList) do
			if hero.info.pos == pos then
				return hero
			end
		end
	elseif personType == "npc" then
		return Npc.getInstance(string.trim(personArr[2]))
	elseif personType == "pet" then
		return Npc.getPet(string.trim(personArr[2]))
	elseif personType == "monster" then
		return Monster.getMonsterByBaseID(string.trim(personArr[2]))
	elseif personType == "chance" then
		return Npc.getChance(string.trim(personArr[2]))
	elseif personType == "team" then
		local trimStr = string.trim(personArr[2])
		local index = tonumber(trimStr)

		if index > 1 then
			index = math.min(index, TeamManager.getTeamNum())
		end

		return TeamManager.getUnit(index)
	elseif personType == "hero_templete" then
		return Npc.getHeroTemplete(string.trim(personArr[2]))
	end
end

function POP_dialog:setHead(person, index)
	if empty(person) then
		return
	end

	local flag = self:getFlagByTag("flag_head")
	local centerX = flag.x + flag.width / 2
	local centerY = flag.y + flag.height / 2

	if self.person ~= person then
		if self.personHead then
			local preHead = self.personHead

			transition.stopTarget(preHead)
			transition.fadeTo(preHead, {
				time = 0.1,
				easing = "sineOut",
				opacity = 0,
				onComplete = function ()
					preHead:removeSelf()
				end
			})

			self.personHead = nil

			self:setComponentToTag("flag_head")
		end

		local head = nil
		local personArr = string.split(person, ":")
		local personType = string.trim(personArr[1])
		local baseID = string.trim(personArr[2])
		local emoji = nil

		if not empty(personArr[3]) then
			emoji = tonumber(string.trim(personArr[3]))
		end

		local csv = CsvParser.getCsvData(personType, baseID, nil, true)

		if csv and not empty(csv.head) then
			local pic = IconManager.getHead(csv.head, emoji)
			head = self:createIconOnFlag("flag_head", pic, 100, UILayout.SCALE_TYPE.LARGE, nil, , UILayout.ALIGN_TYPE.BOTTOM)
		else
			local personUnit = self:getPersonUnit(person)

			if personUnit and not personUnit.spineData then
				head = PortraitManager.getUnitMugshot(personUnit, flag, 3, 0, {
					x = 0,
					y = 5
				})
			else
				local csv = CsvParser.getCsvData(personType, baseID, nil, true)

				if csv then
					head = PortraitManager.getMixedMugshot(personType, baseID, flag, 3, 0, {
						x = 0,
						y = 5
					})
				end
			end

			if head then
				self:addChild(head, 100)

				local size = head:getContentSize()

				head:setScale(math.min(flag.width / size.width, flag.height / size.height))
				head:setLocalZOrder(100)
				head:setPosition(centerX, centerY)
				head:setColor(cc.c3b(255, 255, 255))
			end
		end

		if head then
			head:setOpacity(0)
			transition.fadeTo(head, {
				time = 0.1,
				easing = "sineOut",
				opacity = 255
			})
		end

		self.personHead = head
		self.person = person
	end
end

function POP_dialog:setText(text)
	local isLight = false

	if Localization.isAlphabet() then
		isLight = true
	end

	local ubbMap, labels, lines, totalWidth, totalHeight = self:createUbbOnFlag("flag_text", text, {
		wrap = true
	}, isLight)
	self.testTotalHeight = totalHeight
	local fadeTime = 0.02
	local defaultInterval = 0.025
	local defaultLineInterval = 0
	local textOver = false

	local function onUbbComplete()
		textOver = true

		self:showArrow()

		if self:nextIsQa() then
			self:next()
		end
	end

	if isTest then
		-- Nothing
	elseif Localization.isAlphabet() then
		local fadeTime = 0.2

		for i, label in ipairs(labels) do
			label:setOpacity(0)
			transition.fadeIn(label, {
				time = fadeTime
			})
		end

		self:performWithDelay(onUbbComplete, fadeTime)
	else
		self:animateUbb(ubbMap, labels, fadeTime, defaultInterval, defaultLineInterval, onUbbComplete)
	end

	local mask = self:getComponentByTag("mask")

	local function onMaskTap()
		if self.answerUiArr then
			return
		end

		if textOver then
			self:hideArrow()
			mask:removeTap()
			self:next()
		else
			for i = 1, #labels do
				local label = labels[i]

				transition.stopTarget(label)
				label:setOpacity(255)
			end

			textOver = true

			self:showArrow()

			if self:nextIsQa() then
				self:next()
			end
		end
	end

	mask:addTap(onMaskTap)
end

function POP_dialog:hideArrow()
	local arrow = self:getComponentByTag("arrow")

	transition.stopTarget(arrow)
	arrow:setOpacity(0)
end

function POP_dialog:showArrow()
	local arrow = self:getComponentByTag("arrow")

	transition.stopTarget(arrow)
	Style.makePuyo(arrow)
	transition.fadeIn(arrow, {
		time = 0.2
	})
end

return POP_dialog
