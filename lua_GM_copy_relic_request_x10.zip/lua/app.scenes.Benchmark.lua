local Benchmark = class("Benchmark", function ()
	return display.newScene("Benchmark")
end)
local events = {
	{
		defaultInterval = 30,
		with = "abyss_battle",
		id = "abyss_enter",
		name = "深渊进入"
	},
	{
		defaultInterval = 30,
		id = "abyss_battle",
		name = "深渊战斗"
	},
	{
		defaultInterval = 1,
		id = "tavern_refresh",
		name = "酒馆刷新"
	},
	{
		defaultInterval = 1,
		id = "camp_move",
		name = "营地走动"
	}
}
Benchmark.events = events

function Benchmark:ctor()
	global.isBenchmark = true
	self.ready_ui = FRAME_benchmark_ready.new(self)

	self:addChild(self.ready_ui)
end

function Benchmark:start(params, eventMap, eventArr)
	self.ready_ui:removeSelf()

	self.ready_ui = nil
	self.ui = FRAME_benchmark.new(self, params, eventMap, eventArr)

	self:addChild(self.ui)
end

function Benchmark:init()
end

function Benchmark:onEnter()
	app:onSceneEnter(self)
	self:init()
end

function Benchmark:onExit()
	app:onSceneExit(self)
end

return Benchmark
