local InfoQuest = {}
local rawData = {}
local autoAcceptLocked = false

function InfoQuest.init()
	Connection.listen("quest_sync", InfoQuest.sync)
	Connection.listen("quest_sync_remove", InfoQuest.syncRemove)
end

app:addToAppEnterCall(InfoQuest.init)

function InfoQuest.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoQuest.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("quest_query", callback)
end

function InfoQuest.onQuery(rcvData)
	rawData = {}

	for i, data in ipairs(rcvData.list) do
		local questData = CsvParser.getCsvData("quest", data.base_id)

		if questData then
			rawData[data.id] = data
		end
	end
end

function InfoQuest.sync(data)
	dump(data, "$$$ InfoQuest.sync")

	local changedIdStack = {}

	for i, syncData in ipairs(data.list) do
		local id = syncData.id

		if rawData[id] then
			for k, v in pairs(syncData) do
				rawData[id][k] = v
			end
		else
			rawData[id] = syncData
		end

		changedIdStack[id] = rawData[id]
	end

	ManagerInfo.dataChange("quest", changedIdStack)
end

function InfoQuest.syncRemove(data)
	dump(data, "$$$ InfoQuest.syncRemove")

	local changedIdStack = {}

	for i, id in ipairs(data.list) do
		if rawData[id] then
			changedIdStack[id] = rawData[id]
			rawData[id] = nil
		end
	end

	ManagerInfo.dataChange("quest", changedIdStack)
end

function InfoQuest.refresh(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Http.request("quest/refresh", callback)
end

function InfoQuest.getDungeonQuests(dungeon_id)
	local quests = {}

	for _id, info in pairs(rawData) do
		if info.dungeon_id == dungeon_id then
			table.insert(quests, info)
		end
	end

	return quests
end

function InfoQuest.getQuestID(quest_base_id)
	for _id, info in pairs(rawData) do
		if info.base_id == quest_base_id then
			return info.id
		end
	end
end

function InfoQuest.getQuestLevel()
	return InfoDungeon.getAbyssMaxLevel()
end

function InfoQuest.getInfo(id)
	return rawData[id]
end

function InfoQuest.getQuestReward(questInfo)
	local rewardArr = {}

	for i = 1, 3 do
		if not empty(questInfo["reward_item_" .. i]) and not empty(questInfo["reward_num_" .. i]) then
			table.insert(rewardArr, {
				base_id = questInfo["reward_item_" .. i],
				num = questInfo["reward_num_" .. i]
			})
		end
	end

	return rewardArr
end

return InfoQuest
