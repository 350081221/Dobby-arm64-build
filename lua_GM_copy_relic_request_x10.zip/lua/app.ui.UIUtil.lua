local UIUtil = {}

function UIUtil.createStar(ui, tag, starNum, xOffset, yOffset, align, frame, scale, zorder)
	ui:clearDuplicated(tag)
	ui:getComponentByTag(tag):setVisible(true)

	if starNum == 0 then
		ui:getComponentByTag(tag):setVisible(false)

		return {}
	else
		local stars = ui:duplicateComponent(tag, starNum - 1, xOffset, yOffset, align)

		for i, star in ipairs(stars) do
			if frame then
				star:setFrame(frame)
			end

			if scale then
				star:setScale(scale)
			end

			if zorder then
				star:setLocalZOrder(zorder)
			end
		end

		return stars
	end
end

return UIUtil
