local NAV_base = import(".NAV_base")
local NAV_hatch_get = class("NAV_hatch_get", NAV_base)

function NAV_hatch_get.open(npc, pos)
	local ui = NAV_hatch_get.new(npc, pos)

	return ui
end

function NAV_hatch_get:ctor(npc, pos)
	self.pos = pos

	NAV_hatch_get.super.ctor(self, npc, "nav_hatch_get")
end

function NAV_hatch_get:init()
	NAV_hatch_get.super.init(self)

	local ui = self.buttons[1].ui

	ui:createBarByTag("progress", NAV_base.COLOR.PROGRESS, true)
	self:refresh(true)
	self:addEnterFrame("fresh", function ()
		self:refresh()
	end)
end

function NAV_hatch_get:refresh(isFirst)
	local per, timeLeft = InfoPetHatch.getHatchTime(self.pos)
	local ui = self.buttons[1].ui

	ui:createLabelOnFlag("flag_timeleft", Time.format(timeLeft))
	ui:setBarProgressByTag("progress", per)

	if per >= 1 then
		ui:setBarColorByTag("progress", NAV_base.COLOR.READY)
	else
		ui:setBarColorByTag("progress", NAV_base.COLOR.PROGRESS)
	end

	local button = self.buttons[2].button
	local ui = self.buttons[2].ui
	local shadow = self.buttons[2].shadow

	if timeLeft > 0 then
		local accNeed = CsvParser.getCsvData("config", "hatch_speedup_need").value
		local accPrice = CsvParser.getCsvData("config", "hatch_speedup_need_price").value
		local speedupItem = CsvParser.getCsvData("config", "hatch_speedup_item").value
		local speedupTime = CsvParser.getCsvData("config", "hatch_speedup_time").value
		local speedupItemNum = InfoItem.getNum(speedupItem)

		if speedupItemNum > 0 then
			if self.nowIcon ~= 1 then
				self.nowIcon = 1

				ui:createIconOnFlag("flag_icon", IconManager.getItemIcon(speedupItem), 100, true)

				local shadow = ui:createIconOnFlag("flag_icon_shadow", IconManager.getItemIcon(speedupItem), 99, true)

				shadow:setColor(cc.c3b(0, 0, 0))
				shadow:setOpacity(64)
			end

			ui:createLabelOnFlag("flag_num", speedupItemNum)
		else
			local accItemNum = InfoItem.getNum(accNeed)
			local accItemNeed = math.ceil(timeLeft / 3600 * accPrice)

			if self.nowIcon ~= 2 then
				self.nowIcon = 2

				ui:createIconOnFlag("flag_icon", IconManager.getItemIcon(accNeed), 100, true)

				local shadow = ui:createIconOnFlag("flag_icon_shadow", IconManager.getItemIcon(accNeed), 99, true)

				shadow:setColor(cc.c3b(0, 0, 0))
				shadow:setOpacity(64)
			end

			local color = nil

			if accItemNum < accItemNeed then
				color = Style.red
			end

			ui:createLabelOnFlag("flag_num", accItemNeed, {
				color = color
			})
		end
	else
		self.buttons[2].enabled = false

		if not self.isAlreadyClosed then
			self.isAlreadyClosed = true

			if isFirst then
				button:setVisible(false)

				if shadow then
					shadow:setVisible(false)
				end
			else
				transition.scaleTo(button, {
					easing = "backIn",
					scale = 0,
					time = 0.2,
					delay = delay,
					onComplete = function ()
						button:setVisible(false)
					end
				})

				if shadow then
					transition.scaleTo(shadow, {
						easing = "backIn",
						scale = 0,
						time = 0.2,
						delay = delay,
						onComplete = function ()
							shadow:setVisible(false)
						end
					})
				end
			end
		end
	end
end

function NAV_hatch_get:onTap(index)
	NAV_hatch_get.super.onTap(self, index)

	if index == 1 then
		InfoPetHatch.born(self.pos, 0, function ()
			InfoBuilding.playOpenSfx(InfoBuilding.TAG.PET)

			if global.player then
				global.player:npcChanged(true)
			end
		end)
	elseif index == 2 then
		local speedupItem = CsvParser.getCsvData("config", "hatch_speedup_item").value
		local speedupItemNum = InfoItem.getNum(speedupItem)
		local acc = 1

		if speedupItemNum > 0 then
			acc = 2
		end

		InfoPetHatch.born(self.pos, acc, function (rcvData)
			InfoBuilding.playOpenSfx(InfoBuilding.TAG.PET)

			if rcvData.is_born == 1 and global.player then
				global.player:npcChanged(true)
			end
		end)
	end
end

return NAV_hatch_get
