local POP_show_item = class("POP_show_item", UI_base)

function POP_show_item.open(rewardList, title)
	local ui = POP_show_item.new(rewardList, title)

	PopManager.open(ui)
end

function POP_show_item:ctor(rewardList, title)
	POP_show_item.super.ctor(self, "pop_show_item", UIManager.BIG_TYPE.CENTER)

	self.rewardList = rewardList
	self.title = title

	self:init()
end

function POP_show_item:init()
	self:initUI()
end

function POP_show_item:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local function tapListener(ui, itemInfo, index, x, y)
		DropManager.popDetail(DropManager.TYPE.ITEM, itemInfo)
	end

	self.list = self:createListOnFlag("flag_list", LIST_show_item, tapListener)

	self.list:setTapGroup("list_click")

	local holder = self:getComponentByTag("holder")

	self.list:setHolders({
		holder
	}, nil, 5)
	self.list:setItems(self.rewardList)

	if not empty(self.title) then
		self:createLabelOnFlag("flag_title", self.title)
	else
		self:removeLabelOnFlag("flag_title")
	end

	local bt_confirm = self:getComponentByTag("bt_confirm")

	bt_confirm:toTouchable()
	bt_confirm:setTapGroup("button_click")
	bt_confirm:addTap(function ()
		PopManager.closeTo(self)
	end)
end

return POP_show_item
