local InfoMission = {}
local rawData = nil

function InfoMission.init()
	Connection.listen("mission_sync", InfoMission.sync)
end

app:addToAppEnterCall(InfoMission.init)

function InfoMission.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoMission.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("mission_query", callback)
end

function InfoMission.onQuery(rcvData)
	rawData = rcvData
end

function InfoMission.sync(data)
	dump(data, "$$$ InfoMission.sync")

	for k, v in pairs(data) do
		rawData[k] = v
	end

	ManagerInfo.dataChange("mission", data)
end

local currentRecordID = nil

function InfoMission.getRecord(id)
	local section, position = BitUtil.split(30, id)
	local recordNum = rawData["record_" .. section]

	return BitUtil.getBitByIndex(recordNum, position)
end

function InfoMission.getRecordID(missionID, cIndex)
	local recordIndex = (missionID - 1) * 3 + cIndex

	return recordIndex
end

function InfoMission.setDramaBattle(finishEventIndex)
	InfoMission.isDramaBattle = finishEventIndex
	InfoMission.dramaFinishBattleEventIndex = finishEventIndex
end

function InfoMission.clearDramaBattle()
	InfoMission.isDramaBattle = nil
	InfoMission.dramaFinishBattleEventIndex = nil
end

function InfoMission.drama(dramaName, missionID, cIndex, eventIndex)
	DramaManager.start(dramaName, nil, , function ()
		if currentRecordID then
			local function onSuccess()
				if missionID and cIndex and eventIndex then
					local missionCSV = CsvParser.getCsvData("mission", missionID)

					if cIndex == 2 and missionCSV.cpoint2_param == 2 or cIndex == 3 and missionCSV.cpoint3_param == 2 then
						InfoDungeon.finishMonsterDrama(eventIndex)
					elseif InfoMission.dramaFinishBattleEventIndex then
						InfoDungeon.finishMonsterDrama(InfoMission.dramaFinishBattleEventIndex)
					end
				end

				InfoMission.clearDramaBattle()
			end

			InfoMission.finish(currentRecordID, onSuccess)
		end
	end)
end

function InfoMission.check(missionID, cIndex)
	local recordID = InfoMission.getRecordID(missionID, cIndex)

	return InfoMission.getRecord(recordID) == 0
end

function InfoMission.trigger(cIndex, pIndex, params)
	if DramaManager.opening then
		return
	end

	if DramaManager.isBranch then
		return
	end

	local missionID = InfoDungeon.getMissionID()

	if empty(missionID) then
		return false
	end

	if not InfoMission.check(missionID, cIndex) then
		return false
	end

	local missionCSV = CsvParser.getCsvData("mission", missionID)

	if cIndex == 1 then
		if missionCSV.cpoint1_param == pIndex and missionCSV.cpoint1_disabled ~= 1 and not empty(missionCSV.cpoint1_drama) then
			local tile = params.tile
			local eventIndex = params.eventIndex

			DramaManager.presetTile(tile)
			DramaManager.presetEventID(eventIndex)
			InfoMission.drama(missionCSV.cpoint1_drama, missionID, cIndex, eventIndex)

			currentRecordID = InfoMission.getRecordID(missionID, cIndex)

			return true
		end
	elseif cIndex == 2 then
		if missionCSV.cpoint2_param == pIndex and missionCSV.cpoint2_disabled ~= 1 then
			if pIndex == 1 then
				if not empty(missionCSV.cpoint2_drama) then
					local tile = params.tile
					local eventIndex = params.eventIndex

					DramaManager.presetTile(tile)
					DramaManager.presetEventID(eventIndex)
					InfoMission.drama(missionCSV.cpoint2_drama, missionID, cIndex, eventIndex)

					currentRecordID = InfoMission.getRecordID(missionID, cIndex)

					return true
				end
			elseif pIndex == 2 then
				if not empty(missionCSV.cpoint2_drama) then
					local tile = params.tile
					local eventIndex = params.eventIndex

					DramaManager.presetTile(tile)
					DramaManager.presetEventID(eventIndex)
					InfoMission.drama(missionCSV.cpoint2_drama, missionID, cIndex, eventIndex)

					currentRecordID = InfoMission.getRecordID(missionID, cIndex)

					return true
				end
			elseif pIndex == 3 and not empty(missionCSV.cpoint2_drama) then
				local tile = params.tile
				local eventIndex = params.eventIndex

				DramaManager.presetTile(tile)
				DramaManager.presetEventID(eventIndex)
				InfoMission.drama(missionCSV.cpoint2_drama, missionID, cIndex, eventIndex)

				currentRecordID = InfoMission.getRecordID(missionID, cIndex)

				return true
			end
		end
	elseif cIndex == 3 and missionCSV.cpoint3_param == pIndex and missionCSV.cpoint3_disabled ~= 1 then
		if pIndex == 1 then
			if not empty(missionCSV.cpoint3_drama) then
				local tile = params.tile
				local eventIndex = params.eventIndex

				DramaManager.presetTile(tile)
				DramaManager.presetEventID(eventIndex)
				InfoMission.drama(missionCSV.cpoint3_drama, missionID, cIndex, eventIndex)

				currentRecordID = InfoMission.getRecordID(missionID, cIndex)

				return true
			end
		elseif pIndex == 2 then
			if not empty(missionCSV.cpoint3_drama) then
				local tile = params.tile
				local eventIndex = params.eventIndex

				DramaManager.presetTile(tile)
				DramaManager.presetEventID(eventIndex)
				InfoMission.drama(missionCSV.cpoint3_drama, missionID, cIndex, eventIndex)

				currentRecordID = InfoMission.getRecordID(missionID, cIndex)

				return true
			end
		elseif pIndex == 3 and not empty(missionCSV.cpoint3_drama) then
			local tile = params.tile
			local eventIndex = params.eventIndex

			DramaManager.presetTile(tile)
			DramaManager.presetEventID(eventIndex)
			InfoMission.drama(missionCSV.cpoint3_drama, missionID, cIndex, eventIndex)

			currentRecordID = InfoMission.getRecordID(missionID, cIndex)

			return true
		end
	end

	return false
end

function InfoMission.finish(record_id, onSuccess, onFailure)
	if InfoMission.getRecord(record_id) == 0 then
		local function callback(rcvData)
			if rcvData.err then
				if onFailure then
					onFailure()
				end
			elseif onSuccess then
				onSuccess()
			end
		end

		Connection.request("mission_finish", {
			record_id = record_id
		}, callback)
	end
end

function InfoMission.checkLayer(layer)
	local mission_csv_by_layer = CacheData.get("InfoMission_mission_csv_by_layer")

	if not mission_csv_by_layer then
		mission_csv_by_layer = {}
		local csv_raw = CsvParser.getCsvRaw("mission")

		for id, v in pairs(csv_raw) do
			mission_csv_by_layer[v.abyss_layer] = v
		end

		CacheData.set("InfoMission_mission_csv_by_layer", mission_csv_by_layer)
	end

	if mission_csv_by_layer[layer] then
		local mission_csv = mission_csv_by_layer[layer]

		for i = 1, 3 do
			if mission_csv["cpoint" .. i .. "_disabled"] ~= 1 and not empty(mission_csv["cpoint" .. i .. "_drama"]) and not empty(mission_csv["cpoint" .. i .. "_param"]) then
				local recordIndex = InfoMission.getRecordID(mission_csv.id, i)

				if InfoMission.getRecord(recordIndex) <= 0 then
					return mission_csv
				end
			end
		end
	end
end

function InfoMission.getNextMission()
	local missionCSVList = CsvParser.getCsvList("mission")
	local abyssLayer = InfoDungeon.getAbyssMaxLayer()
	local lastCSV = nil

	for i, v in ipairs(missionCSVList) do
		lastCSV = v

		if abyssLayer <= v.abyss_layer then
			break
		end
	end

	return lastCSV
end

return InfoMission
