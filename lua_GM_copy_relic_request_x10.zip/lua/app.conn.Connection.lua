local proto = import("..proto.proto")
local sproto = import("..proto.sproto")
local Scheduler = cc.Director:getInstance():getScheduler()

require("pack")

local function pack_msg(str)
	if _VERSION ~= "Lua 5.3" then
		local len = string.len(str)
		local leninfo = string.pack("bb", math.floor(len / 256), len % 256)

		return string.pack("A", leninfo .. str)
	else
		return string.pack(">s2", str)
	end
end

local host = sproto.new(proto.s2c):host("package")
local request = host:attach(sproto.new(proto.c2s))
local queryproto = nil
local last = ""

local function unpack_package(text)
	local size = #text

	if size < 2 then
		return nil, text
	end

	local s = text:byte(1) * 256 + text:byte(2)

	if size < s + 2 then
		return nil, text
	end

	return text:sub(3, 2 + s), text:sub(3 + s)
end

local function recv_package(r)
	local result = nil
	result, last = unpack_package(last)

	if result then
		return host:dispatch(result)
	end

	result, last = unpack_package(last .. r)

	if result then
		return host:dispatch(result)
	end
end

local session = 0

local function pack_request(name, args)
	session = session + 1
	local str = request(name, args, session)
	local package = pack_msg(str)

	return package, session
end

local function print_request(name, args)
	print("REQUEST", name)

	if args then
		for k, v in pairs(args) do
			print(k, v)
		end
	end
end

local function print_response(session, args)
	print("RESPONSE", session)

	if args then
		for k, v in pairs(args) do
			print(k, v)
		end
	end
end

local function print_package(t, ...)
	if t == "REQUEST" then
		print_request(...)
	else
		assert(t == "RESPONSE")
		print_response(...)
	end
end

local SimpleTCP = require("framework.SimpleTCP")
local Connection = {
	host = nil,
	port = nil,
	socket = nil
}

function Connection.init(host, port, onAuthReady)
	Connection.listen("auth_ok", function ()
		print("$$$ auth_ok")
		Connection.send("auth_ok")

		Connection.sendLock = nil
	end)
	Connection.listen("load_ok", function ()
		print("$$$ load_ok")
		InfoUser.afterLogin()

		Connection.sendLock = nil
	end)
	Connection.listen("auth_ready", function (args)
		dump(args, "auth_ready")

		DEV_MODE = args.dev_mode == 1
		global.server_id = args.server_id
		global.need_active = args.need_active
		global.pay_open = args.pay_open
		global.currency = args.currency
		global.fixed_currency = args.fixed_currency

		Connection.removeListen("auth_ready")

		if onAuthReady then
			onAuthReady()
		end
	end)
	Log.verbose("[Connection.init]", host, port)

	Connection.host = host
	Connection.port = port

	Connection.initSocket()

	local function callback(dt)
		Connection.flushCallback()
		Connection.sendNext()
	end

	local callbackEntry = Scheduler:scheduleScriptFunc(callback, 0.2, false)
end

function Connection.disConnect()
	if Connection.socket then
		Connection.socket:close()
	end
end

function Connection.initSocket()
	Connection.socket = SimpleTCP.new(Connection.host, Connection.port, function (event, data)
		if event ~= SimpleTCP.EVENT_DATA then
			Log.debug("Connection", event, Connection.waitingForReconnect, Connection.isPopConn)
			Console.refreshStat()

			if Connection.waitingForReconnect then
				if Connection.waitingForReconnect == 2 then
					if event == SimpleTCP.EVENT_CONNECTED then
						Connection.waitingForReconnect = 1

						print("$$$ Connection.socket:close 2")
						Connection.socket:close()

						return
					end
				elseif Connection.waitingForReconnect == 1 then
					if event == SimpleTCP.EVENT_CONNECTED then
						Connection.waitingForReconnect = nil

						if Connection.reconnectCallback then
							Connection.reconnectCallback()
						end
					elseif event == SimpleTCP.EVENT_CLOSED or event == SimpleTCP.EVENT_FAILED then
						Connection.socket:connect()
					end
				end

				if not Connection.isPopConn then
					return
				end
			end

			if event == "Connected" then
				Connection.isPopConn = nil
			end

			notify.dispatch("connection", event)
		end

		Connection.onSocketEvent(event, data)
	end)

	Connection.socket:connect()
end

function Connection.connect()
	Connection.socket:connect()
end

function Connection.reconnect(onComplete, isPopConn)
	if InfoUser.isKick then
		return
	end

	print("Connection.reconnect", Connection.getStat(), isPopConn)

	Connection.isPopConn = isPopConn

	if Connection.socket then
		if Connection.socket.stat == SimpleTCP.STAT_CONNECTING then
			Connection.waitingForReconnect = 2
			Connection.reconnectCallback = onComplete
		elseif Connection.socket.stat == SimpleTCP.STAT_CONNECTED then
			Connection.waitingForReconnect = 1
			Connection.reconnectCallback = onComplete

			print("$$$ Connection.socket:close 1")
			Connection.socket:close()
		else
			Connection.socket:connect()
		end
	elseif onComplete then
		onComplete()
	end
end

function Connection.registerSocket()
end

local beatInfo = {}
local beat_check_start = 17
local beat_check_scale = 1.1
local beat_count_threhold = 2
local beat_err_threhold = 3
local beat_reset_time = 37

function Connection.clearBeatCheck()
	beatInfo = {}
end

function Connection.checkBeat(resp)
	local time = resp.time
	local nowTime = math.floor(Time.time())

	if not beatInfo.beatCheckStart or beatInfo.beatCheckEnd < nowTime then
		if beatInfo.beatCheckStart then
			beatInfo.beatErr = math.max(0, (beatInfo.beatErr or 0) - 0.2)
		end

		beatInfo.beat = time
		beatInfo.beatStart = time
		beatInfo.beatCheckStart = nowTime
		beatInfo.beatCheckEnd = nowTime + beat_reset_time
		beatInfo.count = 0
	end

	local clientOffset = nowTime - beatInfo.beatCheckStart
	local serverOffset = time - beatInfo.beatStart

	if beat_check_start < serverOffset and clientOffset > serverOffset * beat_check_scale then
		if beatInfo.count < beat_count_threhold then
			beatInfo.count = beatInfo.count + 1
		else
			beatInfo.count = 0
			beatInfo.beatErr = (beatInfo.beatErr or 0) + 1

			if beatInfo.beatErr < beat_err_threhold then
				beatInfo.beatCheckStart = nil
			else
				InfoUser.report(InfoUser.REPORT_CODE.CHEAT_ACCELERATE_C)
			end
		end
	end
end

function Connection.onSocketEvent(event, data)
	if event == SimpleTCP.EVENT_DATA then
		local t, session_id, resp, err = recv_package(data)

		while t do
			if t == "REQUEST" then
				if session_id == "heartbeat" then
					Connection.checkBeat(resp)
				else
					local pack = Connection.listener[session_id]

					if pack then
						Connection.addCallback(pack.callback, resp)

						if pack.totalTimes then
							pack.times = pack.times + 1

							if pack.totalTimes <= pack.times then
								Connection.listener[session_id] = nil
							end
						end
					end
				end
			else
				assert(t == "RESPONSE")

				Connection.tosendStack[session_id] = nil

				if Connection.response[session_id] then
					if resp.err then
						print("[err]" .. resp.err)

						if DEV_MODE and resp.err == "request_locked" then
							print("$$$ request_locked", Connection.response[session_id].cmd)
						end

						ErrCode.onErr(resp.err)
					end

					Connection.addCallback(Connection.response[session_id].callback, resp)

					if CONFIG.is_ta then
						TaHelper.endAsset()
					end

					if CONFIG.isBench then
						BenchHelper.onResponse(session_id, resp)
					end

					Connection.response[session_id] = nil
				end

				Connection.sendLock = nil
			end

			t, session_id, resp, err = recv_package("")
		end

		Connection.sendNext()
	elseif event == SimpleTCP.EVENT_CONNECTED then
		Connection.clearBeatCheck()
	elseif event == SimpleTCP.EVENT_CONNECTING then
		-- Nothing
	elseif event == SimpleTCP.EVENT_CONNECTED then
		-- Nothing
	elseif event == SimpleTCP.EVENT_CLOSED then
		Connection.clearBeatCheck()

		Connection.ingame = nil
	end
end

Connection.tocallStack = {}

function Connection.addCallback(func, data)
	if app.inScene then
		if DEV_MODE then
			func(data)
		else
			local ok = pcall(func, data)
		end
	else
		table.insert(Connection.tocallStack, {
			func = func,
			data = data
		})
	end
end

function Connection.flushCallback()
	if app.inScene then
		while #Connection.tocallStack > 0 do
			local pack = table.remove(Connection.tocallStack, 1)
			local func = pack.func
			local data = pack.data

			if DEV_MODE then
				func(data)
			else
				local ok = pcall(func, data)
			end
		end
	end
end

Connection.response = {}
Connection.listener = {}
Connection.tosendStack = {}
Connection.sendLock = nil

function Connection.flush()
	dump(Connection.tosendStack, "$$$ Connection.tosendStack")
	Connection.sendNext()
end

function Connection.clearFlush()
	Connection.tosendStack = {}
end

function Connection.send(name, args)
	if Connection.waitingForReconnect then
		return
	end

	local package, session = pack_request(name, args)

	if Connection.socket then
		Connection.tosendStack[session] = package

		if CONFIG.isBench then
			queryproto = queryproto or host:queryproto(sproto.new(proto.c2s))
			local proto = queryproto(name)

			BenchHelper.setSession(session, name, proto.tag, args)
		end

		Connection.sendNext()
	end

	return session
end

function Connection.sendNext()
	if Connection.socket.stat == SimpleTCP.STAT_CONNECTED and (not Connection.sendLock or Connection.sendLock < Time.time()) then
		local tosendList = {}

		for session, package in pairs(Connection.tosendStack) do
			table.insert(tosendList, {
				session = session,
				package = package
			})
		end

		if #tosendList > 0 then
			table.sort(tosendList, function (a, b)
				return a.session < b.session
			end)

			local first = tosendList[1]
			Connection.tosendStack[first.session] = nil
			local package = first.package

			if CONFIG.isBench then
				BenchHelper.onSend(first.session, package)
			end

			Connection.sendLock = Time.time() + GameConfig.request_lock_c

			Connection.socket:send(package)
		end
	end
end

function Connection.request(cmd, args, callback)
	if type(args) == "function" then
		callback = args
		args = {}
	end

	local isTaAsset = nil

	if CONFIG.is_ta and string.sub(cmd, 1, 5) ~= "camp_" then
		TaHelper.startAsset(cmd)
	end

	args.beat = math.floor(Time.lifeTime())
	local session = Connection.send(cmd, args)
	local time = Time.time()

	local function _callback(...)
		if LagRecord then
			local lag = Time.time() - time

			pcall(LagRecord.add, lag * 1000)
		end

		if callback then
			callback(...)
		end
	end

	Connection.response[session] = {
		callback = _callback,
		isTaAsset = isTaAsset,
		cmd = cmd
	}

	return session
end

function Connection.requestCancel(session)
	if session then
		Connection.response[session] = nil
	end
end

function Connection.listen(cmd, callback, times)
	Connection.listener[cmd] = {
		times = 0,
		callback = callback,
		totalTimes = times
	}
end

function Connection.removeListen(cmd)
	Connection.listener[cmd] = nil
end

function Connection.getStat()
	if Connection.socket then
		if Connection.socket.stat == SimpleTCP.STAT_CONNECTING then
			return "connecting"
		elseif Connection.socket.stat == SimpleTCP.STAT_FAILED then
			return "failed"
		elseif Connection.socket.stat == SimpleTCP.STAT_CONNECTED then
			return "connected"
		elseif Connection.socket.stat == SimpleTCP.STAT_CLOSED then
			return "closed"
		end

		return "unknown"
	else
		return "no socket"
	end
end

return Connection
