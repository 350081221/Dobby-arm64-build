local UI_base = import("..UI_base")
local FRAME_abyss_boss_neo = class("FRAME_abyss_boss_neo", UI_base)
local TEAM_MAX = 3
local ptPerTile = 140
local heroIso = {
	{
		y = 2,
		x = 2
	},
	{
		y = 1,
		x = 2
	},
	{
		y = 0,
		x = 2
	}
}
local petIsoMap = {}
local isoDragThreshold = 10

function FRAME_abyss_boss_neo.open(areaCSV, bossCSV, akasaCSV)
	local ui = FRAME_abyss_boss_neo.new(areaCSV, bossCSV, akasaCSV)

	PopManager.open(ui, nil, , , 200)
end

function FRAME_abyss_boss_neo:ctor(areaCSV, bossCSV, akasaCSV)
	self.areaCSV = areaCSV
	self.bossCSV = bossCSV
	self.akasaCSV = akasaCSV

	FRAME_abyss_boss_neo.super.ctor(self, "frame_abyss_boss_neo", UIManager.BIG_TYPE.POP)
	self:init()
end

function FRAME_abyss_boss_neo:init()
	self:initUI()

	local neoList = InfoAbyssArea.getBossNeoList(self.areaCSV.id)

	self:initStand(neoList)
	self:createLabelOnFlag("flag_title", self.areaCSV.boss_name)
	self.list:setItems(neoList)

	local index = 1

	for i, csv in ipairs(neoList) do
		if InfoAbyssArea.checkNeoOpen(self.areaCSV.id, i) then
			index = i
		else
			break
		end
	end

	self.list:setSelectedIndex(index)
	self:refresh()
	ManagerInfo.onDataChange(self, "abyss_area", nil, function ()
		self:refresh()
	end)
end

function FRAME_abyss_boss_neo:initStand(neoList)
	self.standPicArr = {}
	local rect = self:getComponentByTag("stand_mask")
	local pic_mask = rect

	pic_mask:setOpacity(5)

	local zorder = pic_mask:getLocalZOrder()
	local clippingName = "boss_neo"
	local container = display.newNode()

	for i, csv in ipairs(neoList) do
		local clippingData = JsonParser.parse("res/clipping/" .. clippingName .. ".json")
		local picPath = getFinalRes("res/image/" .. clippingData.path .. "/" .. csv.pic .. ".png")
		local pic = display.newSprite(picPath)
		local picData = clippingData.clipping[csv.pic .. ".png"]

		pic:setScale(picData.scale / 100)
		pic:setPosition(rect.x + math.floor(clippingData.width / 2) + picData.xoffset, rect.y + math.floor(clippingData.height / 2) - picData.yoffset)
		container:addChild(pic, -i)

		pic.x = rect.x
		pic.y = rect.y
		pic.width = rect.width
		pic.height = rect.height

		table.insert(self.standPicArr, pic)
	end

	local clipNode = cc.ClippingNode:create()

	clipNode:setStencil(pic_mask)
	clipNode:setAlphaThreshold(0.0001)
	clipNode:addChild(container)
	clipNode:setCascadeOpacityEnabled(true)
	self:addChild(clipNode, zorder)
end

function FRAME_abyss_boss_neo:refreshStand(neoList)
	local index = self.list:getSelectedIndex()

	for i, pic in ipairs(self.standPicArr) do
		transition.stopTarget(pic)

		if i < index then
			pic:setVisible(false)
		elseif index < i then
			pic:setVisible(true)
			Shader.gray(pic)
			pic:setOpacity(50)
		else
			pic:setVisible(true)
			Shader.recover(pic)
			pic:setOpacity(100)
			transition.fadeTo(pic, {
				opacity = 255,
				time = 0.2
			})
		end
	end
end

function FRAME_abyss_boss_neo:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local function tapListener(ui, data, index)
		self:refresh()
	end

	self.list = self:createListOnFlag("flag_list", LIST_abyss_boss_neo, tapListener)

	self.list:setTapGroup("list_click")

	self.costList = self:createListOnFlag("flag_cost", CostList)

	self.costList:setCols(2)
	self.costList:setNumSimplify()

	local function tapListener(ui, data, index)
		DropManager.popDetail(data.type, data.info)
	end

	self.rewardList = self:createListOnFlag("flag_reward_boss", LIST_abyss_prepare, tapListener)

	self.rewardList:setCols(4)
	self.rewardList:setSpace(0, 0)
	self.rewardList:setTapGroup("list_click")

	local enterBt = self:getComponentByTag("bt_enter_boss")

	enterBt:toTouchable()
	enterBt:setTapGroup("button_click")
	enterBt:addTap(function ()
		if InfoHero.countTeam() < GameConfig.hero_team_num then
			Alert.open(StringUtil.replace(Localization.getSrcText("队伍不满{1}人"), GameConfig.hero_team_num))

			return
		end

		local function onSuccess(rcvData)
			DungeonScene.enterDungeon(DungeonScene.ENTER_TYPE.NEW, rcvData)
		end

		local speedup = 0
		local neoCSV = self.list:getSelectedItem()
		local abyssCSV = CsvParser.getCsvData("abyss", neoCSV.abyss)

		InfoDungeon.enter(InfoDungeon.TYPE.ABYSS, {
			layer = abyssCSV.layer,
			dungeon_id = abyssCSV.id,
			speedup = speedup
		}, onSuccess)
	end)

	local bt_open = self:getComponentByTag("bt_open")

	bt_open:toTouchable()
	bt_open:setTapGroup("button_click")
	bt_open:addTap(function ()
		local neoCSV = self.list:getSelectedItem()

		InfoAbyssArea.neoOpen(neoCSV.id, function ()
			Alert.open(Localization.getSrcText("开启成功"))
		end)
	end)

	local bt_desc = self:getComponentByTag("bt_desc")

	bt_desc:toTouchable()
	bt_desc:setOpacity(0)
	bt_desc:setTapGroup("button_click")
	bt_desc:addTap(function ()
		self:switchDesc()
	end)

	local bg2 = self:getComponentByTag("bg2")

	bg2:toTouchable()

	local rect = self:getFlagByTag("flag_desc_clipping")
	local node = display.newClippingRectangleNode(cc.rect(0, 0, rect.width + 1, rect.height + 1))

	node:setPosition(rect.x, rect.y)
	self:addChild(node, bt_desc:getLocalZOrder())

	self.descUI = UIManager.getUI("frame_neo_desc")
	local textArea = self.descUI:createTextAreaOnFlag("flag_desc")

	textArea:addEventListener("onTapListIcon", function (event)
		self:switchDesc()
	end)
	textArea:setUbbEnabled(true)
	textArea:setSpace(5, 5)

	self.textArea = textArea

	node:addChild(self.descUI)

	self.descOpening = false

	self.descUI:setPositionY(-270)

	local arrow = self.descUI:getComponentByTag("arrow")

	arrow:setFlippedY(true)
	Style.makeShining(arrow)

	local empty_bg = self.descUI:getComponentByTag("empty_bg")

	empty_bg:setLocalZOrder(2000)
	empty_bg:setOpacity(0)
	empty_bg:toTouchable()
	empty_bg:addTap(function ()
		self:switchDesc()
	end)
end

function FRAME_abyss_boss_neo:refreshEmpty()
	local listFlag = self.descUI:getFlagByTag("flag_desc")
	local empty_bg = self.descUI:getComponentByTag("empty_bg")
	local offset = listFlag.height - self.textArea.totalHeight - (self.textArea.topSpace or 0)

	if offset > 0 then
		empty_bg:setSize(nil, offset)
	else
		empty_bg:setVisible(false)
	end
end

function FRAME_abyss_boss_neo:switchDesc()
	self.descOpening = not self.descOpening
	local arrow = self.descUI:getComponentByTag("arrow")

	transition.stopTarget(arrow)
	transition.stopTarget(self.descUI)

	if self.descOpening then
		transition.moveTo(self.descUI, {
			y = 0,
			easing = "sineOut",
			time = 0.2
		})
		transition.fadeTo(arrow, {
			opacity = 0,
			easing = "sineOut",
			time = 0.2
		})
		self.textArea:setTouchEnabled(true)
	else
		transition.moveTo(self.descUI, {
			y = -270,
			easing = "sineOut",
			time = 0.2
		})
		Style.makeShining(arrow)
		arrow:setOpacity(0)
		self.textArea:setTouchEnabled(false)
	end
end

function FRAME_abyss_boss_neo:refresh()
	local index = self.list:getSelectedIndex()
	local neoCSV = self.list:getSelectedItem()
	local abyssCSV = CsvParser.getCsvData("abyss", neoCSV.abyss)
	local opened = InfoAbyssArea.checkNeoOpen(self.areaCSV.id, index)
	local preOK = InfoAbyssArea.checkNeoPre(self.areaCSV.id, index)

	self.costList:setVisible(not opened)
	self.rewardList:setVisible(not opened)

	local bt_open = self:getComponentByTag("bt_open")
	local bt_enter_boss = self:getComponentByTag("bt_enter_boss")
	local label_cost = self:getComponentByTag("label_cost")
	local pre_limit = self:getComponentByTag("pre_limit")

	self.rewardList:setVisible(opened)
	bt_enter_boss:setVisible(opened)
	bt_open:setVisible(not opened and preOK)
	label_cost:setVisible(not opened and preOK)
	self.costList:setVisible(not opened and preOK)
	pre_limit:setVisible(not opened and not preOK)

	if opened then
		local info = InfoDungeon.getAbyssInfo(abyssCSV.layer)

		if info then
			local itemArr = {}
			local arr = string.split(info.reward_item, ";")

			for i, v in ipairs(arr) do
				if not empty(v) then
					local itemID = tonumber(v)

					if InfoItem.getNum(itemID) == 0 then
						table.insert(itemArr, {
							type = DropManager.TYPE.ITEM,
							info = {
								num = 1,
								base_id = itemID
							}
						})
					end
				end
			end

			local arr = string.split(info.item_display, ";")

			for i, v in ipairs(arr) do
				if not empty(v) then
					local itemID = tonumber(v)
					local itemCSV = CsvParser.getCsvData("item", itemID)

					if itemCSV.drop_level_min <= info.level + 3 and info.level <= itemCSV.drop_level_max then
						table.insert(itemArr, {
							type = DropManager.TYPE.ITEM,
							info = {
								num = 1,
								base_id = itemID
							}
						})
					end
				end
			end

			self.rewardList:setAbyssLevel(self.bossCSV.level)
			self.rewardList:setItems(itemArr)
		end
	elseif preOK then
		local costArr = SheetUtil.getColumnList(neoCSV, {
			"open_item_id_",
			"open_item_num_"
		}, {
			"base_id",
			"num"
		})

		self.costList:setItems(costArr)
	end

	local desc = string.gsub(neoCSV.desc, "\\n", "\n")

	self.textArea:setText(desc)
	self:refreshEmpty()
	self:refreshStand()
	self:refreshScore(abyssCSV.layer)
end

function FRAME_abyss_boss_neo:refreshScore(layer)
	local ui = self
	local index = self.list:getSelectedIndex()
	local teamScore = InfoHero.getTeamScore()

	ui:createLabelOnFlag("flag_score", teamScore, style)

	local info = InfoDungeon.getAbyssInfo(layer)
	local style = {
		color = Style.font3
	}

	if teamScore < info.standard_score then
		style.color = Style.disableColor
	end

	ui:createLabelOnFlag("flag_score_boss", info.standard_score, style)

	local firstScore = InfoAbyssArea.getFirstScore(self.areaCSV.id, index)

	if empty(firstScore) then
		ui:createLabelOnFlag("flag_score_my_first", "-- --")
	else
		ui:createLabelOnFlag("flag_score_my_first", firstScore)
	end

	InfoAbyssArea.getFirstAverage(self.areaCSV.id, index, function (score)
		if empty(score) then
			ui:createLabelOnFlag("flag_score_average", "-- --")
		else
			ui:createLabelOnFlag("flag_score_average", score)
		end
	end)
end

return FRAME_abyss_boss_neo
