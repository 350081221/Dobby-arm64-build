local Animation = class("Animation", function ()
	local node = display.newNode()

	return node
end)

function Animation:ctor()
	event_listener.extendMethods(self, true)
	self:setCascadeOpacityEnabled(true)
	self:setCascadeColorEnabled(true)

	self.bmp = display.newSprite()

	self:addChild(self.bmp)
end

function Animation:load(name)
	self.animationName = name
	local data = JsonParser.parse("res/animation/data_" .. name .. ".json")
	self.anim = {
		frameStack = {},
		offsetStack = {}
	}

	for actionName, picArr in pairs(data.actions) do
		self.anim.frameStack[actionName] = {}
		self.anim.offsetStack[actionName] = {}

		for i = 1, #picArr do
			Animation.loadTexture(picArr[i].pic)
			table.insert(self.anim.frameStack[actionName], display.newSpriteFrame(picArr[i].pic))
			table.insert(self.anim.offsetStack[actionName], picArr[i].offset)
		end
	end

	self.anim.sizeStack = data.actionSize
	self.anim.frameOffset = {
		x = 0,
		y = 0
	}
	self.anim.frameSkip = data.frameSkip
	self.anim.xoffset = data.xoffset
	self.anim.yoffset = data.yoffset
	self.anim.action = "idle"
	self.anim.playCount = 0
	self.anim.frame = 1
	self.anim.loopFrame = 1
	self.mirror = false
	self.scale = 1
	self.innerScaleX = 1
	self.innerScaleY = 1
	self.radius = data.radius

	if empty(data.config) then
		self.config = {}
	else
		self.config = ConfParser.parse(data.config) or {}
	end

	self:setFrame(self.anim.action, self.anim.frame)
end

function Animation:setLooper(looper)
	if self.looper then
		self.looper:stopLoop(self, self.playLoop)
	end

	self.looper = looper

	if self:getTotalFrame() > 1 then
		self.looper:startLoop(self, self.playLoop)
	end
end

function Animation:setActionLock(b)
	self.actionLocked = b
end

function Animation:setAction(action, loop, onComplete, force)
	if self.actionLocked then
		return
	end

	if self.anim.action ~= action or force then
		self.anim.action = action
		self.anim.playCount = 0
		self.anim.frame = 1
		self.anim.actionOverFunc = onComplete
		self.anim.actionLoop = loop

		self:setFrame(self.anim.action, self.anim.frame)

		if self.looper then
			if self:getTotalFrame() > 1 then
				self.looper:startLoop(self, self.playLoop)
			else
				self.looper:stopLoop(self, self.playLoop)
			end
		end
	end
end

function Animation:setInnerScale(scaleX, scaleY)
	if self.innerScaleX ~= scaleX or self.innerScaleY ~= scaleY then
		self.innerScaleX = scaleX
		self.innerScaleY = scaleY

		self:draw()
	end
end

function Animation:getSize()
	return self.anim.sizeStack[self.anim.action]
end

function Animation:setScale(scale)
	if self.scale ~= scale then
		self.scale = scale

		self:draw()
	end
end

function Animation:getScale()
	return self.scale
end

function Animation:rawSetScale(scale)
	cc.Node.setScale(self, scale)
end

function Animation:rawGetScale()
	return cc.Node.getScale(self)
end

function Animation:rawGetScaleX()
	return cc.Node.getScaleX(self)
end

function Animation:rawGetScaleY()
	return cc.Node.getScaleY(self)
end

function Animation:setMirror(b)
	self.mirror = b

	self:draw()
end

function Animation:draw()
	if not self.anim then
		return
	end

	local frameOffset = self.anim.frameOffset

	self.bmp:setScaleY(self.scale * self.innerScaleY)

	if self.mirror then
		self.bmp:setScaleX(-self.scale * self.innerScaleX)
		self.bmp:setPosition(-(self.anim.xoffset + frameOffset.x) * self.scale, (self.anim.yoffset - frameOffset.y) * self.scale)
	else
		self.bmp:setScaleX(self.scale * self.innerScaleX)
		self.bmp:setPosition((self.anim.xoffset + frameOffset.x) * self.scale, (self.anim.yoffset - frameOffset.y) * self.scale)
	end
end

function Animation:playLoop(frame, passed, sharp)
	if sharp > 0 and self.playNext then
		self:playNext()
	end
end

function Animation:getTotalFrame()
	if self.anim.frameStack[self.anim.action] then
		return #self.anim.frameStack[self.anim.action]
	else
		return 0
	end
end

function Animation:getNextFrame()
	self.anim.frame = self.anim.frame + 1
	local totalFrame = self:getTotalFrame()

	if totalFrame < self.anim.frame then
		self.anim.frame = math.min(totalFrame, self.anim.loopFrame)
	end

	return self.anim.frame
end

function Animation:setLastFrameFreeze(frame)
	self.lastFrameFreeze = frame
end

function Animation:randomizeFrame()
	local totalFrame = self:getTotalFrame()
	self.anim.frame = math.floor(math.random() * totalFrame) + 1
	self.anim.playCount = math.floor(math.random() * self.anim.frameSkip)
end

function Animation:playNext()
	local isCallOverFunc = false
	local totalFrame = nil

	if self.syncFrame then
		self.anim.playCount = self.anim.frameSkip - 1 - math.floor(self.looper.frame) % self.anim.frameSkip
	end

	if (self.anim.playCount == 1 or self.anim.frameSkip == 0 and self.anim.playCount == 0) and self.anim.actionLoop ~= nil and self.anim.actionLoop > 0 then
		totalFrame = self:getTotalFrame()

		if self.anim.frame == totalFrame then
			self.anim.actionLoop = self.anim.actionLoop - 1

			if self.anim.actionLoop == 0 then
				isCallOverFunc = true
			end
		end
	end

	if self.anim.playCount <= 0 then
		local frame = nil

		if self.syncFrame then
			totalFrame = totalFrame or self:getTotalFrame()
			frame = math.ceil(self.looper.frame / self.anim.frameSkip) % totalFrame + 1
		else
			frame = self:getNextFrame()
		end

		self:setFrame(self.anim.action, frame)

		self.anim.playCount = self.anim.frameSkip

		if self.lastFrameFreeze then
			totalFrame = totalFrame or self:getTotalFrame()

			if frame == totalFrame then
				if type(self.lastFrameFreeze) == "function" then
					self.anim.playCount = self.anim.playCount + self.lastFrameFreeze()
				else
					self.anim.playCount = self.anim.playCount + self.lastFrameFreeze
				end
			end
		end
	else
		self.anim.playCount = self.anim.playCount - 1
	end

	if isCallOverFunc and self.anim.actionOverFunc then
		self.anim.actionOverFunc(self)

		self.anim.actionOverFunc = nil
	end
end

function Animation:setFrame(action, frame)
	self.anim.frameOffset = self.anim.offsetStack[action][frame]
	local spriteFrame = self.anim.frameStack[action][frame]

	if spriteFrame then
		self.bmp:setSpriteFrame(spriteFrame)
	end

	self:draw()
end

function Animation:setBlendFunc(srcBlend, dstBlend)
	self.bmp:setBlendFunc(srcBlend, dstBlend)
end

function Animation.loadTexture(texture)
	local textureMap = JsonParser.parse("res/animation/texture_packed_map.json")
	local textureName = textureMap[texture]

	if textureName then
		display.addSpriteFrames(getFinalRes("res/animation/" .. textureName .. "_sprites.plist"), getFinalRes("res/animation/" .. textureName .. "_texture.png"))
	end
end

function Animation:onExit()
	if self.looper then
		self.looper:stopLoop(self, self.playLoop)
	end
end

return Animation
