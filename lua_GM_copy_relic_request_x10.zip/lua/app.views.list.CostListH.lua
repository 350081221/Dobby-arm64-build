local List = import("...ui.List")
local CostListH = class("CostListH", List)

function CostListH:ctor(rect, cellName, cellWidth)
	CostListH.super.ctor(self, rect, List.DIRECTION_HORIZONTAL)

	self.isBounc = false
	self.noEmptyText = true

	self:setCellName(cellName or "cell_cost")
	self:setCellSize(cc.size(cellWidth or 200, self.touchRect.height))
	self:addEventListener("onTapListIcon", function (event)
		if not self.detailDisabled then
			DropManager.popDetail(DropManager.TYPE.ITEM, event.data)
		end
	end)
	self:setTapGroup("list_click")
end

function CostListH:setIsUnion(b)
	self.isUnion = b
end

function CostListH:setDetailDisabled()
	self.detailDisabled = true
end

function CostListH:setNumSimplify()
	self.numSimplify = true
end

function CostListH:onCellInit(ui, data)
	local id = data.id or data.base_id
	local costData = CsvParser.getCsvData("item", id)
	local costPic = IconManager.getItemIcon(costData.id)

	if ui:getFlagByTag("flag_num") then
		local itemNum = 0

		if self.isUnion then
			itemNum = InfoUnion.getResourceNum(id)
		else
			itemNum = InfoItem.getNum(id)
		end

		local style = {}

		if itemNum < data.num then
			style.color = Style.red
		end

		if self.numSimplify then
			ui:createLabelGroupOnFlag("flag_num", {
				StringUtil.simplifyNumber(itemNum),
				"/",
				StringUtil.simplifyNumber(data.num)
			}, {
				style
			})
		else
			ui:createLabelGroupOnFlag("flag_num", {
				StringUtil.simplifyNumber(itemNum),
				"/",
				data.num
			}, {
				style
			})
		end
	end

	local icon = ui:createIconOnFlag("flag_icon", costPic, 100, true)
	local shadow = ui:createIconOnFlag("flag_shadow", costPic, 90, true)

	shadow:setColor(cc.c3b(0, 0, 0))
	shadow:setOpacity(100)
end

return CostListH
