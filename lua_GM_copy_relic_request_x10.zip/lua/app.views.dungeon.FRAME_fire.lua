local FRAME_fire = class("FRAME_fire", UI_base)

function FRAME_fire.start(tile, itemID, bag_index)
	if FRAME_fire.opening then
		Alert.open(Localization.getSrcText("无法重复升起篝火"))

		return
	end

	FRAME_fire.itemID = itemID
	FRAME_fire.bag_index = bag_index
	FRAME_fire.itemData = CsvParser.getCsvData("item", itemID)
	FRAME_fire.centerTile = tile
	FRAME_fire.opening = true
	local mapX, mapY = global.map:tileToMap(tile)
	local fire = Effect.new()

	fire:load(MiscConfig.campfire_effect)
	fire:setScale(0.75)
	fire:display(global.map, mapX, mapY)
	fire:setCustomLight(0.8, 3, cc.c3b(195, 116, 36))
	fire:setAction("start", 1, function ()
		fire:setAction("idle")
	end)

	FRAME_fire.fireEffect = fire
	Map.NO_UNIT_BLOCK = true

	global.player:setGoDirectionLocked("camp_fire", true)
	global.player:lockTrain(true)
	tile:setForceWalk("camp_fire", 2)

	local prepareTime = 60
	local units = TeamManager.getTeam()
	local exceptMap = {}

	for i, unit in ipairs(units) do
		unit.speed = math.max(0, unit.data.speed * (1 + unit.attrs.battle_speed / 100))
		local path = MapUtils.findCampfireSeat(unit, tile, exceptMap)
		local destTile = nil

		if path == true then
			destTile = unit.tile

			unit:faceToTile(tile)
			unit:setAction("sit")
		elseif type(path) == "table" then
			destTile = path[#path]

			unit:goPath(path, true)

			if unit.moving then
				local walkTime = #path * global.map.ptPerTile / unit.speed
				prepareTime = math.max(prepareTime, walkTime)
				local checkUnitMovingLoop = nil

				function checkUnitMovingLoop()
					if not unit.moving then
						Looper.stopLoop(FRAME_fire, checkUnitMovingLoop)
						unit:faceToTile(tile)
						unit:setAction("sit")
					end
				end

				Looper.startLoop(FRAME_fire, checkUnitMovingLoop)
			end
		end

		if destTile then
			exceptMap[destTile.tag] = true
		end
	end

	Unit.setFocusUnit(nil)
	global.map:setConfig({
		light = {
			min = 0.2,
			radius = 0.5
		}
	})
	global.map:tweenViewZoom(1.25, prepareTime, nil, , "outQuad")
	global.map:tweenScrollTo(mapX, mapY, prepareTime, nil, "outQuad")
	global.map:tweenFov(mapX, mapY, prepareTime, "outQuad")
	Looper.setTimeout(function ()
		FRAME_fire.doing()
	end, prepareTime, global.map)
	FRAME_fire.open()
end

local timeCount = 0
local healTimeCount = 0
local healCount = 0
local originalHpMap = {}
local originalMp = 0
local chatID, chatPos, chatCount = nil

function FRAME_fire.doing()
	local itemData = FRAME_fire.itemData
	timeCount = 0
	healTimeCount = itemData.use_value2
	healCount = 0

	Looper.startLoop(FRAME_fire, FRAME_fire.healing)
	Looper.startLoop(FRAME_fire, FRAME_fire.chating)

	local ui = POP_read.open(Localization.getSrcText("篝火"), 1)

	ui:setPositionY(40)

	chatCount = math.random(160, 200)
	local units = TeamManager.getTeam()

	for i, unit in ipairs(units) do
		originalHpMap[i] = unit.battleData.hp
	end

	originalMp = InfoModao.getMp()

	FRAME_fire.ui:show()
end

function FRAME_fire.chating(obj, frame, passed, sharp)
	if WarMachine.on then
		FRAME_fire.stop()

		return
	end

	local itemData = FRAME_fire.itemData

	if chatCount <= 0 then
		local units = TeamManager.getTeam()
		local chatUnit = nil

		if #units > 1 then
			local chatUnits = {}

			for i, unit in ipairs(units) do
				if i ~= chatPos then
					table.insert(chatUnits, {
						pos = i,
						unit = unit
					})
				end
			end

			local unitObj = chatUnits[math.random(1, #chatUnits)]
			chatUnit = unitObj.unit
			chatPos = unitObj.pos
			chatCount = math.random(240, 360)
		else
			chatUnit = units[1]
			chatCount = math.random(320, 400)
		end

		if chatUnit then
			local dungeonData = InfoDungeon.getDungeonCSV()
			local chatMsg, sayTime = LinesManager.getCampfire(chatUnit.data.class, dungeonData.map_type, InfoDungeon.getLevel(), chatID)

			if chatMsg then
				chatID = chatMsg.id

				chatUnit:say(chatMsg.text, sayTime)
			end
		end
	else
		chatCount = chatCount - sharp
	end
end

function FRAME_fire.healing(obj, frame, passed, sharp)
	if WarMachine.on then
		FRAME_fire.stop()

		return
	end

	local itemData = FRAME_fire.itemData

	for i = 1, sharp do
		if healTimeCount <= 0 then
			healCount = healCount + 1
			local percent = itemData.use_value1 * healCount
			local abs = 0
			local mpPercent = 0
			local mpAbs = 0
			local mirrorData = InfoMirror.getCurrent(5)

			if mirrorData then
				if not empty(mirrorData.value1) then
					percent = percent + mirrorData.value1 * healCount
				end

				if not empty(mirrorData.value2) then
					abs = abs + mirrorData.value2 * healCount
				end

				if not empty(mirrorData.value3) then
					mpPercent = mirrorData.value3 * healCount
				end

				if not empty(mirrorData.value4) then
					mpAbs = mirrorData.value4 * healCount
				end
			end

			local units = TeamManager.getTeam()

			for i, unit in ipairs(units) do
				local hpMax = unit.attrs.hp
				hpMax = math.floor(hpMax * (1 - InfoDungeon.getHeroHPLose(unit.info.id) / 100))
				local newHP = math.min(hpMax, originalHpMap[i] + math.floor(unit.attrs.hp * percent / 100 + abs))
				local healValue = newHP - unit.battleData.hp

				if healValue > 0 then
					local effectGen = unit:getEffectGen()

					if effectGen then
						effectGen:castEffect(itemData.use_effect, unit, nil, unit.angle, unit)
					end

					unit:fakeHp(newHP)
					unit:jumpWord(healValue, "font_heal_", nil, , -40, true)
				end
			end

			local mp, attrMp = InfoModao.getMp()

			if mpPercent > 0 and mpAbs > 0 then
				local newMp = math.min(attrMp, originalMp + math.floor(attrMp * mpPercent / 100 + mpAbs))
				local addValue = newMp - mp

				if addValue > 0 then
					InfoModao.fakeMp(newMp)

					local fireEffect = FRAME_fire.fireEffect

					if fireEffect then
						fireEffect:jumpWord(addValue, "font_mana_", nil, , 20, true, 45, 20)
					end
				end
			end

			healTimeCount = itemData.use_value2
		end

		healTimeCount = healTimeCount - 1
		timeCount = timeCount + 1

		if itemData.use_value3 < timeCount then
			Looper.stopLoop(FRAME_fire, FRAME_fire.healing)
		end

		POP_read.setPercent(math.max(0, math.min(1, (itemData.use_value3 - timeCount) / itemData.use_value3)))
	end
end

function FRAME_fire.stop()
	Looper.stopLoop(FRAME_fire, FRAME_fire.healing)
	Looper.stopLoop(FRAME_fire, FRAME_fire.chating)
	POP_read.close()

	local function onItemUseSuccess()
		FRAME_fire.opening = nil

		InfoModao.refreshMp()

		local lockCount = 2
		local tweenFrame = 60
		local frameCount = tweenFrame
		local lightColor = cc.c3b(195, 116, 36)

		global.map:recoverConfig()

		local scene = display.getRunningScene()

		if scene.recoverLight then
			scene:recoverLight()
		end

		global.map:tweenViewZoom(1, tweenFrame, nil, , "outQuad")
		global.map:tweenFov(global.player.x, global.player.y, tweenFrame, "outQuad")
		global.map:tweenScrollTo(global.player.x, global.player.y, tweenFrame, function ()
			Unit.setFocusUnit(global.player)
			FRAME_fire.fireEffect:removeSelf()
			FRAME_fire.centerTile:removeForceWalk("camp_fire")

			lockCount = lockCount - 1
		end, "outQuad", nil, function ()
			frameCount = frameCount - 1
			local lightPercent = math.max(0, frameCount / tweenFrame)
			lightPercent = math.sqrt(lightPercent)

			FRAME_fire.fireEffect:setCustomLight(0.8 * lightPercent, 3 * lightPercent, lightColor)
			FRAME_fire.fireEffect:refreshLight()
			FRAME_fire.fireEffect:setOpacity(lightPercent * 255)
		end)

		local units = TeamManager.getTeam()

		for i, unit in ipairs(units) do
			unit:setAction("idle")
		end

		global.player:lockTrain(false)
		TeamManager.regroup(function ()
			global.player:setGoDirectionLocked("camp_fire", true)

			lockCount = lockCount - 1
		end)

		local checkLockLoop = nil

		function checkLockLoop()
			if lockCount == 0 then
				Looper.stopLoop(FRAME_fire, checkLockLoop)

				Map.NO_UNIT_BLOCK = false

				global.player:setGoDirectionLocked("camp_fire", false)
				WarMachine.normalSpeed()
				FRAME_fire.ui:close()
			end
		end

		Looper.startLoop(FRAME_fire, checkLockLoop)
	end

	local bag_index = FRAME_fire.bag_index
	local itemID = FRAME_fire.itemID
	local bagInfo = InfoBag.getBagInfo(FRAME_fire.bag_index)

	if not bagInfo or bagInfo.type ~= DropManager.TYPE.ITEM or bagInfo.item_id ~= itemID then
		bag_index = InfoBag.getItemUseIndex(itemID)
	end

	if bag_index then
		InfoItem.use(itemID, 1, bag_index, nil, onItemUseSuccess, nil, {
			count = healCount
		})
	else
		onItemUseSuccess()
	end
end

function FRAME_fire.open()
	local ui = FRAME_fire.new()

	display.getRunningScene():addChild(ui, LayerConfig.sys)

	FRAME_fire.ui = ui
end

function FRAME_fire:ctor()
	FRAME_fire.super.ctor(self, "frame_fire")
	self:init()
end

function FRAME_fire:init()
	self:initUI()
end

function FRAME_fire:initUI()
	local mask = self:getComponentByTag("mask")

	mask:toTouchable()
	mask:setOpacity(0)
	self:setOpacity(0)
end

function FRAME_fire:show()
	local mask = self:getComponentByTag("mask")

	mask:setVisible(false)

	local cancelButton = self:getComponentByTag("bt_cancel")

	transition.fadeTo(self, {
		time = 0.5,
		opacity = 255,
		easing = "outQuad"
	})
	cancelButton:toTouchable()
	cancelButton:addTap(function ()
		cancelButton:removeTouchable()
		FRAME_fire.stop()
		mask:setVisible(true)
		transition.fadeTo(self, {
			time = 0.5,
			opacity = 0,
			easing = "outQuad"
		})
	end)
end

function FRAME_fire:close()
	self:removeSelf()
end

function FRAME_fire:onExit()
	FRAME_fire.super.onExit(self)

	FRAME_fire.ui = nil
end

return FRAME_fire
