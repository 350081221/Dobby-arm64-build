local FestivalUtils = class("FestivalUtils")
local inter = 3
local globalScale = 1.2
local pScale = 0.8
local pOpacity = 255
local hanabiLines = {}

local function initHanabiLines()
	local csvList = CsvParser.getCsvList("lines_hanabi")
	local arr = {}

	for i, csv in ipairs(csvList) do
		table.insert(arr, csv)
	end

	hanabiLines = Random.randomOrder(arr)
end

local function getHanabiLines()
	if #hanabiLines == 0 then
		initHanabiLines()
	end

	if #hanabiLines > 0 then
		local csv = table.remove(hanabiLines, 1)
		local lang = Localization.getLang()
		local text = csv[lang] or ""

		return text
	end

	return ""
end

local function makeWenziColor(id)
	local wenziCSV = CsvParser.getCsvData("hanabi_wenzi", id)

	if not empty(wenziCSV.color_1) then
		local color1 = ColorUtil.getC3B(wenziCSV.color_1)

		if not empty(wenziCSV.color_2) then
			local color2 = ColorUtil.getC3B(wenziCSV.color_2)
			local percent = math.random()
			local r = math.floor(color1.r * (1 - percent) + color2.r * percent)
			local g = math.floor(color1.g * (1 - percent) + color2.g * percent)
			local b = math.floor(color1.b * (1 - percent) + color2.b * percent)

			return cc.c3b(r, g, b)
		else
			return color1
		end
	end
end

local function makeWenziPts(id)
	local wenziCSV = CsvParser.getCsvData("hanabi_wenzi", id)
	local lines = SheetUtil.getColumnValueList(wenziCSV, "line_")
	local pts = {}
	local angle = (math.random() - 0.5) * math.pi / 3 * 2
	local scale = SheetUtil.getNumber(wenziCSV.scale) / 100 * globalScale

	for i, line in ipairs(lines) do
		local arr = string.split(line, "~")
		local arr1 = string.split(arr[1], ",")
		local arr2 = string.split(arr[2], ",")
		local pt1 = {
			x = tonumber(arr1[1]),
			y = tonumber(arr1[2])
		}
		local pt2 = {
			x = tonumber(arr2[1]),
			y = tonumber(arr2[2])
		}
		local _distance = math.sqrt(math.pow(pt1.y, 2) + math.pow(pt1.x, 2)) * scale
		local _angle = math.atan2(pt1.y, pt1.x) + angle
		local x1 = _distance * math.cos(_angle)
		local y1 = _distance * math.sin(_angle)
		local _distance = math.sqrt(math.pow(pt2.y, 2) + math.pow(pt2.x, 2)) * scale
		local _angle = math.atan2(pt2.y, pt2.x) + angle
		local x2 = _distance * math.cos(_angle)
		local y2 = _distance * math.sin(_angle)

		table.insert(pts, {
			pt1 = cc.p(x1, y1),
			pt2 = cc.p(x2, y2)
		})
	end

	return pts
end

local function getRandomWenzi()
	local wenziCache = CacheData.get("FestivalUtils_wenziCache")

	if not wenziCache then
		local powerArr = {}
		local csvArr = {}
		local csvList = CsvParser.getCsvList("hanabi_wenzi")

		if #csvList > 0 then
			for index, csv in ipairs(csvList) do
				if csv.rare ~= "" and csv.rare > 0 then
					local power = 1 / csv.rare

					table.insert(powerArr, power)
					table.insert(csvArr, csv)
				end
			end
		end

		wenziCache = {
			powerArr = powerArr,
			csvArr = csvArr
		}

		CacheData.set("FestivalUtils_wenziCache", wenziCache)
	end

	local powerArr = wenziCache.powerArr
	local csvArr = wenziCache.csvArr

	if #csvArr > 0 then
		local powerIndex = SheetUtil.getPowerRandomIndex(powerArr)

		return csvArr[powerIndex].id
	end
end

local eStackOnline = {}

function FestivalUtils.hanabiOnline()
	local preStackNum = #eStackOnline

	if preStackNum > 50 then
		return
	end

	local emitter = {
		x = math.random(display.width / 4, display.width / 4 * 3),
		y = math.random(display.height / 4, display.height / 4 * 3)
	}

	if math.random() < 0.5 then
		emitter.wenzi = getRandomWenzi()

		if emitter.wenzi then
			emitter.color = makeWenziColor(emitter.wenzi)
		end
	end

	if not emitter.color then
		emitter.color = cc.c3b(math.random(150, 255), math.random(150, 255), math.random(150, 255))
	end

	FestivalUtils.hanabiBoom(emitter, eStackOnline, true)

	if preStackNum == 0 then
		local container = global.adventureUI

		container:addEnterFrame("hanabi_loop", function (dt)
			local passed = dt * 60
			local index = 1
			local loop = #eStackOnline

			while index <= loop do
				local emitter = eStackOnline[index]
				local preX = emitter.x
				local preY = emitter.y
				emitter.speed = emitter.speed * math.pow(emitter.decay, passed)

				if emitter.type == 1 then
					emitter.x = emitter.x + emitter.speed * math.cos(emitter.angle) * passed
					emitter.y = emitter.y + emitter.speed * math.sin(emitter.angle) * passed
				elseif emitter.type == 2 then
					emitter.offX = emitter.offX + emitter.speed * math.cos(emitter.angle) * passed
					emitter.offY = emitter.offY + emitter.speed * math.sin(emitter.angle) * passed
					emitter.gSpeed = emitter.gSpeed - emitter.g * passed
					emitter.offY = emitter.offY + emitter.gSpeed * passed
					emitter.x = emitter.centerX + emitter.offX * emitter.radius
					emitter.y = emitter.centerY + emitter.offY * emitter.radius
				elseif emitter.type == 3 then
					emitter.x = emitter.x + emitter.speed * math.cos(emitter.angle) * passed
					emitter.y = emitter.y + emitter.speed * math.sin(emitter.angle) * passed
					emitter.gSpeed = emitter.gSpeed - emitter.g * passed
					emitter.y = emitter.y + emitter.gSpeed * passed
				end

				if not emitter.off then
					local angle = math.atan2(emitter.y - preY, emitter.x - preX)
					local distance = math.sqrt(math.pow(emitter.y - preY, 2) + math.pow(emitter.x - preX, 2)) + emitter.interLeft
					local interLoop = math.floor(distance / inter)
					emitter.interLeft = distance - interLoop * inter

					for i = 1, interLoop do
						local x = preX + math.cos(angle) * inter * (i - 1)
						local y = preY + math.sin(angle) * inter * (i - 1)
						local p = display.newSprite("#map_assets_hanabi", x, y)

						container:addChild(p, 100)
						p:setColor(emitter.color)

						if emitter.type == 1 then
							p:setScale(0.8 * pScale)
							p:setOpacity(emitter.pOpacity)
							transition.scaleTo(p, {
								easing = "sineOut",
								time = 0.1,
								scale = pScale
							})
						else
							p:setScale(pScale)
							p:setOpacity(emitter.pOpacity)
						end

						transition.fadeTo(p, {
							opacity = 0,
							easing = "sineOut",
							time = emitter.pTime,
							onComplete = function ()
								p:removeSelf()
							end
						})
					end
				end

				local isOver = nil

				if emitter.type == 1 then
					if emitter.boomCount then
						if emitter.boomCount <= 0 then
							FestivalUtils.hanabiBoom(emitter)

							isOver = true
						else
							emitter.boomCount = emitter.boomCount - passed
						end
					elseif emitter.boomReady then
						if emitter.boomReady <= 0 then
							emitter.off = true
							emitter.boomCount = 10
						else
							local percent = emitter.boomReady / 20
							emitter.pOpacity = pOpacity * percent
							emitter.pTime = math.max(0.01, 0.5 * percent)
							emitter.boomReady = emitter.boomReady - passed
						end
					elseif emitter.yTop <= emitter.y then
						emitter.boomReady = 20
						emitter.decay = 0.92
					end
				elseif emitter.life <= 0 then
					isOver = true
				else
					emitter.life = emitter.life - passed
					local percent = math.max(1, emitter.life) / emitter.lifeMax
					emitter.pOpacity = pOpacity * percent
					emitter.pTime = math.max(0.01, 0.5 * percent)
					percent = math.pow(percent, 4)
					local r = math.floor(emitter.endColor.r * (1 - percent) + emitter.startColor.r * percent)
					local g = math.floor(emitter.endColor.g * (1 - percent) + emitter.startColor.g * percent)
					local b = math.floor(emitter.endColor.b * (1 - percent) + emitter.startColor.b * percent)
					emitter.color = cc.c3b(r, g, b)
				end

				if isOver then
					table.remove(eStackOnline, index)

					loop = loop - 1
				else
					index = index + 1
				end
			end

			if #eStackOnline == 0 then
				if container.removeEnterFrame then
					container:removeEnterFrame("hanabi_loop")
				end

				print("$$$ hanabiOnlineClose", preStackNum)
			end
		end)
	end
end

local eStack = {}
local container = nil
local wenziWait = 0

function FestivalUtils.hanabiShot()
	local emitter = {
		type = 1,
		x = math.random(display.width / 5, display.width / 4 * 3),
		y = -100,
		angle = math.pi / 2,
		speed = 3 + math.random() * 1,
		decay = 1,
		pOpacity = pOpacity,
		pTime = 0.5,
		yTop = math.random(display.height / 3, display.height / 5 * 4)
	}

	if wenziWait <= 0 then
		emitter.wenzi = getRandomWenzi()

		if emitter.wenzi then
			emitter.color = makeWenziColor(emitter.wenzi)
		end

		wenziWait = SheetUtil.getNumber("0:2;1:10;2:20;3:10")
	else
		wenziWait = wenziWait - 1
	end

	if not emitter.color then
		emitter.color = cc.c3b(math.random(150, 255), math.random(150, 255), math.random(150, 255))
	end

	emitter.interLeft = -inter

	table.insert(eStack, emitter)
end

function FestivalUtils.hanabiBoom(startEmitter, stack, isOnline)
	local x = startEmitter.x
	local y = startEmitter.y
	local color = startEmitter.color
	stack = stack or eStack

	if startEmitter.wenzi then
		local pts = makeWenziPts(startEmitter.wenzi)
		local wenziColor = makeWenziPts(startEmitter.wenzi)
		local endColor = nil

		if wenziColor then
			endColor = color
		else
			endColor = cc.c3b(math.random(150, 255), math.random(150, 255), math.random(150, 255))
		end

		for i, line in ipairs(pts) do
			local pt1 = line.pt1
			local pt2 = line.pt2
			local distance = math.sqrt(math.pow(pt2.y - pt1.y, 2) + math.pow(pt2.x - pt1.x, 2))
			local emitter = {
				type = 3,
				x = pt1.x + x,
				y = pt1.y + y,
				angle = math.atan2(pt2.y - pt1.y, pt2.x - pt1.x),
				speed = distance / 15,
				decay = 0.95,
				gSpeed = 0,
				g = 0.01,
				pOpacity = pOpacity,
				pTime = 0.65,
				lifeMax = math.random(40, 60)
			}
			emitter.life = emitter.lifeMax
			emitter.color = color
			emitter.startColor = color
			emitter.endColor = endColor
			emitter.interLeft = -inter

			table.insert(stack, emitter)
		end
	else
		local endColor = nil

		if math.random() < 0.7 then
			endColor = cc.c3b(math.random(150, 255), math.random(150, 255), math.random(150, 255))
		end

		local boomType = SheetUtil.getNumber("1:7;2:3")

		if boomType == 1 then
			local count = math.random(16, 20)

			for i = 1, count do
				local emitter = {
					type = 2,
					centerX = x,
					centerY = y,
					offX = 0,
					offY = 0,
					x = x,
					y = y,
					angle = math.random() * math.pi * 2,
					speed = math.random() * 2 + 10,
					decay = 0.95,
					gSpeed = 0,
					g = 0.05,
					pOpacity = pOpacity,
					pTime = 0.5,
					radius = ((1 - math.sin(math.random() * math.pi)) * 0.8 + 0.2) * globalScale
				}

				if isOnline then
					emitter.lifeMax = math.random(30, 40)
				elseif math.random() < 0.4 then
					emitter.lifeMax = math.random(60, 70)
				else
					emitter.lifeMax = math.random(30, 40)
				end

				emitter.life = emitter.lifeMax
				emitter.color = color
				emitter.startColor = color

				if endColor then
					emitter.endColor = endColor
				else
					emitter.endColor = cc.c3b(math.random(150, 255), math.random(150, 255), math.random(150, 255))
				end

				emitter.interLeft = -inter

				table.insert(stack, emitter)
			end
		elseif boomType == 2 then
			local count = math.random(16, 20)
			local radius = math.random() * 0.3 + 0.7
			local speed = math.random() * 2 + 8

			for i = 1, count do
				local emitter = {
					type = 2,
					centerX = x,
					centerY = y,
					offX = 0,
					offY = 0,
					x = x,
					y = y,
					angle = math.pi * 2 / count * (i + math.random()),
					speed = speed,
					decay = 0.95,
					gSpeed = 0,
					g = 0.03,
					pOpacity = pOpacity,
					pTime = 0.5,
					radius = radius * globalScale,
					lifeMax = math.random(40, 50)
				}
				emitter.life = emitter.lifeMax
				emitter.color = color
				emitter.startColor = color

				if endColor then
					emitter.endColor = endColor
				else
					emitter.endColor = cc.c3b(math.random(150, 255), math.random(150, 255), math.random(150, 255))
				end

				emitter.interLeft = -inter

				table.insert(stack, emitter)
			end
		end
	end
end

local hanabiLinesLocked = nil

function FestivalUtils.checkHanabiLines()
	if hanabiLinesLocked then
		return
	end

	local text = getHanabiLines()
	hanabiLinesLocked = true
	local ubbMap, labels = container:createUbbOnFlag("flag_lines", text, nil, false)

	for i, label in ipairs(labels) do
		label:setOpacity(220)

		local interval = 0.08

		if Localization.isAlphabet() then
			interval = 0.05
		end

		local delay = i * interval + 3
		local y = label:getPositionY()
		local onComplete = nil

		if i == #labels then
			transition.moveTo(label, {
				easing = "sineOut",
				time = 0.2,
				delay = delay,
				y = y + 5,
				onComplete = function ()
					container:removeLabelGroupOnFlag("flag_lines")
					container:performWithDelay(function ()
						hanabiLinesLocked = nil
					end, 0.5)
				end
			})
		else
			transition.moveTo(label, {
				easing = "sineOut",
				time = 0.2,
				delay = delay,
				y = y + 5
			})
		end

		transition.fadeTo(label, {
			opacity = 0,
			easing = "sineOut",
			time = 0.2,
			delay = delay
		})
	end
end

function FestivalUtils.startHanabi(unit, itemID, sky)
	FestivalUtils.stopHanabi(unit, sky, true)

	hanabiLinesLocked = nil

	initHanabiLines()

	local dis = 10
	local tileX = math.max(1, unit.tile.x - dis)
	local tileY = math.max(1, unit.tile.y - dis)
	local offset = math.min(unit.tile.x - tileX, unit.tile.y - tileY)
	local tileX = unit.tile.x - offset
	local tileY = unit.tile.y - offset
	local mapX, mapY = global.map:tileToMap(tileX, tileY)

	global.map:tweenScrollTo(mapX, mapY, 30)

	eStack = {}
	local white = sky:getComponentByTag("white")

	white:setOpacity(0)
	white:setLocalZOrder(200)

	local whitePeak = 0
	container = sky

	container:addEnterFrame("hanabi_loop", function (dt)
		local passed = dt * 60
		whitePeak = math.max(0, whitePeak * math.pow(0.98, passed) - 0.03 * passed)
		local index = 1
		local loop = #eStack

		while index <= loop do
			local emitter = eStack[index]
			local preX = emitter.x
			local preY = emitter.y
			emitter.speed = emitter.speed * math.pow(emitter.decay, passed)

			if emitter.type == 1 then
				emitter.x = emitter.x + emitter.speed * math.cos(emitter.angle) * passed
				emitter.y = emitter.y + emitter.speed * math.sin(emitter.angle) * passed
			elseif emitter.type == 2 then
				emitter.offX = emitter.offX + emitter.speed * math.cos(emitter.angle) * passed
				emitter.offY = emitter.offY + emitter.speed * math.sin(emitter.angle) * passed
				emitter.gSpeed = emitter.gSpeed - emitter.g * passed
				emitter.offY = emitter.offY + emitter.gSpeed * passed
				emitter.x = emitter.centerX + emitter.offX * emitter.radius
				emitter.y = emitter.centerY + emitter.offY * emitter.radius
			elseif emitter.type == 3 then
				emitter.x = emitter.x + emitter.speed * math.cos(emitter.angle) * passed
				emitter.y = emitter.y + emitter.speed * math.sin(emitter.angle) * passed
				emitter.gSpeed = emitter.gSpeed - emitter.g * passed
				emitter.y = emitter.y + emitter.gSpeed * passed
			end

			if not emitter.off then
				local angle = math.atan2(emitter.y - preY, emitter.x - preX)
				local distance = math.sqrt(math.pow(emitter.y - preY, 2) + math.pow(emitter.x - preX, 2)) + emitter.interLeft
				local interLoop = math.floor(distance / inter)
				emitter.interLeft = distance - interLoop * inter

				for i = 1, interLoop do
					local x = preX + math.cos(angle) * inter * (i - 1)
					local y = preY + math.sin(angle) * inter * (i - 1)
					local p = display.newSprite("#map_assets_hanabi", x, y)

					container:addChild(p, 100)
					p:setColor(emitter.color)

					if emitter.type == 1 then
						p:setScale(0.8 * pScale)
						p:setOpacity(emitter.pOpacity)
						transition.scaleTo(p, {
							easing = "sineOut",
							time = 0.1,
							scale = pScale
						})
					else
						p:setScale(pScale)
						p:setOpacity(emitter.pOpacity)
					end

					transition.fadeTo(p, {
						opacity = 0,
						easing = "sineOut",
						time = emitter.pTime,
						onComplete = function ()
							p:removeSelf()
						end
					})
				end
			end

			local isOver = nil

			if emitter.type == 1 then
				if emitter.boomCount then
					if emitter.boomCount <= 0 then
						FestivalUtils.checkHanabiLines()

						whitePeak = 1

						FestivalUtils.hanabiBoom(emitter)

						isOver = true
					else
						emitter.boomCount = emitter.boomCount - passed
					end
				elseif emitter.boomReady then
					if emitter.boomReady <= 0 then
						local sound = InfoFestival.useItemSound(itemID, 2)

						if not empty(sound) then
							Sound.playSound(sound)
						end

						emitter.off = true
						emitter.boomCount = 10
					else
						local percent = emitter.boomReady / 20
						emitter.pOpacity = pOpacity * percent
						emitter.pTime = math.max(0.01, 0.5 * percent)
						emitter.boomReady = emitter.boomReady - passed
					end
				elseif emitter.yTop <= emitter.y then
					emitter.boomReady = 20
					emitter.decay = 0.92
				end
			elseif emitter.life <= 0 then
				isOver = true
			else
				emitter.life = emitter.life - passed
				local percent = math.max(1, emitter.life) / emitter.lifeMax
				emitter.pOpacity = pOpacity * percent
				emitter.pTime = math.max(0.01, 0.5 * percent)
				percent = math.pow(percent, 4)
				local r = math.floor(emitter.endColor.r * (1 - percent) + emitter.startColor.r * percent)
				local g = math.floor(emitter.endColor.g * (1 - percent) + emitter.startColor.g * percent)
				local b = math.floor(emitter.endColor.b * (1 - percent) + emitter.startColor.b * percent)
				emitter.color = cc.c3b(r, g, b)
			end

			if isOver then
				table.remove(eStack, index)

				loop = loop - 1
			else
				index = index + 1
			end
		end

		white:setOpacity(whitePeak * 35)
	end)
end

function FestivalUtils.stopHanabi(unit, sky, immediately)
	if container then
		if container.removeEnterFrame then
			container:removeEnterFrame("hanabi_loop")
		end

		if container.removeLabelGroupOnFlag then
			container:removeLabelGroupOnFlag("flag_lines")
		end

		container = nil
	end

	local mapX, mapY = global.map:tileToMap(unit.tile)

	global.map:tweenScrollTo(mapX, mapY, 30, function ()
		eStack = {}
	end)
end

function FestivalUtils.startFirework(unit, itemID, isSelf)
	if unit.firework_clip then
		FestivalUtils.resumeFirework(unit)

		return
	end

	FestivalUtils.stopFirework(unit, isSelf, true)

	local tile = MapUtils.findFrontTile(unit)

	if tile then
		local model = "firework_1"
		local clip = Effect.new()

		clip:load(model)

		local mapX, mapY = global.map:tileToMap(tile)

		clip:display(global.map, mapX, mapY)

		unit.firework_clip = clip
		unit.firework_timer = Looper.setTimeout(function ()
			if unit.firework_clip == clip then
				unit.firework_clip = nil
			end

			FestivalUtils.removeFirework(clip)
		end, 90, unit)

		if isSelf then
			local sound = InfoFestival.useItemSound(itemID, 1)

			if not empty(sound) then
				unit.firework_sound = sound

				Sound.playSound(sound, nil, , true)
			end
		end

		return clip
	end
end

function FestivalUtils.resumeFirework(unit)
	if unit.firework_timer then
		Looper.clearTimeout(unit.firework_timer)

		unit.firework_timer = nil
	end

	if unit.firework_clip then
		local clip = unit.firework_clip

		if clip then
			unit.firework_timer = Looper.setTimeout(function ()
				if unit.firework_clip == clip then
					unit.firework_clip = nil
				end

				FestivalUtils.removeFirework(clip)
			end, 90, unit)
		end
	end
end

function FestivalUtils.stopFirework(unit, isSelf, immediately)
	if unit.firework_timer then
		Looper.clearTimeout(unit.firework_timer)

		unit.firework_timer = nil
	end

	if isSelf and unit.firework_sound then
		Sound.stopSound(unit.firework_sound)

		unit.firework_sound = nil
	end

	if unit.firework_clip then
		FestivalUtils.removeFirework(unit.firework_clip, immediately)

		unit.firework_clip = nil
	end
end

function FestivalUtils.removeFirework(clip, immediately)
	if not tolua.isnull(clip) then
		if immediately then
			clip:removeSelf()
		else
			clip:removeFromMap()
			clip:destroy()

			local effectGen = clip:getEffectGen()

			if effectGen then
				effectGen:fadeTo(10, 0)
			end
		end
	end
end

local conStackOnline = {}

function FestivalUtils.confettiOnline()
	print("$$$ confettiOnline")

	local preStackNum = #conStackOnline

	if preStackNum > 5 then
		return
	end

	local container = global.adventureUI

	FestivalUtils.confettiShot(container, conStackOnline, 150)
	container:addEnterFrame("confetti_loop_online", function (dt)
		local passed = dt * 60
		local index = 1
		local loop = #conStackOnline

		while index <= loop do
			local emitter = conStackOnline[index]
			local preX = emitter.x
			local preY = emitter.y
			emitter.frame = emitter.frame + passed
			emitter.speed = emitter.speed * math.pow(emitter.decay, passed)
			emitter.offX = emitter.offX + emitter.speed * math.cos(emitter.angle) * passed
			emitter.offY = emitter.offY + emitter.speed * math.sin(emitter.angle) * passed
			emitter.gSpeed = emitter.gSpeed - emitter.g * passed
			emitter.offY = emitter.offY + emitter.gSpeed
			emitter.x = emitter.centerX + emitter.offX * emitter.radius
			emitter.y = emitter.centerY + emitter.offY * emitter.radius
			emitter.rotate = emitter.rotate + emitter.rotateSpeed * passed
			local anima = emitter.anima

			if anima and not tolua.isnull(anima) then
				anima:setPosition(emitter.x, emitter.y)
			end

			local isOver = nil

			if emitter.y < 0 then
				local anima = emitter.anima

				if anima and not tolua.isnull(anima) then
					anima:removeSelf()

					emitter.anima = nil
				end

				isOver = true
			else
				local anima = emitter.anima

				if anima and not tolua.isnull(anima) then
					local scale = 1

					if emitter.frame < emitter.startFrame then
						scale = math.min(1, emitter.frame / emitter.startFrame)
					end

					if emitter.frame > emitter.endFrame - emitter.startFrame then
						scale = math.min(1, (emitter.endFrame - emitter.frame) / emitter.startFrame)
					end

					anima:setScale(scale * emitter.scale)
					anima:setRotation(emitter.rotate)

					if emitter.endFrame <= emitter.frame then
						isOver = true

						anima:removeSelf()

						emitter.anima = nil
					end
				end
			end

			if isOver then
				table.remove(conStackOnline, index)

				loop = loop - 1
			else
				index = index + 1
			end
		end

		if #conStackOnline == 0 then
			if container.removeEnterFrame then
				container:removeEnterFrame("confetti_loop_online")
			end

			print("$$$ confettiOnlineClose", preStackNum)
		end
	end)
end

function FestivalUtils.confettiShot(customeContainer, customStack, customOpacity)
	container = customeContainer or container

	if not container then
		return
	end

	local animaType = "confetti_01;confetti_02;confetti_03"
	local x = math.random(display.width / 5, display.width / 5 * 4)
	local y = math.random(display.height / 2, display.height / 6 * 5)
	local count = math.random(15, 20)
	local gSpeed = math.random() * 2 + 2

	for i = 1, count do
		local emitter = {
			type = 2,
			centerX = x,
			centerY = y,
			offX = 0,
			offY = 0,
			x = x,
			y = y,
			angle = math.random() * math.pi * 2,
			speed = math.random() * 2 + 10,
			decay = 0.95,
			gSpeed = gSpeed,
			g = 0.03,
			pOpacity = pOpacity,
			pTime = 0.5,
			radius = ((1 - math.sin(math.random() * math.pi)) * 1 + 0.2) * globalScale,
			frame = 0,
			startFrame = math.random(15, 20),
			endFrame = math.random(80, 120),
			scale = math.random() * 0.5 + 0.2,
			rotate = math.random(),
			rotateSpeed = (math.random() * 2 - 1) * 20
		}
		local color = cc.c3b(math.random(0, 255), math.random(0, 255), math.random(0, 255))
		local anima = Animation.new()

		anima:load(SheetUtil.getString(animaType))
		anima:setLooper(MapFrameManager.core)
		anima:setPosition(emitter.x, emitter.y)
		anima:setColor(color)
		anima:setScale(0)

		if customOpacity then
			anima:setOpacity(customOpacity)
		end

		container:addChild(anima, 100)

		emitter.anima = anima

		table.insert(customStack or eStack, emitter)
	end
end

function FestivalUtils.startConfetti(unit, itemID, sky)
	if eStack then
		for i, emitter in ipairs(eStack) do
			local anima = emitter.anima

			if anima then
				anima:removeSelf()
			end
		end
	end

	FestivalUtils.stopConfetti(unit, sky, true)

	local dis = 2
	local tileX = math.max(1, unit.tile.x - dis)
	local tileY = math.max(1, unit.tile.y - dis)
	local offset = math.min(unit.tile.x - tileX, unit.tile.y - tileY)
	local tileX = unit.tile.x - offset
	local tileY = unit.tile.y - offset
	local mapX, mapY = global.map:tileToMap(tileX, tileY)

	global.map:tweenScrollTo(mapX, mapY, 30)

	eStack = {}
	local white = sky:getComponentByTag("white")

	white:setOpacity(0)
	white:setLocalZOrder(200)

	local whitePeak = 0
	container = sky

	container:addEnterFrame("confetti_loop", function (dt)
		local passed = dt * 60
		whitePeak = math.max(0, whitePeak * math.pow(0.98, passed) - 0.03 * passed)
		local index = 1
		local loop = #eStack

		while index <= loop do
			local emitter = eStack[index]
			local preX = emitter.x
			local preY = emitter.y
			emitter.frame = emitter.frame + passed
			emitter.speed = emitter.speed * math.pow(emitter.decay, passed)
			emitter.offX = emitter.offX + emitter.speed * math.cos(emitter.angle) * passed
			emitter.offY = emitter.offY + emitter.speed * math.sin(emitter.angle) * passed
			emitter.gSpeed = emitter.gSpeed - emitter.g * passed
			emitter.offY = emitter.offY + emitter.gSpeed
			emitter.x = emitter.centerX + emitter.offX * emitter.radius
			emitter.y = emitter.centerY + emitter.offY * emitter.radius
			emitter.rotate = emitter.rotate + emitter.rotateSpeed * passed
			local anima = emitter.anima

			if anima then
				anima:setPosition(emitter.x, emitter.y)
			end

			local isOver = nil

			if emitter.y < 0 then
				local anima = emitter.anima

				if anima then
					anima:removeSelf()

					emitter.anima = nil
				end

				isOver = true
			else
				local anima = emitter.anima

				if anima then
					local scale = 1

					if emitter.frame < emitter.startFrame then
						scale = math.min(1, emitter.frame / emitter.startFrame)
					end

					if emitter.frame > emitter.endFrame - emitter.startFrame then
						scale = math.min(1, (emitter.endFrame - emitter.frame) / emitter.startFrame)
					end

					anima:setScale(scale * emitter.scale)
					anima:setRotation(emitter.rotate)

					if emitter.endFrame <= emitter.frame then
						isOver = true

						anima:removeSelf()

						emitter.anima = nil
					end
				end
			end

			if isOver then
				table.remove(eStack, index)

				loop = loop - 1
			else
				index = index + 1
			end
		end

		white:setOpacity(whitePeak * 35)
	end)
end

function FestivalUtils.stopConfetti(unit, sky, immediately)
	if container then
		if container.removeEnterFrame then
			container:removeEnterFrame("confetti_loop")
		end

		container = nil
	end

	local mapX, mapY = global.map:tileToMap(unit.tile)

	global.map:tweenScrollTo(mapX, mapY, 30, function ()
		for i, emitter in ipairs(eStack) do
			local anima = emitter.anima

			if anima then
				anima:removeSelf()
			end
		end

		eStack = {}
	end)
end

function FestivalUtils.clearOnScene()
	eStackOnline = {}
	hanabiLines = {}
	eStack = {}
	container = nil
	hanabiLinesLocked = nil
	conStackOnline = {}
end

return FestivalUtils
