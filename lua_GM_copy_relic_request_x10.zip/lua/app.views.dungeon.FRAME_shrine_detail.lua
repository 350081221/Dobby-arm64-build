local FRAME_shrine_detail = class("FRAME_shrine_detail", UI_base)
local OPEN_TYPE = {
	NONE = 0,
	REMOVE = 1
}
FRAME_shrine_detail.OPEN_TYPE = OPEN_TYPE
local type_buttons = {
	[OPEN_TYPE.NONE] = {},
	[OPEN_TYPE.REMOVE] = {
		"bt_remove"
	}
}

function FRAME_shrine_detail.open(shrineInfo)
	local ui = FRAME_shrine_detail.new(shrineInfo)

	PopManager.open(ui)
end

function FRAME_shrine_detail:ctor(shrineInfo)
	FRAME_shrine_detail.super.ctor(self, "frame_shrine_detail", UIManager.BIG_TYPE.POP)

	self.shrineInfo = shrineInfo

	self:init()
end

function FRAME_shrine_detail:init()
	local buffData = CsvParser.getCsvData("buff", self.shrineInfo.id)

	if buffData.buff_type == 1 then
		self:refreshOpenType(OPEN_TYPE.REMOVE)
	else
		self:refreshOpenType(OPEN_TYPE.NONE)
	end

	self:initUI()
end

function FRAME_shrine_detail:refreshOpenType(openType)
	local allButtonMap = {}
	local openButtonMap = {}

	for type, buttons in pairs(type_buttons) do
		for i, buttonName in ipairs(buttons) do
			allButtonMap[buttonName] = true

			if openType == type then
				openButtonMap[buttonName] = i
			end
		end
	end

	for buttonName, v in pairs(allButtonMap) do
		local com = self:getComponentByTag(buttonName)
		local index = openButtonMap[buttonName]

		com:setVisible(index ~= nil)

		if index then
			com:setTapGroup("button_click")
			com:toTouchable()
			com:addTap(function ()
				if self.callbackStack and self.callbackStack[index] then
					local callback = self.callbackStack[index]

					if callback then
						callback(self.compareUI or self)
					end
				end
			end)
		end
	end

	local bg2 = self:getComponentByTag("bg2")
	local descFlag = self:getFlagByTag("flag_desc")
	local space = 87

	if empty(openButtonMap) then
		descFlag.height = descFlag.height + space
		descFlag.y = descFlag.y - space

		bg2:setSize(nil, bg2.originalHeight + space)
		bg2:setPos(nil, bg2.originalY - space)
	end
end

function FRAME_shrine_detail:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local shrineInfo = self.shrineInfo
	local random = Random.new(shrineInfo.seed)
	local buffData = CsvParser.getCsvData("buff", shrineInfo.id)
	local slot = DropSlot.new(self:getFlagByTag("flag_icon"), "slot_01")

	self:addChild(slot, 100)
	slot:setDrop(DropManager.TYPE.BUFF, shrineInfo)
	self:createLabelOnFlag("flag_name", buffData.name)

	local desc = StringUtil.replaceTag(buffData.desc, function (tag)
		if buffData[tag] then
			return SheetUtil.getNumber(buffData[tag], random)
		end
	end)
	local removeBtn = self:getComponentByTag("bt_remove")

	removeBtn:toTouchable()
	removeBtn:addTap(function ()
		InfoDungeon.removeShrine(shrineInfo, function ()
			PopManager.close()
		end)
	end)

	local textArea = self:createTextAreaOnFlag("flag_desc")

	textArea:setSpace(10, 10)
	textArea:setText(desc)
end

return FRAME_shrine_detail
