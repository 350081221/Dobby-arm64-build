local NAV_base = import(".NAV_base")
local NAV_home_dj = class("NAV_home_dj", NAV_base)

function NAV_home_dj.open(npc)
	local ui = NAV_home_dj.new(npc)

	return ui
end

function NAV_home_dj:ctor(npc)
	NAV_home_dj.super.ctor(self, npc, "nav_home_dj")
end

function NAV_home_dj:init()
	NAV_pet.super.init(self)
end

function NAV_home_dj:onTap(index)
	NAV_home_dj.super.onTap(self, index)

	if index == 1 then
		if InfoHome.isSelf() then
			FRAME_home_dj.open(self.npc)
		else
			FRAME_home_dj_other.open(self.npc)
		end
	end
end

return NAV_home_dj
