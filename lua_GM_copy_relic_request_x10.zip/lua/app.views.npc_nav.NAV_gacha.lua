local NAV_base = import(".NAV_base")
local NAV_gacha = class("NAV_gacha", NAV_base)

function NAV_gacha.open(npc)
	local ui = NAV_gacha.new(npc)

	return ui
end

function NAV_gacha:ctor(npc)
	NAV_gacha.super.ctor(self, npc, "nav_gacha")
	self:refreshRedot()
	ManagerInfo.onDataChange(self, "order", nil, function ()
		self:refreshRedot()
	end)
end

function NAV_gacha:refreshRedot()
	local index = 1
	local ui = self.buttons[index].ui
	local redotCount = InfoGacha.countRedot()
	local redot = ui:getComponentByTag("redot")

	redot:setVisible(redotCount > 0)

	local gachaArr = InfoGacha.getList(self.festival_id)

	if #gachaArr > 0 then
		local gachaData = gachaArr[1]
		local ui = self.buttons[1].ui

		self:setButtonName(ui, gachaData.button_name)
	end
end

function NAV_gacha:onTap(index)
	NAV_gacha.super.onTap(self, index)

	if index == 1 then
		local arr = InfoGacha.getList()

		if #arr > 0 then
			FRAME_gacha.open(self.npc)
		else
			Alert.open(Localization.getSrcText("当前没有可订购的货物"))
		end
	elseif index == 2 then
		FRAME_any_shop.open(InfoGacha, self.npc)
	elseif index == 3 then
		FRAME_card_exchange.open(self.npc)
	end
end

return NAV_gacha
