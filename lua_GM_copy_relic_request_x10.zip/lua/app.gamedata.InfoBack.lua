local InfoBack = {}
local rawData = {}

function InfoBack.init()
	Connection.listen("back_sync", InfoBack.sync)
end

app:addToAppEnterCall(InfoBack.init)

function InfoBack.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoBack.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("back_query", callback)
end

function InfoBack.onQuery(rcvData)
	dump(rcvData, "back_query")

	rawData = {}

	for i, v in ipairs(rcvData.list) do
		rawData[v.id] = v
	end
end

function InfoBack.sync(data)
	dump(data, "$$$ InfoBack.sync")

	if data.is_all == 1 then
		rawData = {}

		for i, data in ipairs(data.list) do
			rawData[data.id] = data
		end
	else
		for i, data in ipairs(data.list) do
			if not rawData[data.id] then
				rawData[data.id] = data
			else
				for k, v in pairs(data) do
					rawData[data.id][k] = v
				end
			end
		end
	end

	notify.dispatch("campaign_changed")
	ManagerInfo.dataChange("back")
end

function InfoBack.checkOpening(id)
	local data = rawData[id]

	if data then
		local nowDay = Time.getToday()
		local createDay = Time.getDay(data.create_time)

		return nowDay - createDay < data.lasting_days, data.lasting_days - (nowDay - createDay)
	end

	return false
end

function InfoBack.getCurrent()
	local arr = {}

	for id, data in pairs(rawData) do
		if InfoBack.checkOpening(id) then
			table.insert(arr, data)
		end
	end

	if #arr > 1 then
		table.sort(arr, function (a, b)
			return b.create_time < a.create_time
		end)
	end

	return arr[1]
end

function InfoBack.countRedot(data)
	local redotCount = 0
	redotCount = redotCount + InfoBackRecord.countRedot(data)
	redotCount = redotCount + InfoBackAchieve.countRedotDay(data)
	redotCount = redotCount + InfoBackAchieve.countRedot(data)

	return redotCount
end

function InfoBack.getTabList(data)
	local csv = CsvParser.getCsvData("back", data.base_id)
	local items = {}
	local obj = {
		label = Localization.getUiLabel("InfoBack.list_1"),
		uiClass = FRAME_back_record,
		countRedot = function ()
			return InfoBackRecord.countRedot(data)
		end
	}

	table.insert(items, obj)

	local obj = {
		type = 1,
		label = Localization.getUiLabel("InfoBack.list_2"),
		uiClass = FRAME_back_achieve,
		countRedot = function ()
			return InfoBackAchieve.countRedotDay(data)
		end
	}

	table.insert(items, obj)

	local obj = {
		type = 2,
		label = Localization.getUiLabel("InfoBack.list_3"),
		uiClass = FRAME_back_achieve,
		countRedot = function ()
			return InfoBackAchieve.countRedot(data)
		end
	}

	table.insert(items, obj)

	if not empty(csv.stage_id) then
		local obj = {
			label = Localization.getUiLabel("InfoBack.list_4"),
			uiClass = FRAME_back_stage,
			countRedot = function ()
				return 0
			end
		}

		table.insert(items, obj)
	end

	return items
end

function InfoBack.enterStage(back_id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			local result = rcvData.dungeon_result
			local title, subTitle = InfoDungeon.getTitle(result.type, result.dungeon_id, result.quest_id, result.abyss_seed)

			Transition.setTitle(title, subTitle)
			Transition.leave(function ()
				if onSuccess then
					onSuccess(result)
				end
			end)
		end
	end

	Connection.request("back_stage_enter", {
		back_id = back_id
	}, callback)
end

return InfoBack
