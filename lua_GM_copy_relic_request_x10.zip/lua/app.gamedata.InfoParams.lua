local InfoParams = {}
local rawData = {}

function InfoParams.init()
	Connection.listen("params_sync", InfoParams.sync)
end

app:addToAppEnterCall(InfoParams.init)

function InfoParams.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoParams.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("params_query", callback)
end

local codeMap = nil

local function getCSV(code)
	local codeMap = CacheData.get("InfoParams_codeMap")

	if not codeMap then
		codeMap = {}
		local csvRaw = CsvParser.getCsvRaw("gm_params")

		for k, csv in pairs(csvRaw) do
			codeMap[csv.code] = csv
		end

		CacheData.set("InfoParams_codeMap", codeMap)
	end

	return codeMap[code]
end

function InfoParams.onQuery(rcvData)
	dump(rcvData, "params_query")

	rawData = {}

	for i, v in ipairs(rcvData.list) do
		local csv = getCSV(v.code)

		if csv.type == 3 then
			rawData[v.code] = v.value_str
		else
			rawData[v.code] = v.value
		end
	end
end

function InfoParams.sync(data)
	dump(data, "$$$ InfoParams.sync")

	for i, v in ipairs(data.list) do
		local csv = getCSV(v.code)

		if csv.type == 3 then
			rawData[v.code] = v.value_str
		else
			rawData[v.code] = v.value
		end
	end

	ManagerInfo.dataChange("params")
end

function InfoParams.getValue(code)
	if rawData[code] then
		return rawData[code]
	else
		local csv = getCSV(code)

		return csv.default_value
	end
end

return InfoParams
