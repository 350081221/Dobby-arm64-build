local UI_base = import("..UI_base")
local FRAME_naraka_boss = class("FRAME_naraka_boss", UI_base)

function FRAME_naraka_boss.open()
	local ui = FRAME_naraka_boss.new()

	ui:onOpen()
	PopManager.open(ui, nil, function ()
		if ui.onClose then
			ui:onClose()
		end
	end, PopManager.ANIM_TYPE.FADE, 100)
end

function FRAME_naraka_boss:ctor()
	FRAME_naraka_boss.super.ctor(self, "frame_naraka_boss", UIManager.BIG_TYPE.POP)
	self:init()
end

function FRAME_naraka_boss:init()
	self:initUI()

	local csvList = CsvParser.getCsvList("naraka_mode")

	self.list:setItems(csvList)

	local openMap = {}
	local modes = InfoNaraka.getModes()

	for i, v in ipairs(modes) do
		openMap[tonumber(v)] = true
	end

	local arr = {}
	local starNum = 0
	local starMax = 0

	for i, v in ipairs(csvList) do
		if openMap[v.id] then
			table.insert(arr, i)

			starNum = starNum + v.reward_score
		end

		starMax = starMax + v.reward_score
	end

	self.list:setSelectedMulti(arr)

	local style = {
		size = 30,
		color = InfoHero.getHpColor(1 - starNum / starMax)
	}

	self:replaceLabelGroupOnFlag("flag_star_num", {
		starNum
	}, {
		style
	})
end

function FRAME_naraka_boss:initUI()
	local mask = self:getComponentByTag("mask")

	mask:toTouchable()
	mask:setOpacity(0)

	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local narakaCSV = InfoNaraka.getNarakaCSV()

	local function restart()
		local data = self.list:getSelectedItem()

		local function onSuccess(result)
			InfoDungeon.enterStage(result)
			DungeonScene.enterDungeon(DungeonScene.ENTER_TYPE.NEW, result)
		end

		InfoNaraka.enterStage(narakaCSV.id, onSuccess)
	end

	local bt_restart = self:getComponentByTag("bt_restart")

	bt_restart:toTouchable()
	bt_restart:setTapGroup("button_click")
	bt_restart:addTap(function ()
		POP_notice.open(Localization.getSrcText("要重新开始永劫之庭吗？"), restart)
	end)

	local function tapListener(ui, csv, index)
	end

	self.list = self:createListOnFlag("flag_mode", LIST_naraka_mode, tapListener, touchListener)

	self.list:setTapGroup("list_click")
	self.list:setMultiSelectEnabled(true, true)
end

function FRAME_naraka_boss:onOpen()
	local mask = self:getComponentByTag("mask")
	local centerX = mask.x / 2

	global.map:setPositionOffset("ui_open", centerX - display.cx, 0)
	MapUtils.focusIn(nil, , 10, 1.4)
end

function FRAME_naraka_boss:onClose()
	global.map:setPositionOffset("ui_open", 0, 0)
	MapUtils.focusOut(nil, , 15)
end

return FRAME_naraka_boss
