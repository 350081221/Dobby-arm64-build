local UI_base = import("..UI_base")
local QuickQuest = class("QuickQuest", UI_base)

function QuickQuest:ctor()
	QuickQuest.super.ctor(self, "com_quick_quest")
	self:init()
end

function QuickQuest:init()
	self:initUI()
	self:refreshQuest()
	ManagerInfo.onDataChange(self, "quest", nil, function ()
		self:refreshQuest()
	end)
	ManagerInfo.onDataChange(self, "item", nil, function ()
		self:refreshQuest()
	end)
end

function QuickQuest:initUI()
end

function QuickQuest:refreshQuest()
	local questInfo = InfoQuest.getFocusQuest()
	local bg = self:getComponentByTag("quest_bg")
	local icon = self:getComponentByTag("quest_icon")

	if questInfo then
		local questData = CsvParser.getCsvData("quest", questInfo.quest_id)
		local targetDesc = InfoQuest.getTargetDesc(questInfo.quest_id)
		local label, labelWidth, labelHeight = self:createLabelOnFlag("flag_quest_target", targetDesc)

		bg:setSize(labelWidth + 35)
		bg:setVisible(true)
		icon:setVisible(true)

		if not InfoQuest.canFinish(questInfo.quest_id) then
			icon:setFrame(1)
		else
			icon:setFrame(2)
		end

		bg:toTouchable()
		bg:addTap(function ()
			FRAME_quest.open()
		end)
	else
		self:removeLabelOnFlag("flag_quest_target")
		bg:setVisible(false)
		icon:setVisible(false)
	end
end

return QuickQuest
