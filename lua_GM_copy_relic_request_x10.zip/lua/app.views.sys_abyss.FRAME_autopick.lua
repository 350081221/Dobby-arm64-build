local FRAME_autopick = class("FRAME_autopick", UI_base)

function FRAME_autopick.open()
	local ui = FRAME_autopick.new()

	PopManager.open(ui)

	return ui
end

function FRAME_autopick:ctor()
	FRAME_autopick.super.ctor(self, "frame_autopick", UIManager.BIG_TYPE.POP)
	self:init()
end

function FRAME_autopick:init()
	self:initUI()
	self:refreshNum()
	self:refreshAutopick()
end

function FRAME_autopick:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local autopick_item = CsvParser.getCsvData("config", "autopick_item").value
	local itemData = CsvParser.getCsvData("item", autopick_item)
	local itemInfo = {
		base_id = autopick_item,
		num = InfoItem.getNum(autopick_item)
	}
	self.maxNum = InfoItem.getNum(autopick_item)
	self.minNum = math.min(self.maxNum, 1)
	self.num = self.minNum
	local slot = DropSlot.new(self:getFlagByTag("flag_icon"), "slot_01")

	self:addChild(slot, 100)
	slot:setDrop(DropManager.TYPE.ITEM, itemInfo)

	local function tapListener(ui, data, index, x, y)
		if ui.slots then
			local worldPos = self.textArea:convertToWorldSpace(cc.p(x, y))

			for i, slot in ipairs(ui.slots) do
				if slot:hitTestByComponent("bg", worldPos.x, worldPos.y, true) then
					if slot.type == DropManager.TYPE.CARD then
						FRAME_card.openPreview(slot.info)

						break
					end

					if slot.type == DropManager.TYPE.ITEM then
						local x, y = slot:getPosition()
						local pos = ui:convertToWorldSpace(cc.p(x, y))

						FRAME_item_mini.open(cc.rect(pos.x, pos.y, slot.width, slot.height), slot.info)

						break
					end

					DropManager.popDetail(slot.type, slot.info)

					break
				end
			end
		end
	end

	self.textArea = self:createListOnFlag("flag_desc", function (rect)
		return LIST_item_detail.new(rect, self:getStyleByTag("flag_desc"))
	end, tapListener)

	self.textArea:setSpace(10, 10)

	local holder = self:getComponentByTag("holder")
	local holder_bg = self:getComponentByTag("holder_bg")
	local items, hasDrop = FRAME_item_detail.getDesc(itemData, self.textArea)

	if hasDrop then
		holder:setVisible(true)
		holder_bg:setVisible(true)
		self.textArea:setHolders({
			holder
		}, nil, 5)
	else
		holder:setVisible(false)
		holder_bg:setVisible(false)
	end

	self.textArea:setItems(items, true)
	self:createScrollerByTag("bar", "flag_bar", function (percent, isEnd)
		self.num = math.floor((self.maxNum - self.minNum) * percent) + self.minNum

		self:refreshNum()
	end)

	local bar_bg = self:getComponentByTag("bar_bg")

	bar_bg:removeTouchable()

	local style = {
		wrap = true
	}
	local label = self:createLabelOnFlag("flag_name", itemData.name, style)
	local bt_use = self:getComponentByTag("bt_use")

	bt_use:toTouchable()
	bt_use:setTapGroup("button_click")
	bt_use:addTap(function ()
		if self.num > 0 then
			InfoDungeon.autoPickAdd(self.num, function ()
				PopManager.closeTo(self)
			end)
		else
			Alert.open(Localization.getSrcText("物品数量不足"))
		end
	end)
end

function FRAME_autopick:refreshAutopick()
	local funcCSV = InfoFunction.checkFuncOpen(10160)

	if funcCSV then
		local autopick_item = CsvParser.getCsvData("config", "autopick_item").value
		local item_csv = CsvParser.getCsvData("item", autopick_item)
		local label_yes = self:getComponentByTag("label_autopick_yes")
		local label_no = self:getComponentByTag("label_autopick_no")

		local function refreshTime()
			local nowTime = math.floor(Time.now())
			local time = InfoDungeon.autoPickTime()

			if time <= nowTime then
				label_no:setVisible(true)
				label_yes:setVisible(false)
				self:removeEnterFrame("refreshTime_autopick")

				self.autopickTimeStr = nil
			else
				label_no:setVisible(false)

				local timeLeft = time - nowTime
				local timeStr = Time.showMin(timeLeft)

				if self.autopickTimeStr ~= timeStr then
					self.autopickTimeStr = timeStr

					self:replaceLabelOnFlag("label_autopick_yes", nil, timeStr)
				end
			end
		end

		self:addEnterFrame("refreshTime_autopick", refreshTime)
		refreshTime()
	end
end

function FRAME_autopick:refreshNum()
	self.num = math.min(self.num, self.maxNum)
	local percent = 0

	if self.maxNum > 1 then
		percent = (self.num - self.minNum) / (self.maxNum - self.minNum)
	end

	self:setScollerProgressByTag("flag_bar", percent)
	self:replaceLabelOnFlag("flag_num", nil, self.num)
end

return FRAME_autopick
