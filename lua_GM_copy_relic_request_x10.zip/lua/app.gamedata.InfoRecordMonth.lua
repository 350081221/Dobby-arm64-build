local InfoRecordMonth = {}
local rawData = nil

function InfoRecordMonth.init()
	Connection.listen("record_month_sync", InfoRecordMonth.sync)
end

app:addToAppEnterCall(InfoRecordMonth.init)

function InfoRecordMonth.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoRecordMonth.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("record_month_query", callback)
end

function InfoRecordMonth.onQuery(rcvData)
	rawData = rcvData

	InfoRecordMonth.checkNextTurn(onSuccess, onFailure)
end

function InfoRecordMonth.sync(syncData)
	for k, v in pairs(syncData) do
		rawData[k] = v
	end

	notify.dispatch("campaign_changed")
	ManagerInfo.dataChange("record_month")
end

function InfoRecordMonth.getReward(day, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("record_month_get_reward", {
		day = day
	}, callback)
end

function InfoRecordMonth.checkNextTurn(onSuccess, onFailure)
	local turnMap = InfoRecordMonth.getTurnMap()
	local days = turnMap[rawData.turn]

	for i, v in ipairs(days) do
		if InfoRecordMonth.getRecord(v.day) == 0 then
			return
		end
	end

	local nowTime = Time.now()
	local isPassed = RefreshManager.checkTimePassed(RefreshManager.TYPE.SIGN_IN, nowTime, rawData.reward_time)

	if not isPassed then
		return
	end

	local function callback(rcvData)
		dump(rcvData, "record_month_next_turn")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("record_month_next_turn", callback)
end

function InfoRecordMonth.getRecord(day)
	local recordNum = rawData.reward_record

	return BitUtil.getBitByIndex(recordNum, day)
end

function InfoRecordMonth.getDays()
	local nowTime = Time.now()
	local login_time = rawData.login_time
	local login_days = rawData.login_days
	local dayPassed = RefreshManager.checkTimePassedDays(RefreshManager.TYPE.SIGN_IN, nowTime, login_time)

	return login_days + dayPassed
end

function InfoRecordMonth.getTurnMap()
	local record_month_turnMap = CacheData.get("InfoRecordMonth_record_month_turnMap")

	if not record_month_turnMap then
		record_month_turnMap = {}
		local csvRaw = CsvParser.getCsvRaw("record_month")

		for k, v in pairs(csvRaw) do
			if not record_month_turnMap[v.turn] then
				record_month_turnMap[v.turn] = {}
			end

			record_month_turnMap[v.turn][v.day] = v
		end

		CacheData.set("InfoRecordMonth_record_month_turnMap", record_month_turnMap)
	end

	return record_month_turnMap
end

function InfoRecordMonth.getList()
	local turnMap = InfoRecordMonth.getTurnMap()
	local days = turnMap[rawData.turn]
	local arr = {}

	for k, v in pairs(days) do
		table.insert(arr, v)
	end

	table.sort(arr, function (a, b)
		return a.day < b.day
	end)

	return arr
end

function InfoRecordMonth.countRedot()
	local redotCount = 0
	local turnMap = InfoRecordMonth.getTurnMap()
	local days = turnMap[rawData.turn]

	for i, v in ipairs(days) do
		if v.day <= InfoRecordMonth.getDays() and InfoRecordMonth.getRecord(v.day) == 0 then
			redotCount = redotCount + 1
		end
	end

	print("$$$ InfoRecordMonth.countRedot", redotCount)

	return redotCount
end

return InfoRecordMonth
