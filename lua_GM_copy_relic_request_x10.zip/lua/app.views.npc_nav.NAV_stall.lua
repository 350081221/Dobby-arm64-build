local NAV_base = import(".NAV_base")
local NAV_stall = class("NAV_stall", NAV_base)

function NAV_stall.open(npc, stallData)
	local ui = NAV_stall.new(npc, stallData)

	return ui
end

function NAV_stall:ctor(npc, stallData)
	NAV_stall.super.ctor(self, npc, "nav_stall")

	self.stallData = stallData
end

function NAV_stall:init()
	NAV_stall.super.init(self)
end

function NAV_stall:onTap(index)
	NAV_stall.super.onTap(self, index)

	if index == 1 then
		FRAME_exchange_buy.open(self.npc, self.stallData)
	end
end

return NAV_stall
