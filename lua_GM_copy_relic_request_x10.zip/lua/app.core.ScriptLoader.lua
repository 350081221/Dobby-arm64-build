local ScriptLoader = {
	load = function (path)
		local lua = getFileString(path)
		local t = type(lua)

		if t == "nil" or lua == "" then
			return nil
		elseif t == "number" or t == "string" or t == "boolean" then
			lua = tostring(lua)
		else
			error("can not load a " .. t .. " type.")
		end

		local sBegan, sEnd = string.find(lua, "return", 1, true)

		if sBegan ~= 1 then
			lua = "return " .. lua
		end

		local func = loadstring(lua)

		if func == nil then
			return nil
		end

		local res = func()

		return res
	end
}

return ScriptLoader
