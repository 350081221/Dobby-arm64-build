local LIST_gate_server = class("LIST_gate_server", List)
local statusLabelMap = {
	{
		name = Localization.getSrcText("推荐"),
		style = {
			color = Style.green
		}
	},
	{
		name = Localization.getSrcText("火热"),
		style = {
			color = Style.red
		}
	},
	{
		name = Localization.getSrcText("维护"),
		style = {
			color = Style.gray
		}
	}
}

function LIST_gate_server:ctor(rect, cols)
	LIST_gate_server.super.ctor(self, rect)
	self:setCols(cols or 3)
	self:setSpace(0, 5)
	self:setCellName("cell_gate_server")
	self:setCellSize(cc.size(self.touchRect.width, 70))
end

function LIST_gate_server:getCellName(index)
	local data = self.items[self.cols * (index - 1) + 1]

	if data.label then
		return "cell_gate_server_line"
	else
		return self.cellName
	end
end

function LIST_gate_server:getCellSize(index)
	local data = self.items[self.cols * (index - 1) + 1]

	if data.label then
		return cc.size(self.touchRect.width, 55)
	else
		return self.cellSize
	end
end

function LIST_gate_server:onCellInit(ui, data, index)
	if data.empty then
		ui:setVisible(false)

		return
	end

	ui:setVisible(true)

	if data.label then
		ui:createLabelOnFlag("flag_label", data.label)

		local offsetWidth = self.rect.width - self.rect.originalWidth
		local line = ui:getComponentByTag("line")

		line:setSize(line.originalWidth + offsetWidth)
	else
		ui:createLabelOnFlag("flag_name", data.name)

		local statusLabel = statusLabelMap[data.status]

		if statusLabel then
			ui:createLabelOnFlag("flag_status", statusLabel.name, statusLabel.style)
		else
			ui:removeLabelOnFlag("flag_status")
		end

		self:onCellSelected(ui, data, self.selectedIndex == index)
	end
end

function LIST_gate_server:onCellSelected(ui, data, _selected)
	local selected = ui:getComponentByTag("selected")

	selected:setVisible(_selected)
end

return LIST_gate_server
