local NAV_base = import(".NAV_base")
local NAV_pet = class("NAV_pet", NAV_base)

function NAV_pet.open(npc)
	local ui = NAV_pet.new(npc)

	return ui
end

function NAV_pet:ctor(npc)
	NAV_pet.super.ctor(self, npc, "nav_pet")
end

function NAV_pet:init()
	NAV_pet.super.init(self)
	self:setBuildingLvupIndex(2)

	local index = 4
	local funcCSV = InfoFunction.checkFuncOpen(10091)

	if funcCSV then
		self:setButtonVisible(index, true)
	else
		self:setButtonVisible(index, false)
	end

	local index = 5
	local opening = InfoParams.getValue("pet_replace")

	self:setButtonVisible(index, opening == 1)

	local index = 6
	local opening = InfoParams.getValue("pet_quality_up")

	self:setButtonVisible(index, opening == 1)
end

function NAV_pet:onTap(index)
	NAV_pet.super.onTap(self, index)

	if index == 1 then
		local arr = FRAME_pet_transfer.getPetList()

		if #arr > 0 then
			FRAME_pet_transfer.open(self.npc)
		else
			Alert.open(Localization.getSrcText("没有可进化的宠物"))
		end
	elseif index == 3 then
		FRAME_pet_equip_compose.open(self.npc)
	elseif index == 4 then
		local arr = FRAME_pet_synth.getPetList()

		if #arr > 0 then
			FRAME_pet_synth.open(self.npc)
		else
			Alert.open(Localization.getSrcText("没有可融合的宠物"))
			self.npc:say(Localization.getSrcText("2星及以上宠物可以融合哦"), frameTime, style)
		end
	elseif index == 5 then
		local opening = InfoParams.getValue("pet_replace")

		if opening == 1 then
			FRAME_pet_exchange.open(self.npc)
		end
	elseif index == 6 then
		local opening = InfoParams.getValue("pet_quality_up")

		if opening == 1 then
			FRAME_pet_quality.open(self.npc)
		end
	elseif index == 7 then
		FRAME_pet_sell.open(self.npc)
	end
end

return NAV_pet
