local CacheData = {}
local dataCached = {}

function CacheData.get(cache_key)
	return dataCached[cache_key]
end

function CacheData.set(cache_key, data)
	dataCached[cache_key] = data
end

function CacheData.clear(cache_key)
	dataCached[cache_key] = nil
end

function CacheData.clearOnScene()
	dataCached = {}
end

function CacheData.chance_getGladiator(chanceID, state)
	local csvList = CsvParser.getCsvList("chance_gladiator")

	for i, csv in ipairs(csvList) do
		if csv.chance_id == chanceID and csv.state == state then
			print("$$$ chance_gladiator", csv.id)

			return csv
		end
	end
end

return CacheData
