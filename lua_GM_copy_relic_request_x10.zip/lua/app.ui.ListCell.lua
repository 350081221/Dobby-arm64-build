local UIManager = import(".UIManager")
local ListCell = class("ListCell", function (contentSize)
	local node = display.newNode()

	if contentSize then
		node:setContentSize(contentSize)
	end

	node:setNodeEventEnabled(true)
	node:setCascadeOpacityEnabled(true)
	node:setCascadeColorEnabled(true)

	return node
end)
ListCell.DIRECTION_VERTICAL = 1
ListCell.DIRECTION_HORIZONTAL = 2

function ListCell:ctor(size, ui, cols, direction, leftSpace, rightSpace)
	event_listener.extendMethods(self, true)
	self:setContentSize(size)

	self.size = size

	if cols > 1 then
		self.ui = display.newNode()

		self.ui:setCascadeOpacityEnabled(true)
		self.ui:setCascadeColorEnabled(true)

		self.ui_cols = {}

		for i = 1, cols do
			local uiInstance = nil

			if not ui or ui == "" then
				uiInstance = display.newNode()

				uiInstance:setCascadeOpacityEnabled(true)
				uiInstance:setCascadeColorEnabled(true)
			else
				uiInstance = UIManager.getUI(ui)
			end

			if direction == ListCell.DIRECTION_VERTICAL then
				uiInstance:setPositionX(math.floor((size.width - leftSpace - rightSpace) / cols * (i - 1) + leftSpace))
			else
				uiInstance:setPositionY(math.floor((size.height - leftSpace - rightSpace) / cols * (cols - i) + rightSpace))
			end

			table.insert(self.ui_cols, uiInstance)
			self.ui:addChild(uiInstance)
		end
	elseif not ui or ui == "" then
		self.ui = display.newNode()

		self.ui:setCascadeOpacityEnabled(true)
		self.ui:setCascadeColorEnabled(true)
	else
		self.ui = UIManager.getUI(ui)
	end

	self:addChild(self.ui)
end

function ListCell:setData(data)
	self.data = data

	if self.ui_cols then
		for i = 1, #self.ui_cols do
			self.ui_cols[i]:setVisible(self.data[i] ~= nil)

			if self.data[i] then
				self.ui_cols[i].data = self.data[i]
			end
		end
	end
end

function ListCell:setSize(size)
	self:setContentSize(size)
end

function ListCell:onTouch(event, x, y)
	self:dispatchEvent({
		name = "onTouchListIcon",
		data = self.data,
		state = event,
		x = x,
		y = y,
		ui = self.ui,
		ui_cols = self.ui_cols,
		index = self.index
	})
end

function ListCell:onTap(x, y)
	self:dispatchEvent({
		name = "onTapListIcon",
		data = self.data,
		x = x,
		y = y,
		ui = self.ui,
		ui_cols = self.ui_cols,
		index = self.index
	})
end

function ListCell:onExit()
	self:removeAllEventListeners()
	self:removeAllNodeEventListeners()
end

return ListCell
