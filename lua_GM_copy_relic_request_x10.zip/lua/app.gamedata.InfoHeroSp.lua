local InfoHeroSp = {}
local rawData = {}
local storyLockCache = nil

function InfoHeroSp.init()
	Connection.listen("hero_sp_sync", InfoHeroSp.sync)

	storyLockCache = {}
	local csvRaw = CsvParser.getCsvRaw("hero_story")

	for k, csv in pairs(csvRaw) do
		if not empty(csv.next) then
			storyLockCache[csv.next] = csv.id
		end
	end
end

app:addToAppEnterCall(InfoHeroSp.init)

function InfoHeroSp.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoHeroSp.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("hero_sp_query", callback)
end

function InfoHeroSp.onQuery(rcvData)
	rawData = {}

	for i, data in ipairs(rcvData.list) do
		rawData[data.base_id] = data
	end
end

function InfoHeroSp.sync(data)
	dump(data, "$$$ InfoHeroSp.sync")

	for i, syncData in ipairs(data.list) do
		local base_id = syncData.base_id

		if rawData[base_id] then
			for k, v in pairs(syncData) do
				rawData[base_id][k] = v
			end
		else
			rawData[base_id] = syncData
		end
	end

	ManagerInfo.dataChange("hero_sp")
end

function InfoHeroSp.enterStory(hero_id, story_id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			local result = rcvData.dungeon_result
			local title, subTitle = InfoDungeon.getTitle(result.type, result.dungeon_id, result.quest_id, result.abyss_seed)

			Transition.setTitle(title, subTitle)
			Transition.leave(function ()
				if onSuccess then
					onSuccess(result)
				end
			end)
		end
	end

	Connection.request("hero_sp_story", {
		hero_id = hero_id,
		story_id = story_id
	}, callback)
end

function InfoHeroSp.getReward(hero_id, story_id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("hero_sp_reward", {
		hero_id = hero_id,
		story_id = story_id
	}, callback)
end

function InfoHeroSp.isStoryOpen(story_id)
	local lockID = storyLockCache[story_id]

	if lockID then
		return InfoHeroSp.isStoryFin(lockID)
	end

	return true
end

function InfoHeroSp.isStoryFin(story_id)
	local story_csv = CsvParser.getCsvData("hero_story", story_id)
	local sp_id = story_csv.sp_id

	if rawData[sp_id] then
		local currentID = rawData[sp_id].story_id

		while not empty(currentID) do
			if currentID == story_id then
				return true
			end

			currentID = storyLockCache[currentID]
		end
	end

	return false
end

function InfoHeroSp.countRedotHero(heroInfo)
	local redotCount = 0
	local arr = InfoHero.getSpStoryList(heroInfo)

	for i, v in ipairs(arr) do
		redotCount = redotCount + InfoHeroSp.countRedotStory(v.id)
	end

	return redotCount
end

function InfoHeroSp.countRedotStory(story_id)
	local redotCount = 0

	if InfoHeroSp.isStoryOpen(story_id) and not InfoHeroSp.isStoryFin(story_id) then
		local story_csv = CsvParser.getCsvData("hero_story", story_id)
		local sp_id = story_csv.sp_id
		local heroInfo = InfoHero.getTopLevelSP(sp_id)

		if heroInfo then
			local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)

			if story_csv.job_level <= heroCSV.job_level then
				redotCount = redotCount + 1
			end
		end
	end

	return redotCount
end

return InfoHeroSp
