local InfoLang = {}
local rawData = {}

function InfoLang.init()
	Connection.listen("lang_sync", InfoLang.sync)
end

app:addToAppEnterCall(InfoLang.init)

function InfoLang.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoLang.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("lang_query", callback)
end

function InfoLang.onQuery(rcvData)
	dump(rcvData, "lang_query")

	rawData = {}

	for i, v in ipairs(rcvData.list) do
		rawData[v.id] = v.open
	end

	Localization.init(4)
end

function InfoLang.sync(data)
	dump(data, "$$$ InfoLang.sync")

	rawData = {}

	for i, v in ipairs(data.list) do
		rawData[v.id] = v.open
	end

	Localization.init(5)
	ManagerInfo.dataChange("lang")
end

function InfoLang.getOpen(id)
	if rawData[id] then
		return rawData[id] == 1
	else
		return true
	end
end

return InfoLang
