local UI_base = import("..UI_base")
local DropSlot = class("DropSlot", UI_base)
local ICON_DESIGN_SIZE = 64
DropSlot.ICON_DESIGN_SIZE = ICON_DESIGN_SIZE

function DropSlot:ctor(rect, uiName)
	DropSlot.super.ctor(self, uiName)

	self.size = rect

	self:init()

	if rect then
		self:setPosition(rect.x, rect.y)
	end
end

function DropSlot:init()
	self:initUI()
	self:setSelected(false)
end

function DropSlot:fitSize(tag)
	local com = self:getComponentByTag(tag)

	if com then
		com:setSize(com.width + self.widthOffset, com.height + self.heightOffset)
		com:resetLabel()
	end

	return com
end

function DropSlot:initUI()
	local originalWidth = self.width
	local originalHeight = self.height
	local rect = self:getFlagByTag("rect")

	if rect then
		originalWidth = rect.width
		originalHeight = rect.height
	end

	self.width = self.size.width
	self.height = self.size.height
	local widthOffset = 0
	local heightOffset = 0

	if self.width ~= originalWidth or self.height ~= originalHeight then
		widthOffset = self.width - originalWidth
		heightOffset = self.height - originalHeight
		local comTags = {
			"quality",
			"selected",
			"border",
			"quality_border",
			"ex_border",
			"bg",
			"cd_flash"
		}

		for i, tag in ipairs(comTags) do
			local com = self:getComponentByTag(tag)

			if com then
				com:setSize(com.width + widthOffset, com.height + heightOffset)
			end
		end

		local comTags = {
			"bar_bg",
			"hp_bar",
			"bg1"
		}

		for i, tag in ipairs(comTags) do
			local com = self:getComponentByTag(tag)

			if com then
				com:setSize(com.width + widthOffset, com.height)
			end
		end

		local comTags = {
			"growth"
		}

		for i, tag in ipairs(comTags) do
			local com = self:getComponentByTag(tag)

			if com then
				com:setPositionX(com:getPositionX() + widthOffset)
			end
		end

		local comTags = {
			"equiped",
			"skill_border"
		}

		for i, tag in ipairs(comTags) do
			local com = self:getComponentByTag(tag)

			if com then
				com:setPositionY(com:getPositionY() + heightOffset)
			end
		end

		local comTags = {
			"locker"
		}

		for i, tag in ipairs(comTags) do
			local com = self:getComponentByTag(tag)

			if com then
				com:setPositionX(com:getPositionX() + widthOffset)
				com:setPositionY(com:getPositionY() + heightOffset)
			end
		end

		local flagTags = {
			"flag_skill",
			"flag_hero_level"
		}

		for i, tag in ipairs(flagTags) do
			local flag = self:getFlagByTag(tag)

			if flag then
				flag.y = flag.y + heightOffset
			end
		end

		local flagTags = {
			"flag_icon"
		}

		for i, tag in ipairs(flagTags) do
			local flag = self:getFlagByTag(tag)

			if flag then
				flag.width = flag.width + widthOffset
				flag.height = flag.height + heightOffset
			end
		end

		local flagTags = {
			"flag_num",
			"flag_num_1",
			"flag_enhance"
		}

		for i, tag in ipairs(flagTags) do
			local flag = self:getFlagByTag(tag)

			if flag then
				flag.x = flag.x + widthOffset
			end
		end

		for i = 1, GameConfig.equip_gem_max do
			local flag = self:getFlagByTag("flag_gem_" .. i)

			if flag then
				flag.x = flag.x + widthOffset / 2
				flag.originalX = flag.x
			end
		end

		local flagTags = {
			"flag_name"
		}

		for i, tag in ipairs(flagTags) do
			local flag = self:getFlagByTag(tag)

			if flag then
				flag.width = flag.width + widthOffset
			end
		end
	end

	self.widthOffset = widthOffset
	self.heightOffset = heightOffset
	local quality = self:getComponentByTag("quality")

	if quality then
		quality:setVisible(false)
	end

	local equiped = self:getComponentByTag("equiped")

	if equiped then
		equiped:setVisible(false)
		equiped:setLocalZOrder(equiped:getLocalZOrder() + 100)
	end

	local locker = self:getComponentByTag("locker")

	if locker then
		locker:setVisible(false)
		locker:setLocalZOrder(locker:getLocalZOrder() + 100)
	end

	local illusion = self:getComponentByTag("illusion")

	if illusion then
		illusion:setVisible(false)
	end

	self:setContentSize(cc.size(self.width, self.height))

	local qualityBorder = self:getComponentByTag("quality_border")

	if qualityBorder then
		qualityBorder:setLocalZOrder(qualityBorder:getLocalZOrder() + 100)
	end

	local bg1 = self:getComponentByTag("bg1")

	if bg1 then
		bg1:setLocalZOrder(bg1:getLocalZOrder() + 100)
	end

	local border = self:getComponentByTag("border")

	if border then
		border:setLocalZOrder(border:getLocalZOrder() + 100)
	end

	local selected = self:getComponentByTag("selected")

	if selected then
		selected:setLocalZOrder(selected:getLocalZOrder() + 100)
	end

	local heroBorder = self:getComponentByTag("hero_border")

	if heroBorder then
		heroBorder:setLocalZOrder(heroBorder:getLocalZOrder() + 100)
	end

	local growth = self:getComponentByTag("growth")

	if growth then
		growth:setVisible(false)
	end

	local star = self:getComponentByTag("star")

	if star then
		star:setPos(star.x + widthOffset / 2)
		star:setVisible(false)
		star:setLocalZOrder(star:getLocalZOrder() + 100)
	end

	local ex_border = self:getComponentByTag("ex_border")

	if ex_border then
		ex_border:setLocalZOrder(ex_border:getLocalZOrder() + 100)
	end
end

function DropSlot:setBorderColor(color)
	local qualityBorder = self:getComponentByTag("quality_border")

	if qualityBorder then
		qualityBorder:setColor(color)
	end

	local border = self:getComponentByTag("border")

	if border then
		border:setColor(color)
	end
end

function DropSlot:refreshStars(starNum)
	if not starNum then
		return
	end

	local star = self:getComponentByTag("star")

	if star then
		local spaceX = 12

		if star.labelStyle then
			spaceX = star.labelStyle.size
		end

		UIUtil.createStar(self, "star", starNum, spaceX, 0, Style.center, 1, spaceX / 16, 200)
	end
end

function DropSlot:setDrop(_type, info, param)
	self:clearDrop()

	_type = tonumber(_type)
	self.type = _type
	self.info = info
	local growth = self:getComponentByTag("growth")

	if growth then
		growth:setVisible(_type == DropManager.TYPE.ITEM_GROWTH)
		growth:setLocalZOrder(1000)
	end

	if _type == DropManager.TYPE.ITEM or _type == DropManager.TYPE.ITEM_GROWTH then
		if empty(info.base_id) then
			return
		end

		local itemData = CsvParser.getCsvData("item", info.base_id)
		self.icon = self:createIconOnFlag("flag_icon", IconManager.getItemIcon(info.base_id), 100, true)

		if info.num then
			if type(info.num) == "number" then
				if info.num > 1 or self.alwaysShowNumber then
					self:createLabelOnFlag("flag_num", StringUtil.simplifyNumber(info.num))
				end
			elseif type(info.num) == "string" then
				if string.find(info.num, "~") then
					local numArr = string.split(info.num, "~")

					self:createLabelOnFlag("flag_num_1", numArr[1])
					self:createLabelOnFlag("flag_num", "~" .. numArr[2])
				else
					self:createLabelOnFlag("flag_num", info.num)
				end
			end
		end

		if self:getFlagByTag("flag_name") then
			self:createLabelOnFlag("flag_name", itemData.name)
		end

		local quality = self:getComponentByTag("quality")
		local qualityColor = nil

		if quality then
			qualityColor = InfoHero.getQualityColor(itemData.quality)

			quality:setVisible(true)
			quality:setColor(qualityColor)
		end

		local qualityBorder = self:getComponentByTag("quality_border")

		if qualityBorder then
			qualityBorder:setVisible(true)
			qualityBorder:setColor(qualityColor or InfoHero.getQualityColor(itemData.quality))
		end
	elseif _type == DropManager.TYPE.EQUIP then
		if empty(info.base_id) then
			return
		end

		local equipData = CsvParser.getCsvData("equip", info.base_id)
		self.icon = self:createIconOnFlag("flag_icon", IconManager.getEquipIcon(info.base_id), 100, true)
		local quality = self:getComponentByTag("quality")
		local qualityColor = nil

		if quality then
			qualityColor = InfoEquip.getQualityColor(info)

			quality:setVisible(true)
			quality:setColor(qualityColor)
		end

		local qualityBorder = self:getComponentByTag("quality_border")

		if qualityBorder then
			qualityBorder:setVisible(true)
			qualityBorder:setColor(qualityColor or InfoEquip.getQualityColor(info))
		end

		local excellentCSV = nil

		if not empty(info.excellent) then
			excellentCSV = CsvParser.getCsvData("equip_excellent", info.excellent)
		end

		local bg = self:getComponentByTag("bg")

		if bg then
			if excellentCSV and (excellentCSV.type == 1 or excellentCSV.type == 3) then
				bg:setFrame(3)
			elseif info.saved == 0 then
				bg:setFrame(2)
			else
				bg:setFrame(1)
			end
		end

		local ex_border = self:getComponentByTag("ex_border")

		if ex_border and excellentCSV and (excellentCSV.type == 2 or excellentCSV.type == 3) then
			ex_border:setColor(Style.excellentColor)
			ex_border:setVisible(true)
		end

		if param ~= "simple" then
			local equiped = self:getComponentByTag("equiped")

			if equiped then
				equiped:setVisible(InfoEquip.getEquipedHero(info) ~= nil)
			end

			local locker = self:getComponentByTag("locker")

			locker:setVisible(info.locked == 1)

			local illusion = self:getComponentByTag("illusion")

			illusion:setVisible(not empty(info.illusion))

			if self:getFlagByTag("flag_enhance") and info.enhance_level and info.enhance_level > 0 then
				if global.compareBase then
					self:createLabelOnFlag("flag_enhance", "+0")
				else
					local style = nil

					if info.suit_excellent and info.suit_excellent > 0 then
						style = {
							color = Style.fontSuit
						}
					end

					self:createLabelOnFlag("flag_enhance", "+" .. info.enhance_level, style)
				end
			end

			if self:getFlagByTag("flag_name") then
				local names, styles = InfoEquip.getNameDisplay(info)

				self:createLabelGroupOnFlag("flag_name", names, styles, {
					align = Style.center
				})
				ManagerInfo.onDataChange(self, "equip", info.id, function (data)
					self:setDrop(_type, InfoEquip.getInfo(info.id), true)
				end)
			end

			if self:getFlagByTag("flag_gem_1") then
				local centerX = self:getFlagByTag("flag_gem_2").originalX
				local spaceX = self:getFlagByTag("flag_gem_2").originalX - self:getFlagByTag("flag_gem_1").originalX

				for i = 1, info.slot do
					local flag = self:getFlagByTag("flag_gem_" .. i)
					flag.x = centerX - (info.slot - 1) / 2 * spaceX + (i - 1) * spaceX

					if info["gem" .. i] ~= 0 then
						self:createIconOnFlag("flag_gem_" .. i, IconManager.getMiscIcon("gem"))
					else
						self:createIconOnFlag("flag_gem_" .. i, IconManager.getMiscIcon("gem_empty"))
					end
				end
			end
		elseif bg then
			bg:setColor(cc.c3b(150, 150, 150))
		end
	elseif _type == DropManager.TYPE.SKILL then
		if empty(info) then
			return
		end

		local baseID = nil

		if type(info) == "table" then
			baseID = info.base_id or info.id or info.data.id
		else
			baseID = info
		end

		if empty(baseID) then
			return
		end

		if self:getFlagByTag("flag_name") then
			local skillData = CsvParser.getCsvData("skill", baseID)

			self:createLabelOnFlag("flag_name", skillData.name)
		end

		self.icon = self:createIconOnFlag("flag_icon", IconManager.getSkillIcon(baseID), 100, true)
	elseif _type == DropManager.TYPE.HERO then
		if self:getFlagByTag("flag_name") then
			self:createLabelOnFlag("flag_name", info.name)
		end

		local bg = self:getComponentByTag("bg")

		if param == "big" then
			local mugshotRect = self:getRectByFlag("flag_icon")
			local scale = math.floor(mugshotRect.width / 25 * 10) / 10 * 0.7
			local portrait = PortraitManager.getHeroMugshot(info, mugshotRect, scale, 0, cc.p(0, 12), nil, , InfoEquip.getDisplayListOnHero(info))

			portrait:setPosition(mugshotRect.x + mugshotRect.width / 2, mugshotRect.y + mugshotRect.height / 2)
			self:addChild(portrait, 100)
			self:setComponentToTag("flag_icon", portrait)

			self.icon = portrait

			bg:setColor(cc.c3b(150, 150, 150))
		else
			local mugshotRect = self:getRectByFlag("flag_icon")
			local scale = math.floor(mugshotRect.width / 25 * 10) / 10
			local portrait = PortraitManager.getHeroMugshot(info, mugshotRect, scale, 0, cc.p(0, 0), nil, , InfoEquip.getDisplayListOnHero(info))

			portrait:setPosition(mugshotRect.x + mugshotRect.width / 2, mugshotRect.y + mugshotRect.height / 2)
			self:addChild(portrait, 100)
			self:setComponentToTag("flag_icon", portrait)

			self.icon = portrait
		end

		if (type(param) ~= "table" or not param.no_level) and self:getFlagByTag("flag_hero_level") then
			local exp, expUpg, level, maxLevel, displayLevel, displayMaxLevel = InfoHero.getExp(info)

			self:createLabelOnFlag("flag_hero_level", displayLevel)
		end

		local quality = self:getComponentByTag("quality")
		local qualityColor = nil

		if quality then
			qualityColor = InfoHero.getQualityColor(InfoHero.getQuality(info))

			quality:setVisible(true)
			quality:setColor(qualityColor)
		end

		local qualityBorder = self:getComponentByTag("quality_border")

		if qualityBorder then
			qualityBorder:setVisible(true)
			qualityBorder:setColor(qualityColor or InfoHero.getQualityColor(InfoHero.getQuality(info)))
		end

		local heroBorder = self:getComponentByTag("hero_border")

		if heroBorder then
			heroBorder:setVisible(true)
			heroBorder:setColor(qualityColor or InfoHero.getQualityColor(InfoHero.getQuality(info)))
		end

		if self:getFlagByTag("flag_skill") then
			local heroCSV = CsvParser.getCsvData("hero", info.base_id)

			if heroCSV and not empty(heroCSV.skill_id) then
				self:createIconOnFlag("flag_skill", IconManager.getSkillIcon(heroCSV.skill_id), 900, true)

				local skillBorder = self:getComponentByTag("skill_border")

				if skillBorder then
					skillBorder:setVisible(true)
					skillBorder:setLocalZOrder(1000)
				end
			end
		end

		if type(param) ~= "table" or not param.no_star then
			local star = self:getComponentByTag("star")

			if star then
				local spaceX = 12

				if star.labelStyle then
					spaceX = star.labelStyle.size
				end

				local starType, starNum = InfoHero.getStar(info)

				UIUtil.createStar(self, "star", starNum, spaceX, 0, Style.center, starType == InfoHero.STAR_TYPE.PEAK and 4 or 1, spaceX / 16, 200)
			end
		end

		local locker = self:getComponentByTag("locker")

		if locker then
			locker:setVisible(info.locked == 1)
		end
	elseif _type == DropManager.TYPE.GWAR_HERO then
		if self:getFlagByTag("flag_name") then
			self:createLabelOnFlag("flag_name", info.name)
		end

		local bg = self:getComponentByTag("bg")
		local mugshotRect = self:getRectByFlag("flag_icon")
		local scale = math.floor(mugshotRect.width / 25 * 10) / 10
		local portrait = PortraitManager.getHeroGwarMugshot(info, mugshotRect, scale, 0, cc.p(0, 0))

		portrait:setPosition(mugshotRect.x + mugshotRect.width / 2, mugshotRect.y + mugshotRect.height / 2)
		self:addChild(portrait, 100)
		self:setComponentToTag("flag_icon", portrait)

		self.icon = portrait
		local quality = self:getComponentByTag("quality")
		local qualityColor = nil

		if quality then
			qualityColor = InfoHero.getQualityColor(InfoHero.getQuality(info))

			quality:setVisible(true)
			quality:setColor(qualityColor)
		end

		local qualityBorder = self:getComponentByTag("quality_border")

		if qualityBorder then
			qualityBorder:setVisible(true)
			qualityBorder:setColor(qualityColor or InfoHero.getQualityColor(InfoHero.getQuality(info)))
		end

		local heroBorder = self:getComponentByTag("hero_border")

		if heroBorder then
			heroBorder:setVisible(true)
			heroBorder:setColor(qualityColor or InfoHero.getQualityColor(InfoHero.getQuality(info)))
		end

		if (type(param) ~= "table" or not param.no_level) and self:getFlagByTag("flag_hero_level") then
			local exp, expUpg, level, maxLevel, displayLevel, displayMaxLevel = InfoHero.getExp(info)

			self:createLabelOnFlag("flag_hero_level", displayLevel)
		end

		if type(param) ~= "table" or not param.no_star then
			local star = self:getComponentByTag("star")

			if star then
				local spaceX = 12

				if star.labelStyle then
					spaceX = star.labelStyle.size
				end

				local starType, starNum = InfoHero.getStar(info)

				UIUtil.createStar(self, "star", starNum, spaceX, 0, Style.center, starType == InfoHero.STAR_TYPE.PEAK and 4 or 1, spaceX / 16, 200)
			end
		end
	elseif _type == DropManager.TYPE.PET then
		local petData = CsvParser.getCsvData("pet", info.base_id)

		if self:getFlagByTag("flag_name") then
			self:createLabelOnFlag("flag_name", petData.name)
		end

		local bg = self:getComponentByTag("bg")

		if param == "big" then
			local mugshotRect = self:getRectByFlag("flag_icon")
			local scale = math.floor(mugshotRect.width / 25 * 10) / 10 * 0.6
			local portrait = PortraitManager.getPetMugshot(info.base_id, mugshotRect, scale, 0, cc.p(0, 10))

			portrait:setPosition(mugshotRect.x + mugshotRect.width / 2, mugshotRect.y + mugshotRect.height / 2)
			self:addChild(portrait, 100)
			self:setComponentToTag("flag_icon", portrait)

			self.icon = portrait

			bg:setColor(cc.c3b(150, 150, 150))
		else
			local mugshotRect = self:getRectByFlag("flag_icon")
			local scale = math.floor(mugshotRect.width / 25 * 10) / 10 * 0.8
			local portrait = PortraitManager.getPetMugshot(info.base_id, mugshotRect, scale, 0, cc.p(0, 0))

			portrait:setPosition(mugshotRect.x + mugshotRect.width / 2, mugshotRect.y + mugshotRect.height / 2)
			self:addChild(portrait, 100)
			self:setComponentToTag("flag_icon", portrait)

			self.icon = portrait
		end

		if (type(param) ~= "table" or not param.no_level) and self:getFlagByTag("flag_hero_level") then
			local exp, expUpg, level, maxLevel, displayLevel, displayMaxLevel = InfoPet.getExp(info)

			self:createLabelOnFlag("flag_hero_level", displayLevel)
		end

		local quality = self:getComponentByTag("quality")
		local qualityColor = nil

		if quality then
			qualityColor = InfoHero.getQualityColor(info.quality)

			quality:setVisible(true)
			quality:setColor(qualityColor)
		end

		local qualityBorder = self:getComponentByTag("quality_border")

		if qualityBorder then
			qualityBorder:setVisible(true)
			qualityBorder:setColor(qualityColor or InfoHero.getQualityColor(info.quality))
		end

		if type(param) ~= "table" or not param.no_star then
			local star = self:getComponentByTag("star")

			if star then
				local spaceX = 12

				if star.labelStyle then
					spaceX = star.labelStyle.size
				end

				local starType, starNum = InfoPet.getStar(info)

				UIUtil.createStar(self, "star", starNum, spaceX, 0, Style.center, starType == InfoHero.STAR_TYPE.PEAK and 4 or 1, spaceX / 16, 200)
			end
		end

		local locker = self:getComponentByTag("locker")

		if locker then
			locker:setVisible(info.locked == 1)
		end
	elseif _type == DropManager.TYPE.MONSTER then
		local monsterData = CsvParser.getCsvData("monster", info.base_id)

		if self:getFlagByTag("flag_name") then
			self:createLabelOnFlag("flag_name", monsterData.name)
		end

		local mugshotRect = self:getRectByFlag("flag_icon")
		local portrait = PortraitManager.getMonsterMugshot(monsterData.id, mugshotRect, 3, 0, cc.p(0, 0))

		portrait:setPosition(mugshotRect.x + mugshotRect.width / 2, mugshotRect.y + mugshotRect.height / 2)
		self:addChild(portrait, 100)
		self:setComponentToTag("flag_icon", portrait)

		self.icon = portrait
		local quality = self:getComponentByTag("quality")
		local qualityColor = nil

		if quality then
			qualityColor = InfoHero.getQualityColor(InfoManualMonster.getQuality(info.class or monsterData.class))

			quality:setVisible(true)
			quality:setColor(qualityColor)
		end

		local qualityBorder = self:getComponentByTag("quality_border")

		if qualityBorder then
			qualityBorder:setVisible(true)
			qualityBorder:setColor(qualityColor or InfoHero.getQualityColor(InfoManualMonster.getQuality(info.class or monsterData.class)))
		end
	elseif _type == DropManager.TYPE.BUFF then
		local buffData = CsvParser.getCsvData("buff", info.id)
		local quality = self:getComponentByTag("quality")
		local qualityColor = nil

		if quality then
			local buffQuality = buffData.quality

			if empty(buffQuality) then
				buffQuality = 0
			end

			qualityColor = InfoHero.getQualityColor(buffQuality)

			quality:setVisible(true)
			quality:setColor(qualityColor)
		end

		local qualityBorder = self:getComponentByTag("quality_border")

		if qualityBorder then
			qualityBorder:setVisible(true)

			local buffQuality = buffData.quality

			if empty(buffQuality) then
				buffQuality = 0
			end

			qualityBorder:setColor(qualityColor or InfoHero.getQualityColor(buffQuality))
		end

		self.icon = self:createIconOnFlag("flag_icon", IconManager.getBuffIcon(info.id), 100, true)
	elseif _type == DropManager.TYPE.UNION_BUFF then
		local buffData = CsvParser.getCsvData("union_buff", info.id)
		local quality = self:getComponentByTag("quality")
		local qualityColor = nil

		if quality then
			local buffQuality = buffData.quality

			if empty(buffQuality) then
				buffQuality = 0
			end

			qualityColor = InfoHero.getQualityColor(buffQuality)

			quality:setVisible(true)
			quality:setColor(qualityColor)
		end

		local qualityBorder = self:getComponentByTag("quality_border")

		if qualityBorder then
			qualityBorder:setVisible(true)

			local buffQuality = buffData.quality

			if empty(buffQuality) then
				buffQuality = 0
			end

			qualityBorder:setColor(qualityColor or InfoHero.getQualityColor(buffQuality))
		end

		self.icon = self:createIconOnFlag("flag_icon", IconManager.getUnionBuffIcon(info.id), 100, true)
	elseif _type == DropManager.TYPE.GWAR_BUFF then
		local buffData = CsvParser.getCsvData("union_battle_buff", info.id)
		local quality = self:getComponentByTag("quality")
		local qualityColor = nil

		if quality then
			local buffQuality = buffData.quality

			if empty(buffQuality) then
				buffQuality = 0
			end

			qualityColor = InfoHero.getQualityColor(buffQuality)

			quality:setVisible(true)
			quality:setColor(qualityColor)
		end

		local qualityBorder = self:getComponentByTag("quality_border")

		if qualityBorder then
			qualityBorder:setVisible(true)

			local buffQuality = buffData.quality

			if empty(buffQuality) then
				buffQuality = 0
			end

			qualityBorder:setColor(qualityColor or InfoHero.getQualityColor(buffQuality))
		end

		self.icon = self:createIconOnFlag("flag_icon", IconManager.getBuffIconPic(buffData.pic), 100, true)
	elseif _type == DropManager.TYPE.MODAO then
		if empty(info) then
			return
		end

		local baseID = nil

		if type(info) == "table" then
			baseID = info.base_id or info.id or info.data.id
		else
			baseID = info
		end

		if empty(baseID) then
			return
		end

		local modaoSkillCSV = CsvParser.getCsvData("modao_skill", baseID)

		if self:getFlagByTag("flag_name") then
			self:createLabelOnFlag("flag_name", modaoSkillCSV.name)
		end

		self.icon = self:createIconOnFlag("flag_icon", IconManager.getSkillIcon(modaoSkillCSV.skill_id), 100, true)
	elseif _type == DropManager.TYPE.CARD then
		if empty(info) then
			return
		end

		local cardCSV = CsvParser.getCsvData("card", info.base_id)

		if self:getFlagByTag("flag_name") then
			self:createLabelOnFlag("flag_name", cardCSV.name)
		end

		local equiped = self:getComponentByTag("equiped")

		if equiped then
			equiped:setVisible(InfoCard.getEquipedHero(info) ~= nil)
		end

		self.icon = self:createIconOnFlag("flag_icon", IconManager.getCardIcon(cardCSV.id), 100, true)
		local locker = self:getComponentByTag("locker")

		locker:setVisible(info.locked == 1)

		local qualityBorder = self:getComponentByTag("quality_border")

		if qualityBorder then
			qualityBorder:setVisible(true)
			qualityBorder:setColor(qualityColor or InfoHero.getQualityColor(cardCSV.quality))
		end

		if info.level and self:getFlagByTag("flag_level") then
			self:createLabelOnFlag("flag_level", info.level)
		end

		local bg = self:getComponentByTag("bg")

		if bg then
			if info.saved == 0 then
				bg:setFrame(2)
			else
				bg:setFrame(1)
			end
		end

		if info.star then
			local star = self:getComponentByTag("star")

			if star then
				self:refreshStars(info.star)
			end
		end
	elseif _type == DropManager.TYPE.SIGIL then
		if empty(info) then
			return
		end

		local sigilCSV = CsvParser.getCsvData("sigil", info.base_id)

		if self:getFlagByTag("flag_name") then
			self:createLabelOnFlag("flag_name", sigilCSV.name)
		end

		local equiped = self:getComponentByTag("equiped")

		if equiped then
			equiped:setVisible(InfoSigil.getEquipedHero(info) ~= nil)
		end

		local pic = nil

		if param and param.inDisk then
			pic = IconManager.getHeroIcon(sigilCSV.pic)
		else
			pic = IconManager.getItemPic(sigilCSV.pic)
		end

		self.icon = self:createIconOnFlag("flag_icon", pic, 100, true)
		local locker = self:getComponentByTag("locker")

		if locker then
			locker:setVisible(info.locked == 1)
		end

		local qualityBorder = self:getComponentByTag("quality_border")

		if qualityBorder then
			qualityBorder:setVisible(true)
			qualityBorder:setColor(InfoHero.getQualityColor(info.quality))
		end

		if info.level and self:getFlagByTag("flag_level") then
			self:createLabelOnFlag("flag_level", info.level)
		end

		local bg = self:getComponentByTag("bg")

		if bg then
			if info.saved == 0 then
				bg:setFrame(2)
			else
				bg:setFrame(1)
			end
		end
	elseif _type == DropManager.TYPE.ARTIFACT then
		if empty(info) then
			return
		end

		local artifactCSV = CsvParser.getCsvData("artifact", info.base_id)

		if self:getFlagByTag("flag_name") then
			self:createLabelOnFlag("flag_name", artifactCSV.name)
		end

		local equiped = self:getComponentByTag("equiped")

		if equiped then
			equiped:setVisible(InfoArtifact.getEquipedHero(info) ~= nil)
		end

		local pic = nil

		if info.star and artifactCSV.unlock_star <= info.star then
			pic = IconManager.getArtifactIcon(artifactCSV.pic_2)
		else
			pic = IconManager.getArtifactIcon(artifactCSV.pic_1)
		end

		self.icon = self:createIconOnFlag("flag_icon", pic, 100, true)
		local locker = self:getComponentByTag("locker")

		if locker then
			locker:setVisible(info.locked == 1)
		end

		local qualityBorder = self:getComponentByTag("quality_border")

		if qualityBorder then
			qualityBorder:setVisible(true)
			qualityBorder:setColor(InfoHero.getQualityColor(artifactCSV.quality))
		end

		if info.level and self:getFlagByTag("flag_level") then
			self:createLabelOnFlag("flag_level", info.level)
		end

		local bg = self:getComponentByTag("bg")

		if bg then
			if info.saved == 0 then
				bg:setFrame(2)
			else
				bg:setFrame(1)
			end
		end

		if info.star then
			local star = self:getComponentByTag("star")

			if star then
				local spaceX = 12

				if star.labelStyle then
					spaceX = star.labelStyle.size
				end

				local starType, starNum = InfoArtifact.getStar(info)

				UIUtil.createStar(self, "star", starNum, spaceX, 0, Style.center, starType == 2 and 4 or 1, spaceX / 16, 200)
			end
		end

		if InfoArtifact.checkHeroSkill(info) then
			local flag = self:getFlagByTag("flag_icon")

			if flag then
				local spineName = "artifact_slot"
				local skeletons = SpineHelper.createUI(spineName)

				for i, skeleton in ipairs(skeletons) do
					self:addChild(skeleton, skeleton.layer + 100)
					skeleton:setScale(skeleton.scale * flag.width / 90)
					skeleton:setPosition(flag.x + flag.width / 2, flag.y + flag.width / 2)
				end

				self.iconSkeletons = skeletons
			end
		end
	elseif _type == DropManager.TYPE.MIRROR then
		if empty(info) then
			return
		end

		local baseID = nil

		if type(info) == "table" then
			baseID = info.id
		else
			baseID = info
		end

		if empty(baseID) then
			return
		end

		local mirrorCSV = CsvParser.getCsvData("mirror_skill", baseID)

		if self:getFlagByTag("flag_name") then
			self:createLabelOnFlag("flag_name", mirrorCSV.name)
		end

		self.icon = self:createIconOnFlag("flag_icon", IconManager.getMirrorIcon(mirrorCSV.id), 100, true)
	elseif _type == DropManager.TYPE.EMOJI then
		if empty(info) then
			return
		end

		self.effect = Effect.new()

		self:addChild(self.effect, 100)

		local flag = self:getFlagByTag("flag_icon")

		self.effect:setPosition(flag.x + flag.width / 2, flag.y + 9)
		self.effect:rawSetScale(1.75)
		self.effect:load(info.model)
	end
end

function DropSlot:clearDrop()
	self:removeIconOnFlag("flag_icon")
	self:removeLabelOnFlag("flag_num")
	self:removeLabelOnFlag("flag_num_1")
	self:removeLabelOnFlag("flag_enhance")
	self:removeLabelOnFlag("flag_level")
	self:removeLabelOnFlag("flag_name")
	self:removeLabelOnFlag("flag_hero_level")

	local quality = self:getComponentByTag("quality")

	if quality then
		quality:setVisible(false)
	end

	local equiped = self:getComponentByTag("equiped")

	if equiped then
		equiped:setVisible(false)
	end

	local qualityBorder = self:getComponentByTag("quality_border")

	if qualityBorder then
		qualityBorder:setColor(Style.white)
	end

	local selected = self:getComponentByTag("selected")

	if selected then
		selected:setVisible(false)
	end

	local bg = self:getComponentByTag("bg")

	if bg then
		bg:setFrame(1)
	end

	for i = 1, GameConfig.equip_gem_max do
		self:removeIconOnFlag("flag_gem_" .. i)
	end

	if self:getFlagByTag("flag_skill") then
		self:removeIconOnFlag("flag_skill")
	end

	local skillBorder = self:getComponentByTag("skill_border")

	if skillBorder then
		skillBorder:setVisible(false)
	end

	local heroBorder = self:getComponentByTag("hero_border")

	if heroBorder then
		heroBorder:setColor(Style.white)
		heroBorder:setVisible(false)
	end

	self:refreshStars(0)

	local locker = self:getComponentByTag("locker")

	if locker then
		locker:setVisible(false)
	end

	local illusion = self:getComponentByTag("illusion")

	if illusion then
		illusion:setVisible(false)
	end

	if self.effect then
		self.effect:removeSelf()

		self.effect = nil
	end

	local ex_border = self:getComponentByTag("ex_border")

	if ex_border then
		ex_border:setVisible(false)
	end

	if self.iconSkeletons then
		for i, skeleton in ipairs(self.iconSkeletons) do
			skeleton:removeSelf()
		end

		self.iconSkeletons = nil
	end

	self.type = nil
	self.info = nil
end

function DropSlot:toTouchable(isTouchAnime)
	local bg = self:getComponentByTag("bg")

	bg:toTouchable(isTouchAnime)
end

function DropSlot:setTapGroup(groupName)
	local bg = self:getComponentByTag("bg")

	bg:setTapGroup(groupName)
end

function DropSlot:addTap(handler)
	local bg = self:getComponentByTag("bg")

	bg:setTapGroup("slot_click", self)

	if self.draggable then
		local function onTouch(event, x, y)
			if event == "began" then
				local selfX, selfY = self:getPosition()

				if self._touchStartRect then
					selfX = self._touchStartRect.x
					selfY = self._touchStartRect.y
				end

				self.drag = {
					isTap = true,
					speed = 0,
					startZorder = self:getLocalZOrder(),
					startViewX = selfX,
					startViewY = selfY,
					startX = x,
					startY = y,
					preX = x,
					preY = y,
					preTime = socket.gettime()
				}
			elseif event == "moved" then
				if (not self.checkDragFunc or self.checkDragFunc()) and self.drag.isTap and (self.dragThreshold <= math.abs(x - self.drag.startX) or self.dragThreshold <= math.abs(y - self.drag.startY)) then
					self.drag.isTap = false

					if self.dragStartHandler then
						self.dragStartHandler(x, y)
					end
				end

				if not self.drag.isTap then
					self:setPosition(self.drag.startViewX + x - self.drag.startX, self.drag.startViewY + y - self.drag.startY)
					self:setLocalZOrder(self.drag.startZorder + 100)

					if self.dragMovedHandler then
						self.dragMovedHandler(x, y)
					end
				end
			elseif event == "ended" then
				if self.drag.isTap then
					if handler then
						handler(x, y)
					end
				else
					self:setLocalZOrder(self.drag.startZorder)
					transition.stopTarget(self)

					self.afterPick = {
						x = self.drag.startViewX,
						y = self.drag.startViewY
					}

					transition.moveTo(self, {
						time = 0.2,
						easing = "sineOut",
						x = self.drag.startViewX,
						y = self.drag.startViewY,
						onComplete = function ()
							self.afterPick = nil
						end
					})

					if self.dragOverHandler then
						self.dragOverHandler(x, y)
					end
				end
			end
		end

		bg:addTouch(onTouch)
	else
		bg:addTap(handler)
	end
end

function DropSlot:addTouch(handler)
	local bg = self:getComponentByTag("bg")

	bg:addTouch(handler)
end

function DropSlot:setDrag(dragStartHandler, dragMovedHandler, dragOverHandler, checkDragFunc)
	self.dragThreshold = 20
	self.checkDragFunc = checkDragFunc
	self.draggable = true
	self.dragStartHandler = dragStartHandler
	self.dragMovedHandler = dragMovedHandler
	self.dragOverHandler = dragOverHandler
end

function DropSlot:stopDragAnimation(isHide)
	if self.afterPick then
		transition.stopTarget(self)
		self:setPosition(self.afterPick.x, self.afterPick.y)
		self:setVisible(not isHide)

		self.afterPick = nil
	end
end

function DropSlot:setDetailEnabled(enabled)
	self.detailEnabled = enabled
	local bg = self:getComponentByTag("bg")

	if self.detailEnabled then
		bg:toTouchable()
		bg:setTapGroup("slot_click", self)
		bg:addTap(function ()
			DropManager.popDetail(self.type, self.info)
		end)
	else
		bg:removeTouchable()
	end
end

function DropSlot:setSelected(_selected)
	local selected = self:getComponentByTag("selected")

	if selected then
		selected:setVisible(_selected)
	end
end

function DropSlot:setAlwaysShowNumber(b)
	self.alwaysShowNumber = b

	if self.type == DropManager.TYPE.ITEM then
		if self.info.num and (self.info.num > 1 or self.alwaysShowNumber) then
			self:createLabelOnFlag("flag_num", self.info.num)
		else
			self:removeLabelOnFlag("flag_num")
		end
	elseif self.type == DropManager.TYPE.EQUIP then
		if self.info.num and (self.info.num > 1 or self.alwaysShowNumber) then
			self:createLabelOnFlag("flag_num", self.info.num)
		else
			self:removeLabelOnFlag("flag_num")
		end
	end
end

function DropSlot:setNum(num)
	self:createLabelOnFlag("flag_num", num)
end

function DropSlot:clearNum()
	self:removeLabelOnFlag("flag_num")
end

function DropSlot:setQuality(_quality)
	local quality = self:getComponentByTag("quality")
	local qualityColor = nil

	if quality then
		qualityColor = InfoHero.getQualityColor(_quality)

		quality:setVisible(true)
		quality:setColor(qualityColor)
	end

	local qualityBorder = self:getComponentByTag("quality_border")

	if qualityBorder then
		qualityBorder:setVisible(true)
		qualityBorder:setColor(qualityColor or InfoHero.getQualityColor(_quality))
	end
end

return DropSlot
