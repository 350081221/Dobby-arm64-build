local NAV_base = import(".NAV_base")
local NAV_union_buff = class("NAV_union_buff", NAV_base)

function NAV_union_buff.open(npc)
	local ui = NAV_union_buff.new(npc)

	return ui
end

function NAV_union_buff:ctor(npc)
	NAV_union_buff.super.ctor(self, npc, "nav_union_buff")
end

function NAV_union_buff:init()
	NAV_union_buff.super.init(self)
	self:refresh()
	ManagerInfo.onDataChange(self, "union", nil, function ()
		self:refresh()
	end)
end

function NAV_union_buff:refresh()
	local index = 3

	if InfoUnion.checkPower("lvup_building") then
		self:setButtonVisible(index, true)
		self:setBuildingLvupIndex(index, true)
	else
		self:setButtonVisible(index, false)
	end
end

function NAV_union_buff:onTap(index)
	NAV_union_buff.super.onTap(self, index)

	if index == 1 then
		FRAME_union_buff.open(self.npc)
	elseif index == 2 then
		local arr, alreadyCount, openCount = InfoUnion.getBuffList()

		if alreadyCount > 0 then
			FRAME_union_buff_open.open(self.npc)
		else
			Alert.open(Localization.getSrcText("请先使用研究功能"))
		end
	end
end

return NAV_union_buff
