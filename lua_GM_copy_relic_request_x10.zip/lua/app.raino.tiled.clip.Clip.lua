local MapFrameManager = import("..map.MapFrameManager")
local Clip = class("Clip", function ()
	local node = display.newNode()

	return node
end)
CLIP_TYPE = {
	SPINE = 3,
	PIC = 2,
	MODEL = 1
}
Clip.CLIP_TYPE = CLIP_TYPE
Clip.loadedModel = {}

function Clip.clear()
	Clip.loadedModel = {}
end

function Clip.getModelSnapShot(modelName, action, direction, frame)
	local modelData = Clip.loadModel(modelName)
	action = action or "idle"
	direction = direction or 1
	frame = frame or 1

	for curAction, grid in pairs(modelData.stack) do
		if curAction == action then
			for i = 1, #grid do
				if i == direction then
					for j = 1, #grid[i] do
						if j == frame then
							return grid[i][j]
						end
					end
				end
			end
		end
	end
end

function Clip.loadModel(modelName)
	if Clip.loadedModel[modelName] == nil then
		local texture = getFinalRes("res/model/" .. modelName .. "/texture.png")
		local plist = getFinalRes("res/model/" .. modelName .. "/texture.plist")

		display.addSpriteFrames(plist, texture)

		local modelData = JsonParser.parse("res/model/" .. modelName .. "/model_data.json")
		Clip.loadedModel[modelName] = modelData
	end

	return Clip.loadedModel[modelName]
end

function Clip:ctor()
	self:setCascadeColorEnabled(true)
	self:setCascadeOpacityEnabled(true)
	event_listener.extendMethods(self, true)

	self.bmp = display.newSprite()

	self:addChild(self.bmp)

	self.action = "idle"
	self.frame = 1
	self.playCount = 0
	self.playSkip = 2
	self.angle = 0
	self.topType = 1
	self.loopFrame = 1
	self.rotate = false
	self.one = false
	self.yoff = 0
	self.allOneDirection = true
	self.scale = 1
	self.exScale = 1
	self.paused = false
	self.syncFrame = false
	self.syncFrameOffset = 0
	self.z = 0
	self.mappedAction = {}
	self.actionSkip = {}
	self.lastFrame = {}
	self.shadowScale = 1
end

function Clip:loadSpine(spineName)
	self.clipType = CLIP_TYPE.SPINE
	self.spineName = spineName
	local data = JsonParser.parse("res/spine_set/" .. spineName .. ".json")

	if not data then
		Log.debug("Clip:loadSpine 不存在", spineName)
	end

	self.light = {
		selfLight = data.selfLight or 0,
		light = data.light or 0,
		radius = data.lightRadius or 0,
		rgb = ColorUtil.getC3B(data.lightRGB)
	}
	self.width = data.width or 0
	self.height = data.height or 0
	self.originalWidth = self.width
	self.originalHeight = self.height
	self.spineData = data
end

function Clip:loadPic(url)
	self.clipType = CLIP_TYPE.PIC
	self.modelName = url
	self.isPic = true

	self.bmp:removeSelf()

	self.bmp = display.newSprite(url)

	self:addChild(self.bmp)
	self.bmp:setAnchorPoint(cc.p(0.5, 0))

	local size = self.bmp:getContentSize()
	self.originalWidth = size.width
	self.originalHeight = size.height
	self.width = self.originalWidth * self.scale
	self.height = self.originalHeight * self.scale
	self.isShadow = true
	self.light = {
		light = 0,
		radius = 0,
		selfLight = 0,
		rgb = cc.c3b(255, 255, 255)
	}
	self.yoff = 0
	self.layer = 1
	self.rotate = 0
	self.portraitInfo = {
		mirror = 1,
		scale = 1,
		x = 0,
		y = -self.height / 2
	}
end

function Clip:load(modelName)
	self.modelName = modelName

	if string.sub(modelName, 1, 1) == "@" then
		local spineName = string.sub(modelName, 2)

		self:loadSpine(spineName)

		return
	end

	self.clipType = CLIP_TYPE.MODEL
	local modelData = Clip.loadModel(modelName)

	assert(modelData ~= nil, "NO MODEL name:" .. modelName)

	local widthArray = {}
	local heightArray = {}
	self.frameStack = {}
	self.rectStack = {}

	for action, grid in pairs(modelData.stack) do
		if #grid > 1 then
			self.allOneDirection = false
		end

		self.frameStack[action] = {}
		self.rectStack[action] = {}

		for i = 1, #grid do
			self.frameStack[action][i] = {}
			self.rectStack[action][i] = {}

			for j = 1, #grid[i] do
				self.frameStack[action][i][j] = display.newSpriteFrame(grid[i][j])
				local rect = modelData.rectStack[action][i][j]

				if action == "idle" or modelData.stack.idle == nil then
					table.insert(widthArray, rect[3])
					table.insert(heightArray, -rect[2])
				end

				local rectX = -rect[1]
				local rectY = rect[2]
				rectY = rect[4] / 2 * 3 + rectY
				self.rectStack[action][i][j] = {
					x = rectX,
					y = rectY,
					width = rect[3],
					height = rect[4]
				}
			end
		end
	end

	self.vaction = modelData.vaction
	self.originalWidth = average.harmonic(widthArray)
	self.originalHeight = average.harmonic(heightArray) - modelData.yoff
	self.width = self.originalWidth * self.scale
	self.height = self.originalHeight * self.scale
	self.isShadow = modelData.shadow
	self.light = {
		selfLight = modelData.selfLight or 0,
		light = modelData.light or 0,
		radius = modelData.lightRadius or 0,
		rgb = ColorUtil.getC3B(modelData.lightRGB)
	}
	self.avatarInfo = modelData.avatar
	self.portraitInfo = json.decode(modelData.portraitInfo) or {
		mirror = 0,
		scale = 1,
		x = 0,
		y = -self.height / 2
	}
	local param = ConfParser.parse(modelData.paramInfo)

	if param.actionSkip then
		self.actionSkip = param.actionSkip
	end

	if param.shadow_scale then
		self.shadowScale = param.shadow_scale
	end

	if param.no_hurt_color then
		self.noHurtColor = param.no_hurt_color
	end

	if param.battle_height then
		self.battleHeight = param.battle_height
	end

	if param.lastFrame then
		self.lastFrame = param.lastFrame
	end

	if param.flatten then
		self:setScaleY(param.flatten)
	end

	if param.rotate_offset then
		self.rotateOffset = param.rotate_offset
	end

	if param.rotate_random then
		local arr1 = string.split(param.rotate_random, ",")
		local str1 = arr1[math.random(1, #arr1)]
		local arr2 = string.split(str1, "-")
		self.rotateOffset = tonumber(arr2[1]) + math.random() * (tonumber(arr2[2]) - tonumber(arr2[1]))

		self:setRotate(0)
	end

	if param.auto_rotate then
		self.autoRotateValue = math.random(0, 359)
		self.autoRotate = param.auto_rotate
	end

	if param.alpha then
		self:setOpacity(math.floor(param.alpha * 255))
	end

	if param.overhead == 1 then
		self.overhead = true
	end

	if param.zorder_offset then
		self.zorderOffset = param.zorder_offset
	end

	self.param = param
	self.yoff = modelData.yoff
	self.playSkip = modelData.playSkip * 2
	self.loopFrame = modelData.loop + 1
	self.layer = modelData.layer
	self.rotate = modelData.rotate
	self.one = modelData.one

	if not self.isSelfUpdate then
		MapFrameManager.startLoop(self, self.playLoop)
		self:playLoop(0, 0, 1)
	end
end

function Clip:setBlendFunc(srcBlend, dstBlend)
	self.bmp:setBlendFunc(srcBlend, dstBlend)
end

function Clip:setSelfUpdateFreeze(isFreeze)
	self.selfUpdateFreeze = isFreeze
end

function Clip:selfUpdate()
	MapFrameManager.stopLoop(self, self.playLoop)

	self.updateFrame = 0
	self.isSelfUpdate = true

	self:addNodeEventListener(cc.NODE_ENTER_FRAME_EVENT, function (elapsed_time)
		if self.selfUpdateFreeze then
			return
		end

		local frameSpeed = 60 * elapsed_time
		frameSpeed = math.min(frameSpeed, 5)
		local preFrame = self.updateFrame
		self.updateFrame = self.updateFrame + frameSpeed
		local frame = self.updateFrame
		local passed = frameSpeed
		local sharp = math.floor(frame) - math.floor(preFrame)

		self:playLoop(frame, passed, sharp)
	end)
	self:scheduleUpdate()
end

function Clip:hasAction(action)
	return self.frameStack and self.frameStack[action] ~= nil
end

function Clip:removeMappedAction(action)
	self.mappedAction[action] = nil
end

function Clip:setMappedAction(action, toAction)
	self.mappedAction[action] = toAction
end

function Clip:getMappedAction(action)
	local mapped = self.mappedAction[action]

	if mapped and self:hasAction(mapped) then
		return mapped
	else
		return action
	end
end

function Clip:setFixedAction(action)
	self.fixedAction = action

	self:forceAction(action)
end

function Clip:setAngle(angle)
	self.angle = angle
	local direction = self:getDirection()
	local totalFrame = self:getTotalFrame(direction)

	self:setFrame(self.action, direction, math.min(totalFrame, self.frame))
end

function Clip:setAngleMirror(isForce)
	if isForce then
		self.isAngleMirror = true
	else
		self.isAngleMirror = nil
	end
end

function Clip:setAction(action, loop, overFunc, startFrame)
	action = self:getMappedAction(action)

	if self.fixedAction then
		action = self.fixedAction
	end

	if self.frameStack == nil or self.frameStack[action] == nil and (not self.vaction or self.vaction[action] == nil) then
		action = "idle"
	end

	local direction = self:getDirection()
	local totalFrame = self:getTotalFrame(direction)

	if self.action ~= action or loop ~= nil then
		self.frame = 1
		self.playCount = self:getPlaySkip(action, self.frame == totalFrame)
	end

	if startFrame then
		self.frame = startFrame
		self.playCount = self:getPlaySkip(action, self.frame == totalFrame)
	end

	self.action = action
	self.actionLoop = loop
	self.actionOverFunc = overFunc
	local direction = self:getDirection()

	self:setFrame(self.action, direction, math.min(totalFrame, self.frame))
end

function Clip:forceAction(action, frame, angle)
	if angle then
		self.angle = angle
	end

	if frame then
		self.frame = frame
	end

	local direction = self:getDirection()
	local totalFrame = self:getTotalFrame(direction)

	self:setFrame(action or self.action, direction, math.min(totalFrame, self.frame))
end

function Clip:setOverFunc(overFunc)
	self.actionLoop = 1
	self.actionOverFunc = overFunc
end

function Clip:setScale(scale)
	self.scale = scale

	self:refreshScale()
end

function Clip:setExScale(scale)
	self.exScale = scale

	self:refreshScale()
end

function Clip:refreshScale()
	local scale = self.scale * self.exScale
	local direction = self:getDirection()

	if direction.scale == 1 then
		self.bmp:setScaleX(1 * scale)
	else
		self.bmp:setScaleX(-1 * scale)
	end

	self.bmp:setScaleY(scale)

	if self.originalWidth ~= nil then
		self.width = self.originalWidth * scale
		self.height = self.originalHeight * scale
	end

	self:setBmpX()
	self:setBmpY()
end

function Clip:rawSetScale(scale)
	cc.Node.setScale(self, scale)
end

function Clip:playLoop(frame, passed, sharp)
	sharp = sharp or 1

	for i = 1, sharp do
		if self.playNext then
			self:playNext()
		end
	end

	if self.autoRotate then
		self.autoRotateValue = self.autoRotateValue + self.autoRotate * passed

		self:setRotation(self.autoRotateValue)
	end
end

function Clip:playNext()
	local isCallOverFunc = false
	local direction, totalFrame = nil

	if self.syncFrame then
		self.playCount = self:getPlaySkip() - 1 - math.floor(MapFrameManager.getAbsFrame() + self.syncFrameOffset) % self:getPlaySkip()
	end

	if self.playCount <= 0 then
		if self.actionLoop ~= nil and self.actionLoop > 0 then
			direction = self:getDirection()
			totalFrame = self:getTotalFrame(direction)

			if self.frame == totalFrame then
				self.actionLoop = self.actionLoop - 1

				if self.actionLoop == 0 then
					isCallOverFunc = true
				end
			end
		end

		direction = direction or self:getDirection()
		local frame = nil

		if self.syncFrame then
			totalFrame = totalFrame or self:getTotalFrame(direction)
			frame = math.ceil((MapFrameManager.getAbsFrame() + self.syncFrameOffset) / self:getPlaySkip(nil, totalFrame == frame)) % totalFrame + 1
		else
			frame = self:getNextFrame(direction)
		end

		self:setFrame(self.action, direction, frame)

		totalFrame = totalFrame or self:getTotalFrame(direction)
		self.playCount = self:getPlaySkip(nil, totalFrame == frame) + self.playCount
	else
		self.playCount = self.playCount - 1
	end

	if isCallOverFunc and self.actionOverFunc ~= nil then
		self:actionOverFunc()

		self.actionOverFunc = nil
	end
end

function Clip:getPlaySkip(action, isLastFrame)
	action = action or self.action

	if isLastFrame and self.lastFrame[action] then
		return self.lastFrame[action]
	end

	return self.actionSkip[action] or self.playSkip
end

function Clip:getNextFrame(direction)
	self.frame = self.frame + 1
	local totalFrame = self:getTotalFrame(direction)

	if totalFrame < self.frame then
		self.frame = math.min(totalFrame, self.loopFrame)
	end

	return self.frame
end

function Clip:setDirectionBackward(tof)
	self.directionBackward = tof

	self:setFrame(self.action, self:getDirection(), self.frame)
end

function Clip:getDir(angle)
	angle = angle or self.angle
	local totalDirection = self:getTotalDirection()
	local perAngle = math.pi / totalDirection

	return math.floor(angle / perAngle + 0.5)
end

function Clip:setDir(dir)
	local totalDirection = self:getTotalDirection()
	local perAngle = math.pi / totalDirection
	self.angle = perAngle * dir
end

function Clip:getDirection(angle)
	angle = angle or self.angle
	local td, perA, d = nil

	if self.directionBackward then
		angle = angle + math.pi
	end

	if self.topType ~= Map.TOP_90 then
		angle = angle + math.pi / 4
	end

	local a = angle % (math.pi * 2)

	if a < 0 then
		a = a + math.pi * 2
	end

	local totalDirection = self:getTotalDirection()

	if self.isAngleMirror and totalDirection <= 1 then
		local a = math.floor(angle / math.pi * 2 % 2)

		if a == 0 then
			return {
				scale = 1,
				d = 0
			}
		else
			return {
				scale = -1,
				d = 0
			}
		end
	end

	if totalDirection == 4 then
		td = 4
		perA = math.pi * 2 / td
		d = math.floor((a + perA / 2) / perA) + 3
		d = d % td

		if d == 3 then
			d = 2
		elseif d == 2 then
			d = 3
		end

		return {
			scale = 1,
			d = d
		}
	elseif totalDirection == 3 then
		td = 4
		perA = math.pi * 2 / td
		d = math.floor((a + perA / 2) / perA) + 3
		d = d % td

		if totalDirection > d then
			return {
				scale = 1,
				d = d
			}
		else
			return {
				scale = -1,
				d = td - d
			}
		end
	elseif totalDirection == 2 then
		td = 4
		perA = math.pi * 2 / td
		d = math.floor(a / perA) + 3
		d = d % td

		if totalDirection > d then
			return {
				scale = 1,
				d = d
			}
		else
			return {
				scale = -1,
				d = td - 1 - d
			}
		end
	elseif totalDirection == 5 then
		td = 8
		perA = math.pi * 2 / td
		d = math.floor((a - math.pi / 8) / perA + 7)
		d = d % td

		if totalDirection > d then
			return {
				scale = 1,
				d = d
			}
		else
			return {
				scale = -1,
				d = td - d
			}
		end
	elseif totalDirection == 1 and not self.one and not self.rotate then
		td = 2
		perA = math.pi * 2 / td
		d = math.floor((a + math.pi / 2) / perA) + 1
		d = d % td

		if totalDirection > d then
			return {
				scale = 1,
				d = 0
			}
		else
			return {
				scale = -1,
				d = 0
			}
		end
	end

	return {
		scale = 1,
		d = 0
	}
end

function Clip:getTotalDirection()
	if self.vaction and self.vaction[self.action] then
		local vactionObj = self.vaction[self.action][self.frame]

		if self.frameStack and self.frameStack[vactionObj[1]] then
			return #self.frameStack[vactionObj[1]]
		end
	end

	if self.frameStack and self.frameStack[self.action] then
		return #self.frameStack[self.action]
	else
		return 0
	end
end

function Clip:getTotalFrame(direction)
	if self.vaction and self.vaction[self.action] then
		return #self.vaction[self.action]
	end

	direction = direction or self:getDirection()

	if self.frameStack and self.frameStack[self.action] then
		return #self.frameStack[self.action][direction.d + 1]
	else
		return 0
	end
end

function Clip:getActionHeight(action)
	local heightTotal = 0
	local heightCount = 0

	if self.rectStack[action] then
		for i = 1, #self.rectStack[action] do
			for j = 1, #self.rectStack[action][i] do
				local rect = self.rectStack[action][i][j]
				heightTotal = heightTotal + rect.height
				heightCount = heightCount + 1
			end
		end
	end

	if heightTotal > 0 and heightCount > 0 then
		return math.floor(heightTotal / heightCount * self.scale)
	end

	return self.height
end

function Clip:getActionTotalFrameTime(action)
	action = self:getMappedAction(action)

	if self.vaction and self.vaction[action] then
		return (#self.vaction[action] - 1) * (self:getPlaySkip(action) + 1) + self:getPlaySkip(action, true)
	end

	if not self.frameStack[action] then
		action = "idle"
	end

	return (#self.frameStack[action][1] - 1) * (self:getPlaySkip(action) + 1) + self:getPlaySkip(action, true)
end

function Clip:getFrameByFrameTime(action, time)
	action = self:getMappedAction(action)

	if not self.frameStack then
		return 1
	end

	if not self.frameStack[action] then
		action = "idle"
	end

	return (time - self:getPlaySkip(action, true)) / (self:getPlaySkip(action) + 1)
end

function Clip:getFrameCount(action)
	action = self:getMappedAction(action)

	if self.vaction and self.vaction[action] then
		return #self.vaction[action] - 1
	end

	if not self.frameStack then
		return 1
	end

	if not self.frameStack[action] then
		action = "idle"
	end

	return #self.frameStack[action][1] - 1
end

function Clip:transFrame(action, direction, frame)
	if self.vaction and self.vaction[action] then
		local vactionObj = self.vaction[action][frame]

		return vactionObj[1], direction, vactionObj[2] + 1
	else
		return action, direction, frame
	end
end

function Clip:setFrame(action, direction, frame)
	action, direction, frame = self:transFrame(action, direction, frame)

	if self.frameStack and self.frameStack[action] then
		if self.frameStack[action][direction.d + 1][frame] == nil then
			self.bmp:setVisible(false)
		else
			self.bmp:setVisible(true)

			local spriteFrame = self.frameStack[action][direction.d + 1][frame]

			if spriteFrame then
				self.bmp:setSpriteFrame(spriteFrame)
			end

			if direction.scale == 1 then
				self.bmp:setScaleX(1 * self.scale * self.exScale)
			else
				self.bmp:setScaleX(-1 * self.scale * self.exScale)
			end

			local rect = self.rectStack[action][direction.d + 1][frame]

			self.bmp:setAnchorPoint(cc.p(rect.x / rect.width, -0.5 + rect.y / rect.height))
		end

		self:setBmpX()
		self:setBmpY()
	end

	return action, direction, frame
end

function Clip:setBmpX()
	local offsetX = 0

	if self.rotateBmpOffset then
		offsetX = offsetX + self.rotateBmpOffset.x
	end

	if self.effectOffset then
		offsetX = offsetX + self.effectOffset.x
	end

	self.bmp:setPositionX(offsetX * self.scale * self.exScale)

	return offsetX
end

function Clip:setBmpY()
	local offsetY = self.yoff - self:getZ()

	if self.rotateBmpOffset then
		offsetY = offsetY + self.rotateBmpOffset.y
	end

	if self.effectOffset then
		offsetY = offsetY + self.effectOffset.y
	end

	self.bmp:setPositionY(-offsetY * self.scale * self.exScale)

	return offsetY
end

function Clip:getZ()
	local z = self.z

	if self.zOffset then
		z = z + self.zOffset
	end

	return z
end

function Clip:playPause()
	if not self.paused then
		self.paused = true

		MapFrameManager.stopLoop(self, self.playLoop)
	end
end

function Clip:playResume()
	if self.paused then
		self.paused = false

		if not self.isSelfUpdate then
			MapFrameManager.startLoop(self, self.playLoop)
		end
	end
end

function Clip:stopPlay()
	MapFrameManager.stopLoop(self, self.playLoop)
end

function Clip:setRotate(value)
	local rotation = value * 180 / math.pi + (self.rotateOffset or 0)

	self.bmp:setRotation(rotation)

	if self.portraitInfo then
		local angle = rotation / 180 * math.pi
		local pX = self.portraitInfo.x
		local pY = -self.portraitInfo.y + self.yoff
		local dis = math.sqrt(math.pow(pX, 2) + math.pow(pY, 2))
		local pX1 = math.cos(angle + math.pi / 2) * dis
		local pY1 = math.sin(angle + math.pi / 2) * dis
		self.rotateBmpOffset = {
			x = pX1 - pX,
			y = pY1 - pY
		}
	end

	self:setBmpX()
	self:setBmpY()

	return rotation
end

function Clip:setRotateByPosition(is90, x, y, z, preX, preY, preZ)
	preX = preX or 0
	preY = preY or 0
	preZ = preZ or 0
	local rotation = nil

	if is90 then
		rotation = math.atan2(y - z - (preY - preZ), x - preX)
	else
		local x45 = (x - preX - (y - preY)) / 2
		local y45 = (x - preX + y - preY) / 4
		rotation = math.atan2(y45 - z + preZ, x45)
	end

	self:setRotate(rotation)
end

function Clip:randomizeFrame()
	local totalFrame = self:getTotalFrame()
	self.frame = math.floor(math.random() * totalFrame) + 1
	self.playCount = math.floor(math.random() * self:getPlaySkip())
end

function Clip:clone(class)
	class = class or Clip
	local cloneClip = class.new()

	if self.isPic then
		cloneClip:loadPic(self.modelName)
	else
		cloneClip:load(self.modelName)
	end

	cloneClip:setScale(self.scale)
	self:cloneAction(cloneClip)

	return cloneClip
end

function Clip:cloneAction(cloneClip)
	cloneClip:setAction(self.action)

	cloneClip.frame = self.frame
	cloneClip.playCount = self.playCount
	cloneClip.angle = self.angle

	cloneClip:setFrame(cloneClip.action, cloneClip:getDirection(), cloneClip.frame)
end

function Clip:setOpacity(opacity)
	self.bmp:setOpacity(opacity)
end

function Clip:onEnter()
end

function Clip:onExit()
	if not app.sceneChanging then
		self:stopPlay()
		MapFrameManager.clearLoop(self)
	end
end

return Clip
