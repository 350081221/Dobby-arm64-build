local CampUtils = {
	getNpcEvent = function (npcID)
		local eventList = MapEventManager.getEventByTagArray("npc")

		if not eventList then
			return
		end

		for i, v in ipairs(eventList) do
			local info = ConfParser.parse(v.info)

			if info.id == npcID then
				return v
			end
		end
	end
}

function CampUtils.getGoNext()
	local eventList = MapEventManager.getEventByTagArray("go_next")

	if not eventList then
		return
	end

	local eventData = eventList[1]

	if eventData then
		local tileX = eventData.x
		local tileY = eventData.y
		local mapX, mapY = global.map:tileToMap(tileX, tileY)

		return mapX, mapY, eventData.index
	end
end

function CampUtils.getNpcGo(npcID)
	local eventData = nil
	local eventList = MapEventManager.getEventByTagArray("npc")

	if eventList then
		for i, v in ipairs(eventList) do
			local info = ConfParser.parse(v.info)

			if info.id == npcID then
				eventData = v

				break
			end
		end
	end

	if not eventData then
		local eventList = MapEventManager.getEventByTagArray("actv_npc")

		if eventList then
			for i, v in ipairs(eventList) do
				local info = ConfParser.parse(v.info)
				local npcList = InfoFestival.getNpsListByPos(info.pos)

				if npcList then
					for j, _npcID in ipairs(npcList) do
						if _npcID == npcID then
							eventData = v

							break
						end
					end
				end

				if eventData then
					break
				end
			end
		end
	end

	if eventData then
		local tileX = eventData.x
		local tileY = eventData.y
		local npcCSV = CsvParser.getCsvData("npc", npcID)

		if npcCSV.building == InfoBuilding.TAG.FURNACE then
			tileX = tileX + 1
		end

		if npcCSV.building == InfoBuilding.TAG.KANBAN then
			tileY = tileY + 1
		end

		if npcCSV.building == InfoBuilding.TAG.FARM then
			tileX = tileX + 1
			tileY = tileY + 2
		end

		local mapX, mapY = global.map:tileToMap(tileX, tileY)

		return mapX, mapY, eventData.index
	end
end

function CampUtils.goNpc(npcID)
	if global.player then
		local mapX, mapY = CampUtils.getNpcGo(npcID)

		if mapX and mapY then
			local path = MapUtils.getPathClose(mapX, mapY)

			if path then
				global.player:goPath(path, true)
			end
		end

		local npcCSV = CsvParser.getCsvData("npc", npcID)

		if npcCSV and not empty(npcCSV.building) then
			local newNpcID = CampUtils.findBuldingNpc(npcCSV.building)

			print("$$$ newNpcID", newNpcID)

			if newNpcID then
				local newMapX, newMapY = CampUtils.getNpcGo(newNpcID)

				if newMapX and newMapY then
					local path = MapUtils.getPathClose(newMapX, newMapY)

					if path then
						global.player:goPath(path, true)
					end
				end
			end
		end
	end
end

local findBuldingNpcCache = {}

function CampUtils.findBuldingNpc(tag)
	if not findBuldingNpcCache[tag] then
		local npcEventMap = MapEventManager.eventMapByTag.npc

		for k, v in pairs(npcEventMap) do
			local info = ConfParser.parse(v.info)
			local npcCSV = CsvParser.getCsvData("npc", info.id)

			if npcCSV.building == tag then
				findBuldingNpcCache[tag] = {
					id = info.id,
					x = v.x,
					y = v.y
				}

				break
			end
		end
	end

	local obj = findBuldingNpcCache[tag]

	if obj then
		return obj.id, obj.x, obj.y
	end
end

local findBulding0NpcCache = {}

function CampUtils.findBulding0Npc(tag)
	if not findBulding0NpcCache[tag] then
		local npcEventMap = MapEventManager.eventMapByTag.npc

		for k, v in pairs(npcEventMap) do
			local info = ConfParser.parse(v.info)
			local npcCSV = CsvParser.getCsvData("npc", info.id)

			if npcCSV.building0 == tag then
				findBulding0NpcCache[tag] = {
					id = info.id,
					x = v.x,
					y = v.y
				}

				break
			end
		end
	end

	local obj = findBulding0NpcCache[tag]

	if obj then
		return obj.id, obj.x, obj.y
	end
end

function CampUtils.clearOnScene()
	findBuldingNpcCache = {}
	findBulding0NpcCache = {}
end

return CampUtils
