local POP_drama = class("POP_drama", UI_base)
local instance = nil

function POP_drama.clear()
	instance = nil
end

function POP_drama.open(topHeight)
	if not instance then
		instance = POP_drama.new()

		display.getRunningScene():addChild(instance, LayerConfig.drama)
		instance:instanceOpen(topHeight)
	end
end

function POP_drama.close()
	if instance then
		instance:instanceClose()
	end
end

function POP_drama:ctor()
	POP_drama.super.ctor(self, "pop_drama")
	self:init()
end

function POP_drama:init()
	self:initUI()
end

function POP_drama:initUI()
	local bt_skip = self:getComponentByTag("bt_skip")

	bt_skip:toTouchable()
	bt_skip:setTapGroup("button_click")
	bt_skip:addTap(function ()
		if not self.enabled then
			return
		end

		DramaManager.setFreeze(true, "POP_drama_ask_skip")
		POP_notice.open(Localization.getSrcText("跳过剧情吗？"), function ()
			DramaManager.setFreeze(false, "POP_drama_ask_skip")
			DramaManager.skip()
		end, function ()
			DramaManager.setFreeze(false, "POP_drama_ask_skip")
		end)
	end)
end

function POP_drama:instanceOpen(topHeight)
	transition.moveTo(self, {
		time = 0.2,
		easing = "sineOut",
		y = -topHeight,
		onComplete = function ()
			self.enabled = true
		end
	})
end

function POP_drama:instanceClose()
	self.enabled = nil

	transition.moveTo(self, {
		y = 0,
		time = 0.2,
		easing = "sineOut",
		onComplete = function ()
			self:removeSelf()
		end
	})
end

function POP_drama:onExit()
	POP_drama.super.onExit(self)

	instance = nil
end

return POP_drama
