local POP_precious = class("POP_precious", UI_base)

function POP_precious.open(itemID, onClose)
	local ui = POP_precious.new(itemID)

	Sound.playSound("gotitem")

	local mask = ui:getComponentByTag("mask")

	PopManager.open(ui, function ()
		mask:setVisible(false)
	end, onClose, PopManager.ANIM_TYPE.CENTER)

	return ui
end

function POP_precious:ctor(itemID)
	POP_precious.super.ctor(self, "pop_precious", UIManager.BIG_TYPE.CENTER)

	self.itemID = itemID

	self:init()
end

function POP_precious:init()
	self:initUI()
end

function POP_precious:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local mask = self:getComponentByTag("mask")

	mask:setOpacity(0)
	mask:toTouchable()

	local slot = DropSlot.new(self:getFlagByTag("flag_icon"), "slot_01")

	self:addChild(slot, 100)
	slot:setDrop(DropManager.TYPE.ITEM, {
		num = 1,
		base_id = self.itemID
	})
	slot:setDetailEnabled(true)

	local itemCSV = CsvParser.getCsvData("item", self.itemID)

	self:createLabelOnFlag("flag_desc", itemCSV.short_desc)
end

return POP_precious
