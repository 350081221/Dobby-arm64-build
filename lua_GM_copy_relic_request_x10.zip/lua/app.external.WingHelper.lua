local json = require("framework.json")
local WingHelper = {
	ghw_user_import = function ()
		print("$$$ WingHelper.ghw_user_import A_wing:", tostring(A_wing))

		if not A_wing then
			return
		end

		local params = {
			serverId = tostring(global.server_id),
			gameUserId = tostring(InfoUser.getID()),
			nickname = tostring(InfoUser.getNickName()),
			level = InfoDungeon.getAbyssMaxLevel()
		}

		LuaBridge.call("lua_ghw_user_import", params, function (result)
		end)
	end,
	ghw_initiated_purchase = function ()
		if not A_wing then
			return
		end

		local params = {}

		LuaBridge.call("lua_ghw_initiated_purchase", params, function (result)
		end)
	end,
	ghw_level_achieved = function ()
		print("$$$ WingHelper.ghw_level_achieved A_wing:", tostring(A_wing), "level:", InfoDungeon.getAbyssMaxLevel())

		if not A_wing then
			return
		end

		local params = {
			currentLevel = InfoDungeon.getAbyssMaxLevel(),
			score = InfoHero.getMaxScore(),
			fighting = InfoHero.getMaxScore()
		}

		LuaBridge.call("lua_ghw_level_achieved", params, function (result)
		end)
	end,
	ghw_user_create = function ()
		print("$$$ WingHelper.ghw_user_create A_wing:", tostring(A_wing))

		if not A_wing then
			return
		end

		local params = {
			serverId = tostring(global.server_id),
			gameUserId = tostring(InfoUser.getID()),
			nickname = tostring(InfoUser.getNickName()),
			registerTime = InfoUser.getCreateTime(),
			fighting = InfoHero.getMaxScore()
		}

		LuaBridge.call("lua_ghw_user_create", params, function (result)
		end)
	end,
	ghw_user_info_update = function ()
		print("$$$ WingHelper.ghw_user_info_update A_wing:", tostring(A_wing))

		if not A_wing then
			return
		end

		local params = {
			nickname = tostring(InfoUser.getNickName())
		}

		LuaBridge.call("lua_ghw_user_info_update", params, function (result)
		end)
	end,
	ghw_self_tutorial_completed = function ()
		print("$$$ WingHelper.ghw_self_tutorial_completed A_wing:", tostring(A_wing))

		if not A_wing then
			return
		end

		local params = {}

		LuaBridge.call("lua_ghw_self_tutorial_completed", params, function (result)
		end)
	end,
	gameReview = function ()
		print("$$$ WingHelper.gameReview")

		if not A_wing then
			return
		end

		local params = {}

		LuaBridge.call("lua_game_review", params, function (result)
			if result.isGood then
				InfoService.reviewReward()
			end
		end)
	end
}

return WingHelper
