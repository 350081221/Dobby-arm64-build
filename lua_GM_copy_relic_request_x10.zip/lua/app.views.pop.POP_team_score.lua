local POP_team_score = class("POP_team_score", UI_base)

function POP_team_score.open(preScore, newScore)
	if not POP_team_score.instance then
		local ui = POP_team_score.new()

		ui:setOpacity(0)
		ui:setPositionY(-50)
		transition.moveTo(ui, {
			easing = "backOut",
			time = 0.2,
			y = 0
		})
		transition.fadeTo(ui, {
			easing = "sineOut",
			time = 0.2,
			opacity = 255
		})
		display.getRunningScene():addChild(ui, LayerConfig.pop)

		POP_team_score.instance = ui
	end

	POP_team_score.instance:show(preScore, newScore)

	return ui
end

function POP_team_score:ctor()
	POP_team_score.super.ctor(self, "pop_team_score", UIManager.BIG_TYPE.POP)
	self:init()
end

function POP_team_score:init()
end

function POP_team_score:show(preScore, newScore)
	if self.overSequence then
		self:stopAction(self.overSequence)

		self.overSequence = nil
	end

	self.preScore = self.preScore or preScore
	self.newScore = newScore
	local score = self.preScore
	local maxStep = 10
	local step = 0

	local function refreshScore()
		local score = (self.newScore - self.preScore) * step / maxStep + self.preScore

		self:createLabelOnFlag("flag_score", math.floor(score))

		if maxStep <= step then
			self:removeEnterFrame("refreshScore")
			self:delayClose()
		else
			step = step + 1
		end
	end

	self:addEnterFrame("refreshScore", refreshScore)
end

function POP_team_score:delayClose()
	local label = self:createLabelOnFlag("flag_score_add", "+" .. self.newScore - self.preScore)

	label:setOpacity(0)
	transition.fadeTo(label, {
		easing = "sineOut",
		time = 0.2,
		opacity = 255
	})

	self.overSequence = self:performWithDelay(function ()
		POP_team_score.instance = nil

		transition.fadeTo(self, {
			easing = "sineOut",
			time = 0.2,
			opacity = 0,
			onComplete = function ()
				self:removeSelf()
			end
		})
	end, 1)
end

function POP_team_score:onExit()
	POP_team_score.super.onExit(self)

	POP_team_score.instance = nil
end

return POP_team_score
