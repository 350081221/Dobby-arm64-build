local TransitionScene = class("TransitionScene", function ()
	return display.newScene("TransitionScene")
end)

function TransitionScene:ctor()
end

function TransitionScene:onEnter()
	app:resumeScene(self)
end

function TransitionScene:onExit()
	app:clearScene(scene)
end

return TransitionScene
