local UI_base = import("..UI_base")
local FRAME_actv_main = class("FRAME_actv_main", UI_base)

function FRAME_actv_main:ctor(uiName, data)
	FRAME_actv_main.super.ctor(self, "iframe_actv_main")

	self.data = data

	self:init()
end

function FRAME_actv_main:init()
	self:initUI()
	self:refresh()
	ManagerInfo.onDataChange(self, "festival", nil, function ()
		self:refresh()
	end)
end

function FRAME_actv_main:resetData(data)
	self.data = data

	self:refresh()
end

function FRAME_actv_main:refresh()
	local data = self.data
	local pic_mask = self:getComponentByTag("pic_mask")

	pic_mask:setVisible(false)

	if not empty(data.page) then
		local page = Localization.getTextByLang(data.page)

		PicLoader.load(page, function (path)
			if pic_mask.setVisible then
				pic_mask:setVisible(true)
				self:createPicOnFlag("pic_mask", path, nil, UILayout.SCALE_TYPE.LARGE)
			end
		end)
	end

	local maxWidth = 0
	local _, _, totalWidth = self:createLabelGroupOnFlag("flag_time_start", {
		Localization.getSrcText("开始时间："),
		StringUtil.ymdtFormat(data.stime)
	}, {
		{},
		{
			color = Style.font3
		}
	}, {
		align = Style.left
	})
	maxWidth = math.max(maxWidth, totalWidth)
	local _, _, totalWidth = self:createLabelGroupOnFlag("flag_time_end", {
		Localization.getSrcText("结束时间："),
		StringUtil.ymdtFormat(data.etime)
	}, {
		{},
		{
			color = Style.font3
		}
	}, {
		align = Style.left
	})
	maxWidth = math.max(maxWidth, totalWidth)

	if empty(data.shop_time) or data.shop_time == data.etime then
		local _, _, totalWidth = self:createLabelGroupOnFlag("flag_time_shop", {
			Localization.getSrcText("兑换截止时间："),
			Localization.getSrcText("同活动结束时间")
		}, {
			{},
			{
				color = Style.font3
			}
		}, {
			align = Style.left
		})
		maxWidth = math.max(maxWidth, totalWidth)
	else
		local _, _, totalWidth = self:createLabelGroupOnFlag("flag_time_shop", {
			Localization.getSrcText("兑换截止时间："),
			StringUtil.ymdtFormat(data.shop_time)
		}, {
			{},
			{
				color = Style.font3
			}
		}, {
			align = Style.left
		})
		maxWidth = math.max(maxWidth, totalWidth)
	end

	local time_bg = self:getComponentByTag("time_bg")

	time_bg:setSize(maxWidth + 10)
	time_bg:setLocalZOrder(110)

	local navArr = {}
	local bt_go = self:getComponentByTag("bt_go")

	bt_go:setVisible(false)

	local currentFestival = InfoFestival.checkCurrent(self.data.id)

	if not empty(currentFestival) then
		local opening, actv_id = InfoFestival.checkShopOpening(currentFestival)

		bt_go:setVisible(opening)
	end
end

function FRAME_actv_main:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local bt_go = self:getComponentByTag("bt_go")

	bt_go:toTouchable()
	bt_go:setTapGroup("button_click")
	bt_go:addTap(function ()
		local currentFestival = InfoFestival.checkCurrent(self.data.id)

		if not empty(currentFestival) then
			local opening, actv_id = InfoFestival.checkShopOpening(currentFestival)

			if opening then
				local csv = CsvParser.getCsvData("festival", currentFestival)

				CampUtils.goNpc(csv.npc)
				PopManager.close()
			end
		end
	end)

	local bt_info = self:getComponentByTag("bt_info")

	bt_info:toTouchable()
	bt_info:setTapGroup("button_click")
	bt_info:addTap(function ()
		FRAME_actv_preview.open(self.data)
	end)
end

return FRAME_actv_main
