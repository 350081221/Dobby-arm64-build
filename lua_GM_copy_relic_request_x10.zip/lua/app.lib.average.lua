local function sum(x)
	local s = 0

	for _, v in ipairs(x) do
		s = s + v
	end

	return s
end

local function arithmetic_mean(x)
	return sum(x) / #x
end

local function geometric_mean(x)
	local prod = 1

	for _, v in ipairs(x) do
		prod = prod * v
	end

	return prod^(1 / #x)
end

local function harmonic_mean(x)
	local s = 0

	for _, v in ipairs(x) do
		s = s + 1 / v
	end

	return #x / s
end

local function quadratic_mean(x)
	local ssquares = 0

	for _, v in ipairs(x) do
		ssquares = ssquares + v * v
	end

	return math.sqrt(1 / #x * ssquares)
end

local function generalized_mean(x, p)
	local sump = 0

	for _, v in ipairs(x) do
		sump = sump + v^p
	end

	return (1 / #x * sump)^(1 / p)
end

local function weighted_mean(x, w)
	local sump = 0

	for i, v in ipairs(x) do
		sump = sump + v * w[i]
	end

	return sump / sum(w)
end

local function midrange_mean(x)
	local sump = 0

	return 0.5 * (math.min(unpack(x)) + math.max(unpack(x)))
end

local function energetic_mean(x)
	local s = 0

	for _, v in ipairs(x) do
		s = s + 10^(v / 10)
	end

	return 10 * math.log10(1 / #x * s)
end

return {
	arithmetic = arithmetic_mean,
	geometric = geometric_mean,
	harmonic = harmonic_mean,
	quadratic = quadratic_mean,
	generalized = generalized_mean,
	weighted = weighted_mean,
	midrange = midrange_mean,
	energetic = energetic_mean
}
