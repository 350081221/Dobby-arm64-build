local InfoDungeon = {}
local TYPE = {
	ABYSS = 2,
	QUEST = 1,
	CORE = 5,
	STAGE = 4,
	TASK = 3
}
InfoDungeon.TYPE = TYPE
local STAGE_TYPE = {
	ACTV = 4,
	HERO_STORY = 3,
	WILD = 2,
	NORMAL = 1,
	actv_stage = 103,
	tower = 102,
	unified = 101,
	BACK = 12,
	UNION_PVE_NORMAL_STAGE = 11,
	UNION_SOLO = 10,
	UNION_TRAIN = 9,
	DUST = 8,
	DUST_PREPARE = 7,
	NARAKA_BOSS = 6,
	NARAKA_PREPARE = 5
}
InfoDungeon.STAGE_TYPE = STAGE_TYPE
local type, dungeonID, dungeonLevel, abyssLayer, enterLayer, abyssSeed = nil
local dungeonSeed = 0
local session, questID, questLevel, questSeed = nil
local passCount = 0
local passTotal = 0
local missionID, questDbID = nil
local abyssMaxLayer = 0
local abyssMaxLevel = 0
local mapSeedArr = {}
local eventInfoMap = {}
local currentMapIndex = 0
local lifeData = {}
local relicData = {}
local finalRelic = {}
local shrineData = {}
local unionBuffData = {}
local heroHpData = {}
local heroHpLoseData = {}
local modaoMp = 0
local modaoMax = 0
local sneakPoint = 0
local sneakBuffID = 0
local sneakBuffTime = 0
local runeMap = {}
local allCarry = {}
local heroTeamData = {}
local petTeamData = {}
local queryInfo = {}
local preCompleteEventInfo = nil
local stageType = 0
local stageID = 0
local stageParams = {}
local probUpMap = {}
local actvMonster = {}
local speedup = 0
local autopick_time = 0
local autopick_curr = 0
local layerSafe = 0
local mutateType = 0
local mutateID = 0
local terrainType = 0
local terrainID = 0
local gapID = ""
local gap_currentMapIndex = 0
local gap_mapSeedArr = {}
local gap_relicData = {}
local gap_finalRelic = {}
local gap_eventInfoMap = {}
local timeStart = 0
local timeUsed = 0

function InfoDungeon.init()
	Connection.listen("dungeon_sync", InfoDungeon.onSync)
	Connection.listen("dungeon_sync_hero_hp", InfoDungeon.syncHeroHP)
	Connection.listen("dungeon_trap_hp", InfoDungeon.trapHeroHP)
	Connection.listen("dungeon_event_fin", InfoDungeon.syncEventFin)
	Connection.listen("dungeon_clear_speedup", InfoDungeon.onClearSpeedup)
	Connection.listen("dungeon_layer_safe", InfoDungeon.onLayerSafe)
	Connection.listen("dungeon_abyss_max_layer", InfoDungeon.onAbyssMaxLayer)
	Connection.listen("dungeon_shrine_sync", InfoDungeon.onShrineSync)
	Connection.listen("dungeon_sneak_sync", InfoDungeon.onSneakSync)
	Connection.listen("dungeon_relic_fin", InfoDungeon.onRelicFin)
	Connection.listen("dungeon_relic_add", InfoDungeon.onRelicAdd)
	Connection.listen("dungeon_reload", function (rcvData)
	end)
end

app:addToAppEnterCall(InfoDungeon.init)

function InfoDungeon.onRelicAdd(data)
	if InfoDungeon.inGap() then
		if gap_currentMapIndex == data.map_index then
			if not gap_relicData[gap_currentMapIndex] then
				gap_relicData[gap_currentMapIndex] = {}
			end

			table.insert(gap_relicData[gap_currentMapIndex][data.event_index], data.relic)

			if gap_relicData[gap_currentMapIndex][data.event_index] then
				InfoDungeon.addRelic(true, data.event_index, gap_relicData[gap_currentMapIndex][data.event_index], true)
			end
		end
	elseif currentMapIndex == data.map_index then
		if not relicData[currentMapIndex] then
			relicData[currentMapIndex] = {}
		end

		table.insert(relicData[currentMapIndex][data.event_index], data.relic)

		if relicData[currentMapIndex][data.event_index] then
			InfoDungeon.addRelic(false, data.event_index, relicData[currentMapIndex][data.event_index], true)
		end
	end
end

function InfoDungeon.onRelicFin(data)
	if InfoDungeon.inGap() then
		if currentMapIndex == data.map_index and gap_relicData[currentMapIndex][data.event_index] and gap_relicData[currentMapIndex][data.event_index][data.relic_index] then
			gap_relicData[currentMapIndex][data.event_index][data.relic_index].fin = 1
			local npcs = ClipOnMap.getUnitList("npc")

			for i, npc in ipairs(npcs) do
				if npc.npcType == Npc.TYPE.RELIC and npc.eventIndex == data.event_index and npc.relicIndex == data.relic_index then
					npc:relicDestroy(true)
				end
			end
		end
	elseif currentMapIndex == data.map_index and relicData[currentMapIndex][data.event_index] and relicData[currentMapIndex][data.event_index][data.relic_index] then
		relicData[currentMapIndex][data.event_index][data.relic_index].fin = 1
		local npcs = ClipOnMap.getUnitList("npc")

		for i, npc in ipairs(npcs) do
			if npc.npcType == Npc.TYPE.RELIC and npc.eventIndex == data.event_index and npc.relicIndex == data.relic_index then
				npc:relicDestroy(true)
			end
		end
	end
end

function InfoDungeon.onSync(data)
	dump(data, "$$$ InfoDungeon.onSync")

	if data.autopick_time then
		autopick_time = data.autopick_time
	end

	ManagerInfo.dataChange("dungeon")
end

function InfoDungeon.onSneakSync(data)
	local prePoint = sneakPoint
	sneakPoint = data.sneak_point
	sneakBuffID = data.sneak_buff_id
	sneakBuffTime = data.sneak_buff_time

	if prePoint == 0 and sneakPoint > 0 or prePoint > 0 and sneakPoint == 0 then
		TeamManager.refreshTeamSneak()
	end

	notify.dispatch("sneak_point_changed")
end

function InfoDungeon.onShrineSync(data)
	shrineData = {}

	if data.shrine then
		for i, v in ipairs(data.shrine) do
			shrineData[v.index] = v
		end

		InfoDungeon.refreshShrine()
	end
end

function InfoDungeon.getAfDungeon(level)
	local csvList = CsvParser.getCsvList("af_track_dungeon", "__line", nil, function (a, b)
		return b.__line < a.__line
	end)

	for i, csv in ipairs(csvList) do
		if csv.level <= level then
			return csv.id
		end
	end
end

function InfoDungeon.onAbyssMaxLayer(data)
	local preMaxLevel = abyssMaxLevel

	if data.abyss_max_layer then
		abyssMaxLayer = data.abyss_max_layer
	end

	if data.abyss_max_level then
		abyssMaxLevel = data.abyss_max_level
	end

	if preMaxLevel < abyssMaxLevel then
		InfoUser.setUserInfo(false)
		WingHelper.ghw_level_achieved()

		local preAfLevel = InfoDungeon.getAfDungeon(preMaxLevel)
		local currentAfLevel = InfoDungeon.getAfDungeon(abyssMaxLevel)

		if currentAfLevel and currentAfLevel ~= preAfLevel then
			LuaBridge.call("luaAfEvent", {
				eventName = currentAfLevel
			})
		end
	end
end

function InfoDungeon.onLayerSafe(data)
	layerSafe = data.layer_safe

	notify.dispatch("layer_safe_changed")
end

function InfoDungeon.onClearSpeedup(data)
	speedup = 0

	Alert.open(Localization.getSrcText("加速装置已失效"))
end

function InfoDungeon.syncEventFin(data)
	for i, v in ipairs(data.list) do
		local eventInfo = nil

		if InfoDungeon.inGap() then
			eventInfo = gap_eventInfoMap[gap_currentMapIndex][v.index]
		else
			eventInfo = eventInfoMap[currentMapIndex][v.index]
		end

		eventInfo.fin = v.fin

		if eventInfo then
			local npc = Npc.getByEvent(v.index)

			if npc then
				npc:refreshOpened(true)
			end
		end

		notify.dispatch("event_fin", v.index)
	end
end

function InfoDungeon.syncPass(data)
	local prePassCount = passCount
	local prePassTotal = passTotal
	passCount = data.pass_count
	passTotal = data.pass_total

	if passCount ~= prePassCount or passTotal ~= prePassTotal then
		notify.dispatch("pass_changed")
	end
end

function InfoDungeon.debug()
	print("================== InfoDungeon.debug() ==================")
	print("$$$ dungeonID", dungeonID)
	print("$$$ dungeonLevel", dungeonLevel)
	print("$$$ dungeonSeed", dungeonSeed)
	print("$$$ abyssSeed", abyssSeed)
	dump(MapEventManager.eventMapByIndex, "$$$ MapEventManager.eventMapByIndex")
	dump(eventInfoMap, "$$$ eventInfoMap")
	dump(gap_eventInfoMap, "$$$ gap_eventInfoMap")
end

function InfoDungeon.query(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "dungeon_query")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			queryInfo = rcvData
			abyssMaxLayer = rcvData.abyss_max_layer
			abyssMaxLevel = rcvData.abyss_max_level
			abyssSeed = rcvData.abyssSeed
			dungeonSeed = rcvData.seed
			type = rcvData.type
			stageType = rcvData.stage_type
			stageID = rcvData.stage_id
			autopick_time = rcvData.autopick_time

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("dungeon_query", callback)
end

function InfoDungeon.setMapTag(tag, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Http.request("dungeon/setmaptag", {
		tag = tag
	}, callback)
end

function InfoDungeon.getSneakPoint()
	return sneakPoint
end

function InfoDungeon.getSneakBuff()
	local sneak_buff_id = CsvParser.getCsvData("config", "sneak_buff_id").value
	local sneak_buff_time = CsvParser.getCsvData("config", "sneak_buff_time").value
	local buffID = sneakBuffID

	if buffID == 0 then
		buffID = sneak_buff_id
	end

	local buffTime = sneakBuffTime

	if buffTime == 0 then
		buffTime = sneak_buff_time
	end

	return buffID, buffTime
end

function InfoDungeon.prepareRune()
	local itemMap = InfoQuickSlots.getRuneMap()
	runeMap = {}

	for i = 1, GameConfig.rune_num do
		local itemID = itemMap[i] or 0
		local num = 0

		if not empty(itemID) then
			num = 1
		end

		runeMap[i] = {
			used = 0,
			base_id = itemID,
			num = num
		}
	end
end

function InfoDungeon.getRuneList()
	return runeMap
end

function InfoDungeon.getRune(index)
	return runeMap[index]
end

function InfoDungeon.useRuneBattle(index)
	local itemInfo = InfoDungeon.getRune(index)
	itemInfo.num = itemInfo.num - 1
	itemInfo.used = itemInfo.used + 1
end

function InfoDungeon.isCampHome()
	return InfoDungeon.isCamp() or InfoDungeon.isHome()
end

function InfoDungeon.isCamp()
	return InfoChapter.checkCampMap(DungeonScene.currentMap)
end

function InfoDungeon.isHome()
	return DungeonScene.enterInfo and DungeonScene.enterInfo.isHome
end

function InfoDungeon.enterCamp()
	notify.dispatch("exit_map")

	InfoDungeon.isAbyssEnter = nil

	if InfoDungeon.getType() == TYPE.ABYSS then
		InfoDungeon.isAbyssExit = true
	end

	InfoDungeon.clear()
	Transition.setTitle(InfoChapter.getCampName())
	DungeonState.init()
	DungeonScene.enterMap(DungeonScene.ENTER_TYPE.NEW, InfoChapter.getCampMap())
end

function InfoDungeon.finishQuest(onSuccess, onFailure)
	local preType = type

	local function callback(rcvData)
		dump(rcvData, "dungeon_finish_quest", 10)

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			notify.dispatch("quest_finish")

			if CONFIG.is_ta and preType == TYPE.QUEST then
				local questID = InfoDungeon.getQuestID()

				if questID then
					local csv = CsvParser.getCsvData("quest", questID)
					local params = {
						quest_id = questID,
						quest_star = csv.star
					}

					TaHelper.taTrack("quest_complete", params)
				end
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("dungeon_finish_quest", callback)
end

function InfoDungeon.finishStage(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "dungeon_finish_stage", 10)

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			notify.dispatch("stage_finish")

			if CONFIG.is_ta and type == TYPE.STAGE then
				if stageType == STAGE_TYPE.WILD then
					local params = {
						stage_id = dungeonID,
						hero_info = TaHelper.getHeroInfoAll(),
						dungeon_duration = rcvData.time_used
					}

					TaHelper.taTrack("world_win", params)
				elseif stageType == STAGE_TYPE.tower then
					local params = {
						stage_id = dungeonID,
						hero_info = TaHelper.getHeroInfoAll(),
						dungeon_duration = rcvData.time_used
					}

					TaHelper.taTrack("team_win", params)
				end
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	local score = InfoHero.getTeamScore()

	Connection.request("dungeon_finish_stage", {
		score = score
	}, callback)
end

function InfoDungeon.clear()
	type = nil
	dungeonID = nil
	dungeonLevel = nil
	abyssSeed = nil
	questID = nil
	questLevel = nil
	questSeed = nil
	passCount = 0
	passTotal = 0
	mapSeedArr = {}
	eventInfoMap = {}
	currentMapIndex = 0
	lifeData = {}
	relicData = {}
	finalRelic = {}
	shrineData = {}
	heroHpData = {}
	heroHpLoseData = {}
	modaoMp = 0
	modaoMax = 0
	sneakPoint = 0
	missionID = nil
	questDbID = nil
	stageType = 0
	stageID = 0
	stageParams = {}

	InfoDungeon.clearGap()
end

function InfoDungeon.getDungeonMaps(type, dungeonID, questID, abyssSeed)
	local dungeonData, quest_map_csv = InfoDungeon.getDungeonCSV(type, dungeonID, questID, abyssSeed)

	if type == TYPE.QUEST then
		local maps = SheetUtil.getColumnValueList(quest_map_csv, "map_")

		return maps, quest_map_csv
	elseif type == TYPE.TASK then
		local maps = SheetUtil.getColumnValueList(quest_map_csv, "map_")

		return maps, quest_map_csv
	elseif type == TYPE.ABYSS then
		local maps = SheetUtil.getColumnValueList(dungeonData, "map_")

		return maps
	elseif type == TYPE.STAGE then
		local maps = SheetUtil.getColumnValueList(dungeonData, "map_")

		return maps
	end
end

function InfoDungeon.getProbup(type)
	return probUpMap[type] or {}
end

local actvMonsterMap = {}

function InfoDungeon.initActvMonster(monsterEventArr)
	actvMonsterMap = {}

	if InfoDungeon.getType() == TYPE.ABYSS then
		local map_seed = InfoDungeon.getMapSeed()
		local random = Random.new(map_seed)
		local readyArr = {}

		for id, v in pairs(actvMonster) do
			if v.num > 0 and v.prob_1000 > 0 then
				table.insert(readyArr, {
					id = id,
					prob_1000 = v.prob_1000,
					num = v.num
				})
			end
		end

		table.sort(readyArr, function (a, b)
			return a.id < b.id
		end)

		monsterEventArr = random:order(monsterEventArr)

		for i, eventIndex in ipairs(monsterEventArr) do
			for j, obj in ipairs(readyArr) do
				if obj.num > 0 and random:next() * 1000 <= obj.prob_1000 then
					actvMonsterMap[eventIndex] = obj.id
					obj.num = obj.num - 1
				end
			end
		end
	end
end

function InfoDungeon.getActvMonster(index)
	return actvMonsterMap[index]
end

function InfoDungeon.enterStage(rcvData)
	InfoDungeon.clearGap()
	InfoDungeon.makeMaps(rcvData)
end

function InfoDungeon.makeMaps(rcvData)
	print("$$$ makeMaps 1")

	probUpMap = {}

	if rcvData.prob_up then
		for i, v in ipairs(rcvData.prob_up) do
			probUpMap[v.type] = probUpMap[v.type] or {}
			probUpMap[v.type][v.id] = v.value
		end
	end

	actvMonster = {}

	if rcvData.actv_monster then
		for i, v in ipairs(rcvData.actv_monster) do
			actvMonster[v.id] = v
		end
	end

	dump(actvMonster, "$$$ actvMonster")

	type = rcvData.type
	dungeonID = rcvData.dungeon_id
	dungeonLevel = rcvData.level

	print("$$$ rcvData.abyss_layer", rcvData.abyss_layer, rcvData.enter_layer)

	abyssLayer = rcvData.abyss_layer or abyssLayer
	enterLayer = rcvData.enter_layer or enterLayer

	if rcvData.abyss_seed then
		abyssSeed = rcvData.abyss_seed
	end

	dungeonSeed = rcvData.seed
	session = rcvData.session
	mapSeedArr = rcvData.map_seeds
	questID = rcvData.quest_id
	questLevel = rcvData.quest_level
	questSeed = rcvData.quest_seed
	passCount = rcvData.pass_count
	passTotal = rcvData.pass_total
	missionID = rcvData.mission_id
	questDbID = rcvData.quest_db_id
	stageType = rcvData.stage_type
	stageID = rcvData.stage_id
	stageParams = {}

	if rcvData.stage_params ~= "" then
		stageParams = json.decode(rcvData.stage_params)
	end

	speedup = rcvData.speedup

	if rcvData.autopick_curr then
		autopick_curr = rcvData.autopick_curr
	end

	timeStart = Time.now()
	timeUsed = 0

	if rcvData.time_used then
		timeUsed = rcvData.time_used
	end

	layerSafe = rcvData.layer_safe
	mutateType = rcvData.mutate_type
	mutateID = rcvData.mutate_id
	terrainType = rcvData.terrain_type
	terrainID = rcvData.terrain_id
	local maps = InfoDungeon.getDungeonMaps(type, dungeonID, questID, abyssSeed)
	relicData = {}
	finalRelic = {}
	shrineData = {}
	local eventInfos, relicInfos = nil

	if rcvData.events then
		eventInfos = json.decode(rcvData.events)
	end

	if rcvData.relic then
		relicInfos = json.decode(rcvData.relic)
	end

	if rcvData.shrine then
		for i, v in ipairs(rcvData.shrine) do
			shrineData[v.index] = v
		end
	end

	unionBuffData = rcvData.union_buff or {}

	InfoDungeon.refreshShrine()
	print("$$$ makeMaps 2")

	eventInfoMap = {}

	for mapIndex, mapName in ipairs(maps) do
		local mapSeed = mapSeedArr[mapIndex]
		local random = Random.new(mapSeed)
		eventInfoMap[mapIndex] = {}
		relicData[mapIndex] = {}

		print("$$$ getMapData 1", mapIndex, mapName, mapSeed)

		local mapObj = Map.getMapData(mapName, mapSeed)

		print("$$$ getMapData 2", mapObj)

		for eventIndex, eventData in ipairs(mapObj.eventData) do
			local eventIndexStr = tostring(eventIndex)
			local eventSeed = random:getInt(1, 65535)

			if relicInfos and relicInfos[mapIndex] then
				relicData[mapIndex][eventIndex] = relicInfos[mapIndex][eventIndexStr]
			end

			if eventInfos and eventInfos[mapIndex] and eventInfos[mapIndex][eventIndexStr] then
				table.insert(eventInfoMap[mapIndex], {
					data = eventData,
					seed = eventSeed,
					fin = eventInfos[mapIndex][eventIndexStr].fin,
					set_index = eventInfos[mapIndex][eventIndexStr].set_index
				})
			else
				table.insert(eventInfoMap[mapIndex], {
					fin = 0,
					data = eventData,
					seed = eventSeed
				})
			end
		end
	end

	print("$$$ makeMaps 3")

	lifeData = {}

	DungeonState.init()
	InfoDungeon.setMapIndex(1)

	if rcvData.team_state then
		DungeonState.setState(json.decode(rcvData.team_state))
	end

	queryInfo.type = type
	queryInfo.dungeon_id = dungeonID
	queryInfo.quest_id = questID
	queryInfo.abyss_seed = abyssSeed

	print("$$$ makeMaps 4")
end

function InfoDungeon.getMaps()
	if empty(gapID) then
		local maps = InfoDungeon.getDungeonMaps(type, dungeonID, questID, abyssSeed)

		return maps
	else
		local maps = InfoDungeon.getDungeonMaps(TYPE.STAGE, gapID)

		return maps
	end
end

function InfoDungeon.getMapName(map_index)
	local maps = InfoDungeon.getMaps()

	return maps[map_index]
end

function InfoDungeon.setMapIndex(index)
	if currentMapIndex ~= index then
		currentMapIndex = index

		DungeonState.setMapIndex()
	end
end

function InfoDungeon.getMapIndex()
	if empty(gapID) then
		return currentMapIndex
	else
		return gap_currentMapIndex
	end
end

function InfoDungeon.getMapSeed()
	if empty(gapID) then
		return mapSeedArr[currentMapIndex] or 0
	else
		return gap_mapSeedArr[gap_currentMapIndex] or 0
	end
end

function InfoDungeon.inDust()
	if InfoDungeon.inDungeon() and type == TYPE.STAGE then
		local stageType, stageID = InfoDungeon.getStage()

		return stageType == STAGE_TYPE.DUST
	end
end

function InfoDungeon.getDustID()
	if InfoDungeon.inDungeon() and type == TYPE.STAGE then
		local stageType, stageID = InfoDungeon.getStage()

		if stageType == STAGE_TYPE.DUST or stageType == STAGE_TYPE.DUST_PREPARE then
			return stageID
		end
	end
end

function InfoDungeon.inDustPrepare()
	if InfoDungeon.inDungeon() and type == TYPE.STAGE then
		local stageType, stageID = InfoDungeon.getStage()

		return stageType == STAGE_TYPE.DUST_PREPARE
	end
end

function InfoDungeon.checkInDust(dust_id)
	if InfoDungeon.inDust() or InfoDungeon.inDustPrepare() then
		return true
	end

	return false
end

function InfoDungeon.getDustData()
	if InfoDungeon.inDust() or InfoDungeon.inDustPrepare() then
		local dustData = InfoDust.getDustData()

		return dustData
	end
end

function InfoDungeon.getDustBaseNumFile()
	local fileName = "dust_base_num"
	local state, dustID = InfoDust.getState()

	if dustID and dustID > 1 then
		fileName = "dust_base_num_" .. dustID
	end

	return fileName
end

function InfoDungeon.inDungeon()
	return not empty(dungeonID)
end

function InfoDungeon.inDungeonSafe()
	if InfoDungeon.inDustPrepare() then
		return true
	end

	return false
end

function InfoDungeon.inNoSafe()
	if InfoDungeon.inDungeon() and not InfoDungeon.inDungeonSafe() then
		return true
	end

	if type == TYPE.CORE then
		return true
	end

	return false
end

function InfoDungeon.setType(_type)
	type = _type
end

function InfoDungeon.getType()
	return type
end

function InfoDungeon.getCurrentType()
	if InfoDungeon.inGap() then
		return TYPE.STAGE
	else
		return type
	end
end

function InfoDungeon.getID()
	return dungeonID
end

function InfoDungeon.getLevel()
	return dungeonLevel or 1
end

function InfoDungeon.getQuestID()
	return questID
end

function InfoDungeon.getQuestLevel()
	return questLevel
end

function InfoDungeon.getQuestSeed()
	return questSeed
end

function InfoDungeon.getAbyssMaxLayer()
	return abyssMaxLayer
end

function InfoDungeon.getAbyssMaxLevel()
	return abyssMaxLevel
end

function InfoDungeon.getAbyssLayer()
	return abyssLayer
end

function InfoDungeon.getEnterLayer()
	return enterLayer
end

function InfoDungeon.getMaxEquipLevel()
	local abyssCSV = CsvParser.getCsvData("abyss_base_num", InfoDungeon.getAbyssMaxLevel())

	return abyssCSV.equip_level_1
end

function InfoDungeon.getMinEquipLevel()
	local abyssCSV = CsvParser.getCsvData("abyss_base_num", InfoDungeon.getAbyssMaxLevel())
	local levelArr = SheetUtil.getColumnValueList(abyssCSV, "equip_level_")

	return levelArr[#levelArr]
end

function InfoDungeon.gmSetAbyss(maxLayer, maxLevel, autoPickTime, autoPickCurr)
	abyssMaxLayer = maxLayer
	abyssMaxLevel = maxLevel
	autopick_time = autoPickTime
	autopick_curr = autoPickCurr
end

function InfoDungeon.getMissionID()
	return missionID
end

function InfoDungeon.getQuestDbID()
	return questDbID
end

function InfoDungeon.getSeed()
	return dungeonSeed
end

function InfoDungeon.getSession()
	return session
end

local abyss_map_random_all = nil

function InfoDungeon.getDungeonCSV(_type, _dungeonID, _questID, _abyssSeed)
	_type = _type or type
	_dungeonID = _dungeonID or dungeonID
	_questID = _questID or questID
	_abyssSeed = _abyssSeed or abyssSeed
	local dungeonData, quest_map_csv = nil

	if _type == TYPE.QUEST then
		dungeonData = CsvParser.getCsvData("quest_dungeon", _dungeonID)

		if not dungeonData then
			return
		end

		quest_map_csv = CsvParser.getCsvData("quest_map", _dungeonID .. "_" .. _questID)
	elseif _type == TYPE.TASK then
		dungeonData = CsvParser.getCsvData("task_quest", _questID)

		if not dungeonData then
			return
		end

		quest_map_csv = CsvParser.getCsvData("task_quest_map", _dungeonID .. "_" .. _questID)
	elseif _type == TYPE.STAGE then
		dungeonData = CsvParser.getCsvData("stage", _dungeonID)

		if not dungeonData then
			return
		end
	elseif _type == TYPE.ABYSS then
		dungeonData = CsvParser.getCsvData("abyss", _dungeonID)

		if not dungeonData then
			return
		end

		if dungeonData.map_random ~= "" then
			if not abyss_map_random_all then
				abyss_map_random_all = {}
				local map_random_group = {}
				local map_random_index = {}
				local abyss_csv_list = CsvParser.getCsvList("abyss")

				for i, abyss_csv in ipairs(abyss_csv_list) do
					local map_random = abyss_csv.map_random

					if map_random ~= "" then
						if not map_random_group[map_random] then
							map_random_group[map_random] = {}
						end

						table.insert(map_random_group[map_random], abyss_csv.id)

						map_random_index[abyss_csv.id] = #map_random_group[map_random]
					end
				end

				abyss_map_random_all = {
					group = map_random_group,
					index = map_random_index
				}
			end

			local group = abyss_map_random_all.group[dungeonData.map_random]
			local index = abyss_map_random_all.index[dungeonData.id]
			local ran = Random.new(_abyssSeed)
			group = ran:order(group)
			local replaceID = group[index]

			if dungeonData.id ~= replaceID then
				local replace_dungeon_csv = CsvParser.getCsvData("abyss", replaceID)
				local newDungeonCSV = {}

				for k, v in pairs(replace_dungeon_csv) do
					if string.sub(k, 1, 4) == "map_" and k ~= "map_random" and k ~= "map_type" then
						newDungeonCSV[k] = v
					else
						newDungeonCSV[k] = dungeonData[k]
					end
				end

				dungeonData = newDungeonCSV
			end
		end
	end

	return dungeonData, quest_map_csv
end

function InfoDungeon.getHeroHP(hero_id)
	return heroHpData[hero_id]
end

function InfoDungeon.getHeroHPLose(hero_id)
	return heroHpLoseData[hero_id] or 0
end

function InfoDungeon.getModaoMP()
	return modaoMp
end

function InfoDungeon.getModaoMax()
	return modaoMax
end

function InfoDungeon.debugSetModaoMP(mp)
	modaoMp = mp
end

function InfoDungeon.idDeadout()
	local heros = InfoHero.getTeam()
	local idDeadout = true

	for i, heroInfo in ipairs(heros) do
		local hero_id = heroInfo.id

		if not heroHpData[hero_id] or heroHpData[hero_id] > 0 then
			idDeadout = false

			break
		end
	end

	return idDeadout
end

function InfoDungeon.syncHeroHP(data)
	local heroInfos = InfoHero.getTeamInPos()

	for pos = 1, GameConfig.hero_team_num do
		local heroInfo = heroInfos[pos]
		local hp = data["hero_hp_" .. pos]
		local hpLose = data["hero_hp_lose_" .. pos]

		if heroInfo then
			if hp then
				heroHpData[heroInfo.id] = hp
			end

			if hpLose then
				heroHpLoseData[heroInfo.id] = hpLose
			end
		end

		if hp and OnlineCamp.inRoom() == 2 then
			OnlineCamp.uploadHeroHp(heroInfo.pos, hp, true)
		end
	end

	modaoMp = data.modao_mp
	local maxChanged = false

	if data.modao_max and modaoMax ~= data.modao_max then
		modaoMax = data.modao_max
		maxChanged = true
	end

	if WarMachine.on then
		Looper.setTimeout(function ()
			TeamManager.refreshTeamHp()
		end, 30, global.map)
	else
		TeamManager.refreshTeamHp()
	end

	InfoModao.refreshMp(maxChanged)
end

local trapHeroDelay = nil

function InfoDungeon.setTrapHeroDelay(frameTime)
	trapHeroDelay = frameTime
end

function InfoDungeon.trapHeroHP(data)
	local function doHurt()
		for pos = 1, GameConfig.hero_team_num do
			local unit = TeamManager.getHeroByPos(pos)
			local hp = data["hero_hp_" .. pos]

			if unit and hp then
				unit:jumpWord(hp, "font_dmg_")
				unit:hurtAnimation()
			end
		end
	end

	if global.player then
		if empty(trapHeroDelay) then
			doHurt()
		else
			Looper.setTimeout(doHurt, trapHeroDelay, global.player)
		end
	end
end

function InfoDungeon.checkAllDie()
	local allDie = true

	for i = 1, GameConfig.hero_team_num do
		local hero = TeamManager.getHeroByPos(i)

		if hero and hero.battleData.hp > 0 then
			allDie = false

			break
		end
	end

	return allDie
end

function InfoDungeon.uploadHeroHP(params)
	for i = 1, GameConfig.hero_team_num do
		local hero = TeamManager.getHeroByPos(i)

		if hero then
			params["hero_hp_" .. i] = hero.battleData.hp
			params["hero_dmg_" .. i] = DmgCount.getHeroDmg(hero.info.id)
		end
	end
end

function InfoDungeon.goHome(eventIndex, onSuccess, onFailure)
	local abyssLevel = InfoDungeon.getLevel()

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			InfoDungeon.clearGap()
			InfoDungeon.clearShrine()

			if CONFIG.is_ta and InfoDungeon.inDungeon() and type == TYPE.ABYSS then
				local dungeonData = InfoDungeon.getDungeonCSV()
				local currentLayer = dungeonData.layer

				if rcvData.enter_layer < currentLayer then
					local isFirst = rcvData.enter_max_layer <= rcvData.enter_layer
					local params = {
						dungeon_id = dungeonID,
						is_first_start = isFirst,
						hero_info = TaHelper.getHeroInfoAll(),
						dungeon_duration = rcvData.time_used
					}

					if TaHelper.warnTeamScore then
						local warnValue = TaHelper.warnTeamScore(abyssLevel, InfoHero.getTeamScore())

						if warnValue then
							params.warn_score = warnValue
						end
					end

					TaHelper.taTrack("dungeon_win", params)
				end
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("dungeon_abyss_home", {
		map_index = InfoDungeon.getMapIndex(),
		event_index = eventIndex
	}, callback)
end

function InfoDungeon.goNext(eventIndex, layer, onSuccess, onFailure)
	if Transition.isOpening() then
		return
	end

	local nowTime = Time.time()

	if global.goNextLockedTime and nowTime < global.goNextLockedTime then
		return
	end

	global.goNextLockedTime = nowTime + 1

	local function callback(rcvData)
		notify.dispatch("exit_map")

		if rcvData.err then
			Log.debug("InfoDungeon.enter callback Failure", rcvData.err)

			if rcvData.err == "some_err" then
				if not Transition.isOpening() then
					InfoDungeon.retry()
				end
			elseif onFailure then
				onFailure(rcvData.err)
			end
		else
			InfoDungeon.clearGap()

			local title, subTitle = InfoDungeon.getTitle(rcvData.type, rcvData.dungeon_id, rcvData.quest_id, rcvData.abyss_seed)

			Transition.setTitle(title, subTitle)
			Transition.leave(function ()
				InfoDungeon.makeMaps(rcvData)

				if onSuccess then
					onSuccess(rcvData)
				end
			end)

			abyssMaxLayer = rcvData.abyss_max_layer
			abyssMaxLevel = rcvData.abyss_max_level
		end
	end

	InfoDungeon.isAbyssEnter = nil
	local score = InfoHero.getTeamScore()

	Connection.request("dungeon_abyss_next", {
		map_index = InfoDungeon.getMapIndex(),
		event_index = eventIndex,
		layer = layer,
		score = score
	}, callback)
end

function InfoDungeon.checkRecover()
	local hasRecover = false
	local isRetreat = false
	local dungeonData = nil

	if queryInfo then
		hasRecover = queryInfo.type ~= nil and queryInfo.dungeon_id ~= "0"

		if hasRecover then
			dungeonData = InfoDungeon.getDungeonCSV(queryInfo.type, queryInfo.dungeon_id, queryInfo.quest_id, queryInfo.abyss_seed)

			if queryInfo.type == TYPE.QUEST then
				isRetreat = queryInfo.pass_count < queryInfo.pass_total
			elseif queryInfo.type == TYPE.ABYSS then
				isRetreat = true
			end
		end
	end

	return hasRecover, isRetreat, dungeonData, queryInfo
end

function InfoDungeon.getQueryInfo()
	return queryInfo
end

function InfoDungeon.dungeon_check_version(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "dungeon_check_version")

		if rcvData.err then
			Log.debug("InfoDungeon.enter callback Failure", rcvData.err)

			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("dungeon_check_version", callback)
end

function InfoDungeon.reload(onlineData)
	InfoDungeon.query(function ()
		InfoDungeon.retry(onlineData)
	end)
end

function InfoDungeon.retry(onlineData)
	local function onSuccess(rcvData)
		Monster.noCheckBattle = nil

		DramaManager.clearOnRetry()
		WarMachine.clearOnRetry()

		if CONFIG.is_ta and onlineData and rcvData.type == TYPE.STAGE and rcvData.stage_type == STAGE_TYPE.tower then
			local params = {
				stage_id = rcvData.dungeon_id,
				hero_info = TaHelper.getHeroInfoAll(),
				player_num = onlineData.total
			}

			TaHelper.taTrack("team_challenge", params)
		end

		DungeonScene.enterDungeon(DungeonScene.ENTER_TYPE.RETRY, rcvData, onlineData)
	end

	InfoDungeon.recover(onSuccess)
end

function InfoDungeon.recover(onSuccess, onFailure)
	Log.debug("InfoDungeon.recover", dungeonID)

	local function callback(rcvData)
		notify.dispatch("exit_map")
		dump(rcvData, "dungeon_recover")

		if rcvData.err then
			Log.debug("InfoDungeon.enter callback Failure", rcvData.err)

			if onFailure then
				onFailure(rcvData.err)
			end
		else
			local title, subTitle = nil

			if not empty(queryInfo.gap_id) then
				title, subTitle = InfoDungeon.getTitle(TYPE.STAGE, queryInfo.gap_id)
			else
				title, subTitle = InfoDungeon.getTitle(queryInfo.type, queryInfo.dungeon_id, queryInfo.quest_id, queryInfo.abyss_seed)
			end

			Transition.setTitle(title, subTitle)
			Transition.leave(function ()
				InfoDungeon.makeMaps(rcvData)
				InfoDungeon.makeGapMaps(rcvData)

				if onSuccess then
					onSuccess(rcvData)
				end
			end)
		end
	end

	Connection.request("dungeon_recover", callback)
end

function InfoDungeon.recoverOnReconnect(onSuccess, onFailure)
	local type = queryInfo.type
	local dungeonID = queryInfo.dungeon_id
	local questID = queryInfo.quest_id
	local maps = InfoDungeon.getDungeonMaps(type, dungeonID, questID, queryInfo.abyss_seed)

	Log.debug("InfoDungeon.recoverOnReconnect", dungeonID)

	local function callback(rcvData)
		dump(rcvData, "recoverOnReconnect")

		if rcvData.err then
			Log.debug("InfoDungeon.enter callback Failure", rcvData.err)

			if onFailure then
				onFailure(rcvData.err)
			end
		else
			session = rcvData.session

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("dungeon_recover", callback)
end

function InfoDungeon.saveTeamState(isAll, data, isTopChanged, onSuccess, onFailure)
	if not dungeonID then
		return
	end

	if InfoDungeon.isFixedTeam() then
		return
	end

	if InfoDungeon.inGap() then
		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	local params = {
		is_all = isAll and 1 or 0,
		state = data,
		is_top = isTopChanged and 1 or 0
	}

	if InfoDungeon.getType() == TYPE.ABYSS then
		local dungeonData = InfoDungeon.getDungeonCSV()
		params.abyss_layer = dungeonData.layer
	end

	Connection.request("dungeon_state", params, callback)
end

function InfoDungeon.enter(type, info, onSuccess, onFailure)
	local count, countMax = InfoEquip.count()

	if countMax <= count then
		Alert.open(Localization.getSrcText("装备数量达到上限，请先处理"))

		return
	end

	local count, countMax = InfoSigil.count()

	if countMax <= count then
		Alert.open(Localization.getSrcText("魔纹数量达到上限，请先处理"))

		return
	end

	local function callback(rcvData)
		notify.dispatch("exit_map")
		dump(rcvData, "dungeon_enter")

		if rcvData.err then
			Log.debug("InfoDungeon.enter callback Failure", rcvData.err)

			if onFailure then
				onFailure(rcvData.err)
			end
		else
			InfoDungeon.clearGap()

			local title, subTitle = InfoDungeon.getTitle(rcvData.type, rcvData.dungeon_id, rcvData.quest_id, rcvData.abyss_seed)

			Transition.setTitle(title, subTitle)
			Transition.leave(function ()
				InfoDungeon.makeMaps(rcvData)

				if onSuccess then
					onSuccess(rcvData)
				end
			end)

			if CONFIG.is_ta then
				if type == TYPE.QUEST then
					local csv = CsvParser.getCsvData("quest", info.base_id)
					local params = {
						quest_id = info.base_id,
						quest_star = csv.star
					}

					TaHelper.taTrack("quest_start", params)
				elseif type == TYPE.TASK then
					-- Nothing
				elseif type == TYPE.ABYSS then
					local maxLayer = InfoDungeon.getAbyssMaxLayer()
					local isFirst = maxLayer <= info.layer
					local params = {
						dungeon_id = info.dungeon_id,
						is_first_start = isFirst,
						hero_info = TaHelper.getHeroInfoAll()
					}

					TaHelper.taTrack("dungeon_start", params)
				end
			end
		end
	end

	local params = {
		type = type,
		layer = info.layer,
		quest_id = info.id,
		speedup = info.speedup,
		akasa_level = info.akasa_level
	}

	if type == TYPE.ABYSS and InfoDungeon.getType() ~= TYPE.ABYSS then
		InfoDungeon.isAbyssEnter = true
	else
		InfoDungeon.isAbyssEnter = nil
	end

	InfoDungeon.isAbyssExit = nil

	Connection.request("dungeon_enter", params, callback)
end

function InfoDungeon.exit(safe_type, onSuccess, onFailure)
	local abyssLevel = InfoDungeon.getLevel()

	local function callback(rcvData)
		notify.dispatch("exit_map")
		dump(rcvData, "dungeon_exit")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			InfoDungeon.clearGap()
			InfoDungeon.clearShrine()

			if CONFIG.is_ta and InfoDungeon.inDungeon() then
				if type == TYPE.ABYSS then
					local trackName = nil

					if safe_type > 0 then
						trackName = "dungeon_win"
					else
						trackName = "dungeon_lose"
					end

					local dungeonData = InfoDungeon.getDungeonCSV()
					local currentLayer = dungeonData.layer
					local maxLayer = InfoDungeon.getAbyssMaxLayer()

					if rcvData.enter_layer < currentLayer then
						local isFirst = rcvData.enter_max_layer <= rcvData.enter_layer
						local params = {
							dungeon_id = dungeonID,
							is_first_start = isFirst,
							hero_info = TaHelper.getHeroInfoAll(),
							dungeon_duration = rcvData.time_used
						}

						if TaHelper.warnTeamScore then
							local warnValue = TaHelper.warnTeamScore(abyssLevel, InfoHero.getTeamScore())

							if warnValue then
								params.warn_score = warnValue
							end
						end

						TaHelper.taTrack(trackName, params)
					end
				elseif type == TYPE.STAGE then
					if stageType == STAGE_TYPE.WILD then
						local params = {
							stage_id = dungeonID,
							hero_info = TaHelper.getHeroInfoAll(),
							dungeon_duration = rcvData.time_used
						}

						TaHelper.taTrack("world_lose", params)
					elseif stageType == STAGE_TYPE.tower then
						local params = {
							stage_id = dungeonID,
							hero_info = TaHelper.getHeroInfoAll(),
							dungeon_duration = rcvData.time_used
						}

						TaHelper.taTrack("team_lose", params)
					end
				end
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	local score = InfoHero.getTeamScore()

	Connection.request("dungeon_exit", {
		safe_type = safe_type,
		score = score
	}, callback)
end

function InfoDungeon.checkGuide(id)
	if preCompleteEventInfo then
		local eventData = preCompleteEventInfo.data
		local eventInfo = ConfParser.parse(eventData.info)
		local guideArr = string.split(tostring(eventInfo.new_guide), ",")

		for i, guideStr in ipairs(guideArr) do
			if guideStr == tostring(id) then
				return true
			end
		end
	end

	return false
end

function InfoDungeon.finishMonsterDrama(eventIndex, onSuccess, onFailure, notResumeDrama)
	InfoDungeon.finishMonster(eventIndex, onSuccess, onFailure, notResumeDrama, true)
end

function InfoDungeon.getBattleHash(eventIndex, isDrama)
	local warnCount, sumStack = WarMachine.getCheckSum()
	local attrCheckCount, attrCheckMap = WarMachine.getCheckAttr()
	local newCheckMap = {}
	local modaoLevelMap = {}

	for heroID, data in pairs(attrCheckMap) do
		if data.ty == 1 or data.ty == 3 then
			local obj = {
				ct = data.ct,
				cte = data.cte,
				id = data.id,
				ty = data.ty,
				attrs = ""
			}

			if data.attrs then
				for i, v in ipairs(data.attrs) do
					if i > 1 then
						obj.attrs = obj.attrs .. ","
					end

					if v ~= 0 then
						obj.attrs = obj.attrs .. v
					end
				end
			end

			newCheckMap[heroID] = obj
		elseif data.ty == 10 then
			modaoLevelMap[tostring(data.id)] = data.level
		end
	end

	local hashObj = {
		a = warnCount,
		b = sumStack,
		c = attrCheckCount,
		d = newCheckMap,
		e = modaoLevelMap
	}

	if isDrama then
		hashObj.z = 1
	end

	local hashstr = json.encode(hashObj)
	local key = crypto.md5(session .. eventIndex)
	key = string.sub(key, 7, 11)
	local hash = crypto.encryptXXTEA(hashstr, key)

	return hash
end

function InfoDungeon.finishMonsterYD(maxClass, eventIndex, onSuccess, onFailure, notResumeDrama, isDrama, isRetry, onHashFail)
	InfoDungeon.finishMonster(eventIndex, onSuccess, onFailure, notResumeDrama, isDrama, isRetry, onHashFail)

	if CONFIG.is_yd and maxClass >= 10 then
		YdHelper.check(1, true)
	end
end

function InfoDungeon.finishMonster(eventIndex, onSuccess, onFailure, notResumeDrama, isDrama, isRetry, onHashFail)
	print("$$$ InfoDungeon.finishMonster", eventIndex)

	if not eventIndex then
		onSuccess()

		return
	end

	if InfoDungeon.checkAllDie() then
		WarMachine.showBattleLose()

		return
	end

	local function callback(rcvData)
		dump(rcvData, "dungeon_finish_monster " .. Time.formatHour(Time.now()), 10)

		if rcvData.err then
			if rcvData.err == "doBattle_err_check_hash" then
				POP_confirm.open(Localization.getSrcText("检测到战斗异常，请重试"), function ()
					InfoDungeon.retry()
				end, Localization.getSrcText("重试"))

				if onHashFail then
					onHashFail(rcvData.err)
				end
			elseif rcvData.err == "dungeon_finish_monster_no_hash" then
				POP_confirm.open(Localization.getSrcText("版本已更新，请重新进入游戏"), function ()
					app.exit()
				end, Localization.getSrcText("退出"))
			else
				if rcvData.session then
					session = rcvData.session
				end

				if onFailure then
					onFailure(rcvData.err)
				end
			end
		else
			InfoDungeon.onEventComplete(eventIndex, rcvData)

			local stageType, stageID = InfoDungeon.getStage()
			local usedMap = {}

			for k, v in pairs(runeMap) do
				if v.used > 0 then
					if not usedMap[v.base_id] then
						usedMap[v.base_id] = v.used
					else
						usedMap[v.base_id] = usedMap[v.base_id] + v.used
					end
				end
			end

			for base_id, num in pairs(usedMap) do
				TaHelper.taTrack("item_use", {
					item_id = base_id,
					item_num = num,
					dungeon_type = InfoDungeon.getType(),
					dungeon_level = InfoDungeon.getLevel(),
					stage_id = stageID
				})
			end

			if onSuccess then
				onSuccess(rcvData)
			end

			notify.dispatch("monster_fin")
		end
	end

	if isRetry and InfoDungeon.dungeon_finish_monster_params then
		local params = ObjUtil.clone(InfoDungeon.dungeon_finish_monster_params)
		params.redun = ""
		local len = math.random(16, 32)

		for i = 1, len do
			params.redun = params.redun .. tostring(math.random(1, 9))
		end

		params.hash = InfoDungeon.getBattleHash(eventIndex, isDrama)

		Connection.request("dungeon_finish_monster", params, callback)

		return
	end

	local eventInfo = nil

	if InfoDungeon.inGap() then
		eventInfo = gap_eventInfoMap[gap_currentMapIndex][eventIndex]
	else
		eventInfo = eventInfoMap[currentMapIndex][eventIndex]
	end

	local eventData = eventInfo.data
	local hash = InfoDungeon.getBattleHash(eventIndex, isDrama)
	local teamState = DungeonState.getState()
	local item_used = InfoBag.getRuneIndexArr(runeMap)
	local params = {
		hash = hash,
		map_index = InfoDungeon.getMapIndex(),
		event_index = eventIndex,
		state = teamState,
		item_used = item_used
	}

	InfoDungeon.uploadHeroHP(params)

	local currentMp = InfoModao.getMp()
	params.modao_mp = currentMp

	if InfoGuide.getFreeRecord(4) == 0 then
		TaHelper.taGuideDetail(11600)
	end

	InfoDungeon.dungeon_finish_monster_params = ObjUtil.clone(params)

	Connection.request("dungeon_finish_monster", params, callback)
end

function InfoDungeon.onEventsetSelect(eventIndex, eventsetIndex)
	local eventInfo = nil

	if InfoDungeon.inGap() then
		eventInfo = gap_eventInfoMap[gap_currentMapIndex][eventIndex]
	else
		eventInfo = eventInfoMap[currentMapIndex][eventIndex]
	end

	eventInfo.set_index = eventsetIndex

	if global.player then
		global.player:npcChanged(true)
	end
end

function InfoDungeon.onEventComplete(eventIndex, rcvData)
	local inGap = InfoDungeon.inGap()
	local eventInfo = nil

	if inGap then
		eventInfo = gap_eventInfoMap[gap_currentMapIndex][eventIndex]
	else
		eventInfo = eventInfoMap[currentMapIndex][eventIndex]
	end

	local eventData = eventInfo.data
	preCompleteEventInfo = eventInfo
	eventInfo.fin = rcvData.fin or 1

	if rcvData.pass_count then
		local prePassCount = passCount
		passCount = rcvData.pass_count

		if passCount ~= prePassCount then
			notify.dispatch("pass_changed")
		end
	end

	if rcvData.relic then
		if inGap then
			if not gap_relicData[gap_currentMapIndex] then
				gap_relicData[gap_currentMapIndex] = {}
			end

			gap_relicData[gap_currentMapIndex][eventIndex] = rcvData.relic

			if gap_relicData[gap_currentMapIndex][eventIndex] then
				InfoDungeon.addRelic(true, eventIndex, gap_relicData[gap_currentMapIndex][eventIndex], true)
			end
		else
			if not relicData[currentMapIndex] then
				relicData[currentMapIndex] = {}
			end

			relicData[currentMapIndex][eventIndex] = rcvData.relic

			if relicData[currentMapIndex][eventIndex] then
				InfoDungeon.addRelic(false, eventIndex, relicData[currentMapIndex][eventIndex], true)
			end
		end
	end

	if rcvData.shrine then
		shrineData = {}

		if rcvData.shrine then
			for i, v in ipairs(rcvData.shrine) do
				shrineData[v.index] = v
			end
		end

		InfoDungeon.refreshShrine()
	end

	MapEventManager.linkTrigger(eventData)
	ManagerInfo.dataChange("dungeon")
end

function InfoDungeon.getEventInfo(eventIndex)
	if InfoDungeon.inGap() then
		if gap_eventInfoMap[gap_currentMapIndex] and gap_eventInfoMap[gap_currentMapIndex][eventIndex] then
			return gap_eventInfoMap[gap_currentMapIndex][eventIndex]
		end
	elseif eventInfoMap[currentMapIndex] and eventInfoMap[currentMapIndex][eventIndex] then
		return eventInfoMap[currentMapIndex][eventIndex]
	end

	return {
		seed = 1,
		fin = 0
	}
end

function InfoDungeon.isPassed()
	local questData = nil

	if InfoDungeon.getType() == TYPE.QUEST then
		questData = CsvParser.getCsvData("quest", questID)
	elseif InfoDungeon.getType() == TYPE.TASK then
		questData = CsvParser.getCsvData("task_quest", questID)
	end

	if questData and questData.type == 1 then
		return math.floor(passCount / passTotal * 100) >= 90, passCount, passTotal
	else
		return passTotal <= passCount, passCount, passTotal
	end
end

function InfoDungeon.getProgressStr()
	local questData = nil

	if InfoDungeon.getType() == TYPE.QUEST then
		questData = CsvParser.getCsvData("quest", questID)
	elseif InfoDungeon.getType() == TYPE.TASK then
		questData = CsvParser.getCsvData("task_quest", questID)
	end

	if questData and questData.type == 1 then
		return math.floor(passCount / passTotal * 100) .. "%"
	else
		return passCount .. "/" .. passTotal
	end
end

function InfoDungeon.setData(key, value)
	lifeData[key] = value
end

function InfoDungeon.getData(key)
	return lifeData[key]
end

function InfoDungeon.isOpen(dungeonID)
	return true
end

function InfoDungeon.inLevelRange(min, max)
	if not dungeonID then
		return false
	end

	local dungeonData = InfoDungeon.getDungeonCSV()

	if min <= dungeonData.level and dungeonData.level <= max then
		return true
	end

	return false
end

function InfoDungeon.getGatherInfo(eventIndex, eventsetIndex, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if rcvData.eventset_index then
				InfoDungeon.onEventsetSelect(eventIndex, rcvData.eventset_index)
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("dungeon_get_gather_info", {
		map_index = InfoDungeon.getMapIndex(),
		event_index = eventIndex,
		eventset_index = eventsetIndex
	}, callback)
end

function InfoDungeon.getGather(eventIndex, bagInfo, eventsetIndex, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if rcvData.eventset_index then
				InfoDungeon.onEventsetSelect(eventIndex, rcvData.eventset_index)
			end

			InfoDungeon.onEventComplete(eventIndex, rcvData)
			notify.dispatch("top_map_refresh")

			if onSuccess then
				onSuccess(rcvData)
			end

			notify.dispatch("guide_rantile")
		end
	end

	local teamState = DungeonState.getState()

	Connection.request("dungeon_get_gather", {
		map_index = InfoDungeon.getMapIndex(),
		event_index = eventIndex,
		eventset_index = eventsetIndex,
		bag = bagInfo,
		state = teamState
	}, callback)
end

function InfoDungeon.getShrine(eventIndex, eventsetIndex, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "dungeon_get_shrine", 10)

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if rcvData.eventset_index then
				InfoDungeon.onEventsetSelect(eventIndex, rcvData.eventset_index)
			end

			InfoDungeon.onEventComplete(eventIndex, rcvData)
			notify.dispatch("top_map_refresh")

			if onSuccess then
				onSuccess(rcvData)
			end

			notify.dispatch("guide_rantile")
		end
	end

	local teamState = DungeonState.getState()

	Connection.request("dungeon_get_shrine", {
		map_index = InfoDungeon.getMapIndex(),
		event_index = eventIndex,
		eventset_index = eventsetIndex,
		state = teamState
	}, callback)
end

function InfoDungeon.getShrineData()
	return shrineData
end

function InfoDungeon.getUnionBuff()
	if InfoDungeon.inDungeon() then
		return unionBuffData or {}
	else
		return {}
	end
end

function InfoDungeon.getLuckyShrineList()
	local sortArr = {}
	local shrine_max = InfoDungeon.getShrineMax()

	for k, v in pairs(shrineData) do
		local index = tonumber(k)

		if shrine_max < index then
			table.insert(sortArr, {
				index = index,
				data = v
			})
		end
	end

	table.sort(sortArr, function (a, b)
		return a.index < b.index
	end)

	local arr = {}

	for i, v in ipairs(sortArr) do
		table.insert(arr, v.data)
	end

	return arr
end

function InfoDungeon.getShrineMax()
	local shrine_max = CsvParser.getCsvData("config", "battle_buff_num").value
	local mirrorData = InfoMirror.getCurrent(8)

	if mirrorData and not empty(mirrorData.value1) then
		shrine_max = shrine_max + mirrorData.value1
	end

	return shrine_max
end

function InfoDungeon.removeShrine(shrineInfo, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "dungeon_shrine_remove", 10)

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			shrineData[shrineInfo.index] = nil

			InfoDungeon.refreshShrine()

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("dungeon_shrine_remove", {
		index = shrineInfo.index
	}, callback)
end

function InfoDungeon.refreshShrine()
	TeamManager.refreshTeamShrineBuff()
	notify.dispatch("shrine_changed")
end

function InfoDungeon.clearShrine()
	shrineData = {}

	TeamManager.refreshTeamShrineBuff()
	notify.dispatch("shrine_changed")
end

function InfoDungeon.countShrine(typeMap)
	local count = 0

	for k, v in pairs(shrineData) do
		local buffCSV = CsvParser.getCsvData("buff", v.id)

		if not typeMap or typeMap[buffCSV.buff_type] then
			count = count + 1
		end
	end

	return count
end

function InfoDungeon.getDropItem(eventIndex, itemMap, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if onSuccess then
				onSuccess(rcvData)
			end

			notify.dispatch("guide_rantile")
		end
	end

	local items = {}

	for k, v in pairs(itemMap) do
		table.insert(items, {
			base_id = k,
			num = v
		})
	end

	Connection.request("dungeon_get_drop_item", {
		map_index = InfoDungeon.getMapIndex(),
		event_index = eventIndex,
		items = items
	}, callback)
end

function InfoDungeon.chanceDropItems(npc, drop_items)
	if npc and npc.map and drop_items and #drop_items > 0 then
		npc:popItems(drop_items, true)
	end
end

function InfoDungeon.getChance(npc, eventIndex, params, onSuccess, onFailure)
	params = params or {}
	local eventsetIndex = npc.eventsetIndex
	local eventInfo = nil

	if InfoDungeon.inGap() then
		eventInfo = gap_eventInfoMap[gap_currentMapIndex][eventIndex]
	else
		eventInfo = eventInfoMap[currentMapIndex][eventIndex]
	end

	local eventData = eventInfo.data
	local info = ConfParser.parse(eventData.info)
	local chanceID = nil

	if info.id then
		chanceID = info.id
	else
		local random = Random.new(eventData.seed)
		local drop_rare = 0
		chanceID = DropManager.dropLibChance(info.drop_id, InfoDungeon.getLevel(), drop_rare, random)
	end

	local chanceCSV = nil

	if not eventsetIndex then
		chanceCSV = CsvParser.getCsvData("chance", chanceID)
	end

	if not eventsetIndex and (chanceCSV.type == 7 or chanceCSV.type == 11 and params.type == 1) and InfoDungeon.checkAllDie() then
		WarMachine.showBattleLose()

		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if rcvData.err == "doBattle_err_check_hash" then
				POP_confirm.open(Localization.getSrcText("检测到战斗异常，请重试"), function ()
					InfoDungeon.retry()
				end, Localization.getSrcText("重试"))
			else
				if rcvData.session then
					session = rcvData.session
				end

				if onFailure then
					onFailure(rcvData.err)
				end
			end
		else
			if not eventsetIndex and (chanceCSV.type == 7 or chanceCSV.type == 11 and params.type == 1) then
				local stageType, stageID = InfoDungeon.getStage()
				local usedMap = {}

				for k, v in pairs(runeMap) do
					if v.used > 0 then
						if not usedMap[v.base_id] then
							usedMap[v.base_id] = v.used
						else
							usedMap[v.base_id] = usedMap[v.base_id] + v.used
						end
					end
				end

				for base_id, num in pairs(usedMap) do
					TaHelper.taTrack("item_use", {
						item_id = base_id,
						item_num = num,
						dungeon_type = InfoDungeon.getType(),
						dungeon_level = InfoDungeon.getLevel(),
						stage_id = stageID
					})
				end
			end

			if rcvData.eventset_index then
				InfoDungeon.onEventsetSelect(eventIndex, rcvData.eventset_index)
			end

			npc:refreshEventset()
			InfoDungeon.onEventComplete(eventIndex, rcvData)
			InfoDungeon.chanceDropItems(npc, rcvData.drop_items)
			notify.dispatch("top_map_refresh")

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	local teamState = DungeonState.getState()
	local requestParams = {
		map_index = InfoDungeon.getMapIndex(),
		event_index = eventIndex,
		eventset_index = eventsetIndex,
		params = json.encode(params),
		state = teamState
	}

	if not eventsetIndex and (chanceCSV.type == 7 or chanceCSV.type == 11 and params.type == 1) then
		local item_used = InfoBag.getRuneIndexArr(runeMap)
		requestParams.item_used = item_used

		InfoDungeon.uploadHeroHP(requestParams)

		local currentMp = InfoModao.getMp()
		requestParams.modao_mp = currentMp
		requestParams.hash = InfoDungeon.getBattleHash(eventIndex)
	end

	Connection.request("dungeon_get_chance", requestParams, callback)
end

function InfoDungeon.getHeroTemp(eventIndex, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "dungeon_get_hero_temp", 10)

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			InfoDungeon.onEventComplete(eventIndex, rcvData)

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	local teamState = DungeonState.getState()

	Connection.request("dungeon_get_hero_temp", {
		map_index = InfoDungeon.getMapIndex(),
		event_index = eventIndex,
		state = teamState
	}, callback)
end

function InfoDungeon.getRelicInfo(eventIndex, relicIndex, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("dungeon_get_relic_info", {
		map_index = InfoDungeon.getMapIndex(),
		event_index = eventIndex,
		relic_index = relicIndex
	}, callback)
end

function InfoDungeon.getRelic(eventIndex, relicIndex, bagInfo, onSuccess, onFailure)
	local relicID = InfoDungeon.getRelicID(eventIndex, relicIndex)
	local relicCSV = CsvParser.getCsvData("relic", relicID)
	local isFinal = false
	local _finalRelic = InfoDungeon.getFinalRelic(eventIndex)

	if _finalRelic and _finalRelic.index == relicIndex then
		isFinal = true
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if relicCSV.type == Npc.RELIC_TYPE.BLOOD then
				local heros = TeamManager.getTeam()

				for i, hero in ipairs(heros) do
					if hero.battleData.hp > 0 then
						if not empty(relicCSV.hero_effect) then
							local effectGen = hero:getEffectGen()

							if effectGen then
								effectGen:castEffect(relicCSV.hero_effect, hero)
							end
						end

						local hpMax = hero.attrs.hp
						local addHp = hpMax * relicCSV.value1 / 100 + relicCSV.value2
						local mirrorData = InfoMirror.getCurrent(1)

						if mirrorData then
							if not empty(mirrorData.value1) then
								addHp = addHp + hpMax * mirrorData.value1 / 100
							end

							if not empty(mirrorData.value2) then
								addHp = addHp + mirrorData.value2
							end
						end

						local healball_dmgadd = hero.attrs.healball_dmgadd

						if healball_dmgadd ~= 0 then
							addHp = addHp * (1 + healball_dmgadd / 100)
						end

						hero:jumpWord(math.floor(addHp), "font_heal_", 0, 30)
					end
				end
			end

			local _relicData = InfoDungeon.getRelicData(eventIndex, relicIndex)

			print("$$$ _relicData", _relicData)

			if _relicData then
				_relicData.fin = 1
			end

			if isFinal then
				local unitList = ClipOnMap.getUnitList("npc")

				for _, unit in ipairs(unitList) do
					if unit.eventData and unit.eventData.index == eventIndex and unit:isGladiator() then
						unit:refreshGladiator(true)
					end
				end
			end

			if not empty(rcvData.gap_id) then
				local title, subTitle = InfoDungeon.getTitle(TYPE.STAGE, rcvData.gap_id)

				Transition.setTitle(title, subTitle)
				Transition.leave(function ()
					InfoDungeon.makeGapMaps(rcvData)

					if onSuccess then
						onSuccess(rcvData)
					end
				end)

				return
			end

			if onSuccess then
				onSuccess(rcvData)
			end

			notify.dispatch("guide_rantile")
		end
	end

	local teamState = DungeonState.getState()
	local params = {
		map_index = InfoDungeon.getMapIndex(),
		event_index = eventIndex,
		relic_index = relicIndex,
		bag = bagInfo,
		state = teamState
	}

	Connection.request("dungeon_get_relic", params, callback)
end

function InfoDungeon.removeBlood(eventIndex, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			local indexMap = {}

			for i, v in ipairs(rcvData.list) do
				indexMap[v.index] = true
			end

			local unitList = ClipOnMap.getUnitList("npc")

			for _, unit in ipairs(unitList) do
				if unit.npcType == Npc.TYPE.RELIC and indexMap[unit.relicIndex] then
					unit:relicDestroy(true)
				end
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("dungeon_remove_blood", {
		map_index = InfoDungeon.getMapIndex(),
		event_index = eventIndex
	}, callback)
end

function InfoDungeon.addRelicAll()
	if InfoDungeon.inGap() then
		for mapIndex, mapRelic in pairs(gap_relicData) do
			if gap_currentMapIndex == mapIndex then
				for eventIndex, relics in pairs(mapRelic) do
					InfoDungeon.addRelic(true, eventIndex, relics)
				end
			end
		end
	else
		for mapIndex, mapRelic in pairs(relicData) do
			if currentMapIndex == mapIndex then
				for eventIndex, relics in pairs(mapRelic) do
					InfoDungeon.addRelic(false, eventIndex, relics)
				end
			end
		end
	end
end

function InfoDungeon.addRelic(isGap, eventIndex, relics, isNew)
	local eventInfo = nil

	print("$$$ addRelic", isGap, eventIndex)

	if isGap then
		if gap_eventInfoMap[gap_currentMapIndex] then
			eventInfo = gap_eventInfoMap[gap_currentMapIndex][eventIndex]
		end
	elseif eventInfoMap[currentMapIndex] then
		eventInfo = eventInfoMap[currentMapIndex][eventIndex]
	end

	if not eventInfo then
		return
	end

	local eventData = eventInfo.data
	local eventRect = cc.rect(eventData.x, eventData.y, eventData.w, eventData.h)
	local hubData = MapEventManager.findLinkOne(eventData, "hub")

	if hubData then
		local info = ConfParser.parse(eventData.info)

		if info.hub_pos == 1 then
			eventRect = cc.rect(hubData.x, hubData.y, hubData.w, hubData.h)
		end
	end

	local posArr = MapUtils.getRelicPositions(eventRect, eventInfo.seed, relics)
	local now = Time.now()
	local preIndex = eventInfo.relicIndex or 0

	for relicIndex, relicObj in ipairs(relics) do
		if preIndex < relicIndex then
			if relicObj.fin == 0 and (empty(relicObj.time) or now < relicObj.time) then
				if relicObj.is_final == 1 then
					relicObj.index = relicIndex

					InfoDungeon.addFinalRelic(eventIndex, relicObj, isNew)
				else
					local relicID = relicObj.id
					local relicCSV = CsvParser.getCsvData("relic", relicID)
					local disabled = false

					if relicCSV.type == Npc.RELIC_TYPE.GAP and InfoParams.getValue("dungeon_gap") ~= 1 then
						disabled = true
					end

					if not disabled then
						local pos = posArr[relicIndex]

						if not pos then
							break
						end

						local function showRelic()
							local relic = Npc.new()

							relic:setRelicID(relicID, eventIndex, relicIndex, relicObj.time)
							relic:display(global.map, pos.x, pos.y)

							if isNew then
								relic:bornEffect()
							end
						end

						if isNew then
							Looper.setTimeout(showRelic, 30, global.map)
						else
							showRelic()
						end
					end
				end
			end

			eventInfo.relicIndex = relicIndex
		end
	end
end

function InfoDungeon.getRelicData(eventIndex, relicIndex)
	print("$$$ InfoDungeon.getRelicData", InfoDungeon.inGap())

	if InfoDungeon.inGap() then
		if gap_relicData[gap_currentMapIndex] and gap_relicData[gap_currentMapIndex][eventIndex] and gap_relicData[gap_currentMapIndex][eventIndex][relicIndex] then
			return gap_relicData[gap_currentMapIndex][eventIndex][relicIndex]
		end
	elseif relicData[currentMapIndex] and relicData[currentMapIndex][eventIndex] and relicData[currentMapIndex][eventIndex][relicIndex] then
		return relicData[currentMapIndex][eventIndex][relicIndex]
	end
end

function InfoDungeon.getRelicID(eventIndex, relicIndex)
	print("$$$ InfoDungeon.getRelicID", InfoDungeon.inGap())

	if InfoDungeon.inGap() then
		if gap_relicData[gap_currentMapIndex] and gap_relicData[gap_currentMapIndex][eventIndex] and gap_relicData[gap_currentMapIndex][eventIndex][relicIndex] then
			return gap_relicData[gap_currentMapIndex][eventIndex][relicIndex].id
		end
	elseif relicData[currentMapIndex] and relicData[currentMapIndex][eventIndex] and relicData[currentMapIndex][eventIndex][relicIndex] then
		return relicData[currentMapIndex][eventIndex][relicIndex].id
	end
end

function InfoDungeon.addFinalRelic(eventIndex, relicObj, isNew)
	if InfoDungeon.inGap() then
		gap_finalRelic[eventIndex] = relicObj
	else
		finalRelic[eventIndex] = relicObj
	end

	local unitList = ClipOnMap.getUnitList("npc")

	for _, unit in ipairs(unitList) do
		if unit.eventData and unit.eventData.index == eventIndex and unit:isGladiator() then
			unit:refreshGladiator(isNew)
		end
	end
end

function InfoDungeon.getFinalRelic(eventIndex)
	if InfoDungeon.inGap() then
		return gap_finalRelic[eventIndex]
	else
		return finalRelic[eventIndex]
	end
end

function InfoDungeon.removeFinalRelic(eventIndex)
	if InfoDungeon.inGap() then
		gap_finalRelic[eventIndex] = nil
	else
		finalRelic[eventIndex] = nil
	end
end

function InfoDungeon.getMerchantInfo(eventIndex, type, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			InfoShop.onGetShopList(type, rcvData.items)

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	local teamState = DungeonState.getState()

	Connection.request("dungeon_get_merchant_info", {
		map_index = InfoDungeon.getMapIndex(),
		event_index = eventIndex,
		state = teamState,
		type = type
	}, callback)
end

function InfoDungeon.getMerchant(eventIndex, type, shop_id, onSuccess, onFailure)
	if CONFIG.is_ta then
		local shopCSV = CsvParser.getCsvData("shop", shop_id)

		if shopCSV.product_id == GameConfig.tp_item then
			TaHelper.startAsset("dungeon_get_merchant_2")
		else
			TaHelper.startAsset("dungeon_get_merchant_1")
		end
	end

	local preIndex = InfoShop.getRefreshIndex(type)

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if rcvData.item then
				local item = rcvData.item

				InfoShop.onBuyItem(type, item, preIndex)
			end

			if CONFIG.is_ta then
				TaHelper.endAsset()
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("dungeon_get_merchant", {
		map_index = InfoDungeon.getMapIndex(),
		event_index = eventIndex,
		type = type,
		shop_id = shop_id
	}, callback)
end

function InfoDungeon.checkExit()
	local function callback(rcvData)
	end

	Connection.request("dungeon_check_exit", callback)
end

function InfoDungeon.getHeroTeam(filterFunc, sortFunc)
	local teamList = {}

	for i, id in ipairs(heroTeamData) do
		local heroInfo = InfoHero.getHero(id)

		if not filterFunc or filterFunc(heroInfo) then
			table.insert(teamList, heroInfo)
		end
	end

	table.sort(teamList, sortFunc or function (a, b)
		return a.pos < b.pos
	end)

	return teamList
end

function InfoDungeon.getPetTeam(filterFunc, sortFunc)
	local teamList = {}

	for i, id in ipairs(petTeamData) do
		local petInfo = InfoPet.getPet(id)

		if not filterFunc or filterFunc(petInfo) then
			table.insert(teamList, petInfo)
		end
	end

	table.sort(teamList, sortFunc or function (a, b)
		return a.pos < b.pos
	end)

	return teamList
end

function InfoDungeon.getEventTimes(eventTag)
	local infoMap = nil

	if InfoDungeon.inGap() then
		infoMap = gap_eventInfoMap
	else
		infoMap = eventInfoMap
	end

	local totalCount = 0
	local finCount = 0

	for mapIndex, eventArr in pairs(infoMap) do
		for i, obj in ipairs(eventArr) do
			local eventData = obj.data

			if eventData.tag == eventTag then
				totalCount = totalCount + 1

				if obj.fin == 1 then
					finCount = finCount + 1
				end
			end
		end
	end

	return finCount, totalCount
end

function InfoDungeon.getAbyssGroup(abyssData)
	local group = {
		abyssData
	}

	while not empty(abyssData.next) do
		abyssData = CsvParser.getCsvData("abyss", abyssData.next)

		table.insert(group, abyssData)
	end

	return group
end

local fishingData = nil

function InfoDungeon.fishingStart(eventIndex, bait_id, bait_index, rod_id, onSuccess, onFailure)
	fishingData = {
		bait_id = bait_id
	}

	local function callback(rcvData)
		dump(rcvData, "dungeon_fishing_start")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			notify.dispatch("fishing_start")

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("dungeon_fishing_start", {
		map_index = InfoDungeon.getMapIndex(),
		event_index = eventIndex,
		bait_id = bait_id,
		bait_index = bait_index,
		rod_id = rod_id
	}, callback)
end

function InfoDungeon.fishingOver(eventIndex, succ, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "dungeon_fishing_over")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			InfoDungeon.onEventComplete(eventIndex, rcvData)
			notify.dispatch("fishing_over")

			if CONFIG.is_ta then
				local params = {
					pond_id = rcvData.pond_id,
					fish_id = rcvData.fish_id,
					bait_id = fishingData.bait_id
				}

				TaHelper.taTrack("fishing_success", params)
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	local teamState = DungeonState.getState()

	Connection.request("dungeon_fishing_over", {
		map_index = InfoDungeon.getMapIndex(),
		event_index = eventIndex,
		state = teamState,
		succ = succ
	}, callback)
end

function InfoDungeon.fishnet(eventIndex, bait_id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "dungeon_fishnet")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			InfoDungeon.onEventComplete(eventIndex, rcvData)
			notify.dispatch("fishing_over")

			if CONFIG.is_ta then
				local params = {
					pond_id = rcvData.pond_id,
					fish_id = rcvData.fish_id_arr,
					bait_id = bait_id
				}

				TaHelper.taTrack("fishnet_success", params)
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	local teamState = DungeonState.getState()

	Connection.request("dungeon_fishnet", {
		map_index = InfoDungeon.getMapIndex(),
		event_index = eventIndex,
		bait_id = bait_id,
		state = teamState
	}, callback)
end

function InfoDungeon.getEquipShopInfo(eventIndex, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "dungeon_get_equip_shop_info", 10)

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	local params = {
		map_index = InfoDungeon.getMapIndex(),
		event_index = eventIndex
	}

	Connection.request("dungeon_get_equip_shop_info", params, callback)
end

function InfoDungeon.buyEquipShop(eventIndex, index, cost_type, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			InfoDungeon.onEventComplete(eventIndex, rcvData)
			notify.dispatch("top_map_refresh")

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	local teamState = DungeonState.getState()
	local params = {
		map_index = InfoDungeon.getMapIndex(),
		event_index = eventIndex,
		index = index,
		cost_type = cost_type,
		state = teamState
	}

	Connection.request("dungeon_get_equip_shop_buy", params, callback)
end

function InfoDungeon.getAbyssInfo(abyss_layer)
	local abyssInfoMap = CacheData.get("InfoDungeon_abyssInfoMap")

	if not abyssInfoMap then
		abyssInfoMap = {}
		local csvRaw = CsvParser.getCsvRaw("abyss_info")

		for k, v in pairs(csvRaw) do
			abyssInfoMap[v.layer] = v
		end

		CacheData.set("InfoDungeon_abyssInfoMap", abyssInfoMap)
	end

	return abyssInfoMap[abyss_layer]
end

local guide_abyss_map = nil

function InfoDungeon.getLayerRandomAbyss(layer)
	if abyssMaxLayer <= layer then
		local guide_abyss_map = CacheData.get("InfoDungeon_guide_abyss_map")

		if not guide_abyss_map then
			guide_abyss_map = {}
			local abyss_csv_list = CsvParser.getCsvList("abyss")

			for i, v in ipairs(abyss_csv_list) do
				if v.guide_map == 1 then
					guide_abyss_map[v.layer] = v.id
				end
			end

			CacheData.set("InfoDungeon_guide_abyss_map", guide_abyss_map)
		end

		local fixed_id = guide_abyss_map[layer]

		if fixed_id then
			return fixed_id, 1
		end
	end

	local mission_csv = InfoMission.checkLayer(layer)
	local fixed_map_type = ""

	if mission_csv then
		fixed_map_type = mission_csv.map_type
	end

	local except_type = except_type or ""
	local isEntrance = 1
	local abyss_ready = {}
	local abyss_csv_list = CsvParser.getCsvList("abyss")

	for i, v in ipairs(abyss_csv_list) do
		if v.guide_map ~= 1 then
			if not empty(fixed_map_type) then
				if v.layer == layer and v.map_type == fixed_map_type and v.rare ~= 0 and (isEntrance ~= 1 or v.entrance == 1) then
					table.insert(abyss_ready, {
						id = v.id,
						power = 1 / v.rare
					})
				end
			elseif v.layer == layer and v.map_type ~= except_type and v.rare ~= 0 and (isEntrance ~= 1 or v.entrance == 1) then
				table.insert(abyss_ready, {
					id = v.id,
					power = 1 / v.rare
				})
			end
		end
	end

	if #abyss_ready > 0 then
		local random = Random.new((dungeonSeed or 0) % (layer + 2501))
		local powerIndex = SheetUtil.getPowerRandomIndex(abyss_ready, random, "power")

		return abyss_ready[powerIndex].id, #abyss_ready
	end
end

function InfoDungeon.getStage()
	return stageType, stageID, stageParams
end

function InfoDungeon.getStageCSV()
	if type == TYPE.STAGE then
		local dungeonData = CsvParser.getCsvData("stage", dungeonID)

		return dungeonData
	end
end

function InfoDungeon.isFixedTeam()
	if InfoDungeon.inDungeon() and type == TYPE.STAGE then
		local dungeonData = CsvParser.getCsvData("stage", dungeonID)

		if dungeonData then
			return not empty(dungeonData.fixed_team), dungeonData.fixed_team
		end
	end

	return false
end

function InfoDungeon.jumpToEnter()
	if global.player then
		local enterEvent = MapEventManager.getEventByTagOne("enter")
		local destData = MapEventManager.findLinkOne(enterEvent, "enter_dest")

		if enterEvent then
			local enterX = enterEvent.x
			local enterY = enterEvent.y
			local destX = enterX
			local destY = enterY

			if destData then
				destX = destData.x
				destY = destData.y
			end

			local mapX, mapY = global.map:tileToMap(destX, destY)

			global.player:draw(mapX, mapY, true)
			global.player:setGoDirectionLocked("enterDest", true)

			local angle = math.atan2(destY - enterY, destX - enterX)
			global.player.angle = angle

			global.player:fillTrain()
			global.player:checkTrain()

			local units = global.player:getTrainUnits()

			for i, unit in ipairs(units) do
				unit.angle = angle
				local effectGen = unit:getEffectGen()

				if effectGen then
					effectGen:zmove(0, 1000)
				end

				local function fall()
					local effectGen = unit:getEffectGen()

					if i == #units then
						if effectGen then
							effectGen:zmove(60, 0, nil, function ()
								DungeonState.flush()
								MapEffect.quake()
								global.player:clearGoDirectionLocked()

								Monster.noCheckBattle = nil
							end)
						end
					elseif effectGen then
						effectGen:zmove(60, 0, nil, function ()
							MapEffect.quake()
						end)
					end
				end

				MapFrameManager.setTimeout(fall, 10 * (i - 1))
			end

			PopManager.close()

			return
		end
	end

	Alert.open(Localization.getSrcText("未找到入口"))
end

function InfoDungeon.isSpeedup()
	if InfoDungeon.inDust() then
		return InfoDust.getSpeedupLife() > 0
	else
		return speedup == 1
	end
end

function InfoDungeon.isLayerSafe()
	return layerSafe == 1
end

function InfoDungeon.getTerrainCSV()
	local dungeonData, quest_map_csv = InfoDungeon.getDungeonCSV(type, dungeonID, questID, abyssSeed)
	local mapType = nil

	if type == TYPE.QUEST then
		mapType = quest_map_csv.dungeon
	elseif type == TYPE.TASK then
		mapType = quest_map_csv.dungeon
	elseif type == TYPE.ABYSS then
		mapType = dungeonData.map_type
	elseif type == TYPE.STAGE then
		mapType = dungeonData.map_type
	end

	local terrainCSV = nil

	if not empty(mapType) then
		terrainCSV = CsvParser.getCsvData("abyss_terrain", mapType, nil, true)
	end

	terrainCSV = terrainCSV or CsvParser.getCsvData("abyss_terrain", "plain")

	return terrainCSV
end

function InfoDungeon.getTerrain()
	if InfoDungeon.inDungeon() then
		local terrainCSV = nil

		if not empty(terrainID) then
			if InfoDungeon.getType() == TYPE.ABYSS then
				-- Nothing
			elseif InfoDungeon.getType() == TYPE.STAGE and terrainType == 2 then
				terrainCSV = CsvParser.getCsvData("stage_terrain", terrainID)
			end
		end

		return terrainCSV
	end
end

function InfoDungeon.getMutate()
	if InfoDungeon.inGap() then
		return
	end

	if InfoDungeon.inDungeon() then
		local mutateCSV = nil

		if not empty(mutateID) then
			if InfoDungeon.getType() == TYPE.ABYSS then
				if mutateType == 0 then
					mutateCSV = CsvParser.getCsvData("abyss_mutate", mutateID)
				elseif mutateType == 1 then
					mutateCSV = CsvParser.getCsvData("abyss_akasa_mutate", mutateID)
				end
			elseif InfoDungeon.getType() == TYPE.STAGE and mutateType == 2 then
				mutateCSV = CsvParser.getCsvData("stage_mutate", mutateID)
			end
		end

		return mutateCSV
	end
end

function InfoDungeon.getMutateFriendBuff()
	local mutateCSV = InfoDungeon.getMutate()

	if mutateCSV and not empty(mutateCSV.friend_buff) then
		return mutateCSV.friend_buff
	end
end

function InfoDungeon.getMutateMonster()
	local mutateCSV = InfoDungeon.getMutate()

	if mutateCSV and not empty(mutateCSV.monster_id) then
		local mutateMonsterCSV = nil

		if InfoDungeon.getType() == TYPE.ABYSS then
			mutateMonsterCSV = CsvParser.getCsvData("abyss_mutate_monster", mutateCSV.monster_id)
		elseif InfoDungeon.getType() == TYPE.STAGE then
			mutateMonsterCSV = CsvParser.getCsvData("stage_mutate_monster", mutateCSV.monster_id)
		end

		return mutateMonsterCSV
	end
end

function InfoDungeon.getMutateMonsterDropAffix()
	local mutateCSV = InfoDungeon.getMutate()

	if mutateCSV then
		if InfoDungeon.getType() == TYPE.STAGE then
			if not empty(mutateCSV.monster_drop_index) then
				return "stage_mutate" .. mutateCSV.monster_drop_index .. "_drop_id_"
			end
		elseif not empty(mutateCSV.monster_drop_index) then
			return "mutate" .. mutateCSV.monster_drop_index .. "_drop_id_"
		end
	end
end

function InfoDungeon.getTitle(type, dungeonID, questID, abyssSeed)
	local dungeonData, quest_map_csv = InfoDungeon.getDungeonCSV(type, dungeonID, questID, abyssSeed)
	local title = dungeonData.name
	local subTitle = nil

	if type == TYPE.QUEST then
		subTitle = quest_map_csv.name
	elseif type == TYPE.ABYSS then
		-- Nothing
	elseif type == TYPE.TASK then
		subTitle = quest_map_csv.name

		if not empty(quest_map_csv.dungeon) then
			local questDungeonCSV = CsvParser.getCsvData("quest_dungeon", quest_map_csv.dungeon)
			title = questDungeonCSV.name
		end
	elseif type == TYPE.STAGE then
		-- Nothing
	end

	return title, subTitle
end

function InfoDungeon.getAbyssPreview()
	local csvList = CsvParser.getCsvList("abyss_preview")
	local abyssLayer = InfoDungeon.getAbyssMaxLevel()

	for i, v in ipairs(csvList) do
		if abyssLayer <= v.id then
			return v
		end
	end
end

local areaLayerMap, akasaLayerMap, areaEntranceMap, areaOpenLayerMap, layerAreaMap, akasaInfoMap = nil

function InfoDungeon.isAkasa()
	if InfoDungeon.getType() == TYPE.ABYSS then
		local csv = InfoDungeon.getDungeonCSV()

		return csv.is_akasa == 1
	end
end

function InfoDungeon.isNormalLayer(abyssCSV)
	if empty(abyssCSV.is_akasa) then
		local isBoss = false

		if not empty(abyssCSV.area_id) then
			local areaCSV = CsvParser.getCsvData("abyss_area", abyssCSV.area_id)

			if areaCSV.is_boss == 1 then
				isBoss = true
			elseif areaCSV.is_boss == 2 then
				isBoss = true
			end
		end

		if not isBoss then
			return true
		end
	end
end

function InfoDungeon.isBossLayer(abyssCSV)
	local isBoss = false

	if not empty(abyssCSV.area_id) then
		local areaCSV = CsvParser.getCsvData("abyss_area", abyssCSV.area_id)

		if areaCSV.is_boss == 1 then
			isBoss = true
		elseif areaCSV.is_boss == 2 then
			isBoss = true
		end
	end

	return isBoss
end

local bossNeoLayerCache = nil

function InfoDungeon.isBossNeoLayer(_enterLayer)
	if not bossNeoLayerCache then
		bossNeoLayerCache = {}
		local csvRaw = CsvParser.getCsvRaw("abyss_neo")

		for k, csv in pairs(csvRaw) do
			local abyssCSV = CsvParser.getCsvData("abyss", csv.abyss)

			if abyssCSV then
				bossNeoLayerCache[abyssCSV.layer] = true
			end
		end
	end

	return bossNeoLayerCache[_enterLayer]
end

function InfoDungeon.isBossOpen(abyssCSV)
	InfoDungeon.initAbyssArea()

	if not empty(abyssCSV.area_id) then
		local openLayer = areaOpenLayerMap[abyssCSV.area_id]

		if openLayer <= InfoDungeon.getAbyssMaxLayer() then
			return true
		end
	end
end

function InfoDungeon.initAbyssArea()
	if not areaLayerMap then
		local abyssList = CsvParser.getCsvList("abyss", "layer")
		local tempEntranceMap = {}
		areaLayerMap = {}
		akasaLayerMap = {}
		areaEntranceMap = {}
		areaOpenLayerMap = {}
		akasaInfoMap = {}
		local preAkasa, preAkasaOver = nil
		local preNormalLayer = 0
		local currentAreaID = 1

		for i, csv in ipairs(abyssList) do
			if not empty(csv.area_id) then
				areaOpenLayerMap[csv.area_id] = preNormalLayer
				areaLayerMap[csv.area_id] = csv
				akasaLayerMap[csv.area_id] = preAkasa

				if preAkasa and preAkasaOver then
					akasaInfoMap[csv.area_id] = {
						startLayer = preAkasa.layer,
						overLayer = preAkasaOver.layer,
						startLevel = preAkasa.level,
						overLevel = preAkasaOver.level
					}
				end
			end

			if InfoDungeon.isNormalLayer(csv) then
				preNormalLayer = csv.layer

				if csv.entrance == 1 then
					tempEntranceMap[csv.layer] = csv
				end
			end

			if csv.is_akasa == 1 and csv.entrance == 1 then
				preAkasa = csv
			end

			if csv.is_akasa == 2 then
				preAkasaOver = csv
			end
		end

		local tempChapterIndex = {}
		layerAreaMap = {}
		local preLayer = -1
		local areaList = CsvParser.getCsvList("abyss_area")

		for i, v in ipairs(areaList) do
			local bossLayer = areaLayerMap[v.id].layer

			if bossLayer then
				for layer = preLayer + 1, bossLayer do
					local chapterID = v.chapter
					local entranceCSV = tempEntranceMap[layer]

					if entranceCSV then
						if not tempChapterIndex[chapterID] then
							tempChapterIndex[chapterID] = 0
						else
							tempChapterIndex[chapterID] = tempChapterIndex[chapterID] + 1
						end
					end

					layerAreaMap[layer] = {
						csv = v,
						chapterID = chapterID,
						chapterIndex = tempChapterIndex[chapterID]
					}
				end

				preLayer = bossLayer + 1
			end
		end

		for i, csv in ipairs(abyssList) do
			if csv.entrance == 1 and layerAreaMap[csv.layer] then
				local areaID = layerAreaMap[csv.layer].csv.id

				if not areaEntranceMap[areaID] then
					areaEntranceMap[areaID] = {}
				end

				table.insert(areaEntranceMap[areaID], csv)
			end
		end
	end
end

function InfoDungeon.getAkasaInfo(areaID)
	InfoDungeon.initAbyssArea()

	return akasaInfoMap[areaID]
end

function InfoDungeon.getLayerArea(layer)
	InfoDungeon.initAbyssArea()

	return layerAreaMap[layer]
end

function InfoDungeon.isAreaFinished(areaID)
	InfoDungeon.initAbyssArea()

	local bossLayer = areaLayerMap[areaID]
	local abyssLayer = InfoDungeon.getAbyssMaxLayer()

	return bossLayer.layer <= abyssLayer
end

function InfoDungeon.getAreaList()
	InfoDungeon.initAbyssArea()

	local csvList = CsvParser.getCsvList("abyss_area")
	local chapterID = InfoChapter.getID()
	local abyssLayer = InfoDungeon.getAbyssMaxLayer()
	local maxIndex = 1
	local found = false

	for i, v in ipairs(csvList) do
		if v.chapter == chapterID then
			local bossLayer = areaLayerMap[v.id]

			if bossLayer and abyssLayer <= bossLayer.layer then
				found = true
				maxIndex = i

				break
			end
		end
	end

	if not found then
		maxIndex = #csvList
	end

	local areaOpenMax = InfoAbyssReward.getAreaOpened()
	local arr = {}

	for i, v in ipairs(csvList) do
		if v.chapter == chapterID then
			if i <= areaOpenMax and i <= maxIndex then
				table.insert(arr, 1, v)
			else
				break
			end
		end
	end

	return arr, maxIndex, areaOpenMax
end

function InfoDungeon.getEntranceList(areaID)
	InfoDungeon.initAbyssArea()

	local areaCSV = CsvParser.getCsvData("abyss_area", areaID)
	local abyssList = areaEntranceMap[areaID]
	local entranceList = {}
	local minLayer = -1

	if areaLayerMap[areaID - 1] then
		minLayer = areaLayerMap[areaID - 1].layer
	end

	local maxLayer = InfoDungeon.getAbyssMaxLayer()

	if areaLayerMap[areaID] then
		maxLayer = math.min(maxLayer, areaLayerMap[areaID].layer)
	end

	local layerExisted = {}
	local maxAreaLayer = 0
	local bossCSV, akasaCSV = nil

	for i, v in ipairs(abyssList) do
		if minLayer < v.layer and v.layer <= maxLayer then
			if empty(v.area_id) or areaCSV.is_boss ~= 1 then
				if empty(v.is_akasa) then
					if not layerExisted[v.layer] then
						layerExisted[v.layer] = true

						table.insert(entranceList, 1, {
							csv = v,
							areaID = areaID,
							areaIndex = #entranceList + 1,
							isAkasa = not empty(v.is_akasa)
						})

						maxAreaLayer = math.max(maxAreaLayer, v.layer)
					end
				else
					akasaCSV = v
				end
			else
				bossCSV = v
			end
		end
	end

	bossCSV = bossCSV or areaLayerMap[areaID]
	akasaCSV = akasaCSV or akasaLayerMap[areaID]

	return entranceList, bossCSV, akasaCSV
end

function InfoDungeon.getAreaInfo(areaID)
	InfoDungeon.initAbyssArea()

	local abyssList = areaEntranceMap[areaID]
	local mineCount = 0
	local mineAlready = 0
	local mapCount = 0
	local mapAlready = 0
	local maxLayer = InfoDungeon.getAbyssMaxLayer()
	local lastNormalLayer = nil
	local layerExisted = {}

	for i, v in ipairs(abyssList) do
		if not layerExisted[v.layer] then
			layerExisted[v.layer] = true
			local group = InfoDungeon.getAbyssGroup(v)

			for i, abyssData in ipairs(group) do
				if abyssData and not empty(abyssData.mine_index) then
					if InfoFurnace.getMineRecord(abyssData.mine_index) > 0 then
						mineAlready = mineAlready + 1
					end

					mineCount = mineCount + 1
				end
			end

			if InfoDungeon.isNormalLayer(v) then
				mapCount = mapCount + 1

				if v.layer <= maxLayer then
					mapAlready = mapAlready + 1
				end

				lastNormalLayer = v
			end
		end
	end

	mapAlready = mapAlready - 1

	if lastNormalLayer then
		local group = InfoDungeon.getAbyssGroup(lastNormalLayer)

		if group and #group > 0 and group[#group].layer <= maxLayer then
			mapAlready = mapAlready + 1
		end
	end

	mapAlready = math.max(0, mapAlready)

	return mapCount, mapAlready, mineCount, mineAlready
end

function InfoDungeon.onLeave(rcvData)
	local _stageType = stageType
	local _stageID = stageID

	InfoDungeon.clear()

	if _stageType == InfoDungeon.STAGE_TYPE.UNION_TRAIN or _stageType == InfoDungeon.STAGE_TYPE.UNION_SOLO then
		InfoUnion.enterMap(true)
	elseif _stageType == InfoDungeon.STAGE_TYPE.DUST then
		local dustID = _stageID

		local function onSuccess(result)
			InfoDungeon.makeMaps(result)
			DungeonScene.enterDungeon(DungeonScene.ENTER_TYPE.NEW, result)
		end

		InfoDust.enterPrepare(dustID, onSuccess)
	elseif _stageType == InfoDungeon.STAGE_TYPE.UNION_PVE_NORMAL_STAGE then
		local from_map = UserCookie.get("from_map")

		if from_map == "union" and InfoUnion.hasUnion() then
			InfoUnion.enterMap()

			return
		end

		InfoDungeon.enterCamp()
	else
		InfoDungeon.enterCamp()
	end
end

local stageMutateCache = {}

function InfoDungeon.getStageMutate(_stageID, mutateGen)
	local refine_data = stageMutateCache[_stageID]

	if not refine_data then
		local csvList = CsvParser.getCsvList("stage_mutate")
		refine_data = {
			arr = {},
			powArr = {}
		}

		for i, csv in ipairs(csvList) do
			if not empty(csv.weight) then
				local isMatch = true

				if csv.stage_match ~= "" then
					local matchArr = string.split(csv.dust_id, ",")
					isMatch = false

					for j, v in ipairs(matchArr) do
						if v == tostring(_stageID) then
							isMatch = true

							break
						end
					end
				end

				if isMatch then
					table.insert(refine_data.arr, csv.id)
					table.insert(refine_data.powArr, csv.weight)
				end
			end
		end

		stageMutateCache[_stageID] = refine_data
	end

	local arr = refine_data.arr
	local powArr = refine_data.powArr

	if #powArr > 0 then
		local powerIndex = SheetUtil.getPowerRandomIndex(powArr, mutateGen)

		return arr[powerIndex]
	else
		return 0
	end
end

local dustAttrGenCache = nil

function InfoDungeon.getDustAttrGen(dustID, level)
	if not dustAttrGenCache then
		local csvList = CsvParser.getCsvList("dust_attr_gen")
		dustAttrGenCache = {}

		for i, csv in ipairs(csvList) do
			local dust_id = csv.dust_id

			if not dustAttrGenCache[dust_id] then
				dustAttrGenCache[dust_id] = {}
			end

			table.insert(dustAttrGenCache[dust_id], {
				id = csv.id,
				level = csv.dust_level
			})
		end
	end

	local arr = dustAttrGenCache[dustID]

	if arr then
		for i, v in ipairs(arr) do
			if level <= v.level then
				return CsvParser.getCsvData("dust_attr_gen", v.id)
			end
		end
	end
end

function InfoDungeon.getAreaCSV()
	if InfoNaraka.inNarakaBoss() then
		local narakaCSV = InfoNaraka.getNarakaCSV()
		local areaCSV = CsvParser.getCsvData("abyss_area", narakaCSV.abyss_area)

		return areaCSV
	elseif InfoDungeon.inDust() then
		local dustCSV = CsvParser.getCsvData("dust", InfoDungeon.getDustID())
		local areaCSV = CsvParser.getCsvData("abyss_area", dustCSV.abyss_area)

		return areaCSV
	elseif InfoDungeon.getType() == TYPE.ABYSS then
		local areaInfo = InfoDungeon.getLayerArea(enterLayer)

		if areaInfo then
			return areaInfo.csv
		end
	end
end

function InfoDungeon.isFixTough()
	local areaCSV = InfoDungeon.getAreaCSV()

	if areaCSV then
		if CONFIG.isNeo then
			if InfoDungeon.inDust() then
				return areaCSV.dust_tough_neo == 1
			else
				return areaCSV.tough_neo == 1
			end
		elseif InfoDungeon.inDust() then
			return areaCSV.dust_tough == 1
		else
			return areaCSV.tough == 1
		end
	else
		local fix_tough_level = CsvParser.getCsvData("config", "fix_tough_level").value

		if fix_tough_level <= InfoDungeon.getLevel() then
			return true
		end
	end

	return false
end

function InfoDungeon.exitGap(eventIndex, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			InfoDungeon.clearGap()
			InfoDungeon.retry()
		end
	end

	Connection.request("dungeon_exit_gap", {
		map_index = InfoDungeon.getMapIndex(),
		event_index = eventIndex
	}, callback)
end

function InfoDungeon.inGap()
	return not empty(gapID)
end

function InfoDungeon.getGapID()
	return gapID
end

function InfoDungeon.clearGap()
	if queryInfo then
		queryInfo.gap_id = ""
	end

	gapID = ""
	gap_currentMapIndex = 0
	gap_mapSeedArr = {}
	gap_relicData = {}
	gap_finalRelic = {}
	gap_eventInfoMap = {}
end

function InfoDungeon.setGapMapIndex(index)
	if gap_currentMapIndex ~= index then
		gap_currentMapIndex = index
	end
end

function InfoDungeon.makeGapMaps(rcvData)
	print("$$$ makeGapMaps 1")

	gapID = rcvData.gap_id

	if empty(gapID) then
		return
	end

	gap_mapSeedArr = rcvData.gap_map_seeds
	local maps = InfoDungeon.getDungeonMaps(TYPE.STAGE, gapID)
	gap_relicData = {}
	gap_finalRelic = {}
	local eventInfos, relicInfos = nil

	if rcvData.gap_events then
		eventInfos = json.decode(rcvData.gap_events)
	end

	if rcvData.gap_relic then
		relicInfos = json.decode(rcvData.gap_relic)
	end

	print("$$$ makeGapMaps 2")

	gap_eventInfoMap = {}

	for mapIndex, mapName in ipairs(maps) do
		local mapSeed = gap_mapSeedArr[mapIndex]
		local random = Random.new(mapSeed)
		gap_eventInfoMap[mapIndex] = {}
		gap_relicData[mapIndex] = {}

		print("$$$ getMapData 1", mapIndex, mapName, mapSeed)

		local mapObj = Map.getMapData(mapName, mapSeed)

		print("$$$ getMapData 2", mapObj)

		for eventIndex, eventData in ipairs(mapObj.eventData) do
			local eventIndexStr = tostring(eventIndex)
			local eventSeed = random:getInt(1, 65535)

			if relicInfos and relicInfos[mapIndex] then
				gap_relicData[mapIndex][eventIndex] = relicInfos[mapIndex][eventIndexStr]
			end

			if eventInfos and eventInfos[mapIndex] and eventInfos[mapIndex][eventIndexStr] then
				table.insert(gap_eventInfoMap[mapIndex], {
					data = eventData,
					seed = eventSeed,
					fin = eventInfos[mapIndex][eventIndexStr].fin,
					set_index = eventInfos[mapIndex][eventIndexStr].set_index
				})
			else
				table.insert(gap_eventInfoMap[mapIndex], {
					fin = 0,
					data = eventData,
					seed = eventSeed
				})
			end
		end
	end

	dump(gap_eventInfoMap, "$$$ gap_eventInfoMap")
	dump(gap_relicData, "$$$ gap_relicData")
	print("$$$ makeGapMaps 3")
	InfoDungeon.setGapMapIndex(1)

	queryInfo.gap_id = gapID

	print("$$$ makeGapMaps 4")
end

function InfoDungeon.getTimeUsed()
	return timeUsed + math.max(0, Time.now() - timeStart)
end

function InfoDungeon.isAutoPick()
	return autopick_curr == 1
end

function InfoDungeon.autoPickCurr()
	return autopick_curr
end

function InfoDungeon.autoPickTime()
	return autopick_time
end

function InfoDungeon.autoPickAdd(num, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "dungeon_autopick_add")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("dungeon_autopick_add", {
		num = num
	}, callback)
end

function InfoDungeon.clearCache()
	areaLayerMap = nil
	areaOpenLayerMap = nil
	layerAreaMap = nil
	areaEntranceMap = nil
	akasaLayerMap = nil
	akasaInfoMap = nil
end

return InfoDungeon
