local Condition = class("Condition")
local TYPE = {
	LEVEL = 1,
	NOT_ENTER_LAYER = 10,
	IS_ENTER_LAYER = 9,
	STAGE_INDEX_LESS = 8,
	STAGE_INDEX_MORE = 7,
	STAGE_INDEX = 6,
	HAVE_ITEM_NOT = 5,
	HAVE_ITEM = 4,
	LEVEL_LESS = 3,
	LEVEL_MORE = 2
}
Condition.TYPE = TYPE

local function checkConditionOne(condType, condValue)
	if condType == TYPE.LEVEL then
		if InfoDungeon.getLevel() ~= condValue then
			return false
		end
	elseif condType == TYPE.LEVEL_MORE then
		if InfoDungeon.getLevel() <= condValue then
			return false
		end
	elseif condType == TYPE.LEVEL_LESS then
		if condValue <= InfoDungeon.getLevel() then
			return false
		end
	elseif condType == TYPE.HAVE_ITEM then
		if InfoItem.getNum(condValue) == 0 then
			return false
		end
	elseif condType == TYPE.HAVE_ITEM_NOT then
		if InfoItem.getNum(condValue) > 0 then
			return false
		end
	elseif condType == TYPE.STAGE_INDEX then
		local stageCSV = InfoDungeon.getStageCSV()

		if stageCSV then
			return stageCSV.index == condValue
		else
			return false
		end
	elseif condType == TYPE.STAGE_INDEX_MORE then
		local stageCSV = InfoDungeon.getStageCSV()

		if stageCSV then
			return condValue < stageCSV.index
		else
			return false
		end
	elseif condType == TYPE.STAGE_INDEX_LESS then
		local stageCSV = InfoDungeon.getStageCSV()

		if stageCSV then
			return stageCSV.index < condValue
		else
			return false
		end
	elseif condType == TYPE.IS_ENTER_LAYER then
		local abyssLayer = InfoDungeon.getAbyssLayer()
		local enterLayer = InfoDungeon.getEnterLayer()

		return abyssLayer == enterLayer
	elseif condType == TYPE.NOT_ENTER_LAYER then
		local abyssLayer = InfoDungeon.getAbyssLayer()
		local enterLayer = InfoDungeon.getEnterLayer()

		return abyssLayer ~= enterLayer
	end

	return true
end

function Condition.checkSheet(data, condTypePrefix, condValuePrefix)
	local condList = SheetUtil.getColumnList(data, {
		condTypePrefix,
		condValuePrefix
	}, {
		"type",
		"value"
	})

	for i, v in ipairs(condList) do
		local condType = v.type
		local condValue = v.value

		if not checkConditionOne(condType, condValue) then
			return false
		end
	end

	return true
end

function Condition.checkText(conditionStr)
	local lines = string.split(conditionStr, "\n")

	if #lines == 1 then
		lines = string.split(conditionStr, "\r")
	end

	local condType, condValue = nil
	local typeDone = true

	for i = 1, #lines do
		local line = lines[i]

		if line:sub(1, 2) ~= "//" then
			local parts = string.split(line, "=")

			if #parts == 2 then
				local key = string.trim(parts[1])
				local value = string.trim(parts[2])

				if key == "type" then
					if not typeDone and not checkConditionOne(TYPE[condType]) then
						return false
					end

					condType = value
					typeDone = false
				elseif key == "value" then
					condValue = tonumber(value) or value

					if not empty(condType) and not checkConditionOne(TYPE[condType], condValue) then
						return false
					end

					typeDone = true
				end
			end
		end
	end

	if not typeDone and not checkConditionOne(TYPE[condType]) then
		return false
	end

	return true
end

function Condition.onChangeSheet(view, data, condTypePrefix, condValuePrefix, callback)
	local condList = SheetUtil.getColumnList(data, {
		condTypePrefix,
		condValuePrefix
	}, {
		"type",
		"value"
	})

	for i, v in ipairs(condList) do
		local condType = v.type
		local condValue = v.value

		if condType == 1 then
			ManagerInfo.onDataChange(view, "hero", nil, callback)
		elseif condType == 2 then
			ManagerInfo.onDataChange(view, "quest", nil, callback)
		elseif condType == 3 then
			ManagerInfo.onDataChange(view, "quest", nil, callback)
		elseif condType == 4 then
			ManagerInfo.onDataChange(view, "item", nil, callback)
		elseif condType == 5 then
			-- Nothing
		elseif condType == 6 then
			-- Nothing
		elseif condType == 7 then
			ManagerInfo.onDataChange(view, "dunpass", nil, callback)
		end
	end

	return true
end

function Condition.checkID(id)
	local conditionData = CsvParser.getCsvData("condition", id)

	return Condition.checkSheet(conditionData, "cond_type_", "cond_value_")
end

function Condition.onChangeID(view, id, callback)
	local conditionData = CsvParser.getCsvData("condition", id)

	return Condition.onChangeSheet(view, conditionData, "cond_type_", "cond_value_", callback)
end

return Condition
