local FrameLooper = import("....lib.FrameLooper")
local MapFrameManager = class("MapFrameManager")
MapFrameManager.core = FrameLooper.new()
local map = nil

function MapFrameManager.setMode(mode)
	MapFrameManager.core:setMode(mode)
end

function MapFrameManager.clear()
	MapFrameManager.setMode(FrameLooper.MODE.NORMAL)
	MapFrameManager.core:clear()
end

function MapFrameManager.next()
	MapFrameManager.core:next()
end

function MapFrameManager.clearWithMap()
	map = nil

	MapFrameManager.core:clear()
end

function MapFrameManager.pause(tag)
	MapFrameManager.core:pause(tag)
end

function MapFrameManager.resume(tag)
	MapFrameManager.core:resume(tag)
end

function MapFrameManager.setMap(_map)
	map = _map

	MapFrameManager.core:setOwner(_map)
end

function MapFrameManager.startLoop(obj, func)
	if not map then
		return
	end

	MapFrameManager.core:startLoop(obj, func)
end

function MapFrameManager.stopLoop(obj, func)
	if not map then
		return
	end

	MapFrameManager.core:stopLoop(obj, func)
end

function MapFrameManager.clearLoop(obj)
	if not map then
		return
	end

	MapFrameManager.core:clearLoop(obj)
end

function MapFrameManager.markTimeUsed()
	MapFrameManager.core:markTimeUsed()
end

function MapFrameManager.getTimeUsed()
	return MapFrameManager.core:getTimeUsed() or 0
end

function MapFrameManager.tween(time, subject, target, easing, onComplete, onUpdate)
	if not map then
		return
	end

	return MapFrameManager.core:tween(time, subject, target, easing, onComplete, onUpdate)
end

function MapFrameManager.stopTween(tweenID)
	if not map then
		return
	end

	MapFrameManager.core:stopTween(tweenID)
end

function MapFrameManager.setTimeout(func, frameTime, existingNode)
	if not map then
		return
	end

	return MapFrameManager.core:setTimeout(func, frameTime, existingNode)
end

function MapFrameManager.clearTimeout(idFunc)
	if not map then
		return
	end

	MapFrameManager.core:clearTimeout(idFunc)
end

function MapFrameManager.getSecond()
	return MapFrameManager.core:getSecond()
end

function MapFrameManager.getAbsFrame()
	return MapFrameManager.core:getAbsFrame()
end

function MapFrameManager.getFrame()
	return MapFrameManager.core:getFrame()
end

function MapFrameManager.getFrameSpeed()
	return MapFrameManager.core:getFrameSpeed()
end

function MapFrameManager.setTimeRatio(r)
	return MapFrameManager.core:setTimeRatio("normal", r)
end

function MapFrameManager.setSuperTimeRatio(r)
	return MapFrameManager.core:setTimeRatio("super", r)
end

function MapFrameManager.clearSuperTimeRatio()
	return MapFrameManager.core:clearTimeRatio("super")
end

return MapFrameManager
