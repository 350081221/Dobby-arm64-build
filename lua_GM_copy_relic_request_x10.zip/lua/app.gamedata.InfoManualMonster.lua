local InfoManualMonster = {}
local rawData = {}

function InfoManualMonster.init()
	Connection.listen("manual_monster_sync", InfoManualMonster.sync)
end

app:addToAppEnterCall(InfoManualMonster.init)

function InfoManualMonster.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoManualMonster.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("manual_monster_query", callback)
end

function InfoManualMonster.onQuery(rcvData)
	rawData = {}

	for i, data in ipairs(rcvData.list) do
		rawData[data.base_id] = data
	end
end

function InfoManualMonster.sync(data)
	for i, syncData in ipairs(data.list) do
		local base_id = syncData.base_id

		if rawData[base_id] then
			for k, v in pairs(syncData) do
				rawData[base_id][k] = v
			end
		else
			rawData[base_id] = syncData
		end
	end

	ManagerInfo.dataChange("manual_monster")
end

function InfoManualMonster.meet(monsterID, affixID, onSuccess, onFailure)
	local manualID = InfoManualMonster.getManualByMonster(monsterID)

	if not manualID then
		return
	end

	if rawData[manualID] and not affixID then
		return
	end

	local affix_str = nil

	if not empty(affixID) then
		local affixArr = {}

		if rawData[manualID] then
			local affixStr = rawData[manualID].affix_arr

			if not empty(affixStr) then
				affixArr = string.split(affixStr, ",")
			end
		end

		local found = false

		for i, v in ipairs(affixArr) do
			if tostring(v) == tostring(affixID) then
				found = true

				break
			end
		end

		if rawData[manualID] and found then
			return
		end

		if not found then
			table.insert(affixArr, tostring(affixID))
		end

		affix_str = ""

		for i, v in ipairs(affixArr) do
			if affix_str ~= "" then
				affix_str = affix_str .. ","
			end

			affix_str = affix_str .. v
		end
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			if rcvData.is_new == 1 then
				local manualCSV = CsvParser.getCsvData("manual_monster", manualID)

				notify.dispatch("caution_push", {
					base_id = 100001,
					id = manualCSV.monster_1
				})
			end

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("manual_monster_meet", {
		id = manualID,
		affix_arr = affix_str
	}, callback)
end

function InfoManualMonster.mark(arr, onSuccess, onFailure)
	local id_arr = {}

	for i, manualID in ipairs(arr) do
		if rawData[manualID] and rawData[manualID].is_new == 1 then
			table.insert(id_arr, manualID)
		end
	end

	if #id_arr == 0 then
		return
	end

	local function callback(rcvData)
		dump(rcvData, "manual_monster_mark")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("manual_monster_mark", {
		id_arr = id_arr
	}, callback)
end

function InfoManualMonster.getLabelList()
	local mapLabelList = {}
	local csvList = CsvParser.getCsvList("manual_monster")
	local areaID = InfoWorld.getAbyssArea()
	local existMap = {}
	local checkedMap = {}

	for i, csv in ipairs(csvList) do
		if not checkedMap[csv.map] then
			checkedMap[csv.map] = true
			local terrainCSV = CsvParser.getCsvData("abyss_terrain", csv.map)
			local isOpen = true

			if not empty(terrainCSV.area_open) and areaID < terrainCSV.area_open then
				isOpen = false
			end

			if isOpen then
				local obj = {
					newCount = 0,
					csv = terrainCSV
				}
				existMap[csv.map] = obj

				table.insert(mapLabelList, obj)
			end
		end

		local obj = existMap[csv.map]

		if obj and rawData[csv.id] and rawData[csv.id].is_new == 1 then
			obj.newCount = obj.newCount + 1
		end
	end

	return mapLabelList
end

function InfoManualMonster.getList(abyssTerrain)
	local csvList = CsvParser.getCsvList("manual_monster")
	local classArr = {}
	local classMap = {}

	for i, csv in ipairs(csvList) do
		if csv.map == abyssTerrain then
			if not classMap[csv.class] then
				classMap[csv.class] = {
					class = csv.class,
					arr = {}
				}

				table.insert(classArr, classMap[csv.class])
			end

			table.insert(classMap[csv.class].arr, {
				csv = csv,
				info = rawData[csv.id]
			})
		end
	end

	table.sort(classArr, function (a, b)
		return b.class < a.class
	end)

	local arr = {}

	for i, v in ipairs(classArr) do
		table.insert(arr, {
			class = v.class
		})
		table.insert(arr, {
			monsters = v.arr
		})
	end

	return arr
end

function InfoManualMonster.getQuality(class)
	if class == 12 then
		return 4
	elseif class == 11 then
		return 3
	elseif class == 2 then
		return 2
	else
		return 1
	end
end

function InfoManualMonster.getAffixList(manualID)
	local manualCSV = CsvParser.getCsvData("manual_monster", manualID)
	local monsterArr = SheetUtil.getColumnValueList(manualCSV, "monster_")
	local activedMap = {}

	if rawData[manualID] then
		local affix_arr = string.split(rawData[manualID].affix_arr, ",")

		for i, v in ipairs(affix_arr) do
			if not empty(v) then
				activedMap[v] = true
			end
		end
	end

	local existMap = {}
	local affixArr = {}

	for i, monsterID in ipairs(monsterArr) do
		local monsterCSV = CsvParser.getCsvData("monster", monsterID)

		if not empty(monsterCSV.affix) then
			local arr1 = string.split(monsterCSV.affix, ";")

			for j, v in ipairs(arr1) do
				local arr2 = string.split(v, ":")

				if not empty(arr2[1]) and not existMap[arr2[1]] then
					existMap[arr2[1]] = true

					table.insert(affixArr, {
						id = arr2[1],
						actived = activedMap[arr2[1]]
					})
				end
			end
		end
	end

	return affixArr
end

function InfoManualMonster.getManualByMonster(monsterID)
	local monsterToManual = CacheData.get("InfoManualMonster_monsterToManual")

	if not monsterToManual then
		monsterToManual = {}
		local csvRaw = CsvParser.getCsvRaw("manual_monster")

		for k, v in pairs(csvRaw) do
			local idArr = SheetUtil.getColumnValueList(v, "monster_")

			for i, monsterID in ipairs(idArr) do
				monsterToManual[monsterID] = v.id
			end
		end

		CacheData.set("InfoManualMonster_monsterToManual", monsterToManual)
	end

	local manualID = monsterToManual[monsterID]

	return manualID
end

function InfoManualMonster.getCollectNum(abyssTerrain)
	local csvList = CsvParser.getCsvList("manual_monster")
	local num = 0
	local max = 0

	for i, csv in ipairs(csvList) do
		if csv.map == abyssTerrain then
			max = max + 1

			if rawData[csv.id] then
				num = num + 1
			end
		end
	end

	return num, max
end

function InfoManualMonster.countRedot()
	local redotCount = 0
	local areaID = InfoWorld.getAbyssArea()
	local csvList = CsvParser.getCsvList("manual_monster")
	local existMap = {}

	for i, csv in ipairs(csvList) do
		local terrainCSV = CsvParser.getCsvData("abyss_terrain", csv.map)
		local isOpen = true

		if not empty(terrainCSV.area_open) and areaID < terrainCSV.area_open then
			isOpen = false
		end

		if isOpen and rawData[csv.id] and rawData[csv.id].is_new == 1 then
			redotCount = redotCount + 1
		end
	end

	return redotCount
end

return InfoManualMonster
