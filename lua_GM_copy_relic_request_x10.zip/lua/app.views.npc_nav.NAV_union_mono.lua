local NAV_base = import(".NAV_base")
local NAV_union_mono = class("NAV_union_mono", NAV_base)

function NAV_union_mono.open(npc)
	local ui = NAV_union_mono.new(npc)

	return ui
end

function NAV_union_mono:ctor(npc)
	NAV_union_mono.super.ctor(self, npc, "nav_union_mono")
end

function NAV_union_mono:init()
	NAV_union_mono.super.init(self)
	self:refresh()
	ManagerInfo.onDataChange(self, "union", nil, function ()
		self:refresh()
	end)
end

function NAV_union_mono:refresh()
	local index = 3

	if InfoUnion.checkPower("lvup_building") then
		self:setButtonVisible(index, true)
		self:setBuildingLvupIndex(index, true)
	else
		self:setButtonVisible(index, false)
	end

	local hasStage = InfoUnion.getBuildingLevel(InfoBuilding.TAG.UNION_MONO) > 0

	self:setButtonVisible(1, hasStage)
	self:setButtonVisible(2, hasStage)
end

function NAV_union_mono:onTap(index)
	NAV_union_mono.super.onTap(self, index)

	if index == 1 then
		FRAME_union_mono_stage.open(self.npc)
	elseif index == 2 then
		FRAME_union_mono_stage.open(self.npc, true)
	elseif index == 4 then
		FRAME_ranking.open(self.npc)
	end
end

return NAV_union_mono
