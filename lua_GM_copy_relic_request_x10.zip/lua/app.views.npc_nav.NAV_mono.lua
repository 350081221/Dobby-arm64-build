local NAV_base = import(".NAV_base")
local NAV_mono = class("NAV_mono", NAV_base)

function NAV_mono.open(npc)
	local ui = NAV_mono.new(npc)

	return ui
end

function NAV_mono:ctor(npc)
	NAV_mono.super.ctor(self, npc, "nav_mono")
end

function NAV_mono:init()
	NAV_mono.super.init(self)
	self:setBuildingLvupIndex(2)

	local index = 3
	local funcCSV = InfoFunction.checkFuncOpen(10050)

	if funcCSV then
		self:setButtonVisible(index, true)

		local ui = self.buttons[index].ui

		self:setButtonName(ui, funcCSV.name)
	else
		self:setButtonVisible(index, false)
	end

	local index = 4
	local ui = self.buttons[index].ui
	local button = self.buttons[index].button

	button:setCascadeOpacityEnabled(false)
	button:setOpacity(0)

	self.headSlot = HeadSlot.new(ui:getFlagByTag("flag_slot"))

	ui:addChild(self.headSlot, 100)
	self:refresh()
	ManagerInfo.onDataChange(self, "user", nil, function ()
		self:refresh()
	end)
end

function NAV_mono:refresh()
	local index = 4
	local ui = self.buttons[index].ui
	local button = self.buttons[index].button

	self.headSlot:setHead(InfoUser.getHead())
end

function NAV_mono:onTap(index)
	NAV_mono.super.onTap(self, index)

	if index == 1 then
		InfoBuilding.playOpenSfx(InfoBuilding.TAG.MONO)
		FRAME_modao.open(self.npc)
	elseif index == 2 then
		-- Nothing
	elseif index == 3 then
		FRAME_building_plus.open(self.npc)
	elseif index == 4 then
		InfoBuilding.playOpenSfx(InfoBuilding.TAG.MONO)
		FRAME_user_head.open()
	end
end

return NAV_mono
