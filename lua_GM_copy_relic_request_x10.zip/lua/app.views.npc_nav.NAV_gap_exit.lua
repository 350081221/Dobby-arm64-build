local NAV_base = import(".NAV_base")
local NAV_gap_exit = class("NAV_gap_exit", NAV_base)

function NAV_gap_exit.open(npc)
	local ui = NAV_gap_exit.new(npc)

	return ui
end

function NAV_gap_exit:ctor(npc)
	NAV_gap_exit.super.ctor(self, npc, "nav_gap_exit")
end

function NAV_gap_exit:onTap(index)
	NAV_gap_exit.super.onTap(self, index)
	print("NAV_gap_exit:onTap", index, self.npc)

	if index == 1 then
		POP_notice.open(Localization.getSrcText("离开后无法再次进入，是否继续？"), function ()
			if not self.requestLock and self.npc then
				self.requestLock = true

				InfoDungeon.exitGap(self.npc.eventData.index, function (rcvData)
				end, function ()
					self.requestLock = nil
				end)
			end
		end)
	end
end

return NAV_gap_exit
