local UI_base = import("..UI_base")
local FRAME_server_mini = class("FRAME_server_mini", UI_base)

function FRAME_server_mini.open()
	local ui = FRAME_server_mini.new()

	PopManager.open(ui)
end

function FRAME_server_mini:ctor()
	FRAME_server_mini.super.ctor(self, "frame_server_mini")
	self:init()
end

function FRAME_server_mini:init()
	self.noCloseByKey = true

	self:initUI()
end

function FRAME_server_mini:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()
end

return FRAME_server_mini
