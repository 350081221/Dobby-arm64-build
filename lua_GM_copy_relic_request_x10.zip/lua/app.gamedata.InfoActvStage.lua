local InfoActvStage = {}
local dataMap = {}

function InfoActvStage.init()
	Connection.listen("actv_stage_sync", InfoActvStage.sync)
end

app:addToAppEnterCall(InfoActvStage.init)

function InfoActvStage.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoActvStage.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("actv_stage_query", callback)
end

function InfoActvStage.onQuery(rcvData)
	dump(rcvData, "actv_stage_query", 10)

	dataMap = {}

	for i, v in ipairs(rcvData.list) do
		dataMap[v.actv_id] = v
	end

	dump(dataMap, "$$$ dataMap")
end

function InfoActvStage.sync(data)
	dump(data, "InfoActvStage.sync", 10)

	if data.list then
		for i, syncData in ipairs(data.list) do
			if dataMap[syncData.actv_id] then
				for k, v in pairs(syncData) do
					dataMap[syncData.actv_id][k] = v
				end
			else
				dataMap[syncData.actv_id] = syncData
			end
		end
	end

	notify.dispatch("actv_redot")
	ManagerInfo.dataChange("actv_stage")
end

function InfoActvStage.checkOpening(actv_id)
	local opening = InfoActv.checkBindOpening(actv_id, GameConfig.ACTV_TYPE.stage)

	return opening, actv_id
end

function InfoActvStage.checkShopOpening(actv_id)
	local opening = InfoActv.checkBindShopOpening(actv_id, GameConfig.ACTV_TYPE.stage)

	return opening, actv_id
end

function InfoActvStage.afterOpening(actv_id)
	local opening = InfoActv.afterBindOpening(actv_id, GameConfig.ACTV_TYPE.stage)

	return opening
end

function InfoActvStage.getData(actv_id)
	local data = dataMap[actv_id]

	return data
end

function InfoActvStage.getActvID(stage_id)
	for actv_id, data in pairs(dataMap) do
		local opening = InfoActvStage.checkShopOpening(actv_id)

		if opening and data.current == stage_id then
			return actv_id
		end
	end
end

function InfoActvStage.checkNewRecord(stage_id)
	local actv_id = InfoActvStage.getActvID(stage_id)

	if actv_id and InfoDungeon.isPassed() then
		local data = dataMap[actv_id]

		if data.passed_level < InfoDungeon.getLevel() or InfoDungeon.getLevel() == data.passed_level and data.level_time_mark < data.level_time then
			return true
		end
	end

	return false
end

function InfoActvStage.getCurrentCSV(actv_id)
	local data = dataMap[actv_id]

	if data and not empty(data.current) then
		return CsvParser.getCsvData("actv_stage", data.current)
	end
end

function InfoActvStage.setLevel(actv_id, level, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("actv_stage_set_level", {
		actv_id = actv_id,
		level = level
	}, callback)
end

function InfoActvStage.enterStage(actv_id, stage_id, level, sp_index, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			local result = rcvData.dungeon_result
			local title, subTitle = InfoDungeon.getTitle(result.type, result.dungeon_id, result.quest_id, result.abyss_seed)

			Transition.setTitle(title, subTitle)
			Transition.leave(function ()
				if onSuccess then
					onSuccess(result)
				end
			end)
		end
	end

	Connection.request("actv_stage_enter", {
		actv_id = actv_id,
		stage_id = stage_id,
		level = level,
		sp_index = sp_index or 0
	}, callback)
end

function InfoActvStage.create(actv_id, room_id, onSuccess, onFailure)
	InfoActvStage.enterRoom(actv_id, room_id, nil, 1, onSuccess, onFailure)
end

function InfoActvStage.join(actv_id, room_id, inst_id, onSuccess, onFailure)
	InfoActvStage.enterRoom(actv_id, room_id, inst_id, nil, onSuccess, onFailure)
end

function InfoActvStage.match(actv_id, room_id, onSuccess, onFailure)
	InfoActvStage.enterRoom(actv_id, room_id, nil, , onSuccess, onFailure)
end

function InfoActvStage.enterRoom(actv_id, room_id, inst_id, is_private, onSuccess, onFailure)
	OnlineRoom.clear()

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			OnlineRoom.setRoomID(rcvData.room_id)

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("actv_stage_enter_room", {
		actv_id = actv_id,
		room_id = room_id,
		inst_id = inst_id,
		is_private = is_private
	}, callback)
end

function InfoActvStage.stageRecord(actv_id)
	local opening = InfoActvStage.checkOpening(actv_id)

	if opening then
		local data = dataMap[actv_id]

		if data then
			local reward_count = data.reward_count

			if Time.checkDayPassed(data.reward_time) then
				reward_count = 0
			end

			if data.actv_id ~= actv_id then
				reward_count = 0
			end

			return reward_count, data.award_num
		end
	end

	return 0, 0
end

function InfoActvStage.getRecordSp(actv_id, index)
	local data = dataMap[actv_id]
	local recordNum = data.sp_reward_record or 0

	return BitUtil.getBitByIndex(recordNum, index)
end

function InfoActvStage.getRewardList(actv_id)
	local opening, actv_id = InfoActvStage.checkOpening(actv_id)

	if opening then
		local data = dataMap[actv_id]

		if data then
			local rewardArr = {}

			for i, v in ipairs(data.award) do
				table.insert(rewardArr, {
					base_id = v.id,
					num = v.num
				})
			end

			return rewardArr
		end
	end

	return {}
end

function InfoActvStage.countRedot(actv_id)
	local redotCount = 0
	local csv = InfoActvStage.getCurrentCSV(actv_id)
	local spArr = SheetUtil.getColumnValueList(csv, "sp")

	for i, spID in ipairs(spArr) do
		if InfoActvStage.getRecordSp(actv_id, i) == 0 then
			redotCount = redotCount + 1
		end
	end

	return redotCount
end

function InfoActvStage.getLevel(actv_id, stage_id)
	local csv = CsvParser.getCsvData("actv_stage", stage_id)
	local abyssLevel = InfoDungeon.getAbyssMaxLevel()
	local actvData = InfoActv.get(actv_id)

	if actvData then
		local data = dataMap[actv_id]
		local minLevel = math.floor(abyssLevel * csv.min_level_ratio)
		local dayPassed = Time.getToday() - Time.getDay(actvData.stime)
		local maxLevel = nil

		if csv.daily_level_up == -1 then
			maxLevel = csv.max_level
		else
			maxLevel = math.min(abyssLevel + csv.daily_level_up * dayPassed, csv.max_level)
		end

		local currLevel = data.current_level or 0
		currLevel = math.max(minLevel, math.min(currLevel, maxLevel))
		local passedLevel = data.passed_level

		return minLevel, maxLevel, currLevel, passedLevel
	end
end

local stageRankingMaxCache = nil

function InfoActvStage.getRankingMax(actv_stage_id)
	if not stageRankingMaxCache then
		stageRankingMaxCache = {}
		local csvRaw = CsvParser.getCsvRaw("actv_stage_rank")

		for k, csv in pairs(csvRaw) do
			if not stageRankingMaxCache[csv.rank_reward_id] then
				stageRankingMaxCache[csv.rank_reward_id] = csv.ranking_max
			else
				stageRankingMaxCache[csv.rank_reward_id] = math.max(stageRankingMaxCache[csv.rank_reward_id], csv.ranking_max)
			end
		end
	end

	local csv = CsvParser.getCsvData("actv_stage", actv_stage_id)

	if not empty(csv.rank_reward_id) then
		return stageRankingMaxCache[csv.rank_reward_id]
	end
end

local ranking_map_type = {}
local requesting_map_type = {}
local request_time_map_type = {}
local rankingAmount_type = {}
local selfRank_type = {}
local snapshot_type = {}

function InfoActvStage.getMyRank(actv_id)
	return selfRank_type[actv_id] or 0
end

function InfoActvStage.getRankingAmount(actv_id)
	return rankingAmount_type[actv_id] or 0
end

function InfoActvStage.getRankingSnapshot(actv_id)
	return snapshot_type[actv_id]
end

function InfoActvStage.checkRankingReward(onSuccess, onFailure)
	local needCheck = false

	for actv_id, data in pairs(dataMap) do
		if data.rewarded == 0 and InfoActvStage.afterOpening(actv_id) then
			local csv = CsvParser.getCsvData("actv_stage", data.current)

			if csv and not empty(csv.rank_reward_id) then
				needCheck = true

				break
			end
		end
	end

	print("$$$ InfoActvStage.checkRankingReward needCheck", needCheck)

	if needCheck then
		local function callback(rcvData)
			if rcvData.err then
				if onFailure then
					onFailure(rcvData.err)
				end
			elseif onSuccess then
				onSuccess(rcvData)
			end
		end

		Connection.request("actv_stage_ranking_reward", callback)
	end
end

function InfoActvStage.startRanking(actv_id, isArea, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			rankingAmount_type[actv_id] = rcvData.amount
			selfRank_type[actv_id] = rcvData.self_rank
			snapshot_type[actv_id] = rcvData.snapshot

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("actv_stage_ranking_start", {
		actv_id = actv_id,
		is_area = isArea and 1 or 0
	}, callback)
end

function InfoActvStage.getRanking(actv_id, page, isArea, onSuccess, onFailure)
	local ranking_map, requesting_map, request_time_map = InfoActvStage.prepareRanking(actv_id)
	local start_index = (page - 1) * GameConfig.ranking_page + 1
	local actv_stage_ranking_look_num = CsvParser.getCsvData("config", "actv_stage_ranking_look_num").value
	local data = InfoActvStage.getData(actv_id)
	local ranking_max = InfoActvStage.getRankingMax(data.current) or actv_stage_ranking_look_num

	if ranking_max < start_index then
		return
	end

	local function callback(rcvData)
		requesting_map[page] = nil
		request_time_map[page] = Time.time()

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			local list = rcvData.list

			for i, v in ipairs(list) do
				local rank = start_index + i - 1
				local snapshot = {}

				if not empty(v.snapshot) then
					snapshot = json.decode(v.snapshot) or {}
				end

				ranking_map[rank] = {
					rank = rank,
					id = v.id,
					user_id = v.user_id,
					name = v.name,
					level = v.level,
					level_time = v.level_time,
					head = v.head,
					head_frame = v.head_frame,
					score = v.score,
					snapshot = snapshot
				}
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	requesting_map[page] = true

	Connection.request("actv_stage_ranking", {
		actv_id = actv_id,
		start_index = start_index,
		is_area = isArea and 1 or 0
	}, callback)
end

function InfoActvStage.getRankingData(actv_id, rank, isArea)
	local ranking_map, requesting_map, request_time_map = InfoActvStage.prepareRanking(actv_id)
	local page = math.floor((rank - 1) / GameConfig.ranking_page) + 1

	if not ranking_map[rank] or GameConfig.ranking_local_time < Time.time() - request_time_map[page] then
		if not requesting_map[page] then
			InfoActvStage.getRanking(actv_id, page, isArea)
		end
	else
		return ranking_map[rank]
	end
end

function InfoActvStage.prepareRanking(actv_id)
	if not ranking_map_type[actv_id] then
		ranking_map_type[actv_id] = {}
	end

	if not requesting_map_type[actv_id] then
		requesting_map_type[actv_id] = {}
	end

	if not request_time_map_type[actv_id] then
		request_time_map_type[actv_id] = {}
	end

	return ranking_map_type[actv_id], requesting_map_type[actv_id], request_time_map_type[actv_id]
end

local lookCached = {}

function InfoActvStage.look(actv_id, id, onSuccess, onFailure)
	local code = actv_id .. "_" .. id

	if lookCached[code] and Time.time() - lookCached[code].time < 60 then
		if onSuccess then
			onSuccess(lookCached[code].data)
		end

		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			lookCached[code] = {
				data = rcvData,
				time = Time.time()
			}

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("actv_stage_look", {
		actv_id = actv_id,
		id = id
	}, callback)
end

function InfoActvStage.clearRanking(actv_id)
	ranking_map_type[actv_id] = {}
	requesting_map_type[actv_id] = {}
	request_time_map_type[actv_id] = {}
end

return InfoActvStage
