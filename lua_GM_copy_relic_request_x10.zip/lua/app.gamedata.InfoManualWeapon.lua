local InfoManualWeapon = {}
local rawData = {}

function InfoManualWeapon.init()
	Connection.listen("manual_weapon_sync", InfoManualWeapon.sync)
end

app:addToAppEnterCall(InfoManualWeapon.init)

function InfoManualWeapon.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoManualWeapon.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("manual_weapon_query", callback)
end

function InfoManualWeapon.onQuery(rcvData)
	dump(rcvData, "manual_weapon_query")

	rawData = {}

	for i, data in ipairs(rcvData.list) do
		rawData[data.base_id] = data
	end
end

function InfoManualWeapon.sync(data)
	for i, syncData in ipairs(data.list) do
		local base_id = syncData.base_id

		if rawData[base_id] then
			for k, v in pairs(syncData) do
				rawData[base_id][k] = v
			end
		else
			rawData[base_id] = syncData
		end
	end

	ManagerInfo.dataChange("manual_weapon")
end

function InfoManualWeapon.mark(arr, onSuccess, onFailure)
	local id_arr = {}

	for i, manualID in ipairs(arr) do
		if rawData[manualID] and rawData[manualID].is_new == 1 then
			table.insert(id_arr, manualID)
		end
	end

	if #id_arr == 0 then
		return
	end

	local function callback(rcvData)
		dump(rcvData, "manual_weapon_mark")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("manual_weapon_mark", {
		id_arr = id_arr
	}, callback)
end

function InfoManualWeapon.getData(base_id)
	return rawData[base_id]
end

function InfoManualWeapon.getEquipInfo(base_id)
	local manualCSV = CsvParser.getCsvData("manual_weapon", base_id)
	local equip_csv = CsvParser.getCsvData("equip", base_id)
	local equip_info = {
		quality = 0,
		identified = 0,
		slot_max = 0,
		slot = 0,
		best_suffix = 0,
		best_prefix = 0,
		enhance_level = 0,
		drop_rare = 1,
		level = 1,
		drop_level = 1,
		base_id = base_id,
		equip_pos = equip_csv.equip_pos,
		ran = math.random(1, 65535)
	}

	for i = 1, GameConfig.equip_affix_max do
		equip_info["prefix_" .. i] = 0
		equip_info["preran_" .. i] = 0
		equip_info["suffix_" .. i] = 0
		equip_info["sufran_" .. i] = 0
	end

	for i = 1, GameConfig.equip_gem_max do
		equip_info["gem" .. i] = 0
	end

	return equip_info
end

function InfoManualWeapon.getList()
	local csvList = CsvParser.getCsvList("manual_weapon")

	return csvList
end

function InfoManualWeapon.countRedot()
	local redotCount = 0
	local csvList = CsvParser.getCsvList("manual_weapon")
	local existMap = {}

	for i, csv in ipairs(csvList) do
		if rawData[csv.id] and rawData[csv.id].is_new == 1 then
			redotCount = redotCount + 1
		end
	end

	return redotCount
end

return InfoManualWeapon
