local SkillTrigger = {
	check = function (triggerStr, caster, target, ran)
		if empty(triggerStr) then
			return true
		end

		ran = ran or math.random()
		triggerStr = string.gsub(triggerStr, "ran", ran)

		return Serialize.unserialize(triggerStr)
	end
}

return SkillTrigger
