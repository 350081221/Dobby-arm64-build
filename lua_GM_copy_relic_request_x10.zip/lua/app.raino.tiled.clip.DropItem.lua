local ClipOnMap = import(".ClipOnMap")
local DropItem = class("DropItem", ClipOnMap)

function DropItem:ctor()
	DropItem.super.ctor(self, "dropItem")

	self.alwaysVisible = true
	self.zorderOffset = -1
	self.effects = {}
	self.last_effects = {}
end

function DropItem:loadPic(url)
	DropItem.super.loadPic(self, url)

	local rect = IconManager.getImageRect(url)

	if rect then
		self.yoff = self.height - (rect.y + rect.height)
	end
end

function DropItem:setDrop(info)
	self.dropType = info.type
	self.dropInfo = info.info
	self.eventIndex = info.eventIndex
	local iconPath = nil

	if self.dropType == DropManager.TYPE.EQUIP then
		iconPath = IconManager.getEquipIcon(self.dropInfo.base_id)
	elseif self.dropType == DropManager.TYPE.ITEM then
		iconPath = IconManager.getItemIcon(self.dropInfo.base_id)
	elseif self.dropType == DropManager.TYPE.CARD then
		iconPath = IconManager.getCardIcon(self.dropInfo.base_id)
	elseif self.dropType == DropManager.TYPE.SIGIL then
		local sigilCSV = CsvParser.getCsvData("sigil", info.base_id)
		iconPath = IconManager.getHeroIcon(sigilCSV.pic)
	end

	self:loadPic(iconPath)
end

function DropItem:draw(x, y, setXY)
	x = x or self.x
	y = y or self.y
	local drawX, drawY = DropItem.super.draw(self, x, y, setXY)

	if Unit.focusUnit == self and not self.map.isBattle then
		self.map:scrollTo(x, y)
		self.map:setFov(x, y)
	end

	return drawX, drawY
end

function DropItem:flyShake(time, height, shakeRange, waitTime, onComplete)
	local loopFunc = nil
	local map = self.map

	local function _onComplete()
		MapFrameManager.stopLoop(self, loopFunc)
		map:setPositionOffsetTween("flyShake", 0, 0, 60)

		if onComplete then
			onComplete()
		end
	end

	local effectGen = self:getEffectGen()

	if effectGen then
		effectGen:shake(0, time + waitTime)
	end

	local timeCount = 0
	local preShakeTime = -1

	function loopFunc(obj, frame, passed, sharp)
		timeCount = timeCount + passed

		if timeCount < time then
			local _height = math.min(height, height * timeCount / time)
			local shakeTime = math.floor(timeCount / 30)

			if preShakeTime < shakeTime then
				preShakeTime = shakeTime
				local _shakeRange = math.min(shakeRange, math.sqrt(shakeRange * timeCount / time))
				local effectGen = self:getEffectGen()

				if effectGen then
					effectGen:setShakeRange(_shakeRange)
				end
			end

			local effectGen = self:getEffectGen()

			if effectGen then
				effectGen:zmove(0, _height)
			end

			map:setPositionOffset("flyShake", 0, -_height * global.map.viewZoom)
		elseif timeCount >= time + waitTime then
			_onComplete()
		end
	end

	MapFrameManager.startLoop(self, loopFunc)
end

function DropItem:flyToPrecious(onComplete)
	local loopFunc = nil
	local map = self.map

	local function _onComplete()
		MapFrameManager.stopLoop(self, loopFunc)
		POP_precious.open(self.dropInfo.base_id, function ()
			global.player:stop()

			local units = TeamManager.getUnits()

			for i, unit in ipairs(units) do
				local effectGen = unit:getEffectGen()

				if effectGen then
					effectGen:fadeTo(30, 255, "outQuad")
				end
			end

			MapUtils.focusOut(nil, , time)
			map:setPositionOffsetTween("flyToPrecious", 0, 0, 30)

			if onComplete then
				onComplete()
			end
		end)
	end

	MapUtils.focusIn(self, nil, 30, 2)

	local flyTime = 150
	local flyHeight = 100

	MapFrameManager.setTimeout(function ()
		local effectGen = self:getEffectGen()

		if effectGen then
			effectGen:fadeTo(30, 0, "linear", function ()
				if _onComplete then
					_onComplete()
				end

				self:removeSelf()
			end)
		end
	end, 120, self)

	local height = 0
	local preArcCount = 0

	function loopFunc(obj, frame, passed, sharp)
		height = height + passed * flyHeight / flyTime
		local arcCount = math.floor(frame / 12)

		if preArcCount < arcCount then
			local str = "6&-1~~&-1~~~~~.5~~~.1~&1~~~.1~&2&1&effect_blue_ash~~~~~&12&{1}~&1~&100~&200&2~~"
			str = StringUtil.replace(str, height / map.config.scale.unit / map.config.scale.map)
			local arcEffect = ArcEffect.new(map, cc.p(self.x, self.y), 0, str)

			arcEffect:start()
		end

		preArcCount = arcCount

		map:setPositionOffset("flyToPrecious", 0, -height)

		local effectGen = self:getEffectGen()

		if effectGen then
			effectGen:zmove(0, height)
		end
	end

	MapFrameManager.startLoop(self, loopFunc)

	local units = TeamManager.getUnits()

	for i, unit in ipairs(units) do
		local effectGen = unit:getEffectGen()

		if effectGen then
			effectGen:fadeTo(30, 0, "outQuad")
		end
	end
end

function DropItem:flyToBag(onComplete)
	local itemID = self.dropInfo.base_id
	local itemCSV = CsvParser.getCsvData("item", itemID)

	if not empty(itemCSV.convert_item) then
		itemID = itemCSV.convert_item
	end

	local ui = global.adventureUI.bottomUI:getComponentByTag("bt_bag")
	local x, y = ui:getPosition()
	local pos = global.adventureUI.bottomUI:convertToWorldSpace(cc.p(x, y))
	local scale = 1
	local x, y = self:getPosition()
	local worldPos = self:getParent():convertToWorldSpace(cc.p(x, y))

	self:retain()
	self:removeFromParent()
	self:setPosition(worldPos.x, worldPos.y)
	display.getRunningScene():addChild(self)
	self:release()

	local function _onComplete()
		self:removeSelf()
		MapEffect.quake()

		if onComplete then
			onComplete()
		end
	end

	local time = math.random() * 0.2 + 0.5
	local effectGen = self:getEffectGen()

	if effectGen then
		effectGen:zmove(math.floor(time * 60), 0)
	end

	transition.scaleTo(self, {
		time = time,
		scale = scale
	})

	local easingArr = {
		"linear",
		"sineIn",
		"sineOut"
	}

	transition.moveTo(self, {
		time = time,
		x = pos.x,
		easing = easingArr[math.random(1, #easingArr)]
	})

	local peakY = worldPos.y - math.max(-math.random(100, 150), pos.y - worldPos.y)

	transition.moveTo(self, {
		easing = "sineOut",
		time = time / 2,
		y = peakY,
		onComplete = function ()
			transition.moveTo(self, {
				easing = "sineIn",
				time = time / 2,
				y = pos.y - self.height * scale / 2,
				onComplete = _onComplete
			})
		end
	})
end

function DropItem:flyToResource(onComplete)
	local itemID = self.dropInfo.base_id
	local itemCSV = CsvParser.getCsvData("item", itemID)

	if not empty(itemCSV.convert_item) then
		itemID = itemCSV.convert_item
	end

	local ui, pos, scale = global.resource:readyFly(itemID)
	local x, y = self:getPosition()
	local worldPos = self:getParent():convertToWorldSpace(cc.p(x, y))

	self:retain()
	self:removeFromParent()
	self:setPosition(worldPos.x, worldPos.y)
	display.getRunningScene():addChild(self)
	self:release()

	local function _onComplete()
		self:clearLight()
		self:removeSelf()
		ui:addNum(self.dropInfo.num)
		global.resource:flyOver(itemID)

		if onComplete then
			onComplete()
		end
	end

	local time = math.random() * 0.2 + 0.2

	transition.scaleTo(self, {
		time = time,
		scale = scale
	})

	local easingArr = {
		"backIn",
		"linear",
		"sineIn",
		"sineOut"
	}

	transition.moveTo(self, {
		time = time,
		x = pos.x,
		easing = easingArr[math.random(1, #easingArr)]
	})
	transition.moveTo(self, {
		time = time,
		y = pos.y - self.height * scale / 2,
		onComplete = _onComplete
	})
end

function DropItem:fadeUp(onComplete, upTime, fadeTime, height, easing)
	local function _onComplete()
		local effectGen = self:getEffectGen()

		if effectGen then
			effectGen:fadeTo(fadeTime or 10, 0, "linear", function ()
				self:removeSelf()

				if onComplete then
					onComplete()
				end
			end)
		end
	end

	local effectGen = self:getEffectGen()

	if effectGen then
		effectGen:zTween(upTime or 20, 0, height or 200, easing or "outBack", _onComplete)
	end
end

function DropItem:jump(dest, speed, height, callback, minTime, onUpdate)
	self.angle = math.atan2(dest.y - self.y, dest.x - self.x)
	minTime = minTime or 20
	local startardRange = 96
	local distance = math.sqrt(math.pow(dest.y - self.y, 2) + math.pow(dest.x - self.x, 2))
	local frameTime = math.floor(distance / speed)

	if frameTime < minTime then
		frameTime = minTime
		distance = frameTime * speed
	end

	self.jumpData = {
		from = {
			x = self.x,
			y = self.y
		},
		to = dest,
		height = height,
		countTotal = frameTime,
		count = frameTime,
		callback = callback,
		onUpdate = onUpdate
	}

	if height > 0 then
		height = height * math.pow(distance / startardRange, 0.2) / 5
		local gravity = height / (frameTime / 2)
		self.jumpData.gravity = gravity
		self.jumpData.zSpeed = -math.pow(frameTime, 2) * gravity / 2 / frameTime
	elseif height == -1 then
		self.jumpData.initZ = self.z
	end

	MapFrameManager.startLoop(self, self.jumpLoop)

	return frameTime
end

function DropItem:jumpLoop(frame, passed, sharp)
	self.jumpData.count = self.jumpData.count - passed

	if self.jumpData.gravity then
		self.z = self.z - self.jumpData.zSpeed * passed
		self.jumpData.zSpeed = self.jumpData.zSpeed + self.jumpData.gravity * sharp
	elseif self.jumpData.height == -1 then
		self.z = self.jumpData.initZ * self.jumpData.count / self.jumpData.countTotal
	end

	local overCallback = nil
	local onUpdate = self.jumpData.onUpdate

	if self.jumpData.count <= 0 then
		self.x = self.jumpData.to.x
		self.y = self.jumpData.to.y
		self.z = 0
		overCallback = self.jumpData.callback

		self:stopJump()
	else
		local jumpPercent = (self.jumpData.countTotal - self.jumpData.count) / self.jumpData.countTotal
		self.x = self.jumpData.from.x + (self.jumpData.to.x - self.jumpData.from.x) * jumpPercent
		self.y = self.jumpData.from.y + (self.jumpData.to.y - self.jumpData.from.y) * jumpPercent
	end

	self:draw()
	self:retile()

	if onUpdate then
		onUpdate()
	end

	if overCallback then
		overCallback()
	end
end

function DropItem:stopJump()
	MapFrameManager.stopLoop(self, self.jumpLoop)

	self.jumpData = nil
end

function DropItem:addLastingEffect(effectName, frameTime, noCount)
	if not self.map then
		self.readyLastingEffect = self.readyLastingEffect or {}

		table.insert(self.readyLastingEffect, {
			effectName = effectName,
			frameTime = frameTime,
			noCount = noCount
		})

		return
	end

	if self.last_effects[effectName] then
		local obj = self.last_effects[effectName]
		obj.count = obj.count + 1

		if frameTime and frameTime > 0 then
			MapFrameManager.setTimeout(function ()
				self:removeEffect(effectName)
			end, frameTime, obj.clip)
		end

		return obj.clip
	end

	local effect = Effect.new()

	effect:load(effectName)

	local spines = nil

	if effect.clipType == Clip.CLIP_TYPE.SPINE then
		spines = {}

		effect:refreshSpine(self.map)

		for i, skeleton in ipairs(effect.skeletons) do
			local obj = {
				clip = skeleton,
				overhead = effect.skeletonParams[i].overhead == 1
			}

			table.insert(spines, obj)
		end
	end

	if effect:hasAction("start") then
		effect:setAction("start", 1, function ()
			effect:setAction("idle")
		end)
	end

	if effect.layer == 0 then
		self.map.lowLayer:addChild(effect)
	elseif effect.layer == 2 then
		self.map.highLayer:addChild(effect)
	else
		self.map.baseLayer:addChild(effect)
	end

	local obj = {
		count = 1,
		clip = effect,
		overhead = effect.overhead,
		name = effectName,
		spines = spines
	}
	self.last_effects[effectName] = obj
	local bodyScale = math.max(1, self:getTotalWidth() / 96)
	local effectScale = 1

	if effect.param and effect.param.effect_scale then
		effectScale = effect.param.effect_scale
	end

	effect:setScale(math.sqrt(self.scale * bodyScale) * effectScale)
	self:draw()

	if frameTime and frameTime > 0 then
		MapFrameManager.setTimeout(function ()
			self:removeLastingEffect(effectName)
		end, frameTime, effect)
	end

	return effect
end

function DropItem:removeLastingEffect(effectName, noCount)
	if self.last_effects[effectName] then
		local obj = self.last_effects[effectName]

		if not noCount and obj.count > 1 then
			obj.count = obj.count - 1
		else
			local effect = obj.clip

			if effect.hasAction and effect:hasAction("over") then
				effect:setAction("over", 1, function ()
					effect:removeSelf()
				end)
			else
				effect:removeSelf()
			end

			self.last_effects[effectName] = nil
		end
	end
end

function DropItem:addEffect(effectName, customAction)
	self:removeEffect(effectName)

	local effect = Effect.new()

	effect:load(effectName)

	local spines = nil

	if effect.clipType == Clip.CLIP_TYPE.SPINE then
		spines = {}

		effect:refreshSpine(self.map)

		for i, skeleton in ipairs(effect.skeletons) do
			local obj = {
				clip = skeleton,
				overhead = effect.skeletonParams[i].overhead == 1
			}

			table.insert(spines, obj)
		end
	end

	if effect.layer == 0 then
		self.map.lowLayer:addChild(effect)
	elseif effect.layer == 2 then
		self.map.highLayer:addChild(effect)
	else
		self.map.baseLayer:addChild(effect)
	end

	local obj = {
		clip = effect,
		overhead = effect.overhead,
		spines = spines
	}
	self.effects[effectName] = obj
	local bodyScale = math.max(1, self:getTotalWidth() / 96)
	local effectScale = 1

	if effect.param and effect.param.effect_scale then
		effectScale = effect.param.effect_scale
	end

	effect:setScale(math.sqrt(self.scale * bodyScale) * effectScale)

	if not customAction then
		local effectAction = "idle"

		if effect:hasAction(self.action) then
			effectAction = self.action
		end

		effect:setAction(effectAction, 1, function ()
			if self.removeEffect then
				self:removeEffect(effectName)
			end
		end, nil, "over")
	end

	self:draw()

	return effect, obj
end

function DropItem:removeEffect(effectName)
	if self.effects[effectName] then
		local obj = self.effects[effectName]

		if not tolua.isnull(obj.clip) then
			obj.clip:setOpacity(0)

			if obj.clip.delayRemove then
				obj.clip:delayRemove()
			else
				obj.clip:removeSelf()
			end
		end

		self.effects[effectName] = nil
	end
end

function DropItem:clearEffect()
	if self.effects then
		for effectName, obj in pairs(self.effects) do
			local clip = obj.clip

			if not tolua.isnull(clip) then
				if clip.delayRemove then
					clip:delayRemove()
				else
					clip:removeSelf()
				end
			end
		end

		self.effects = {}
	end

	if self.last_effects then
		for effectName, obj in pairs(self.last_effects) do
			local clip = obj.clip

			if not tolua.isnull(clip) then
				if clip.delayRemove then
					clip:delayRemove()
				else
					clip:removeSelf()
				end
			end
		end

		self.last_effects = {}
	end
end

function DropItem:setBmpY()
	DropItem.super.setBmpY(self)

	local selfZ = self:getZ()

	if self.effects then
		for effectName, obj in pairs(self.effects) do
			local effectY = -self.drawY

			if obj.overhead then
				effectY = effectY + self.height
			end

			if obj.clip.layer == 0 and not obj.overhead then
				obj.clip:setPosition(self.drawX, effectY)
			else
				obj.clip:setPosition(self.drawX, effectY + selfZ * obj.clip.scale)
			end

			obj.clip:setLocalZOrder(self.drawY + (obj.zOffset or 0))

			if obj.spines then
				for i, spineObj in ipairs(obj.spines) do
					local effectY = -self.drawY

					if spineObj.overhead then
						effectY = effectY + self.height
					end

					if spineObj.clip.layer == 0 and not spineObj.overhead then
						spineObj.clip:setPosition(self.drawX, effectY - spineObj.clip.yoff)
					else
						spineObj.clip:setPosition(self.drawX, effectY + selfZ * spineObj.clip.scale - spineObj.clip.yoff)
					end

					spineObj.clip:setLocalZOrder(self.drawY + (spineObj.clip.zOffset or 0))
				end
			end
		end
	end

	if self.last_effects then
		for effectName, obj in pairs(self.last_effects) do
			local effectY = -self.drawY

			if obj.overhead then
				effectY = effectY + self.height
			end

			if obj.clip.layer == 0 and not obj.overhead then
				obj.clip:setPosition(self.drawX, effectY)
			else
				obj.clip:setPosition(self.drawX, effectY + selfZ * obj.clip.scale)
			end

			obj.clip:setLocalZOrder(self.drawY + (obj.zOffset or 0))

			if obj.spines then
				for i, spineObj in ipairs(obj.spines) do
					local effectY = -self.drawY

					if spineObj.overhead then
						effectY = effectY + self.height
					end

					if spineObj.clip.layer == 0 and not spineObj.overhead then
						spineObj.clip:setPosition(self.drawX, effectY - spineObj.clip.yoff)
					else
						spineObj.clip:setPosition(self.drawX, effectY + selfZ * spineObj.clip.scale - spineObj.clip.yoff)
					end

					spineObj.clip:setLocalZOrder(self.drawY + (spineObj.clip.zOffset or 0))
				end
			end
		end
	end
end

function DropItem:delayRemove()
	MapFrameManager.setTimeout(function ()
		self:removeSelf()
	end, 1, self)
end

function DropItem:setOpacity(opacity)
	DropItem.super.setOpacity(self, opacity)

	if self.effects then
		for effectName, obj in pairs(self.effects) do
			obj.clip:setOpacity(opacity)
		end
	end

	if self.last_effects then
		for effectName, obj in pairs(self.last_effects) do
			obj.clip:setOpacity(opacity)
		end
	end
end

function DropItem:refreshVisible(force)
	local visibleChanged = DropItem.super.refreshVisible(self, force)

	if visibleChanged then
		if self.effects then
			for effectName, obj in pairs(self.effects) do
				obj.clip:setVisible(self.visible)
			end
		end

		if self.last_effects then
			for effectName, obj in pairs(self.last_effects) do
				obj.clip:setVisible(self.visible)
			end
		end
	end
end

return DropItem
