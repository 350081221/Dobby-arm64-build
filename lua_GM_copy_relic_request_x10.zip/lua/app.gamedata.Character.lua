local Character = {
	TIMING = {
		BATTLE_START_ELITE = 106,
		TEAM_DIE = 105,
		BATTLE_HURT = 104,
		BATTLE_KILL = 103,
		BATTLE_WIN = 102,
		BATTLE_START = 101,
		RETURN_CAMP = 6,
		START_CAMP = 5,
		OLD_MAP = 4,
		NEW_MAP = 3,
		POS_ON = 2,
		TAVERN_SELECT = 1
	}
}
local characterMap, characterPowerMap = nil

function Character.getCharacter(character, timing)
	if not characterMap then
		characterMap = {}
		characterPowerMap = {}
		local csvList = CsvParser.getCsvList("hero_character")

		for i, data in ipairs(csvList) do
			if not characterMap[data.character] then
				characterMap[data.character] = {}
				characterPowerMap[data.character] = {}
			end

			if not characterMap[data.character][data.timing] then
				characterMap[data.character][data.timing] = {}
				characterPowerMap[data.character][data.timing] = {}
			end

			table.insert(characterMap[data.character][data.timing], data)
			table.insert(characterPowerMap[data.character][data.timing], data.power)
		end
	end

	if characterMap[character] and characterMap[character][timing] then
		local arr = characterMap[character][timing]
		local powerArr = characterPowerMap[character][timing]
		local index = SheetUtil.getPowerRandomIndex(powerArr)

		return SheetUtil.getString(arr[index].msg)
	end
end

return Character
