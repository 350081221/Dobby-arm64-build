local POP_realname = class("POP_realname", UI_base)

function POP_realname.open()
	local ui = POP_realname.new()

	display.getRunningScene():addChild(ui, LayerConfig.sys)
	PopManager.popinAnim(ui, nil, PopManager.ANIM_TYPE.JUMP)
end

function POP_realname:ctor()
	POP_realname.super.ctor(self, "pop_realname")
	self:init()
end

function POP_realname:init()
	self:initUI()
end

function POP_realname:initUI()
	local mask = self:getComponentByTag("mask")

	mask:toTouchable()

	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local closePB = self:getComponentByTag("bt_close")

	closePB:toTouchable()
	closePB:addTap(function ()
		Sound.playSound("ui_close")
		PopManager.fadeoutAnim(self)
	end)

	self.nameEB = self:createEditBoxOnComponent("eb_name")

	self.nameEB:setInputMode(6)

	self.sfzEB = self:createEditBoxOnComponent("eb_sfz")

	self.sfzEB:setInputMode(6)

	local confirmPB = self:getComponentByTag("bt_confirm")

	confirmPB:toTouchable()
	confirmPB:addTap(function ()
		self:yanzheng()
	end)
	confirmPB:setTapGroup("button_click")
end

function POP_realname:yanzheng()
	local name = self.nameEB:getText()
	local sfz = self.sfzEB:getText()
	sfz = string.upper(sfz)

	if name == "" then
		Alert.open("请输入真实姓名")

		return
	end

	if sfz == "" then
		Alert.open("请输入身份证号")

		return
	end

	if SFZ.verify(sfz) ~= SFZ.ERR.SUCCESS then
		Alert.open("身份证号码错误")

		return
	end

	InfoUser.checkRealname(name, sfz, function (rcvData)
	end, function (err)
	end)
end

return POP_realname
