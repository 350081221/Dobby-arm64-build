local List = import("...ui.List")
local LIST_dungeon_prepare_hero = class("LIST_dungeon_prepare_hero", List)

function LIST_dungeon_prepare_hero:ctor(rect)
	LIST_dungeon_prepare_hero.super.ctor(self, rect)
	self:setCellName("cell_dungeon_prepare_hero")
	self:setSpace(5, 5)
	self:setCellSize(cc.size(self.touchRect.width, 110))
end

function LIST_dungeon_prepare_hero:onCellInit(ui, heroInfo)
	local heroData = CsvParser.getCsvData("hero", heroInfo.base_id)
	ui.pickVisibleArr = {}

	table.insert(ui.pickVisibleArr, ui:getComponentByTag("bg"))
	table.insert(ui.pickVisibleArr, ui:getComponentByTag("border"))

	if not ui.slot then
		local slotFlag = ui:getFlagByTag("flag_slot")
		ui.slot = DropSlot.new(slotFlag, "slot_01")

		ui:addChild(ui.slot, 100)
	end

	local affixData = CsvParser.getCsvData("hero_affix", heroInfo.affix)
	local label = ui:createLabelOnFlag("flag_name", InfoHero.getName(heroInfo))

	table.insert(ui.pickVisibleArr, label)

	local label = ui:replaceLabelOnFlag("flag_job_affix_level", nil, heroData.job_name, affixData.name, heroInfo.level)

	table.insert(ui.pickVisibleArr, label)

	local label = ui:replaceLabelOnFlag("flag_score", nil, InfoHero.getScore(heroInfo))

	table.insert(ui.pickVisibleArr, label)
	ui.slot:setDrop(DropManager.TYPE.HERO, heroInfo)
end

function LIST_dungeon_prepare_hero:onCellPicked(ui, data, picked)
	for i, com in ipairs(ui.pickVisibleArr) do
		com:setVisible(not picked)
	end
end

return LIST_dungeon_prepare_hero
