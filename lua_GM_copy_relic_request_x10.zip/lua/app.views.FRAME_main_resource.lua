local UI_base = import(".UI_base")
local FRAME_main_resource = class("FRAME_main_resource", UI_base)

function FRAME_main_resource:ctor(uiName, count, ...)
	FRAME_main_resource.ui = self

	FRAME_main_resource.super.ctor(self, uiName or "frame_main_resource", UIManager.BIG_TYPE.TOP)

	self.count = count
	self.items = {
		...
	}

	self:init()
end

function FRAME_main_resource:init()
	self:initUI()

	self.lockedMap = {}

	self:refreshResource()
	notify.safeRegister(self, "liuhai_change", function ()
		self:refreshResource()
	end)
	self:refreshRedot()
	ManagerInfo.onDataChange(self, "service", nil, function (data)
		self:refreshRedot()
	end)
end

function FRAME_main_resource:refreshRedot()
	local redot_setup = self:getComponentByTag("redot_setup")

	if redot_setup then
		redot_setup:setVisible(InfoService.countRedot() > 0)
	end
end

function FRAME_main_resource:getResourceRect()
	local rect = self:getFlagByTag("flag_resource")
	rect = {
		x = rect.x,
		y = rect.y,
		width = rect.width,
		height = rect.height
	}

	if UIManager.getLiuhai() == "left" then
		rect.x = rect.x + UIManager.LIUHAI_WIDTH
		rect.width = rect.width - UIManager.LIUHAI_WIDTH
	end

	return rect
end

function FRAME_main_resource:refreshResource()
	local rect = self:getResourceRect()

	if self.resourceUIArr then
		for i, ui in ipairs(self.resourceUIArr) do
			ui:removeSelf()
		end

		self.resourceUIArr = nil
	end

	self.resourceUIArr = {}
	local cols = self.count
	local perWidth = math.floor(rect.width / cols)

	if perWidth < 118 then
		cols = math.ceil(self.count / 2)
		perWidth = math.floor(rect.width / cols)
	end

	self.space = math.min(self.space, math.floor(perWidth))
	self.cols = cols
	local resourceList = {}

	for i, itemID in ipairs(self.items) do
		local ui = Resource.new(itemID, "com_resource", nil, self.space, i / #self.items)
		local x, y = self:getPos(i)

		ui:setPosition(x, y)
		self:addChild(ui)

		self.resourceMap[itemID] = ui
		local icon = ui.icon
		local x, y = icon:getPosition()
		ui.iconPos = icon:getParent():convertToWorldSpace(cc.p(x, y))
		ui.iconScale = icon:getScaleX()
		self.occupiedMap[i] = ui
		self.occupiedFixed = self.occupiedFixed + 1

		ui:setLocalZOrder(100 - i)
		table.insert(self.resourceUIArr, ui)
	end
end

function FRAME_main_resource:getPos(index)
	local rect = self:getResourceRect()
	local x, y = nil

	if index <= self.cols then
		x = rect.x + rect.width - ((index - 1) % self.cols + 1) * self.space
		y = rect.y - math.floor((index - 1) / self.cols) * rect.height
	else
		x = rect.x + rect.width - ((index - 2) % (self.cols - 1) + 1) * self.space - self.space
		y = rect.y - math.floor((index - 2) / (self.cols - 1)) * rect.height
	end

	return x, y
end

function FRAME_main_resource:initUI()
	self.resourceMap = {}
	self.tempResourceMap = {}
	self.lockMap = {}
	self.occupiedMap = {}
	self.occupiedFixed = 1
	self.space = 200
	local setupBtn = self:getComponentByTag("bt_setup")

	if setupBtn then
		setupBtn:toTouchable()
		setupBtn:addTap(function ()
			POP_setup.open()
		end)
		setupBtn:setTapGroup("button_click")
	end

	local mailBtn = self:getComponentByTag("bt_mail")

	if mailBtn then
		mailBtn:toTouchable()
		mailBtn:addTap(function ()
			FRAME_mail.open()
		end)
		mailBtn:setTapGroup("button_click")

		local mailRedot = self:getComponentByTag("redot_mail")

		mailRedot:setVisible(InfoMail.countRedot() > 0 or InfoMailPerson.countRedot() > 0)
		ManagerInfo.onDataChange(self, "mail", nil, function (data)
			mailRedot:setVisible(InfoMail.countRedot() > 0 or InfoMailPerson.countRedot() > 0)
		end)
		ManagerInfo.onDataChange(self, "mail_person", nil, function (data)
			mailRedot:setVisible(InfoMail.countRedot() > 0 or InfoMailPerson.countRedot() > 0)
		end)
	end
end

function FRAME_main_resource:prepareTempResource(itemID)
	if self.resourceMap[itemID] then
		return self.resourceMap[itemID]
	end

	local occupiedIndex = self.occupiedFixed

	while self.occupiedMap[occupiedIndex] do
		occupiedIndex = occupiedIndex + 1
	end

	local rect = self:getResourceRect()
	local ui = Resource.new(itemID, "com_resource", self.lockedMap[itemID], self.space)
	local x, y = self:getPos(occupiedIndex)

	ui:setPosition(x, y)
	self:addChild(ui)

	self.resourceMap[itemID] = ui
	local icon = ui.icon
	local x, y = icon:getPosition()
	ui.iconPos = icon:getParent():convertToWorldSpace(cc.p(x, y))
	ui.iconScale = icon:getScaleX()

	ui:setPositionY(display.height / self:getBigScale())

	ui.isNewTemp = true
	ui.flyingCount = 0
	ui.occupiedIndex = occupiedIndex
	self.occupiedMap[occupiedIndex] = ui

	return ui
end

function FRAME_main_resource:readyFly(itemID)
	local ui = self.resourceMap[itemID]
	ui = ui or self:prepareTempResource(itemID)

	if ui.isNewTemp then
		if not ui.isFlyOut then
			ui.isFlyOut = true
			local x, y = self:getPos(ui.occupiedIndex)

			transition.moveTo(ui, {
				easing = "sineOut",
				time = 0.2,
				y = y
			})
		end

		ui.flyingCount = ui.flyingCount + 1

		if ui.removeHandler then
			Looper.clearTimeout(ui.removeHandler)

			ui.removeHandler = nil
		end
	end

	return ui, ui.iconPos, ui.iconScale
end

function FRAME_main_resource:flyOver(itemID)
	local ui = self.resourceMap[itemID]

	if ui and ui.isNewTemp then
		ui.flyingCount = ui.flyingCount - 1

		if ui.flyingCount == 0 then
			local function delayRemove()
				self.resourceMap[itemID] = nil
				local occupiedIndex = ui.occupiedIndex

				transition.moveTo(ui, {
					easing = "backIn",
					time = 0.2,
					y = display.height,
					onComplete = function ()
						self.occupiedMap[occupiedIndex] = nil

						ui:removeSelf()
					end
				})
			end

			ui.removeHandler = Looper.setTimeout(delayRemove, 30, ui)
		end
	end
end

function FRAME_main_resource:lockResource(itemID)
	self.lockedMap[itemID] = true
	local ui = self.resourceMap[itemID]

	if ui then
		ui:setRefreshLocked(true)
	end
end

function FRAME_main_resource:unlockResource(itemID)
	self.lockedMap[itemID] = nil
	local ui = self.resourceMap[itemID]

	if ui then
		ui:setRefreshLocked(false)
		ui:refreshNum()
	end
end

function FRAME_main_resource:lockAll()
	FRAME_main_resource.allLocked = true
end

function FRAME_main_resource:unlockAll()
	FRAME_main_resource.allLocked = nil

	for itemID, ui in pairs(self.resourceMap) do
		if ui then
			ui:setRefreshLocked(false)
			ui:refreshNum()
		end
	end
end

function FRAME_main_resource:onExit()
	FRAME_main_resource.super.onExit(self)

	FRAME_main_resource.ui = nil
end

return FRAME_main_resource
