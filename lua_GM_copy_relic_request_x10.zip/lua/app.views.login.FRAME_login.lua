local FRAME_login = class("FRAME_login", UI_base)

function FRAME_login:ctor()
	FRAME_login.super.ctor(self, "frame_login")
	LayerConfig.setPopLocked("FRAME_login", true)
	self:init()
end

function FRAME_login:init()
	global.loginLoadOver = nil
	global.loginFrameOver = nil
	global.loginUI = self

	self:initUI()
	self:showMaintain()

	if A_notice_channel then
		local channel_type = Cookie.get("channel_type")

		print("$$$ channel_type", channel_type)

		if channel_type then
			self:openNotice(function ()
				self:startLogin()
			end, channel_type)
		else
			self:closeMaintain()
			self:startLogin()
		end
	else
		self:openNotice(function ()
			self:startLogin()
		end)
	end
end

function FRAME_login:showMaintain(delay)
end

function FRAME_login:closeMaintain()
end

function FRAME_login:afterLoginChannel(channel_type)
	Cookie.set("channel_type", channel_type, true)

	if not global.noticeAlreadyShow then
		self:openNotice(nil, channel_type)
	end
end

function FRAME_login:openNotice(_onComplete, channel)
	local function onComplete()
		self:removeLabelOnFlag("flag_channel")

		if _onComplete then
			_onComplete()
		end
	end

	global.noticeAlreadyShow = true
	local url = PUBLISH_URL

	if (CONFIG.dafu or CONFIG.shijie) and device.platform == "windows" then
		url = "http://" .. SERVER_HOST .. ":6029/?cmd=get_notice"

		print("$$$ SERVER_HOST", SERVER_HOST, url)
	end

	if not empty(url) and not global.alreadyShowNotice then
		if channel then
			self:replaceLabelOnFlag("flag_channel", nil, channel)
		end

		channel = channel or 0

		if A_notice_channel_except and A_notice_channel_to then
			local inExcept = false

			for i, v in ipairs(A_notice_channel_except) do
				if tostring(channel) == tostring(v) then
					inExcept = true

					break
				end
			end

			if not inExcept then
				channel = A_notice_channel_to
			end
		end

		url = url .. "&lang=" .. (Localization.getLang() or "") .. "&qudao_channel=" .. tostring(channel)

		Http.request(url, nil, function (data)
			self:closeMaintain()

			if data and data.text then
				FRAME_publish.open(data.text, onComplete)
			else
				onComplete()
			end
		end, "GET", function ()
			self:closeMaintain()
			onComplete()
		end)

		global.alreadyShowNotice = true
	else
		self:closeMaintain()
		onComplete()
	end
end

function FRAME_login:selectServer(serverData, onSelect)
	local status, labelObj, isClosing = WorldUtils.getStatus(serverData)

	if status ~= 3 then
		if CONFIG.center_addr ~= serverData.addr then
			local function doSelectServer()
				CONFIG.dafu = true
				CONFIG.center_addr = serverData.addr

				if onSelect then
					onSelect()
				end
			end

			if CONFIG.center_addr then
				InfoUser.stopLoadInitData()
				Connection.clearFlush()

				CONFIG.center_addr = nil

				Connection.reconnect(doSelectServer)
			else
				doSelectServer()
			end
		end
	else
		if CONFIG.center_addr then
			InfoUser.stopLoadInitData()
			Connection.clearFlush()
			Connection.reconnect()

			CONFIG.center_addr = nil
		end

		if isClosing then
			CONFIG.dafu = true
			CONFIG.center_addr = serverData.addr

			if onSelect then
				onSelect()
			end
		end
	end
end

function FRAME_login:openServerList(onSelect, isChange)
	local function _onSelect(serverData)
		self.currentServer = serverData

		self:refreshServerMini()
		self:selectServer(serverData, onSelect)
	end

	FRAME_server_list.open(self.serverList, _onSelect, isChange, self.currentServer)
end

function FRAME_login:closeServerMini()
	if self.serverMiniUI then
		self.serverMiniUI:removeSelf()

		self.serverMiniUI = nil
	end
end

function FRAME_login:openServerMini(onSelect)
	self:closeServerMini()

	local ui = UIManager.getUI("frame_server_mini")

	self:addChild(ui, 100)

	self.serverMiniUI = ui

	self:refreshServerMini()

	local bg = ui:getComponentByTag("bg")

	bg:setOpacity(200)
	bg:toTouchable()
	bg:addTap(function ()
		self:openServerList(onSelect, true)
	end)
	bg:setTapGroup("bg_click")
end

function FRAME_login:refreshServerMini()
	local ui = self.serverMiniUI
	local data = self.currentServer

	if ui and data then
		local status, labelObj = WorldUtils.getStatus(data)

		if status == 3 then
			if labelObj then
				ui:createLabelOnFlag("flag_status", labelObj.name, labelObj.style)
			else
				ui:removeLabelOnFlag("flag_status")
			end

			ui:createLabelOnFlag("flag_name", data.server_name)
		else
			ui:createLabelOnFlag("flag_name", data.server_name, {
				align = Style.center
			})
		end
	end
end

function FRAME_login:requestServerList(qudao_user_id, qudao_code, is_qudao, onSelect)
	local function onServerList(rcvData)
		self:closeMaintain()
		dump(rcvData, "$$$ 服务器列表")

		CONFIG.dafu = nil
		CONFIG.center_addr = nil

		Time.setServerTime(rcvData.time, rcvData.timezone_offset)

		local nowTime = math.floor(Time.now())
		local server_list = rcvData.server_list
		local login_list = rcvData.player_login_info
		self.serverList = {}

		for k, v in pairs(server_list) do
			if DEV_MODE then
				table.insert(self.serverList, v)
			elseif v.open_time < nowTime then
				table.insert(self.serverList, v)
			end
		end

		if #self.serverList == 0 then
			print("$$$ 服务器列表为空")
			POP_confirm.open(Localization.getSrcText("没有运行中的服务器"), function ()
				app.exit()
			end, Localization.getSrcText("退出"))
		elseif #self.serverList > 1 or CONFIG.shijie_force then
			self.serverMap = {}

			for i, v in ipairs(server_list) do
				self.serverMap[v.server_id] = v
			end

			if login_list and #login_list > 0 then
				table.sort(login_list, function (a, b)
					return b.login_time < a.login_time
				end)

				self.currentServer = self.serverMap[login_list[1].server_id]
			end

			self:openServerMini(onSelect)

			if self.currentServer then
				local serverData = self.currentServer

				self:selectServer(serverData, onSelect)
			else
				print("$$$ 打开选服界面")
				self:openServerList(onSelect)
			end
		else
			print("$$$ 自动选择唯一服务器")

			local serverData = self.serverList[1]

			self:selectServer(serverData, onSelect)
		end
	end

	self:showMaintain()

	local params = {
		qudao_user_id = qudao_user_id,
		qudao_code = qudao_code,
		is_qudao = is_qudao
	}
	local url = "http://" .. CONFIG.world_addr .. "/?cmd=get_server_list"

	for k, v in pairs(params) do
		url = url .. "&" .. k .. "=" .. v
	end

	Http.request(url, params, onServerList)
end

function FRAME_login:closeTap2start()
	local label = self:getComponentByTag("flag_tap2start")

	transition.stopTarget(label)
	label:setOpacity(0)
end

function FRAME_login:retryLogin(params, delay)
	if A_sdk_retry then
		print("$$$ retryLogin")
		self:retryLoginCancel()

		delay = delay or 300
		self.retryLoginTimer = Looper.setTimeout(function ()
			print("$$$ retryLogin do")
			InfoUser.loginErr("retryLogin")
			Http.cancelPreRetry()
			self:closeProgress()
			self:startLogin()
		end, delay)
	end
end

function FRAME_login:retryLoginCancel()
	if A_sdk_retry and self.retryLoginTimer then
		Looper.clearTimeout(self.retryLoginTimer)

		self.retryLoginTimer = nil
	end
end

function FRAME_login:reLogin()
	local label2 = self:getComponentByTag("flag_tap2login")

	label2:setOpacity(0)
	transition.fadeTo(label2, {
		easing = "sineOut",
		opacity = 255,
		time = 0.5,
		onComplete = function ()
			Style.makeShining(label2, nil, , 0.3, 0.2)
		end
	})

	local bg = self:getComponentByTag("bg")

	bg:toTouchable()
	bg:addTap(function ()
		transition.stopTarget(label2)
		label2:setOpacity(0)
		bg:removeTap()
		self:startLogin()
	end)
end

function FRAME_login:startLogin()
	if app.sceneData and app.sceneData.isResetScene and InfoUser.isLogin then
		self:openProgress()

		local function onSuccess()
			self:closePopLogin()
			self:readyToStart()
			self:closeProgress()
		end

		local function onFailure(err)
			if self.loginUI then
				self.loginUI:setVisible(true)
			end

			self:closeProgress()
		end

		local function onProgress(index, total, msg)
			if msg then
				self:setProgress(index / total, msg .. "(" .. index .. "/" .. total .. ")")
			else
				self:setProgress(index / total)
			end
		end

		InfoUser.resetLogin(onSuccess, onFailure, onProgress)

		return
	end

	Log.debug("$$$ FRAME_login:startLogin", CONFIG.is_sdk_login, CONFIG.dafu, CONFIG.shijie, CONFIG.show_privace)
	TaHelper.taTrack("loginstart")

	if CONFIG.is_sdk_login then
		local function doSdkLogin(result)
			self:retryLogin()

			global.isGuest = result.isGuest
			global.qudao_user_id = result.user_id

			Log.debug("$$$ doSdkLogin", result.user_id, result.user_name, result.token, result.channel_type, result.isGuest)

			local function onSuccess()
				Log.debug("$$$ InfoUser.loginQudao onSuccess")
				self:closePopLogin()
				self:readyToStart()
				self:closeProgress()
			end

			local function onFailure(err)
				Log.debug("$$$ InfoUser.loginQudao onFailure")
				self:closeProgress()
			end

			local function onProgress(index, total, msg)
				Log.debug("$$$ InfoUser.loginQudao onProgress", index, total, msg)

				if msg then
					self:setProgress(index / total, msg .. "(" .. index .. "/" .. total .. ")")
				else
					self:setProgress(index / total)
				end
			end

			local function doLoginQudao()
				self:closeTap2start()
				self:openProgress()
				self:setProgress(0, Localization.getSrcText("登录账号"))
				self:showMaintain()

				local function onHttpSuccess()
					self:closeMaintain()
					self:retryLoginCancel()
				end

				InfoUser.loginQudao(CONFIG.qudao_code, result.user_id, result.user_name, result.token, result.channel_type, onSuccess, onFailure, onProgress, result.s, onHttpSuccess)

				self.loginStarted = true
			end

			if CONFIG.shijie then
				self:requestServerList(result.user_id, CONFIG.qudao_code, 1, doLoginQudao)
			else
				doLoginQudao()
			end

			if A_notice_channel then
				self:afterLoginChannel(result.channel_type)
			end
		end

		if global.testSdkInfo then
			doSdkLogin(global.testSdkInfo)
		elseif global.switchAccountResult then
			doSdkLogin(global.switchAccountResult)

			global.switchAccountResult = nil
		else
			local openSDKLogin = nil

			local function delayLoginFail(result)
				Alert.open(Localization.getSrcText("SDK登录失败：") .. result.rs .. "," .. (result.message or ""))

				local msg = Localization.getSrcText("登录失败")

				if result and result.rs == "cancelled" then
					msg = Localization.getSrcText("登录取消")
				end

				POP_confirm.open(msg, function ()
					openSDKLogin()
				end, Localization.getSrcText("重新登录"))
			end

			local function onLoginCallback(result)
				Log.debug("$$$ luaLogin", result.rs)

				if result.rs == "success" then
					doSdkLogin(result)
				else
					Looper.setTimeout(function ()
						delayLoginFail(result)
					end, 60)
				end
			end

			LuaBridge.register("login_callback", onLoginCallback)

			function openSDKLogin()
				if InfoUser.isKick then
					return
				end

				LuaBridge.call("luaLogin", {}, onLoginCallback)
			end

			if CONFIG.show_privace == 1 then
				local show_privace_count = Cookie.get("show_privace_count")

				if show_privace_count and show_privace_count > 0 then
					openSDKLogin()
				else
					LuaBridge.call("luaShowPrivace", {}, function (result)
						Log.debug("$$$ luaShowPrivace", result.rs)

						CONFIG.show_privace = true

						if result.rs == "success" then
							Cookie.set("show_privace_count", (show_privace_count or 0) + 1, true)
							openSDKLogin()
						else
							app.exit()
						end
					end)
				end
			elseif CONFIG.init_privace == 1 then
				LuaBridge.call("luaShowPrivace", {}, function (result)
					Log.debug("$$$ luaShowPrivace", result.rs)

					CONFIG.init_privace = true

					if result.rs == "success" then
						openSDKLogin()
					else
						app.exit()
					end
				end)
			else
				openSDKLogin()
			end
		end

		LuaBridge.register("luaSwitchAccount", function (result)
			global.switchAccountResult = result

			Connection.clearFlush()
			Connection.reconnect(function ()
				InfoUser.clearOnReconnect()
				Transition.setTitle("")
				app:enterScene("LoginScene")
			end)
		end)

		return
	end

	local function doPopLogin()
		self:closeTap2start()
		self:popLogin()
	end

	if CONFIG.shijie then
		self:requestServerList("local", 0, 0, doPopLogin)
	else
		doPopLogin()
	end
end

function FRAME_login:onReconnect()
	if not self.loginStarted then
		return
	end

	local function onSuccess()
		self:closePopLogin()
		self:readyToStart()
		self:closeProgress()
	end

	local function onFailure(err)
		if self.loginUI then
			self.loginUI:setVisible(true)
		end

		self:closeProgress()
	end

	local function onProgress(index, total, msg)
		if msg then
			self:setProgress(index / total, msg .. "(" .. index .. "/" .. total .. ")")
		else
			self:setProgress(index / total)
		end
	end

	if not InfoUser.isKick and InfoUser.hasAutoLoginData() then
		InfoUser.autoLogin(onSuccess, onFailure, onProgress, true)
	else
		onFailure()
	end
end

function FRAME_login:initUI()
	local label = self:getComponentByTag("flag_tap2start")

	label:setOpacity(0)

	local label2 = self:getComponentByTag("flag_tap2login")

	label2:setOpacity(0)

	local shader = self:getComponentByTag("shader")

	shader:setOpacity(100)

	local lang = Localization.getLang()
	local logo = nil

	if CONFIG.logo_name then
		logo = self:getComponentByTag(CONFIG.logo_name)
	elseif lang == GameConfig.default_lang then
		if CONFIG.is_cadpa then
			logo = self:getComponentByTag("logo_cn")
		else
			logo = self:getComponentByTag("logo")
		end
	else
		logo = self:getComponentByTag("logo_" .. lang)
	end

	logo = logo or self:getComponentByTag("logo_en")

	logo:setPositionY(logo:getPositionY() - 500)
	self:replaceLabelOnFlag("flag_version", nil, CONFIG.appVersion or "", version)
	self:removeLabelOnFlag("flag_channel")

	local cadpa = self:getComponentByTag("cadpa")

	cadpa:setLocalZOrder(1000)
	cadpa:toTouchable()
	cadpa:setTapGroup("button_click")
	cadpa:addTap(function ()
		FRAME_cadpa.open()
	end)

	if not empty(A_privacy_url) and not empty(A_protocol_url) then
		self.privacyOn = true
		local label = self:getComponentByTag("flag_tap2start")

		label:setPositionY(label:getPositionY() + 80)
	end

	if A_cadpa_5 then
		self:createLabelOnFlag("label_cadpa_5", A_cadpa_5)
	end

	cadpa:setVisible(CONFIG.is_cadpa)

	local cadpaIndex = 1
	local labelCadpa = self:getComponentByTag("label_cadpa_" .. cadpaIndex)

	while labelCadpa do
		if CONFIG.is_cadpa_mini then
			labelCadpa:setVisible(cadpaIndex < 4)

			local y = labelCadpa:getPositionY()

			labelCadpa:setPositionY(y - 53)
		else
			labelCadpa:setVisible(CONFIG.is_cadpa)
		end

		cadpaIndex = cadpaIndex + 1
		labelCadpa = self:getComponentByTag("label_cadpa_" .. cadpaIndex)
	end

	if CONFIG.is_cadpa and not CONFIG.is_cadpa_mini then
		if A_cadpa_icp then
			self:createUbbOnFlag("flag_icp", A_cadpa_icp)
		elseif string.find(CONFIG.server_host, "goodsmilegames", 1, true) then
			self:createUbbOnFlag("flag_icp", "备案编号：[url=https://beian.miit.gov.cn|沪ICP备20011780号-5A]")
		else
			self:createUbbOnFlag("flag_icp", "备案编号：[url=https://beian.miit.gov.cn|沪ICP备17041577号-5A]")
		end
	end

	local cadpa_kor = self:getComponentByTag("cadpa_kor")

	cadpa_kor:setVisible(A_korea)

	local safeButton = self:getComponentByTag("bt_safe")

	safeButton:setVisible(false)
	self:createBarByTag("login_progress", cc.c3b(230, 223, 207))
	self:setBarProgressByTag("login_progress", 0)

	local coms = {
		"login_progress",
		"login_progress_bg"
	}

	for i = 1, #coms do
		local com = self:getComponentByTag(coms[i])

		com:setOpacity(0)
	end

	local bg = self:getComponentByTag("bg")
	local bg_dark = self:getComponentByTag("bg_dark")
	local bg_star = self:getComponentByTag("bg_star")
	local nowHour = Time.localHour()

	for i, v in ipairs(MiscConfig.HOUR_COLOR) do
		local nextV = MiscConfig.HOUR_COLOR[i + 1]

		if v.hour <= nowHour and nowHour < nextV.hour then
			local percent = 1 - (nowHour - v.hour) / (nextV.hour - v.hour)
			local dark = math.min(255, math.max(0, math.floor(v.dark * percent + nextV.dark * (1 - percent))))
			local star = math.min(255, math.max(0, math.floor(v.star * percent + nextV.star * (1 - percent))))

			bg_dark:setOpacity(dark)
			bg_star:setOpacity(star)

			break
		end
	end
end

function FRAME_login:openProgress()
	self:removeLabelOnFlag("flag_progress")

	local coms = {
		"login_progress",
		"login_progress_bg"
	}

	for i = 1, #coms do
		local com = self:getComponentByTag(coms[i])

		com:setOpacity(255)
	end
end

function FRAME_login:closeProgress()
	local coms = {
		"login_progress",
		"login_progress_bg",
		"flag_progress"
	}

	for i = 1, #coms do
		local com = self:getComponentByTag(coms[i])

		if com then
			com:setOpacity(0)
		end
	end
end

function FRAME_login:setProgress(percent, msg)
	self:setBarProgressByTag("login_progress", percent)

	if msg then
		self:createLabelOnFlag("flag_progress", msg)
	else
		self:removeLabelOnFlag("flag_progress")
	end
end

function FRAME_login:autoLogin()
	if InfoUser.isKick then
		return
	end

	local function onSuccess()
		self:readyToStart()
		self:closeProgress()
	end

	local function onFailure(err)
		self:popLogin()
		self:closeProgress()
	end

	local function onProgress(index, total, msg)
		if msg then
			self:setProgress(index / total, msg .. "(" .. index .. "/" .. total .. ")")
		else
			self:setProgress(index / total)
		end
	end

	self:openProgress()
	self:setProgress(0, Localization.getSrcText("登录账号"))
	InfoUser.autoLogin(onSuccess, onFailure, onProgress)
end

function FRAME_login:popLogin()
	local uiName = "pop_login"

	if CONFIG.isBench then
		uiName = "pop_login_bench"
	end

	local loginUI = UIManager.getUI(uiName)

	self:addChild(loginUI, 100)

	self.loginUI = loginUI
	local usernameEB = loginUI:createEditBoxOnComponent("eb_username")

	usernameEB:setInputMode(6)

	local passwordEB = loginUI:createEditBoxOnComponent("eb_password")

	passwordEB:setInputFlag(0)

	if DEV_MODE then
		local username = Cookie.get("savedUsername")

		if username then
			usernameEB:setText(username)
		end

		passwordEB:setVisible(false)
		loginUI:createLabelOnFlag("flag_password", "")
	end

	local bg = loginUI:getComponentByTag("bg")

	if bg then
		bg:toTouchable()
	end

	local loginPB = loginUI:getComponentByTag("login_pb")

	loginPB:toTouchable()

	local function tapLogin()
		print("$$$ tapLogin")

		local username = usernameEB:getText()
		local password = crypto.md5(passwordEB:getText())

		if DEV_MODE then
			if username == "" then
				Alert.open(Localization.getSrcText("请输入用户名"))

				return
			end
		elseif username == "" and passwordEB:getText() == "" then
			Alert.open(Localization.getSrcText("请输入用户名和密码"))

			return
		elseif username == "" then
			Alert.open(Localization.getSrcText("请输入用户名"))

			return
		elseif passwordEB:getText() == "" then
			Alert.open(Localization.getSrcText("请输入密码"))

			return
		end

		local function onSuccess()
			self:closePopLogin()
			self:readyToStart()
			self:closeProgress()
		end

		local function onFailure(err)
			if DEV_MODE and err == "login_fail_password" then
				POP_notice.open(Localization.getSrcText("账号不存在，是否直接注册新账号？"), function ()
					local function onRegisterSuccess(data)
						self:closePopRegister()
						self:readyToStart()
						self:closeProgress()
					end

					local function onRegisterFailure()
						loginUI:setVisible(true)
						self:closeProgress()
					end

					local function onRegisterProgress(index, total, msg)
						if msg then
							self:setProgress(index / total, msg .. "(" .. index .. "/" .. total .. ")")
						else
							self:setProgress(index / total)
						end
					end

					loginUI:setVisible(false)
					self:openProgress()
					InfoUser.register(username, password, onRegisterSuccess, onRegisterFailure, onRegisterProgress)
				end)
			end

			loginUI:setVisible(true)
			self:closeProgress()
		end

		local function onProgress(index, total, msg)
			if msg then
				self:setProgress(index / total, msg .. "(" .. index .. "/" .. total .. ")")
			else
				self:setProgress(index / total)
			end
		end

		loginUI:setVisible(false)
		self:openProgress()
		self:setProgress(0, Localization.getSrcText("登录账号"))
		print("$$$ InfoUser.login")
		self:showMaintain()

		local function onHttpSuccess()
			self:closeMaintain()
			self:retryLoginCancel()
		end

		InfoUser.login(username, password, onSuccess, onFailure, onProgress, onHttpSuccess)

		self.loginStarted = true
	end

	loginPB:addTap(tapLogin)
	loginPB:setTapGroup("button_click")

	local goregisterPB = loginUI:getComponentByTag("goregister_pb")

	goregisterPB:toTouchable()

	local function tapGoregister()
		self:closePopLogin()
		self:popRegister()
	end

	goregisterPB:addTap(tapGoregister)
	goregisterPB:setTapGroup("button_click")

	if CONFIG.isBench then
		local gateEB = loginUI:createEditBoxOnComponent("eb_gate")

		gateEB:setInputMode(6)

		local tokenEB = loginUI:createEditBoxOnComponent("eb_token")

		tokenEB:setInputFlag(6)

		local gate = Cookie.get("bench_gate")
		local token = Cookie.get("bench_token")

		if gate then
			gateEB:setText(gate)
		end

		if token then
			tokenEB:setText(token)
		end

		local login_pb_token = loginUI:getComponentByTag("login_pb_token")

		login_pb_token:toTouchable()
		login_pb_token:setTapGroup("button_click")
		login_pb_token:addTap(function ()
			local gate = gateEB:getText()
			local token = tokenEB:getText()

			if empty(gate) or not string.find(gate, ":") then
				Alert.open("请输入逻辑服地址:端口")

				return
			end

			if empty(token) then
				Alert.open("请输入登录token")

				return
			end

			local function onSuccess()
				Cookie.set("bench_gate", gate)
				Cookie.set("bench_token", token, true)
				self:closePopLogin()
				self:readyToStart()
				self:closeProgress()
			end

			local function onFailure(err)
				loginUI:setVisible(true)
				self:closeProgress()
			end

			local function onProgress(index, total, msg)
				if msg then
					self:setProgress(index / total, msg .. "(" .. index .. "/" .. total .. ")")
				else
					self:setProgress(index / total)
				end
			end

			local serverArr = string.split(gate, ":")
			SERVER_HOST = serverArr[1]
			SERVER_PORT = tonumber(serverArr[2])

			Log.debug("SERVER_HOST", SERVER_HOST, "SERVER_PORT", SERVER_PORT)
			Connection.init(SERVER_HOST, SERVER_PORT)
			loginUI:setVisible(false)
			self:openProgress()
			self:setProgress(0, Localization.getSrcText("登录账号"))
			InfoUser.loginGate(token, nil, onSuccess, onFailure, onProgress)

			self.loginStarted = true
		end)
	end
end

function FRAME_login:onTryLogin()
	if self.loginUI then
		self.loginUI:setVisible(false)
	end

	self:openProgress()
	self:setProgress(0, Localization.getSrcText("登录账号"))
end

function FRAME_login:closePopLogin()
	if self.loginUI then
		self.loginUI:removeSelf()

		self.loginUI = nil
	end
end

function FRAME_login:popRegister()
	local registerUI = UIManager.getUI("pop_register")

	self:addChild(registerUI, 100)

	self.registerUI = registerUI
	local bg = registerUI:getComponentByTag("bg")

	if bg then
		bg:toTouchable()
	end

	local usernameEB = registerUI:createEditBoxOnComponent("eb_username")

	usernameEB:setInputMode(6)

	local passwordEB = registerUI:createEditBoxOnComponent("eb_password")
	local passwordConfirmEB = registerUI:createEditBoxOnComponent("eb_password_confirm")

	passwordEB:setInputFlag(0)
	passwordConfirmEB:setInputFlag(0)

	if DEV_MODE then
		passwordEB:setVisible(false)
		passwordConfirmEB:setVisible(false)
		registerUI:createLabelOnFlag("flag_password", "")
		registerUI:createLabelOnFlag("flag_password_confirm", "")
	end

	local registerPB = registerUI:getComponentByTag("register_pb")

	registerPB:toTouchable()

	local function tapLogin()
		local username = usernameEB:getText()
		local password = crypto.md5(passwordEB:getText())
		local passwordConfirm = crypto.md5(passwordConfirmEB:getText())

		if DEV_MODE then
			if username == "" then
				Alert.open(Localization.getSrcText("请输入用户名"))

				return
			end
		elseif username == "" and passwordEB:getText() == "" then
			Alert.open(Localization.getSrcText("请输入用户名和密码"))

			return
		elseif username == "" then
			Alert.open(Localization.getSrcText("请输入用户名"))

			return
		elseif passwordEB:getText() == "" then
			Alert.open(Localization.getSrcText("请输入密码"))

			return
		elseif passwordConfirm ~= password then
			Alert.open(Localization.getSrcText("两次输入的密码不一致"))

			return
		end

		local function onSuccess(data)
			self:closePopRegister()
			self:readyToStart()
			self:closeProgress()
		end

		local function onFailure()
			registerUI:setVisible(true)
			self:closeProgress()
		end

		local function onProgress(index, total, msg)
			if msg then
				self:setProgress(index / total, msg .. "(" .. index .. "/" .. total .. ")")
			else
				self:setProgress(index / total)
			end
		end

		registerUI:setVisible(false)
		self:openProgress()
		InfoUser.register(username, password, onSuccess, onFailure, onProgress)
	end

	registerPB:addTap(tapLogin)
	registerPB:setTapGroup("button_click")

	local gologinPB = registerUI:getComponentByTag("gologin_pb")

	gologinPB:toTouchable()

	local function tapGologin()
		self:closePopRegister()
		self:popLogin()
	end

	gologinPB:addTap(tapGologin)
	gologinPB:setTapGroup("button_click")
end

function FRAME_login:closePopRegister()
	if self.registerUI then
		self.registerUI:removeSelf()

		self.registerUI = nil
	end
end

function FRAME_login:readyToStart()
	self:closeMaintain()
	self:retryLoginCancel()

	if CONFIG.hide_float then
		local noFloat = false

		if A_is_gs and global.channel_type == 26056 then
			noFloat = true
		end

		if not noFloat then
			if Cookie.get("hide_float") == 1 then
				LuaBridge.call("luaCloseFloat", {}, function (result)
				end)
			else
				LuaBridge.call("luaOpenFloat", {}, function (result)
				end)
			end
		end
	end

	print("$$$ self.privacyOn", self.privacyOn)

	if self.privacyOn then
		local ui = UIManager.getUI("frame_login_privacy")

		self:addChild(ui, 1000)

		local bt_privacy = ui:getComponentByTag("bt_privacy")

		bt_privacy:toTouchable()
		bt_privacy:setTapGroup("button_click")
		bt_privacy:addTap(function ()
			print("$$$ A_privacy_url", A_privacy_url)
			LuaBridge.call("luaOpenURL", A_privacy_url)
		end)

		local bt_protocol = ui:getComponentByTag("bt_protocol")

		bt_protocol:toTouchable()
		bt_protocol:setTapGroup("button_click")
		bt_protocol:addTap(function ()
			print("$$$ A_protocol_url", A_protocol_url)
			LuaBridge.call("luaOpenURL", A_protocol_url)
		end)

		local bg = ui:getComponentByTag("bg")

		bg:toTouchable()

		local bg_gou = ui:getComponentByTag("bg_gou")

		bg_gou:setOpacity(150)

		self.privacyComfirmed = UserCookie.get("privacyComfirmed")
		local gou = ui:getComponentByTag("gou")

		gou:setVisible(self.privacyComfirmed)

		local function refreshPrivacy()
			gou:setVisible(self.privacyComfirmed)
		end

		local bt_gou = ui:getComponentByTag("bt_gou")

		bt_gou:toTouchable()
		bt_gou:setTapGroup("bg_click")
		bt_gou:setOpacity(0)
		bt_gou:addTap(function ()
			if self.privacyComfirmed then
				self.privacyComfirmed = false
			else
				self.privacyComfirmed = true
			end

			UserCookie.set("privacyComfirmed", self.privacyComfirmed, true)
			refreshPrivacy()
		end)
		ui:setOpacity(0)
		transition.fadeTo(ui, {
			easing = "sineOut",
			opacity = 255,
			time = 0.2
		})
	end

	global.loginLoadOver = true
	global.loginUI = nil
	local shader = self:getComponentByTag("shader")

	transition.fadeTo(shader, {
		easing = "sineOut",
		opacity = 150,
		time = 0.5
	})

	local label = self:getComponentByTag("flag_tap2start")

	label:setOpacity(0)
	transition.fadeTo(label, {
		easing = "sineOut",
		opacity = 255,
		time = 0.5,
		onComplete = function ()
			Style.makeShining(label, nil, , 0.3, 0.2)
		end
	})
	Localization.init(3)
	InfoExchange.checkSys()
	InfoWild.checkGrowth()
	InfoManual.checkRecover()

	if InfoParams.getValue("union_pve") == 1 and InfoUnion.checkPveOpen() then
		InfoUnion.pveQuery()
	end

	local bg = self:getComponentByTag("bg")

	bg:toTouchable()
	bg:addTap(function ()
		if self.privacyOn and not self.privacyComfirmed then
			Alert.open("请阅读并同意‘隐私政策’和‘用户协议’")

			return
		end

		LayerConfig.setPopLocked("FRAME_login", false)
		self:enterGame()
	end)

	local hasRecover, isRetreat, dungeonData = InfoDungeon.checkRecover()

	if hasRecover and dungeonData ~= nil then
		local safeButton = self:getComponentByTag("bt_safe")

		safeButton:setOpacity(0)
		safeButton:setVisible(true)
		transition.fadeTo(safeButton, {
			easing = "sineOut",
			opacity = 200,
			time = 0.2
		})
		safeButton:toTouchable()
		safeButton:addTap(function ()
			LayerConfig.setPopLocked("FRAME_login", false)
			self:enterGame(true)
		end)
	end
end

function FRAME_login:enterGame(isSafe)
	print("$$$ enterGame", isSafe)
	LuaBridge.call("luaAfEvent", {
		eventName = "enter game"
	})

	global.loginFrameOver = true

	TaHelper.taGuideDetail(10100)
	OnlineChat.refreshOnlineSetup()

	local hasRecover, isRetreat, dungeonData, queryInfo = InfoDungeon.checkRecover()

	if hasRecover and dungeonData ~= nil then
		InfoBag.saveBagItemInfo()

		local function onCheckVersion(rcvData)
			dump(rcvData, "$$$ onCheckVersion")

			if rcvData.is_diff == 1 then
				global.dungeonVersionDiffData = rcvData

				InfoDungeon.enterCamp()
			else
				InfoBag.clearBagItemInfo()

				if OnlineCamp.isOnlineStage() then
					if isSafe then
						POP_notice.open(Localization.getSrcText("要离开[color=238,199,111]联机副本[/color]吗？"), function ()
							local function onSuccess(rcvData)
								InfoDungeon.enterCamp()
							end

							InfoDungeon.exit(0, onSuccess)
						end, nil, Localization.getSrcText("离开"), Localization.getSrcText("取消"), POP_notice.BUTTON_STYLE.RED)
					else
						OnlineCamp.recover(function (rcvData)
						end, function (err)
							local function onSuccess(rcvData)
								InfoDungeon.enterCamp()
							end

							InfoDungeon.exit(0, onSuccess)
						end)
					end
				else
					local str = isRetreat and "要离开[color=238,199,111]{1}[/color]吗?\n撤退会丢失地城所得" or "要离开[color=238,199,111]{1}[/color]吗?\n离开会丢失地城所得"
					str = Localization.getSrcText(str)

					if isSafe then
						POP_notice.open(StringUtil.replace(str, dungeonData.name), function ()
							local function onSuccess(rcvData)
								InfoDungeon.enterCamp()
							end

							InfoDungeon.exit(0, onSuccess)
						end, nil, isRetreat and Localization.getSrcText("撤退") or Localization.getSrcText("离开"), Localization.getSrcText("取消"), POP_notice.BUTTON_STYLE.RED)
					elseif device.platform == "windows" then
						POP_notice.open(StringUtil.replace(str, dungeonData.name), function ()
							local function onSuccess(rcvData)
								InfoDungeon.enterCamp()
							end

							InfoDungeon.exit(0, onSuccess)
						end, function ()
							if queryInfo.type == InfoDungeon.TYPE.STAGE and queryInfo.stage_type == InfoDungeon.STAGE_TYPE.DUST_PREPARE and not InfoDust.inSeason() then
								InfoDungeon.enterCamp()
							else
								local function onSuccess(rcvData)
									DungeonScene.enterDungeon(DungeonScene.ENTER_TYPE.RECOVER, rcvData)
								end

								InfoDungeon.recover(onSuccess)
							end
						end, isRetreat and Localization.getSrcText("撤退") or Localization.getSrcText("离开"), Localization.getSrcText("回到地城"), POP_notice.BUTTON_STYLE.RED)
					elseif queryInfo.type == InfoDungeon.TYPE.STAGE and queryInfo.stage_type == InfoDungeon.STAGE_TYPE.DUST_PREPARE and not InfoDust.inSeason() then
						InfoDungeon.enterCamp()
					else
						local function onSuccess(rcvData)
							DungeonScene.enterDungeon(DungeonScene.ENTER_TYPE.RECOVER, rcvData)
						end

						InfoDungeon.recover(onSuccess)
					end
				end
			end
		end

		InfoDungeon.dungeon_check_version(onCheckVersion)
	else
		local main_map = UserCookie.get("main_map")

		if main_map == "home" then
			local homeItem = InfoHome.getCurrentMapItem()

			if homeItem then
				InfoHome.enter(homeItem)

				return
			end
		end

		if main_map == "union" and InfoUnion.hasUnion() then
			InfoUnion.enterMap()

			return
		end

		InfoDungeon.enterCamp()
	end
end

return FRAME_login
