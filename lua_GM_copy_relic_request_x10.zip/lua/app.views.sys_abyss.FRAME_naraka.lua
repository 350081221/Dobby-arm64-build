local UI_base = import("..UI_base")
local FRAME_naraka = class("FRAME_naraka", UI_base)

function FRAME_naraka.open()
	local ui = FRAME_naraka.new()

	PopManager.open(ui)
end

function FRAME_naraka:ctor()
	local uiName = "frame_naraka"

	FRAME_naraka.super.ctor(self, uiName, UIManager.BIG_TYPE.POP)
	self:init()
end

function FRAME_naraka:init()
	self:initUI()

	local csvList = InfoNaraka.getList()

	self.list:setItems(csvList, true)
	self.list:setSelectedIndex(1)
	self:refreshDetail()
end

function FRAME_naraka:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local times, timesMax = InfoNaraka.getRewardTimes()
	local style = {
		color = Style.enableColor
	}

	if times <= 0 then
		style.color = Style.disableColor
	end

	self:replaceLabelGroupOnFlag("flag_reward_times", {
		times,
		timesMax
	}, {
		style,
		{
			color = Style.font3
		}
	})

	local function tapListener(ui, csv, index)
		if InfoNaraka.isOpen(csv.id) then
			self.list:setSelectedIndex(index)
		else
			Alert.open(Localization.getSrcText("暂未开放"))

			return
		end

		self:refreshDetail()
	end

	self.list = self:createListOnFlag("flag_list", LIST_naraka, tapListener, touchListener)

	self.list:setTapGroup("list_click")

	local holder = self:getComponentByTag("holder")

	self.list:setHolders({
		holder
	}, nil, 5)

	self.rewardList = self:createListOnFlag("flag_reward", RewardList)

	self.rewardList:setSpace(5, 5)

	local bt_enter = self:getComponentByTag("bt_enter")

	bt_enter:toTouchable()
	bt_enter:setTapGroup("button_click")
	bt_enter:addTap(function ()
		local data = self.list:getSelectedItem()

		local function onSuccess(result)
			InfoDungeon.enterStage(result)
			DungeonScene.enterDungeon(DungeonScene.ENTER_TYPE.NEW, result)
		end

		InfoNaraka.enterStage(data.id, onSuccess)
	end)
end

function FRAME_naraka:refreshDetail()
	local data = self.list:getSelectedItem()
	local areaCSV = CsvParser.getCsvData("abyss_area", data.abyss_area)

	if not empty(areaCSV.stand) then
		local pic = self:createClippingOnFlag("stand_mask", "naraka", areaCSV.stand)

		if pic then
			pic:setOpacity(200)
			transition.fadeTo(pic, {
				opacity = 255,
				time = 0.2
			})
		end
	end

	local itemArr = string.split(data.item_display, ",")
	local rewardArr = {}

	for i, v in ipairs(itemArr) do
		if not empty(v) then
			table.insert(rewardArr, {
				base_id = v
			})
		end
	end

	self.rewardList:setItems(rewardArr)
	self:replaceLabelGroupOnFlag("flag_terrain", {
		data.map_type
	}, {
		{
			color = Style.font3
		}
	})
	self:replaceLabelGroupOnFlag("flag_depth", {
		InfoDungeon.getAbyssMaxLevel()
	}, {
		{
			color = Style.font3
		}
	})
end

return FRAME_naraka
