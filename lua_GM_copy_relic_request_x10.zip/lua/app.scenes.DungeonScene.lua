local DungeonScene = class("DungeonScene", function ()
	return display.newScene("DungeonScene")
end)
local ENTER_TYPE = {
	RETRY = 3,
	RECOVER = 2,
	NEW = 1,
	CORE = 5,
	DRAMA_BRANCH = 4
}
DungeonScene.ENTER_TYPE = ENTER_TYPE

function DungeonScene.enterDungeon(enterType, info, onlineData)
	local maps = InfoDungeon.getMaps()

	Log.verbose("DungeonScene.enterDungeon", maps[1])
	DungeonScene.enterMap(enterType, maps[1], nil, onlineData)
end

function DungeonScene.enterMap(enterType, mapName, enterInfo, onlineData)
	FRAME_wild.close()
	FRAME_union_pve.close()
	Log.verbose("DungeonScene.enterMap", mapName, enterType)

	if InfoDungeon.inDungeon() then
		local mapIndex = nil
		local maps = InfoDungeon.getMaps()

		for i, v in ipairs(maps) do
			if mapName == v then
				mapIndex = i

				break
			end
		end

		if mapIndex then
			InfoDungeon.setMapIndex(mapIndex)
		else
			InfoDungeon.setMapIndex(1)
		end
	end

	DungeonScene.enterType = enterType
	DungeonScene.currentMap = mapName
	DungeonScene.enterInfo = enterInfo
	DungeonScene.onlineData = onlineData

	app:enterScene("DungeonScene")
end

function DungeonScene:ctor()
	Log.debug("DungeonScene:ctor")
	event_listener.extendMethods(self, true)
end

function DungeonScene:init()
	Log.debug("DungeonScene:init")

	if InfoDungeon.inDungeon() then
		CombatAttr.setAttrLevel(InfoDungeon.getLevel())
	end

	InfoTaskQuest.snapshot()
	self:initMap()
	Log.debug("DungeonScene:init initMap over")
	notify.safeRegister(self, "battle_state_change", function (isBattle)
		self.isBattle = isBattle

		if isBattle then
			PopManager.closeAll()
			self:enterBattle()
		else
			self:enterAdventure()
		end
	end)
	self:initModao()
	self:initUnits()

	self.adventureUI = FRAME_dungeon.new()

	self.adventureUI:setVisible(false)
	self:addChild(self.adventureUI)

	global.adventureUI = self.adventureUI
	self.battleUI = FRAME_dungeon_battle.new()

	self.battleUI:setVisible(false)
	self:addChild(self.battleUI)

	global.battleUI = self.battleUI

	if InfoDungeon.getAbyssMaxLayer() > 0 then
		global.main_bard = FRAME_main_bard.new()

		self:addChild(global.main_bard, 1)
	end

	if InfoDungeon.getType() == InfoDungeon.TYPE.CORE then
		-- Nothing
	elseif self.isBattle then
		self:enterBattle()
	else
		self:enterAdventure()
	end

	if OnlineCamp.isOnlineStage() and InfoDungeon.idDeadout() then
		self:openOpMode()
	end

	local stageType, stageID = InfoDungeon.getStage()

	if stageType == InfoDungeon.STAGE_TYPE.NARAKA_PREPARE then
		self.adventureUI:openNarakaPrepare()
	end

	if InfoDungeon.isCamp() then
		self:startChat()
		global.map:setViewZoom(1.2)
		global.map:tweenViewZoom(1, 60)
	end

	if not global.hideui and not empty(global.map.name) then
		local title, subTitle = Transition.getTitle()

		if title then
			POP_mapname.open(title, subTitle)
		end
	end

	if OnlineCamp.isOnline() then
		if global.player then
			local function refreshOnline()
				OnlineCamp.tryEnter()
			end

			notify.safeRegister(global.player, "reconn_succ", refreshOnline)
			notify.safeRegister(global.player, "main_guide_fin", refreshOnline)
			refreshOnline()
		end
	elseif DungeonScene.onlineData then
		local x = 0
		local y = 0

		if global.player then
			x = global.player.tile.x
			y = global.player.tile.y
		else
			local tile = global.map:mapToTile(self.opTrainInfo)
			x = tile.x
			y = tile.y
		end

		OnlineCamp.summon(x, y)
	end

	self:initWeather()
	self:recoverLight()

	global.alreadyIn = true
	self.opTrainInfo = nil
	local isRecover = DramaManager.recover()

	print("$$$ isRecover", isRecover)

	if InfoDungeon.getType() == InfoDungeon.TYPE.CORE then
		InfoCore.battleStart()
		self:enterBattle()
	end
end

function DungeonScene:recoverLight()
	if InfoDungeon.inDungeon() then
		local mutateCSV = InfoDungeon.getMutate()

		if mutateCSV and not empty(mutateCSV.color) then
			local color = ColorUtil.getC3B(mutateCSV.color)
			local atoms = Sound.getAtomsVolume() or 1
			local ratio = atoms * 0.7 + 0.3
			color.r = math.floor(255 - (255 - color.r) * ratio)
			color.g = math.floor(255 - (255 - color.g) * ratio)
			color.b = math.floor(255 - (255 - color.b) * ratio)

			global.map:setLightRGB(color)

			return
		end
	end
end

local chatID, chatPos, chatCount, chatHandler = nil

function DungeonScene.startChat()
	if global.player then
		Looper.startLoop(DungeonScene, DungeonScene.chating)

		chatCount = math.random(160, 200)
		chatHandler = notify.safeRegister(global.player, "player_go_start", function ()
			DungeonScene.stopChat()
		end)
	end
end

function DungeonScene.stopChat()
	notify.unregister("player_go_start", chatHandler)
	Looper.stopLoop(DungeonScene, DungeonScene.chating)
end

function DungeonScene.chating(obj, frame, passed, sharp)
	if chatCount <= 0 then
		local units = TeamManager.getTeam()
		local chatUnit = nil

		if #units > 1 then
			local chatUnits = {}

			for i, unit in ipairs(units) do
				if i ~= chatPos then
					table.insert(chatUnits, {
						pos = i,
						unit = unit
					})
				end
			end

			local unitObj = chatUnits[math.random(1, #chatUnits)]
			chatUnit = unitObj.unit
			chatPos = unitObj.pos
			chatCount = math.random(360, 480)
		else
			chatUnit = units[1]
			chatCount = math.random(480, 600)
		end

		if chatUnit then
			local chatMsg, sayTime = LinesManager.getEnterCamp(chatUnit.data.class, InfoDungeon.getAbyssMaxLevel(), chatID)

			if chatMsg then
				chatID = chatMsg.id

				chatUnit:say(chatMsg.text, sayTime)
			end
		end
	else
		chatCount = chatCount - sharp
	end
end

function DungeonScene:enterAdventure()
	if global.ui then
		global.ui:out()
		global.ui:setVisible(false)
	end

	if not self.adventureUI then
		self.adventureUI = FRAME_dungeon.new()

		self.adventureUI:setVisible(false)
		self:addChild(self.adventureUI)

		global.adventureUI = self.adventureUI

		if InfoDungeon.getAbyssMaxLayer() > 0 and not global.main_bard then
			global.main_bard = FRAME_main_bard.new()

			self:addChild(global.main_bard, 1)
		end
	end

	global.ui = self.adventureUI

	global.ui:ready()
	global.ui:setVisible(true)

	if global.hideui then
		global.ui:setOpacity(0)
	end
end

function DungeonScene:enterBattle()
	if global.ui then
		global.ui:out()
		global.ui:setVisible(false)
	end

	if not self.battleUI then
		self.battleUI = FRAME_dungeon_battle.new()

		self.battleUI:setVisible(false)
		self:addChild(self.battleUI)

		global.battleUI = self.battleUI

		if InfoDungeon.getAbyssMaxLayer() > 0 and not global.main_bard then
			global.main_bard = FRAME_main_bard.new()

			self:addChild(global.main_bard, 1)
		end
	end

	global.ui = self.battleUI

	global.ui:ready()
	global.ui:setVisible(true)

	if global.hideui then
		global.ui:setOpacity(0)
	end
end

function DungeonScene:initMap()
	local map = Map.new(display.width, display.height)

	self:addChild(map)
	map:setGamma(Sound.getGamma())

	local state = DungeonState.getCurrentState()

	print("$$$ state.map_index", state.map_index)

	if DungeonScene.enterType == ENTER_TYPE.DRAMA_BRANCH then
		map:load(DungeonScene.currentMap)
	elseif DungeonScene.enterType == ENTER_TYPE.CORE then
		map:load(DungeonScene.currentMap)
		InfoDungeon.setType(InfoDungeon.TYPE.CORE)
	else
		print("$$$ DungeonScene.currentMap", DungeonScene.currentMap)

		if not empty(state.map_index) then
			InfoDungeon.setMapIndex(state.map_index)
			map:load(InfoDungeon.getMapName(state.map_index))
		else
			map:load(DungeonScene.currentMap)
		end
	end

	global.map = map

	MapEventManager.setTileTriggerListener(DungeonEvent.onMapTrigger)

	local enterEvent = MapEventManager.getEventByTagOne("enter")

	if enterEvent then
		MapUtils.markSafe(enterEvent)
	end
end

function DungeonScene:inWeatherCamp()
	return InfoDungeon.isCamp() or InfoDungeon.inDustPrepare() or InfoUnion.inMap()
end

function DungeonScene:initWeather()
	if global.player then
		self:refreshWeather()
		notify.safeRegister(self, "show_weather_changed", function (isBattle)
			self:refreshWeather()
		end)

		if InfoDungeon.inDungeon() and InfoDungeon.inGap() then
			notify.safeRegister(self, "monster_fin", function ()
				self:refreshWeather()
			end)
		end
	end
end

function DungeonScene:refreshWeather()
	local showWeather = Cookie.get("showWeather") or 1

	print("$$$ showWeather", showWeather)

	if showWeather == 1 then
		if self:inWeatherCamp() then
			local fixedWeather = nil

			if not empty(global.map.params.weather) then
				fixedWeather = global.map.params.weather
			end

			self:openWeather(fixedWeather)

			return
		elseif InfoDungeon.inDungeon() and InfoDungeon.inGap() then
			local gapID = InfoDungeon.getGapID()
			local gapCSV = CsvParser.getCsvData("stage", gapID)
			local finCount, allCount = MapEventManager.countTagAll("monster")

			if allCount <= finCount then
				if not empty(gapCSV.clear_weather) then
					self:setWeather(gapCSV.clear_weather)

					return
				end
			elseif not empty(gapCSV.start_weather) then
				self:setWeather(gapCSV.start_weather)

				return
			end
		end
	end

	self:clearWeather()
end

function DungeonScene:clearWeather()
	self:setWeather(1)
	global.map:clearLightRGB()
end

function DungeonScene:openWeather(fixedWeather)
	print("$$$ openWeather", fixedWeather)

	local random = Random.new(17)
	local perlin = Perlin.new(360, random)
	local weather = 0

	if fixedWeather then
		weather = fixedWeather
	else
		local now = Time.now() / MiscConfig.WEATHER_SCALE
		local weatherRan = math.min(1, math.max(0, perlin:noise(now, 1, 1) + 0.5))

		for i, v in ipairs(MiscConfig.WEATHERS) do
			if weatherRan <= v.ran then
				weather = v.weather

				break
			end
		end
	end

	local nowHour = Time.nowHour()
	local baseColor = nil

	for i, v in ipairs(MiscConfig.HOUR_COLOR) do
		local nextV = MiscConfig.HOUR_COLOR[i + 1]

		if v.hour <= nowHour and nowHour < nextV.hour then
			local percent = 1 - (nowHour - v.hour) / (nextV.hour - v.hour)
			local r = math.min(255, math.max(0, math.floor(v.color[1] * percent + nextV.color[1] * (1 - percent))))
			local g = math.min(255, math.max(0, math.floor(v.color[2] * percent + nextV.color[2] * (1 - percent))))
			local b = math.min(255, math.max(0, math.floor(v.color[3] * percent + nextV.color[3] * (1 - percent))))
			baseColor = cc.c3b(r, g, b)

			break
		end
	end

	self:setWeather(weather, baseColor)
end

function DungeonScene:setWeather(weather, baseColor)
	print("$$$ setWeather", weather)
	dump(baseColor, "$$$ baseColor")

	if self.preWeather == weather then
		return
	end

	self.preWeather = weather
	baseColor = baseColor or cc.c3b(255, 255, 255)
	local csv = CsvParser.getCsvData("weather", math.max(1, weather))

	if not empty(csv.snow_power) then
		MapEffect.snow(csv.snow_power, 0)
	else
		MapEffect.snowStop()
	end

	if not empty(csv.rain_power) then
		MapEffect.rain(csv.rain_power, csv.rain_angle * math.pi / 180)
	else
		MapEffect.rainStop()
	end

	if self.lightningLoop then
		Looper.stopLoop(self, self.lightningLoop)
	end

	if not empty(csv.lightning_interval) then
		self.lightning_interval = csv.lightning_interval
		self.nextLightningCount = SheetUtil.getNumber(self.lightning_interval) / 2

		if not self.lightningLoop then
			function self.lightningLoop(obj, frame, passed, sharp)
				if self.nextLightningCount then
					if self.nextLightningCount < 0 then
						MapEffect.natureLightning(math.random(120, 200))
						self:performWithDelay(function ()
							local sound = MiscConfig.THUNDER_SOUND[math.random(1, #MiscConfig.THUNDER_SOUND)]

							Sound.playSound(sound)
						end, math.random() + 1)

						self.nextLightningCount = SheetUtil.getNumber(self.lightning_interval)
					else
						self.nextLightningCount = self.nextLightningCount - passed
					end
				end
			end
		end

		Looper.startLoop(self, self.lightningLoop)
	end

	local colorDeday = csv.darkness
	local r = math.min(255, math.max(0, math.floor(baseColor.r - colorDeday)))
	local g = math.min(255, math.max(0, math.floor(baseColor.g - colorDeday)))
	local b = math.min(255, math.max(0, math.floor(baseColor.b - colorDeday)))

	global.map:setLightRGB(cc.c3b(r, g, b))
end

function DungeonScene:initModao()
	global.modao = Modao.new()
end

function DungeonScene:initUnits(noEnterAction, fixedEnter)
	local isFixedTeam, fixed_team = InfoDungeon.isFixedTeam()

	if isFixedTeam then
		StageUtils.initFixed(fixed_team)
	end

	local state = DungeonState.getCurrentState()
	local trainInfo = nil

	if InfoDungeon.isCamp() then
		trainInfo = InfoVars.getLocal("camp_train_info")
	elseif InfoDungeon.isHome() then
		-- Nothing
	elseif DungeonScene.enterType == ENTER_TYPE.RECOVER or DungeonScene.enterType == ENTER_TYPE.RETRY then
		local state = DungeonState.getCurrentState()

		if state and state.train_info then
			trainInfo = state.train_info
		end
	end

	if OnlineCamp.isOnlineStage() and InfoDungeon.idDeadout() then
		self.opTrainInfo = trainInfo
	else
		if InfoDungeon.inGap() then
			TeamManager.createUnitsOnMap(DungeonScene.enterInfo, noEnterAction)
		elseif trainInfo and not isFixedTeam then
			TeamManager.createUnitsOnRecover(trainInfo)
		else
			dump(DungeonScene.onlineData, "$$$ DungeonScene.onlineData")

			local fixedIndex = nil

			if DungeonScene.onlineData then
				fixedIndex = DungeonScene.onlineData.index
			end

			TeamManager.createUnitsOnMap(DungeonScene.enterInfo, noEnterAction, fixedEnter, fixedIndex)
		end

		TeamManager.refreshTeamSneak()
	end

	self.initIsCamp = InfoDungeon.isCamp()

	InfoDungeon.addRelicAll()

	if global.player then
		global.player:checkNearNpc()
	end

	InfoEquip.checkEquipDuplicated()
end

function DungeonScene:openOpMode()
	self.adventureUI:openOpMode()

	if self.opTrainInfo then
		global.map:setFov(self.opTrainInfo.x, self.opTrainInfo.y)
		global.map:scrollTo(self.opTrainInfo.x, self.opTrainInfo.y)
	end
end

function DungeonScene:onEnter()
	app:onSceneEnter(self, nil, 1)
	self:init()
end

function DungeonScene:onExit()
	if self.initIsCamp and global.player then
		local train_info = {
			x = global.player.x,
			y = global.player.y,
			angle = global.player.angle,
			train = global.player:getTrainPoints()
		}

		InfoVars.setLocal("camp_train_info", train_info)
	end

	OnlineCamp.tryExit()

	global.main_bard = nil
	global.player = nil
	global.ui = nil
	global.map = nil
	global.battleUI = nil
	global.adventureUI = nil

	app:onSceneExit(self)
end

return DungeonScene
