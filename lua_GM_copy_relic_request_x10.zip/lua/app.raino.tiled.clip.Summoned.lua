local CombatUnit = import(".CombatUnit")
local Summoned = class("Summoned", CombatUnit)

function Summoned:ctor()
	Summoned.super.ctor(self, "summoned")
end

function Summoned:onBattleStart(warSeed)
	Summoned.super.onBattleStart(self, warSeed)
end

function Summoned:setInfo(summonedInfo)
	self.info = summonedInfo
	self.summonerType = summonedInfo.summonerType
	local summonedData = CsvParser.getCsvData(summonedInfo.base_type, summonedInfo.base_id)

	self:setData(summonedData)
	self:refreshBattleData()
end

function Summoned:setSummoner(unit)
	self.summoner = unit
	local superSummoner = unit

	if unit.superSummoner then
		superSummoner = unit.superSummoner
	else
		local tempUnit = unit

		if tempUnit.summoner then
			while tempUnit.summoner do
				tempUnit = tempUnit.summoner
			end
		end

		superSummoner = tempUnit
	end

	self.superSummoner = superSummoner
	self.eventPack = unit.eventPack
end

function Summoned:startLife()
	self.startLifeTime = WarMachine.getFrame()

	self:bornEffect()
end

function Summoned:battleUpdate(think)
	Summoned.super.battleUpdate(self, think)

	local fullFrameTime = WarMachine.getFrame()

	if not empty(self.data.life) then
		local lifeTime = self.data.life

		if self.summoner and self.summoner.attrs and self.summoner.attrs.summon_time then
			lifeTime = lifeTime + self.summoner.attrs.summon_time
		end

		if lifeTime <= fullFrameTime - self.startLifeTime then
			self:die()
		end
	end
end

function Summoned:refreshBattleData()
	Summoned.super.refreshBattleData(self)
	self:setBattleData(CombatAttr.getSummonedAttr(self.info, self))
end

function Summoned:setData(data)
	Summoned.super.setData(self, data)

	self.trapOnly = data.damage_trap == 1

	self:updateAvatar()

	if not empty(data.attack_id) then
		self:addSkill(data.attack_id)
	end

	local index = 1

	while not empty(data["skill_" .. index]) do
		local skillID = data["skill_" .. index]

		self:addSkill(skillID)

		index = index + 1
	end

	if not empty(data.skill_born) then
		self:addSkill(data.skill_born, false)
	end
end

function Summoned:display(map, x, y, customLayer)
	Summoned.super.display(self, map, x, y, customLayer)

	local random = Random.new(self.seed)
	local index = 1
	local level = self.info.level

	while not empty(self.data["buff_" .. index]) do
		local levelOK = true

		if self.summonerType == "monster" then
			levelOK = false
			local buff_level = self.data["buff_level_" .. index]

			if empty(buff_level) then
				levelOK = true
			else
				local arr = string.split(buff_level, ",")

				if #arr == 1 then
					if tonumber(arr[1]) <= level then
						levelOK = true
					end
				elseif tonumber(arr[1]) <= level and level <= tonumber(arr[2]) then
					levelOK = true
				end
			end
		end

		if levelOK then
			local buffID = self.data["buff_" .. index]

			self:addCardBuff(buffID, random:getInt(1, 65535))
		end

		index = index + 1
	end
end

function Summoned:die()
	if not self.battleData.die then
		local effectGen = self:getEffectGen()

		if effectGen then
			if isBattleOver then
				self:getEffectGen():castEffect(self.data.over_effect, self)
			else
				self:getEffectGen():castEffect(self.data.die_effect, self)
			end
		end

		self:clearEffect()
		self:setAction("idle")
		self:stopPlay()

		if self.shadow then
			self.shadow:removeSelf()

			self.shadow = nil
		end

		WarMachine.removeSummoned(self)

		local effectGen = self:getEffectGen()

		if effectGen then
			effectGen:fadeTo(30, 0, easing, function ()
				MapFrameManager.setTimeout(function ()
					self:removeSelf()
				end, MiscConfig.unit_delay_remove)
			end)
		end

		self:removeFromMap()

		if self.summonerType == "monster" and WarMachine.checkMonsterBattle(self.summoner) then
			InfoModao.addMpKill(self.info)
		end

		if self.summoner then
			local summonQueueMap = self.summoner.summonQueueMap

			if summonQueueMap then
				local found = false

				for k, summonQueue in pairs(summonQueueMap) do
					for i, unit in ipairs(summonQueue) do
						if unit == self then
							table.remove(summonQueue, i)

							found = true

							break
						end
					end

					if found then
						break
					end
				end
			end
		end
	end

	Summoned.super.die(self)
end

function Summoned:setHudVisible(visible)
	local color, style = nil

	if self.battleData.camp == 1 then
		color = cc.c3b(35, 180, 28)
	else
		color = cc.c3b(248, 184, 16)
	end

	Summoned.super.setHudVisible(self, visible, color, style)
end

function Summoned:setBattleData(data)
	Summoned.super.setBattleData(self, data)

	if self.summonerType == "monster" then
		if InfoDungeon.isAkasa() then
			local baseData = CsvParser.getCsvData("monster_base_num", self.info.level)

			for i, attr in ipairs(CombatAttr.attrs) do
				local ratio = baseData["akasa_" .. attr .. "_ratio"]

				if not empty(ratio) then
					self.attrs[attr] = math.floor(self.attrs[attr] * ratio)
				end
			end
		end

		if InfoNaraka.inNarakaBoss() then
			local baseData = CsvParser.getCsvData("monster_base_num", self.info.level)

			for i, attr in ipairs(CombatAttr.attrs) do
				local ratio = baseData["naraka_" .. attr .. "_ratio"]

				if not empty(ratio) then
					self.attrs[attr] = math.floor(self.attrs[attr] * ratio)
				end
			end
		end
	end

	if not self.battleData.hp then
		self.battleData.hp = self.attrs.hp
	end
end

return Summoned
