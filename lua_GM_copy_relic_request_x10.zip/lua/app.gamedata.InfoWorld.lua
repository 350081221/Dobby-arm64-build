local InfoWorld = {}
local rawData = {}

function InfoWorld.init()
	Connection.listen("world_sync", InfoWorld.sync)
end

app:addToAppEnterCall(InfoWorld.init)

function InfoWorld.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoWorld.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("world_query", callback)
end

function InfoWorld.onQuery(rcvData)
	dump(rcvData, "world_query")

	rawData = {}

	for i, v in ipairs(rcvData.list) do
		rawData[v.id] = v.value
	end
end

function InfoWorld.sync(data)
	dump(data, "$$$ InfoWorld.sync")

	for i, v in ipairs(data.list) do
		rawData[v.id] = v.value
	end

	ManagerInfo.dataChange("world")
end

function InfoWorld.getAbyssArea()
	if rawData.abyss_area then
		return rawData.abyss_area
	else
		local world_abyss_area_default = CsvParser.getCsvData("config", "world_abyss_area_default").value

		return world_abyss_area_default
	end
end

function InfoWorld.getArenaAreaDesc(area)
	area = area or 1
	area = math.max(1, math.min(3, area))
	local names = {
		"C",
		"B",
		"A"
	}
	local str = Localization.getSrcText("{1}赛区")
	local name = StringUtil.replace(str, names[area])
	local hint = ""

	if area == 3 then
		hint = Localization.getSrcText("已达到最高赛区")
	else
		hint = Localization.getSrcText("下周结算奖励时，如果达到深渊{1}层则进入下一赛区")
		local nextLevel = nil

		if area == 2 then
			nextLevel = rawData.arena_ranking_level_A
		else
			nextLevel = rawData.arena_ranking_level_B
		end

		hint = StringUtil.replace(hint, nextLevel)
	end

	return name, hint
end

return InfoWorld
