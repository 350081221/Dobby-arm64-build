local List = import("...ui.List")
local LIST_naraka_main = class("LIST_naraka_main", List)

function LIST_naraka_main:ctor(rect)
	LIST_naraka_main.super.ctor(self, rect)

	self.isBounc = false

	self:setCols(2)
	self:setCellName("cell_naraka_main")
	self:setCellSize(cc.size(self.touchRect.width, 50))
end

function LIST_naraka_main:onCellInit(ui, data, index)
	local csv = data.csv
	local iconPath = IconManager.getNarakaMode(csv.id)
	local icon = ui:createIconOnFlag("flag_icon", iconPath, 100, 1)

	if not data.open then
		icon:setOpacity(150)
		Shader.gray(icon)
	end

	local skill_mask = ui:getComponentByTag("skill_mask")

	skill_mask:setOpacity(150)
	skill_mask:setLocalZOrder(1000)
end

return LIST_naraka_main
