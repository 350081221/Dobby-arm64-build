local UI_base = import("..UI_base")
local TinyHint = class("TinyHint", UI_base)

function TinyHint.open(pos, msg, upOrDown, isWrap)
	local ui = TinyHint.new(msg, isWrap)
	local bigScale = UIManager.getBigScale()
	local x = pos.x - ui.width / 2 * bigScale
	x = math.max(0, math.min(display.width - ui.width, x))

	if upOrDown then
		ui:setPosition(x, pos.y + (ui.height + 30) * bigScale)
	else
		ui:setPosition(x, pos.y - 20 * bigScale)
	end

	local container = display.newNode()

	container:addChild(ui)
	container:setCascadeOpacityEnabled(true)
	PopManager.open(container, nil, , , 200)
end

function TinyHint.openHeroAffix(pos, affixID, upOrDown)
	local affixCSV = CsvParser.getCsvData("hero_affix", affixID)

	TinyHint.open(pos, affixCSV.desc, upOrDown)
end

function TinyHint.openWrap(pos, msg, upOrDown)
	TinyHint.open(pos, msg, upOrDown, true)
end

function TinyHint.autoUpOrDown(y)
	if y < display.height / 2 then
		return true
	else
		return false
	end
end

function TinyHint:ctor(msg, isWrap)
	TinyHint.super.ctor(self, "com_tiny_hint", UIManager.BIG_TYPE.BOTTOM)

	self.msg = msg
	self.isWrap = isWrap

	self:init()
end

function TinyHint:init()
	self:initUI()
end

function TinyHint:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local descFlag = self:getFlagByTag("flag_desc")
	local totalWidth, totalHeight = nil

	if self.isWrap then
		local _, _labelWidth, _labelHeight = self:createLabelOnFlag("flag_desc", self.msg, {
			align = Style.left
		})

		if descFlag.originalWidth < _labelWidth then
			_, _labelWidth, _labelHeight = self:createLabelOnFlag("flag_desc", self.msg, {
				align = Style.left,
				wrap = self.isWrap
			})
		end

		totalWidth = _labelWidth
		totalHeight = _labelHeight
	else
		local _, _, _, _totalWidth, _totalHeight = self:createUbbOnFlag("flag_desc", self.msg, {
			align = Style.left,
			wrap = self.isWrap
		}, true)
		totalWidth = _totalWidth
		totalHeight = _totalHeight
	end

	print("$$$ bg.originalWidth", bg.originalWidth, totalWidth)

	local width = bg.originalWidth + totalWidth - descFlag.originalWidth
	local height = totalHeight + 30

	bg:setSize(width, height)
	bg:setPositionY(bg:getPositionY() - height + 60)

	self.width = bg.width
	self.height = bg.height
end

return TinyHint
