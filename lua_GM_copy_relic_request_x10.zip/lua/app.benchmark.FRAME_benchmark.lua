local FRAME_benchmark = class("FRAME_benchmark", UI_base)

function FRAME_benchmark:ctor(benchmark, params, eventMap, eventArr)
	FRAME_benchmark.super.ctor(self, "frame_benchmark")

	self.benchmark = benchmark
	self.params = params
	self.eventMap = eventMap
	self.eventArr = eventArr
	self.logTime = Time.time()
	self.eventCountMap = {}
	self.eventLagTotalMap = {}
	self.eventLagCountMap = {}

	self:init()
end

function FRAME_benchmark:init()
	self:initUI()

	local pauseButton = self:getComponentByTag("bt_pause")

	pauseButton:toTouchable()
	pauseButton:addTap(function ()
		self.creating = not self.creating

		if self.creating then
			self.startTime = Time.time() * self.params.speed - #self.units

			self:log("::继续创建")
			pauseButton:addLabel("暂停创建")
		else
			self:log("::暂停创建")
			pauseButton:addLabel("继续创建")
		end
	end)

	self.units = {}

	self:start()
end

function FRAME_benchmark:initUI()
	self.textArea = self:createTextAreaOnFlag("flag_list")

	self.textArea:setSpace(5, 5)

	local holder = self:getComponentByTag("holder")

	self.textArea:setHolders({
		holder
	}, nil, 5)
	self.textArea:setMax(self.params.logMax)
end

function FRAME_benchmark:start()
	self.startTime = Time.time() * self.params.speed
	self.creating = true

	self:addEnterFrame("updateUnits", function ()
		self:loop()
	end)
	self:log("::开始")
end

function FRAME_benchmark:loop()
	local now = Time.time()

	if now >= self.logTime + self.params.logInterval then
		self.logTime = now
		local str = "-----------------------------------\n连接数:" .. (self.connectedCount or 0)

		for i, v in ipairs(self.eventArr) do
			local lag = 0

			if self.eventLagTotalMap[v.id] then
				lag = math.floor(self.eventLagTotalMap[v.id] / self.eventLagCountMap[v.id] * 1000)
			end

			str = str .. "\n└" .. v.name .. " times:" .. (self.eventCountMap[v.id] or 0) .. " lag:" .. lag
		end

		self:log(str)

		self.eventCountMap = {}
		self.eventLagTotalMap = {}
		self.eventLagCountMap = {}

		return
	end

	if #self.units < self.params.max and self.creating and #self.units < Time.time() * self.params.speed - self.startTime then
		local unit = BenchUnit.new(self.params.code, #self.units + 1, self.params, self.eventMap)

		table.insert(self.units, unit)
	end

	local connectedCount = 0
	local loginReadyCount = 0
	local heroReadyCount = 0
	local _eventLagStackMap = {}

	for i, unit in ipairs(self.units) do
		local eventCountMap, eventLagStackMap = unit:update()

		for k, v in pairs(eventCountMap) do
			if not self.eventCountMap[k] then
				self.eventCountMap[k] = v
			else
				self.eventCountMap[k] = self.eventCountMap[k] + v
			end
		end

		for k, v in pairs(eventLagStackMap) do
			local lagTotal = 0
			local lagCount = 0

			for i1, v1 in ipairs(v) do
				if not self.eventLagTotalMap[k] then
					self.eventLagTotalMap[k] = v1
				else
					self.eventLagTotalMap[k] = self.eventLagTotalMap[k] + v1
				end

				if not self.eventLagCountMap[k] then
					self.eventLagCountMap[k] = 1
				else
					self.eventLagCountMap[k] = self.eventLagCountMap[k] + 1
				end
			end
		end

		if unit:getStat() == "connected" then
			connectedCount = connectedCount + 1
		end

		if unit:isLoginReady() then
			loginReadyCount = loginReadyCount + 1
		end

		if unit:isHeroReady() then
			heroReadyCount = heroReadyCount + 1
		end
	end

	self:createLabelOnFlag("flag_total", #self.units .. "/" .. self.params.max)
	self:createLabelOnFlag("flag_connected", connectedCount)
	self:createLabelOnFlag("flag_login_ready", loginReadyCount)
	self:createLabelOnFlag("flag_hero_ready", heroReadyCount)

	self.connectedCount = connectedCount
	self.loginReadyCount = loginReadyCount
	self.heroReadyCount = heroReadyCount
end

function FRAME_benchmark:log(msg)
	local isMax = self.textArea:isMax()

	self.textArea:addText(msg)

	if isMax then
		self.textArea:scrollToMax(true)
	end
end

return FRAME_benchmark
