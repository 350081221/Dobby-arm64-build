local List = import("...ui.List")
local RewardList = class("RewardList", List)

function RewardList:ctor(rect, cols)
	RewardList.super.ctor(self, rect, List.DIRECTION_HORIZONTAL)

	self.isBounc = false
	self.noEmptyText = true

	if cols then
		self:setCols(cols)
	end

	cols = cols or 1

	self:setCellName("cell_reward")
	self:setCellSize(cc.size(self.touchRect.height / cols, self.touchRect.height))
	self:addEventListener("onTapListIcon", function (event)
		local data = event.data

		if data.type then
			DropManager.popDetail(data.type, data.info)
		else
			DropManager.popDetail(DropManager.TYPE.ITEM, data)
		end
	end)
	self:setTapGroup("list_click")
end

function RewardList:setSlotName(name)
	self.slotName = name
end

function RewardList:setAlwaysShowNumber(b)
	self.alwaysShowNumber = b
end

function RewardList:onCellInit(ui, data)
	local slotFlag = ui:getFlagByTag("flag_slot")
	slotFlag.width = self.touchRect.height / self.cols - slotFlag.x * 2
	slotFlag.height = slotFlag.width

	if not ui.slot then
		ui.slot = DropSlot.new(slotFlag, self.slotName or "slot_01")

		ui:addChild(ui.slot, 100)
	end

	ui.slot:setAlwaysShowNumber(self.alwaysShowNumber)

	if data.type then
		ui.slot:setDrop(data.type, data.info)
	else
		ui.slot:setDrop(DropManager.TYPE.ITEM, data)
	end
end

return RewardList
