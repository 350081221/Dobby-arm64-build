local EmuScene = class("EmuScene", function ()
	return display.newScene("EmuScene")
end)

function EmuScene:ctor()
	Log.debug("EmuScene:ctor")
	event_listener.extendMethods(self, true)
end

function EmuScene:isReplay()
	return true
end

function EmuScene:init()
	if app.sceneData and app.sceneData.myteam then
		self.myteam = true
	end

	global.inEmu = true

	Log.debug("EmuScene:init")

	global.monsterNoDropItem = true

	MapEffect.setDisabled(true)
	Sound.setSoundOn(false)
	Sound.setMusicOn(false)
	self:initMap()
	Log.debug("EmuScene:init initMap over")
	notify.safeRegister(self, "battle_state_change", function (isBattle)
		self.isBattle = isBattle
	end)

	self.ui = FRAME_emu.new()

	self:addChild(self.ui)

	global.ui = self.ui
end

function EmuScene:initMap()
	local map = Map.new(display.width, display.height)

	self:addChild(map)
	map:load("emu_abyss")
	map:setPositionOffset("emu", -150, 0)

	global.map = map
	local battleCenter = MapEventManager.getEventByTagOne("battle-center")
	local centerX, centerY = map:tileToMap(battleCenter.x, battleCenter.y)

	map:scrollTo(centerX, centerY)
	map:setFov(centerX, centerY)
end

function EmuScene:recordManualCast(heroIndex, event)
	local frame = WarMachine.getFrame()
	local info = {
		frame = frame,
		hero = heroIndex
	}

	if event.type == "pos" then
		info.target = {
			x = event.x,
			y = event.y
		}
	elseif event.type == "unit" then
		info.target = {
			index = event.index
		}
	end

	table.insert(self.skillRecord, info)
end

function EmuScene:recordSetAutoSkill(heroIndex, event)
	local frame = WarMachine.getFrame()
	local info = {
		frame = frame,
		hero = heroIndex,
		auto = event.isAuto and 1 or 0
	}

	table.insert(self.skillRecord, info)
end

function EmuScene:onEnter()
	app:onSceneEnter(self, nil, 1)
	self:init()
end

function EmuScene:onExit()
	global.player = nil
	global.ui = nil
	global.map = nil
	global.battleUI = nil
	global.adventureUI = nil

	app:onSceneExit(self)
end

return EmuScene
