local ColorUtil = {
	getC3B = function (rgbstr)
		local colorArr = string.split(rgbstr, ",")

		return cc.c3b(tonumber(colorArr[1]), tonumber(colorArr[2]), tonumber(colorArr[3]))
	end,
	getC4B = function (rgbstr, opacity)
		local colorArr = string.split(rgbstr, ",")

		return cc.c4b(tonumber(colorArr[1]), tonumber(colorArr[2]), tonumber(colorArr[3]), opacity)
	end
}

function ColorUtil.getUbb(color)
	return color.r .. "," .. color.g .. "," .. color.b
end

return ColorUtil
