local InfoDelayItem = {}
local TYPE = {
	HOME_WORKSHOP = 5,
	HOME_ALCHEMY_OTHER = 4,
	HOME_CRAFT_OTHER = 3,
	HOME_ALCHEMY = 2,
	HOME_CRAFT = 1
}
InfoDelayItem.TYPE = TYPE
local LABEL = {
	[TYPE.HOME_CRAFT] = Localization.getSrcText("工作台"),
	[TYPE.HOME_ALCHEMY] = Localization.getSrcText("炼金炉"),
	[TYPE.HOME_CRAFT_OTHER] = Localization.getSrcText("工作台（借用）"),
	[TYPE.HOME_ALCHEMY_OTHER] = Localization.getSrcText("炼金炉（借用）"),
	[TYPE.HOME_WORKSHOP] = Localization.getSrcText("工坊")
}
InfoDelayItem.LABEL = LABEL
local rawData = {}

function InfoDelayItem.init()
	Connection.listen("delay_item_sync", InfoDelayItem.sync)
	Connection.listen("delay_item_sync_remove", InfoDelayItem.syncRemove)
end

app:addToAppEnterCall(InfoDelayItem.init)

function InfoDelayItem.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoDelayItem.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("delay_item_query", callback)
end

function InfoDelayItem.onQuery(rcvData)
	rawData = {}

	for i, data in ipairs(rcvData.list) do
		rawData[data.id] = data
	end
end

function InfoDelayItem.sync(data)
	dump(data, "$$$ InfoDelayItem.sync")

	local changedIdStack = {}

	for i, syncData in ipairs(data.list) do
		local id = syncData.id

		if not rawData[id] then
			rawData[id] = syncData
		else
			for k, v in pairs(syncData) do
				rawData[id][k] = v
			end
		end

		changedIdStack[id] = rawData[id]
	end

	ManagerInfo.dataChange("delay_item", changedIdStack)
end

function InfoDelayItem.syncRemove(data)
	local teamChanged = false
	local changedIdStack = {}

	for i, id in ipairs(data.list) do
		if rawData[id] then
			changedIdStack[id] = rawData[id]
			rawData[id] = nil
		end
	end

	ManagerInfo.dataChange("delay_item", changedIdStack)
end

function InfoDelayItem.get(id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("delay_item_get", {
		id = id
	}, callback)
end

function InfoDelayItem.cancel(id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("delay_item_cancel", {
		id = id
	}, callback)
end

local function getTypes(types)
	local _types = {}

	if type(types) == "number" then
		_types = {
			types
		}
	elseif type(types) == "table" then
		_types = types
	else
		for k, v in pairs(_types) do
			table.insert(_types, v)
		end

		table.sort(_types, function (a, b)
			return a < b
		end)
	end

	return _types
end

function InfoDelayItem.getList(types)
	types = getTypes(types)
	local typeMap = {}

	for i, v in ipairs(types) do
		typeMap[v] = i
	end

	local nowTime = Time.now()
	local arr = {}
	local existMap = {}

	for k, v in pairs(rawData) do
		if typeMap[v.type] then
			if v.end_time <= nowTime and not existMap[v.type] then
				existMap[v.type] = true
				typeMap[v.type] = typeMap[v.type] - 1000
			end

			table.insert(arr, v)
		end
	end

	table.sort(arr, function (a, b)
		return typeMap[a.type] < typeMap[b.type]
	end)

	return arr
end

function InfoDelayItem.countReady(types)
	local typeMap = {}

	for i, v in ipairs(types) do
		typeMap[v] = i
	end

	local nowTime = Time.now()
	local count = 0

	for k, v in pairs(rawData) do
		if typeMap[v.type] and v.end_time <= nowTime then
			count = count + 1
		end
	end

	return count
end

function InfoDelayItem.getBestProgress(types)
	local typeMap = {}

	for i, v in ipairs(types) do
		typeMap[v] = i
	end

	local nowTime = Time.now()
	local percent = 0

	for k, v in pairs(rawData) do
		if typeMap[v.type] then
			local timeLeft = math.max(0, v.end_time - nowTime)
			local timeTotal = v.end_time - v.start_time
			local per = 1 - timeLeft / timeTotal

			if percent < per then
				percent = per
			end
		end
	end

	return percent
end

function InfoDelayItem.count(type)
	local count = 0

	for k, v in pairs(rawData) do
		if v.type == type then
			count = count + 1
		end
	end

	return count
end

return InfoDelayItem
