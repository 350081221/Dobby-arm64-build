local OnlineChat = {}
local CHANNEL = {
	WORLD = 1,
	NONE = 0,
	RECRUIT = 3,
	UNION = 2
}
OnlineChat.CHANNEL = CHANNEL
local TYPE = {
	MSG = 1,
	TOWER_ROOM = 10,
	SONG = 9,
	BATTLE_REPLAY = 8,
	BATTLE = 7,
	EMOJI = 6,
	CARD = 5,
	EQUIP = 4,
	PET = 3,
	HERO = 2
}
OnlineChat.TYPE = TYPE
local blacklistMap = {}

function OnlineChat.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			OnlineChat.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("chat_query", callback)
end

function OnlineChat.onQuery(rcvData)
	dump(rcvData, "$$$ chat_query")

	blacklistMap = {}
	local blacklist = rcvData.blacklist

	for i, info in ipairs(blacklist) do
		if info.user_info and info.user_info.user_id then
			blacklistMap[info.user_info.user_id] = info
		end
	end

	dump(blacklistMap, "$$$ blacklistMap")
end

function OnlineChat.addBlack(user_id, isAdd, onSuccess, onFailure)
	print("$$$ addBlacklist", isAdd and 1 or 2)

	local function callback(rcvData)
		dump(rcvData, "$$$ addBlacklist")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			if isAdd then
				local info = rcvData.user_info

				if info and info.user_info and info.user_info.user_id then
					blacklistMap[info.user_info.user_id] = info
				end
			else
				blacklistMap[user_id] = nil
			end

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("chat_blacklist_add_or_del", {
		user_id = user_id,
		operate = isAdd and 1 or 2
	}, callback)
end

function OnlineChat.inBlack(user_id)
	return blacklistMap[user_id] ~= nil
end

function OnlineChat.getBlackList()
	local arr = {}

	for user_id, info in pairs(blacklistMap) do
		table.insert(arr, info)
	end

	table.sort(arr, function (infoA, infoB)
		return infoB.join_time < infoA.join_time
	end)

	return arr
end

OnlineChat.currChannel = CHANNEL.WORLD

function OnlineChat.getChannels()
	local channels = {}

	table.insert(channels, {
		channel = CHANNEL.WORLD,
		name = Localization.getSrcText("世界")
	})

	local opening = InfoParams.getValue("union")

	if opening == 1 and InfoUnion.hasUnion() then
		table.insert(channels, {
			channel = CHANNEL.UNION,
			name = Localization.getSrcText("联盟")
		})
	end

	return channels
end

function OnlineChat.init()
	OnlineChat.initStack()
	Connection.listen("chat_push_msg", OnlineChat.onPushMsg)
	Connection.listen("chat_battle_count", OnlineChat.onUpdateBattleCount)
end

app:addToAppEnterCall(OnlineChat.init)

local lessTowerMap = {}
local lessMsgMap = {}
local chatStackMap = {}
local userInfoCached = {}
local equipInfoCached = {}
local cardInfoCached = {}
local heroInfoCached = {}
local petInfoCached = {}
local replayInfoCached = {}

function OnlineChat.initStack()
	chatStackMap = {}

	for k, channel in pairs(CHANNEL) do
		if channel ~= 0 then
			chatStackMap[channel] = {}
		end
	end
end

function OnlineChat.clear()
	OnlineChat.initStack()

	userInfoCached = {}
end

function OnlineChat.tryReconnect()
	if OnlineChat.isOnline() then
		OnlineChat.join()
	end
end

function OnlineChat.getStack(customChannel)
	return chatStackMap[customChannel or OnlineChat.currChannel]
end

function OnlineChat.cutStack(chatStack)
	while GameConfig.CHAT_CACHE_NUM < #chatStack do
		table.remove(chatStack, 1)
	end
end

function OnlineChat.clearLess()
	local now = math.floor(Time.time())

	for k, time in pairs(lessTowerMap) do
		if MiscConfig.chat_less_tower_time < now - time then
			lessTowerMap[k] = nil
		end
	end

	for k, time in pairs(lessMsgMap) do
		if MiscConfig.chat_less_msg_time < now - time then
			lessMsgMap[k] = nil
		end
	end
end

function OnlineChat.checkMsg(data)
	local now = math.floor(Time.time())

	if data.type == TYPE.TOWER_ROOM then
		local chatLessTower = Cookie.get("chatLessTower") or 1

		if chatLessTower == 1 then
			local user_id = data.user_info.user_id

			if user_id ~= InfoUser.getID() then
				if lessTowerMap[user_id] and now - lessTowerMap[user_id] <= MiscConfig.chat_less_tower_time then
					return false
				end

				lessTowerMap[user_id] = now
			end
		end
	end

	if data.type == TYPE.MSG then
		local user_id = data.user_info.user_id

		if user_id ~= InfoUser.getID() then
			local code = user_id .. "_" .. data.msg

			if lessMsgMap[code] and now - lessMsgMap[code] <= MiscConfig.chat_less_msg_time then
				lessMsgMap[code] = now

				return false
			end

			lessMsgMap[code] = now
		end
	end

	if data.poc == 1 and data.user_info and data.user_info.user_id ~= InfoUser.getID() then
		return false
	end

	if data.user_info and OnlineChat.inBlack(data.user_info.user_id) then
		return false
	end

	return true
end

local dupCache = {}
local maxDup = 0

function OnlineChat.clearOnScene()
	if maxDup and maxDup > 1 then
		print("OnlineChat.clearOnScene maxDup:", maxDup)

		for i = 1, math.min(maxDup, 5) do
			OnlineChat.exit()
		end
	end

	dupCache = {}
	maxDup = 0
	userInfoCached = {}
	equipInfoCached = {}
	cardInfoCached = {}
	heroInfoCached = {}
	petInfoCached = {}
	replayInfoCached = {}

	OnlineChat.clearLess()
end

function OnlineChat.onPushMsg(data)
	data = data.data

	dump(data, "$$$ OnlineChat.onPushMsg")

	local dupCode = (data.channel or CHANNEL.WORLD) .. "_" .. data.index

	print("$$$ dupCode", dupCode)

	if dupCache[dupCode] then
		dupCache[dupCode] = dupCache[dupCode] + 1
		maxDup = dupCache[dupCode]
	else
		dupCache[dupCode] = 0

		if data.type == TYPE.MSG and data.user_info.user_id ~= InfoUser.getID() then
			local chatLangMap = Cookie.get("chatLangMap")

			if data.lang and chatLangMap and not chatLangMap[data.lang] then
				return
			end
		end

		if OnlineChat.checkMsg(data) then
			local chatStack = chatStackMap[data.channel]

			table.insert(chatStack, data)
			OnlineChat.cutStack(chatStack)
			notify.dispatch("chat_add", {
				data
			}, true)
		end
	end
end

function OnlineChat.onUpdateBattleCount(data)
	dump(data, "$$$ OnlineChat.onUpdateBattleCount")

	local chatStack = chatStackMap[data.channel or CHANNEL.WORLD]

	for i, v in ipairs(chatStack) do
		if v.index == data.index then
			v.count = data.count

			notify.dispatch("chat_battle_count", v.index)

			return
		end
	end
end

function OnlineChat.join(channel, onSuccess, onFailure)
	channel = channel or OnlineChat.currChannel
	local chatStack = chatStackMap[channel]

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			OnlineChat.currChannel = channel

			if rcvData.list and #rcvData.list > 0 then
				for i, v in ipairs(rcvData.list) do
					if OnlineChat.checkMsg(v) then
						table.insert(chatStack, v)
					end
				end

				OnlineChat.cutStack(chatStack)
				notify.dispatch("chat_add", chatStack)
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	local start_index = 1

	if #chatStack > 0 then
		start_index = chatStack[#chatStack].index + 1
	end

	print("$$$ start_index", start_index)
	Connection.request("chat_join", {
		chat_channel = channel,
		start_index = start_index
	}, callback)
end

function OnlineChat.exit(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("chat_exit", callback)
end

function OnlineChat.getUserInfo(user_id, onSuccess, onFailure, force)
	local nowTime = Time.now()

	if not force and userInfoCached[user_id] and nowTime < userInfoCached[user_id].time + 300 then
		onSuccess(userInfoCached[user_id].data)

		return
	end

	local function callback(rcvData)
		dump(rcvData, "$$$ chat_get_user_info")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			userInfoCached[user_id] = {
				time = nowTime,
				data = rcvData
			}

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("chat_get_user_info", {
		user_id = user_id
	}, callback)
end

function OnlineChat.getEquipInfo(user_id, id, onSuccess, onFailure)
	local nowTime = Time.now()

	if equipInfoCached[id] and nowTime < equipInfoCached[id].time + 300 then
		onSuccess(equipInfoCached[id].data)

		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			equipInfoCached[id] = {
				time = nowTime,
				data = rcvData
			}

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("chat_get_equip_info", {
		user_id = user_id,
		id = id
	}, callback)
end

function OnlineChat.getCardInfo(user_id, id, onSuccess, onFailure)
	local nowTime = Time.now()

	if cardInfoCached[id] and nowTime < cardInfoCached[id].time + 300 then
		onSuccess(cardInfoCached[id].data)

		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			cardInfoCached[id] = {
				time = nowTime,
				data = rcvData
			}

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("chat_get_card_info", {
		user_id = user_id,
		id = id
	}, callback)
end

function OnlineChat.getHeroInfo(user_id, id, onSuccess, onFailure)
	local nowTime = Time.now()

	if heroInfoCached[id] and nowTime < heroInfoCached[id].time + 300 then
		onSuccess(heroInfoCached[id].data)

		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			heroInfoCached[id] = {
				time = nowTime,
				data = rcvData
			}

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("chat_get_hero_info", {
		user_id = user_id,
		id = id
	}, callback)
end

function OnlineChat.getPetInfo(user_id, id, onSuccess, onFailure)
	local nowTime = Time.now()

	if petInfoCached[id] and nowTime < petInfoCached[id].time + 300 then
		onSuccess(petInfoCached[id].data)

		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			petInfoCached[id] = {
				time = nowTime,
				data = rcvData
			}

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("chat_get_pet_info", {
		user_id = user_id,
		id = id
	}, callback)
end

function OnlineChat.addMsg(msg, onSuccess, onFailure)
	if InfoUser.isMute() then
		Alert.open(Localization.getSrcText("禁言中"))

		return
	end

	if not OnlineChat.checkTimes() then
		Alert.open(Localization.getSrcText("等待CD"))

		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			OnlineChat.useTimes()
			notify.dispatch("chat_cd")

			local params = {
				chat_content = msg,
				masked_content = rcvData.masked_msg or msg
			}

			TaHelper.taTrack("chat", params)

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("chat_add_msg", {
		msg = msg,
		lang = Localization.getLang(),
		channel = OnlineChat.currChannel
	}, callback)
end

function OnlineChat.addEquip(id, data, onSuccess, onFailure)
	if InfoUser.isMute() then
		Alert.open(Localization.getSrcText("禁言中"))

		return
	end

	if not OnlineChat.checkTimes() then
		Alert.open(Localization.getSrcText("等待CD"))

		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			OnlineChat.useTimes()
			notify.dispatch("chat_cd")

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	local pack = json.encode(data)

	Connection.request("chat_add_equip", {
		id = id,
		pack = pack,
		lang = Localization.getLang(),
		channel = OnlineChat.currChannel
	}, callback)
end

function OnlineChat.addCard(id, data, onSuccess, onFailure)
	if InfoUser.isMute() then
		Alert.open(Localization.getSrcText("禁言中"))

		return
	end

	if not OnlineChat.checkTimes() then
		Alert.open(Localization.getSrcText("等待CD"))

		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			OnlineChat.useTimes()
			notify.dispatch("chat_cd")

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	local pack = json.encode(data)

	Connection.request("chat_add_card", {
		id = id,
		pack = pack,
		lang = Localization.getLang(),
		channel = OnlineChat.currChannel
	}, callback)
end

function OnlineChat.addEmoji(id, onSuccess, onFailure)
	if InfoUser.isMute() then
		Alert.open(Localization.getSrcText("禁言中"))

		return
	end

	if not OnlineChat.checkTimes() then
		Alert.open(Localization.getSrcText("等待CD"))

		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			OnlineChat.useTimes()
			notify.dispatch("chat_cd")

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("chat_add_emoji", {
		id = id,
		channel = OnlineChat.currChannel
	}, callback)
end

function OnlineChat.addSong(id, onSuccess, onFailure)
	if InfoUser.isMute() then
		Alert.open(Localization.getSrcText("禁言中"))

		return
	end

	if not OnlineChat.checkTimes() then
		Alert.open(Localization.getSrcText("等待CD"))

		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			OnlineChat.useTimes()
			notify.dispatch("chat_cd")

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("chat_add_song", {
		id = id,
		channel = OnlineChat.currChannel
	}, callback)
end

function OnlineChat.addHero(id, data, onSuccess, onFailure)
	if InfoUser.isMute() then
		Alert.open(Localization.getSrcText("禁言中"))

		return
	end

	if not OnlineChat.checkTimes() then
		Alert.open(Localization.getSrcText("等待CD"))

		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			OnlineChat.useTimes()
			notify.dispatch("chat_cd")

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	local pack = json.encode(data)

	Connection.request("chat_add_hero", {
		id = id,
		pack = pack,
		lang = Localization.getLang(),
		channel = OnlineChat.currChannel
	}, callback)
end

function OnlineChat.addPet(id, data, onSuccess, onFailure)
	if InfoUser.isMute() then
		Alert.open(Localization.getSrcText("禁言中"))

		return
	end

	if not OnlineChat.checkTimes() then
		Alert.open(Localization.getSrcText("等待CD"))

		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			OnlineChat.useTimes()
			notify.dispatch("chat_cd")

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	local pack = json.encode(data)

	Connection.request("chat_add_pet", {
		id = id,
		pack = pack,
		lang = Localization.getLang(),
		channel = OnlineChat.currChannel
	}, callback)
end

function OnlineChat.addBattle(onSuccess, onFailure)
	if InfoUser.isMute() then
		Alert.open(Localization.getSrcText("禁言中"))

		return
	end

	if not OnlineChat.checkTimes() then
		Alert.open(Localization.getSrcText("等待CD"))

		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			OnlineChat.useTimes()
			notify.dispatch("chat_cd")

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	local pack = json.encode(data)

	Connection.request("chat_add_battle", {
		channel = OnlineChat.currChannel
	}, callback)
end

function OnlineChat.addTowerRoom(roomID, instID, onSuccess, onFailure)
	if not OnlineChat.checkTimes(3) then
		Alert.open(Localization.getSrcText("等待CD"))

		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			OnlineChat.useTimes(3)
			notify.dispatch("chat_cd")

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("chat_add_tower_room", {
		room_id = roomID,
		inst_id = instID,
		channel = OnlineChat.currChannel
	}, callback)
end

local battleUserID = nil

function OnlineChat.getBattleUserID()
	return battleUserID
end

function OnlineChat.startBattle(seed, attr_level, teams, user_id)
	battleUserID = user_id

	ArenaScene.enterMap(ArenaScene.TYPE.CHAT, seed, attr_level, teams)
end

function OnlineChat.startReplay(seed, attr_level, teams, skill_record)
	ArenaScene.enterMap(ArenaScene.TYPE.CHAT_REPLAY, seed, attr_level, teams, skill_record)
end

function OnlineChat.battleStart(index, onSuccess, onFailure)
	if not OnlineChat.checkTimes() then
		Alert.open(Localization.getSrcText("等待CD"))

		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			OnlineChat.useTimes()
			notify.dispatch("chat_cd")

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("chat_battle_start", {
		index = index,
		channel = OnlineChat.currChannel
	}, callback)
end

function OnlineChat.getBattleReplay(index, id, onSuccess, onFailure)
	local code = index .. "," .. id

	print("$$$ getBattleReplay", code, index, id, replayInfoCached[code])

	local nowTime = Time.now()

	if replayInfoCached[code] then
		onSuccess(replayInfoCached[code])

		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			replayInfoCached[code] = rcvData

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("chat_get_battle_replay", {
		index = index,
		id = id
	}, callback)
end

local battleLang = nil

function OnlineChat.saveBattleLang(lang)
	battleLang = lang
end

function OnlineChat.battleOver(isWin, skillRecord, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	local is_win = isWin and 1 or 0
	local recordStr = json.encode(skillRecord)

	Connection.request("chat_battle_over", {
		is_win = is_win,
		skill_record = recordStr,
		lang = battleLang
	}, callback)
end

function OnlineChat.battleLike(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ chat_battle_like")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("chat_battle_like", callback)
end

local chat_cd = 0
local chat_times = 0

function OnlineChat.checkTimes(point)
	point = point or 1
	local nowTime = Time.now()
	local chat_times_cd = CsvParser.getCsvData("config", "chat_times_cd").value
	local chat_times_max = CsvParser.getCsvData("config", "chat_times_max").value
	local timeOffset = nowTime - chat_cd
	local passedTimes = math.floor(timeOffset / chat_times_cd)
	local chat_times = math.max(chat_times - passedTimes, 0)

	if chat_times_max <= chat_times + point - 1 then
		return false
	end

	return true
end

function OnlineChat.useTimes(point)
	point = point or 1
	local nowTime = Time.now()
	local chat_times_cd = CsvParser.getCsvData("config", "chat_times_cd").value
	local chat_times_max = CsvParser.getCsvData("config", "chat_times_max").value
	local timeOffset = nowTime - chat_cd
	local passedTimes = math.floor(timeOffset / chat_times_cd)
	chat_times = math.max(chat_times - passedTimes, 0) + point

	if chat_times == 1 then
		chat_cd = nowTime
	else
		chat_cd = nowTime - (timeOffset - passedTimes * chat_times_cd)
	end

	return true
end

function OnlineChat.getCD()
	local nowTime = Time.now()
	local chat_times_cd = CsvParser.getCsvData("config", "chat_times_cd").value
	local chat_times_max = CsvParser.getCsvData("config", "chat_times_max").value
	local timeOffset = nowTime - chat_cd
	local passedTimes = math.floor(timeOffset / chat_times_cd)
	local chat_times = math.max(chat_times - passedTimes, 0)
	local percent = 1

	if chat_times > 0 then
		percent = (nowTime - chat_cd) / chat_times_cd % 1
	end

	local times = chat_times_max - chat_times

	return times, percent, chat_times_cd, chat_times_max
end

function OnlineChat.isOnlineChat()
	local isOnlineChat = Cookie.get("isOnlineChat") or 1

	return isOnlineChat
end

function OnlineChat.refreshOnlineSetup()
	local isOnlineChat = OnlineChat.isOnlineChat()

	OnlineChat.setOnline("chat_setup", isOnlineChat == 1)
	notify.dispatch("main_bard_refresh")
end

local onlineStat = nil

function OnlineChat.setOnline(tag, isOnline)
	local preOnline = OnlineChat.isOnline()

	if isOnline then
		onlineStat = onlineStat or {}
		onlineStat[tag] = true
	elseif onlineStat then
		onlineStat[tag] = nil
	end

	if onlineStat and table.nums(onlineStat) == 0 then
		onlineStat = nil
	end

	if not preOnline and OnlineChat.isOnline() then
		OnlineChat.join()
	end

	if not isOnline and not OnlineChat.isOnline() then
		OnlineChat.exit()
	end
end

function OnlineChat.isOnline()
	return onlineStat ~= nil
end

function OnlineChat.clearOnlineStat()
	onlineStat = nil
end

return OnlineChat
