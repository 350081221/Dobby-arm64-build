local InfoPetHatch = {}
local rawData = {}

function InfoPetHatch.init()
	Connection.listen("pet_hatch_sync", InfoPetHatch.sync)
	Connection.listen("pet_hatch_sync_remove", InfoPetHatch.syncRemove)
end

app:addToAppEnterCall(InfoPetHatch.init)

function InfoPetHatch.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			rawData = {}

			for i, data in ipairs(rcvData.list) do
				rawData[data.pos] = data
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("pet_hatch_query", callback)
end

function InfoPetHatch.sync(data)
	local changedIdStack = {}

	for i, syncData in ipairs(data.list) do
		local pos = syncData.pos

		if not rawData[pos] then
			rawData[pos] = syncData
		else
			for k, v in pairs(syncData) do
				rawData[pos][k] = v
			end
		end

		changedIdStack[pos] = rawData[pos]
	end

	ManagerInfo.dataChange("pet_hatch", changedIdStack)
end

function InfoPetHatch.syncRemove(data)
	local changedIdStack = {}

	for i, syncData in ipairs(data.list) do
		local pos = syncData.pos

		if rawData[pos] then
			changedIdStack[pos] = rawData[pos]
			rawData[pos] = nil
		end
	end

	ManagerInfo.dataChange("pet_hatch", changedIdStack)
end

function InfoPetHatch.getByPos(pos)
	return rawData[pos]
end

function InfoPetHatch.create(pos, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "pet_hatch_create")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("pet_hatch_create", {
		pos = pos
	}, callback)
end

function InfoPetHatch.put(pos, item_id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("pet_hatch_put", {
		pos = pos,
		item_id = item_id
	}, callback)
end

function InfoPetHatch.born(pos, is_acc, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			global.perHatchID = rcvData.id

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("pet_hatch_born", {
		pos = pos,
		is_acc = is_acc
	}, callback)
end

function InfoPetHatch.getHatchTime(pos)
	local hatchData = InfoPetHatch.getByPos(pos)

	if hatchData then
		local now = Time.now()
		local timeLeft = math.max(0, hatchData.end_time - now)
		local per = (now - hatchData.start_time) / (hatchData.end_time - hatchData.start_time)
		per = math.min(1, math.max(0, per))

		return per, timeLeft
	else
		return 0, 0
	end
end

function InfoPetHatch.getHatchNum()
	local count = 0

	for k, v in pairs(rawData) do
		count = count + 1
	end

	return count
end

function InfoPetHatch.countRedot()
	local csvRaw = CsvParser.getCsvRaw("achievement")
	local redotCount = 0

	for pos, v in pairs(rawData) do
		local hatchData = InfoPetHatch.getByPos(pos)

		if hatchData and not empty(hatchData.base_id) then
			local per, timeLeft = InfoPetHatch.getHatchTime(pos)

			if per >= 1 then
				redotCount = redotCount + 1
			end
		end
	end

	return redotCount
end

return InfoPetHatch
