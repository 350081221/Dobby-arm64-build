local NAV_base = import(".NAV_base")
local NAV_dust_next = class("NAV_dust_next", NAV_base)

function NAV_dust_next.open(npc)
	local ui = NAV_dust_next.new(npc)

	return ui
end

function NAV_dust_next:ctor(npc)
	NAV_dust_next.super.ctor(self, npc, "nav_dust_next")
end

function NAV_dust_next:onTap(index)
	NAV_dust_next.super.onTap(self, index)

	if index == 1 and InfoDungeon.inDust() then
		local eventData = self.npc.eventData

		if eventData then
			if not MapEventManager.checkBossKilled() then
				ErrCode.onErr("abyss_next_monster_clear")

				return
			end

			FRAME_dust_next.open(eventData.index)
		end
	end
end

return NAV_dust_next
