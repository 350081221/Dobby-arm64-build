local UI_base = import("..UI_base")
local Hint = class("Hint", UI_base)
local POSITION = {
	RIGHT = 3,
	CENTER = 2,
	LEFT = 1
}
local instanceStackMap = {
	[POSITION.LEFT] = {},
	[POSITION.CENTER] = {},
	[POSITION.RIGHT] = {}
}
local startXMap = {
	[POSITION.LEFT] = 0,
	[POSITION.CENTER] = display.width / 2,
	[POSITION.RIGHT] = display.width
}
local xAnchorMap = {
	[POSITION.LEFT] = 0,
	[POSITION.CENTER] = 0.5,
	[POSITION.RIGHT] = 1
}
local startYMap = {
	[POSITION.LEFT] = 500,
	[POSITION.CENTER] = 450,
	[POSITION.RIGHT] = 100
}
local ySpaceMap = {
	[POSITION.LEFT] = -32,
	[POSITION.CENTER] = 32,
	[POSITION.RIGHT] = 32
}
local maxMap = {
	[POSITION.LEFT] = 5,
	[POSITION.CENTER] = 5,
	[POSITION.RIGHT] = 5
}
local lastingTime = 2
local fadeinTime = 0.2
local fadeoutTime = 0.2
local moveTime = 0.2

function Hint.left(str, icon, time)
	Hint.add(POSITION.LEFT, str, icon, time)
end

function Hint.center(str, icon, time)
	Hint.add(POSITION.CENTER, str, icon, time)
end

function Hint.right(str, icon, time)
	Hint.add(POSITION.RIGHT, str, icon, time)
end

function Hint.add(position, str, icon, time)
	local instance = Hint.new(position, str, icon, time)
	instance.new = true
	local instanceStack = instanceStackMap[position]

	table.insert(instanceStack, instance)
	display.getRunningScene():addChild(instance, LayerConfig.hint)
	Hint.arrange(position)
end

function Hint.arrange(position)
	local instanceStack = instanceStackMap[position]
	local startX = startXMap[position]
	local startY = startYMap[position]
	local ySpace = ySpaceMap[position]
	local xAnchor = xAnchorMap[position]
	local max = maxMap[position]

	while max < #instanceStack do
		instanceStack[1]:delete()
	end

	for i = 1, #instanceStack do
		local instance = instanceStack[i]
		local y = startY + ySpace * (#instanceStack - i)

		if instance.new then
			instance:setOpacity(0)
			transition.fadeTo(instance, {
				opacity = 255,
				time = fadeinTime
			})
			instance:setPosition(startX - xAnchor * instance.width, y)

			instance.new = nil
		elseif (not instance.transID or instance.transY ~= y) and (instance.transID or instance:getPositionY() ~= y) then
			if instance.transID then
				instance:stopAction(instance.transID)
			end

			instance.transID = transition.moveTo(instance, {
				y = y,
				time = moveTime,
				onComplete = function ()
					instance.transID = nil
				end
			})
			instance.transY = y
		end
	end
end

function Hint.remove(position, instance)
	local instanceStack = instanceStackMap[position]

	for i = 1, #instanceStack do
		if instanceStack[i] == instance then
			table.remove(instanceStack, i)

			return
		end
	end

	Hint.arrange(position)
end

app:addToSceneExitCall(function ()
	instanceStackMap = {
		[POSITION.LEFT] = {},
		[POSITION.CENTER] = {},
		[POSITION.RIGHT] = {}
	}
end)

function Hint:ctor(position, str, icon, time)
	Hint.super.ctor(self, "hint")

	self.position = position
	self.msg = str
	self.icon = icon
	self.time = time or lastingTime

	self:init()
end

function Hint:init()
	self:initUI()
	self:performWithDelay(function ()
		self:delete()
	end, self.time)
end

function Hint:delete()
	Hint.remove(self.position, self)
	transition.fadeTo(self, {
		opacity = 0,
		time = fadeoutTime,
		onComplete = function ()
			self:removeSelf()
		end
	})
end

function Hint:initUI()
	local label, labelWidth = self:createLabelOnFlag("flag_msg", self.msg)

	if self.icon then
		self:createIconOnFlag("flag_icon", self.icon, 100)
		self:getComponentByTag("bg"):setSize(labelWidth + 40)

		self.width = labelWidth + 40
	else
		label:setPositionX(label:getPositionX() - 30)
		self:getComponentByTag("bg"):setSize(labelWidth + 10)

		self.width = labelWidth + 10
	end
end

return Hint
