local FRAME_user_active = class("FRAME_user_active", UI_base)

function FRAME_user_active.open(onConfirm)
	local ui = FRAME_user_active.new(onConfirm)

	display.getRunningScene():addChild(ui, LayerConfig.sys)
	PopManager.popinAnim(ui, callback, PopManager.ANIM_TYPE.JUMP)
end

function FRAME_user_active:ctor(onConfirm)
	FRAME_user_active.super.ctor(self, "frame_user_active")

	self.onConfirm = onConfirm

	self:init()
end

function FRAME_user_active:init()
	self:initUI()
end

function FRAME_user_active:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local mask = self:getComponentByTag("mask")

	mask:toTouchable()

	local inputEB = self:createEditBoxOnComponent("eb_input")

	inputEB:setInputMode(6)

	local confirmPB = self:getComponentByTag("confirm_pb")

	confirmPB:toTouchable()

	local function handleConfirm()
		local inputStr = inputEB:getText()

		if empty(inputStr) then
			Alert.open(Localization.getSrcText("请输入激活码"))

			return
		end

		if self.onConfirm then
			self.onConfirm(inputStr, function ()
				PopManager.fadeoutAnim(self)
			end)
		end
	end

	confirmPB:addTap(handleConfirm)

	local cancelPB = self:getComponentByTag("cancel_pb")

	cancelPB:toTouchable()

	local function handleCancel()
		PopManager.fadeoutAnim(self)
	end

	cancelPB:addTap(handleCancel)
	confirmPB:setTapGroup("button_click")
	cancelPB:setTapGroup("button_click")
end

return FRAME_user_active
