local BinarySort = class("BinarySort")

function BinarySort:ctor(arr)
	self.array = arr

	table.sort(self.array, function (a, b)
		return a.value < b.value
	end)
end

function BinarySort:find(value)
	local startIndex = 0
	local endIndex = #self.array

	while true do
		local index = math.floor((startIndex + endIndex) / 2)

		if self.array[index + 1].value <= value and (not self.array[index + 2] or value < self.array[index + 2].value) then
			return self.array[index + 1], self.array[index + 2]
		elseif value < self.array[index + 1].value then
			if index == 0 then
				return self.array[index + 1]
			else
				endIndex = index
			end
		elseif self.array[index + 2].value <= value then
			startIndex = index + 1
		end
	end
end

return BinarySort
