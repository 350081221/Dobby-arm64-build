local NAV_base = import(".NAV_base")
local NAV_build = class("NAV_build", NAV_base)

function NAV_build.open(npc)
	local ui = NAV_build.new(npc)

	return ui
end

function NAV_build:ctor(npc)
	NAV_build.super.ctor(self, npc, "nav_build")
	self:refreshBuild()
end

function NAV_build:onTap(index)
	NAV_build.super.onTap(self, index)

	local building = self.npc.data.building0

	if index == 1 then
		if InfoGuide.buildingLvupLock(building) then
			Alert.open(Localization.getSrcText("引导期间无法建造该建筑"))

			return
		end

		InfoBuilding.levelup(building, function ()
			if global.player then
				global.player:npcChanged(true)
			end
		end)
	elseif index == 2 then
		local buildingData = InfoBuilding.getBuildingData(building)
		local permitItem = buildingData.permit_item

		FRAME_item_detail.open({
			num = 1,
			base_id = permitItem
		})
	end
end

function NAV_build:refreshBuild()
	local building = self.npc.data.building0
	local buildingData = InfoBuilding.getBuildingData(building)
	local permitItem = buildingData.permit_item
	local ui = self.buttons[2].ui

	ui:createIconOnFlag("flag_icon", IconManager.getItemIcon(permitItem), 100, true)

	local shadow = ui:createIconOnFlag("flag_icon_shadow", IconManager.getItemIcon(permitItem), 99, true)

	shadow:setColor(cc.c3b(0, 0, 0))
	shadow:setOpacity(64)

	local progress = ui:getComponentByTag("progress")

	if InfoItem.getNum(permitItem) > 0 then
		progress:setColor(NAV_base.COLOR.READY)
	else
		progress:setColor(NAV_base.COLOR.DISABLE)
	end
end

return NAV_build
