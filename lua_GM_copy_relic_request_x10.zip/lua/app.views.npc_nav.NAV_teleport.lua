local NAV_base = import(".NAV_base")
local NAV_teleport = class("NAV_teleport", NAV_base)

function NAV_teleport.open(npc)
	local ui = NAV_teleport.new(npc)

	return ui
end

function NAV_teleport:ctor(npc)
	NAV_teleport.super.ctor(self, npc, "nav_teleport")
end

function NAV_teleport:onTap(index)
	NAV_teleport.super.onTap(self, index)
	print("NAV_teleport:onTap", index, self.npc)

	if index == 1 then
		print("$$$ self.npc.eventData.index", self.npc.eventData.index)

		local noResult = InfoDungeon.inDustPrepare()

		POP_notice.open(Localization.getSrcText("返回营地？"), function ()
			if not self.requestLock and self.npc then
				TaHelper.taGuideDetail(12600)

				if not noResult then
					InfoBag.saveBagItemInfo()
				end

				self.requestLock = true

				InfoDungeon.goHome(self.npc.eventData.index, function (rcvData)
					if not noResult then
						FRAME_dungeon_result.open(rcvData, FRAME_dungeon_result.OPEN_TYPE.EXIT)
						InfoBag.clearBagItemInfo()
					else
						InfoDungeon.enterCamp()
					end
				end, function ()
					self.requestLock = nil
				end)
			end
		end)
	end
end

return NAV_teleport
