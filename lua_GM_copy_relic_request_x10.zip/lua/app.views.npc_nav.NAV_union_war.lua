local NAV_base = import(".NAV_base")
local NAV_union_war = class("NAV_union_war", NAV_base)

function NAV_union_war.open(npc)
	local ui = NAV_union_war.new(npc)

	return ui
end

function NAV_union_war:ctor(npc)
	NAV_union_war.super.ctor(self, npc, "nav_union_war")
end

function NAV_union_war:init()
	NAV_union_war.super.init(self)
	self:setEnrollVisible(false)
	self:setZoneVisible(false)

	local mask = self:getComponentByTag("mask")

	mask:setOpacity(0)
	transition.fadeTo(mask, {
		easing = "sineOut",
		time = 0.2,
		opacity = 100
	})
	self:refresh()
end

function NAV_union_war:setEnrollVisible(visible, step, isEnroll)
	print("$$$ setEnrollVisible", visible)
	self:setButtonVisible(4, visible)

	if visible then
		local index = 4
		local ui = self.buttons[index].ui
		local bg = ui:getComponentByTag("bg")

		if isEnroll and InfoUnion.UNION_WAR_STEP.ENROLL <= step and step <= InfoUnion.UNION_WAR_STEP.ROUND_FIGHTING then
			bg:setColor(Style.white)
			self:setButtonName(ui, Localization.getSrcText("已报名"), {
				outline = 1,
				color = Style.enableColor
			})

			return
		end

		self:setButtonName(ui, Localization.getSrcText("报名"))

		if step == InfoUnion.UNION_WAR_STEP.ENROLL then
			bg:setColor(Style.white)
		else
			bg:setColor(Style.gray)
		end
	end
end

function NAV_union_war:setZoneVisible(visible)
	print("$$$ setZoneVisible", visible)
	self:setButtonVisible(3, visible)
end

function NAV_union_war:refresh()
	InfoUnion.warCheckSeason(function (seasonData)
		if self.init then
			self.infoUI = FRAME_union_war_info.new()

			self:addChild(self.infoUI, 100)
			self.infoUI:setOpacity(0)
			transition.fadeTo(self.infoUI, {
				easing = "sineOut",
				time = 0.2,
				opacity = 255
			})

			local isEnroll = seasonData.enroll == 1

			if InfoUnion.checkPower("war_enroll") then
				self:setEnrollVisible(true, seasonData.step, isEnroll)
			end

			self:setZoneVisible(false)

			if isEnroll and InfoUnion.UNION_WAR_STEP.ROUND_SETTING <= seasonData.step and seasonData.step <= InfoUnion.UNION_WAR_STEP.WAR_WATING_END then
				self:setZoneVisible(true)
			end
		end
	end)
end

function NAV_union_war:onTap(index)
	NAV_union_war.super.onTap(self, index)

	if index == 1 then
		FRAME_gwar_ready.open(self)
	elseif index == 2 then
		FRAME_union_war_history.open()
	elseif index == 3 then
		local seasonData = InfoUnion.warGetSeason()

		if seasonData then
			FRAME_union_war_zone.open()
		end
	elseif index == 4 then
		local seasonData = InfoUnion.warGetSeason()

		if seasonData then
			if seasonData.step ~= InfoUnion.UNION_WAR_STEP.ENROLL then
				Alert.open(Localization.getSrcText("不在报名时间内"))

				return
			end

			local isEnroll = seasonData.enroll == 1

			if isEnroll then
				Alert.open(Localization.getSrcText("已经报名过"))

				return
			end
		end

		InfoUnion.warEnroll(function ()
			Alert.open(Localization.getSrcText("报名成功"))
			self:setEnrollVisible(false)
			self:refresh()
		end)
	end
end

function NAV_union_war:close(immediately)
	NAV_union_war.super.close(self, immediately)

	local mask = self:getComponentByTag("mask")

	transition.stopTarget(mask)
	transition.fadeTo(mask, {
		easing = "sineOut",
		time = 0.2,
		opacity = 0
	})

	if self.infoUI then
		transition.fadeTo(self.infoUI, {
			easing = "sineOut",
			time = 0.2,
			opacity = 0
		})
	end
end

return NAV_union_war
