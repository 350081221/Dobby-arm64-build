local InfoCore = {}
local dataMap = {}

function InfoCore.init()
	Connection.listen("core_sync", InfoCore.sync)
end

app:addToAppEnterCall(InfoCore.init)

function InfoCore.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoCore.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("core_query", callback)
end

function InfoCore.onQuery(rcvData)
	dump(rcvData, "core_query", 10)

	dataMap = {}

	for i, v in ipairs(rcvData.list) do
		dataMap[v.week_id] = v
	end
end

function InfoCore.sync(data)
	dump(data, "InfoCore.sync", 10)

	if data.list then
		for i, syncData in ipairs(data.list) do
			if dataMap[syncData.week_id] then
				for k, v in pairs(syncData) do
					dataMap[syncData.week_id][k] = v
				end
			else
				dataMap[syncData.week_id] = syncData
			end
		end
	end

	ManagerInfo.dataChange("core")
end

function InfoCore.waveStart(week_id, wave, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("core_wave_start", {
		week_id = week_id,
		wave = wave
	}, callback)
end

function InfoCore.waveFin(week_id, wave, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	local params = {
		week_id = week_id,
		wave = wave,
		hash = InfoCore.getBattleHash(week_id, wave)
	}

	Connection.request("core_wave_fin", params, callback)
end

function InfoCore.selectBuff(week_id, wave, buffID, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("core_wave_select_buff", {
		week_id = week_id,
		wave = wave,
		buff_id = buffID
	}, callback)
end

function InfoCore.getReward(week_id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("core_reward", {
		week_id = week_id
	}, callback)
end

function InfoCore.getBattleHash(week_id, wave)
	WarMachine.makeCheckSum()

	local warnCount, sumStack = WarMachine.getCheckSum()
	local attrCheckCount, attrCheckMap = WarMachine.getCheckAttr()
	local newCheckMap = {}
	local modaoLevelMap = {}

	for heroID, data in pairs(attrCheckMap) do
		if data.ty == 1 or data.ty == 3 then
			local obj = {
				ct = data.ct,
				cte = data.cte,
				id = data.id,
				ty = data.ty,
				attrs = ""
			}

			if data.attrs then
				for i, v in ipairs(data.attrs) do
					if i > 1 then
						obj.attrs = obj.attrs .. ","
					end

					if v ~= 0 then
						obj.attrs = obj.attrs .. v
					end
				end
			end

			newCheckMap[heroID] = obj
		elseif data.ty == 10 then
			modaoLevelMap[tostring(data.id)] = data.level
		end
	end

	local hashObj = {
		a = warnCount,
		b = sumStack,
		c = attrCheckCount,
		d = newCheckMap,
		e = modaoLevelMap
	}
	local hashstr = json.encode(hashObj)
	local key = crypto.md5(wave .. week_id)
	key = string.sub(key, 4, 8)
	local hash = crypto.encryptXXTEA(hashstr, key)

	return hash
end

function InfoCore.getWeekID()
	local nowTime = math.floor(Time.now())
	local core_week_offset = CsvParser.getCsvData("config", "core_week_offset").value
	local weekID = Time.getSharpWeek(nowTime, -core_week_offset)

	return weekID
end

function InfoCore.getCurrentData()
	local weekID = InfoCore.getWeekID()
	local data = dataMap[weekID]

	if not data then
		data = {
			week_id = weekID,
			wave = 0,
			time = 0,
			buffs = "",
			best_wave = 0,
			best_time = 0,
			timestamp = 0,
			rewarded = 0
		}
	end

	return data
end

function InfoCore.test()
	local data = InfoCore.getCurrentData()

	InfoCore.enter(data)

	return true
end

local state, stateTime, retryState, battleWave, battleData, waveStartTime, waveEndTime, buffArr = nil

function InfoCore.retry()
	InfoCore.enter(battleData)

	return true
end

function InfoCore.getDisplay()
	local time = nil

	if waveStartTime then
		time = math.max(0, (waveEndTime or Time.now()) - waveStartTime)
	end

	return battleWave, time
end

function InfoCore.enter(data)
	battleData = data or InfoCore.getCurrentData()
	battleWave = 0
	waveStartTime = nil
	waveEndTime = nil
	buffArr = {}
	local csvList = CsvParser.getCsvList("core_battle")
	local battleIndex = battleData.week_id % #csvList + 1
	local csv = csvList[battleIndex]

	DungeonScene.enterMap(DungeonScene.ENTER_TYPE.CORE, csv.map)
end

function InfoCore.battleStart()
	print("$$$ InfoCore.battleStart")

	state = 0
	stateTime = Time.now() + 3

	InfoModao.initDungeon(true)

	local csvList = CsvParser.getCsvList("core_battle")
	local battleIndex = battleData.week_id % #csvList + 1
	local csv = csvList[battleIndex]
	local anchor = MapEventManager.getEventByTagOne("anchor")
	local battleCenter = MapEventManager.getEventByTagOne("battle-center")
	local centerTile = global.map:getTile(battleCenter.x, battleCenter.y)

	global.map:prepareBattle(centerTile, 0, {
		seed = battleData.week_id
	})
	Looper.startLoop(InfoCore, InfoCore.update)
end

function InfoCore.battleStop()
	print("$$$ InfoCore.battleStop")
	Looper.stopLoop(InfoCore, InfoCore.update)
	WarMachine.over()

	local data = InfoCore.getData(battleData.week_id) or battleData

	FRAME_core_over.open(data)
end

function InfoCore.waveClear()
	WarMachine.cleanSummoned()

	local units = WarMachine.getUnitsByCamp(1)

	for i, unit in ipairs(units) do
		unit:clearDebuff()
	end
end

function InfoCore.addBuff(buffID)
	local units = WarMachine.getUnitsByCamp(1)

	for i, unit in ipairs(units) do
		local buffCSV = CsvParser.getCsvData("core_wave_reward", buffID)

		unit:addShrineBuff(buffCSV.buff_id, 0)
	end

	table.insert(buffArr, buffID)
end

function InfoCore.getBuffs()
	local arr = {}

	for i, buffID in ipairs(buffArr) do
		local csv = CsvParser.getCsvData("core_wave_reward", buffID)

		table.insert(arr, csv)
	end

	return arr
end

function InfoCore.update()
	local nowTime = Time.now()

	if state == 3 then
		if stateTime < nowTime then
			state = retryState
		end
	elseif state == 0 then
		if stateTime < nowTime then
			state = -1
			local wave = battleWave + 1
			local maxWave = CsvParser.getMaxID("core_wave")

			if maxWave < wave then
				InfoCore.battleStop()
			else
				InfoCore.waveStart(battleData.week_id, wave, function ()
					battleWave = wave
					waveStartTime = Time.now()
					waveEndTime = nil

					InfoCore.makeMonster()

					state = 1
				end, function ()
					retryState = 0
					state = 3
					stateTime = Time.now() + 1
				end)
			end
		end
	elseif state == 1 then
		local heroCount = 0
		local units = WarMachine.getUnitsByCamp(1)

		for i, unit in ipairs(units) do
			if unit.type == "hero" then
				heroCount = heroCount + 1

				break
			end
		end

		local isLose = heroCount == 0

		if isLose then
			InfoCore.battleStop()
		else
			local units = WarMachine.getUnitsByCamp(2)
			local isWin = #units == 0

			if isWin then
				local wave = battleWave
				local waveCSV = CsvParser.getCsvData("core_wave", wave, nil, true)

				InfoCore.waveClear()

				state = -1

				MapFrameManager.pause("FRAME_core_reward")
				InfoCore.waveFin(battleData.week_id, wave, function ()
					waveEndTime = Time.now()

					local function goNext()
						MapFrameManager.resume("FRAME_core_reward")

						state = 0
						stateTime = Time.now() + 2
					end

					local rewards = nil

					if waveCSV.is_reward == 1 then
						rewards = InfoCore.getWaveRewards(wave)
					end

					if rewards and #rewards > 0 then
						FRAME_core_reward.open(rewards, function (csv)
							local buffID = csv.id

							InfoCore.selectBuff(battleData.week_id, wave, buffID, function ()
								InfoCore.addBuff(buffID)
								goNext()
							end, goNext)
						end)
					else
						goNext()
					end
				end, function ()
					retryState = 1
					state = 3
					stateTime = Time.now() + 1
				end)
			end
		end
	end
end

function InfoCore.getWaveRewards(wave)
	local waveCSV = CsvParser.getCsvData("core_wave", wave)
	local csvList = CsvParser.getCsvList("core_wave_reward", nil, {
		group = waveCSV.reward_group
	})
	local seed = battleData.week_id * 100 + wave
	local random = Random.new(seed)
	local csvList = random:order(csvList)
	local arr = {}

	for i, csv in ipairs(csvList) do
		table.insert(arr, csv)

		if i >= 3 then
			break
		end
	end

	return arr
end

function InfoCore.makeMonster()
	local csvList = CsvParser.getCsvList("core_battle")
	local battleIndex = battleData.week_id % #csvList + 1
	local battleCSV = csvList[battleIndex]
	local wave = battleWave
	local seed = battleData.week_id * 100 + wave
	local random = Random.new(seed)
	local groupID = battleCSV["battle_" .. wave]
	local waveCSV = CsvParser.getCsvData("core_wave", wave)
	local groups = MapEventManager.getMonsterGroup(groupID, random)
	local groupData = groups[1]
	local anchor = MapEventManager.getEventByTagOne("anchor")
	local posArray = {}

	local function generatePosArray()
		for i = 0, anchor.w - 1 do
			for j = 0, anchor.h - 1 do
				local tile = global.map:getTile(anchor.x + i, anchor.y + j)

				if tile and tile:getWalk() == 0 then
					table.insert(posArray, {
						x = anchor.x + i,
						y = anchor.y + j
					})
				end
			end
		end
	end

	generatePosArray()

	local monsterInfoArr = {}
	local index = 1

	while #posArray > 0 do
		local monsterObj = groupData.monsters[index]

		if monsterObj then
			local num = SheetUtil.getNumber(monsterObj.num, random)

			for j = 1, num do
				local monsterInfo = MapEventManager.getMonsterInfo(monsterObj.id)
				monsterInfo.level = waveCSV.level
				local monster = Monster.new(anchor.index)
				monster.seed = seed
				monster.random = Random.new(monster.seed)

				monster:setInfo(monsterInfo)

				local pos = table.remove(posArray, random:getInt(1, #posArray))
				local x, y = global.map:tileToMap(pos.x, pos.y)

				monster:display(global.map, x, y)
				WarMachine.addUnit(monster, 2, "InfoCore.makeMonster")
				monster:bornEffect()

				if #posArray == 0 then
					generatePosArray()
				end
			end

			index = index + 1
		else
			break
		end
	end
end

function InfoCore.getData(week_id)
	local data = dataMap[week_id]

	return data
end

local ranking_map_week = {}
local requesting_map_week = {}
local request_time_map_week = {}
local rankingAmount_week = {}
local selfRank_week = {}
local snapshot_week = {}

function InfoCore.getMyRank(week_id)
	return selfRank_week[week_id] or 0
end

function InfoCore.getRankingAmount(week_id)
	return rankingAmount_week[week_id] or 0
end

function InfoCore.getRankingSnapshot(week_id)
	return snapshot_week[week_id]
end

function InfoCore.startRanking(week_id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ core_ranking_start")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			rankingAmount_week[week_id] = rcvData.amount
			selfRank_week[week_id] = rcvData.self_rank
			snapshot_week[week_id] = rcvData.snapshot

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("core_ranking_start", {
		week_id = week_id
	}, callback)
end

function InfoCore.getRanking(week_id, page, onSuccess, onFailure)
	local ranking_map, requesting_map, request_time_map = InfoCore.prepareRanking(week_id)
	local start_index = (page - 1) * GameConfig.ranking_page + 1
	local ranking_max = CsvParser.getCsvData("config", "core_ranking_max").value

	if ranking_max < start_index then
		return
	end

	local function callback(rcvData)
		dump(rcvData, "$$$ core_ranking")

		requesting_map[page] = nil
		request_time_map[page] = Time.time()

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			local list = rcvData.list

			for i, v in ipairs(list) do
				local rank = start_index + i - 1
				local snapshot = {}

				if not empty(v.snapshot) then
					snapshot = json.decode(v.snapshot) or {}
				end

				ranking_map[rank] = {
					rank = rank,
					id = v.id,
					user_id = v.user_id,
					name = v.name,
					best_wave = v.best_wave,
					best_time = v.best_time,
					head = v.head,
					head_frame = v.head_frame,
					score = v.score,
					snapshot = snapshot
				}
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	requesting_map[page] = true

	Connection.request("core_ranking", {
		week_id = week_id,
		start_index = start_index
	}, callback)
end

function InfoCore.getRankingData(week_id, rank)
	local ranking_map, requesting_map, request_time_map = InfoCore.prepareRanking(week_id)
	local page = math.floor((rank - 1) / GameConfig.ranking_page) + 1

	if not ranking_map[rank] or GameConfig.ranking_local_time < Time.time() - request_time_map[page] then
		if not requesting_map[page] then
			InfoCore.getRanking(week_id, page)
		end
	else
		return ranking_map[rank]
	end
end

function InfoCore.prepareRanking(week_id)
	if not ranking_map_week[week_id] then
		ranking_map_week[week_id] = {}
	end

	if not requesting_map_week[week_id] then
		requesting_map_week[week_id] = {}
	end

	if not request_time_map_week[week_id] then
		request_time_map_week[week_id] = {}
	end

	return ranking_map_week[week_id], requesting_map_week[week_id], request_time_map_week[week_id]
end

local lookCached = {}

function InfoCore.look(week_id, id, onSuccess, onFailure)
	local code = week_id .. "_" .. id

	if lookCached[code] and Time.time() - lookCached[code].time < 60 then
		if onSuccess then
			onSuccess(lookCached[code].data)
		end

		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			lookCached[code] = {
				data = rcvData,
				time = Time.time()
			}

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("core_look", {
		week_id = week_id,
		id = id
	}, callback)
end

function InfoCore.clearRanking(week_id)
	ranking_map_week[week_id] = {}
	requesting_map_week[week_id] = {}
	request_time_map_week[week_id] = {}
end

function InfoCore.countRedot()
	local redotCount = 0
	local data = InfoCore.getCurrentData()

	if data.rewarded == 0 and data.best_wave > 0 then
		redotCount = redotCount + 1
	end

	return redotCount
end

return InfoCore
