local LinesManager = class("LinesManager")
local RARE_BASE = 100
local opArr = {
	"!=",
	">=",
	"<=",
	"=",
	">",
	"<"
}

local function checkCond(data, cond, emptyPass)
	local op, var = nil
	local values = {}

	for i, _op in ipairs(opArr) do
		local tagStart, tagEnd = string.find(cond, _op)

		if tagStart then
			op = _op
			var = string.sub(cond, 1, tagStart - 1)
			local value = string.sub(cond, tagEnd + 1)
			var = StringUtil.trim(var)
			value = StringUtil.trim(value)

			if string.find(value, ",") then
				local _values = string.split(value, ",")

				for i, v in ipairs(_values) do
					v = StringUtil.trim(v)

					if v ~= "" then
						table.insert(values, tonumber(v) or v)
					end
				end

				break
			end

			table.insert(values, tonumber(value) or value)

			break
		end
	end

	if empty(data[var]) and emptyPass then
		return true
	end

	local orOK = false

	for i, value in ipairs(values) do
		if (var == "min_level" or var == "max_level" or var == "min_layer" or var == "max_layer") and empty(data[var]) then
			orOK = true
		elseif op == "!=" then
			orOK = data[var] ~= value
		elseif op == ">=" then
			orOK = value <= data[var]
		elseif op == "<=" then
			orOK = data[var] <= value
		elseif op == "=" then
			orOK = data[var] == value
		elseif op == ">" then
			orOK = value < data[var]
		elseif op == "<" then
			orOK = data[var] < value
		end

		if orOK then
			break
		end
	end

	return orOK
end

local baseIDArrayStack = {}

function getBaseID(sheetName, baseConArr, random, emptyPass, checkFunc)
	local cache_key = "LinesManager_getBaseID@" .. sheetName

	for i, v in ipairs(baseConArr) do
		cache_key = cache_key .. "_" .. v
	end

	local itemArray = baseIDArrayStack[cache_key]

	if not itemArray then
		itemArray = {}
		local rawData = CsvParser.getCsvList(sheetName)

		for index, data in ipairs(rawData) do
			local condOK = true

			for i, cond in ipairs(baseConArr) do
				if not checkCond(data, cond, emptyPass) then
					condOK = false

					break
				end
			end

			if condOK then
				table.insert(itemArray, data)
			end
		end

		baseIDArrayStack[cache_key] = itemArray
	end

	if #itemArray > 0 then
		local power_arr = {}
		local csv_arr = {}

		for i, data in ipairs(itemArray) do
			if (not checkFunc or checkFunc(data)) and not empty(data.rare) then
				local power = data.rare

				if power > 0 then
					power = 1 / power
					power = math.pow(power, RARE_BASE / (RARE_BASE + 0))

					table.insert(power_arr, power)
					table.insert(csv_arr, data)
				end
			end
		end

		local power_index = SheetUtil.getPowerRandomIndex(power_arr, random)

		if #csv_arr > 0 then
			local csv = csv_arr[power_index]

			return csv.id, csv
		end
	end
end

function LinesManager.clearCache()
	baseIDArrayStack = {}
end

local NPC_NEAR_INTERVAL_ONE = "20~30"
local NPC_NEAR_INTERVAL_ALL = "7~12"
local npcNearTimeMap = {}
local npcNearTimeAll = nil

function LinesManager.checkNpcNearTime(npcID)
	local nowTime = Time.now()

	if npcNearTimeAll and nowTime < npcNearTimeAll then
		return false
	end

	if npcNearTimeMap[npcID] and nowTime < npcNearTimeMap[npcID] then
		return false
	end

	return true
end

function LinesManager.markNpcNearTime(npcID)
	local nowTime = Time.now()
	npcNearTimeAll = nowTime + SheetUtil.getNumber(NPC_NEAR_INTERVAL_ALL)
	npcNearTimeMap[npcID] = nowTime + SheetUtil.getNumber(NPC_NEAR_INTERVAL_ONE)
end

function LinesManager.getNpcNear(npcID)
	local abyssLayer = InfoDungeon.getAbyssMaxLayer()
	local baseConArr = {}

	table.insert(baseConArr, "npc=" .. npcID)
	table.insert(baseConArr, "min_layer<=" .. abyssLayer)
	table.insert(baseConArr, "max_layer>=" .. abyssLayer)

	local id, data = getBaseID("lines_npc_near", baseConArr, nil, true)

	if data then
		return data.text
	end
end

function LinesManager.getNpcOpen(npcID)
	local abyssLayer = InfoDungeon.getAbyssMaxLayer()
	local baseConArr = {}

	table.insert(baseConArr, "npc=" .. npcID)
	table.insert(baseConArr, "min_layer<=" .. abyssLayer)
	table.insert(baseConArr, "max_layer>=" .. abyssLayer)

	local id, data = getBaseID("lines_npc_open", baseConArr, nil, true)

	if data then
		return data.text
	end
end

function LinesManager.getBard(type, seed, params)
	local baseConArr = {}

	table.insert(baseConArr, "type=" .. type)

	if params then
		if not empty(params.map_type) then
			table.insert(baseConArr, "map_type=" .. params.map_type)
		end

		if not empty(params.abyss_layer) then
			table.insert(baseConArr, "min_layer<=" .. params.abyss_layer)
			table.insert(baseConArr, "max_layer>=" .. params.abyss_layer)
		end
	end

	local id, data = getBaseID("lines_bard", baseConArr, Random.new(seed))

	if data then
		return data
	end
end

local function getHeroLines(baseFile, hero_class, map_type, dungeon_level, pre_id)
	local baseConArr = {}

	if not empty(map_type) then
		table.insert(baseConArr, "map_type=" .. map_type)
	end

	if not empty(hero_class) then
		table.insert(baseConArr, "hero_class=" .. hero_class)
	end

	if not empty(dungeon_level) then
		table.insert(baseConArr, "min_level<=" .. dungeon_level)
		table.insert(baseConArr, "max_level>=" .. dungeon_level)
	end

	if not empty(pre_id) then
		table.insert(baseConArr, "id!=" .. pre_id)
	end

	local id, data = getBaseID(baseFile, baseConArr, nil, true)

	if data then
		return data
	end
end

local sayTimeBase = 60
local sayTimePer = 10

function LinesManager.getCampfire(hero_class, map_type, dungeon_level, pre_id)
	local chatMsg = getHeroLines("lines_hero_campfire", hero_class, map_type, dungeon_level, pre_id)
	local sayTime = sayTimeBase + sayTimePer * utf8.len(chatMsg.text)

	if Localization.isAlphabet() then
		sayTime = math.ceil(sayTime / 2)
	end

	return chatMsg, sayTime
end

function LinesManager.getAfterBattle(hero_class, map_type, dungeon_level, pre_id)
	local chatMsg = getHeroLines("lines_hero_after_battle", hero_class, map_type, dungeon_level, pre_id)
	local sayTime = sayTimeBase + sayTimePer * utf8.len(chatMsg.text)

	if Localization.isAlphabet() then
		sayTime = math.ceil(sayTime / 2)
	end

	return chatMsg, sayTime
end

function LinesManager.getEnterCamp(hero_class, dungeon_level, pre_id)
	local chatMsg = getHeroLines("lines_hero_enter_camp", hero_class, nil, dungeon_level, pre_id)
	local sayTime = sayTimeBase + sayTimePer * utf8.len(chatMsg.text)

	if Localization.isAlphabet() then
		sayTime = math.ceil(sayTime / 2)
	end

	return chatMsg, sayTime
end

function LinesManager.getAction(id)
	print("$$$ LinesManager.getAction", id)

	local csv = CsvParser.getCsvData("lines_action", id)

	return csv.text
end

function LinesManager.getAbyssHint(isEnter, dungeon_level, seed)
	local baseConArr = {}

	if not empty(dungeon_level) then
		table.insert(baseConArr, "min_level<=" .. dungeon_level)
		table.insert(baseConArr, "max_level>=" .. dungeon_level)
	end

	local timing = "1"

	if not isEnter then
		timing = "2"
	end

	local id, data = getBaseID("abyss_hint", baseConArr, Random.new(seed), true, function (csv)
		local tArr = string.split(tostring(csv.timing), ",")

		for i, v in ipairs(tArr) do
			if v == timing then
				return true
			end
		end

		return false
	end)

	if data then
		return data
	end
end

function LinesManager.getTravelNpc(travel_id)
	local baseConArr = {}

	if not empty(travel_id) then
		table.insert(baseConArr, "travel_id=" .. travel_id)
	end

	local dungeon_level = InfoDungeon.getAbyssMaxLevel()

	table.insert(baseConArr, "min_level<=" .. dungeon_level)
	table.insert(baseConArr, "max_level>=" .. dungeon_level)

	local id, data = getBaseID("lines_travel", baseConArr, nil, true)

	if data then
		return data
	end
end

return LinesManager
