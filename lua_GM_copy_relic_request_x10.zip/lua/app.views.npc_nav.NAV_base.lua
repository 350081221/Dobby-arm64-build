local UI_base = import("..UI_base")
local NAV_base = class("NAV_base", UI_base)
local COLOR = {
	NONE = cc.c3b(255, 255, 255),
	DISABLE = cc.c3b(224, 92, 92),
	PROGRESS = cc.c3b(113, 184, 195),
	READY = cc.c3b(91, 197, 107),
	HIGH = cc.c3b(226, 189, 61)
}
NAV_base.COLOR = COLOR
local instance = nil

function NAV_base:ctor(npc, uiName, isInner)
	global.ui:addChild(self, 110)
	NAV_base.super.ctor(self, uiName, UIManager.BIG_TYPE.POP)

	self.uiName = uiName
	self.npc = npc

	self:init()

	if not isInner then
		if instance and not tolua.isnull(instance) then
			instance:removeSelf()
		end

		instance = self
	end
end

function NAV_base:addUI(navUI)
	self.additionalUI = self.additionalUI or {}

	table.insert(self.additionalUI, navUI)
end

function NAV_base:addButtonInfo(buttonIndex, str)
	if self.buttons[buttonIndex] then
		local ui = self.buttons[buttonIndex].ui
		local infoUI = UIManager.getUI("nav_button_info")

		ui:addChild(infoUI)

		str = string.gsub(str, "\\n", "\n")
		local label, labelWidth, labelHeight = infoUI:createLabelOnFlag("flag_desc", str, {
			wrap = true,
			valign = Style.vbottom
		})
		local bg = infoUI:getComponentByTag("bg")

		bg:setSize(nil, labelHeight + 20)
	end
end

function NAV_base:getButtonUI(buttonIndex)
	return self.uiName .. "_button_" .. buttonIndex
end

function NAV_base:init(ignoreButtons)
	self.buttons = {}
	self._buttons = {}
	local ignoreButtonMap = {}

	if ignoreButtons then
		for i, v in ipairs(ignoreButtons) do
			ignoreButtonMap[v] = true
		end
	end

	self.ignoreButtonMap = ignoreButtonMap
	local buttonIndex = 1
	local button = self:getComponentByTag("button_" .. buttonIndex)
	local minX = nil

	while button do
		button:removeLabel()

		if button.setTexture then
			button:setTexture(UIManager.getEmptyTexture())
		end

		if button.frames then
			for i, v in ipairs(button.frames) do
				if v.setTexture then
					v:setTexture(UIManager.getEmptyTexture())
				end
			end
		end

		if not ignoreButtonMap[buttonIndex] then
			button:toTouchable()
			button:addTap(function (x, y)
				if self.closed then
					return
				end

				self:onButtonTap(x, y)
			end)
			button:addTouch(function (event, x, y)
				if self.closed then
					return
				end

				self:onTapGroupTouch(event, x, y)
			end)
		end

		local ui = UIManager.getUI(self:getButtonUI(buttonIndex))
		local shadow = self:getComponentByTag("shadow_" .. buttonIndex)

		ui:setPosition(button.width / 2, button.height / 2)
		button:addChild(ui, 100)
		self:resizeButtonLabel(ui)
		table.insert(self.buttons, {
			enabled = true,
			button = button,
			ui = ui,
			shadow = shadow
		})
		table.insert(self._buttons, button)

		button.buttonIndex = buttonIndex

		function button.onFocusTap(_button)
			self:onTap(_button.buttonIndex)
		end

		local delay = math.sqrt(buttonIndex - 1) * 0.1

		button:setScale(0)
		transition.scaleTo(button, {
			time = 0.2,
			scale = 1,
			easing = "backOut",
			delay = delay
		})

		if shadow then
			shadow:setScale(0)
			transition.scaleTo(shadow, {
				time = 0.2,
				scale = 1,
				easing = "backOut",
				delay = delay
			})
		end

		local x = button:getPositionX() - button.width / 2

		if not minX or x < minX then
			minX = x
		end

		buttonIndex = buttonIndex + 1
		button = self:getComponentByTag("button_" .. buttonIndex)
	end

	if not self.noAddTask then
		if self.npc and self.npc.npcType == Npc.TYPE.NPC then
			local data = InfoTaskQuest.getDataForNPC(self.npc.baseID)

			if data then
				local taskNav = NAV_task.open(self.npc, data, true)

				self:addUI(taskNav)

				if taskNav.buttons then
					for i, v in ipairs(taskNav.buttons) do
						local button = v.button
						local x = button:getPositionX() - button.width / 2

						if not minX or x < minX then
							minX = x
						end
					end
				end
			end
		end

		if minX and not self.bigScale then
			local nav__mask = UIManager.getUI("nav__mask")
			local bg = nav__mask:getComponentByTag("bg")

			bg:setOpacity(100)
			nav__mask:setPositionX(display.width)
			nav__mask:setOpacity(0)
			transition.stopTarget(nav__mask)
			transition.moveTo(nav__mask, {
				time = 0.2,
				easing = "sineOut",
				x = minX - 30
			})
			transition.fadeTo(nav__mask, {
				opacity = 255,
				time = 0.2,
				easing = "sineOut"
			})
			self:addChild(nav__mask, -100)

			self.__mask = nav__mask
		end
	end
end

function NAV_base:setButtonVisible(index, visible)
	if self.buttons[index] then
		local button = self.buttons[index].button
		local shadow = self.buttons[index].shadow

		if button then
			button:setVisible(visible)
		end

		if shadow then
			shadow:setVisible(visible)
		end
	end
end

function NAV_base:onButtonTap(x, y)
	x = x / self:getBigScale()
	y = y / self:getBigScale()

	for i, buttonObj in ipairs(self.buttons) do
		local button = buttonObj.button
		local distance = math.abs(x - (button.x + button.width / 2)) + math.abs(y - (button.y + button.height / 2))

		if buttonObj.enabled and button:isVisible() and distance < button.width / 2 then
			self:onTap(i)

			return
		end
	end
end

function NAV_base:setBuildingLvupIndex(index, isUnion)
	self.buildingLvupIndex = index
	self.isUnion = isUnion
	local ui = self.buttons[index].ui

	ui:createBarByTag("progress", COLOR.PROGRESS, true)
	self:refreshBuildingLvup()
end

function NAV_base:refreshBuildingLvup()
	if self.buildingLvupIndex then
		local index = self.buildingLvupIndex
		local building = self.npc.data.building
		local buildingData, nextBuildingData = nil

		if self.isUnion then
			buildingData, nextBuildingData = InfoUnion.getBuildingData(building)
		else
			buildingData, nextBuildingData = InfoBuilding.getBuildingData(building)
		end

		local ui = self.buttons[index].ui
		local button = self.buttons[index].button
		local shadow = self.buttons[index].shadow
		local label_max = ui:getComponentByTag("label_max")
		local label_upgrade = ui:getComponentByTag("label_upgrade")

		if nextBuildingData then
			label_max:setVisible(false)
			label_upgrade:setVisible(true)

			local matList = SheetUtil.getColumnList(buildingData, {
				"mat_id_",
				"mat_num_"
			}, {
				"base_id",
				"num"
			})
			local percent = nil

			for i, mat in ipairs(matList) do
				local itemNum = 0

				if self.isUnion then
					itemNum = InfoUnion.getResourceNum(mat.base_id)
				else
					itemNum = InfoItem.getNum(mat.base_id)
				end

				local _percent = itemNum / mat.num

				if not percent or _percent < percent then
					percent = _percent
				end
			end

			percent = percent or 0

			ui:setBarProgressByTag("progress", math.min(1, percent))

			if self.isUnion and InfoUnion.isBaseLimited(building) then
				ui:setBarColorByTag("progress", COLOR.DISABLE)
			elseif percent >= 1 then
				ui:setBarColorByTag("progress", COLOR.READY)
			else
				ui:setBarColorByTag("progress", COLOR.PROGRESS)
			end

			local level = nil

			if self.isUnion then
				level = InfoUnion.getBuildingLevel(building)
			else
				level = InfoBuilding.getBuildingLevel(building)
			end

			local label = ui:createLabelOnFlag("flag_level", level)
			local flag = ui:getFlagByTag("label_upgrade")

			if flag and flag.text then
				local str = flag.text
				local label, labelWidth = ui:createLabelOnFlag("label_upgrade", str, {
					size = 20
				})

				if label and labelWidth then
					local size = math.floor(70 / labelWidth * 20)
					local size = math.max(16, size)

					if size < 20 then
						ui:createLabelOnFlag("label_upgrade", str, {
							size = size
						})
					end
				end
			end
		else
			ui:setBarProgressByTag("progress", 1)
			ui:setBarColorByTag("progress", COLOR.HIGH)
			label_max:setVisible(true)
			label_upgrade:setVisible(false)
			ui:removeLabelOnFlag("flag_level")
		end
	end
end

function NAV_base:onTapGroupTouch(event, x, y)
	x = x / self:getBigScale()
	y = y / self:getBigScale()

	if event == "began" then
		self.tapGroupTouchIndex = nil

		for i, buttonObj in ipairs(self.buttons) do
			local button = buttonObj.button
			local distance = math.abs(x - (button.x + button.width / 2)) + math.abs(y - (button.y + button.height / 2))

			if buttonObj.enabled and distance < button.width / 2 then
				self.tapGroupTouchIndex = i

				break
			end
		end
	end

	if self.tapGroupTouchIndex and self.buttons[self.tapGroupTouchIndex] then
		local button = self.buttons[self.tapGroupTouchIndex].button

		UIManager.callTapCallbackTouch("button_click", button, event)

		if event == "ended" then
			UIManager.callTapCallback("button_click", button)
		end
	end
end

function NAV_base:onTap(index)
	DungeonScene.stopChat()

	if self.buildingLvupIndex == index then
		local building = self.npc.data.building

		FRAME_building_levelup.open(building, self:safeFunc(function ()
			self:refreshBuildingLvup()
		end), self.isUnion)
	end
end

function NAV_base:close(immediately)
	if self.additionalUI then
		for i, navUI in ipairs(self.additionalUI) do
			navUI:close(immediately)
		end
	end

	if self.closed then
		return
	end

	if self.background then
		local background = self.background
		self.background = nil

		transition.stopTarget(background)
		transition.fadeTo(background, {
			opacity = 0,
			time = 0.2,
			easing = "sineOut",
			onComplete = function ()
				background:removeSelf()
			end
		})
	end

	self.closed = true

	if self.__mask then
		local nav__mask = self.__mask

		transition.stopTarget(nav__mask)
		transition.moveTo(nav__mask, {
			time = 0.1,
			x = display.width
		})
		transition.fadeTo(nav__mask, {
			time = 0.1,
			opacity = 0
		})

		self.__mask = nil
	end

	if immediately then
		transition.fadeOut(self, {
			time = 0.1,
			easing = "sineOut",
			onComplete = function ()
				self:removeSelf()
			end
		})
	else
		for i, buttonObj in ipairs(self.buttons) do
			local button = buttonObj.button
			local buttonIndex = #self.buttons + 1 - i
			local delay = math.sqrt(buttonIndex - 1) * 0.1

			if i == 1 then
				transition.scaleTo(button, {
					time = 0.2,
					easing = "backIn",
					scale = 0,
					delay = delay,
					onComplete = function ()
						self:removeSelf()
					end
				})
			else
				transition.scaleTo(button, {
					time = 0.2,
					scale = 0,
					easing = "backIn",
					delay = delay
				})
			end

			local shadow = self:getComponentByTag("shadow_" .. buttonIndex)

			if shadow then
				transition.scaleTo(shadow, {
					time = 0.2,
					scale = 0,
					easing = "backIn",
					delay = delay
				})
			end
		end
	end
end

function NAV_base:openTouch()
	local buttonIndex = 1
	local button = self:getComponentByTag("button_" .. buttonIndex)

	while button do
		if not self.ignoreButtonMap[buttonIndex] then
			button:addTouch(function (event, x, y)
				if self.closed then
					return
				end

				self:onTapGroupTouch(event, x, y)
				self:onButtonTouch(event, x, y)
			end)
		end

		buttonIndex = buttonIndex + 1
		button = self:getComponentByTag("button_" .. buttonIndex)
	end
end

function NAV_base:onButtonTouch(event, x, y)
	x = x / self:getBigScale()
	y = y / self:getBigScale()

	if event == "began" then
		for i, buttonObj in ipairs(self.buttons) do
			local button = buttonObj.button
			local distance = math.abs(x - (button.x + button.width / 2)) + math.abs(y - (button.y + button.height / 2))

			if buttonObj.enabled and distance < button.width / 2 then
				self.touchBeganIndex = i

				self:onTouch(event, i)

				return
			end
		end
	elseif self.touchBeganIndex then
		self:onTouch(event, self.touchBeganIndex)
	end
end

function NAV_base:onTouch(event, index)
end

function NAV_base:onRead(event, msg, soundRead, soundComplete, onReadComplete, customNpc)
	customNpc = customNpc or self.npc

	if event == "began" then
		local function onComplete()
			POP_read.close()

			if not empty(soundComplete) then
				Sound.playSound(soundComplete)
			end

			if onReadComplete then
				onReadComplete()
			end
		end

		local function onUpdate(percent)
			POP_read.setPercent(percent)

			local shock = math.pow(percent, 0.8)

			MapEffect.quake(9 * shock + 1, nil, , , math.pi)
		end

		POP_read.open(msg)

		self.soundSource = nil

		if not empty(soundRead) then
			Sound.playSound(soundRead, nil, function (source)
				self.soundSource = source
			end)
		end

		customNpc:startRead(customNpc.data.read_time, onComplete, onUpdate)
	elseif event == "ended" then
		POP_read.close()

		if customNpc:stopRead() and self.soundSource then
			local soundSource = self.soundSource
			self.soundSource = nil
			local obj = {
				vol = 1
			}

			local function onUpdate()
				soundSource:setVolume(obj.vol)
			end

			local function onComplete()
				soundSource:stop()
			end

			Looper.tween(30, obj, {
				vol = 0
			}, "linear", onComplete, onUpdate)
		end
	end
end

function NAV_base.getLabelSize(labelWidth)
	local size = math.max(18, 80 / labelWidth * 24)

	return size
end

function NAV_base:setButtonName(ui, str, style)
	style = style or {}
	style.size = 24
	local label, labelWidth = ui:createLabelOnFlag("flag_name", str, style)

	if label and labelWidth then
		local size = NAV_base.getLabelSize(labelWidth)

		if size < 24 then
			style.size = size

			ui:createLabelOnFlag("flag_name", str, style)
		end
	end
end

function NAV_base:resizeButtonLabel(ui)
	local bg = ui:getComponentByTag("bg")

	if bg and bg.width == 122 and bg.label and bg.text then
		local size = math.floor(80 / bg.labelWidth * bg.labelStyle.size)
		size = math.min(24, math.max(18, size))

		if size ~= bg.labelStyle.size then
			bg:addLabel(bg.text, {
				size = size
			})
		end
	end
end

function NAV_base:onExit()
	if instance == self then
		instance = nil
	end
end

return NAV_base
