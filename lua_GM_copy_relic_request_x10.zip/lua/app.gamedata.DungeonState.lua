local DungeonState = {}
local state = {}

function DungeonState.setMapIndex()
	state.map_index = InfoDungeon.getMapIndex()
end

function DungeonState.clearMap()
	state.map_index = nil
	state.top_info = nil
	state.train_info = nil
end

function DungeonState.getMapTop(mapName)
	state.top_info = state.top_info or {}

	if not state.top_info[mapName] then
		state.top_info[mapName] = {}
	end

	state.top_info[mapName].already = state.top_info[mapName].already or {}
	state.top_info[mapName].view = state.top_info[mapName].view or {}

	return state.top_info[mapName]
end

function DungeonState.getCorpseTop()
	if not global.map then
		return {}
	end

	if not global.map.top then
		return {}
	end

	local tileMap = global.map.top.tile
	local corpse = {}
	local heros = InfoHero.getTeam()

	for i, heroInfo in ipairs(heros) do
		local hero_id = heroInfo.id
		local corpseInfo = DungeonState.getCorpse(hero_id)

		if corpseInfo and corpseInfo.map_index == InfoDungeon.getMapIndex() then
			local tile = global.map:mapToTile(corpseInfo.x, corpseInfo.y)

			if tile then
				local topIndex = tileMap[tile.tag]

				if topIndex then
					corpse[topIndex] = true
				end
			end
		end
	end

	return corpse
end

function DungeonState.setCorpse(hero_id)
	state.corpse = state.corpse or {}
	local unit = TeamManager.getHeroByID(hero_id)

	if unit then
		state.corpse[tostring(hero_id)] = {
			map_index = InfoDungeon.getMapIndex(),
			x = unit.x,
			y = unit.y,
			d = unit:getDir(),
			angle = unit.angle
		}

		notify.dispatch("refresh_top")
	end
end

function DungeonState.getCorpse(hero_id)
	if state.corpse then
		return state.corpse[tostring(hero_id)]
	end
end

function DungeonState.setTrainInfo()
	local leader = global.player
	local heros = TeamManager.getTeam()

	for i, hero in ipairs(heros) do
		if not hero.battleData.die then
			leader = hero

			break
		end
	end

	state.train_info = {
		x = leader.x,
		y = leader.y,
		angle = leader.angle,
		d = leader:getDir()
	}
end

function DungeonState.setCorpseInfo()
end

function DungeonState.init()
	state = {}
end

function DungeonState.upState(state)
	local newState = {
		map_index = state.map_index
	}

	if state.train_info then
		newState.train_info = {
			x = math.floor(state.train_info.x),
			y = math.floor(state.train_info.y),
			d = state.train_info.d
		}
	end

	if state.top_info then
		newState.top_info = {}

		for mapName, data in pairs(state.top_info) do
			local obj = {
				name = mapName
			}

			if data.already then
				obj.already = {}

				for k1, v1 in pairs(data.already) do
					table.insert(obj.already, tonumber(k1))
				end
			end

			if data.view then
				obj.view = {}

				for k1, v1 in pairs(data.view) do
					table.insert(obj.view, tonumber(k1))
				end
			end

			table.insert(newState.top_info, obj)
		end
	end

	if state.corpse then
		newState.corpse = {}

		for heroID, data in pairs(state.corpse) do
			local obj = {
				hero_id = tonumber(heroID),
				map_index = data.map_index,
				x = math.floor(data.x),
				y = math.floor(data.y),
				d = data.d
			}

			table.insert(newState.corpse, obj)
		end
	end

	return newState
end

function DungeonState.downState(state)
	local newState = {
		map_index = state.map_index,
		train_info = state.train_info
	}

	if state.top_info then
		newState.top_info = {}

		for i, v in ipairs(state.top_info) do
			newState.top_info[v.name] = {}
			local obj = newState.top_info[v.name]

			if v.already then
				obj.already = {}

				for j, v1 in ipairs(v.already) do
					obj.already[tostring(v1)] = 1
				end
			end

			if v.view then
				obj.view = {}

				for j, v1 in ipairs(v.view) do
					obj.view[tostring(v1)] = 1
				end
			end
		end
	end

	if state.corpse then
		newState.corpse = {}

		for i, v in ipairs(state.corpse) do
			local obj = {}
			newState.corpse[tostring(v.hero_id)] = obj
			obj.map_index = v.map_index
			obj.x = v.x
			obj.y = v.y
			obj.d = v.d
		end
	end

	return newState
end

function DungeonState.getState()
	DungeonState.setMapIndex()
	DungeonState.setTrainInfo()

	local newState = DungeonState.upState(state)

	return newState
end

function DungeonState.getCurrentState()
	return state
end

function DungeonState.setState(data)
	state = DungeonState.downState(data)
end

function DungeonState.flush(onSuccess, onFailure)
	if DramaManager.isBranch then
		return
	end

	if WarMachine.on then
		return
	end

	local state = DungeonState.getState()

	InfoDungeon.saveTeamState(true, state, false, onSuccess, onFailure)
end

function DungeonState.flushOnTop(isTopChanged, onSuccess, onFailure)
	if DramaManager.isBranch then
		return
	end

	if WarMachine.on then
		return
	end

	local state = DungeonState.getState()
	local data = {
		top_info = state.top_info,
		train_info = state.train_info
	}

	InfoDungeon.saveTeamState(false, data, isTopChanged, onSuccess, onFailure)
end

return DungeonState
