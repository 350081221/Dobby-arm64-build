local InfoVars = {}
local IGNORE = {
	FIRST_2_4 = 7,
	FIRST_2_3 = 6,
	FIRST_2_2 = 5,
	FIRST_2_1 = 4,
	FIRST_1_3 = 3,
	FIRST_1_2 = 2,
	FIRST_1_1 = 1
}
InfoVars.IGNORE = IGNORE
local rawData = {}
local ignoreRecord = {}

function InfoVars.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoVars.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("vars_query", callback)
end

function InfoVars.onQuery(rcvData)
	dump(rcvData, "$$$ vars_query")

	rawData = rcvData

	if empty(rcvData.ignore_record) then
		ignoreRecord = {}
	else
		local _ignoreRecord = json.decode(rcvData.ignore_record) or {}

		for k, v in pairs(_ignoreRecord) do
			ignoreRecord[tonumber(k)] = v
		end
	end

	dump(ignoreRecord, "$$$ ignoreRecord")
end

function InfoVars.set(key, value, onSuccess, onFailure)
	if rawData[key] == value then
		return
	end

	rawData[key] = value

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	local params = {
		[key] = value
	}

	Connection.request("vars_set", params, callback)
end

function InfoVars.setIgnore(index)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			ignoreRecord[index] = rcvData.time

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("vars_set_ignore", {
		index = index
	}, callback)
end

function InfoVars.get(key)
	return rawData[key]
end

function InfoVars.checkIgnore(index)
	local day = Time.getDay(ignoreRecord[index] or 0)
	local nowDay = Time.getDay()

	return nowDay < day + 7
end

local localVars = {}

function InfoVars.setLocal(key, value)
	localVars[key] = value
end

function InfoVars.getLocal(key)
	return localVars[key]
end

return InfoVars
