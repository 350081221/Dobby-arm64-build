local UnitEffect = class("UnitEffect")

function UnitEffect:ctor(unit)
	self.unit = unit
	self.missleStack = {}
	self.lightningStack = {}
end

local function parseAttr(attrStr)
	local obj = {}

	if not empty(attrStr) then
		local attrArr = string.split(attrStr, ",")

		for i, attr in ipairs(attrArr) do
			local arr = string.split(attr, "=")
			local key = string.trim(arr[1])

			if #arr == 2 then
				local value = string.trim(arr[2])
				value = tonumber(value) or value
				obj[key] = value
			else
				obj[key] = true
			end
		end
	end

	return obj
end

function UnitEffect.getMissleTime(effectStr, caster, target)
	if empty(effectStr) then
		return 0
	end

	local effectStackArr = string.split(effectStr, ";")

	for i, effectStackStr in ipairs(effectStackArr) do
		effectStackStr = StringUtil.trim(effectStackStr)
		local attrArr = string.split(effectStackStr, "#")
		local effectAttrStr = ""
		local effectDescStr = ""

		if #attrArr == 1 then
			effectDescStr = attrArr[1]
		else
			effectAttrStr = attrArr[1]
			effectDescStr = attrArr[2]
		end

		effectAttrStr = StringUtil.trim(effectAttrStr)
		effectDescStr = StringUtil.trim(effectDescStr)
		local attrs = parseAttr(effectAttrStr)
		local effectArr = string.split(effectDescStr, ":")
		local code = effectArr[1]
		local params = string.split(effectArr[2] or "", ",")

		if code == "missle" then
			local speed = tonumber(params[2])
			local distance = math.sqrt(math.pow(caster.x - target.x, 2) + math.pow(caster.y - target.y, 2))

			return math.floor(distance / speed)
		end
	end

	return 0
end

function UnitEffect:castEffect(effectStr, target, callback, angle, caster)
	if global.noEffect and not callback then
		return
	end

	if empty(effectStr) then
		return
	end

	angle = angle or 0
	local effectStackArr = string.split(effectStr, ";")

	for i, effectStackStr in ipairs(effectStackArr) do
		effectStackStr = StringUtil.trim(effectStackStr)
		local attrArr = string.split(effectStackStr, "#")
		local effectAttrStr = ""
		local effectDescStr = ""

		if #attrArr == 1 then
			effectDescStr = attrArr[1]
		else
			effectAttrStr = attrArr[1]
			effectDescStr = attrArr[2]
		end

		effectAttrStr = StringUtil.trim(effectAttrStr)
		effectDescStr = StringUtil.trim(effectDescStr)
		local attrs = parseAttr(effectAttrStr)
		local effectArr = string.split(effectDescStr, ":")
		local code = effectArr[1]
		local params = string.split(effectArr[2] or "", ",")

		local function castEffect()
			if code == "missle" then
				self:missle(callback, caster, target, params[1], tonumber(params[2]), tonumber(params[3]), tonumber(params[4]), tonumber(params[5]), tonumber(params[6]), tonumber(params[7]))
			elseif code == "float" then
				self:float(tonumber(params[1]), tonumber(params[2]), tonumber(params[3]), tonumber(params[4]), tonumber(params[5]))
			elseif code == "floatStop" then
				self:floatStop()
			elseif code == "fall" then
				self:fall(tonumber(params[1]), tonumber(params[2]), params[3])
			elseif code == "z" or code == "zmove" then
				self:zmove(tonumber(params[1]), tonumber(params[2]), params[3])
			elseif code == "updown" then
				self:updown(tonumber(params[1]), tonumber(params[2]))
			elseif code == "arc" then
				local arcEffect = ArcEffect.new(self.unit.map, target, angle, effectArr[2])

				arcEffect:start()
			elseif code == "meteor" then
				local meteorEffect = MeteorEffect.new(self.unit.map, target, params[1], tonumber(params[2]), tonumber(params[3]), tonumber(params[4]))

				meteorEffect:start()
			elseif code == "effect" then
				if target.addEffect ~= nil then
					local effect = target:addEffect(params[1])
				else
					local effect = self:addEffect(params[1])
				end
			else
				if code == "effect_pos" then
					local effect = Effect.new()

					effect:load(params[1])
					effect:display(self.unit.map, target.x, target.y)
					effect:setAction(effect.action, 1, function ()
						effect:removeSelf()
					end)

					return
				end

				if code == "hitstop" then
					-- Nothing
				elseif code == "sfx" then
					Sound.playSound(params[math.random(1, #params)])
				elseif code == "quake" then
					MapEffect.quake(tonumber(params[1]), tonumber(params[2]), tonumber(params[3]), tonumber(params[4]))
				elseif code == "bullet" then
					-- Nothing
				elseif code == "freeze" then
					MapEffect.freezeTime("UnitEffect_" .. self.unit.id, tonumber(params[1]))
				elseif code == "shock" then
					MapEffect.shock("UnitEffect_" .. self.unit.id, target, tonumber(params[1]), tonumber(params[2]), tonumber(params[3]), tonumber(params[4]))
				elseif code == "fadeto" then
					self:fadeTo(tonumber(params[1]), tonumber(params[2]), params[3])
				elseif code == "darkto" then
					self:darkTo(tonumber(params[1]), tonumber(params[2]), params[3])
				elseif code == "whirlwind" then
					self:whirlwind(params[1], tonumber(params[2]), tonumber(params[3]), tonumber(params[4]), tonumber(params[5]))
				elseif code == "afterimage" then
					self:afterimage(tonumber(params[1]), tonumber(params[2]), tonumber(params[3]))
				elseif code == "stopAfterimage" then
					self:stopAfterimage()
				elseif code == "backward" then
					self:setBackward(true)
				elseif code == "stopBackward" then
					self:setBackward(false)
				elseif code == "countdown" then
					self:countdown(tonumber(params[1]))
				elseif code == "stopCountdown" then
					self:stopCountdown()
				elseif code == "muscle" then
					self:muscle(tonumber(params[1]), tonumber(params[2]))
				elseif code == "action" then
					if not empty(tonumber(params[2])) then
						self.unit:setAction(params[1], tonumber(params[2]), function ()
							self.unit:setAction(params[3] or "idle")
						end)
					else
						self.unit:setAction(params[1])
					end
				elseif code == "partaction" then
					self:partAction(params[1], tonumber(params[2]), tonumber(params[3]), tonumber(params[4]))
				elseif code == "loopaction" then
					self:loopAction(params[1], tonumber(params[2]), tonumber(params[3]), tonumber(params[4]))
				elseif code == "stopLoopaction" then
					self:loopActionStop()
				elseif code == "freezeaction" then
					self:freezeAction(params[1], tonumber(params[2]), tonumber(params[3]), tonumber(params[4]))
				elseif code == "stopFreezeaction" then
					self:freezeActionStop()
				elseif code == "effect_scale" then
					self:effectScale(params[1], tonumber(params[2]), tonumber(params[3]), params[4])
				elseif code == "shake" then
					self:shake(tonumber(params[1]), tonumber(params[2]))
				elseif code == "stopShake" then
					self:stopShake()
				elseif code == "whiteout" then
					POP_mask.open(60, 255, 0, "255,255,255")
				elseif code == "lightning" then
					self:lightning(callback, caster, target, params[1], params[2], tonumber(params[3]), tonumber(params[4]), tonumber(params[5]), tonumber(params[6]))
				elseif code == "scale" then
					self:scale(tonumber(params[1]), tonumber(params[2]), params[3])
				elseif code == "say" then
					local sayStr = tostring(params[1])

					self.unit:say(Localization.getSrcText(sayStr), tonumber(params[2]))
				elseif code == "offset" then
					self:offset(tonumber(params[1]), tonumber(params[2]), tonumber(params[3]), params[4])
				elseif code ~= "" then
					Log.warn("UnitEffect not found", code, effectStr)
				end
			end
		end

		if empty(attrs.delay) then
			castEffect()
		else
			MapFrameManager.setTimeout(castEffect, attrs.delay, self.unit)
		end
	end
end

function UnitEffect:scale(_scale, time, easing)
	if time and time > 0 then
		local tweenObj = {
			scale = self.unit.scaleBeforeMap
		}

		local function onUpdate()
			if not tolua.isnull(self.unit) then
				self.unit:setScale(tweenObj.scale)
			end
		end

		self.effectScaleTween = MapFrameManager.tween(time, tweenObj, {
			scale = _scale
		}, easing or "linear", onUpdate, onUpdate)

		return
	end

	self.unit:setScale(_scale)
end

function UnitEffect:lightning(callback, caster, target, solidAnim, shadeAnim, num, time, shakeTime, sectionLen)
	local first = #self.lightningStack == 0

	for i = 1, num do
		local obj = {}

		if i == 1 then
			obj.callback = callback
		end

		obj.caster = caster
		obj.target = target
		obj.solidAnim = solidAnim
		obj.shadeAnim = shadeAnim
		obj.time = time
		obj.sectionLen = sectionLen or 100
		obj.shakeTime = shakeTime or time
		obj.shakeCount = 0

		if not tolua.isnull(target) then
			Shader.subtract(target, 0.5, true)
			table.insert(self.lightningStack, obj)
		end
	end

	if first then
		self.lightningFunc = WarMachine.startLoop(self, function (...)
			self:lightningLoop(...)
		end)
	end
end

function UnitEffect:lightningLoop(frame, passed, sharp)
	local index = 1
	local loop = #self.lightningStack

	while index <= loop do
		local obj = self.lightningStack[index]
		obj.time = obj.time - passed
		local finished = obj.time <= 0

		if finished then
			table.remove(self.lightningStack, index)

			loop = loop - 1

			self:clearLightning(obj)

			if obj.callback ~= nil then
				obj.callback()
			end
		elseif self:drawLightning(obj, passed) then
			index = index + 1
		else
			table.remove(self.lightningStack, index)

			loop = loop - 1

			self:clearLightning(obj)
		end
	end

	if #self.lightningStack == 0 then
		MapFrameManager.stopLoop(self, self.lightningFunc)
	end
end

function UnitEffect:clearLightning(obj)
	if obj.target then
		Shader.recover(obj.target)
	end

	if obj.animations then
		for i, anima in ipairs(obj.animations) do
			anima.line:removeSelf()
			anima.shade:removeSelf()
		end
	end
end

function UnitEffect:drawLightning(obj, passed)
	local caster = obj.caster
	local target = obj.target

	if not target.x or not caster.x then
		return false
	end

	local angle = math.atan2(target.y - caster.y, target.x - caster.x)
	local distance = math.sqrt(math.pow(caster.x - target.x, 2) + math.pow(caster.y - target.y, 2))

	if not obj.sectionArr or obj.shakeTime <= obj.shakeCount then
		if obj.animations then
			for i, anima in ipairs(obj.animations) do
				anima.line:removeSelf()
				anima.shade:removeSelf()
			end
		end

		obj.shakeCount = 0
		local sectionLen = obj.sectionLen
		local step = math.max(1, math.ceil(distance / sectionLen))
		local sectionWeightArr = {}

		for i = 1, step do
			table.insert(sectionWeightArr, math.random(50, 100))
		end

		local sectionArr = MathUtil.integerDivision(distance, sectionWeightArr)
		obj.sectionArr = sectionArr
		local animations = {}
		local offsets = {}

		for i, section in ipairs(obj.sectionArr) do
			local shade = Animation.new()

			shade:setBlendFunc(srcBlend or gl.DST_COLOR, dstBlend or gl.ONE)
			shade:load(obj.shadeAnim)
			shade:setLooper(MapFrameManager.core)

			local line = Animation.new()

			line:setBlendFunc(srcBlend or gl.DST_COLOR, dstBlend or gl.ONE)
			line:load(obj.solidAnim)
			line:setLooper(MapFrameManager.core)
			self.unit.map.baseLayer:addChild(shade)
			self.unit.map.baseLayer:addChild(line)
			table.insert(animations, {
				shade = shade,
				line = line
			})
			table.insert(offsets, {
				len = (math.random() * 0.2 + 0.3) * section,
				angle = math.random() * math.pi * 2
			})
		end

		local shade = Animation.new()

		shade:setBlendFunc(srcBlend or gl.DST_COLOR, dstBlend or gl.ONE)
		shade:load(obj.shadeAnim .. "_ball")
		shade:setLooper(MapFrameManager.core)

		local line = Animation.new()

		line:setBlendFunc(srcBlend or gl.DST_COLOR, dstBlend or gl.ONE)
		line:load(obj.solidAnim .. "_ball")
		line:setLooper(MapFrameManager.core)
		self.unit.map.baseLayer:addChild(shade)
		self.unit.map.baseLayer:addChild(line)
		table.insert(animations, {
			shade = shade,
			line = line
		})

		obj.offsets = offsets
		obj.animations = animations
	end

	obj.shakeCount = obj.shakeCount + passed
	local sectionAdd = 0
	local startHeight = caster.height / 5 * 3
	local endHeight = target.height / 5 * 3
	local prePt = cc.p(caster.x, caster.y)
	local preHeight = startHeight

	for i, section in ipairs(obj.sectionArr) do
		local offset = obj.offsets[i]
		offset.len = offset.len + (math.random() - 0.5) * section * 0.1
		offset.angle = offset.angle + (math.random() - 0.5) * math.pi / 5
		sectionAdd = sectionAdd + section
		local percent = sectionAdd / distance
		local percent2 = sectionAdd / distance
		local x = math.cos(angle) * sectionAdd + caster.x
		local y = math.sin(angle) * sectionAdd + caster.y

		if i < #obj.sectionArr then
			x = x + math.cos(offset.angle) * offset.len
			y = y + math.sin(offset.angle) * offset.len
		end

		local pt = cc.p(x, y)
		local height = (endHeight - startHeight) * percent + startHeight
		local drawX1, drawY1 = self.unit.map:mapToDraw(prePt.x, prePt.y)
		local drawX2, drawY2 = self.unit.map:mapToDraw(pt.x, pt.y)
		local drawCenterY = (drawY1 + drawY2) / 2

		if i == #obj.sectionArr then
			local centerX = drawX2
			local centerY = drawY2 - height
			local drawCenterY = drawY2
			local anima = obj.animations[i + 1]

			anima.line:setPosition(centerX, -centerY)
			anima.line:setLocalZOrder(drawCenterY)
			anima.shade:setPosition(centerX, -centerY)
			anima.shade:setLocalZOrder(drawCenterY - 1000)
		end

		drawY1 = drawY1 - preHeight
		drawY2 = drawY2 - height
		local centerX = (drawX1 + drawX2) / 2
		local centerY = (drawY1 + drawY2) / 2
		local dis = math.sqrt(math.pow(drawY2 - drawY1, 2) + math.pow(drawX2 - drawX1, 2))
		local ang = math.atan2(drawY2 - drawY1, drawX2 - drawX1)
		local anima = obj.animations[i]

		anima.line:setInnerScale(1, dis / 100)
		anima.line:setPosition(centerX, -centerY)
		anima.line:setRotation(ang * 180 / math.pi + 90)
		anima.line:setLocalZOrder(drawCenterY)
		anima.shade:setInnerScale(1, dis / 100)
		anima.shade:setPosition(centerX, -centerY)
		anima.shade:setRotation(ang * 180 / math.pi + 90)
		anima.shade:setLocalZOrder(drawCenterY - 1000)

		prePt = pt
		preHeight = height
	end

	return true
end

function UnitEffect:shake(range, lastingTime, onComplete)
	self.shakeObj = {
		range = range or 10
	}

	MapFrameManager.startLoop(self, self.shakeLoop)

	if lastingTime and lastingTime > 0 then
		MapFrameManager.setTimeout(function ()
			self:stopShake()

			if onComplete then
				onComplete()
			end
		end, lastingTime, self.unit)
	end
end

function UnitEffect:setShakeRange(range)
	if self.shakeObj then
		self.shakeObj.range = range
	end
end

function UnitEffect:stopShake()
	self.shakeObj = nil

	MapFrameManager.stopLoop(self, self.shakeLoop)

	self.unit.effectOffset = nil

	self.unit:setBmpX()
	self.unit:setBmpY()
end

function UnitEffect:shakeLoop()
	local range = self.shakeObj.range
	local distance = math.random() * range
	local angle = math.random() * math.pi * 2
	self.unit.effectOffset = cc.p(math.cos(angle) * distance, math.sin(angle) * distance)

	self.unit:setBmpX()
	self.unit:setBmpY()
end

function UnitEffect:addEffect(effectModel, target)
	target = target or self.unit
	local effect = Effect.new()

	effect:load(effectModel)
	effect:display(self.unit.map, target.x, target.y)
	effect:setOverFunc(function ()
		effect:removeSelf()
	end)

	return effect
end

function UnitEffect:offset(x, y, time, easing)
	local tweenObj = nil

	if self.unit.effectOffset then
		tweenObj = clone(self.unit.effectOffset)
	else
		tweenObj = {}
	end

	tweenObj.x = tweenObj.x or 0
	tweenObj.y = tweenObj.y or 0

	local function onUpdate()
		self.unit.effectOffset = tweenObj
	end

	self.effectScaleTween = MapFrameManager.tween(time, tweenObj, {
		x = x,
		y = y
	}, easing or "linear", nil, onUpdate)
end

function UnitEffect:effectScale(effectName, startScale, endScale, easing)
	local effect = self.unit:addEffect(effectName)
	local tweenObj = {
		scale = startScale
	}

	local function onUpdate()
		if not tolua.isnull(effect) then
			effect:setScale(tweenObj.scale)
		end
	end

	local time = effect:getActionTotalFrameTime("idle")
	self.effectScaleTween = MapFrameManager.tween(time, tweenObj, {
		scale = endScale
	}, easing or "linear", nil, onUpdate)
end

function UnitEffect:loopAction(action, startFrame, endFrame, lastingTime)
	self.loopActionObject = {
		action = self.unit.mappedAction[action] or action,
		frame = startFrame,
		startFrame = startFrame,
		endFrame = endFrame or startFrame,
		playCount = self.unit:getPlaySkip(action),
		angle = self.unit.angle
	}

	if lastingTime then
		self.loopActionObject.overTime = MapFrameManager.getFrame() + lastingTime
	end

	MapFrameManager.startLoop(self, self.loopActionLoop)
end

function UnitEffect:loopActionStop()
	self.loopActionObject = nil

	MapFrameManager.stopLoop(self, self.loopActionLoop)
end

function UnitEffect:loopActionLoop(frame, passed, sharp)
	local action = self.loopActionObject.action
	local startFrame = self.loopActionObject.startFrame
	local endFrame = self.loopActionObject.endFrame
	local overTime = self.loopActionObject.overTime

	if startFrame ~= endFrame then
		if self.loopActionObject.playCount <= 0 then
			self.loopActionObject.frame = self.loopActionObject.frame + 1

			if endFrame < self.loopActionObject.frame then
				self.loopActionObject.frame = startFrame
			end

			self.loopActionObject.playCount = self.unit:getPlaySkip(action)
		else
			self.loopActionObject.playCount = self.loopActionObject.playCount - 1
		end
	end

	local frame = self.loopActionObject.frame
	self.unit.angle = self.loopActionObject.angle

	self.unit:setFrame(action, self.unit:getDirection(), frame)

	if overTime and overTime <= MapFrameManager.getFrame() then
		self:loopActionStop()
	end
end

function UnitEffect:freezeAction(action, startFrame, endFrame, lastingTime)
	self.freezeActionObject = {
		action = self.unit.mappedAction[action] or action,
		frame = startFrame,
		startFrame = startFrame,
		endFrame = endFrame or startFrame,
		playCount = self.unit:getPlaySkip(action),
		angle = self.unit.angle
	}

	if lastingTime then
		self.freezeActionObject.overTime = MapFrameManager.getFrame() + lastingTime
	end

	MapFrameManager.startLoop(self, self.freezeActionLoop)
end

function UnitEffect:freezeActionStop()
	self.freezeActionObject = nil

	MapFrameManager.stopLoop(self, self.freezeActionLoop)
end

function UnitEffect:freezeActionLoop(frame, passed, sharp)
	local action = self.freezeActionObject.action
	local startFrame = self.freezeActionObject.startFrame
	local endFrame = self.freezeActionObject.endFrame
	local overTime = self.freezeActionObject.overTime

	if not self.unit.getDirection then
		self:freezeActionStop()

		return
	end

	if startFrame ~= endFrame then
		if self.freezeActionObject.playCount <= 0 then
			if self.freezeActionObject.frame < endFrame then
				self.freezeActionObject.frame = self.freezeActionObject.frame + 1
			end

			self.freezeActionObject.playCount = self.unit:getPlaySkip(action)
		else
			self.freezeActionObject.playCount = self.freezeActionObject.playCount - 1
		end
	end

	local frame = self.freezeActionObject.frame
	self.unit.angle = self.freezeActionObject.angle

	self.unit:setFrame(action, self.unit:getDirection(), frame)

	if overTime and overTime <= MapFrameManager.getFrame() then
		self:freezeActionStop()
	end
end

function UnitEffect:muscle(scale, opacity)
	local cloneUnit = self.unit:clone()
	cloneUnit.isBlock = false
	self.muscleCloneUnit = cloneUnit

	cloneUnit:setScale(cloneUnit.scale * (scale or 1.5))

	local targetOpacity = opacity or 150
	local tweenObj = {
		opacity = 0
	}
	local actionTime = cloneUnit:getActionTotalFrameTime(cloneUnit.action)

	local function onUpdate()
		cloneUnit:setOpacity(tweenObj.opacity)
	end

	local function onComplete()
		cloneUnit:removeSelf()

		self.muscleTween = nil
	end

	self.muscleTween = MapFrameManager.tween(actionTime, tweenObj, {
		opacity = targetOpacity
	}, "outCubic", onComplete, onUpdate)
end

function UnitEffect:countdown(time)
	self.countdownObj = {
		endTime = MapFrameManager.getFrame() + time
	}

	MapFrameManager.startLoop(self, self.countdownLoop)
end

function UnitEffect:stopCountdown()
	self.countdownObj = nil

	MapFrameManager.stopLoop(self, self.countdownLoop)
end

function UnitEffect:countdownLoop()
	local leftSec = math.floor((self.countdownObj.endTime - MapFrameManager.getFrame()) / 60) + 1

	if leftSec ~= self.countdownObj.leftSec then
		local fontText = tostring(leftSec)
		local fontFamily = "font_dmg_s_"
		local fontZ = 100
		local dmgFont = MapFont.new(fontFamily, fontText, 1)
		local drawX, drawY = self.unit.map:mapToDraw(self.unit:getCenter())

		dmgFont:setScale(3)
		dmgFont:setZOrder(fontZ)
		dmgFont:display(self.unit.map.hudHighLayer, drawX, -drawY + self.unit:getTotalHeight() + 30)
		dmgFont:jumpIn(60)

		self.countdownObj.leftSec = leftSec
	end

	if leftSec <= 1 then
		self:stopCountdown()
	end
end

function UnitEffect:setBackward(tof)
	if not tof then
		self.unit.angle = self.unit.angle + math.pi
	end

	self.unit:setDirectionBackward(tof)
end

local afterimageObj = nil

function UnitEffect:afterimage(interval, opacity, lastingTime)
	afterimageObj = {
		interval = interval or 3,
		count = interval or 3,
		opacity = opacity or 150,
		lastingTime = lastingTime or 30
	}

	MapFrameManager.startLoop(self, self.afterimageLoop)
end

function UnitEffect:stopAfterimage()
	MapFrameManager.stopLoop(self, self.afterimageLoop)

	afterimageObj = nil
end

function UnitEffect:afterimageLoop(frame, passed, sharp)
	if afterimageObj then
		if afterimageObj.count <= 0 then
			local snapshoot = self.unit:getSnapshot()
			local container = self.unit:getParent()
			local zorder = self.unit:getLocalZOrder()
			local x, y = self.unit:getPosition()

			snapshoot:setPosition(x, y)
			container:addChild(snapshoot, zorder)
			snapshoot:setOpacity(afterimageObj.opacity)

			local tweenObj = {
				opacity = afterimageObj.opacity
			}

			MapFrameManager.tween(afterimageObj.lastingTime, tweenObj, {
				opacity = 0
			}, "outQuad", function ()
				snapshoot:removeSelf()
			end, function ()
				snapshoot:setOpacity(tweenObj.opacity)
			end)

			afterimageObj.count = afterimageObj.interval + afterimageObj.count

			return
		end

		afterimageObj.count = afterimageObj.count - passed
	end
end

function UnitEffect:missle(callback, caster, target, modelName, speed, topZ, flow, finalZ, startZ, customTopZ)
	if target == nil then
		return
	end

	caster = caster or self.unit
	speed = speed or 20
	topZ = topZ or 0
	flow = flow or 0
	finalZ = finalZ or 0
	startZ = startZ or (not caster.getZ or caster:getZ()) and caster.z
	topZ = math.max(topZ, startZ)

	if customTopZ then
		topZ = customTopZ
	end

	local x1, y1, x2, y2 = caster:getCenter(target)

	if not x2 or not y2 then
		return
	end

	local angle = GeomPlane.angle(x1, y1, x2, y2)
	local range = GeomPlane.distance(x1, y1, x2, y2)
	local obj = {
		target = target,
		callback = callback,
		x = x1 + math.cos(angle) * caster.width / 2,
		y = y1 + math.sin(angle) * caster.width / 2,
		z = startZ,
		step = math.max(1, math.floor(range / speed))
	}

	if not global.noEffect then
		local clip = Effect.new()

		clip:load(modelName)
		clip:display(self.unit.map, obj.x, obj.y)

		obj.clip = clip

		if flow > 0 and obj.step > 1 then
			local startardRange = 150
			local flowRadius = flow * math.pow(range / startardRange, 0.2) * math.pow(math.random(), 0.4)
			local flowAcc = flowRadius * 2 / math.pow(obj.step / 2, 2)
			obj.flowRadial = {
				acc = -flowAcc,
				speed = flowAcc * obj.step / 2,
				dis = 0,
				angle = math.pi * 2 * math.random()
			}
			local flowRadius = flow * 5 * math.pow(range / startardRange, 0.2) * math.pow(math.random(), 0.4)
			local flowAcc = flowRadius * 2 / math.pow(obj.step / 2, 2)
			obj.flowAxial = {
				acc = -flowAcc,
				speed = flowAcc * obj.step / 2,
				dis = 0
			}
		end

		if topZ > 0 and obj.step > 1 then
			local startardRange = 300
			topZ = topZ * math.pow(range / startardRange, 0.2) / 5
			obj.gravity = topZ / (obj.step / 2)
			obj.zSpeed = (startZ - finalZ - math.pow(obj.step, 2) * obj.gravity / 2) / obj.step
			local nextX = 1 / obj.step * range * math.cos(angle)
			local nextY = 1 / obj.step * range * math.sin(angle)

			if obj.clip.rotate then
				obj.clip:setRotateByPosition(self.unit.map.topType == Map.TOP_90, nextX, nextY, obj.zSpeed)
			else
				clip.angle = math.atan2(nextY, nextX)
			end
		else
			clip.angle = angle
		end
	end

	table.insert(self.missleStack, obj)

	if #self.missleStack == 1 then
		self.missleFunc = WarMachine.startLoop(self, function (...)
			self:missleLoop(...)
		end)
	end

	self.currentMissle = obj
end

function UnitEffect:getCurrentMissle()
	return self.currentMissle
end

function UnitEffect:missleStop(_obj)
	local callbackArr = {}

	for i, obj in ipairs(self.missleStack) do
		if _obj == obj then
			if obj.clip then
				if obj.clip.clipType == CLIP_TYPE.SPINE then
					obj.clip:setRotate(0)
				end

				if obj.clip:hasAction("die") then
					obj.clip:clearLight()
					obj.clip:setAction("die", 1, function (clip)
						clip:removeSelf()
					end)
				else
					obj.clip:removeSelf()
				end
			end

			table.remove(self.missleStack, i)

			if obj.callback ~= nil then
				table.insert(callbackArr, obj.callback)
			end

			break
		end
	end

	if #self.missleStack == 0 then
		MapFrameManager.stopLoop(self, self.missleFunc)
	end

	for i, callback in ipairs(callbackArr) do
		callback()
	end
end

function UnitEffect:missleLoop(frame, passed, sharp)
	local index = 1
	local loop = #self.missleStack

	if not self.unit.getCenter then
		for i, obj in ipairs(self.missleStack) do
			if obj.clip then
				obj.clip:removeSelf()
			end
		end

		self.missleStack = {}

		MapFrameManager.stopLoop(self, self.missleFunc)

		return
	end

	local callbackArr = {}

	while index <= loop do
		local obj = self.missleStack[index]
		obj.step = obj.step - passed

		if obj.clip then
			local x1, y1, x2, y2 = self.unit:getCenter(obj.target)
			local angle = GeomPlane.angle(obj.x, obj.y, x2, y2)
			local range = GeomPlane.distance(obj.x, obj.y, x2, y2)
			local preX = obj.clip.x
			local preY = obj.clip.y
			local preZ = obj.clip.z

			if obj.step >= 1 then
				obj.x = obj.x + passed / obj.step * range * math.cos(angle)
				obj.y = obj.y + passed / obj.step * range * math.sin(angle)
			else
				obj.x = obj.target.x
				obj.y = obj.target.y

				if obj.target.id ~= nil then
					local targetAngle = GeomPlane.angle(preX, preY, x1, y1)
					obj.x = obj.x + math.cos(targetAngle) * obj.target.width / 2
					obj.y = obj.y + math.sin(targetAngle) * obj.target.width / 2
				end
			end

			if obj.gravity ~= nil then
				obj.z = obj.z - obj.zSpeed * passed
				obj.zSpeed = obj.zSpeed + obj.gravity * passed
			end

			local finished = obj.step < 1 or obj.target.id ~= nil and range < obj.target.width / 2 and obj.z < obj.target.height
			local clipPosition = clone(obj)

			if not finished then
				if obj.flowRadial then
					obj.flowRadial.speed = obj.flowRadial.speed + obj.flowRadial.acc * passed
					obj.flowRadial.dis = math.max(0, obj.flowRadial.dis + obj.flowRadial.speed * passed)
					clipPosition.z = clipPosition.z + math.cos(obj.flowRadial.angle) * obj.flowRadial.dis
					local disPlane = math.sin(obj.flowRadial.angle) * obj.flowRadial.dis
					local anglePlane = angle + math.pi / 2
					clipPosition.x = clipPosition.x + math.cos(anglePlane) * disPlane
					clipPosition.y = clipPosition.y + math.sin(anglePlane) * disPlane
				end

				if obj.flowAxial then
					obj.flowAxial.speed = obj.flowAxial.speed + obj.flowAxial.acc * passed
					obj.flowAxial.dis = math.max(0, obj.flowAxial.dis + obj.flowAxial.speed * passed)
					clipPosition.x = clipPosition.x + math.cos(angle + math.pi) * obj.flowAxial.dis
					clipPosition.y = clipPosition.y + math.sin(angle + math.pi) * obj.flowAxial.dis
				end
			end

			obj.clip.z = clipPosition.z

			obj.clip:setBmpY()
			obj.clip:draw(clipPosition.x, clipPosition.y, true)
			obj.clip:retile()

			if not finished then
				if obj.clip.rotate then
					obj.clip:setRotateByPosition(self.unit.map.topType == Map.TOP_90, obj.clip.x, obj.clip.y, obj.clip.z, preX, preY, preZ)
				else
					obj.clip.angle = angle
				end
			else
				if obj.clip.clipType == CLIP_TYPE.SPINE then
					obj.clip:setRotate(0)
				end

				if obj.clip:hasAction("die") then
					obj.clip:clearLight()
					obj.clip:setAction("die", 1, function (clip)
						clip:removeSelf()
					end)
				else
					obj.clip:removeSelf()
				end

				obj.clip = nil
			end
		end

		if obj.step < 1 then
			table.remove(self.missleStack, index)

			loop = loop - 1

			if obj.callback ~= nil then
				table.insert(callbackArr, obj.callback)
			end
		else
			index = index + 1
		end
	end

	if #self.missleStack == 0 then
		MapFrameManager.stopLoop(self, self.missleFunc)
	end

	for i, callback in ipairs(callbackArr) do
		callback()
	end
end

function UnitEffect:fadeTo(time, to, easing, onComplete)
	self:fadeStop()

	if time <= 0 then
		self.unit:setOpacity(to)

		if onComplete then
			onComplete()
		end

		return
	end

	local tweenObj = {
		opacity = self.unit.opacity or 255
	}

	local function onTweenUpdate()
		if self.unit then
			self.unit:setOpacity(tweenObj.opacity)

			if self.unit.effects then
				for effectName, obj in pairs(self.unit.effects) do
					if obj.clip then
						obj.clip:setOpacity(tweenObj.opacity)
					end
				end
			end

			if self.unit.last_effects then
				for effectName, obj in pairs(self.unit.last_effects) do
					if obj.clip then
						obj.clip:setOpacity(tweenObj.opacity)
					end
				end
			end
		end
	end

	local function onTweenComplete()
		self:fadeStop()

		if onComplete then
			onComplete()
		end
	end

	onTweenUpdate()

	self.fadeID = MapFrameManager.tween(time, tweenObj, {
		opacity = to
	}, easing or "linear", onTweenComplete, onTweenUpdate)
end

function UnitEffect:fadeStop()
	if self.fadeID then
		MapFrameManager.stopTween(self.fadeID)

		self.fadeID = nil
	end
end

function UnitEffect:darkTo(time, to, easing)
	self:darkStop()

	local tweenObj = {
		darkness = self.unit.darkness
	}

	local function onTweenUpdate()
		if self.unit then
			local color = cc.c3b(tweenObj.darkness, tweenObj.darkness, tweenObj.darkness)

			self.unit:setColor(color)

			if self.unit.effects then
				for effectName, obj in pairs(self.unit.effects) do
					if obj.clip then
						obj.clip:setColor(color)
					end
				end
			end

			if self.unit.last_effects then
				for effectName, obj in pairs(self.unit.last_effects) do
					if obj.clip then
						obj.clip:setColor(color)
					end
				end
			end
		end
	end

	local function onTweenComplete()
		self:darkStop()
	end

	onTweenUpdate()

	self.unit.fixedDarkness = true
	self.darkID = MapFrameManager.tween(time, tweenObj, {
		darkness = to
	}, easing or "linear", onTweenComplete, onTweenUpdate)
end

function UnitEffect:darkStop()
	self.unit.fixedDarkness = false

	self.unit:refreshVisible()

	if self.darkID then
		MapFrameManager.stopTween(self.darkID)

		self.darkID = nil
	end
end

function UnitEffect:move(time, xyz, easing, onComplete)
	if time > 0 then
		self:tween(time, self.unit, xyz, easing, onComplete)
	else
		self.unit:draw(xyz.x, xyz.y, true)

		self.unit.z = xyz.z

		self.unit:setBmpY()

		if self.unit.setAvatarZ then
			self.unit:setAvatarZ()
		end

		if self.unit.shadow then
			self.unit:refreshShadowZ()
		end
	end
end

function UnitEffect:tween(time, xyzFrom, xyzTo, easing, onComplete)
	self:tweenStop()

	self.tweening = true
	local tweenObj = {
		x = xyzFrom.x,
		y = xyzFrom.y,
		z = xyzFrom.z
	}

	local function onTweenUpdate()
		if self.unit then
			self.unit:draw(tweenObj.x, tweenObj.y, true)

			self.unit.z = tweenObj.z

			self.unit:setBmpY()

			if self.unit.setAvatarZ then
				self.unit:setAvatarZ()
			end

			if self.unit.shadow then
				self.unit:refreshShadowZ()
			end
		end
	end

	local function onTweenComplete()
		self:tweenStop()

		if onComplete then
			onComplete()
		end
	end

	onTweenUpdate()

	if time > 0 then
		self.tweenID = MapFrameManager.tween(time, tweenObj, {
			x = xyzTo.x,
			y = xyzTo.y,
			z = xyzTo.z
		}, easing or "linear", onTweenComplete, onTweenUpdate)
	else
		onTweenComplete()
	end
end

function UnitEffect:tweenStop()
	self.tweening = false

	if self.tweenID then
		MapFrameManager.stopTween(self.tweenID)

		self.tweenID = nil
	end
end

function UnitEffect:fall(time, height, easing, onComplete, onUpdate)
	time = time or 100
	height = height or 1000

	self:zTween(time, height, 0, easing or "inQuad", onComplete, onUpdate)
end

function UnitEffect:updown(time, height)
	time = time or 20
	height = height or 40

	local function onComplete()
		self:zTween(time / 2, height, 0, "inQuad")
	end

	self:zTween(time / 2, 0, height, "outQuad", onComplete)
end

function UnitEffect:zmove(time, z, easing, onComplete)
	if time > 0 then
		self:zTween(time, self.unit.z, z, easing, onComplete)
	else
		self.unit.z = z

		self.unit:setBmpY()

		if self.unit.setAvatarZ then
			self.unit:setAvatarZ()
		end

		if self.unit.shadow then
			self.unit:refreshShadowZ()
		end
	end
end

function UnitEffect:zTween(time, from, to, easing, onComplete, onUpdate)
	self:zTweenStop()

	self.zTweening = true
	local tweenObj = {
		z = from
	}

	local function onTweenUpdate()
		if self.unit then
			self.unit.z = tweenObj.z

			self.unit:setBmpY()

			if self.unit.setAvatarZ then
				self.unit:setAvatarZ()
			end

			if self.unit.shadow then
				self.unit:refreshShadowZ()
			end
		end

		if onUpdate then
			onUpdate()
		end
	end

	local function onTweenComplete()
		self:zTweenStop()

		if onComplete then
			onComplete()
		end
	end

	onTweenUpdate()

	self.zTweenID = MapFrameManager.tween(time, tweenObj, {
		z = to
	}, easing or "linear", onTweenComplete, onTweenUpdate)
end

function UnitEffect:zTweenStop()
	self.zTweening = false

	if self.floatObject then
		self.floatObject.offset = 0
		self.floatObject.count = 0
	end

	if self.zTweenID then
		MapFrameManager.stopTween(self.zTweenID)

		self.zTweenID = nil
	end
end

function UnitEffect:float(type, time, height, base, type4power)
	self.floatObject = {
		offset = 0,
		type = type,
		type4power = type4power or 5,
		time = time,
		height = height,
		base = base or height,
		count = math.random(0, time - 1)
	}

	MapFrameManager.startLoop(self, self.floatLoop)
end

function UnitEffect:floatStop()
	self.floatObject = nil

	MapFrameManager.stopLoop(self, self.floatLoop)
end

function UnitEffect:floatLoop(frame, passed, sharp)
	if self.zTweening then
		return
	end

	if self.floatObject.type == 1 then
		self.floatObject.offset = math.sin(self.floatObject.count / self.floatObject.time * math.pi * 2) * self.floatObject.height + self.floatObject.base
	elseif self.floatObject.type == 2 then
		self.floatObject.offset = (0.125 - math.pow(self.floatObject.count / self.floatObject.time - 0.5, 2)) * self.floatObject.height * 8 + self.floatObject.base
	elseif self.floatObject.type == 3 then
		if self.floatObject.count < self.floatObject.time / 2 then
			self.floatObject.offset = (0.25 - math.pow(self.floatObject.count * 2 / self.floatObject.time - 0.5, 2)) * self.floatObject.height * 4 + self.floatObject.base
		else
			self.floatObject.offset = -((0.25 - math.pow((self.floatObject.count - self.floatObject.time / 2) * 2 / self.floatObject.time - 0.5, 2)) * self.floatObject.height) * 4 + self.floatObject.base
		end
	elseif self.floatObject.count < self.floatObject.time / 4 or self.floatObject.count > self.floatObject.time / 4 * 3 then
		self.floatObject.offset = (self.floatObject.height - self.floatObject.offset) / self.floatObject.type4power + self.floatObject.offset
	else
		self.floatObject.offset = (-self.floatObject.height - self.floatObject.offset) / self.floatObject.type4power + self.floatObject.offset
	end

	self.floatObject.count = self.floatObject.count + passed

	if self.floatObject.time < self.floatObject.count then
		self.floatObject.count = 0
	end

	local yoffset = self.floatObject.offset
	self.unit.z = yoffset

	self.unit:setBmpY()

	if self.unit.setAvatarZ then
		self.unit:setAvatarZ()
	end

	if self.unit.shadow then
		self.unit:refreshShadowZ()
	end
end

function UnitEffect:whirlwind(action, frameTime, startFrame, endFrame, rotateSpeed)
	action = action or "attack"
	self.whirlwindObject = {
		action = self.unit.mappedAction[action] or action,
		frame = startFrame or 3,
		startFrame = startFrame or 3,
		endFrame = endFrame or 5,
		playCount = self.unit:getPlaySkip(action),
		speed = rotateSpeed or 0.3927,
		angle = self.unit.angle,
		time = frameTime or 10
	}

	MapFrameManager.startLoop(self, self.whirlwindLoop)
end

function UnitEffect:whirlwindStop()
	self.whirlwindObject = nil

	MapFrameManager.stopLoop(self, self.whirlwindLoop)
end

function UnitEffect:whirlwindLoop(frame, passed, sharp)
	local action = self.whirlwindObject.action
	local startFrame = self.whirlwindObject.startFrame
	local endFrame = self.whirlwindObject.endFrame

	if startFrame ~= endFrame then
		if self.whirlwindObject.playCount <= 0 then
			self.whirlwindObject.frame = self.whirlwindObject.frame + 1

			if endFrame < self.whirlwindObject.frame then
				self.whirlwindObject.frame = startFrame
			end

			self.whirlwindObject.playCount = self.unit:getPlaySkip(action)
		else
			self.whirlwindObject.playCount = self.whirlwindObject.playCount - 1
		end
	end

	local frame = self.whirlwindObject.frame
	self.whirlwindObject.angle = self.whirlwindObject.angle + self.whirlwindObject.speed
	local angle = self.whirlwindObject.angle
	self.unit.angle = angle

	self.unit:setFrame(action, self.unit:getDirection(), frame)

	self.whirlwindObject.time = self.whirlwindObject.time - passed

	if self.whirlwindObject.time <= 0 then
		self:whirlwindStop()
	end
end

function UnitEffect:partAction(action, startFrame, endFrame, customPlaySkip, onFrame, onComplete)
	customPlaySkip = customPlaySkip or self.unit:getPlaySkip(action)
	self.partActionObject = {
		action = self.unit.mappedAction[action] or action,
		frame = startFrame,
		startFrame = startFrame,
		endFrame = endFrame,
		playSkip = customPlaySkip,
		playCount = customPlaySkip,
		onFrame = onFrame,
		onComplete = onComplete
	}

	if onFrame then
		onFrame(startFrame)
	end

	MapFrameManager.startLoop(self, self.partActionLoop)
end

function UnitEffect:partActionStop()
	self.partActionObject = nil

	MapFrameManager.stopLoop(self, self.partActionLoop)
end

function UnitEffect:partActionLoop(frame, passed, sharp)
	local action = self.partActionObject.action
	local startFrame = self.partActionObject.startFrame
	local endFrame = self.partActionObject.endFrame
	local playSkip = self.partActionObject.playSkip
	local onFrame = self.partActionObject.onFrame
	local onComplete = self.partActionObject.onComplete

	if self.partActionObject.playCount <= 0 then
		if self.partActionObject.frame == endFrame then
			self:partActionStop()

			if onComplete then
				onComplete()
			end

			return
		end

		self.partActionObject.frame = self.partActionObject.frame + 1

		if endFrame < self.partActionObject.frame then
			self.partActionObject.frame = startFrame
		end

		if onFrame then
			onFrame(self.partActionObject.frame)
		end

		self.partActionObject.playCount = playSkip
	else
		self.partActionObject.playCount = self.partActionObject.playCount - 1
	end

	self.unit:setFrame(action, self.unit:getDirection(), self.partActionObject.frame)
end

function UnitEffect:destroy()
	self:loopActionStop()
	self:zTweenStop()
	self:floatStop()
	self:fadeStop()
	self:darkStop()
	self:whirlwindStop()
	self:stopAfterimage()
	self:stopCountdown()
	self:stopShake()

	if self.effectScaleTween then
		MapFrameManager.stopTween(self.effectScaleTween)

		self.effectScaleTween = nil
	end

	if self.muscleTween then
		MapFrameManager.stopTween(self.muscleTween)

		self.muscleTween = nil

		if self.muscleCloneUnit then
			self.muscleCloneUnit:removeSelf()

			self.muscleCloneUnit = nil
		end
	end
end

return UnitEffect
