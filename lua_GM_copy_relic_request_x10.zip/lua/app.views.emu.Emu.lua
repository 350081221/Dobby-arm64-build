local Emu = {}
local RARE_BASE = 100
local opArr = {
	"!=",
	">=",
	"<=",
	"=",
	">",
	"<"
}

local function checkCond(data, cond)
	local op, var = nil
	local values = {}

	for i, _op in ipairs(opArr) do
		local tagStart, tagEnd = string.find(cond, _op)

		if tagStart then
			op = _op
			var = string.sub(cond, 1, tagStart - 1)
			local value = string.sub(cond, tagEnd + 1)
			var = StringUtil.trim(var)
			value = StringUtil.trim(value)

			if string.find(value, ",") then
				local _values = string.split(value, ",")

				for i, v in ipairs(_values) do
					v = StringUtil.trim(v)

					if v ~= "" then
						table.insert(values, tonumber(v) or v)
					end
				end

				break
			end

			table.insert(values, tonumber(value) or value)

			break
		end
	end

	if data[var] == "" then
		return false
	end

	local orOK = false

	for i, value in ipairs(values) do
		if op == "!=" then
			orOK = data[var] ~= value
		elseif op == ">=" then
			orOK = value <= data[var]
		elseif op == "<=" then
			orOK = data[var] <= value
		elseif op == "=" then
			orOK = data[var] == value
		elseif op == ">" then
			orOK = value < data[var]
		elseif op == "<" then
			orOK = data[var] < value
		end

		if orOK then
			break
		end
	end

	return orOK
end

local equipMapCache = {}
local params = nil

function Emu.init(_params)
	Emu.setParams(_params)

	local path = cc.FileUtils:getInstance():getWritablePath() .. "emu_equips.txt"

	if io.exists(path) then
		local contents = getFileString(path)
		local obj = json.decode(contents)

		if obj ~= nil then
			equipMapCache = obj
		end
	end
end

function Emu.setParams(_params)
	params = _params
end

function Emu.getEquipMap(level)
	local levelStr = tostring(level)

	if not equipMapCache[levelStr] then
		local equipClassMap = Emu.dropBestEquip(10003, level, params.equip_times)
		equipMapCache[levelStr] = equipClassMap
		local path = cc.FileUtils:getInstance():getWritablePath() .. "emu_equips.txt"

		io.writefile(path, json.encode(equipMapCache))
	end

	return equipMapCache[levelStr]
end

function Emu.clearEquipCache()
	equipMapCache = {}
	local path = cc.FileUtils:getInstance():getWritablePath() .. "emu_equips.txt"

	io.writefile(path, json.encode(equipMapCache))
end

function Emu.createMonsterTeam(seed, level, normal_num, elite_num, boss_num)
	local max_level = CsvParser.getMaxID("monster_base_num")
	level = math.min(level, max_level)
	local oneArr = {}
	local random = Random.new(seed)
	local abyssEventArr = {}
	local abyssCsvRaw = CsvParser.getCsvRaw("abyss")

	for k, csv in pairs(abyssCsvRaw) do
		if csv.entrance == 0 and csv.level == level then
			if empty(csv.next) then
				if not empty(csv.battle1_id_1) then
					for i = 1, boss_num do
						table.insert(abyssEventArr, {
							id = csv.battle1_id_1,
							depth = i,
							depth_max = boss_num
						})
					end
				end
			else
				local _normal_num = 0
				local _elite_num = 0

				if not empty(csv.battle1_id_2) then
					_normal_num = normal_num
				end

				if not empty(csv.battle1_id_1) then
					_elite_num = elite_num
				end

				if not empty(csv.battle1_id_2) then
					for i = 1, normal_num do
						table.insert(abyssEventArr, {
							id = csv.battle1_id_2,
							depth = i,
							depth_max = _normal_num + _elite_num
						})
					end
				end

				if not empty(csv.battle1_id_1) then
					for i = 1, elite_num do
						table.insert(abyssEventArr, {
							id = csv.battle1_id_1,
							depth = _normal_num + i,
							depth_max = _normal_num + _elite_num
						})
					end
				end
			end
		end
	end

	local groupArr = {}

	for i, v in ipairs(abyssEventArr) do
		local abyssEventID = v.id
		local abyssEventCSV = CsvParser.getCsvData("abyss_event", abyssEventID)

		if abyssEventCSV then
			local power_arr = SheetUtil.getColumnListFull(abyssEventCSV, {
				"info_",
				"power_"
			}, {
				"info",
				"power"
			})
			local powerIndex = SheetUtil.getPowerRandomIndex(power_arr, random, "power")

			if empty(powerIndex) then
				powerIndex = 1
			end

			if abyssEventCSV.tag == "monster" then
				local info = ConfParser.parse(abyssEventCSV["info_" .. powerIndex])
				local groups = MapEventManager.getMonsterGroup(info.id, random, v.depth, v.depth_max, level)

				table.insert(groupArr, {
					monsterCreateID = info.id,
					groups = groups
				})
			end
		end
	end

	return groupArr, random:nextInt(1, 65535)
end

local petEquipCache = nil

function Emu.getPetEquip(pos, level)
	if not petEquipCache then
		petEquipCache = {}
		local csvRaw = CsvParser.getCsvRaw("pet_equip")

		for k, csv in pairs(csvRaw) do
			if not petEquipCache[csv.class] then
				petEquipCache[csv.class] = {}
			end

			petEquipCache[csv.class][csv.level] = csv.id
		end
	end

	if petEquipCache[pos] and petEquipCache[pos][level] then
		return petEquipCache[pos][level]
	end
end

local gemLevelCache = nil

function Emu.getBestGem(gemBestArr, gem_level, gem_class)
	if not gemLevelCache then
		gemLevelCache = {}
		local csvRaw = CsvParser.getCsvRaw("gem")

		for k, csv in pairs(csvRaw) do
			if not gemLevelCache[csv.level] then
				gemLevelCache[csv.level] = {}
			end

			table.insert(gemLevelCache[csv.level], csv)
		end
	end

	local levelArr = gemLevelCache[gem_level]

	if levelArr and #levelArr > 0 then
		local gem_classArr = string.split(gem_class, ",")
		local gem_classMap = {}

		for i, v in ipairs(gem_classArr) do
			local gemClass = tonumber(v)

			if gemClass then
				gem_classMap[gemClass] = true
			end
		end

		local arr = {}

		for i, csv in ipairs(levelArr) do
			if gem_classMap[csv.class] then
				table.insert(arr, csv)
			end
		end

		local bestMap = {}

		for i, v in ipairs(gemBestArr) do
			bestMap[v] = 1000 - i
		end

		table.sort(arr, function (a, b)
			local bestA = bestMap[a.type] or 0
			local bestB = bestMap[b.type] or 0

			if bestA == bestB then
				return a.id < b.id
			else
				return bestB < bestA
			end
		end)

		return arr[1].id
	end
end

function Emu.createMyTeam()
	local copy = {
		hero = {},
		pet = {},
		petIndex = InfoPet.getPetIndex(),
		petBlv = InfoBuilding.getBuildingLevel(InfoBuilding.TAG.PET)
	}
	local myPetTeam = InfoPet.getTeam()

	for i, myPetInfo in ipairs(myPetTeam) do
		local petInfo = ObjUtil.clone(myPetInfo)
		petInfo.equips = {}

		for j = 1, 4 do
			if petInfo["equip_" .. j] ~= 0 then
				petInfo.equips[j] = petInfo["equip_" .. j]
			end
		end

		table.insert(copy.pet, petInfo)
	end

	local myHeroTeam = InfoHero.getTeam()

	for i, myHeroInfo in ipairs(myHeroTeam) do
		local heroInfo = ObjUtil.clone(myHeroInfo)
		heroInfo.equips = {}

		for equipPos = 1, GameConfig.max_equip do
			local myEquipInfo = InfoEquip.getEquipOnHero(heroInfo.id, equipPos)

			if myEquipInfo then
				heroInfo.equips[equipPos] = ObjUtil.copy(myEquipInfo)
			end
		end

		heroInfo.cards = {}

		for equipPos = 1, GameConfig.max_card do
			local myCardInfo = InfoCard.getCardOnHero(heroInfo.id, equipPos)

			if myCardInfo then
				heroInfo.cards[equipPos] = ObjUtil.copy(myCardInfo)
			end
		end

		table.insert(copy.hero, heroInfo)
	end

	dump(copy, "$$$ createMyTeam", 10)

	return copy
end

function Emu.createHeroTeam(team_id, level, equipClassMap)
	local max_level = CsvParser.getMaxID("hero_base_num")
	level = math.min(level, max_level)
	local teamCSV = CsvParser.getCsvData("emu_hero_team", team_id)
	local payCSV = CsvParser.getCsvData("emu_pay_index", math.min(level, CsvParser.getMaxID("emu_pay_index")))
	local copy = {
		hero = {},
		pet = {}
	}
	local petNum = payCSV["pet_num_" .. teamCSV.pay_index]
	local petLevel = payCSV["pet_level_" .. teamCSV.pay_index]
	local petQuality = payCSV["pet_quality_" .. teamCSV.pay_index]

	if petLevel > 0 and petQuality > 0 and petNum > 0 then
		local petEquips = {}
		local petEquipLevel = payCSV["pet_equip_level_" .. teamCSV.pay_index]

		if petEquipLevel > 0 then
			for i = 1, 4 do
				petEquips[i] = Emu.getPetEquip(i, petEquipLevel)
			end
		end

		petNum = math.min(petNum, 3)

		for i = 1, petNum do
			local petID = teamCSV["pet_" .. i]
			petID = InfoPet.getBaseJob(petID)
			local jobLevel = InfoPet.getJoblevel({
				base_id = petID
			}, petLevel)
			local pet_csv = CsvParser.getCsvData("pet", petID)

			while pet_csv.job_level < jobLevel do
				pet_csv = CsvParser.getCsvData("pet", pet_csv.next_id)
			end

			local petInfo = {
				base_id = pet_csv.id,
				level = petLevel,
				quality = petQuality,
				seed = math.random(1, 65535)
			}
			local attrs = CombatAttr.attrs

			for i, attr in ipairs(attrs) do
				petInfo[attr .. "_seed"] = math.floor(32762.5)
			end

			petInfo.equips = petEquips

			table.insert(copy.pet, petInfo)
		end
	end

	for pos = 1, GameConfig.hero_team_num do
		local heroID = teamCSV["hero_" .. pos]
		local emuHeroCSV = CsvParser.getCsvData("emu_hero", heroID)
		local base_id = InfoHero.getBaseJob(emuHeroCSV.base_id)
		local jobLevel = InfoHero.getJoblevel({
			base_id = base_id
		}, level)
		local hero_csv = CsvParser.getCsvData("hero", base_id)

		while hero_csv.job_level < jobLevel do
			hero_csv = CsvParser.getCsvData("hero", hero_csv.next_job)
		end

		local heroInfo = {
			body = "female",
			hair = "female_h_08",
			base_id = hero_csv.id,
			level = level,
			quality = emuHeroCSV.quality
		}
		local attrs = CombatAttr.attrs

		for i, attr in ipairs(attrs) do
			heroInfo[attr .. "_seed"] = math.floor(32762.5)
		end

		for i = 1, 5 do
			heroInfo["skill_enc_" .. i] = emuHeroCSV["skill_enc_" .. i]
		end

		heroInfo.equips = {}
		local classArr = string.split(hero_csv.equip_class, ",")

		for i, classStr in ipairs(classArr) do
			local class = tonumber(classStr)
			local equipInfo = equipClassMap[class]

			if equipInfo then
				local equipCSV = CsvParser.getCsvData("equip", equipInfo.base_id)
				equipInfo = ObjUtil.copy(equipInfo)
				equipInfo.enhance_level = payCSV["enhance_level_" .. teamCSV.pay_index]
				local gem_level = payCSV["gem_level_" .. teamCSV.pay_index]

				if equipInfo.slot > 0 and gem_level > 0 then
					for j = 1, equipInfo.slot do
						local gemBestArr = SheetUtil.getColumnValueList(emuHeroCSV, "gem_best_")
						local gem = Emu.getBestGem(gemBestArr, gem_level, equipCSV.gem_class)

						if gem then
							equipInfo["gem" .. j] = gem
						end
					end
				end

				heroInfo.equips[equipCSV.equip_pos] = equipInfo
			end
		end

		heroInfo.cards = {}
		local card_star = payCSV["card_star_" .. teamCSV.pay_index]
		local card_level = payCSV["card_level_" .. teamCSV.pay_index]

		if card_star > 0 and card_level > 0 then
			local function randomFunc()
				return 0.5
			end

			local cardData = CsvParser.getCsvData("card", emuHeroCSV.card_id)
			local card_info = {
				exp = 0,
				pos = 1,
				base_id = emuHeroCSV.card_id,
				ran = math.random(1, 65535),
				level = card_level,
				star = card_star,
				growth_1 = math.random(math.floor(cardData.growth_min_1 * 1000), math.floor(cardData.growth_max_1 * 1000)),
				growth_2 = math.random(math.floor(cardData.growth_min_2 * 1000), math.floor(cardData.growth_max_2 * 1000)),
				growth_3 = math.random(math.floor(cardData.growth_min_3 * 1000), math.floor(cardData.growth_max_3 * 1000)),
				limit_1 = math.floor(cardData.growth_limit_1 * 1000),
				limit_2 = math.floor(cardData.growth_limit_2 * 1000),
				limit_3 = math.floor(cardData.growth_limit_3 * 1000),
				level_limit = InfoCard.getLimitByLevel(card_info)
			}
			card_info.star = math.min(card_info.star, InfoCard.getMaxStar(card_info))
			card_info.level = math.min(card_info.level, InfoCard.getMaxLevel(card_info))
			heroInfo.cards[1] = card_info
		end

		table.insert(copy.hero, heroInfo)
	end

	return copy
end

local dropCache = {}

function Emu.clearDropCache()
	dropCache = {}
end

function Emu.getAffixID(equip_class, affix_pos, random)
	local cache_key = "affix_raw_array_level_class_pos@" .. equip_class .. "&" .. affix_pos
	local csvArray = dropCache[cache_key]

	if not csvArray then
		local rawData = CsvParser.getCsvRaw("affix")
		csvArray = {}

		for k, itemData in pairs(rawData) do
			if itemData.rare ~= "" and itemData.rare > 0 and itemData.pos == affix_pos then
				local target_class = itemData.target_class
				local target_class_arr = string.split(target_class, ",")
				local include_class = false

				for i, v in ipairs(target_class_arr) do
					if tonumber(v) == equip_class then
						include_class = true

						break
					end
				end

				if include_class then
					table.insert(csvArray, itemData)
				end
			end
		end

		dropCache[cache_key] = csvArray
	end

	return csvArray
end

function Emu.getAffixGen(equip_level, drop_rare, agenCondArr, random, isTest)
	local cache_key = "affix_quality_level_rare@" .. equip_level

	for i, v in ipairs(agenCondArr) do
		cache_key = cache_key .. "_" .. v
	end

	local csvArray = dropCache[cache_key]

	if not csvArray then
		local rawData = CsvParser.getCsvList("affix_gen")
		csvArray = {}

		for i, data in ipairs(rawData) do
			if data.level <= equip_level then
				if data.rare ~= "" and data.rare > 0 then
					local condOK = true

					for i, cond in ipairs(agenCondArr) do
						if not checkCond(data, cond) then
							condOK = false

							break
						end
					end

					if condOK then
						table.insert(csvArray, data)
					end
				end
			else
				break
			end
		end

		dropCache[cache_key] = csvArray
	end

	local power_arr = {}

	for i, v in ipairs(csvArray) do
		local power = v.rare * RARE_BASE / (RARE_BASE + drop_rare * v.mf_ratio)
		power = 1 / power

		table.insert(power_arr, power)
	end

	local power_index = SheetUtil.getPowerRandomIndex(power_arr, random)
	local genData = csvArray[power_index]

	return genData
end

function Emu.dropBestEquip(drop_id, drop_level, drop_rare)
	local times = 10000
	local classMap = {}
	local bestScoreMap = {}
	local count = 0

	while true do
		local equipStack, itemStack, cardStack = Emu.drop(drop_id, drop_level, drop_rare)

		for i, equipInfo in ipairs(equipStack) do
			local equipCSV = CsvParser.getCsvData("equip", equipInfo.base_id)
			local class = equipCSV.class
			local score = InfoEquip.getScore(equipInfo, nil, function (attr, value)
				if attr == "def" then
					return value / 2
				else
					return value
				end
			end)

			if not bestScoreMap[class] or bestScoreMap[class] < score then
				bestScoreMap[class] = score
				classMap[class] = equipInfo
			end
		end

		count = count + 1

		if times <= count then
			local allOver = true

			for i = 1, 8 do
				if not classMap[i] then
					allOver = false
				end
			end

			if allOver then
				break
			end
		end
	end

	return classMap
end

function Emu.drop(drop_id, drop_level, drop_rare)
	local itemStack = {}
	local equipStack = {}
	local cardStack = {}
	local seed = math.random(1, 65535)
	local s_seed = math.random(1, 65535)
	local random = Random.new(seed)
	local isolated_random = Random.new(s_seed)
	local dropData = CsvParser.getCsvData("drop", drop_id)
	local dropQueue = SheetUtil.getColumnValueList(dropData, "lib_id")

	for i, dropStr in ipairs(dropQueue) do
		local dropLibStr = SheetUtil.getString(dropStr, random)

		if not empty(dropLibStr) then
			local dropLibArr = string.split(dropLibStr, ",")
			local dropLibID = dropLibArr[1]
			local dropLibNum = SheetUtil.getNumber(dropLibArr[2], random)

			for j = 1, dropLibNum do
				Emu.dropEquip(dropLibID, drop_level, drop_rare, random, isolated_random, itemStack, equipStack, cardStack)
			end
		end
	end

	return equipStack, itemStack, cardStack
end

function Emu.dropEquip(lib_id, drop_level, drop_rare, random, isolated_random, itemStack, equipStack, cardStack)
	local dropLibData = CsvParser.getCsvData("drop_lib", lib_id)

	if not empty(dropLibData.add_mf) then
		drop_rare = drop_rare + dropLibData.add_mf
	end

	local baseConArr = SheetUtil.getColumnValueList(dropLibData, "base_")
	local dropNum = SheetUtil.getNumber(dropLibData.num, isolated_random)

	for j = 1, dropNum do
		local agenCondArr = SheetUtil.getColumnValueList(dropLibData, "agen_")
		local affixGen = Emu.getAffixGen(drop_level, drop_rare, agenCondArr, isolated_random)
		affixGen = affixGen or Emu.getAffixGen(drop_level, drop_rare, {}, isolated_random)

		if affixGen then
			local quality = affixGen.quality
			local _baseConArr = {}

			for i, rawCond in ipairs(baseConArr) do
				local cond = StringUtil.replaceTag(rawCond, {
					level = drop_level,
					quality = quality
				})

				table.insert(_baseConArr, cond)
			end

			local baseID, equipData = DropManager.getBaseID("equip", drop_level, drop_rare, _baseConArr, isolated_random)

			if baseID then
				if not empty(equipData.suit_id) then
					affixGen = CsvParser.getCsvData("affix_gen", GameConfig.SUIT_QUALITY)
				end

				if baseID then
					local equipInfo = Emu.generateEquip(baseID, drop_level, drop_rare, affixGen, isolated_random)

					table.insert(equipStack, equipInfo)
				end
			end
		end
	end
end

function Emu.generateEquip(base_id, drop_level, drop_rare, affixGen, random)
	local equip_csv = CsvParser.getCsvData("equip", base_id)
	local equip_class = equip_csv.class
	local equip_level = equip_csv.level
	local ranfix_num = SheetUtil.getNumber(affixGen.ranfix_num, random)
	local prefix_num = SheetUtil.getNumber(affixGen.prefix_num, random)
	local suffix_num = SheetUtil.getNumber(affixGen.suffix_num, random)
	local prefixNum = random:getInt(0, ranfix_num)
	local suffixNum = ranfix_num - prefixNum
	prefixNum = prefixNum + prefix_num
	suffixNum = suffixNum + suffix_num
	local affix_pos_arr = {}

	for i = 1, prefixNum do
		table.insert(affix_pos_arr, 1)
	end

	for i = 1, suffixNum do
		table.insert(affix_pos_arr, 2)
	end

	local quality = affixGen.quality
	local prefixArray = {}
	local suffixArray = {}

	for j, affix_pos in ipairs(affix_pos_arr) do
		local affix_list = Emu.getAffixID(equip_class, affix_pos, random)

		if #affix_list > 0 then
			local power_arr = {}

			for i, affix in ipairs(affix_list) do
				local rare = affix.rare

				if rare > 0 then
					local power = 1 / rare

					table.insert(power_arr, power)
				else
					table.insert(power_arr, 0)
				end
			end

			local power_index = SheetUtil.getPowerRandomIndex(power_arr, random)

			if power_index then
				local affixID = affix_list[power_index].id

				if affix_pos == 1 then
					table.insert(prefixArray, affixID)
				else
					table.insert(suffixArray, affixID)
				end
			end
		end
	end

	local best_prefix = 0
	local best_suffix = 0
	local abyssBaseCSV = CsvParser.getCsvData("abyss_base_num", drop_level)
	local rareArr = SheetUtil.getColumnList(abyssBaseCSV, {
		"equip_level_",
		"equip_rare_"
	}, {
		"level",
		"rare"
	})
	local powerArr = {}
	local levelArr = {}

	for i, v in ipairs(rareArr) do
		if v.rare > 0 then
			table.insert(powerArr, 1 / v.rare)
			table.insert(levelArr, v.level)
		end
	end

	local powerIndex = SheetUtil.getPowerRandomIndex(powerArr, random)
	local equip_level = levelArr[powerIndex]
	local slotMax = SheetUtil.getNumber(equip_csv.slot_max, random)
	local slotNum = SheetUtil.getNumber(affixGen.slot_num, function ()
		return 0.9999
	end)
	slotNum = math.min(slotMax, slotNum)
	local equip_info = {
		identified = 0,
		enhance_level = 0,
		base_id = base_id,
		equip_pos = equip_csv.equip_pos,
		ran = random:getInt(1, 65535),
		best_prefix = best_prefix,
		best_suffix = best_suffix,
		slot = slotNum,
		slot_max = slotMax,
		quality = quality,
		drop_level = drop_level,
		level = equip_level,
		drop_rare = drop_rare
	}

	for i = 1, GameConfig.equip_affix_max do
		equip_info["prefix_" .. i] = prefixArray[i] or 0

		if equip_info["prefix_" .. i] ~= 0 then
			equip_info["preran_" .. i] = random:getInt(1, 65535)
		else
			equip_info["preran_" .. i] = 0
		end

		equip_info["suffix_" .. i] = suffixArray[i] or 0

		if equip_info["suffix_" .. i] ~= 0 then
			equip_info["sufran_" .. i] = random:getInt(1, 65535)
		else
			equip_info["sufran_" .. i] = 0
		end
	end

	for i = 1, GameConfig.equip_gem_max do
		equip_info["gem" .. i] = 0
	end

	return equip_info
end

return Emu
