local InfoTravel = {}
local rawData, hour_used, refresh_time = nil

function InfoTravel.init()
	Connection.listen("travel_sync", InfoTravel.sync)
end

app:addToAppEnterCall(InfoTravel.init)

function InfoTravel.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoTravel.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("travel_query", callback)
end

function InfoTravel.onQuery(rcvData)
	rawData = {}
	hour_used = rcvData.hour_used
	refresh_time = rcvData.refresh_time

	for i = 1, #rcvData.list do
		local data = rcvData.list[i]
		rawData[data.base_id] = data
	end
end

function InfoTravel.sync(data)
	local changedIdStack = {}

	if data.hour_used then
		hour_used = data.hour_used
	end

	if data.refresh_time then
		refresh_time = data.refresh_time
	end

	for i, syncData in ipairs(data.list) do
		local base_id = syncData.base_id

		if not rawData[base_id] then
			rawData[base_id] = syncData
		else
			for k, v in pairs(syncData) do
				rawData[base_id][k] = v
			end
		end

		changedIdStack[base_id] = rawData[base_id]
	end

	ManagerInfo.dataChange("travel", data)
end

function InfoTravel.start(id, hero1, hero2, hero3, hourIndex, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if CONFIG.is_ta then
				local heros = {
					hero1,
					hero2,
					hero3
				}
				local heroArr = {}

				for i, heroID in ipairs(heros) do
					if not empty(heroID) then
						local heroInfo = InfoHero.getHero(heroID)

						table.insert(heroArr, TaHelper.getHeroInfo(heroInfo))
					end
				end

				local params = {
					destination_id = id,
					dispatch_duration = GameConfig.travel_hour_list[hourIndex],
					hero_info = heroArr
				}

				TaHelper.taTrack("dispatch_start", params)
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("travel_start", {
		id = id,
		hero_1 = hero1,
		hero_2 = hero2,
		hero_3 = hero3,
		hour_index = hourIndex
	}, callback)
end

function InfoTravel.stop(id, isFin, onSuccess, onFailure)
	local preData = nil

	if CONFIG.is_ta and isFin then
		preData = ObjUtil.copy(rawData[id])
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if CONFIG.is_ta then
				local rewards = rcvData.rewards

				if isFin and preData then
					local heros = {
						preData.hero_1,
						preData.hero_2,
						preData.hero_3
					}
					local heroArr = {}

					for i, heroID in ipairs(heros) do
						if not empty(heroID) then
							local heroInfo = InfoHero.getHero(heroID)

							table.insert(heroArr, TaHelper.getHeroInfo(heroInfo))
						end
					end

					local params = {
						destination_id = preData.base_id,
						dispatch_duration = preData.hour_len,
						hero_info = heroArr
					}

					TaHelper.taTrack("dispatch_end", params)
				end
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	local is_fin = isFin and 1 or 0

	Connection.request("travel_stop", {
		id = id,
		is_fin = is_fin
	}, callback)
end

function InfoTravel.inTravel(heroID)
	for base_id, v in pairs(rawData) do
		if v.start_time > 0 then
			for i = 1, GameConfig.travel_hero_num do
				local hero_id = v["hero_" .. i]

				if hero_id == heroID then
					return true
				end
			end
		end
	end

	return false
end

function InfoTravel.getAvailableHeros(noDust)
	local heros = InfoHero.getAll(function (heroInfo)
		if heroInfo.pos > 0 then
			return false
		end

		if InfoTravel.inTravel(heroInfo.id) then
			return false
		end

		if noDust and InfoDust.isSub(heroInfo.id) then
			return false
		end

		return true
	end, function (a, b)
		if a.quality == b.quality then
			if a.level == b.level then
				return a.id < b.id
			else
				return b.level < a.level
			end
		else
			return b.quality < a.quality
		end
	end)

	return heros
end

function InfoTravel.getData(baseID)
	if rawData[baseID] then
		return rawData[baseID]
	else
		local data = {
			hero_1 = 0,
			start_time = 0,
			hero_2 = 0,
			hero_3 = 0,
			hour_len = 0,
			base_id = baseID
		}

		return data
	end
end

function InfoTravel.getHourLeft()
	local now = Time.now()
	local travel_hours = CsvParser.getCsvData("config", "travel_hours").value

	if InfoOrder.inSeason() then
		travel_hours = travel_hours + InfoOrder.getSeasonFunc(7)
	end

	local hourUsed = hour_used

	if RefreshManager.getNextTime(RefreshManager.TYPE.TRAVEL, refresh_time) <= now then
		hourUsed = 0
	end

	return travel_hours - hourUsed, travel_hours
end

function InfoTravel.getTimeLeft(baseID)
	local info = InfoTravel.getData(baseID)
	local now = Time.now()
	local timeLeft = info.start_time + info.hour_len * 3600 - now
	timeLeft = math.max(0, timeLeft)

	return timeLeft
end

function InfoTravel.getList()
	local csvList = CsvParser.getCsvList("travel")
	local arr = {}

	for i, v in ipairs(csvList) do
		local unlocked = v.unlock_level <= InfoDungeon.getAbyssMaxLevel()

		table.insert(arr, {
			csv = v,
			unlocked = unlocked,
			info = InfoTravel.getData(v.id)
		})

		if not unlocked then
			break
		end
	end

	return arr
end

function InfoTravel.getExp(baseID, hourIndex)
	local travel_exp_ratio = CsvParser.getCsvData("config", "travel_exp_ratio")["value" .. hourIndex]
	local travelCSV = CsvParser.getCsvData("travel", baseID)
	local abyssCSV = CsvParser.getCsvData("abyss_base_num", InfoDungeon.getAbyssMaxLevel())
	local exp = abyssCSV.travel_exp * travel_exp_ratio * travelCSV.exp_ratio

	return exp
end

function InfoTravel.countRedot()
	local csvRaw = CsvParser.getCsvRaw("travel")
	local redotCount = 0
	local now = Time.now()

	for k, v in pairs(csvRaw) do
		local unlocked = v.unlock_level <= InfoDungeon.getAbyssMaxLevel()

		if unlocked then
			local info = InfoTravel.getData(v.id)

			if info.start_time ~= 0 then
				local timeLeft = info.start_time + info.hour_len * 3600 - now

				if timeLeft <= 0 then
					redotCount = redotCount + 1
				end
			end
		end
	end

	return redotCount
end

return InfoTravel
