local NAV_base = import(".NAV_base")
local NAV_abyss = class("NAV_abyss", NAV_base)

function NAV_abyss.open(npc)
	local ui = NAV_abyss.new(npc)

	return ui
end

function NAV_abyss:ctor(npc)
	NAV_abyss.super.ctor(self, npc, "nav_abyss")
end

function NAV_abyss:init()
	NAV_abyss.super.init(self)

	local index = 2
	local funcCSV = InfoFunction.checkFuncOpen(10040)

	if funcCSV then
		self:setButtonVisible(index, true)

		local ui = self.buttons[index].ui

		self:setButtonName(ui, funcCSV.name)
	else
		self:setButtonVisible(index, false)
	end

	local index = 3
	local funcCSV = InfoFunction.checkFuncOpen(10100)

	if funcCSV then
		self:setButtonVisible(index, true)

		local ui = self.buttons[index].ui
		local str = StringUtil.replaceNearestCenterSpace(funcCSV.name)

		self:setButtonName(ui, str)
		ui:createBarByTag("progress", NAV_base.COLOR.HIGH, true)
	else
		self:setButtonVisible(index, false)
	end

	local index = 4
	local funcCSV = InfoFunction.checkFuncOpen(10190)

	if funcCSV then
		self:setButtonVisible(index, true)
	else
		self:setButtonVisible(index, false)
	end

	self:refresh()
	ManagerInfo.onDataChange(self, "abyss_gift", nil, function ()
		self:refresh()
	end)
end

function NAV_abyss:refresh()
	local index = 3
	local funcCSV = InfoFunction.checkFuncOpen(10100)

	if funcCSV then
		local ui = self.buttons[index].ui
		local progress, max = InfoAbyssGift.getProgress()
		local rewardCount = InfoAbyssGift.getRewardCount()

		ui:setBarProgressByTag("progress", math.min(1, progress / max))

		if max <= progress and rewardCount == 0 then
			ui:setBarColorByTag("progress", NAV_base.COLOR.HIGH)
		else
			ui:setBarColorByTag("progress", NAV_base.COLOR.PROGRESS)
		end

		local redot = ui:getComponentByTag("redot")

		redot:setVisible(InfoAbyssGift.countRedot() > 0)
	else
		self:setButtonVisible(index, false)
	end
end

function NAV_abyss:onTap(index)
	NAV_abyss.super.onTap(self, index)

	if index == 1 then
		if not InfoGuide.isFin() then
			local currentGuide = InfoGuide.getCurrent()

			if currentGuide then
				local csv = CsvParser.getCsvData("guide", currentGuide)

				if csv and csv.point_type ~= 1 then
					Alert.open(Localization.getSrcText("请先完成营地内的引导"))

					return
				end
			end
		end

		FRAME_abyss.open(self.npc)
	elseif index == 2 then
		FRAME_mirror.open(self.npc)
	elseif index == 3 then
		FRAME_abyss_gift.open(self.npc)
	elseif index == 4 then
		FRAME_naraka.open()
	end
end

return NAV_abyss
