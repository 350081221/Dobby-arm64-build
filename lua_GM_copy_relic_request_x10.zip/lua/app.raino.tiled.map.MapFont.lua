local MapFont = class("MapFont")
MapFont.cellPoolMap = {}

function MapFont.putCellPool(tag, char)
	transition.stopTarget(char)
	char:setPosition(0, 0)
	char:setScale(1)
	char:removeAllNodeEventListeners()
	char:retain()
	char:removeSelf()

	local poolTag = tag

	if not MapFont.cellPoolMap[poolTag] then
		MapFont.cellPoolMap[poolTag] = {}
	end

	table.insert(MapFont.cellPoolMap[poolTag], char)
end

function MapFont.getCellPool(tag)
	local poolTag = tag

	if MapFont.cellPoolMap[poolTag] and #MapFont.cellPoolMap[poolTag] > 0 then
		local char = table.remove(MapFont.cellPoolMap[poolTag], 1)

		return char, true
	end

	local comData = "#map_assets_" .. tag
	local char = display.newSprite(comData)
	char._poolTag = tag

	return char, false
end

function MapFont.clearCellPool()
	for poolTag, pool in pairs(MapFont.cellPoolMap) do
		for i = 1, #pool do
			pool[i]:release()
		end
	end

	MapFont.cellPoolMap = {}
end

function MapFont:ctor(prefix, str, xSpace)
	event_listener.extendMethods(self)

	self.prefix = prefix
	self.xSpace = xSpace or 0
	self.str = str
	self.scale = 1
	self.tweenID = 0
end

function MapFont:setScale(scale)
	self.scale = scale
end

function MapFont:setZOrder(zorder)
	self.zorder = zorder
end

function MapFont:display(layer, x, y)
	self.x = x
	self.y = y

	if self.chars ~= nil then
		for i, v in ipairs(self.chars) do
			local char = v.char

			MapFont.putCellPool(char._poolTag, char)
		end

		self.chars = nil
	end

	local totalWidth = 0
	local str = self.str
	local xSpace = self.xSpace
	self.chars = {}

	for i = 1, string.len(str) do
		local char = string.sub(str, i, i)
		local tag = self.prefix .. char
		local char, isRecycle = MapFont.getCellPool(tag)

		char:setScale(self.scale)

		totalWidth = totalWidth + char:getContentSize().width + xSpace

		table.insert(self.chars, {
			char = char,
			isRecycle = isRecycle
		})
	end

	self.width = totalWidth - xSpace
	local totalAdd = 0

	for i, v in ipairs(self.chars) do
		local char = v.char

		char:setPosition(totalAdd - self.width * self.scale / 2 + char:getContentSize().width * self.scale / 2 + self.x, self.y)
		layer:addChild(char, self.zorder or 0)

		totalAdd = totalAdd + char:getContentSize().width * self.scale + xSpace * self.scale

		if v.isRecycle then
			char:release()
		end
	end
end

function MapFont:update(step)
	if self.scaleNum ~= nil then
		self:setScale(self.scaleNum)
	end

	if self.alpha ~= nil then
		self:setOpacity(self.alpha)
	end

	if self.x ~= nil and self.y ~= nil then
		self:setPosition(self.x, self.y)
	elseif self.x ~= nil then
		self:setPositionX(self.x)
	elseif self.y ~= nil then
		self:setPositionY(self.y)
	end
end

function MapFont:jumpIn(holding, jumpHeight)
	holding = holding or 30
	jumpHeight = jumpHeight or 0
	local tweenObj = {
		yOffset = 0,
		scaleNum = 1 * self.scale
	}
	local actionArray = {
		{
			easing = "outQuad",
			time = 10,
			scaleNum = 1.5 * self.scale,
			yOffset = 10 + jumpHeight
		},
		{
			easing = "inQuad",
			time = 5,
			scaleNum = 1 * self.scale
		},
		{
			time = holding
		},
		{
			easing = "outQuad",
			scaleNum = 0,
			time = 5,
			yOffset = 20 + jumpHeight
		}
	}

	local function onUpdate()
		local totalAdd = 0

		for i, v in ipairs(self.chars) do
			local char = v.char

			char:setScale(tweenObj.scaleNum)
			char:setPosition((totalAdd - self.width * self.scale / 2 + char:getContentSize().width * self.scale / 2) * tweenObj.scaleNum + self.x, self.y + tweenObj.yOffset)

			totalAdd = totalAdd + char:getContentSize().width + self.xSpace
		end
	end

	local onComplete = nil

	function onComplete()
		MapFrameManager.stopTween(self.tweenID)

		if #actionArray > 0 then
			local actionObj = table.remove(actionArray, 1)
			self.tweenID = MapFrameManager.tween(actionObj.time, tweenObj, {
				scaleNum = actionObj.scaleNum,
				yOffset = actionObj.yOffset
			}, actionObj.easing, onComplete, onUpdate)
		else
			for i, v in ipairs(self.chars) do
				local char = v.char

				MapFont.putCellPool(char._poolTag, char)
			end

			self.chars = nil
		end
	end

	onComplete()
end

function MapFont:jumpAndFade(holding)
	self.scaleNum = 0
	self.alpha = 255

	self:update()

	self.actHolding = holding or 30

	tween.stop(self.tweenID)

	self.tweenID = MapFrameManager.tween(10, self, {
		scaleNum = 1
	}, "outQuad", handler(self, self.jumpAndFade1))
end

function MapFont:jumpAndFade1()
	tween.stop(self.tweenID)

	self.tweenID = MapFrameManager.tween(self.actHolding, self, {}, "linear", handler(self, self.jumpAndFade2))
end

function MapFont:jumpAndFade2()
	tween.stop(self.tweenID)

	self.tweenID = MapFrameManager.tween(15, self, {
		alpha = 0
	}, "outQuad", handler(self, self.jumpAndFadeFinish))
end

function MapFont:jumpAndFadeFinish()
	tween.stop(self.tweenID)
	self:dispatchEvent({
		name = "OVER"
	})
end

function MapFont:moveAndFade(distance, holding)
	self.y = self:getPositionY()
	self.alpha = 0

	self:update()

	self.actHolding = holding or 30

	tween.stop(self.tweenID)

	self.tweenID = MapFrameManager.tween(20, self, {
		alpha = 255,
		y = self.y + distance
	}, "linear", handler(self, self.moveAndFade1))
end

function MapFont:moveAndFade1()
	tween.stop(self.tweenID)

	self.tweenID = MapFrameManager.tween(self.actHolding, self, {}, "linear", handler(self, self.moveAndFade2))
end

function MapFont:moveAndFade2()
	tween.stop(self.tweenID)

	self.tweenID = MapFrameManager.tween(15, self, {
		alpha = 0
	}, "outQuad", handler(self, self.moveAndFadeFinish))
end

function MapFont:moveAndFadeFinish()
	tween.stop(self.tweenID)
	self:dispatchEvent({
		name = "OVER"
	})
end

function MapFont:seal(scale, time, interval, fadeOutTime, fadeOutDelay)
	time = time or 0.1
	interval = interval or 0.05
	scale = scale or 2
	fadeOutTime = fadeOutTime or 0.2
	fadeOutDelay = fadeOutDelay or 0.1

	for i, v in ipairs(self.chars) do
		local char = v.char

		char:setScale(scale)
		char:setOpacity(0)
		transition.scaleTo(char, {
			easing = "sineIn",
			scale = 1,
			time = time,
			delay = interval * (i - 1)
		})

		if i == #self.chars then
			local function fadeAndDestroy()
				transition.fadeOut(self, {
					easing = "sineIn",
					time = fadeOutTime,
					delay = fadeOutDelay,
					onComplete = handler(self, self.destroy)
				})
			end

			transition.fadeIn(char, {
				time = time,
				delay = interval * (i - 1),
				onComplete = fadeAndDestroy
			})
		else
			transition.fadeIn(char, {
				time = time,
				delay = interval * (i - 1)
			})
		end
	end
end

function MapFont:destroy()
	if self.chars then
		for i, v in ipairs(self.chars) do
			local char = v.char

			MapFont.putCellPool(char._poolTag, char)
		end

		self.chars = nil
	end

	self:removeAllEventListeners()
	self:removeSelf()
end

return MapFont
