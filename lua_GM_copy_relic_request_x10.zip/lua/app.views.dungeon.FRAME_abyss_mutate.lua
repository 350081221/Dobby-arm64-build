local FRAME_abyss_mutate = class("FRAME_abyss_mutate", UI_base)

function FRAME_abyss_mutate.open(dungeonCSV, mutateCSV, terrainCSV)
	local ui = FRAME_abyss_mutate.new(dungeonCSV, mutateCSV, terrainCSV)

	PopManager.open(ui)
end

function FRAME_abyss_mutate:ctor(dungeonCSV, mutateCSV, terrainCSV)
	FRAME_abyss_mutate.super.ctor(self, "frame_abyss_mutate")

	self.dungeonCSV = dungeonCSV
	self.mutateCSV = mutateCSV
	self.terrainCSV = terrainCSV

	self:init()
end

function FRAME_abyss_mutate:init()
	self:initUI()
end

function FRAME_abyss_mutate:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	self.textArea = self:createTextAreaOnFlag("flag_text")

	self.textArea:setSpace(10, 10)

	local dungeonCSV = self.dungeonCSV
	local mutateCSV = self.mutateCSV
	local terrainCSV = self.terrainCSV

	self:createLabelOnFlag("flag_title", dungeonCSV.name)

	if terrainCSV then
		self.textArea:addText(terrainCSV.name, {
			color = Style.golden
		})
		self.textArea:addText(terrainCSV.desc, {
			size = 22
		})
	end

	if mutateCSV then
		if InfoDungeon.getType() == InfoDungeon.TYPE.ABYSS then
			if not empty(mutateCSV.map_id) then
				local mutateMapCSV = CsvParser.getCsvData("abyss_mutate_map", mutateCSV.map_id)

				self.textArea:addText(mutateMapCSV.name, {
					color = Style.golden
				})
				self.textArea:addText(mutateMapCSV.desc, {
					size = 22
				})
			end

			if not empty(mutateCSV.monster_id) then
				local mutateMonsterCSV = CsvParser.getCsvData("abyss_mutate_monster", mutateCSV.monster_id)

				self.textArea:addText(mutateMonsterCSV.name, {
					color = Style.golden
				})
				self.textArea:addText(mutateMonsterCSV.desc, {
					size = 22
				})
			end
		elseif InfoDungeon.getType() == InfoDungeon.TYPE.STAGE then
			self.textArea:addText(mutateCSV.name, {
				color = Style.golden
			})
			self.textArea:addText(mutateCSV.desc, {
				size = 22
			})
		end
	end

	self:createScrollerByTag("display_vol", "flag_display", function (percent, isEnd)
		if isEnd then
			UIManager.callTapGroup("button_click")
			self:setScollerProgressByTag("flag_display", Sound.getAtomsVolume())
			self:refreshAtoms()
		end

		self:refreshAtomsLabel()
		Sound.setAtomsLevel(percent, isEnd)
	end)
	self:refreshAtomsLabel()
	self:setScollerProgressByTag("flag_display", Sound.getAtomsVolume())
end

function FRAME_abyss_mutate:refreshAtomsLabel()
	local labels = {
		"高",
		"中",
		"低"
	}
	local label = labels[Sound.getAtomsLevel() + 1] or ""

	self:replaceLabelOnFlag("label_display_level", nil, Localization.getSrcText(label))
end

function FRAME_abyss_mutate:refreshAtoms()
	local scene = display.getRunningScene()

	if scene.recoverLight then
		scene:recoverLight()
	end
end

return FRAME_abyss_mutate
