local HintManager = {}
local currentData = nil

function HintManager.clear()
	currentData = nil
	HintManager.opening = nil
end

function HintManager.getHintID()
	if currentData then
		return currentData.hintData.id
	end
end

function HintManager.next()
	if currentData then
		local hintData = currentData.hintData

		if not empty(hintData.next) then
			HintManager.open(hintData.id, currentData.onComplete, currentData.isContinuous, currentData.onTouch, currentData.pointerReplace)
		else
			local maskName = nil

			if not empty(hintData.mask_name) then
				maskName = hintData.mask_name
			end

			POP_mask.open(18, 0, nil, , , , maskName)
			POP_hint.close()
			POP_focus.close()

			HintManager.opening = nil
			local onComplete = currentData.onComplete
			currentData = nil

			if onComplete then
				onComplete()
			end
		end
	end
end

function HintManager.close()
	POP_hint.close()
	POP_focus.close()
	POP_mask.close()

	HintManager.opening = nil
end

function HintManager.onHintTaNesting(id)
	print("$$$ HintManager.onHintTaNesting", id)

	local hintData = CsvParser.getCsvData("hint", id)

	while not empty(hintData) do
		HintManager.onHintTa(hintData.id)

		if not empty(hintData.next) then
			hintData = CsvParser.getCsvData("hint", hintData.next)
		else
			break
		end
	end
end

function HintManager.onHintTa(id)
	if tostring(id) == "guide_1000_4" then
		TaHelper.taGuideDetail(10400)
	elseif tostring(id) == "guide_1040_31" then
		TaHelper.taGuideDetail(10800)
	elseif tostring(id) == "guide_1040_33" then
		TaHelper.taGuideDetail(10900)
	elseif tostring(id) == "3501" then
		TaHelper.taGuideDetail(11100)
	elseif tostring(id) == "free_2_14" then
		TaHelper.taGuideDetail(12200)
	elseif tostring(id) == "free_20_5" then
		TaHelper.taGuideDetail(12300)
	elseif tostring(id) == "guide_7040_23" then
		TaHelper.taGuideDetail(13300)
	elseif tostring(id) == "mission_1_1_n_4" then
		TaHelper.taGuideDetail(12000)
	elseif tostring(id) == "mission_1_1_n_5" then
		TaHelper.taGuideDetail(12100)
	elseif tostring(id) == "guide_13030_1" then
		TaHelper.taGuideDetail(15400)
	end
end

function HintManager.open(id, onComplete, isContinuous, onTouch, pointerReplace)
	HintManager.pointerReplace = pointerReplace
	local hintData = CsvParser.getCsvData("hint", id)
	local options = SheetUtil.getColumnList(hintData, {
		"option_",
		"option_next_"
	}, {
		"name",
		"next"
	})

	if #options > 0 then
		POP_hint.close()
		POP_focus.close()
		POP_mask.close()
		POP_hint_option.open(id, function (index)
			HintManager.open(options[index].next, onComplete, true, nil, pointerReplace)
		end)

		return
	end

	currentData = {
		hintData = hintData,
		onComplete = onComplete,
		isContinuous = isContinuous,
		onTouch = onTouch,
		pointerReplace = pointerReplace
	}
	local maskName = nil

	if not empty(hintData.mask_name) then
		maskName = hintData.mask_name
	end

	local isCompleted = false

	local function onHintComplete()
		if not isCompleted then
			isCompleted = true

			HintManager.onHintTa(hintData.id)

			if not empty(hintData.next) then
				HintManager.open(hintData.next, onComplete, true, nil, pointerReplace)
			else
				POP_mask.open(18, 0, nil, , , , maskName)
				POP_hint.close()
				POP_focus.close()

				HintManager.opening = nil
				currentData = nil

				if onComplete then
					onComplete()
				end
			end
		end
	end

	local function onReset()
		HintManager.open(id, onComplete, isContinuous, onTouch, pointerReplace)
	end

	local uiPointer = hintData.ui_pointer

	if pointerReplace then
		uiPointer = StringUtil.replace(uiPointer, unpack(pointerReplace))
	end

	if uiPointer ~= "" then
		uiPointer = StringUtil.replaceTag(uiPointer, function (tag)
			if global[tag] then
				return global[tag]
			end
		end)
	end

	local dungeonPointer = hintData.dungeon_pointer
	local hintText = hintData.text
	local maskOpacity = 120
	local focusOpacity = 150

	if hintData.mask_opacity ~= "" then
		maskOpacity = hintData.mask_opacity
	end

	if not empty(uiPointer) then
		local breakCount = 120
		local findLoop = nil

		function findLoop()
			local component = UIManager.findComponent(uiPointer)

			if component then
				local function onClick()
					POP_mask.open(0, maskOpacity, nil, , , , maskName)
					POP_focus.close()
					onHintComplete()
				end

				local function openHint()
					if not empty(hintText) then
						POP_hint.openOnNode(component, id)
					else
						POP_hint.close()

						HintManager.opening = nil
					end
				end

				local function onFocusComplete()
					if not isContinuous then
						openHint()
					end
				end

				POP_mask.open(0, 0, nil, , , , maskName)
				POP_focus.openOnNode(component, focusOpacity, nil, onClick, onFocusComplete, true, hintData.touch_mode, onTouch, onReset, hintData.close_event)

				if isContinuous then
					openHint()
				end

				Looper.stopLoop(DramaManager, findLoop)

				return
			end

			breakCount = breakCount - 1

			if breakCount <= 0 then
				Log.warn("uiPointer not found", uiPointer)
				Looper.stopLoop(DramaManager, findLoop)
				POP_hint.close()
				POP_focus.close()
				POP_mask.close()

				HintManager.opening = nil
				currentData = nil

				if onComplete then
					onComplete()
				end
			end
		end

		Looper.startLoop(DramaManager, findLoop)
	elseif not empty(dungeonPointer) then
		local scene = display.getRunningScene()
		local scrollmap = scene.scrollmap

		if scrollmap then
			scene:scrollToTag(dungeonPointer, function ()
				local x, y = scrollmap:getTagPosition(dungeonPointer)

				local function onClick()
					POP_mask.open(0, maskOpacity, nil, , , , maskName)
					POP_focus.close()
					onHintComplete()
				end

				local function openHint()
					if not empty(hintText) then
						POP_hint.openOnRect(scrollmap.container, cc.rect(x - 25, y - 25, 50, 50), id)
					else
						POP_hint.close()

						HintManager.opening = nil
					end
				end

				local function onFocusComplete()
					if not isContinuous then
						openHint()
					end
				end

				POP_mask.open(0, 0, nil, , , , maskName)
				POP_focus.openOnRect(scrollmap.container, cc.rect(x - 25, y - 25, 50, 50), focusOpacity, nil, onClick, onFocusComplete, true)

				if isContinuous then
					openHint()
				end
			end)
		end
	else
		local function onClick()
			if not POP_hint.isOver then
				return
			end

			onHintComplete()
		end

		local function openHint()
			if not empty(hintText) then
				POP_hint.openOnCenter(id)
			else
				POP_hint.close()

				HintManager.opening = nil
			end
		end

		local function onMaskComplete()
			if not isContinuous then
				openHint()
			end
		end

		POP_mask.open(18, maskOpacity, nil, , onMaskComplete, onClick, maskName)

		if isContinuous then
			openHint()
		end
	end

	HintManager.opening = true
end

return HintManager
