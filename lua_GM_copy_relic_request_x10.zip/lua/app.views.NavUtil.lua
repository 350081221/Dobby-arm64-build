local NavUtil = {}

function NavUtil.createNpcNav(npc)
	local ui = nil

	if npc.type == "monster" then
		ui = NAV_monster.open(npc)
	elseif npc.eventData and npc.eventData.tag == "eventset" then
		if npc:isInteractive() then
			ui = NAV_eventset.open(npc, npc.eventsetArr)
		end
	elseif npc.npcType == Npc.TYPE.NPC then
		if LinesManager.checkNpcNearTime(npc.data.id) then
			local lines = LinesManager.getNpcNear(npc.data.id)

			if lines then
				npc:say(lines, 120)
				LinesManager.markNpcNearTime(npc.data.id)
			end
		end

		if not empty(npc.data.building0) and InfoBuilding.getBuildingLevel(npc.data.building0) == 0 then
			ui = NAV_build.open(npc)
		elseif InfoFestival.getDataForNPC(npc.baseID) then
			ui = NAV_festival.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.FORGE then
			ui = NAV_forge.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.TAVERN then
			ui = NAV_tavern.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.KANBAN then
			ui = NAV_kanban.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.MONO then
			ui = NAV_mono.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.MARKET then
			ui = NAV_market.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.FURNACE then
			ui = NAV_furnace.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.VETERAN then
			ui = NAV_veteran.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.MERCHANT then
			ui = NAV_merchant.open(npc, 11)
		elseif npc.data.building == InfoBuilding.TAG.ASAKA_MCT then
			ui = NAV_merchant.open(npc, 12)
		elseif npc.data.building == InfoBuilding.TAG.DUST_MCT then
			ui = NAV_merchant.open(npc, 13)
		elseif npc.data.building == InfoBuilding.TAG.SHADOW_MCT then
			ui = NAV_merchant.open(npc, 14)
		elseif npc.data.building == InfoBuilding.TAG.DUST_KANBAN then
			ui = NAV_dust.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.BARD then
			ui = NAV_bard.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.ABYSS then
			ui = NAV_abyss.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.TELEPORT then
			ui = NAV_teleport.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.DUST_NEXT then
			ui = NAV_dust_next.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.GAP_EXIT then
			ui = NAV_gap_exit.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.PET_HATCH then
			local info = ConfParser.parse(npc.eventData.info)
			local hatchData = InfoPetHatch.getByPos(info.pos)

			if hatchData then
				if empty(hatchData.base_id) then
					ui = NAV_hatch_put.open(npc, info.pos)
				else
					ui = NAV_hatch_get.open(npc, info.pos)
				end
			else
				ui = NAV_hatch_create.open(npc, info.pos)
			end
		elseif npc.data.building == InfoBuilding.TAG.PET then
			ui = NAV_pet.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.ARENA then
			ui = NAV_arena.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.TRAVEL then
			ui = NAV_travel.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.WILD_SHOP then
			ui = NAV_wild_shop.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.STORAGE then
			ui = NAV_storage.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.GACHA then
			ui = NAV_gacha.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.PIG then
			ui = NAV_pig.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.RECLAIM then
			ui = NAV_reclaim.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.EXCHANGE then
			ui = NAV_exchange_sell.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.FARM then
			ui = NAV_farm.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.FARM_TILE then
			local buildingLevel = InfoBuilding.getBuildingLevel(InfoBuilding.TAG.FARM)

			if buildingLevel > 0 then
				local newSeed = InfoFarm.getNewSeed()

				if newSeed then
					ui = NAV_farm_seed.open(npc, newSeed)
				end
			end
		elseif npc.data.building == InfoBuilding.TAG.CAMPFIRE then
			ui = NAV_campfire.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.HOME then
			ui = NAV_home.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.HOME_POSTBOX then
			ui = NAV_home_postbox.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.DUST_ENTER then
			ui = NAV_dust_enter.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.DUST_FORGE then
			ui = NAV_dust_forge.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.UNION_SHOP then
			ui = NAV_union_shop.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.UNION_RESOURCE then
			ui = NAV_union_donate.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.UNION_CENTER then
			ui = NAV_union_center.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.UNION_BUFF_OPEN then
			ui = NAV_union_buff.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.UNION_MONO then
			ui = NAV_union_mono.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.UNION_GWAR then
			if InfoParams.getValue("union_gwar") == 1 then
				ui = NAV_union_war.open(npc)
			end
		elseif npc.data.building == InfoBuilding.TAG.SEAT then
			ui = NAV_seat.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.SIGIL then
			ui = NAV_sigil.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.ARTIFACT then
			ui = NAV_artifact.open(npc)
		else
			local data = InfoTaskQuest.getDataForNPC(npc.baseID)

			if data then
				ui = NAV_task.open(npc, data)
			end
		end
	elseif npc.npcType == Npc.TYPE.DEVICE then
		if npc.data.building == InfoBuilding.TAG.HOME_CRAFT then
			if InfoHome.isSelf() then
				ui = NAV_home_craft.open(npc)
			else
				ui = NAV_visit_craft.open(npc)
			end
		elseif npc.data.building == InfoBuilding.TAG.HOME_ALCHEMY then
			if InfoHome.isSelf() then
				ui = NAV_home_alchemy.open(npc)
			else
				ui = NAV_visit_alchemy.open(npc)
			end
		elseif npc.data.building == InfoBuilding.TAG.HOME_WORKSHOP then
			if InfoHome.isSelf() then
				ui = NAV_home_workshop.open(npc)
			else
				ui = NAV_visit_workshop.open(npc)
			end
		elseif npc.data.building == InfoBuilding.TAG.HOME_DJ then
			ui = NAV_home_dj.open(npc)
		elseif npc.data.building == InfoBuilding.TAG.HOME_POSTBOX then
			ui = NAV_home_postbox.open(npc)
		end
	elseif npc.npcType == Npc.TYPE.GATHER then
		ui = NAV_gather.open(npc)
	elseif npc.npcType == Npc.TYPE.RELIC then
		ui = NAV_relic.open(npc)
	elseif npc.npcType == Npc.TYPE.SHRINE then
		ui = NAV_shrine.open(npc)
	elseif npc.npcType == Npc.TYPE.PET then
		if InfoParams.getValue("home_pet") == 1 and npc.feedData then
			ui = NAV_pet_feed.open(npc)
		end
	elseif npc.npcType == Npc.TYPE.CHANCE then
		if npc.data.type == 11 then
			local eventData = npc.eventData
			local eventInfo = InfoDungeon.getEventInfo(eventData.index)

			if eventInfo.fin <= GameConfig.gladiator_max then
				ui = NAV_gladiator.open(npc)
			else
				local finalRelic = InfoDungeon.getFinalRelic(eventData.index)

				if finalRelic and finalRelic.fin == 0 then
					ui = NAV_gladiator_relic.open(npc, finalRelic.index)
				end
			end
		else
			ui = NAV_chance.open(npc)
		end
	elseif npc.npcType == Npc.TYPE.DOOR then
		-- Nothing
	elseif npc.npcType == Npc.TYPE.HERO_TEMPLETE then
		-- Nothing
	elseif npc.npcType == Npc.TYPE.MOONCARD_CHEST then
		ui = NAV_mooncard.open(npc)
	end

	return ui
end

function NavUtil.checkChance(npc)
	if npc.npcType ~= Npc.TYPE.CHANCE then
		return false
	end

	if global.player then
		global.player:stop(27)
		global.player:faceToTile(npc.tile)
		global.player:stopMoveDirection()
	end

	local eventIndex = npc.eventData.index
	local mapID = npc.eventData.mapName
	local costList = SheetUtil.getColumnList(npc.data, {
		"cost_id_",
		"cost_num_"
	}, {
		"id",
		"num"
	})
	local costCheck, lackList, lackStr = InfoItem.checkCost(costList)

	if not costCheck then
		local msg = Localization.getSrcText("缺少 {1}")

		Alert.open(StringUtil.replace(msg, lackStr))

		return false
	end

	if npc.data.type == 7 then
		local dungeon_csv = InfoDungeon.getDungeonCSV()
		local mine_index = dungeon_csv.mine_index

		if empty(mine_index) or InfoFurnace.getMineRecord(mine_index) > 0 then
			return false
		end
	elseif npc.data.type == 9 then
		local base_id, id = InfoBook.getRandomID()

		if not base_id then
			if not empty(npc.data.fail_msg) then
				Alert.open(npc.data.fail_msg)
			end

			return false
		end
	end

	return true
end

function NavUtil.openChance(npc)
	if not npc:checkChance() then
		return
	end

	local eventIndex = npc.eventData.index
	local mapID = npc.eventData.mapName

	local function onChanceRequestOver()
		npc:refreshOpened(true)

		if global.player then
			global.player:checkNearNpc()
		end
	end

	if npc.data.type == 1 then
		FRAME_equip_save.open(npc, onChanceRequestOver)
	elseif npc.data.type == 2 then
		FRAME_chance_deliver.open(npc, onChanceRequestOver)
	elseif npc.data.type == 8 then
		FRAME_chance_forge.open(npc, onChanceRequestOver)
	elseif npc.data.type == 3 then
		-- Nothing
	elseif npc.data.type == 4 then
		-- Nothing
	elseif npc.data.type == 5 then
		-- Nothing
	elseif npc.data.type == 6 then
		InfoDungeon.getChance(npc, eventIndex, nil, function (rcvData)
			local hpPercent = 0
			local hpAbs = 0

			if not empty(npc.data.value1) then
				hpPercent = npc.data.value1
			end

			if not empty(npc.data.value2) then
				hpAbs = npc.data.value2
			end

			local heros = TeamManager.getTeam()

			for i, hero in ipairs(heros) do
				if hero.battleData.hp > 0 then
					local hpMax = hero.battleData.hp
					local addHp = hpMax * hpPercent / 100 + hpAbs

					if addHp > 0 then
						if not empty(npc.data.hero_effect) then
							local effectGen = hero:getEffectGen()

							if effectGen then
								effectGen:castEffect(npc.data.hero_effect, hero)
							end
						end

						hero:jumpWord(math.floor(addHp), "font_heal_", 0, 30)
					end
				end
			end

			npc:performWithDelay(function ()
				MapEffect.quake(10)
			end, 0.5)
			onChanceRequestOver()
		end, function (err)
		end)
	elseif npc.data.type == 7 then
		ChanceUtils.furnaceBattle(npc, onChanceRequestOver)
	else
		if npc.data.type == 9 then
			local base_id, id = InfoBook.getRandomID()

			InfoDungeon.getChance(npc, eventIndex, {
				base_id = base_id,
				id = id
			}, function (rcvData)
				local bookCatalog = CsvParser.getCsvData("books_catalog", base_id)

				POP_aside.openText(bookCatalog.aside_text, nil, function ()
					global.player:onNpcDisable(npc)
				end)
			end)

			return
		end

		if npc.data.type == 10 then
			ChanceUtils.openEquipShop(npc, eventIndex)
		elseif npc.data.type == 12 then
			local function onGetChance()
				InfoDungeon.getChance(npc, eventIndex, nil, function (rcvData)
					onChanceRequestOver()
				end, function (err)
				end)
			end

			if not empty(npc.data.dialog) then
				POP_dialog.open(npc.data.dialog, onGetChance)
			elseif not empty(npc.data.dialog_group) then
				local stageType, stageID = InfoDungeon.getStage()
				local foundDialog = false

				if not empty(stageID) then
					local stageCSV = CsvParser.getCsvData("stage", stageID)

					if not empty(stageCSV) then
						local dialogID = npc:getStageDialog(npc.data.dialog_group, stageCSV.index)

						if not empty(dialogID) then
							POP_dialog.open(npc.data.dialog, onGetChance)

							foundDialog = true
						end
					end
				end

				if not foundDialog then
					onGetChance()
				end
			else
				onGetChance()
			end
		elseif npc.data.type == 13 or npc.data.type == 14 then
			local currentEventInfo = InfoDungeon.getEventInfo(eventIndex)

			if currentEventInfo.fin <= 1 then
				if npc.getGatherLock then
					return
				end

				local preFin = currentEventInfo.fin
				local isClosed = false

				InfoDungeon.setTrapHeroDelay(45)

				local function onGetInfo(info)
					local function onGatherGet(rcvData)
						global.player:onNpcDisable(npc)
						npc:refreshOpened()

						isClosed = true
					end

					local function openUI()
						local openEffect = npc.data.open_effect

						if not empty(openEffect) then
							local effectGen = npc:getEffectGen()

							if effectGen then
								effectGen:castEffect(openEffect, npc)
							end
						end

						FRAME_relic_get.open(FRAME_relic_get.TYPE.CHANCE, npc, eventIndex, nil, info.info_drop_equips, info.info_drop_items, info.info_drop_cards, info.info_drop_sigils, function (_rcvData)
							onGatherGet(_rcvData)
						end, function ()
							npc.getGatherLock = nil

							npc:refreshOpened()

							isClosed = true
						end)
					end

					if preFin == 0 then
						local trapEffect = npc.data.trap_effect

						if not empty(trapEffect) then
							local effectGen = npc:getEffectGen()

							if effectGen then
								effectGen:castEffect(trapEffect, npc)
							end

							Looper.setTimeout(openUI, 60, npc)
						else
							openUI()
						end
					else
						openUI()
					end
				end

				local chest_open_time = npc.data.chest_open_time

				if empty(chest_open_time) then
					chest_open_time = 25
				end

				InfoDungeon.getChance(npc, eventIndex, {
					type = 1
				}, function (rcvData)
					npc.getGatherLock = true

					local function onOpenChest()
						if npc:hasAction("open") then
							npc:setAction("open", 1, function ()
								if not isClosed then
									npc:setAction("opened", 1)
								end
							end)
							Looper.setTimeout(function ()
								onGetInfo(rcvData)
							end, chest_open_time, npc)
						else
							npc:setAction("opened", 1)
							onGetInfo(rcvData)
						end
					end

					if preFin == 0 and npc.data.type == 14 and not empty(npc.data.value4) then
						POP_aside.open(npc.data.value4, onOpenChest)
					else
						onOpenChest()
					end
				end, function (err)
				end)
			end
		elseif npc.data.type == 15 then
			FRAME_naraka_gate.open(npc, onChanceRequestOver)
		elseif npc.data.type == 16 then
			TaHelper.taGuideDetail(12500)
			InfoDungeon.getChance(npc, eventIndex, nil, function (rcvData)
				onChanceRequestOver()
				notify.dispatch("team_refresh_pet")

				local guide_pet_item = CsvParser.getCsvData("config", "guide_pet_item").value

				POP_reward.open({
					{
						type = DropManager.TYPE.ITEM,
						info = {
							base_id = guide_pet_item
						}
					}
				}, onClose, Localization.getSrcText("获得宠物蛋？"))
			end, function (err)
			end)
		elseif npc.data.type == 17 then
			InfoDungeon.getChance(npc, eventIndex, nil, function (rcvData)
				if npc.runeItem then
					npc.runeItem:flyToBag()

					npc.runeItem = nil
				end

				onChanceRequestOver()
			end, function (err)
			end)
		else
			InfoDungeon.getChance(npc, eventIndex)
		end
	end
end

return NavUtil
