local ArcEffectClip = import(".ArcEffectClip")
local ArcParticle = class("ArcParticle")

function ArcParticle:ctor(arcEffect, radius, angle, zpos)
	self.radius = radius
	self.angle = angle
	self.x = math.cos(angle) * radius
	self.y = math.sin(angle) * radius
	self.z = zpos
	self.container = arcEffect
	self.axialMotion = arcEffect.param.axialMotion:clone()
	self.radialMotion = arcEffect.param.radialMotion:clone()
	self.whirlMotion = arcEffect.param.whirlMotion:clone()
	self.reverseValue = 1
	self.count = 0
	self.lifeCount = 0
end

function ArcParticle:update()
	self.axialMotion:update()
	self.radialMotion:update()
	self.whirlMotion:update()

	self.preX = self.x
	self.preY = self.y
	self.preZ = self.z
	self.z = self.z + self.axialMotion.speed * self.reverseValue
	self.radius = self.radius + self.radialMotion.speed * self.reverseValue
	self.angle = self.angle + self.whirlMotion.speed * math.pi / 180
	local a = self.angle + self.whirlMotion.chaos
	self.x = math.cos(a) * self.radius
	self.y = math.sin(a) * self.radius
end

function ArcParticle:draw()
	if self.container.param.motion == ArcParam.MOTION_DUPLICATE then
		if self.count % math.floor(self.container.param.duplicateInterval) == 0 then
			local clip = ArcEffectClip.new()

			clip:load(self.container.param.particleType, self.container.param.clipURL)

			clip.z = self.z

			if self.container.center.x and self.container.center.y then
				clip:display(self.container.map, self.x + self.container.center.x, self.y + self.container.center.y)
			end

			if clip.rotate then
				clip:setRotateByPosition(self.container.map.topType == Map.TOP_90, self.x, self.y, self.z, self.preX, self.preY, self.preZ)
			else
				clip.angle = math.atan2(self.y - self.preY, self.x - self.preX)
			end

			clip:setAction("idle", 1, function (clipSelf)
				clipSelf:removeSelf()
			end)
		end

		self.count = self.count + 1
	else
		if self.clip == nil then
			self.clip = ArcEffectClip.new()

			self.clip:load(self.container.param.particleType, self.container.param.clipURL)

			self.clip.z = self.z

			if self.container.center.x and self.container.center.y then
				self.clip:display(self.container.map, self.x + self.container.center.x, self.y + self.container.center.y)
			end
		end

		self.clip.z = self.z

		if self.container.center.x and self.container.center.y then
			self.clip:draw(self.x + self.container.center.x, self.y + self.container.center.y, true)
		end

		if self.clip.rotate then
			self.clip:setRotateByPosition(self.container.map.topType == Map.TOP_90, self.x, self.y, self.z, self.preX, self.preY, self.preZ)
		else
			self.clip.angle = math.atan2(self.y - self.preY, self.x - self.preX)
		end
	end
end

function ArcParticle:destroy()
	if self.clip ~= nil then
		if self.clip:hasAction("die") then
			self.clip:setAction("die", 1, function (clipSelf)
				clipSelf:removeSelf()
			end)
		elseif self.clip.clipType == Clip.CLIP_TYPE.SPINE then
			self.clip:removeSelf()
		else
			self.clip:setOverFunc(function (clipSelf)
				clipSelf:removeSelf()
			end)
		end

		self.clip = nil
	end
end

function ArcParticle:reverse()
	self.reverseValue = -1 * self.reverseValue
end

return ArcParticle
