local POP_envcolor = class("POP_envcolor", UI_base)
local instance = nil

function POP_envcolor.open()
	if instance then
		instance:removeSelf()

		instance = nil
	end

	instance = POP_envcolor.new()
	POP_envcolor.opening = true

	global.map:setPositionOffset("POP_envcolor", -200, 0)
	display.getRunningScene():addChild(instance, LayerConfig.notice)
end

function POP_envcolor.close()
	if instance then
		instance:removeSelf()

		instance = nil
	end

	POP_envcolor.opening = false

	global.map:setPositionOffset("POP_envcolor", 0, 0)
end

function POP_envcolor.switchOpen()
	if instance then
		POP_envcolor.close()
	else
		POP_envcolor.open()
	end
end

function POP_envcolor:ctor()
	POP_envcolor.super.ctor(self, "pop_envcolor")
	self:init()
end

function POP_envcolor:init()
	self:initUI()

	self.color = global.map:getLightRGB()

	self:refreshRGB()

	local arr = {
		"r",
		"g",
		"b"
	}

	for i = 1, #arr do
		local drag = self:getComponentByTag("drag_" .. arr[i])
		local bar = self:getComponentByTag("bar_" .. arr[i])

		drag:toTouchable()
		drag:addTouch(function (event, x, y)
			local value = (y - drag.height / 2 - bar.y) / (bar.height - drag.height) * 255
			value = math.max(0, math.min(255, math.round(value)))
			self.color[arr[i]] = value

			self:refreshRGB()

			if event == "ended" then
				global.map:setLightRGB(self.color)
			end
		end)
	end

	self.light = global.map:getLightConfig()

	self:refreshLight()

	local arr = {
		"min",
		"radius"
	}
	local maxArr = {
		1,
		2
	}

	for i = 1, #arr do
		local drag = self:getComponentByTag("drag_" .. arr[i])
		local bar = self:getComponentByTag("bar_" .. arr[i])

		drag:toTouchable()
		drag:addTouch(function (event, x, y)
			local value = (y - drag.height / 2 - bar.y) / (bar.height - drag.height)
			value = math.max(0, math.min(1, value))
			self.light[arr[i]] = value * maxArr[i]

			self:refreshLight()

			if event == "ended" then
				global.map:setLightConfig(self.light)
			end
		end)
	end

	local testPB = self:getComponentByTag("test_bt")

	testPB:toTouchable()
	testPB:addTap(function ()
		MapEffect.natureLightning()
	end)

	local rain0PB = self:getComponentByTag("rain0_bt")

	rain0PB:toTouchable()
	rain0PB:addTap(function ()
		MapEffect.rainStop()
	end)

	local rain1PB = self:getComponentByTag("rain1_bt")

	rain1PB:toTouchable()
	rain1PB:addTap(function ()
		MapEffect.rain(1, 0)
	end)

	local rain2PB = self:getComponentByTag("rain2_bt")

	rain2PB:toTouchable()
	rain2PB:addTap(function ()
		MapEffect.rain(2, math.pi / 12)
	end)
end

function POP_envcolor:refreshLight()
	local maxArr = {
		1,
		2
	}

	self:createLabelOnFlag("flag_min", math.floor(self.light.min * 100) / 100)
	self:createLabelOnFlag("flag_radius", math.floor(self.light.radius * 100) / 100)

	local arr = {
		"min",
		"radius"
	}

	for i = 1, #arr do
		local drag = self:getComponentByTag("drag_" .. arr[i])
		local bar = self:getComponentByTag("bar_" .. arr[i])
		local value = self.light[arr[i]]

		drag:setPos(nil, bar.y + (bar.height - drag.height) * value / maxArr[i])
	end
end

function POP_envcolor:refreshRGB()
	local colorZone = self:getComponentByTag("color_zone")

	colorZone:setColor(self.color)
	self:createLabelOnFlag("flag_r", self.color.r)
	self:createLabelOnFlag("flag_g", self.color.g)
	self:createLabelOnFlag("flag_b", self.color.b)

	local arr = {
		"r",
		"g",
		"b"
	}

	for i = 1, #arr do
		local drag = self:getComponentByTag("drag_" .. arr[i])
		local bar = self:getComponentByTag("bar_" .. arr[i])
		local value = self.color[arr[i]]

		drag:setPos(nil, bar.y + (bar.height - drag.height) * value / 255)
	end
end

function POP_envcolor:initUI()
	local closePB = self:getComponentByTag("close_pb")

	closePB:toTouchable()
	closePB:addTap(function ()
		POP_envcolor.close()
	end)

	local bg = self:getComponentByTag("bg")

	bg:toTouchable()
end

return POP_envcolor
