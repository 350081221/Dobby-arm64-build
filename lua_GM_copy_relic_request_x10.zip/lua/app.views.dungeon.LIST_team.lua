local List = import("...ui.List")
local LIST_team = class("LIST_team", List)

function LIST_team:ctor(rect)
	LIST_team.super.ctor(self, rect)
	self:setCellName("cell_team")
	self:setSpace(0, 5)

	self.isBounc = false

	self:setCellSize(cc.size(self.touchRect.width, 85))
	self:setSelectEnabled(true)
end

function LIST_team:onCellInit(ui, heroInfo)
	local heroData = CsvParser.getCsvData("hero", heroInfo.base_id)

	if ui.portrait then
		ui.portrait:removeSelf()

		ui.portrait = nil
	end

	local affixData = CsvParser.getCsvData("hero_affix", heroInfo.affix)

	ui:createLabelOnFlag("flag_name", InfoHero.getName(heroInfo))
	ui:createLabelOnFlag("flag_job", heroData.job_name .. "[" .. affixData.name .. "]")

	local mugshotRect = ui:getRectByFlag("flag_mugshot")
	local portrait = PortraitManager.getHeroMugshot(heroInfo, mugshotRect, 3, 0, cc.p(2, 1))

	portrait:setPosition(mugshotRect.x + mugshotRect.width / 2, mugshotRect.y + mugshotRect.height / 2)
	ui:addChild(portrait, 100)

	ui.portrait = portrait
end

return LIST_team
