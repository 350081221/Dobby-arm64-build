local List = import(".List")
local Style = import(".Style")
local Scroller = class("Scroller", List)

function Scroller:ctor(rect, tapListener)
	Scroller.super.ctor(self, rect)

	self.isBounc = false

	if tapListener then
		self:addEventListener("onTapListIcon", function (event)
			tapListener(event.ui, event.data, event.index, event.x, event.y)
		end)
	end
end

function Scroller:getCellSize(index)
	return self.contentSize
end

function Scroller:getCellName(index)
	return ""
end

function Scroller:setContent(content, size)
	self.content = content
	self.contentSize = size

	self:setItems({
		{}
	})
end

function Scroller:onCellInit(ui, data)
	ui:addChild(self.content)
	self:setContentSize(self.contentSize)
end

function Scroller:onCellRemove(ui)
	if self.content then
		self.content:removeSelf()

		self.content = nil
	end
end

return Scroller
