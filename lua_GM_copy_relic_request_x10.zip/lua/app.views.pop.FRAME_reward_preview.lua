local FRAME_reward_preview = class("FRAME_reward_preview", UI_base)

function FRAME_reward_preview.open(rewardArr)
	local ui = FRAME_reward_preview.new(rewardArr)

	PopManager.open(ui)
end

function FRAME_reward_preview:ctor(rewardArr)
	FRAME_reward_preview.super.ctor(self, "frame_reward_preview", UIManager.BIG_TYPE.POP)

	self.rewardArr = rewardArr

	self:init()
end

function FRAME_reward_preview:init()
	self:initUI()

	local items = {}

	for i, v in ipairs(self.rewardArr) do
		table.insert(items, {
			label = v.label
		})
		table.insert(items, {
			arr = v.arr
		})
	end

	self.list:setItems(items)
end

function FRAME_reward_preview:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local function tapListener(ui, data, index, x, y)
		if ui.coms then
			local worldPos = self.list:convertToWorldSpace(cc.p(x, y))

			for i, com in ipairs(ui.coms) do
				local slot = com.slot

				if slot:hitTestByComponent("bg", worldPos.x, worldPos.y, true) then
					UIManager.callTapGroup("slot_click", slot, function ()
						DropManager.popDetail(slot.type, slot.info)
					end)

					break
				end
			end
		end
	end

	self.list = self:createListOnFlag("flag_list", function (rect)
		return LIST_reward_preview.new(rect, 6)
	end, tapListener)
end

return FRAME_reward_preview
