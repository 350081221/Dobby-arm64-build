local sprotoparser = require("sprotoparser")
local proto = {}
local struct = import("..proto.proto_struct")
local c2s = import("..proto.proto_c2s")
local s2c = import("..proto.proto_s2c")

local function initSproto()
	proto.c2s = sprotoparser.parse(struct .. c2s)
	proto.s2c = sprotoparser.parse(struct .. s2c)

	return proto
end

return initSproto()
