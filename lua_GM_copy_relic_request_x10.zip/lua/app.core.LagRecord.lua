local LagRecord = {}
local LAG_STACK_MAX = 100
local data = {}

function LagRecord.init(...)
	local path = cc.FileUtils:getInstance():getWritablePath() .. "lag_record.txt"

	if io.exists(path) then
		local contents = getFileString(path)
		local obj = json.decode(contents)

		if obj ~= nil then
			data = obj
		end
	end
end

function LagRecord.flush()
	dump(data, "$$$ LagRecord.flush")

	local path = cc.FileUtils:getInstance():getWritablePath() .. "lag_record.txt"

	io.writefile(path, json.encode(data))
end

function LagRecord.track()
	local obj = {
		average = 0,
		variance = 0
	}

	if data.avrCount > 0 then
		obj.average = data.avrTotal / data.avrCount
	end

	if data.varCount > 0 then
		obj.variance = data.varTotal / data.varCount
	end

	if obj.average ~= 0 and obj.variance ~= 0 then
		TaHelper.taTrack("daily_lag", obj)
	end
end

function LagRecord.compact()
	if #data.lagStack > 0 then
		local avr = 0

		if data.lagCount > 0 then
			avr = data.lagTotal / data.lagCount
		end

		local varTotal = 0
		local varCount = #data.lagStack

		for i, lag in ipairs(data.lagStack) do
			varTotal = varTotal + math.pow(lag - avr, 2)
		end

		local var = 0

		if varCount > 0 then
			var = math.sqrt(varTotal / varCount)
		end

		data.avrTotal = data.avrTotal + avr
		data.avrCount = data.avrCount + 1
		data.varTotal = data.varTotal + var
		data.varCount = data.varCount + 1
		data.lagStack = {}
		data.lagTotal = 0
		data.lagCount = 0
	end
end

function LagRecord.add(lag)
	local today = Time.getToday()

	if data.day ~= today and data.day then
		LagRecord.compact()
		LagRecord.track()
	end

	data.day = today
	data.varTotal = data.varTotal or 0
	data.varCount = data.varCount or 0
	data.avrTotal = data.avrTotal or 0
	data.avrCount = data.avrCount or 0
	data.lagStack = data.lagStack or {}
	data.lagTotal = data.lagTotal or 0
	data.lagCount = data.lagCount or 0

	table.insert(data.lagStack, lag)

	data.lagTotal = data.lagTotal + lag
	data.lagCount = data.lagCount + 1

	if LAG_STACK_MAX <= #data.lagStack then
		LagRecord.compact()
		LagRecord.flush()
	end
end

return LagRecord
