local UI_base = import("..UI_base")
local FRAME_achieve = class("FRAME_achieve", UI_base)

function FRAME_achieve.open()
	local ui = FRAME_achieve.new()

	ui:onOpen()
	PopManager.open(ui, nil, function ()
		ui:onClose()
	end, nil, 100)
end

function FRAME_achieve:ctor()
	FRAME_achieve.super.ctor(self, "frame_achieve", UIManager.BIG_TYPE.POP)
	self:init()
end

function FRAME_achieve:init()
	self:initUI()

	self.selectedIndex = 1

	self:refresh()
	ManagerInfo.onDataChange(self, "achieve", nil, function (idStack)
		self:refresh(true)
	end)
end

function FRAME_achieve:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local function tapListener(ui, data, index, x, y)
		if ui.slot then
			local worldPos = self.list:convertToWorldSpace(cc.p(x, y))

			if ui.slot:hitTestByComponent("bg", worldPos.x, worldPos.y, true) then
				if data.csv.value <= data.count then
					InfoAchieve.getReward(data.csv.id, function (rcvData)
						local rewards = rcvData.rewards

						if rewards and #rewards > 0 then
							POP_reward.openMixed(rewards, nil, Localization.getSrcText("成就奖励"))
						end
					end)
				else
					Alert.open(Localization.getSrcText("达成后可领取"))
				end
			end
		end
	end

	self.list = self:createListOnFlag("flag_list", LIST_achieve, tapListener)

	self.list:setTapGroup("list_click")

	local holder = self:getComponentByTag("holder")

	self.list:setHolders({
		holder
	}, nil, 5)

	local function tapLabelListener(ui, data, index)
		if index ~= self.selectedIndex then
			self.selectedIndex = index

			self:refresh()
		end
	end

	self.labelList = self:createListOnFlag("flag_list_label", LIST_achieve_label, tapLabelListener)

	self.labelList:setTapGroup("list_click")
end

function FRAME_achieve:refresh(keepOffset)
	local labelList = InfoAchieve.getLabelList()

	self.labelList:setItems(labelList)
	self.labelList:setSelectedIndex(self.selectedIndex)

	local labelData = self.labelList:getSelectedItem().csv
	local label = labelData.id
	local items, doneCount = InfoAchieve.getList(label)

	self.list:setItems(items, keepOffset)
	self:replaceLabelOnFlag("flag_desc", nil, doneCount)
end

function FRAME_achieve:onOpen()
end

function FRAME_achieve:onClose()
end

return FRAME_achieve
