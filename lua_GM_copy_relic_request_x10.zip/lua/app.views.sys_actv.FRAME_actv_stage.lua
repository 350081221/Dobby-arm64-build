local UI_base = import("..UI_base")
local FRAME_actv_stage = class("FRAME_actv_stage", UI_base)

function FRAME_actv_stage:ctor(uiName, data)
	self.actv_id = data and data.actv_id
	local csv = InfoActvStage.getCurrentCSV(self.actv_id)
	self.isSp = csv.type == 4
	self.isFinal = csv.type == 3
	uiName = "iframe_actv_stage"

	if self.isSp then
		uiName = "iframe_actv_stage_sp"
	elseif self.isFinal then
		uiName = "iframe_actv_stage_final"
	end

	FRAME_festival_stage.super.ctor(self, uiName)
	self:init()
end

function FRAME_actv_stage:init()
	self:initUI()
	self:refresh()
	ManagerInfo.onDataChange(self, "actv_stage", nil, function ()
		self:refresh()
	end)

	if self.isSp then
		self:selectSp(1)
	end
end

function FRAME_actv_stage:resetData(data)
	if data then
		self.actv_id = data and data.actv_id

		self:refresh()
	end
end

function FRAME_actv_stage:refresh()
	local csv = InfoActvStage.getCurrentCSV(self.actv_id)
	self.csv = csv

	if self.spCells then
		for i, cell in ipairs(self.spCells) do
			cell:removeSelf()
		end

		self.spCells = nil
	end

	if self.rewardList then
		self.rewardList:removeSelf()

		self.rewardList = nil
	end

	if self.isSp then
		local flag = self:getFlagByTag("flag_sp_list")
		self.spCells = {}
		local spArr = SheetUtil.getColumnValueList(csv, "sp")
		self.spArr = spArr

		for i, spID in ipairs(spArr) do
			local spCSV = CsvParser.getCsvData("hero_sp", spID)
			local cell = UIManager.getUI("cell_actv_stage_sp")

			self:addChild(cell, 100)
			cell:setPosition(flag.x + (i - 1) * 100, flag.y)
			table.insert(self.spCells, cell)
			cell:createClippingOnFlag("pic_mask", "sp_stage_btn", spCSV.pic, 1000)

			local selected = cell:getComponentByTag("selected")

			selected:setLocalZOrder(1100)
			selected:setVisible(false)

			local redot = cell:getComponentByTag("redot")

			redot:setVisible(InfoActvStage.getRecordSp(self.actv_id, i) == 0)
			redot:setLocalZOrder(1200)

			local bg = cell:getComponentByTag("bg")

			bg:toTouchable()
			bg:setTapGroup("bg_click")
			bg:addTap(function ()
				self:selectSp(i)
			end)
		end
	else
		self:createLabelOnFlag("flag_name", csv.name)

		local desc = string.gsub(csv.desc, "\\n", "\n")

		self.textArea:setText(desc)

		local _pic = empty(csv.pic) or self:createPicOnFlag("pic_mask", IconManager.getCampaignPic(csv.pic), nil, UILayout.SCALE_TYPE.LARGE)
		local rewardArr = InfoActvStage.getRewardList(self.actv_id)
		local rewardFlag = self:getFlagByTag("flag_reward_list")
		rewardFlag.width = #rewardArr * rewardFlag.originalWidth
		local label_reward = self:getComponentByTag("label_reward")
		local rewardList = self:createListOnFlag("flag_reward_list", RewardList)

		rewardList:setAlwaysShowNumber(true)
		rewardList:setItems(rewardArr)

		self.rewardList = rewardList
		local rewardCount, rewardMax = InfoActvStage.stageRecord(self.actv_id)
		local color = Style.font3

		if rewardMax <= rewardCount then
			color = Style.disableColor
		end

		self:replaceLabelGroupOnFlag("flag_reward_times", {
			rewardMax - rewardCount,
			rewardMax
		}, {
			{
				color = color
			}
		})

		local bt_match = self:getComponentByTag("bt_match")
		local bt_create_room = self:getComponentByTag("bt_create_room")
		local bt_join_room = self:getComponentByTag("bt_join_room")
		local bt_enter = self:getComponentByTag("bt_enter")
		local bt_enter2 = self:getComponentByTag("bt_enter2")
		local bt_level = self:getComponentByTag("bt_level")
		local bt_ranking = self:getComponentByTag("bt_ranking")
		local bt_hint = self:getComponentByTag("bt_hint")
		local level_bg = self:getComponentByTag("level_bg")

		bt_match:setVisible(false)
		bt_create_room:setVisible(false)
		bt_join_room:setVisible(false)
		bt_enter:setVisible(false)
		bt_enter2:setVisible(false)
		bt_level:setVisible(false)
		bt_ranking:setVisible(false)
		bt_hint:setVisible(false)
		level_bg:setVisible(false)
		self:removeLabelOnFlag("flag_level_1")
		self:removeLabelOnFlag("flag_level_2")
		self:removeLabelGroupOnFlag("flag_level_1")
		self:removeLabelGroupOnFlag("flag_level_2")

		if csv.type == 1 then
			bt_enter:setVisible(true)
		elseif csv.type == 2 then
			bt_match:setVisible(true)
			bt_create_room:setVisible(true)
			bt_join_room:setVisible(true)
		elseif csv.type == 3 then
			bt_enter2:setVisible(true)
			bt_level:setVisible(true)
			bt_ranking:setVisible(true)
			level_bg:setVisible(true)

			if not empty(self.csv.rank_reward_id) then
				bt_hint:setVisible(true)
			end

			local minLevel, maxLevel, currLevel, passedLevel = InfoActvStage.getLevel(self.actv_id, csv.id)

			print("$$$ minLevel, maxLevel, currLevel, passedLevel", minLevel, maxLevel, currLevel, passedLevel)

			local style = {
				size = 22,
				color = Style.font3
			}

			if minLevel then
				if passedLevel == 0 then
					self:replaceLabelGroupOnFlag("flag_level_1", {
						"--"
					}, {
						style
					})
				else
					self:replaceLabelGroupOnFlag("flag_level_1", {
						passedLevel
					}, {
						style
					})
				end

				self:replaceLabelGroupOnFlag("flag_level_2", {
					currLevel,
					minLevel,
					maxLevel
				}, {
					style,
					style,
					style
				})
			else
				self:replaceLabelGroupOnFlag("flag_level_1", {
					"--"
				}, {
					style
				})
				self:replaceLabelGroupOnFlag("flag_level_2", {
					"--",
					"--",
					"--"
				}, {
					style,
					style,
					style
				})
			end
		end

		if self.isFinal then
			local preFinalTime = nil

			local function refreshFinal()
				local data = InfoActvStage.getData(self.actv_id)
				local stime, etime = InfoActv.getTime(self.actv_id)
				local finalTime = math.floor(etime - data.final_hour * Time.SECONDS_PER_HOUR)
				local nowTime = Time.now()

				if preFinalTime ~= finalTime then
					preFinalTime = finalTime
					local style = {
						color = Style.font3
					}
					local inFinal = finalTime < Time.now()

					if inFinal then
						style.color = Style.disableColor
					end

					self:replaceLabelGroupOnFlag("flag_final", {
						StringUtil.mdtFormat(finalTime)
					}, {
						style
					})
					self.rewardList:setVisible(not inFinal)

					if inFinal then
						self:removeLabelOnFlag("label_reward")
						self:removeLabelOnFlag("flag_reward_times")
						self:removeLabelGroupOnFlag("flag_reward_times")
					end

					local label_final_time = self:getComponentByTag("label_final_time")

					label_final_time:setVisible(inFinal)

					local in_final = self:getComponentByTag("in_final")

					in_final:setVisible(inFinal)

					if inFinal then
						local timeleft = math.floor(etime - nowTime)

						self:createLabelOnFlag("flag_final_time", Time.showSec(timeleft))
						bt_enter2:setVisible(false)
						bt_level:setVisible(false)
					end
				end
			end

			refreshFinal()
			self:addEnterFrame("refreshFinal", refreshFinal)
		end
	end
end

function FRAME_actv_stage:selectSp(index)
	local csv = InfoActvStage.getCurrentCSV(self.actv_id)
	self.spIndex = index

	if self.spCells then
		for i, cell in ipairs(self.spCells) do
			local selected = cell:getComponentByTag("selected")

			selected:setVisible(self.spIndex == i)
		end
	end

	local spID = self.spArr[self.spIndex]

	if spID then
		local spCsv = CsvParser.getCsvData("hero_sp", spID)

		self:createLabelOnFlag("flag_name", spCsv.name)

		local desc = string.gsub(spCsv.story_text, "\\n", "\n")

		self.textArea:setText(desc)

		if not empty(spCsv.sp_demo_pic) then
			local originalPic = self:createPicOnFlag("pic_mask", IconManager.getCampaignPic(spCsv.sp_demo_pic), nil, UILayout.SCALE_TYPE.LARGE)

			originalPic:setOpacity(100)
			transition.fadeTo(originalPic, {
				time = 0.3,
				opacity = 255,
				easing = "sineOut"
			})
		end

		if self.rewardList then
			self.rewardList:removeSelf()

			self.rewardList = nil
		end

		local rewardArr = SheetUtil.getColumnList(csv, {
			"sp" .. self.spIndex .. "_reward_",
			"sp" .. self.spIndex .. "_reward_num_"
		}, {
			"base_id",
			"num"
		})
		local rewardFlag = self:getFlagByTag("flag_reward_list")
		rewardFlag.width = #rewardArr * rewardFlag.originalWidth
		local label_reward = self:getComponentByTag("label_reward")
		local rewardList = self:createListOnFlag("flag_reward_list", RewardList)

		rewardList:setAlwaysShowNumber(true)
		rewardList:setItems(rewardArr)

		self.rewardList = rewardList
		local label_reward_already = self:getComponentByTag("label_reward_already")

		label_reward_already:setVisible(InfoActvStage.getRecordSp(self.actv_id, self.spIndex) > 0)
	end
end

function FRAME_actv_stage:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local bt_enter = self:getComponentByTag("bt_enter")

	local function enterStage()
		local csv = self.csv
		local minLevel, maxLevel, currLevel, passedLevel = InfoActvStage.getLevel(self.actv_id, csv.id)

		print("$$$ enterStage", minLevel, maxLevel, currLevel, passedLevel)

		local function onSuccess(result)
			InfoDungeon.enterStage(result)
			DungeonScene.enterDungeon(DungeonScene.ENTER_TYPE.NEW, result)
		end

		InfoActvStage.enterStage(self.actv_id, csv.id, currLevel, self.spIndex, onSuccess)
	end

	bt_enter:toTouchable()
	bt_enter:setTapGroup("button_click")
	bt_enter:addTap(enterStage)

	self.textArea = self:createTextAreaOnFlag("flag_desc")

	self.textArea:setUbbEnabled(true)
	self.textArea:setSpace(5, 5)

	if not self.isSp then
		local bt_match = self:getComponentByTag("bt_match")
		local bt_create_room = self:getComponentByTag("bt_create_room")
		local bt_join_room = self:getComponentByTag("bt_join_room")
		local bt_level = self:getComponentByTag("bt_level")
		local bt_enter2 = self:getComponentByTag("bt_enter2")
		local bt_ranking = self:getComponentByTag("bt_ranking")
		local bt_hint = self:getComponentByTag("bt_hint")

		bt_hint:toTouchable()
		bt_hint:setTapGroup("button_click")
		bt_hint:addTap(function ()
			FRAME_actv_stage_rule.open(self.csv)
		end)
		bt_ranking:toTouchable()
		bt_ranking:setTapGroup("button_click")
		bt_ranking:addTap(function ()
			local csv = self.csv

			FRAME_actv_stage_ranking.open(self.actv_id)
		end)
		bt_enter2:toTouchable()
		bt_enter2:setTapGroup("button_click")
		bt_enter2:addTap(enterStage)
		bt_match:toTouchable()
		bt_match:setTapGroup("button_click")
		bt_match:addTap(function ()
			local csv = self.csv

			if not InfoActvStage.checkOpening(self.actv_id) then
				Alert.open(Localization.getSrcText("活动未在开启中"))

				return
			end

			InfoActvStage.match(self.actv_id, csv.id, function (rcvData)
				FRAME_unified_room.open(csv, rcvData)
			end)
		end)
		bt_create_room:toTouchable()
		bt_create_room:setTapGroup("button_click")
		bt_create_room:addTap(function ()
			local csv = self.csv

			if not InfoActvStage.checkOpening(self.actv_id) then
				Alert.open(Localization.getSrcText("活动未在开启中"))

				return
			end

			InfoActvStage.create(self.actv_id, csv.id, function (rcvData)
				FRAME_unified_room.open(csv, rcvData)
			end)
		end)
		bt_join_room:toTouchable()
		bt_join_room:setTapGroup("button_click")
		bt_join_room:addTap(function ()
			local csv = self.csv

			if not InfoActvStage.checkOpening(self.actv_id) then
				Alert.open(Localization.getSrcText("活动未在开启中"))

				return
			end

			POP_notice_input.open(Localization.getSrcText("输入房间号"), Localization.getSrcText("大小写不敏感"), "", nil, function (code)
				local inst_id = InfoUser.decodeID(code)

				if inst_id then
					InfoActvStage.join(self.actv_id, csv.id, inst_id, function (rcvData)
						FRAME_unified_room.open(csv, rcvData)
					end)
				else
					Alert.open(Localization.getSrcText("房间不存在"))
				end
			end)
		end)
		bt_level:toTouchable()
		bt_level:setTapGroup("button_click")
		bt_level:addTap(function ()
			local csv = self.csv

			if not InfoActvStage.checkOpening(self.actv_id) then
				Alert.open(Localization.getSrcText("活动未在开启中"))

				return
			end

			local minLevel, maxLevel, currLevel, passedLevel = InfoActvStage.getLevel(self.actv_id, csv.id)

			if minLevel then
				local str = Localization.getSrcText("难度范围：{1}~{2}")
				str = StringUtil.replace(str, minLevel, maxLevel)

				POP_level_select.open(Localization.getSrcText("选择难度：{1}"), str, currLevel, minLevel, maxLevel, function (level)
					if level ~= currLevel then
						InfoActvStage.setLevel(self.actv_id, level)
					end
				end)
			end
		end)
	end
end

return FRAME_actv_stage
