local POP_marquee = class("POP_marquee", UI_base)
local marqQueue = {}

function POP_marquee.add(msg, time)
	if not POP_marquee.instance then
		POP_marquee.new()
	end

	local nowTime = Time.time()
	local data = {
		count = 0,
		msg = msg,
		time = time,
		quequeTime = nowTime
	}

	if time then
		data.time = nowTime + time
	end

	POP_marquee.instance:addOne(data)
end

function POP_marquee:ctor()
	POP_marquee.super.ctor(self, "pop_marquee", UIManager.BIG_TYPE.TOP)

	POP_marquee.instance = self

	display.getRunningScene():addChild(self, LayerConfig.marquee)
	self:init()
end

function POP_marquee:init()
	self.oneStack = {}
	local bg = self:getComponentByTag("bg")

	bg:setOpacity(0)

	local rect = self:getFlagByTag("flag_rect")
	local container = display.newClippingRectangleNode(cc.rect(rect.x, rect.y, rect.width + 1, rect.height + 1))

	self:addChild(container, 100)

	self.container = container

	notify.safeRegister(self, "marquee_push", function (data)
		POP_marquee.add(data.msg, data.time)
	end)
	self:checkOpen()
end

local spaceX = 100
local speedX = 2
local nextInterval = 5

function POP_marquee:addOne(data)
	local oneStack = self.oneStack

	table.insert(marqQueue, data)

	if #marqQueue == 1 then
		self:checkOpen()
	end
end

function POP_marquee:checkOpen()
	if #marqQueue > 0 then
		local bg = self:getComponentByTag("bg")

		transition.fadeTo(bg, {
			time = 0.2,
			opacity = 150
		})
		self:addEnterFrame("marquee_update", function (dt)
			self:update(dt)
		end)
	end
end

function POP_marquee:getNextMarq(nowTime)
	local newQueue = {}

	for i, v in ipairs(marqQueue) do
		if v.time then
			if nowTime <= v.time then
				table.insert(newQueue, v)
			end
		elseif v.count == 0 then
			table.insert(newQueue, v)
		end
	end

	marqQueue = newQueue
	local bestMarq, bestTime = nil

	for i, v in ipairs(marqQueue) do
		if not bestTime or v.quequeTime < bestTime then
			bestTime = v.quequeTime
			bestMarq = v
		end
	end

	return bestMarq
end

function POP_marquee:update(dt)
	local timeScale = dt * 60
	local nowTime = Time.time()
	local oneStack = self.oneStack
	local flag_rect = self:getFlagByTag("flag_rect")
	local needNew = true

	if oneStack and #oneStack > 0 then
		local lastOne = oneStack[#oneStack]
		local lastOneX = lastOne:getPositionX()

		if math.max(lastOneX + flag_rect.width / 2, lastOneX + lastOne.width + spaceX) > flag_rect.x + flag_rect.width / 2 then
			needNew = false
		end
	end

	if needNew then
		local nextMarq = self:getNextMarq(nowTime)

		if nextMarq then
			nextMarq.count = nextMarq.count + 1
			nextMarq.quequeTime = nowTime
			local one = UIManager.getUI("pop_marquee_one")

			one:setPositionX(flag_rect.x + flag_rect.width)
			one:setPositionY(flag_rect.y)

			local ubbMap, labels, lines, totalWidth, totalHeight = one:createUbbOnFlag("flag_text", Localization.getTextByLang(nextMarq.msg), {
				align = Style.left,
				valign = Style.vcenter
			})
			one.width = totalWidth

			self.container:addChild(one, 100)
			table.insert(oneStack, one)
		end
	end

	local newStack = {}
	local speed = speedX * timeScale

	for i, one in ipairs(oneStack) do
		local x = one:getPositionX() - speed

		one:setPositionX(x)

		if x + one.width < flag_rect.x then
			one:removeSelf()
		else
			table.insert(newStack, one)
		end
	end

	self.oneStack = newStack
	oneStack = self.oneStack

	if #oneStack == 0 then
		local bg = self:getComponentByTag("bg")

		transition.fadeTo(bg, {
			time = 0.2,
			opacity = 0
		})
		self:removeEnterFrame("marquee_update")
	end
end

function POP_marquee:onExit()
	self:removeEnterFrame("marquee_update")

	POP_marquee.instance = nil

	POP_marquee.super.onExit(self)
end

return POP_marquee
