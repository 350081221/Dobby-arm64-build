local List = import("...ui.List")
local LIST_abyss_boss_neo = class("LIST_abyss_boss_neo", List)

function LIST_abyss_boss_neo:ctor(rect)
	LIST_abyss_boss_neo.super.ctor(self, rect)
	self:setCellName("cell_abyss_boss_neo")
	self:setSpace(5, 5)
	self:setCellSize(cc.size(self.touchRect.width, 130))
	self:setSelectEnabled(true)
end

function LIST_abyss_boss_neo:onCellInit(ui, csv, index)
	ui:createLabelOnFlag("flag_name", csv.name)
	ui:createLabelOnFlag("flag_subtitle", csv.subtitle)

	if ui.unit then
		ui.unit:removeSelf()

		ui.unit = nil
	end

	local unit = Monster.new()
	ui.unit = unit

	ui:addChild(unit, 100)

	local unitFlag = ui:getFlagByTag("flag_unit")

	unit:setPosition(unitFlag.x + unitFlag.width / 2, unitFlag.y + csv.model_y)
	unit:setInfo({
		level = 1,
		base_id = csv.model_show
	})

	local action = "idle"

	unit:setAction(action)

	local unitHeight = unit:getActionHeight(action)
	unitHeight = math.max(1, unitHeight)

	unit:rawSetScale(math.min(2, unitFlag.height / unitHeight))
	unit:randomizeFrame()
	unit:selfUpdate()
	self:onCellSelected(ui, csv, self.selectedIndex == index, true)
end

function LIST_abyss_boss_neo:onCellSelected(ui, csv, selected, isInit)
	local _selected = ui:getComponentByTag("selected")

	_selected:setVisible(selected)

	if isInit then
		if selected then
			ui:setOpacity(255)
		else
			ui:setOpacity(150)
		end
	elseif selected then
		transition.stopTarget(ui)
		transition.fadeTo(ui, {
			time = 0.2,
			opacity = 255
		})
	else
		transition.stopTarget(ui)
		transition.fadeTo(ui, {
			time = 0.2,
			opacity = 200
		})
	end
end

function LIST_abyss_boss_neo:onCellRemove(ui, data, index)
	if ui.unit then
		ui.unit:removeSelf()

		ui.unit = nil
	end
end

return LIST_abyss_boss_neo
