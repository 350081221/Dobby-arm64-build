local ConfParser = {}

function ConfParser.getLocalData(path)
	if cc.FileUtils:getInstance():isFileExist(path) then
		local contents = cc.FileUtils:getInstance():getStringFromFile(path)

		return ConfParser.parse(contents)
	end
end

function ConfParser.parse(contents, separetor)
	if not contents then
		return {}
	end

	local tbl = {}
	local lines = nil

	if separetor then
		lines = string.split(contents, separetor)
	else
		lines = {}

		for line in contents:gmatch("[^\r\n]+") do
			table.insert(lines, line)
		end
	end

	for i = 1, #lines do
		local line = lines[i]

		if line:sub(1, 2) ~= "//" then
			local parts = string.split(line, "=")

			if #parts == 2 then
				local key = string.trim(parts[1])
				local value = string.trim(parts[2])

				if value ~= "" then
					value = value == "true" and true or (value ~= "false" or false) and (tonumber(value) or value)
					local keys = string.split(key, ".")
					local obj = tbl

					for j = 1, #keys do
						if j == #keys then
							obj[keys[j]] = value
						else
							if not obj[keys[j]] then
								obj[keys[j]] = {}
							end

							obj = obj[keys[j]]
						end
					end
				end
			end
		end
	end

	return tbl
end

return ConfParser
