local WarMachine = {}
local campStack = {
	{},
	{}
}
local campCount = {
	0,
	0
}
local unitStack = {}
local readyToRemoveStack = {}
local thinkFreezeArray = {}
local thinkFreezeTime = 0
local updateIndex = 1
local checkIndex = 1
local dropOccupiedItemMap = {}
local dropItemStack = {}
local summonedStack = {}
local petStack = {}
local petActiveTime = 0
local petReadyStack = {}
local petPrepareData = {}
local benefitStack = {}
local serverDropList = {}
local eventDataStack = {}
local monsterGroups = {}
local nextWaveTime = nil
local everMonsterGroups = {}
local startMaxClass = 0
WarMachine.waitingForNextWave = false
WarMachine.mapLocked = false
WarMachine.on = false
WarMachine.paused = false
WarMachine.frame = 0
WarMachine.preFrame = 0
WarMachine.seed = 0
WarMachine.random = nil

function WarMachine.getMaxClass()
	return startMaxClass
end

local attrCheckCount = 0
local attrCheckMap = {}
local checkinst = {}
local checksum = {}
local preCheckSum = nil
local preWarnCount = 0
local instWarnCount = 0
local customWarnCount = 0
local csvHashMap = {}

function WarMachine.clearCheck()
	attrCheckCount = 0
	attrCheckMap = {}
	checkinst = {}
	checksum = {}
	preCheckSum = nil
	preWarnCount = 0
	instWarnCount = 0
	customWarnCount = 0
	csvHashMap = {}

	CsvParser.setCheckFunc(WarMachine.addCsvCheck)
end

local function attrAddup(attrList, originaldata, attrs, type, seed)
	local random = Random.new(seed)

	for _, obj in ipairs(attrList) do
		local attr = obj.attr
		local mul = obj.mul
		local add = obj.add
		local attr_index = obj.attr_index
		local attr_multi = obj.attr_multi
		local attrCSV = CsvParser.getCsvData("attr", attr)

		if (type ~= CombatUnit.BUFF_TYPE.SHRINE or attrCSV.type == 1) and attrs[attr] then
			if not empty(mul) then
				attrs[attr] = attrs[attr] + originaldata[attr] * SheetUtil.getNumber(mul, random) / 100
			end

			if not empty(add) then
				attrs[attr] = attrs[attr] + SheetUtil.getNumber(add, random)
			end

			if not empty(attr_index) and not empty(attr_multi) then
				attrs[attr] = attrs[attr] + originaldata[attr_index] * SheetUtil.getNumber(attr_multi, random) / 100
			end
		end
	end
end

function WarMachine.checkAttr(unit)
	if app.sceneName == "ArenaScene" then
		return true
	end

	local data = nil
	local ty = 0

	if unit.type == "hero" then
		ty = 1
		data = CombatAttr.getHeroAttr(unit.info)
	elseif unit.type == "monster" then
		ty = 2
		data = CombatAttr.getMonsterAttr(unit.info)
	elseif unit.type == "pet" then
		if not unit.info.isCopy then
			ty = 3
			data = CombatAttr.getPetAttr(unit.info)
		else
			return true
		end
	elseif unit.type == "modao" then
		ty = 10
		data = CombatAttr.getModaoAttr(unit.info.level)
	else
		return true
	end

	if not attrCheckMap[tostring(unit.id)] then
		local _obj = {
			cte = 0,
			ct = 0,
			ty = ty
		}

		if unit.type == "modao" then
			_obj.level = unit.info.level
		end

		attrCheckMap[tostring(unit.id)] = _obj
	end

	local obj = attrCheckMap[tostring(unit.id)]
	obj.ct = obj.ct + 1

	if (ty == 1 or ty == 3 or ty == 10) and not obj.attrs then
		obj.id = unit.info.id
		local attrs = {}

		for k, v in pairs(data) do
			attrs[k] = v
		end

		if unit.type == "hero" then
			local buffTypeArr = unit.buffStackMap[CombatUnit.BUFF_TYPE.SHRINE]

			if not empty(buffTypeArr) then
				for i, buffObj in ipairs(buffTypeArr) do
					if not SkillManager.isNoneAttrBuff(buffObj.id) then
						local buffData = CsvParser.getCsvData("buff", buffObj.id)
						local attrList = SheetUtil.getColumnList(buffData, {
							"attr_",
							"mul_value_",
							"add_value_",
							"attr_index",
							"attr_multi"
						}, {
							"attr",
							"mul",
							"add",
							"attr_index",
							"attr_multi"
						})

						if #attrList == 0 then
							SkillManager.markNoneAttrBuff(buffObj.id)
						else
							attrAddup(attrList, data, attrs, type, buffObj.seed)
						end
					end
				end
			end
		end

		CombatAttr.finalize(attrs)

		obj.attrs = {}
		local attrIndexList = CombatAttr.getAttrIndexList()

		for i, attr in ipairs(attrIndexList) do
			table.insert(obj.attrs, attrs[attr])
		end
	end

	local attrs = {}

	for k, v in pairs(data) do
		attrs[k] = v
	end

	if unit.buffStackMap then
		for type, buffTypeArr in pairs(unit.buffStackMap) do
			if not empty(buffTypeArr) then
				for i, buffObj in ipairs(buffTypeArr) do
					if not SkillManager.isNoneAttrBuff(buffObj.id) then
						local buffData = CsvParser.getCsvData("buff", buffObj.id)
						local attrList = SheetUtil.getColumnList(buffData, {
							"attr_",
							"mul_value_",
							"add_value_",
							"attr_index",
							"attr_multi"
						}, {
							"attr",
							"mul",
							"add",
							"attr_index",
							"attr_multi"
						})

						if #attrList == 0 then
							SkillManager.markNoneAttrBuff(buffObj.id)
						else
							attrAddup(attrList, data, attrs, type, buffObj.seed)
						end
					end
				end
			end
		end
	end

	CombatAttr.finalize(attrs)

	if unit.type == "monster" then
		if unit.affixArr then
			for i, affixData in ipairs(unit.affixArr) do
				local random = Random.new(unit.seed)
				local attrList = SheetUtil.getColumnList(affixData, {
					"attr_",
					"mul_value_",
					"add_value_"
				}, {
					"attr",
					"mul",
					"add"
				})

				attrAddup(attrList, data, attrs, nil, random:getInt(1, 65535))
			end
		end

		if InfoDungeon.isAkasa() then
			local baseData = CsvParser.getCsvData("monster_base_num", unit.info.level)

			for i, attr in ipairs(CombatAttr.attrs) do
				local ratio = baseData["akasa_" .. attr .. "_ratio"]

				if not empty(ratio) then
					attrs[attr] = math.floor(attrs[attr] * ratio)
				end
			end
		end

		if InfoNaraka.inNarakaBoss() then
			local baseData = CsvParser.getCsvData("monster_base_num", unit.info.level)

			for i, attr in ipairs(CombatAttr.attrs) do
				local ratio = baseData["naraka_" .. attr .. "_ratio"]

				if not empty(ratio) then
					attrs[attr] = math.floor(attrs[attr] * ratio)
				end
			end
		end
	end

	for k, v in pairs(unit.attrs) do
		if attrs[k] and attrs[k] ~= 0 and v ~= 0 then
			local gap = attrs[k] / v

			if gap < 0.8 or gap > 1.2 then
				attrCheckCount = attrCheckCount + 1
				obj.cte = obj.cte + 1

				return false
			end
		end
	end

	return true
end

function WarMachine.getCheckAttr()
	return attrCheckCount, attrCheckMap
end

function WarMachine.addCustomCheck(count)
	count = count or 1
	customWarnCount = customWarnCount + count
end

function WarMachine.addCsvCheck(csvData)
	if csvData and csvData.id and csvData.__file ~= "shrine" then
		if not csvHashMap[csvData.__file] then
			csvHashMap[csvData.__file] = {}
		end

		csvHashMap[csvData.__file][csvData.id] = csvData.id
	end
end

local function dumpCheckSum()
	preCheckSum = ObjUtil.copy(checksum)
	checksum = {}
	checkinst = {}
	preWarnCount = instWarnCount + customWarnCount
	instWarnCount = 0
	customWarnCount = 0
	local checkFail = false
	local checkFailArr = {}

	for fileName, hashMap in pairs(csvHashMap) do
		for id, _ in pairs(hashMap) do
			local csvData = CsvParser.getCsvData(fileName, id)
			local hash, hashStr = CsvParser.getHash(csvData)

			if hash ~= csvData.__hash then
				preWarnCount = preWarnCount + 10
				checkFail = true

				table.insert(checkFailArr, {
					file = fileName,
					id = id,
					str = hashStr
				})

				if #checkFailArr >= 5 then
					break
				end
			end
		end
	end

	csvHashMap = {}

	CsvParser.clearCheckFunc()
end

function WarMachine.makeCheckSum()
	dumpCheckSum()
end

function WarMachine.addCheckSum(id, hp, offset)
	if not checksum[id] then
		checksum[id] = {}
	end

	table.insert(checksum[id], {
		hp,
		offset
	})
end

function WarMachine.getCheckSum()
	local sumStack = {}

	if preCheckSum then
		for id, stack in pairs(preCheckSum) do
			sumStack[tostring(id)] = {}

			if #stack > 1 then
				for i = 1, 5 do
					local ranIndex = math.random(1, #stack - 1)

					table.insert(sumStack[tostring(id)], {
						ranIndex,
						stack[ranIndex][1],
						stack[ranIndex + 1][1],
						stack[ranIndex + 1][2]
					})
				end
			else
				table.insert(sumStack[tostring(id)], {
					stack[1][1]
				})
			end
		end
	end

	return preWarnCount, sumStack
end

function WarMachine.onHpChange(unit, hp, offset, fromOnline)
	if unit.reinitSkills then
		unit:reinitSkills()
	end

	if offset ~= math.floor(offset) then
		print("$$$ !!!!!!!!!!!!!!!! WarMachine.onHpChange offset!!", unit, hp, offset)
	end

	if unit.type == "OnlinePlayer" then
		return
	end

	if not fromOnline and OnlineCamp.inRoom() == 2 then
		if unit.type == "monster" then
			if unit.onlineAnchor then
				OnlineCamp.uploadMonsterHp(unit.onlineAnchor, offset)
			end
		elseif unit.type == "hero" then
			OnlineCamp.uploadHeroHp(unit.info.pos, hp)
		end
	end

	local id = unit.id

	if id then
		if not checkinst[id] then
			checkinst[id] = hp
		else
			if offset > 0 then
				if hp > checkinst[id] + offset + 1 then
					instWarnCount = instWarnCount + 1

					if DEV_MODE then
						print("instWarnCount1", instWarnCount, id, checkinst[id], hp, offset, debug.traceback())
					else
						print("instWarnCount1", instWarnCount, id, checkinst[id], hp, offset)
					end
				end
			elseif offset < 0 then
				if hp < checkinst[id] + offset - 1 then
					instWarnCount = instWarnCount + 1

					if DEV_MODE then
						print("instWarnCount2", instWarnCount, id, checkinst[id], hp, offset, debug.traceback())
					else
						print("instWarnCount2", instWarnCount, id, checkinst[id], hp, offset)
					end
				end
			elseif hp > checkinst[id] + 1 then
				instWarnCount = instWarnCount + 1

				if DEV_MODE then
					print("instWarnCount3", instWarnCount, id, checkinst[id], hp, offset, debug.traceback())
				else
					print("instWarnCount3", instWarnCount, id, checkinst[id], hp, offset)
				end
			end

			checkinst[id] = hp
		end

		if unit.type == "hero" or unit.type == "hero_copy" then
			local heroID = unit.info.id

			WarMachine.addCheckSum(heroID, hp, offset)
		end
	else
		print("NO  IDDDDDDDD!!!!!!!!", unit, hp, offset, debug.traceback())
	end
end

function WarMachine.clear()
	eventDataStack = {}
	serverDropList = {}
	campStack = {
		{},
		{}
	}
	campCount = {
		0,
		0
	}
	unitStack = {}
	readyToRemoveStack = {}
	thinkFreezeArray = {}
	thinkFreezeTime = 0
	updateIndex = 1
	checkIndex = 1
	WarMachine.waitingForNextWave = false
	WarMachine.on = false
	WarMachine.paused = false
	WarMachine.frame = 0
	WarMachine.locked = nil
	WarMachine.beforeUpdate = nil
	WarMachine.dmg_ratio = nil
	WarMachine.heal_ratio = nil
	WarMachine.shield_ratio = nil
	WarMachine.dramaReplacedDrop = nil
	WarMachine.dramaReplacedEvent = nil
	WarMachine.isTD = false
	WarMachine.createParams = nil
	InfoMission.isDramaBattle = nil
	InfoMission.dramaFinishBattleEventIndex = nil
	WarMachine.event_on = false
	WarMachine.mapLocked = false
	WarMachine.isRetry = nil
end

function WarMachine.setLoseTimeout(frameTime)
	WarMachine.loseTimeout = frameTime
end

function WarMachine.clearLoseTimeout()
	WarMachine.loseTimeout = nil
end

function WarMachine.getFrame()
	return WarMachine.frame
end

function WarMachine.addEventData(eventData)
	for i = 1, #eventDataStack do
		if eventDataStack[i] == eventData then
			return
		end
	end

	table.insert(eventDataStack, eventData)
end

function WarMachine.getEventData(index)
	return eventDataStack[index or 1]
end

function WarMachine.checkGuide(id)
	for i, eventData in ipairs(eventDataStack) do
		local eventInfo = ConfParser.parse(eventData.info)
		local guideArr = string.split(tostring(eventInfo.new_guide), ",")

		for i, guideStr in ipairs(guideArr) do
			if guideStr == tostring(id) then
				return true
			end
		end
	end

	return false
end

function WarMachine.addToFreezeArray(unit)
	table.insert(thinkFreezeArray, unit)
end

function WarMachine.removeFromFreezeArray(unit)
	for i, _unit in ipairs(thinkFreezeArray) do
		if unit == _unit then
			table.remove(thinkFreezeArray, i)

			return
		end
	end
end

function WarMachine.releaseFromFreezeArray()
	if #thinkFreezeArray > 0 and WarMachine.getFrame() - thinkFreezeTime > 30 then
		local freezedUnit = table.remove(thinkFreezeArray, 1)
		freezedUnit.thinkFreezed = false
		thinkFreezeTime = WarMachine.getFrame()

		if freezedUnit.battleUpdate then
			freezedUnit:battleUpdate(true)
		end

		return true
	end

	return false
end

function WarMachine.ready(seed)
	Log.verbose("[WarMachine.ready]", seed)

	eventDataStack = {}
	serverDropList = {}
	campStack = {
		{},
		{}
	}
	campCount = {
		0,
		0
	}
	unitStack = {}
	readyToRemoveStack = {}
	thinkFreezeArray = {}
	thinkFreezeTime = 0
	updateIndex = 1
	checkIndex = 1
	dropOccupiedItemMap = {}
	dropItemStack = {}
	benefitStack = {}
	summonedStack = {}
	petStack = {}
	petActiveTime = 0
	petReadyStack = {}
	petPrepareData = {}
	monsterGroups = {}
	nextWaveTime = nil
	startMaxClass = 0
	everMonsterGroups = {}
	WarMachine.seed = seed
	WarMachine.random = Random.new(WarMachine.seed)
end

function WarMachine.preparePet(camp, centerTile, playerTile, playerAngle)
	petPrepareData[camp] = petPrepareData[camp] or {}
	local data = petPrepareData[camp]
	data.centerTile = centerTile
	data.playerTile = playerTile
	data.playerAngle = playerAngle
	data.timeCount = 0
	data.count = 0
end

function WarMachine.addPetReady(camp, petInfo)
	print("$$$ addPetReady", camp, petInfo)

	petReadyStack[camp] = petInfo
end

function WarMachine.checkPetStart()
	for camp = 1, 2 do
		local petInfo = petReadyStack[camp]

		if petInfo then
			local seed = nil

			if WarMachine.random then
				seed = WarMachine.random:getInt(1, 65535)
			end

			WarMachine.activePet(camp, petInfo, seed)
		end
	end
end

function WarMachine.activePet(camp, petInfo, seed)
	seed = seed or math.random(1, 65535)
	local _petStack = ObjUtil.copy(petStack)

	for i, pet in ipairs(_petStack) do
		if pet.battleData.camp == camp then
			_petStack[i]:die(true)
		end
	end

	local prepareData = petPrepareData[camp]

	if not prepareData then
		return
	end

	local unit = Pet.new(WarMachine.isArena)
	unit.seed = seed
	unit.random = Random.new(unit.seed)
	unit.angle = prepareData.playerAngle

	unit:setInfo(petInfo)
	unit:randomizeFrame()

	unit.isPet = true
	local areaTiles = areaTiles
	prepareData.petTiles = prepareData.petTiles or MapUtils.preparePetBattle(WarMachine.getAreaTileMap(), prepareData.centerTile, prepareData.playerTile, prepareData.playerAngle)
	local petCSV = CsvParser.getCsvData("pet", petInfo.base_id)
	local tile = MapUtils.getPetBattle(prepareData.petTiles, petCSV.location)
	tile = tile or global.player.tile
	local mapX, mapY = global.map:tileToMap(tile)

	unit:display(global.map, mapX, mapY)
	print("$$$ 召唤宠物", tile.tag, petInfo.base_id, unit.seed)
	unit:bornEffect()
	WarMachine.addPet(unit, camp)

	prepareData.count = prepareData.count + 1
	local pet_swap_time = CsvParser.getCsvData("config", "pet_swap_time").value
	prepareData.timeCount = WarMachine.frame + pet_swap_time
	petActiveTime = WarMachine.getFrame()

	notify.dispatch("active_pet", unit)

	if InfoUser.getID() then
		InfoModao.refreshModaoData()
	end
end

function WarMachine.setGroups(_monsterGroups, createParams)
	print("$$$ WarMachine.setGroups")

	monsterGroups = _monsterGroups

	WarMachine.onWaveListChange()

	local winType = 0
	local winParam = 0

	if createParams and createParams.id then
		local monsterCreateCSV = CsvParser.getCsvData("monster_create", createParams.id)

		if not empty(monsterCreateCSV.win_type) then
			local arr = string.split(monsterCreateCSV.win_type, ":")
			winType = tonumber(arr[1])

			if winType == 1 then
				winParam = tonumber(arr[2])
			end
		end
	end

	local maxClass = MapEventManager.getMaxCLass(monsterGroups)
	startMaxClass = maxClass

	POP_battle_start.open(maxClass, winType, winParam)
end

function WarMachine.checkNoEverMonster()
	local count = 0
	local maxClass = 0

	for i, unit in ipairs(unitStack) do
		if unit.battleData.camp == 2 and not unit.everMonsterPack then
			count = count + 1
			maxClass = math.max(maxClass, unit.data.class)
		end
	end

	return count, maxClass
end

function WarMachine.setEverGroups(_everGroups)
	for i, v in ipairs(_everGroups) do
		local obj = {
			count = 0,
			stop = v.stop,
			pack = v.pack,
			drop = SheetUtil.getString(v.drop),
			wait_time = v.wait_time,
			max = SheetUtil.getNumber(v.max),
			timeCount = SheetUtil.getNumber(v.start_time),
			random = Random.new(v.seed)
		}

		table.insert(everMonsterGroups, obj)
	end
end

function WarMachine.checkEverGroups()
	local currentMaxClass, currentCount = nil

	for i, obj in ipairs(everMonsterGroups) do
		if obj.count < obj.max and obj.timeCount <= WarMachine.frame then
			if not obj.over then
				if obj.stop == 1 then
					if not currentCount then
						currentCount, currentMaxClass = WarMachine.checkNoEverMonster()
					end

					if currentCount == 0 then
						obj.over = true
					end
				elseif obj.stop == 2 then
					if not currentMaxClass then
						currentCount, currentMaxClass = WarMachine.checkNoEverMonster()
					end

					if currentMaxClass < startMaxClass then
						obj.over = true
					end
				end
			end

			if not obj.over then
				local monster = MapEventManager.makeEverMonster(obj.drop, obj.random, obj.pack)

				if monster then
					monster.noDropItem = true
					monster.everMonsterPack = obj
					obj.count = obj.count + 1
					obj.timeCount = WarMachine.frame + SheetUtil.getNumber(obj.wait_time)

					monster:bornEffect()
				end
			end
		end
	end
end

function WarMachine.getTimeLeft()
	local timeLeft = 0

	if WarMachine.winType == 1 then
		timeLeft = math.max(0, WarMachine.winParam - WarMachine.frame)
	end

	return timeLeft
end

local devTimeStart, devUpdateUsed = nil

function WarMachine.getBenchmark()
	if devTimeStart and devUpdateUsed then
		local buffUsed = global.buffUsed
		local updateUsed = devUpdateUsed
		local totalUpdateUsed = MapFrameManager.getTimeUsed()
		local timeUsed = Time.time() - devTimeStart
		local frameUsed = WarMachine.getFrame()

		if timeUsed > 0 and frameUsed > 0 then
			local str = "总运算/逻辑/buff 每帧:" .. math.floor(totalUpdateUsed / frameUsed * 60 * 1000) .. "/" .. math.floor(updateUsed / frameUsed * 60 * 1000) .. "/" .. math.floor(buffUsed / frameUsed * 60 * 1000) .. " 每秒:" .. math.floor(totalUpdateUsed / timeUsed * 1000) .. "/" .. math.floor(updateUsed / timeUsed * 1000) .. "/" .. math.floor(buffUsed / timeUsed * 1000)

			return str
		end
	end

	return ""
end

function WarMachine.startBuff()
	local buffArr = InfoPet.getPassiveBuff()

	for i, v in ipairs(buffArr) do
		local buffData = v.buffData
		local petInfo = v.petInfo
		local units = WarMachine.getUnitsByCamp(buffData.target)

		if units then
			for j, unit in ipairs(units) do
				unit:addBuff(buffData.id, buffData.time, nil, , true)
				print("$$$ WarMachine.startBuff pet", buffData.id, buffData.time, buffData.target)
			end
		end
	end

	local units = WarMachine.getUnitsByCamp(1)

	for ii, unit in ipairs(units) do
		if unit.type == "hero" then
			local heroInfo = unit.info
			local buffArr = InfoCard.getAuraBuff(heroInfo.id)

			for i, buffData in ipairs(buffArr) do
				if buffData.target == 1 or buffData.target == 2 then
					local units = WarMachine.getUnitsByCamp(1)

					if units then
						for j, unit in ipairs(units) do
							unit:addBuff(buffData.id, buffData.time, nil, , true)
							print("$$$ WarMachine.startBuff card", buffData.id, buffData.time, buffData.target)
						end
					end
				elseif buffData.target == 3 then
					local units = WarMachine.getUnitsByCamp(2)

					if units then
						for j, unit in ipairs(units) do
							unit:addBuff(buffData.id, buffData.time, nil, , true)
							print("$$$ WarMachine.startBuff card", buffData.id, buffData.time, buffData.target)
						end
					end
				end
			end
		end
	end
end

function WarMachine.startBuffCopy(copyMap, petIndexMap)
	for camp, copy in pairs(copyMap) do
		local petIndex = petIndexMap[camp]
		local buffArr = InfoPet.getPassiveBuff(copy.pet, petIndex)

		for i, v in ipairs(buffArr) do
			local buffData = v.buffData
			local petInfo = v.petInfo
			local units = nil

			if camp == 1 then
				units = WarMachine.getUnitsByCamp(buffData.target)
			else
				units = WarMachine.getUnitsByCamp(3 - buffData.target)
			end

			if units then
				for j, unit in ipairs(units) do
					unit:addBuff(buffData.id, buffData.time, nil, , true)
					print("$$$ WarMachine.startBuffCopy pet", buffData.id, buffData.time, buffData.target, camp)
				end
			end
		end

		local units = WarMachine.getUnitsByCamp(camp)

		for ii, unit in ipairs(units) do
			if unit.type == "hero_copy" then
				local heroInfo = unit.info
				local buffArr = InfoCard.getAuraBuffCopy(heroInfo)

				for i, buffData in ipairs(buffArr) do
					if buffData.target == 1 or buffData.target == 2 then
						local units = WarMachine.getUnitsByCamp(camp)

						if units then
							for j, unit in ipairs(units) do
								unit:addBuff(buffData.id, buffData.time, nil, , true)
								print("$$$ WarMachine.startBuffCopy card", buffData.id, buffData.time, buffData.target, camp)
							end
						end
					elseif buffData.target == 3 then
						local units = WarMachine.getUnitsByCamp(3 - camp)

						if units then
							for j, unit in ipairs(units) do
								unit:addBuff(buffData.id, buffData.time, nil, , true)
								print("$$$ WarMachine.startBuffCopy card", buffData.id, buffData.time, camp)
							end
						end
					end
				end
			end
		end
	end
end

function WarMachine.start(createParams, isArena)
	if DEV_MODE then
		devTimeStart = Time.time()
		devUpdateUsed = 0
		global.buffUsed = 0

		MapFrameManager.markTimeUsed()
	end

	DmgCount.reset()

	if global.tongji and global.ui.startCount then
		global.ui:startCount()
	end

	WarMachine.clearCheck()

	for i, unit in ipairs(unitStack) do
		WarMachine.checkAttr(unit)
	end

	if global.modao then
		local skills = global.modao:getSkills()

		for id, skillPack in pairs(skills) do
			if skillPack.caster then
				WarMachine.checkAttr(skillPack.caster)
			end
		end
	end

	SkillManager.onBattleStart()

	if not isArena then
		InfoPet.onBattleStart()
	end

	MapFrameManager.setMode(FrameLooper.MODE.STEP)
	MapFrameManager.startLoop(WarMachine, WarMachine.update)

	if not isArena and OnlineCamp.inRoom() == 2 then
		local eventData = WarMachine.getEventData()

		if eventData then
			OnlineCamp.battleStart(eventData)
		end
	end

	if global.player then
		local units = global.player:getTrainUnits()

		if units then
			for i, unit in ipairs(units) do
				unit.speed = math.max(0, unit.data.speed * (1 + unit.attrs.battle_speed / 100))

				unit:stop(22)
			end
		end

		if not WarMachine.checkAreaTileMap(global.player.tile) then
			local tileMap = WarMachine.getAreaTileMap()
			local bestTile, bestDistance = nil

			for tag, tile in pairs(tileMap) do
				if tile:getWalkable(0, global.player, true) then
					local distance = math.pow(global.player.tile.x - tile.x, 2) + math.pow(global.player.tile.y - tile.y, 2)

					if not bestDistance or distance < bestDistance then
						bestDistance = distance
						bestTile = tile
					end
				end
			end

			if bestTile then
				print("$$$ bestTile", bestTile.tag)

				local mapX, mapY = global.map:tileToMap(bestTile)

				global.player:draw(mapX, mapY, true)
			end
		end
	end

	WarMachine.mapLocked = true
	WarMachine.on = true
	WarMachine.event_on = true
	WarMachine.isArena = isArena
	WarMachine.winType = 0
	WarMachine.createParams = createParams

	if createParams and createParams.id then
		local monsterCreateCSV = CsvParser.getCsvData("monster_create", createParams.id)

		if not empty(monsterCreateCSV.win_type) then
			local arr = string.split(monsterCreateCSV.win_type, ":")
			WarMachine.winType = tonumber(arr[1])

			if WarMachine.winType == 1 then
				WarMachine.winParam = tonumber(arr[2])
			end
		end
	end

	print("$$$ WarMachine.winType", WarMachine.winType, WarMachine.winParam)

	if WarMachine.winType == 1 then
		notify.dispatch("battle_timecount_start")
	end

	notify.dispatch("WarMachine_start")

	if not isArena and not InfoGuide.isFin() then
		if InfoGuide.getFreeRecord(1) == 0 then
			InfoGuide.triggerFree(1)
		elseif InfoGuide.getFreeRecord(13) == 0 then
			if SkillManager.autoEnabled() then
				InfoGuide.triggerFree(13, nil, function ()
					if InfoGuide.getFreeRecord(37) == 0 then
						local currentMp = InfoModao.getMp()

						if currentMp >= 200 then
							InfoGuide.triggerFree(37)
						end
					end
				end)
			end
		elseif InfoGuide.getFreeRecord(37) == 0 and InfoGuide.getFreeRecord(13) > 0 then
			local currentMp = InfoModao.getMp()

			if currentMp >= 200 then
				InfoGuide.triggerFree(37)
			end
		end
	end

	if not isArena and InfoDungeon.getSneakPoint() > 0 then
		local buffID, buffTime = InfoDungeon.getSneakBuff()

		if not empty(buffID) then
			local units = WarMachine.getUnitsByCamp(2)

			for i, unit in ipairs(units) do
				unit:addBuff(buffID, buffTime)
			end
		end
	end

	if not isArena and InfoMission.isDramaBattle then
		if WarMachine.dramaReplacedEvent then
			eventDataStack[1] = WarMachine.dramaReplacedEvent
		end

		if WarMachine.dramaReplacedDrop then
			local dropList = WarMachine.dramaReplacedDrop
			local unitList = campStack[2]
			local newUnitList = {}

			for i, monster in ipairs(unitList) do
				if not global.monsterNoDropItem and WarMachine.checkMonsterBattle(monster) and not monster.noDropItem and not monster.isNextWave then
					table.insert(newUnitList, monster)
				end
			end

			unitList = newUnitList
			local preIndex = 1

			for i, unit in ipairs(unitList) do
				local dropArr = {}
				local dropIndex = math.ceil(#dropList * i / #unitList)

				for j = preIndex, dropIndex do
					table.insert(dropArr, dropList[j])
				end

				preIndex = dropIndex + 1
				unit.replacedDrop = dropArr
			end
		end
	end

	WarMachine.dramaReplacedDrop = nil
	WarMachine.dramaReplacedEvent = nil

	if InfoUser.getID() then
		InfoModao.refreshModaoData()
	end

	WarMachine.checkPetStart()
end

local afterBattleTalkCount = SheetUtil.getNumber(MiscConfig.afterBattleTalkInterval)
local heroAfterBattleChatID = nil

function WarMachine.over()
	Log.verbose("WarMachine.over")
	InfoModao.battleOver()
	MapFrameManager.stopLoop(WarMachine, WarMachine.update)
	MapFrameManager.setMode(FrameLooper.MODE.NORMAL)
	WarMachine.normalSpeed(true)

	WarMachine.on = false

	TeamManager.lockHeroHP()

	for i = 1, #campStack do
		for j = 1, #campStack[i] do
			local unit = campStack[i][j]

			unit:onBattleOver()
			unit:resetBattle()
		end
	end

	TeamManager.unlockHeroHP()

	WarMachine.preFrame = WarMachine.frame
	WarMachine.frame = 0

	dumpCheckSum()
	notify.dispatch("WarMachine_over")

	if global.tongji then
		if global.ui.stopCount then
			global.ui:stopCount()
		end

		DmgCount.refreshAdvUI()
	end

	if not InfoMission.isDramaBattle then
		afterBattleTalkCount = afterBattleTalkCount - 1

		if afterBattleTalkCount <= 0 then
			local unit = TeamManager.getRandomUnit()

			if unit then
				local function delayDo()
					local dungeonData, questMapCsv = InfoDungeon.getDungeonCSV()
					local mapType = ""

					if InfoDungeon.getType() == InfoDungeon.TYPE.ABYSS then
						mapType = dungeonData.map_type
					elseif questMapCsv then
						mapType = questMapCsv.dungeon
					end

					if dungeonData then
						local chatMsg, sayTime = LinesManager.getAfterBattle(unit.data.class, mapType, InfoDungeon.getLevel(), heroAfterBattleChatID)

						if not empty(chatMsg) then
							heroAfterBattleChatID = chatMsg.id

							unit:say(chatMsg.text, sayTime)
						end
					end
				end

				Looper.setTimeout(delayDo, 150, unit)
			end

			afterBattleTalkCount = SheetUtil.getNumber(MiscConfig.afterBattleTalkInterval)
		end
	end
end

function WarMachine.normalSpeed(doStop)
	if global.player then
		local units = global.player:getTrainUnits()

		for i, unit in ipairs(units) do
			unit.speed = Player.normalSpeed

			if doStop then
				unit:stop(23)
			end
		end
	end
end

function WarMachine.cleanSummoned()
	local _summonedStack = ObjUtil.copy(summonedStack)

	for i = 1, #_summonedStack do
		_summonedStack[i]:die(true)
	end

	summonedStack = {}
end

function WarMachine.clean()
	WarMachine.cleanSummoned()

	local _petStack = ObjUtil.copy(petStack)

	for i = 1, #_petStack do
		_petStack[i]:die(true)
	end

	petStack = {}

	Tile.clearAssetsByName("warning")
	WarMachine.clearAreaTileMap()
end

function WarMachine.clearOnRetry()
	WarMachine.event_on = false
	WarMachine.mapLocked = false
	WarMachine.isRetry = true

	MapFrameManager.stopLoop(WarMachine, WarMachine.update)
end

function WarMachine.clearOnScene()
	dropItemStack = {}
	summonedStack = {}
	petStack = {}
	WarMachine.event_on = false
	WarMachine.mapLocked = false
	WarMachine.isRetry = nil
end

function WarMachine.addSummoned(unit, caster, noCount)
	table.insert(summonedStack, unit)
	WarMachine.addUnit(unit, caster.battleData.camp, "WarMachine.addSummoned", noCount)
end

function WarMachine.removeSummoned(unit)
	for i = 1, #summonedStack do
		if summonedStack[i] == unit then
			table.remove(summonedStack, i)

			return
		end
	end
end

function WarMachine.addPet(unit, camp)
	table.insert(petStack, unit)
	WarMachine.addUnit(unit, camp or 1, "WarMachine.addPet", true)
end

function WarMachine.removePet(unit)
	for i = 1, #petStack do
		if petStack[i] == unit then
			table.remove(petStack, i)

			return
		end
	end
end

function WarMachine.addUnit(unit, camp, from, noCount)
	unit.battleData.camp = camp
	unit.noCount = noCount

	if not unit.noEntity then
		local campArr = campStack[camp]

		for i, _unit in ipairs(campArr) do
			if _unit == unit then
				print("WarMachine.addUnit 重复添加", from, debug.traceback())

				return
			end
		end

		table.insert(campArr, unit)

		if not noCount then
			campCount[camp] = campCount[camp] + 1
		end

		unit.battleData.index = #campArr
		unit.preCheckAttr = unit.battleData.index * 7
	end

	table.insert(unitStack, unit)

	if WarMachine.on then
		WarMachine.checkAttr(unit)
	end

	unit.battleData.allIndex = #unitStack

	unit:onBattleStart(WarMachine.random:getInt(1, 65535))

	if unit.eventPack then
		WarMachine.addEventData(unit.eventPack.eventData)
	end

	notify.dispatch("warmachine_addunit_" .. camp, unit)
end

function WarMachine.removeUnit(unit)
	unit:onBattleOver()
	table.insert(readyToRemoveStack, unit)

	if not unit.noEntity and unit.battleData.camp then
		notify.dispatch("warmachine_removeunit_" .. unit.battleData.camp, unit)
	end

	if unit.everMonsterPack then
		unit.everMonsterPack.count = unit.everMonsterPack.count - 1
	end

	if unit.isPet then
		local prepareData = petPrepareData[unit.battleData.camp]
		prepareData.count = prepareData.count - 1
	end

	if unit.type == "monster" then
		WarMachine.onMonsterDie(unit)
	end
end

function WarMachine.doRemoveUnit(unit)
	if not unit.noEntity then
		local camp = unit.battleData.camp
		local campArr = campStack[camp]
		local index = unit.battleData.index

		if not unit.noCount then
			campCount[camp] = campCount[camp] - 1
		end

		table.remove(campArr, index)

		for i = index, #campArr do
			if campArr[i].battleData then
				campArr[i].battleData.index = campArr[i].battleData.index - 1
			end
		end
	end

	local allIndex = unit.battleData.allIndex

	table.remove(unitStack, allIndex)

	for i = allIndex, #unitStack do
		if unitStack[i].battleData then
			unitStack[i].battleData.allIndex = unitStack[i].battleData.allIndex - 1
		end
	end

	WarMachine.removeFromFreezeArray(unit)

	if allIndex < updateIndex then
		updateIndex = math.max(1, updateIndex - 1)
	end
end

function WarMachine.getUnitsByCamp(camp)
	return campStack[camp]
end

function WarMachine.getEnemyCamp(camp)
	return 3 - camp
end

function WarMachine.getUnits()
	return unitStack
end

function WarMachine.getPets()
	return petStack
end

function WarMachine.getPetCamp(camp)
	local campArr = {}

	for i, unit in ipairs(petStack) do
		if unit.battleData and unit.battleData.camp == camp then
			table.insert(campArr, unit)
		end
	end

	return campArr
end

function WarMachine.startLoop(obj, func)
	local paused = WarMachine.paused

	local function loopFunc(obj, ...)
		if not paused and WarMachine.paused then
			return
		end

		func(...)
	end

	MapFrameManager.startLoop(obj, loopFunc)

	return loopFunc
end

function WarMachine.setBeforeUpdate(callback)
	WarMachine.beforeUpdate = callback
end

function WarMachine.update(obj, frame, passed, sharp, elapsedTime, dt, ot)
	local startTime = nil

	if DEV_MODE then
		startTime = Time.time()
	end

	if WarMachine.paused then
		return
	end

	if WarMachine.isRetry then
		return
	end

	if sharp == 0 then
		return
	end

	local totalFrame = MapFrameManager.getFrame()
	local checkAttrAlready = false

	for i = 1, sharp do
		WarMachine.frame = WarMachine.frame + 1

		if WarMachine.beforeUpdate then
			WarMachine.beforeUpdate()
		end

		if updateIndex > #unitStack and not WarMachine.releaseFromFreezeArray() then
			updateIndex = 1
		end

		local checked = false

		for i = 1, #unitStack do
			local unit = unitStack[i]

			if unit and unit.battleUpdate then
				unit:battleUpdate(updateIndex == i)

				if device.platform ~= "ios" and not checkAttrAlready and checkIndex == i and dt <= elapsedTime * 1.1 and ot <= elapsedTime then
					if not unit.preCheckAttr or totalFrame >= unit.preCheckAttr + 60 then
						WarMachine.checkAttr(unit)

						unit.preCheckAttr = totalFrame
					end

					checked = true
					checkAttrAlready = true
				end
			end
		end

		for i = 1, #readyToRemoveStack do
			WarMachine.doRemoveUnit(readyToRemoveStack[i])
		end

		readyToRemoveStack = {}
		updateIndex = updateIndex + 1

		if checked then
			checkIndex = checkIndex + 1

			if checkIndex > #unitStack then
				checkIndex = 1
			end
		end

		WarMachine.checkEverGroups()

		if nextWaveTime and nextWaveTime <= WarMachine.frame then
			if not WarMachine.waitingForNextWave then
				MapEventManager.prepareNextWave(monsterGroups)
				Alert.open(Localization.getSrcText("敌人突入"))
			end

			WarMachine.waitingForNextWave = false

			MapEventManager.startNextWave(monsterGroups)
			WarMachine.onWaveListChange()
		end

		if InfoDungeon.getType() ~= InfoDungeon.TYPE.CORE then
			local isLose = false

			if not global.isTestBattle then
				if InfoDungeon.inDungeon() then
					local heroCount = 0

					if campStack[1] then
						for i, unit in ipairs(campStack[1]) do
							if unit.type == "hero" then
								heroCount = heroCount + 1

								break
							end
						end
					end

					isLose = heroCount == 0
				else
					isLose = campCount[1] == 0
				end

				if not isLose and WarMachine.loseTimeout and WarMachine.loseTimeout <= WarMachine.frame then
					isLose = true
				end
			end

			if isLose then
				WarMachine.over()
				OnlineCamp.dieout()

				if WarMachine.createParams and WarMachine.createParams.onBattleLose then
					WarMachine.createParams.onBattleLose()

					break
				end

				WarMachine.showBattleLose(function ()
					WarMachine.event_on = false

					global.map:battleOff()
				end)

				break
			else
				local isWin = false

				if WarMachine.winType == 0 then
					if campCount[2] == 0 then
						isWin = true
					end
				elseif WarMachine.winType == 1 and WarMachine.winParam <= WarMachine.frame then
					notify.dispatch("battle_timecount_stop")

					isWin = true
				end

				if isWin then
					if WarMachine.waitingForNextWave then
						break
					end

					if MapEventManager.prepareNextWave(monsterGroups) then
						WarMachine.waitingForNextWave = true

						if not nextWaveTime or nextWaveTime > WarMachine.frame + 90 then
							nextWaveTime = WarMachine.frame + 90
						end

						global.ui:prepareNextWave()
						Alert.open(Localization.getSrcText("下一波"))

						break
					end

					WarMachine.over()
					OnlineCamp.battleOver()

					if WarMachine.winType == 0 then
						MapEffect.bulletTime("WarMachine_over", 0.5)
					end

					local currentEventData = WarMachine.getEventData(1)

					local function overPlay()
						MapEffect.bulletTime("WarMachine_over", 1)
						global.map:battleOff()
						TeamManager.regroup(function ()
							WarMachine.mapLocked = false

							if InfoDungeon.isAutoPick() and global.player then
								global.player:autopickDropItem()
							end

							notify.dispatch("battle_over_drama")
							notify.dispatch("guide_rantile")
						end)
						WarMachine.normalSpeed()
						global.map:tweenFov(global.player.x, global.player.y, 30)
						global.map:tweenToUnit(global.player, 30, function ()
							WarMachine.clean()
							global.map:setFov(global.player.x, global.player.y)
							WarMachine.reclaimDropItem()

							if DEV_MODE or device.platform == "windows" then
								local k = collectgarbage("count")
								local m = math.ceil(k / 1024 * 10) / 10

								print(string.format("战斗结束清内存 before: %0.2f KB (%0.2f MB)", k, m))
							end

							local preGcTime = Cookie.get("gc_time")

							if not preGcTime or preGcTime < MiscConfig.gc_threhold_time then
								local beforeTime = Time.time()

								collectgarbage("collect")

								local timeGC = Time.time() - beforeTime

								Cookie.set("gc_time", timeGC, true)
							else
								local timeGC = preGcTime * 0.9

								Cookie.set("gc_time", timeGC, true)
							end

							if DEV_MODE or device.platform == "windows" then
								local k = collectgarbage("count")
								local m = math.ceil(k / 1024 * 10) / 10

								print(string.format("战斗结束清内存 after: %0.2f KB (%0.2f MB)", k, m))
							end

							local finCount, totalCount = InfoDungeon.getEventTimes("monster")

							if finCount == 1 then
								local eventData = currentEventData

								if eventData then
									local centerX = math.floor(eventData.x + (eventData.w - 1) / 2)
									local centerY = math.floor(eventData.y + (eventData.h - 1) / 2)
									local tile = global.map:getTile(centerX, centerY)

									if tile then
										local params = {
											tile = tile,
											eventIndex = eventData.index
										}

										if totalCount == 1 then
											if InfoMission.trigger(3, 3, params) then
												return
											end
										elseif InfoMission.trigger(2, 3, params) then
											return
										end
									end
								end
							end
						end)
					end

					local function onSent()
						WarMachine.event_on = false

						notify.dispatch("battle_over")
						TeamManager.stopAllRevive()
						Looper.setTimeout(overPlay, 30, global.map)
					end

					if WarMachine.createParams and WarMachine.createParams.onBattleWin then
						WarMachine.createParams.onBattleWin(onSent)
					else
						if WarMachine.winType == 1 then
							for ii, eventData in ipairs(eventDataStack) do
								local enemys = WarMachine.getEventEnemy(eventData)

								for jj, unit in ipairs(enemys) do
									if unit.die then
										unit:die()
									end
								end
							end
						end

						WarMachine.sendBattleOver(onSent, currentEventData)
					end

					break
				end
			end
		end
	end

	if DEV_MODE then
		local timeUsed = Time.time() - startTime
		devUpdateUsed = devUpdateUsed + timeUsed
	end
end

function WarMachine.onWaveListChange()
	local waveList = MapEventManager.getWaveList(monsterGroups)

	global.ui:refreshWaveList(waveList)

	nextWaveTime = nil

	if #waveList > 0 and waveList[1].time then
		nextWaveTime = WarMachine.frame + waveList[1].time
	end
end

function WarMachine.setNextNoLose(isNoLose)
	print("$$$ setNextNoLose", isNoLose)

	WarMachine.noLose = isNoLose
end

function WarMachine.showBattleLose(onBattleResultClose)
	notify.dispatch("battle_over")
	TeamManager.stopAllRevive()

	local isGuideReset = false

	if DramaManager.opening and InfoGuide.reset() then
		isGuideReset = true
	end

	if not isGuideReset and not WarMachine.noLose then
		WarMachine.locked = true

		print("$$$ OnlineCamp.isOnlineStage()", OnlineCamp.isOnlineStage())

		local stageType = InfoDungeon.getStage()

		print("$$$ stageType", stageType)

		if OnlineCamp.isOnlineStage() then
			FRAME_lose_online.open(onBattleResultClose)
		else
			FRAME_battle_lose.open(onBattleResultClose)
		end
	end

	if WarMachine.noLose then
		notify.dispatch("battle_over_drama")
	end

	WarMachine.noLose = nil
end

function WarMachine.killAllMonster(eventData)
	local unitList = ClipOnMap.getUnitList("monster", "summoned")

	for i, unit in ipairs(unitList) do
		if (unit.eventPack and unit.eventPack.eventData and unit.eventPack.eventData == eventData or unit.summoner and unit.summoner.eventPack and unit.summoner.eventPack.eventData and unit.summoner.eventPack.eventData == eventData) and unit.battleData.camp == 2 then
			unit:die()
		end
	end
end

function WarMachine.sendBattleOver(onSent, currentEventData)
	WarMachine.killAllMonster(currentEventData)

	if InfoMission.dramaFinishBattleEventIndex then
		if onSent then
			onSent()
		end
	else
		local timeoutID, completeNext = nil

		function completeNext(rcvData)
			if timeoutID then
				Looper.clearTimeout(timeoutID)

				timeoutID = nil
			end

			if rcvData and rcvData.ex_data then
				for i = 1, #rcvData.ex_data.drop_list do
					table.insert(serverDropList, rcvData.ex_data.drop_list[i])
				end
			end

			if #eventDataStack > 0 then
				local eventData = table.remove(eventDataStack, 1)
				local eventIndex = eventData.index
				local tryCount = 0
				local callFinish = nil

				function callFinish()
					Log.debug("callFinish", tryCount, Connection.getStat())

					local eventInfo = InfoDungeon.getEventInfo(eventIndex)

					if eventInfo and eventInfo.fin > 0 then
						if onSent then
							onSent()
						end

						return
					end

					if Connection.getStat() == "connected" and Connection.ingame then
						InfoDungeon.finishMonsterYD(startMaxClass, eventIndex, completeNext, nil, , , tryCount > 0, function (err)
							if timeoutID then
								Looper.clearTimeout(timeoutID)

								timeoutID = nil
							end
						end)

						tryCount = tryCount + 1
						timeoutID = Looper.setTimeout(callFinish, GameConfig.request_lock_c * 60, global.map)
					else
						timeoutID = Looper.setTimeout(callFinish, 60, global.map)
					end
				end

				callFinish()

				return
			end

			if onSent then
				onSent()
			end
		end

		completeNext()
	end
end

local areaTileMap = nil

function WarMachine.setAreaTileMap(areaTiles)
	areaTileMap = {}

	for i, tile in ipairs(areaTiles) do
		areaTileMap[tile:getTag()] = tile
	end
end

function WarMachine.getAreaTileMap()
	return areaTileMap or Tile.visibleTileMap
end

function WarMachine.checkAreaTileMap(tile)
	local tileMap = WarMachine.getAreaTileMap()

	if not tileMap then
		return false
	end

	if not tile then
		return false
	end

	local tileTag = nil

	if type(tile) == "string" then
		tileTag = tile
	else
		tileTag = tile.tag
	end

	return tileMap[tileTag] ~= nil
end

function WarMachine.clearAreaTileMap()
	areaTileMap = nil
end

local borderTiles = nil

function WarMachine.setBorderTiles(tiles)
	borderTiles = tiles
end

function WarMachine.getBorderTiles()
	return borderTiles
end

function WarMachine.removeBorderTile(tile)
	for i, _tile in ipairs(borderTiles) do
		if _tile.tag == tile.tag then
			table.remove(borderTiles, i)

			return
		end
	end
end

function WarMachine.getTilesAroundUnit(unit, range)
	local tiles = {}
	local centerTile = unit.tile
	local center = {
		x = centerTile.x + (unit.size - 1) / 2,
		y = centerTile.y + (unit.size - 1) / 2
	}

	for i = centerTile.x - range, centerTile.x + unit.size + range - 1 do
		for j = centerTile.y - range, centerTile.y + unit.size + range - 1 do
			local tile = global.map:getTile(i, j)

			if tile then
				local distance = math.sqrt(math.pow(tile.y - center.y, 2) + math.pow(tile.x - center.x, 2))

				if distance <= range and WarMachine.checkAreaTileMap(tile) then
					table.insert(tiles, tile)
				end
			end
		end
	end

	return tiles
end

function WarMachine.getCenterTile()
	return global.map.battleCenterTile
end

function WarMachine.getCenterPosition()
	local x, y = global.map:tileToMap(global.map.battleCenterTile)

	return cc.p(x, y)
end

function WarMachine.getEventIndexArr()
	local arr = {}

	for i, v in ipairs(eventDataStack) do
		table.insert(arr, v.index)
	end

	return arr
end

function WarMachine.checkMonsterBattle(monster)
	if WarMachine.on and monster and monster.eventPack and monster.eventPack.eventData then
		local eventData = monster.eventPack.eventData

		for i, v in ipairs(eventDataStack) do
			if v == eventData then
				return true
			end
		end
	end

	return false
end

function WarMachine.checkEventIndex(eventIndex)
	if WarMachine.on then
		for i, v in ipairs(eventDataStack) do
			if eventIndex == v.index then
				return true
			end
		end
	end

	return false
end

function WarMachine.onMonsterDie(monster)
	if not global.monsterNoDropItem and WarMachine.checkMonsterBattle(monster) and not monster.noDropItem and not monster.isNextWave then
		local exDropArr = nil

		if monster.is_lucky_one and (InfoDungeon.getType() == InfoDungeon.TYPE.ABYSS or InfoDungeon.inDust()) then
			exDropArr = InfoFestival.getDropList()
		end

		WarMachine.dropItem(monster, exDropArr)
	end
end

function WarMachine.setReplacedBattle(eventData, dropList)
	WarMachine.dramaReplacedEvent = eventData
	WarMachine.dramaReplacedDrop = dropList
end

function WarMachine.getDropItemStack(monsterInfo, seed)
	local monsterData = CsvParser.getCsvData("monster", monsterInfo.base_id)
	local level = InfoDungeon.getLevel()
	local dropRare = monsterData.drop_rare
	local globalAttrs = CombatAttr.getGlobalData()
	dropRare = dropRare + (globalAttrs.magic_farm or 0)
	local itemStack = {}
	local noDrop = false

	if WarMachine.createParams then
		local monsterCreateCSV = CsvParser.getCsvData("monster_create", WarMachine.createParams.id)
		noDrop = monsterCreateCSV.no_drop == 1
	end

	if not noDrop then
		local dropAffix = InfoDungeon.getMutateMonsterDropAffix() or "drop_id_"
		local drop_id_arr = SheetUtil.getColumnValueList(monsterData, dropAffix)

		for iii, dropID in ipairs(drop_id_arr) do
			if not empty(dropID) then
				local _itemStack = DropManager.drop(dropID, level, dropRare, seed, InfoDungeon.getType() == InfoDungeon.TYPE.ABYSS)

				for i, v in ipairs(_itemStack) do
					table.insert(itemStack, v)
				end
			end
		end
	end

	return itemStack
end

function WarMachine.dropItem(monster, exDropArr)
	local itemStack = {}

	if monster.replacedDrop then
		itemStack = monster.replacedDrop
	elseif monster.eventPack then
		local level = InfoDungeon.getLevel()
		local dropRare = monster.data.drop_rare
		local globalAttrs = CombatAttr.getGlobalData()
		dropRare = dropRare + (globalAttrs.magic_farm or 0)

		if empty(monster.eventPack) or empty(monster.eventPack.setData) or empty(monster.eventPack.setData.custom_drop) then
			local noDrop = false

			if WarMachine.createParams then
				local monsterCreateCSV = CsvParser.getCsvData("monster_create", WarMachine.createParams.id)
				noDrop = monsterCreateCSV.no_drop == 1
			end

			if not noDrop then
				local dropAffix = nil
				local dustData = InfoDungeon.getDustData()

				if dustData then
					dropAffix = "dust" .. dustData.id .. "_drop_id_"
				else
					dropAffix = "drop_id_"
				end

				local originalAffix = dropAffix

				if not monster.noMutate then
					dropAffix = InfoDungeon.getMutateMonsterDropAffix() or dropAffix
				end

				local drop_id_arr = SheetUtil.getColumnValueList(monster.data, dropAffix)

				print("$$$ dropAffix", dropAffix, originalAffix, #drop_id_arr)

				if #drop_id_arr == 0 and dropAffix ~= originalAffix then
					dropAffix = originalAffix
					drop_id_arr = SheetUtil.getColumnValueList(monster.data, dropAffix)
				end

				for iii, dropID in ipairs(drop_id_arr) do
					if not empty(dropID) then
						local _itemStack = DropManager.drop(dropID, level, dropRare, monster.seed, InfoDungeon.getType() == InfoDungeon.TYPE.ABYSS)

						for i, v in ipairs(_itemStack) do
							table.insert(itemStack, v)
						end
					end
				end

				if exDropArr and monster.eventPack then
					for iii, dropID in ipairs(exDropArr) do
						local seed = monster.eventPack.eventData.seed
						local _itemStack = DropManager.drop(dropID, level, 0, seed, InfoDungeon.getType() == InfoDungeon.TYPE.ABYSS)

						for i, v in ipairs(_itemStack) do
							table.insert(itemStack, v)
						end
					end
				end
			end
		end
	end

	if itemStack and #itemStack > 0 and (monster.eventPack or WarMachine.getEventData()) then
		for i, itemInfo in ipairs(itemStack) do
			local itemData = CsvParser.getCsvData("item", itemInfo.base_id)

			if itemData.is_bag ~= 1 then
				local dropInfo = {
					type = DropManager.TYPE.ITEM,
					info = itemInfo
				}

				if monster.eventPack then
					dropInfo.eventIndex = monster.eventPack.eventData.index
				else
					dropInfo.eventIndex = WarMachine.getEventData().index
				end

				local dropItem = DropItem.new()

				dropItem:setDrop(dropInfo)

				if itemData.is_precious == 1 then
					dropItem:setScale(MiscConfig.precious_item_scale)
				else
					dropItem:setScale(MiscConfig.drop_item_scale)
				end

				dropItem:display(monster.map, monster.x, monster.y)

				if itemData.is_precious == 1 then
					local effect = dropItem:addLastingEffect(MiscConfig.precious_item_effect)

					effect:setOpacity(100)
				end

				local tile = monster.map:mapToTile(monster.x, monster.y)
				local destTile = WarMachine.getDropTile(tile)

				if destTile then
					local x, y = monster.map:tileToMap(destTile)

					dropItem:jump({
						x = x,
						y = y
					}, math.random() * 5 + 10, math.random() * 32 + 64)
				end

				WarMachine.addDropItem(dropItem)
			end
		end
	end
end

function WarMachine.getDropTile(centerTile)
	if not dropOccupiedItemMap[centerTile:getTag()] then
		dropOccupiedItemMap[centerTile:getTag()] = true

		return centerTile
	end

	local range = 1

	local function sortMethod(a, b)
		return a.r < b.r
	end

	while range < 5 do
		local offsets = {
			{
				yb = 0,
				xb = 0,
				x = 1,
				y = range * 2
			},
			{
				yb = 0,
				xb = 1,
				y = 1,
				x = math.max(range * 2 - 2, 1)
			}
		}
		local tileArray = {}

		for l = 1, #offsets do
			local offset = offsets[l]

			for i = centerTile.x - range + offset.xb, centerTile.x + range - offset.xb, offset.x do
				for j = centerTile.y - range + offset.yb, centerTile.y + range - offset.yb, offset.y do
					local tile = global.map:getTile(i, j)

					if tile and tile:getWalk() == 0 and not dropOccupiedItemMap[tile:getTag()] then
						local minR = math.min(math.abs(i - centerTile.x), math.abs(j - centerTile.y))

						table.insert(tileArray, {
							r = minR,
							tile = tile
						})
					end
				end
			end
		end

		if #tileArray > 0 then
			table.sort(tileArray, sortMethod)

			local tile = tileArray[1].tile
			dropOccupiedItemMap[tile:getTag()] = true

			return tile
		end

		range = range + 1
	end
end

function WarMachine.addDropItem(dropItem)
	local code = dropItem.dropType .. ":" .. dropItem.dropInfo.base_id

	if not dropItemStack[code] then
		dropItemStack[code] = {}
	end

	table.insert(dropItemStack[code], dropItem)
end

local dropItemRemoveStack = {}
local dropItemRemoveStackCount = 0
local dropItemFlyoutCount = 0
local dropItemClear = false

function WarMachine.reclaimDropItem()
	local dropListEmpty = true

	if serverDropList and #serverDropList > 0 then
		for i = 1, #serverDropList do
			local drop = serverDropList[i]
			local dropItem = WarMachine.removeDropItem(drop.type, drop.info.base_id, drop)
			dropListEmpty = false
		end
	end

	dropItemFlyoutCount = 0
	dropItemClear = false
end

function WarMachine.removeDropItem(type, baseID, dropInfo)
	local code = type .. ":" .. baseID
	local removedOne = nil

	if dropItemStack[code] and #dropItemStack[code] > 0 then
		removedOne = table.remove(dropItemStack[code], i)

		if #dropItemStack[code] == 0 then
			dropItemStack[code] = nil
		end
	end

	if removedOne then
		WarMachine.addDropItemRemoveStack({
			dropItem = removedOne,
			dropInfo = dropInfo
		})
	end

	return removedOne
end

function WarMachine.getDropNum(type, baseID)
	local code = type .. ":" .. baseID

	if not dropItemStack[code] then
		return 0
	else
		return #dropItemStack[code]
	end
end

function WarMachine.addDropItemRemoveStack(dropObj)
	table.insert(dropItemRemoveStack, dropObj)

	if dropItemRemoveStackCount > 0 then
		return
	end

	if #dropItemRemoveStack == 1 then
		local removeDropItemLoop = nil

		function removeDropItemLoop(obj, frame, passed, sharp)
			if dropItemRemoveStackCount <= 0 then
				local dropObj = table.remove(dropItemRemoveStack, 1)
				local dropItem = dropObj.dropItem
				local dropInfo = dropObj.dropInfo

				local function onFlyoutComplete()
					dropItemFlyoutCount = dropItemFlyoutCount - 1

					if dropItemFlyoutCount == 0 and dropItemClear then
						notify.dispatch("battle_over_drop_complete")
					end
				end

				if dropInfo.type == DropManager.TYPE.ITEM then
					dropItem:flyToResource(onFlyoutComplete)
				else
					local effectGen = dropItem:getEffectGen()

					if effectGen then
						effectGen:fadeTo(10, 0, "inSine")
						effectGen:zmove(10, 64, "outSine", function ()
							dropItem:removeSelf()
							onFlyoutComplete()
						end)
					end
				end

				dropItemFlyoutCount = dropItemFlyoutCount + 1
				local effectGen = dropItem:getEffectGen()

				if effectGen then
					local effect = effectGen:addEffect(MiscConfig.effect_itemFly)

					effect:setScale(0.5)

					effect.playSkip = 0
				end

				if #dropItemRemoveStack > 0 then
					dropItemRemoveStackCount = 5
				else
					dropItemRemoveStackCount = 0

					Looper.stopLoop(WarMachine, removeDropItemLoop)

					dropItemClear = true
				end

				return
			end

			dropItemRemoveStackCount = dropItemRemoveStackCount - passed
		end

		Looper.startLoop(WarMachine, removeDropItemLoop)
	end

	app:addToSceneExitCall(function ()
		Looper.stopLoop(WarMachine, removeDropItemLoop)
	end)
end

function WarMachine.dropBenefit(monster)
	local benefit = {
		exp = CsvParser.getCsvData("monster_base_num", monster.info.level).exp
	}

	WarMachine.addBenefit(benefit)
end

function WarMachine.addBenefit(obj)
	for k, v in pairs(obj) do
		if not benefitStack[k] then
			benefitStack[k] = 0
		end

		benefitStack[k] = benefitStack[k] + v
	end
end

function WarMachine.getBenefit()
	return benefitStack
end

function WarMachine.getEventEnemy(eventData)
	local unitList = ClipOnMap.getUnitList("monster", "summoned")
	local unitArr = {}

	for i, unit in ipairs(unitList) do
		if unit.eventPack and unit.eventPack.eventData and unit.eventPack.eventData == eventData and unit.battleData.camp == 2 then
			table.insert(unitArr, unit)
		end
	end

	return unitArr
end

local logStack = {}

function WarMachine.logStart()
	WarMachine.log_on = true
	logStack = {}
end

function WarMachine.log(msg)
	if WarMachine.log_on then
		table.insert(logStack, {
			frame = WarMachine.frame,
			msg = msg
		})
	end
end

function WarMachine.logStop()
	if WarMachine.log_on then
		local hash = crypto.md5(json.encode(logStack))

		print("$$$ WarMachine.logStop hash:", hash)

		WarMachine.log_on = nil
		logStack = nil
	end
end

local tdData = nil

function WarMachine.getTdData()
	return tdData
end

function WarMachine.getTDMonsterLeft()
	return tdData.monsterLeft
end

function WarMachine.prepareTD(stageID)
	local stageCSV = CsvParser.getCsvData("td_stage", stageID)
	tdData = {
		csv = stageCSV,
		waveArr = SheetUtil.getColumnList(stageCSV, {
			"wave_",
			"enter_",
			"time_",
			"sign_"
		}, {
			"id",
			"enter",
			"time",
			"sign"
		}),
		waveIndex = 1,
		waveStack = {},
		life = stageCSV.life,
		monsterCount = 0
	}
	local monsterLeft = 0

	for i, v in ipairs(tdData.waveArr) do
		local waveData = CsvParser.getCsvData("td_wave", v.id)
		local monsterArr = SheetUtil.getColumnList(waveData, {
			"monster_",
			"num_"
		}, {
			"id",
			"num"
		})

		for j, v in ipairs(monsterArr) do
			monsterLeft = monsterLeft + v.num
		end
	end

	tdData.monsterLeft = monsterLeft
end

function WarMachine.startTD(seed)
	WarMachine.on = true
	WarMachine.isTD = true
	WarMachine.seed = seed
	WarMachine.random = Random.new(WarMachine.seed)
	local battleStart = MapEventManager.getEventByTagOne("td-enter")
	local centerTile = global.map:getTile(battleStart.x, battleStart.y)
	local areaTiles = MapUtils.spreadArea(global.map, centerTile, nil, , , true)

	WarMachine.setAreaTileMap(areaTiles)
	SkillManager.onBattleStart()
	MapFrameManager.startLoop(WarMachine, WarMachine.updateTD)

	tdData.enterMap = {}
	local eventArr = MapEventManager.getEventByTagArray("td-enter")

	for i, eventData in ipairs(eventArr) do
		local info = ConfParser.parse(eventData.info)
		tdData.enterMap[info.index] = eventData
		local path = MapEventManager.findLinkTo(eventData, "td-target", "td-node")
		eventData.targetEvent = path[#path]
		local tileArr = {}

		for ii = 1, eventData.w do
			for jj = 1, eventData.h do
				local tile = global.map:getTile(eventData.x + ii - 1, eventData.y + jj - 1)

				if tile then
					table.insert(tileArr, tile)
				end
			end
		end

		eventData.tileArr = tileArr
	end

	tdData.targetMap = {}
	local eventArr = MapEventManager.getEventByTagArray("td-target")

	for i, eventData in ipairs(eventArr) do
		eventData.targetArr = {}

		for i = 1, eventData.w do
			for j = 1, eventData.h do
				local tile = global.map:getTile(eventData.x + i - 1, eventData.y + j - 1)

				if tile then
					table.insert(eventData.targetArr, tile)

					tdData.targetMap[tile.tag] = true
				end
			end
		end
	end

	notify.dispatch("td_start")
end

function WarMachine.stopTD(isWin)
	if not WarMachine.on then
		return
	end

	Log.verbose("WarMachine.over")
	InfoModao.battleOver()
	MapFrameManager.stopLoop(WarMachine, WarMachine.updateTD)
	MapFrameManager.setMode(FrameLooper.MODE.NORMAL)

	for i = 1, #campStack do
		for j = 1, #campStack[i] do
			local unit = campStack[i][j]

			unit:onBattleOver()
			unit:resetBattle()
			unit:stop()
		end
	end

	WarMachine.on = false
	WarMachine.preFrame = WarMachine.frame
	WarMachine.frame = 0

	notify.dispatch("td_stop", isWin)
end

function WarMachine.prepareWave(waveIndex, waveID, enterIndex)
	local waveStack = tdData.waveStack
	local waveCSV = CsvParser.getCsvData("td_wave", waveID)
	local waveData = {
		count = 0,
		index = waveIndex,
		enterIndex = enterIndex,
		interval = waveCSV.interval
	}
	local monsterArr = SheetUtil.getColumnList(waveCSV, {
		"monster_",
		"type_",
		"num_"
	}, {
		"id",
		"type",
		"num"
	})
	local monArr = {}

	for i, v in ipairs(monsterArr) do
		for j = 1, v.num do
			table.insert(monArr, {
				id = v.id,
				type = v.type
			})
		end
	end

	if waveData.random_sort == 1 then
		WarMachine.random:order(monArr)
	end

	waveData.monArr = monArr

	table.insert(waveStack, waveData)
end

function WarMachine.makeWave(waveData)
	local isFin = false
	local map = global.map

	if waveData.count <= 0 then
		local monData = table.remove(waveData.monArr, 1)
		local tdmCSV = CsvParser.getCsvData("td_monster", monData.id)
		local monsterInfo = {
			base_id = tdmCSV.monster_id,
			level = tdData.csv.level + tdmCSV.ex_level
		}
		local monster = Monster.new(waveData.index)
		monster.seed = WarMachine.random:getInt(1, 65535)
		monster.random = Random.new(monster.seed)

		monster:setInfo(monsterInfo)

		local enterEvent = tdData.enterMap[waveData.enterIndex]
		local targetTile = enterEvent.targetEvent.targetArr[math.random(1, #enterEvent.targetEvent.targetArr)]

		monster:setTD(tdData, waveData, targetTile, tdmCSV)

		local tileArr = enterEvent.tileArr
		local tile = tileArr[math.random(1, #tileArr)]
		local x, y = map:tileToMap(tile)

		monster:display(map, x, y)
		WarMachine.addUnit(monster, 2, "TD.makeWave")
		monster:bornEffect()

		waveData.count = waveData.interval
		tdData.monsterCount = tdData.monsterCount + 1

		if #waveData.monArr == 0 then
			isFin = true
		end
	else
		waveData.count = waveData.count - 1
	end

	return isFin
end

function WarMachine.tdMonsterReach(monster)
	tdData.life = tdData.life - monster.tdmCSV.life_dmg

	notify.dispatch("td_life")

	if tdData.life <= 0 then
		WarMachine.stopTD(false)
	end
end

function WarMachine.tdMonsterDie(monster)
	tdData.monsterCount = tdData.monsterCount - 1
	tdData.monsterLeft = tdData.monsterLeft - 1

	notify.dispatch("td_monster_left")
end

function WarMachine.updateTD(obj, frame, passed, sharp)
	if WarMachine.paused then
		return
	end

	if sharp == 0 then
		return
	end

	for i = 1, sharp do
		WarMachine.frame = WarMachine.frame + 1

		if WarMachine.beforeUpdate then
			WarMachine.beforeUpdate()
		end

		if updateIndex > #unitStack and not WarMachine.releaseFromFreezeArray() then
			updateIndex = 1
		end

		for i = 1, #unitStack do
			local unit = unitStack[i]

			unit:battleUpdate(updateIndex == i)
		end

		for i = 1, #readyToRemoveStack do
			WarMachine.doRemoveUnit(readyToRemoveStack[i])
		end

		readyToRemoveStack = {}
		local waveData = tdData.waveArr[tdData.waveIndex]

		while waveData and waveData.time == WarMachine.frame do
			local waveID = waveData.id
			local enterIndex = waveData.enter

			WarMachine.prepareWave(tdData.waveIndex, waveID, enterIndex)

			tdData.waveIndex = tdData.waveIndex + 1
			waveData = tdData.waveArr[tdData.waveIndex]
		end

		local waveIndex = 1
		local waveStack = tdData.waveStack

		while waveStack[waveIndex] do
			local isFin = WarMachine.makeWave(waveStack[waveIndex])

			if isFin then
				table.remove(waveStack, waveIndex)
			else
				waveIndex = waveIndex + 1
			end
		end

		if tdData.waveIndex > #tdData.waveArr and #waveStack == 0 and campCount[2] == 0 then
			WarMachine.stopTD(true)
		end

		updateIndex = updateIndex + 1
	end
end

return WarMachine
