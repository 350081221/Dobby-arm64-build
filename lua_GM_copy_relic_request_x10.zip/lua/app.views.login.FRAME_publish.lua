local FRAME_publish = class("FRAME_publish", UI_base)

function FRAME_publish.open(text, _onClose)
	local ui = FRAME_publish.new(text, _onClose)

	PopManager.open(ui, nil, function ()
		ui:onClose()
	end)
end

function FRAME_publish:ctor(text, _onClose)
	FRAME_publish.super.ctor(self, "frame_publish", UIManager.BIG_TYPE.POP)

	self.text = text
	self._onClose = _onClose

	self:init()
end

function FRAME_publish:init()
	self:initUI()
	app:setKeyBackCallback(function ()
		PopManager.close()
	end)
end

function FRAME_publish:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local textArea = self:createTextAreaOnFlag("flag_text")

	textArea:setUbbEnabled(true)
	textArea:setSpace(10, 10)

	local holder = self:getComponentByTag("holder")

	textArea:setHolders({
		holder
	}, nil, 5)
	textArea:setText(self.text)
end

function FRAME_publish:onClose()
	app:clearKeyBackCallback()

	if self._onClose then
		self._onClose()
	end
end

return FRAME_publish
