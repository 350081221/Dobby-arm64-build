local UI_base = import("..UI_base")
local FRAME_actv_stage_ranking = class("FRAME_actv_stage_ranking", UI_base)

function FRAME_actv_stage_ranking.open(actv_id)
	local ui = FRAME_actv_stage_ranking.new(actv_id)

	PopManager.open(ui)
end

function FRAME_actv_stage_ranking:ctor(actv_id)
	FRAME_actv_stage_ranking.super.ctor(self, "frame_actv_stage_ranking", UIManager.BIG_TYPE.POP)

	self.actv_id = actv_id

	self:init()
end

function FRAME_actv_stage_ranking:init()
	self:initUI()

	self.isArea = false

	InfoActvStage.startRanking(self.actv_id, self.isArea, function ()
		self:refreshArea()
	end)
end

function FRAME_actv_stage_ranking:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local function unlockRequest()
		self.requestLocked = nil
	end

	local function tapListener(ui, data, index, x, y)
		local rankData = InfoActvStage.getRankingData(self.actv_id, data.rank, self.isArea)

		if rankData and rankData.user_id then
			local worldPos = self.list:convertToWorldSpace(cc.p(x, y))

			if ui:hitTestByComponent("rect_1", worldPos.x, worldPos.y, true) then
				POP_user_info.open(cc.p(worldPos.x, worldPos.y), rankData.user_id)
			elseif ui:hitTestByComponent("rect_2", worldPos.x, worldPos.y, true) then
				local time = Time.time()

				if self.requestLocked and time - self.requestLocked < 1 then
					return
				end

				self.requestLocked = time

				InfoActvStage.look(self.actv_id, rankData.user_id, function (rcvData)
					if rcvData.team and not empty(rcvData.team.copy) then
						FRAME_arena_look.open(rcvData.team)
					else
						Alert.open(Localization.getSrcText("队伍解析错误"))
					end

					unlockRequest()
				end, unlockRequest)
			end
		end
	end

	self.list = self:createListOnFlag("flag_list", LIST_actv_stage_ranking, tapListener, touchListener)

	self.list:setTapGroup("list_click")

	local holder = self:getComponentByTag("holder")

	self.list:setHolders({
		holder
	}, nil, 5)

	self.head = HeadSlot.new(self:getFlagByTag("flag_head"))

	self:addChild(self.head, 100)
end

function FRAME_actv_stage_ranking:refreshArea()
	local arr = {}
	local amount = InfoActvStage.getRankingAmount(self.actv_id)

	for i = 1, amount do
		table.insert(arr, {
			rank = i
		})
	end

	self.list:setIsArea(self.isArea, self.actv_id)
	self.list:setItems(arr)

	local myRank = InfoActvStage.getMyRank(self.actv_id)

	self:removeLabelOnFlag("flag_rank")
	self:removeLabelGroupOnFlag("flag_rank")

	if not empty(myRank) then
		local percent = math.max(0, 3 - (myRank - 1)) / 3

		self:replaceLabelGroupOnFlag("flag_rank", {
			myRank
		}, {
			{
				size = 28,
				color = Style.getColorBetween(Style.golden, Style.red, percent)
			}
		})
	else
		local actv_stage_ranking_num = CsvParser.getCsvData("config", "actv_stage_ranking_num").value
		local data = InfoActvStage.getData(self.actv_id)
		local ranking_max = InfoActvStage.getRankingMax(data.current) or actv_stage_ranking_num
		local str = Localization.getSrcText("未进入前{1}名")

		self:createLabelOnFlag("flag_rank", StringUtil.replace(str, ranking_max))
	end

	local snapshotStr = InfoActvStage.getRankingSnapshot(self.actv_id)
	local snapshot = {}

	if not empty(snapshotStr) then
		snapshot = json.decode(snapshotStr) or {}
	end

	local heros = snapshot.hero or {}

	for i = 1, 3 do
		self.slotMap = self.slotMap or {}
		local slot = self.slotMap[i]

		if heros[i] then
			if not slot then
				slot = DropSlot.new(self:getFlagByTag("slot_" .. i), "slot_01")

				self:addChild(slot, 100)

				self.slotMap[i] = slot
			end

			slot:setOpacity(255)

			local heroInfo = heros[i]

			slot:setDrop(DropManager.TYPE.HERO, heroInfo)
		elseif slot then
			slot:clearDrop()
			slot:setOpacity(100)
		end
	end

	self.head:setHead(InfoUser.getHead())
	self:createLabelOnFlag("flag_name", InfoUser.getNickName())
	self:removeLabelOnFlag("flag_time")
	self:removeLabelOnFlag("flag_level")

	local data = InfoActvStage.getData(self.actv_id)

	dump(data, "$$$ InfoActvStage.getData")

	if data and (data.passed_level > 1 or data.level_time > 0) then
		self:replaceLabelOnFlag("flag_level", nil, data.passed_level)
		self:createLabelOnFlag("flag_time", Time.showSec(data.level_time))
	end
end

return FRAME_actv_stage_ranking
