local InfoMail = {}
local TYPE = {
	GM = 1,
	PERSON = 2
}
InfoMail.TYPE = TYPE
local rawData = {}

function InfoMail.init()
	Connection.listen("mail_sync", InfoMail.sync)
end

app:addToAppEnterCall(InfoMail.init)

function InfoMail.query(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "mail_query")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			rawData = {}

			for i, data in ipairs(rcvData.list) do
				rawData[data.id] = data
			end

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("mail_query", callback)
end

function InfoMail.sync(data)
	dump(data, "$$$ InfoMail.sync")

	local changedIdStack = {}

	for i, syncData in ipairs(data.list) do
		local id = syncData.id

		if not rawData[id] then
			rawData[id] = syncData
		else
			for k, v in pairs(syncData) do
				rawData[id][k] = v
			end
		end

		changedIdStack[id] = rawData[id]
	end

	ManagerInfo.dataChange("mail", changedIdStack)
end

function InfoMail.getList()
	local arr = {}
	local nowTime = Time.now()

	for k, v in pairs(rawData) do
		if v.limit_level <= InfoDungeon.getAbyssMaxLevel() and v.stime <= nowTime and nowTime <= v.etime then
			table.insert(arr, {
				type = TYPE.GM,
				data = v
			})
		end
	end

	local personRawData = InfoMailPerson.getRawData()

	for k, v in pairs(personRawData) do
		if v.stime <= nowTime and nowTime <= v.etime then
			table.insert(arr, {
				type = TYPE.PERSON,
				data = v
			})
		end
	end

	table.sort(arr, function (a, b)
		local priorityA = InfoMail.getPriority(a.data)
		local priorityB = InfoMail.getPriority(b.data)

		if priorityA == priorityB then
			return a.data.etime < b.data.etime
		else
			return priorityB < priorityA
		end
	end)

	return arr
end

function InfoMail.markRead(mail_id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("mail_mark_read", {
		mail_id = mail_id
	}, callback)
end

function InfoMail.getAward(mail_id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("mail_get_award", {
		id_arr = {
			mail_id
		}
	}, callback)
end

function InfoMail.getAwardAll(onSuccess, onFailure)
	local nowTime = Time.now()
	local id_arr = {}

	for k, v in pairs(rawData) do
		if v.limit_level <= InfoDungeon.getAbyssMaxLevel() and v.stime <= nowTime and nowTime <= v.etime and InfoMail.hasAward(v) and v.is_award_get == 0 then
			table.insert(id_arr, v.id)
		end
	end

	if #id_arr == 0 then
		onSuccess({})

		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("mail_get_award", {
		id_arr = id_arr
	}, callback)
end

function InfoMail.hasAward(data)
	if data.award ~= "" and data.award ~= "{}" then
		local awards = json.decode(data.award)

		if awards and #awards > 0 then
			return true
		end
	end

	return false
end

function InfoMail.getPriority(data)
	if InfoMail.hasAward(data) and data.is_award_get == 0 then
		return 2
	elseif data.is_read == 0 and data.is_award_get == 0 then
		return 1
	else
		return 0
	end
end

function InfoMail.countRedot()
	local nowTime = Time.now()
	local redotCount = 0

	for k, v in pairs(rawData) do
		if v.limit_level <= InfoDungeon.getAbyssMaxLevel() and v.stime <= nowTime and nowTime <= v.etime then
			local priority = InfoMail.getPriority(v)

			if priority > 0 then
				redotCount = redotCount + 1
			end
		end
	end

	return redotCount
end

return InfoMail
