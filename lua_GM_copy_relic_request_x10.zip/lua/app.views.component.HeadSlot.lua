local UI_base = import("..UI_base")
local HeadSlot = class("HeadSlot", UI_base)

function HeadSlot:ctor(rect, uiName)
	HeadSlot.super.ctor(self, uiName or "head_slot")

	self.size = rect

	self:init()

	if rect then
		self:setPosition(rect.x, rect.y)
	end
end

function HeadSlot:init()
	self:initUI()
end

function HeadSlot:initUI()
	local originalWidth = self.width
	local originalHeight = self.height
	local rect = self:getFlagByTag("rect")

	if rect then
		originalWidth = rect.width
		originalHeight = rect.height
	end

	self.width = self.size.width
	self.height = self.size.height
	local widthOffset = 0
	local heightOffset = 0

	if self.width ~= originalWidth or self.height ~= originalHeight then
		widthOffset = self.width - originalWidth
		heightOffset = self.height - originalHeight
		local frameFlag = self:getFlagByTag("flag_frame")

		if frameFlag then
			frameFlag.width = frameFlag.width + widthOffset
			frameFlag.height = frameFlag.height + heightOffset
		end

		local iconSize = math.ceil(frameFlag.width * 90 / 128 / 2) * 2
		local iconFlag = self:getFlagByTag("flag_icon")
		iconFlag.width = iconSize
		iconFlag.height = iconSize
		iconFlag.x = (frameFlag.width - iconFlag.width) / 2
		iconFlag.y = (frameFlag.height - iconFlag.height) / 2
	end
end

function HeadSlot:clearDrop()
	self:removeIconOnFlag("flag_icon")
	self:removeIconOnFlag("flag_frame")
end

function HeadSlot:setHead(obj)
	local icon = obj.icon
	local frame = obj.frame

	if empty(icon) then
		icon = GameConfig.default_head
	end

	if empty(frame) then
		frame = GameConfig.default_head_frame
	end

	if self.iconSkeletons then
		for i, skeleton in ipairs(self.iconSkeletons) do
			skeleton:removeSelf()
		end

		self.iconSkeletons = nil
	end

	if self.frameSkeletons then
		for i, skeleton in ipairs(self.frameSkeletons) do
			skeleton:removeSelf()
		end

		self.frameSkeletons = nil
	end

	self:removeIconOnFlag("flag_icon")
	self:removeIconOnFlag("flag_frame")

	local itemCSV = CsvParser.getCsvData("item", icon, nil, true)

	if itemCSV then
		if string.sub(itemCSV.use_value1, 1, 1) == "@" then
			local spineName = string.sub(itemCSV.use_value1, 2)
			local skeletons = SpineHelper.createUI(spineName)
			local flag = self:getFlagByTag("flag_icon")

			for i, skeleton in ipairs(skeletons) do
				self:addChild(skeleton, skeleton.layer + 100)
				skeleton:setScale(skeleton.scale * flag.width / 90)
				skeleton:setPosition(flag.x + flag.width / 2, flag.y + flag.width / 2)
			end

			self.iconSkeletons = skeletons
		else
			local iconPath = IconManager.checkPath("image/pic/user_head/icon/" .. itemCSV.use_value1 .. ".png")

			self:createIconOnFlag("flag_icon", iconPath, 100, true)
		end
	end

	local itemCSV = CsvParser.getCsvData("item", frame, nil, true)

	if itemCSV then
		if string.sub(itemCSV.use_value1, 1, 1) == "@" then
			local spineName = string.sub(itemCSV.use_value1, 2)
			local skeletons = SpineHelper.createUI(spineName)
			local flag = self:getFlagByTag("flag_icon")

			for i, skeleton in ipairs(skeletons) do
				self:addChild(skeleton, skeleton.layer + 110)
				skeleton:setScale(skeleton.scale * flag.width / 90)
				skeleton:setPosition(flag.x + flag.width / 2, flag.y + flag.width / 2)
			end

			self.frameSkeletons = skeletons
		else
			local framePath = IconManager.checkPath("image/pic/user_head/frame/" .. itemCSV.use_value1 .. ".png")

			self:createIconOnFlag("flag_frame", framePath, 110, true)
		end
	end
end

return HeadSlot
