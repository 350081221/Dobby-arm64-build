local InfoAbyssPass = {}
local rawData = nil

function InfoAbyssPass.init()
	Connection.listen("abyss_pass_sync", InfoAbyssPass.sync)
end

app:addToAppEnterCall(InfoAbyssPass.init)

function InfoAbyssPass.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoAbyssPass.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("abyss_pass_query", callback)
end

function InfoAbyssPass.onQuery(rcvData)
	rawData = rcvData
end

function InfoAbyssPass.sync(syncData)
	for k, v in pairs(syncData) do
		rawData[k] = v
	end

	notify.dispatch("campaign_changed")
	ManagerInfo.dataChange("abyss_pass")
end

function InfoAbyssPass.getReward(id, is_pay, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("abyss_pass_get_reward", {
		id = id,
		is_pay = is_pay
	}, callback)
end

function InfoAbyssPass.getRewardAll(onSuccess, onFailure)
	local arr = {}
	local abyssLevel = InfoDungeon.getAbyssMaxLevel()
	local csvList = InfoAbyssPass.getGiftList(passID)

	for i, v in ipairs(csvList) do
		if v.abyss_level <= abyssLevel then
			local reward_arr = SheetUtil.getColumnList(v, {
				"free_reward_",
				"free_num_"
			}, {
				"base_id",
				"num"
			})
			local hasFree = #reward_arr > 0
			local reward_arr = SheetUtil.getColumnList(v, {
				"pay_reward_",
				"pay_num_"
			}, {
				"base_id",
				"num"
			})
			local hasPay = #reward_arr > 0

			if hasFree and InfoAbyssPass.getRecord(v.id) == 0 then
				table.insert(arr, {
					is_pay = 0,
					id = v.id
				})
			end

			if hasPay and InfoAbyssPass.getRecord(v.id, true) == 0 and InfoAbyssPass.isPaid(v.pass_id) then
				table.insert(arr, {
					is_pay = 1,
					id = v.id
				})
			end
		else
			break
		end
	end

	if #arr > 0 then
		local function callback(rcvData)
			if rcvData.err then
				if onFailure then
					onFailure(rcvData.err)
				end
			elseif onSuccess then
				onSuccess(rcvData)
			end
		end

		Connection.request("abyss_pass_get_reward_all", {
			list = arr
		}, callback)
	end
end

function InfoAbyssPass.getRecord(id, isPay)
	local section, position = BitUtil.split(30, id)
	local recordNum = nil

	if isPay then
		recordNum = rawData["pay_record_" .. section]
	else
		recordNum = rawData["free_record_" .. section]
	end

	return BitUtil.getBitByIndex(recordNum, position)
end

function InfoAbyssPass.countRedot(passID)
	local redotCount = 0
	local abyssLevel = InfoDungeon.getAbyssMaxLevel()
	local csvList = InfoAbyssPass.getGiftList(passID)

	for i, v in ipairs(csvList) do
		if v.abyss_level <= abyssLevel then
			local reward_arr = SheetUtil.getColumnList(v, {
				"free_reward_",
				"free_num_"
			}, {
				"base_id",
				"num"
			})
			local hasFree = #reward_arr > 0
			local reward_arr = SheetUtil.getColumnList(v, {
				"pay_reward_",
				"pay_num_"
			}, {
				"base_id",
				"num"
			})
			local hasPay = #reward_arr > 0

			if hasFree and InfoAbyssPass.getRecord(v.id) == 0 or hasPay and InfoAbyssPass.getRecord(v.id, true) == 0 and InfoAbyssPass.isPaid(v.pass_id) then
				redotCount = redotCount + 1
			end
		else
			break
		end
	end

	return redotCount
end

function InfoAbyssPass.isPaid(passID)
	return rawData["paid_" .. passID] > 0
end

function InfoAbyssPass.getGiftList(passID)
	local csvList = CsvParser.getCsvList("abyss_pass_gift", "id", {
		pass_id = passID
	})

	return csvList
end

function InfoAbyssPass.getNextSpReward(passID)
	local csvList = InfoAbyssPass.getGiftList(passID)

	for i, v in ipairs(csvList) do
		if v.pay_reward_sp == 1 and InfoAbyssPass.getRecord(v.id, true) == 0 then
			return v
		end
	end
end

function InfoAbyssPass.countGift(passID)
	local count = 0
	local abyssLevel = InfoDungeon.getAbyssMaxLevel()
	local csvList = InfoAbyssPass.getGiftList(passID)

	for i, v in ipairs(csvList) do
		local reward_arr = SheetUtil.getColumnList(v, {
			"free_reward_",
			"free_num_"
		}, {
			"base_id",
			"num"
		})
		local hasFree = #reward_arr > 0
		local reward_arr = SheetUtil.getColumnList(v, {
			"pay_reward_",
			"pay_num_"
		}, {
			"base_id",
			"num"
		})
		local hasPay = #reward_arr > 0

		if hasFree and InfoAbyssPass.getRecord(v.id) == 0 or hasPay and InfoAbyssPass.getRecord(v.id, true) == 0 then
			count = count + 1
		end
	end

	return count
end

function InfoAbyssPass.getPassList()
	local csvList = CsvParser.getCsvList("abyss_pass")
	local max_chapter = InfoChapter.getMaxID()
	local arr = {}

	for i, v in ipairs(csvList) do
		if v.chapter_id <= max_chapter then
			if InfoAbyssPass.countGift(v.id) > 0 then
				table.insert(arr, v)
			end
		else
			break
		end
	end

	return arr
end

return InfoAbyssPass
