local InfoHomeWorkshop = {}

function InfoHomeWorkshop.init()
	Connection.listen("home_workshop_shop_sync", InfoHomeWorkshop.sync)
end

app:addToAppEnterCall(InfoHomeWorkshop.init)

local shopList, otherShopList = nil

function InfoHomeWorkshop.sync(syncData)
	if syncData.item then
		local item = syncData.item

		if shopList then
			for i, v in ipairs(shopList) do
				if v.shop_id == item.shop_id then
					for k1, v1 in pairs(item) do
						v[k1] = v1
					end
				end
			end
		end
	end

	ManagerInfo.dataChange("home_workshop_shop")
end

function InfoHomeWorkshop.getShopLabels()
	return nil
end

function InfoHomeWorkshop.getShopLabelCSV()
	return "home_workshop_shop_label"
end

function InfoHomeWorkshop.clearOnReconnect()
	shopList = nil
end

function InfoHomeWorkshop.getShopList(_callback)
	local needQuery = shopList == nil

	if needQuery then
		local function callback(rcvData)
			dump(rcvData, "home_workshop_shop_list")

			if rcvData.err then
				-- Nothing
			else
				shopList = rcvData.items

				if _callback then
					_callback(shopList)
				end
			end
		end

		Connection.request("home_workshop_shop_list", callback)
	else
		_callback(shopList)
	end
end

function InfoHomeWorkshop.getShopItems()
	local arr = {}
	local multiLabel = false
	local infoMap = {}

	for i, v in ipairs(shopList) do
		local csv = CsvParser.getCsvData("home_workshop_shop", v.shop_id, nil, true)

		if csv and v.soldout < csv.times then
			infoMap[v.shop_id] = v
		end
	end

	local csvList = CsvParser.getCsvList("home_workshop_shop")

	for i, csv in ipairs(csvList) do
		if (empty(csv.building_id) or InfoBuilding.getBuildingFin(csv.building_id)) and (empty(csv.unlock_item) or InfoItem.getNum(csv.unlock_item) > 0) then
			if csv.times > 0 then
				if infoMap[csv.id] then
					table.insert(arr, infoMap[csv.id])
				end
			else
				table.insert(arr, {
					shop_id = csv.id
				})
			end
		end
	end

	table.sort(arr, function (a, b)
		return a.shop_id < b.shop_id
	end)
	dump(arr, "$$$ getShopItems")

	return arr, multiLabel
end

function InfoHomeWorkshop.buy(shop_id, num, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			InfoHomeWorkshop.sync(rcvData)

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("home_workshop_shop_buy", {
		shop_id = shop_id,
		num = num
	}, callback)
end

function InfoHomeWorkshop.getShopCSV()
	return "home_workshop_shop"
end

function InfoHomeWorkshop.getShopName()
	return "home_workshop_shop"
end

function InfoHomeWorkshop.getBuildingTag()
	return InfoBuilding.TAG.HOME_WORKSHOP
end

function InfoHomeWorkshop.getDelayItemType()
	return InfoDelayItem.TYPE.HOME_WORKSHOP
end

return InfoHomeWorkshop
