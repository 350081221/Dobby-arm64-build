local FRAME_tucao = class("FRAME_tucao", UI_base)

function FRAME_tucao.open(onConfirm)
	local ui = FRAME_tucao.new(onConfirm)

	display.getRunningScene():addChild(ui, LayerConfig.sys)
	PopManager.popinAnim(ui, callback, PopManager.ANIM_TYPE.JUMP)
end

function FRAME_tucao:ctor(onConfirm)
	FRAME_tucao.super.ctor(self, "frame_tucao")

	self.onConfirm = onConfirm

	self:init()
end

function FRAME_tucao:init()
	self:initUI()
end

function FRAME_tucao:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local mask = self:getComponentByTag("mask")

	mask:toTouchable()

	local inputEB = self:createEditBoxOnComponent("eb_input")

	inputEB:setInputMode(6)

	local confirmPB = self:getComponentByTag("confirm_pb")

	confirmPB:toTouchable()

	local function handleConfirm()
		local inputStr = inputEB:getText()

		if self.onConfirm then
			self.onConfirm(inputStr)
			PopManager.fadeoutAnim(self)
		else
			PopManager.fadeoutAnim(self)
		end
	end

	confirmPB:addTap(handleConfirm)

	local cancelPB = self:getComponentByTag("cancel_pb")

	cancelPB:toTouchable()

	local function handleCancel()
		PopManager.fadeoutAnim(self)
	end

	cancelPB:addTap(handleCancel)
	confirmPB:setTapGroup("button_click")
	cancelPB:setTapGroup("button_click")
end

return FRAME_tucao
