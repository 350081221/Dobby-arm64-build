local MapBackground = class("MapBackground", function (width, height, bgPic, bgScale, bgRatio)
	local node = display.newNode()

	return node
end)

function MapBackground:ctor(map, width, height, bgPic, bgScale, bgRatio)
	self.map = map
	self.width = width
	self.height = height
	self.picPath = getFinalRes("res/image/map_bg/" .. bgPic .. ".png")
	self.picScale = bgScale
	self.picRatio = bgRatio
	local sprite = display.newSprite(self.picPath)
	local size = sprite:getContentSize()
	self.blockW = math.floor(size.width * self.picScale)
	self.blockH = math.floor(size.height * self.picScale)
	self.gridW = math.ceil(self.width / self.blockW)
	self.gridH = math.ceil(self.height / self.blockH)
	self.spriteGrid = {}
end

function MapBackground:scrollTo(x, y)
	local halfWidth = self.width / 2
	local halfHeight = self.height / 2

	if self.picRatio ~= 1 then
		local posRatio = 1 - self.picRatio

		self:setPosition(x * posRatio, y * posRatio)

		x = math.floor(x * (1 - posRatio))
		y = math.floor(y * (1 - posRatio))
	end

	local preX = self.x
	local preY = self.y
	self.x = x
	self.y = y
	local border = 0
	local gridX = math.floor((x - halfWidth - border) / self.blockW)
	local gridY = math.floor((y - halfHeight - border) / self.blockH)
	local gridXMax = math.floor((x + halfWidth + border) / self.blockW)
	local gridYMax = math.floor((y + halfHeight + border) / self.blockH)
	local newRect = {
		x = gridX,
		y = gridY,
		width = gridXMax - gridX + 2,
		height = gridYMax - gridY + 2
	}
	local oldRect = nil

	if preX then
		local preGridX = math.floor((preX - halfWidth - border) / self.blockW)
		local preGridY = math.floor((preY - halfHeight - border) / self.blockH)
		local preGridXMax = math.floor((preX + halfWidth + border) / self.blockW)
		local preGridYMax = math.floor((preY + halfHeight + border) / self.blockH)
		oldRect = {
			x = preGridX,
			y = preGridY,
			width = preGridXMax - preGridX + 2,
			height = preGridYMax - preGridY + 2
		}
	end

	local newArr, oldArr = MapUtils.compareRect(newRect, oldRect)

	for i, v in ipairs(newArr) do
		self:drawGrid(v.x, v.y)
	end

	for i, v in ipairs(oldArr) do
		self:eraseGrid(v.x, v.y)
	end
end

function MapBackground:drawGrid(x, y)
	local tag = x .. "_" .. y

	if not self.spriteGrid[tag] then
		local sprite = display.newSprite(self.picPath)

		sprite:setScale(self.picScale)
		sprite:setPosition(x * self.blockW, y * self.blockH)
		self:addChild(sprite)

		self.spriteGrid[tag] = sprite
	end
end

function MapBackground:eraseGrid(x, y)
	local tag = x .. "_" .. y

	if self.spriteGrid[tag] then
		self.spriteGrid[tag]:removeSelf()

		self.spriteGrid[tag] = nil
	end
end

return MapBackground
