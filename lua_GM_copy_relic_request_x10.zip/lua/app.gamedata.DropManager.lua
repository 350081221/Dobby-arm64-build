local DropManager = {
	TYPE = {
		ARTIFACT = 30,
		GWAR_BUFF = 25,
		GWAR_HERO = 24,
		UNION_BUFF = 23,
		EQUIP_DUST = 22,
		EVENTSET = 21,
		EMOJI = 20,
		ITEM_GROWTH = 19,
		CHANCE = 18,
		PET_EQUIP = 17,
		GEM = 16,
		MIRROR = 15,
		GATHER = 14,
		PET = 13,
		PET_EGG = 12,
		ATTR = 11,
		CARD = 10,
		MODAO = 9,
		SHRINE = 8,
		SIGIL = 7,
		MONSTER = 6,
		BUFF = 5,
		HERO = 4,
		SKILL = 3,
		ITEM = 2,
		EQUIP = 1,
		NONE = 0
	}
}
local TYPE = DropManager.TYPE
local RARE_BASE = 100
local opArr = {
	"!=",
	">=",
	"<=",
	"=",
	">",
	"<"
}

local function checkCond(data, cond)
	local op, var = nil
	local values = {}

	for i, _op in ipairs(opArr) do
		local tagStart, tagEnd = string.find(cond, _op)

		if tagStart then
			op = _op
			var = string.sub(cond, 1, tagStart - 1)
			local value = string.sub(cond, tagEnd + 1)
			var = StringUtil.trim(var)
			value = StringUtil.trim(value)

			if string.find(value, ",") then
				local _values = string.split(value, ",")

				for i, v in ipairs(_values) do
					v = StringUtil.trim(v)

					if v ~= "" then
						table.insert(values, tonumber(v) or v)
					end
				end

				break
			end

			table.insert(values, tonumber(value) or value)

			break
		end
	end

	if data[var] == "" then
		return false
	end

	local orOK = false

	for i, value in ipairs(values) do
		if op == "!=" then
			orOK = data[var] ~= value
		elseif op == ">=" then
			orOK = value <= data[var]
		elseif op == "<=" then
			orOK = data[var] <= value
		elseif op == "=" then
			orOK = data[var] == value
		elseif op == ">" then
			orOK = value < data[var]
		elseif op == "<" then
			orOK = data[var] < value
		end

		if orOK then
			break
		end
	end

	return orOK
end

function DropManager.combineItems(...)
	local itemArrList = {
		...
	}
	local item_map = {}

	for i, itemArr in ipairs(itemArrList) do
		for i, itemData in ipairs(itemArr) do
			if not item_map[itemData.base_id] then
				item_map[itemData.base_id] = itemData.num
			else
				item_map[itemData.base_id] = item_map[itemData.base_id] + itemData.num
			end
		end
	end

	local itemArr = {}

	for base_id, num in pairs(item_map) do
		if num > 0 then
			table.insert(itemArr, {
				base_id = base_id,
				num = num
			})
		end
	end

	return itemArr
end

function DropManager.getRewardInfo(v)
	if v.type == DropManager.TYPE.EQUIP then
		return {
			type = v.type,
			info = InfoEquip.getInfo(v.equip_id)
		}
	elseif v.type == DropManager.TYPE.ITEM or v.type == DropManager.TYPE.ITEM_GROWTH then
		return {
			type = v.type,
			info = {
				base_id = v.item_id,
				num = v.item_num
			}
		}
	elseif v.type == DropManager.TYPE.CARD then
		return {
			type = v.type,
			info = InfoCard.getCardInfo(v.card_id)
		}
	elseif v.type == DropManager.TYPE.SIGIL then
		return {
			type = v.type,
			info = InfoSigil.getInfo(v.sigil_id)
		}
	elseif v.type == DropManager.TYPE.ARTIFACT then
		return {
			type = v.type,
			info = InfoArtifact.getInfo(v.artifact_id)
		}
	end
end

function DropManager.convertDropList(type, originalList)
	local list = {}

	for i, v in ipairs(originalList) do
		table.insert(list, {
			type = type,
			info = v
		})
	end

	return list
end

function DropManager.convertDrop(type, original)
	return {
		type = type,
		info = original
	}
end

function DropManager.popDetail(_type, info)
	if _type == TYPE.ITEM then
		FRAME_item_detail.open(info)
	elseif _type == TYPE.ITEM_GROWTH then
		FRAME_item_detail.openGrowth(info)
	elseif _type == TYPE.EQUIP then
		FRAME_equip_detail.open(info)
	elseif _type == TYPE.CARD then
		FRAME_card.open(info)
	elseif _type == TYPE.SKILL then
		if type(info) == "table" then
			FRAME_skill_detail.open(info.id or info.base_id)
		else
			FRAME_skill_detail.open(info)
		end
	elseif _type == TYPE.PET then
		FRAME_pet.open(info)
	elseif _type == TYPE.MONSTER then
		FRAME_monster_detail.open(info)
	elseif _type == TYPE.HERO then
		FRAME_hero.openDetail(info)
	elseif _type == TYPE.SIGIL then
		FRAME_sigil_detail.open(info)
	elseif _type == TYPE.ARTIFACT then
		FRAME_artifact.open(info)
	end
end

function DropManager.getName(_type, info)
	if _type == TYPE.ITEM then
		if empty(info.base_id) then
			return
		end

		local itemData = CsvParser.getCsvData("item", info.base_id)

		return itemData.name, itemData.quality
	elseif _type == TYPE.EQUIP then
		if empty(info.base_id) then
			return
		end

		local names, styles = InfoEquip.getNameDisplay(info)
		local name = ""

		for i, str in ipairs(names) do
			name = name .. str
		end

		return name, info.quality
	elseif _type == TYPE.CARD then
		if empty(info.base_id) then
			return
		end

		local cardData = CsvParser.getCsvData("card", info.base_id)

		return cardData.name, cardData.quality
	elseif _type == TYPE.SIGIL then
		if empty(info.base_id) then
			return
		end

		local sigilData = CsvParser.getCsvData("sigil", info.base_id)

		return sigilData.name, info.quality
	elseif _type == TYPE.ARTIFACT then
		if empty(info.base_id) then
			return
		end

		local artifactData = CsvParser.getCsvData("artifact", info.base_id)

		return artifactData.name, 4
	elseif _type == TYPE.SKILL then
		if empty(info) then
			return
		end

		local skillData = CsvParser.getCsvData("skill", baseID)

		return skillData.name, 0
	elseif _type == TYPE.HERO then
		return info.name, info.quality
	elseif _type == TYPE.PET then
		local petData = InfoPet.getData(info.base_id)

		return petData.name, info.quality
	elseif _type == TYPE.MONSTER then
		local monsterData = CsvParser.getCsvData("monster", info.base_id)

		return monsterData.name, 0
	end
end

function DropManager.dropLibGather(lib_id, drop_level, drop_rare, random, max_quality, probup_map)
	local dropLibData = CsvParser.getCsvData("drop_lib", lib_id)
	drop_rare = drop_rare + dropLibData.add_mf
	local rawBaseCondArr = SheetUtil.getColumnValueList(dropLibData, "base_")
	local baseConArr = {}

	for i, rawCond in ipairs(rawBaseCondArr) do
		local cond = StringUtil.replaceTag(rawCond, function (tag)
			if tag == "level" then
				return drop_level
			end
		end)

		table.insert(baseConArr, cond)
	end

	if max_quality then
		table.insert(baseConArr, "quality<=" .. max_quality)
	end

	if dropLibData.type == TYPE.GATHER then
		local baseID, data = DropManager.getBaseID("gather", drop_level, drop_rare, baseConArr, random, probup_map)

		return baseID, data
	end
end

function DropManager.dropLibEventset(lib_id, drop_level, drop_rare, random)
	local dropLibData = CsvParser.getCsvData("drop_lib", lib_id)
	drop_rare = drop_rare + dropLibData.add_mf
	local rawBaseCondArr = SheetUtil.getColumnValueList(dropLibData, "base_")
	local baseConArr = {}

	for i, rawCond in ipairs(rawBaseCondArr) do
		local cond = StringUtil.replaceTag(rawCond, function (tag)
			if tag == "level" then
				return drop_level
			end
		end)

		table.insert(baseConArr, cond)
	end

	if dropLibData.type == TYPE.EVENTSET then
		local baseID, itemData = DropManager.getBaseID("eventset", drop_level, drop_rare, baseConArr, random)

		return baseID, itemData
	end
end

function DropManager.dropLibShrine(lib_id, drop_level, drop_rare, random, max_quality)
	local dropLibData = CsvParser.getCsvData("drop_lib", lib_id)
	drop_rare = drop_rare + dropLibData.add_mf
	local rawBaseCondArr = SheetUtil.getColumnValueList(dropLibData, "base_")
	local baseConArr = {}

	for i, rawCond in ipairs(rawBaseCondArr) do
		local cond = StringUtil.replaceTag(rawCond, function (tag)
			if tag == "level" then
				return drop_level
			end
		end)

		table.insert(baseConArr, cond)
	end

	if max_quality then
		table.insert(baseConArr, "quality<=" .. max_quality)
	end

	if dropLibData.type == TYPE.SHRINE then
		local baseID, itemData = DropManager.getBaseID("shrine", drop_level, drop_rare, baseConArr, random)

		return baseID, itemData
	end
end

function DropManager.dropLibChance(lib_id, drop_level, drop_rare, random)
	local dropLibData = CsvParser.getCsvData("drop_lib", lib_id)
	drop_rare = drop_rare + dropLibData.add_mf
	local rawBaseCondArr = SheetUtil.getColumnValueList(dropLibData, "base_")
	local baseConArr = {}

	for i, rawCond in ipairs(rawBaseCondArr) do
		local cond = StringUtil.replaceTag(rawCond, function (tag)
			if tag == "level" then
				return drop_level
			end
		end)

		table.insert(baseConArr, cond)
	end

	if dropLibData.type == TYPE.CHANCE then
		local baseID, itemData = DropManager.getBaseID("chance", drop_level, drop_rare, baseConArr, random)

		return baseID, itemData
	end
end

function DropManager.dropLibMonster(lib_id, drop_level, drop_rare, random)
	local dropLibData = CsvParser.getCsvData("drop_lib", lib_id)
	drop_rare = drop_rare + dropLibData.add_mf
	local rawBaseCondArr = SheetUtil.getColumnValueList(dropLibData, "base_")
	local baseConArr = {}

	for i, rawCond in ipairs(rawBaseCondArr) do
		local cond = StringUtil.replaceTag(rawCond, function (tag)
			if tag == "level" then
				return drop_level
			end
		end)

		table.insert(baseConArr, cond)
	end

	if dropLibData.type == TYPE.MONSTER then
		local baseID, itemData = DropManager.getBaseID("monster", drop_level, drop_rare, baseConArr, random)

		return baseID, itemData
	end
end

function DropManager.dropLibAttr(lib_id, drop_level, drop_rare, random)
	local dropLibData = CsvParser.getCsvData("drop_lib", lib_id)
	drop_rare = drop_rare + dropLibData.add_mf
	local baseConArr = SheetUtil.getColumnValueList(dropLibData, "base_")

	if dropLibData.type == TYPE.ATTR then
		local baseID, itemData = DropManager.getBaseID("attr", drop_level, drop_rare, baseConArr, random)

		return baseID, itemData
	end
end

function DropManager.dropLib(lib_id, drop_level, drop_rare, random, itemStack, isAbyss)
	local dropLibData = CsvParser.getCsvData("drop_lib", lib_id)

	if dropLibData.is_peak_drop == 1 and InfoParams.getValue("peak") ~= 1 then
		return
	end

	if dropLibData.is_sigil_drop == 1 and InfoParams.getValue("sigil") ~= 1 then
		return
	end

	if dropLibData.is_artifact_drop == 1 and InfoParams.getValue("artifact") ~= 1 then
		return
	end

	drop_rare = drop_rare + dropLibData.add_mf
	local rawBaseCondArr = SheetUtil.getColumnValueList(dropLibData, "base_")
	local baseConArr = {}

	for i, rawCond in ipairs(rawBaseCondArr) do
		local cond = StringUtil.replaceTag(rawCond, function (tag)
			if tag == "level" then
				return drop_level
			end
		end)

		table.insert(baseConArr, cond)
	end

	if dropLibData.type == TYPE.ITEM then
		local baseID, itemData = DropManager.getBaseID("item", drop_level, drop_rare, baseConArr, random)

		if baseID then
			local dropNum = SheetUtil.getNumber(dropLibData.num, random)

			if isAbyss or global.gmDropLimit == 1 then
				local probLimit = InfoItemLimit.getAbyssLimit(baseID)

				if probLimit and probLimit < random:next() then
					dropNum = 0
				end
			end

			if dropNum > 0 then
				local itemInfo = DropManager.generateItem(baseID, drop_level, drop_rare, dropNum, random, itemData)

				if itemInfo.num > 0 then
					itemInfo.quality = itemData.quality

					table.insert(itemStack, itemInfo)
				end
			end
		end
	end
end

local affixGenCache = nil

function DropManager.getAffixGen(equip_level, drop_rare, agenCondArr, random, isTest)
	local cache_key = "affix_quality_level_rare@" .. equip_level
	local cond_level_map = {}

	for i, cond in ipairs(agenCondArr) do
		local sBegan, sEnd = string.find(cond, "{level}", 1, true)

		if not sBegan then
			cache_key = cache_key .. "_" .. cond
		else
			cond_level_map[cond] = true
		end
	end

	local rawData = CsvParser.getCsvList("affix_gen")
	local idArray = {}

	for i, data in ipairs(rawData) do
		if data.level <= equip_level then
			if data.rare ~= "" and data.rare > 0 then
				local condOK = true

				for i, cond in ipairs(agenCondArr) do
					if not cond_level_map[cond] and not checkCond(data, cond) then
						condOK = false

						break
					end
				end

				if condOK then
					table.insert(idArray, data.id)
				end
			end
		else
			break
		end
	end

	if #idArray > 0 then
		local cond_level_arr = {}

		for cond, v in pairs(cond_level_map) do
			local cond_level = StringUtil.replaceTag(cond, {
				level = equip_level
			})

			table.insert(cond_level_arr, cond_level)
		end

		local power_arr = {}
		local okArray = {}

		for i, id in ipairs(idArray) do
			local data = CsvParser.getCsvData("affix_gen", id)
			local levelCondOK = true

			for i1, cond_level in ipairs(cond_level_arr) do
				if not checkCond(data, cond_level) then
					levelCondOK = false

					break
				end
			end

			if levelCondOK then
				local power = data.rare * RARE_BASE / (RARE_BASE + drop_rare * data.mf_ratio)
				power = 1 / power

				table.insert(power_arr, power)
				table.insert(okArray, id)
			end
		end

		if #okArray > 0 then
			local power_index = SheetUtil.getPowerRandomIndex(power_arr, random)
			local genID = okArray[power_index]
			local genData = CsvParser.getCsvData("affix_gen", genID)

			return genData
		end
	end
end

function DropManager.dropLibLocal(lib_id, drop_level, drop_rare, random, isolated_random)
	local dropLibData = CsvParser.getCsvData("drop_lib", lib_id)
	drop_rare = drop_rare + dropLibData.add_mf
	local rawBaseCondArr = SheetUtil.getColumnValueList(dropLibData, "base_")
	local baseConArr = {}

	for i, rawCond in ipairs(rawBaseCondArr) do
		local cond = StringUtil.replaceTag(rawCond, function (tag)
			if tag == "level" then
				return drop_level
			end
		end)

		table.insert(baseConArr, cond)
	end

	local result = {}

	if dropLibData.type == TYPE.EQUIP then
		local dropNum = SheetUtil.getNumber(dropLibData.num, isolated_random)

		for j = 1, dropNum do
			local agenCondArr = SheetUtil.getColumnValueList(dropLibData, "agen_")
			local affixGen = DropManager.getAffixGen(drop_level, drop_rare, agenCondArr, isolated_random)
			affixGen = affixGen or DropManager.getAffixGen(drop_level, drop_rare, {}, isolated_random)

			if affixGen then
				local quality = affixGen.quality
				local _baseConArr = {}

				for i, rawCond in ipairs(baseConArr) do
					local cond = StringUtil.replaceTag(rawCond, {
						quality = quality
					})

					table.insert(_baseConArr, cond)
				end

				local baseID, equipData = nil

				if dropLibData.type == TYPE.EQUIP_DUST then
					local _baseID = DropManager.getBaseID("dust_equip", drop_level, drop_rare, _baseConArr, isolated_random)

					if _baseID then
						baseID = _baseID
						equipData = CsvParser.getCsvData("equip", baseID)
					end
				else
					baseID, equipData = DropManager.getBaseID("equip", drop_level, drop_rare, _baseConArr, isolated_random)
				end

				if baseID then
					if not empty(equipData.suit_id) then
						affixGen = CsvParser.getCsvData("affix_gen", GameConfig.SUIT_QUALITY)
					end

					local customEquipLevel = nil

					if not empty(dropLibData.equip_level) then
						customEquipLevel = SheetUtil.getNumber(dropLibData.equip_level, isolated_random)
					end

					local equipInfo = DropManager.generateEquip(baseID, drop_level, drop_rare, affixGen, isolated_random, customEquipLevel)

					table.insert(result, equipInfo)
				end
			end
		end
	elseif dropLibData.type == TYPE.CARD then
		local dropNum = SheetUtil.getNumber(dropLibData.num, isolated_random)

		for j = 1, dropNum do
			local baseID, cardData = DropManager.getBaseID("card", drop_level, drop_rare, baseConArr, isolated_random)

			if baseID then
				local cardInfo = DropManager.generateCard(baseID, drop_level, drop_rare, isolated_random)
				cardInfo.quality = cardData.quality

				table.insert(result, cardInfo)
			end
		end
	end

	return result
end

function DropManager.drop(drop_id, drop_level, drop_rare, seed, isAbyss)
	local itemStack = {}
	local random = Random.new(seed)
	local dropData = CsvParser.getCsvData("drop", drop_id)
	local dropQueue = SheetUtil.getColumnValueList(dropData, "lib_id")

	for i, dropStr in ipairs(dropQueue) do
		local dropLibStr = SheetUtil.getString(dropStr, random)

		if not empty(dropLibStr) then
			local dropLibArr = string.split(dropLibStr, ",")
			local dropLibID = dropLibArr[1]
			local dropLibNum = SheetUtil.getNumber(dropLibArr[2], random)

			for j = 1, dropLibNum do
				DropManager.dropLib(dropLibID, drop_level, drop_rare, random, itemStack, isAbyss)
			end
		end
	end

	return itemStack
end

local baseIDArrayStack = {}

function DropManager.getBaseID(typeName, drop_level, drop_rare, baseConArr, random, probup_map)
	local cache_key = "drop_raw_array@" .. typeName

	for i, v in ipairs(baseConArr) do
		cache_key = cache_key .. "_" .. v
	end

	local itemArray = baseIDArrayStack[cache_key]

	if not itemArray then
		itemArray = {}
		local rawData = CsvParser.getCsvList(typeName)

		for index, data in ipairs(rawData) do
			if data.rare ~= "" and data.rare > 0 then
				local condOK = true

				for i, cond in ipairs(baseConArr) do
					if not checkCond(data, cond) then
						condOK = false

						break
					end
				end

				if condOK then
					table.insert(itemArray, data)
				end
			end
		end

		baseIDArrayStack[cache_key] = itemArray
	end

	if #itemArray > 0 then
		local power_arr = {}

		for i, data in ipairs(itemArray) do
			if data.rare ~= "" then
				local power = data.rare

				if power > 0 then
					power = 1 / power

					if probup_map then
						local upValue = probup_map[data.id]

						if upValue then
							power = power * (1 + upValue / 100)
						end
					end

					power = math.pow(power, RARE_BASE / (RARE_BASE + drop_rare))

					table.insert(power_arr, power)
				end
			end
		end

		local power_index = SheetUtil.getPowerRandomIndex(power_arr, random)
		local itemData = itemArray[power_index]

		return itemData.id, itemData
	end
end

local function funcItemDropNum(base_id)
	if base_id == 100100 then
		return 100
	else
		return 0
	end
end

function DropManager.generateItem(base_id, drop_level, drop_rare, drop_num, random, itemData)
	if itemData.is_precious == 1 then
		local currentNum = InfoItem.getNum(base_id)
		local maxNum = GameConfig.max_num

		if not empty(itemData.max) then
			maxNum = itemData.max
		end

		drop_num = math.min(drop_num, maxNum - currentNum)
	end

	local itemInfo = {
		base_id = base_id,
		num = drop_num
	}

	return itemInfo
end

function DropManager.generateEquip(base_id, drop_level, drop_rare, affixGen, random, customEquipLevel)
	local equip_csv = CsvParser.getCsvData("equip", base_id)
	local equip_class = equip_csv.class
	local equip_level = equip_csv.level
	local ranfix_num = SheetUtil.getNumber(affixGen.ranfix_num, random)
	local prefix_num = SheetUtil.getNumber(affixGen.prefix_num, random)
	local suffix_num = SheetUtil.getNumber(affixGen.suffix_num, random)
	local prefixNum = random:getInt(0, ranfix_num)
	local suffixNum = ranfix_num - prefixNum
	prefixNum = prefixNum + prefix_num
	suffixNum = suffixNum + suffix_num
	local affix_pos_arr = {}

	for i = 1, prefixNum do
		table.insert(affix_pos_arr, 1)
	end

	for i = 1, suffixNum do
		table.insert(affix_pos_arr, 2)
	end

	local quality = affixGen.quality
	local equip_level = nil

	if customEquipLevel then
		equip_level = customEquipLevel
	else
		local abyssBaseCSV = CsvParser.getCsvData("abyss_base_num", drop_level)
		local rareArr = SheetUtil.getColumnList(abyssBaseCSV, {
			"equip_level_",
			"equip_rare_"
		}, {
			"level",
			"rare"
		})
		local powerArr = {}
		local levelArr = {}

		for i, v in ipairs(rareArr) do
			if v.rare > 0 then
				table.insert(powerArr, 1 / v.rare)
				table.insert(levelArr, v.level)
			end
		end

		local powerIndex = SheetUtil.getPowerRandomIndex(powerArr, random)
		equip_level = levelArr[powerIndex]
	end

	local prefixArray = {}
	local suffixArray = {}

	for j, affix_pos in ipairs(affix_pos_arr) do
		local affix_list = DropManager.getAffixID(equip_class, affix_pos, random)

		if #affix_list > 0 then
			local power_arr = {}

			for i, affix in ipairs(affix_list) do
				local rare = affix.rare

				if rare > 0 then
					local power = 1 / rare

					table.insert(power_arr, power)
				else
					table.insert(power_arr, 0)
				end
			end

			local power_index = SheetUtil.getPowerRandomIndex(power_arr, random)

			if power_index then
				local affixID = affix_list[power_index].id

				if affix_pos == 1 then
					table.insert(prefixArray, affixID)
				else
					table.insert(suffixArray, affixID)
				end
			end
		end
	end

	local best_prefix = DropManager.getBestAffix(prefixArray)
	local best_suffix = DropManager.getBestAffix(suffixArray)
	local slotMax, slotNum = nil

	if equip_csv.fixed_slot == "" or tonumber(equip_csv.fixed_slot) == nil then
		slotMax = SheetUtil.getNumber(equip_csv.slot_max, random)
		local slotGen = SheetUtil.getNumber(affixGen.slot_num, random)
		slotNum = math.min(slotMax, slotGen)
	else
		slotNum = tonumber(equip_csv.fixed_slot)
	end

	local equip_info = {
		identified = 0,
		base_id = base_id,
		equip_pos = equip_csv.equip_pos,
		ran = random:getInt(1, 65535),
		best_prefix = best_prefix,
		best_suffix = best_suffix,
		slot = slotNum,
		slot_max = slotMax,
		quality = quality,
		drop_level = drop_level,
		level = equip_level,
		drop_rare = drop_rare
	}

	for i = 1, GameConfig.equip_affix_max do
		equip_info["prefix_" .. i] = prefixArray[i] or 0

		if equip_info["prefix_" .. i] ~= 0 then
			equip_info["preran_" .. i] = random:getInt(1, 65535)
		else
			equip_info["preran_" .. i] = 0
		end

		equip_info["suffix_" .. i] = suffixArray[i] or 0

		if equip_info["suffix_" .. i] ~= 0 then
			equip_info["sufran_" .. i] = random:getInt(1, 65535)
		else
			equip_info["sufran_" .. i] = 0
		end
	end

	for i = 1, GameConfig.equip_gem_max do
		equip_info["gem" .. i] = 0
	end

	equip_info.dust_id = 0
	equip_info.dust_sp_attr = 0
	equip_info.dust_sp_ran = 0

	for i = 1, GameConfig.equip_dust_max do
		equip_info["dust_id_" .. i] = 0
		equip_info["dust_ran_" .. i] = 0
		equip_info["dust_level_" .. i] = 0
		equip_info["dust_exp_" .. i] = 0
	end

	return equip_info
end

function DropManager.generateCard(base_id, drop_level, drop_rare, random)
	local cardData = CsvParser.getCsvData("card", base_id)
	local card_info = {
		exp = 0,
		star = 1,
		level = 1,
		base_id = base_id,
		ran = random:getInt(1, 65535),
		drop_level = drop_level,
		drop_rare = drop_rare,
		growth_1 = random:getInt(math.floor(cardData.growth_min_1 * 1000), math.floor(cardData.growth_max_1 * 1000)),
		growth_2 = random:getInt(math.floor(cardData.growth_min_2 * 1000), math.floor(cardData.growth_max_2 * 1000)),
		growth_3 = random:getInt(math.floor(cardData.growth_min_3 * 1000), math.floor(cardData.growth_max_3 * 1000)),
		limit_1 = math.floor(cardData.growth_limit_1 * 1000),
		limit_2 = math.floor(cardData.growth_limit_2 * 1000),
		limit_3 = math.floor(cardData.growth_limit_3 * 1000)
	}

	return card_info
end

function DropManager.getBestAffix(affixArray)
	local bestLevel, readyArray = nil

	for i, affixID in ipairs(affixArray) do
		local affixCSV = CsvParser.getCsvData("affix", affixID)

		if not bestLevel or bestLevel < affixCSV.level_min then
			readyArray = {
				affixID
			}
		elseif affixCSV.level_min == bestLevel then
			table.insert(readyArray, affixID)
		end
	end

	if readyArray and #readyArray > 0 then
		return readyArray[math.random(1, #readyArray)]
	else
		return 0
	end
end

function DropManager.getAffixID(equip_class, affix_pos, random)
	local rawData = CsvParser.getCsvRaw("affix")
	local idArray = {}

	for k, itemData in pairs(rawData) do
		if itemData.rare ~= "" and itemData.rare > 0 and itemData.pos == affix_pos then
			local target_class = itemData.target_class
			local target_class_arr = string.split(target_class, ",")
			local include_class = false

			for i, v in ipairs(target_class_arr) do
				if tonumber(v) == equip_class then
					include_class = true

					break
				end
			end

			if include_class then
				table.insert(idArray, itemData.id)
			end
		end
	end

	local affixArray = {}

	for i, id in ipairs(idArray) do
		local data = CsvParser.getCsvData("affix", id)

		table.insert(affixArray, data)
	end

	return affixArray
end

function DropManager.getBaseIDList(typeName, drop_level, drop_rare, baseConArr)
	local cache_key = "drop_raw_array@" .. typeName

	for i, v in ipairs(baseConArr) do
		cache_key = cache_key .. "_" .. v
	end

	local itemArray = baseIDArrayStack[cache_key]

	if not itemArray then
		itemArray = {}
		local rawData = CsvParser.getCsvList(typeName)

		for index, data in ipairs(rawData) do
			if data.rare ~= "" and data.rare > 0 then
				local condOK = true

				for i, cond in ipairs(baseConArr) do
					if not checkCond(data, cond) then
						condOK = false

						break
					end
				end

				if condOK then
					table.insert(itemArray, data)
				end
			end
		end

		baseIDArrayStack[cache_key] = itemArray
	end

	if #itemArray > 0 then
		local powerTotal = 0
		local power_arr = {}

		for i, data in ipairs(itemArray) do
			if data.rare ~= "" then
				local power = data.rare

				if power > 0 then
					power = 1 / power
					power = math.pow(power, RARE_BASE / (RARE_BASE + drop_rare))

					table.insert(power_arr, {
						base_id = data.id,
						power = power
					})

					powerTotal = powerTotal + power
				end
			end
		end

		return power_arr, powerTotal
	end

	return {}
end

local showDropType = {
	[DropManager.TYPE.ITEM] = "item",
	[DropManager.TYPE.EQUIP] = "equip",
	[DropManager.TYPE.CARD] = "card",
	[DropManager.TYPE.SIGIL] = "sigil",
	[DropManager.TYPE.ARTIFACT] = "artifact"
}

function DropManager.getDropList(drop_id, drop_level, drop_rare)
	local dropData = CsvParser.getCsvData("drop", drop_id)
	local dropQueue = SheetUtil.getColumnValueList(dropData, "lib_id")

	return DropManager.getDropQueue(dropQueue, drop_level, drop_rare)
end

function DropManager.getDropLibList(drop_lib_id, drop_level, drop_rare)
	return DropManager.getDropQueue({
		drop_lib_id .. ",1"
	}, drop_level, drop_rare)
end

function DropManager.getDropQueue(dropQueue, drop_level, drop_rare)
	local mustArr = {}
	local probArr = {}

	for iii, value in ipairs(dropQueue) do
		local valueArr = {}
		local hasZero = false
		local hasProb = false

		if type(value) == "number" then
			table.insert(valueArr, {
				power = 100,
				lib_id = value
			})
		elseif not string.find(value, ";") then
			if not string.find(value, ":") then
				table.insert(valueArr, {
					power = 100,
					lib_id = value
				})
			else
				local pairArr = string.split(value, ":")

				table.insert(valueArr, {
					power = 100,
					lib_id = pairArr[1]
				})
			end
		elseif not string.find(value, ":") then
			local _valueArr = string.split(value, ";")

			for ii, v in ipairs(_valueArr) do
				if v ~= "" then
					table.insert(valueArr, {
						power = 100,
						lib_id = v
					})
				end
			end
		else
			local _valueArr = string.split(value, ";")

			for i, v in ipairs(_valueArr) do
				if v ~= "" then
					local pairArr = string.split(v, ":")

					table.insert(valueArr, {
						lib_id = pairArr[1],
						power = tonumber(pairArr[2])
					})
				end
			end
		end

		local powerTotal = 0

		for i, v in ipairs(valueArr) do
			powerTotal = powerTotal + v.power
		end

		local libDropArr = {}

		for ii, v in ipairs(valueArr) do
			local dropLibArr = string.split(v.lib_id, ",")
			local dropLibID = dropLibArr[1]
			local dropLibNum = SheetUtil.getNumber(dropLibArr[2], random)
			local prob = v.power / powerTotal

			if dropLibNum > 0 then
				local dropLibData = CsvParser.getCsvData("drop_lib", dropLibID)

				if not empty(dropLibData.base_1) then
					local typeName = showDropType[dropLibData.type]

					if typeName then
						local rawBaseCondArr = SheetUtil.getColumnValueList(dropLibData, "base_")
						local baseConArr = {}

						for i, rawCond in ipairs(rawBaseCondArr) do
							local cond = StringUtil.replaceTag(rawCond, function (tag)
								if tag == "level" then
									return drop_level
								end
							end)

							table.insert(baseConArr, cond)
						end

						local arr, pTotal = DropManager.getBaseIDList(typeName, drop_level, drop_rare, baseConArr)

						for i, v in ipairs(arr) do
							local data = {
								type = dropLibData.type,
								num = dropLibData.num,
								base_id = v.base_id,
								prob = prob * v.power / pTotal
							}

							if dropLibData.type == TYPE.CARD then
								data.level = 1
								data.star = 1
								data.exp = 1
								data.level_limit = 1
							elseif dropLibData.type == TYPE.EQUIP then
								local sampleEquip = InfoEquip.getSampleEquip(v.base_id, true)

								for key, value in pairs(sampleEquip) do
									data[key] = value
								end

								if not empty(dropLibData.equip_level) then
									data.level = dropLibData.equip_level
								end
							elseif dropLibData.type == TYPE.SIGIL then
								local sampleSigil = InfoSigil.getSampleSigil(v.base_id, true)

								if not empty(dropLibData.sigil_level) then
									sampleSigil.level = dropLibData.sigil_level
								end

								if not empty(dropLibData.sigil_quality) then
									sampleSigil.quality = dropLibData.sigil_quality
								end
							elseif dropLibData.type == TYPE.ARTIFACT then
								local sampleArtifact = InfoArtifact.getSample(v.base_id)
							end

							table.insert(libDropArr, data)
						end

						if #arr > 1 then
							hasProb = true
						end
					end
				end
			else
				hasZero = true
			end

			if prob < 1 then
				hasProb = true
			end
		end

		if hasProb then
			table.insert(probArr, {
				arr = libDropArr,
				hasZero = hasZero
			})
		elseif not hasZero then
			for i, v in ipairs(libDropArr) do
				table.insert(mustArr, v)
			end
		end
	end

	local finalArr = {}

	if #mustArr > 0 then
		table.insert(finalArr, {
			type = 1,
			arr = mustArr
		})
	end

	for i, v in ipairs(probArr) do
		table.insert(finalArr, {
			arr = v.arr,
			type = v.hasZero and 3 or 2
		})
	end

	local function getQuality(type, base_id)
		if type == TYPE.ITEM then
			local csv = CsvParser.getCsvData("item", base_id)

			return csv.quality
		elseif type == TYPE.CARD then
			local csv = CsvParser.getCsvData("card", base_id)

			return csv.quality
		else
			return 0
		end
	end

	for i, v in ipairs(finalArr) do
		local arr = v.arr

		table.sort(arr, function (a, b)
			if a.prob == b.prob then
				local qualityA = getQuality(a.type, a.base_id)
				local qualityB = getQuality(b.type, b.base_id)

				return qualityB < qualityA
			else
				return a.prob < b.prob
			end
		end)
	end

	return finalArr
end

function DropManager.clearOnScene()
	baseIDArrayStack = {}
end

return DropManager
