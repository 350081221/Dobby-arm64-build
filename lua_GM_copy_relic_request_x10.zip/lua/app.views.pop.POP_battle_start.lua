local POP_battle_start = class("POP_battle_start", UI_base)

function POP_battle_start.open(maxClass, winType, winParam)
	local ui = POP_battle_start.new(maxClass, winType, winParam)

	display.getRunningScene():addChild(ui, LayerConfig.pop)
end

function POP_battle_start:ctor(maxClass, winType, winParam)
	local uiName = nil

	if winType == 1 then
		uiName = "pop_battle_start_defence"
	elseif maxClass == 11 then
		uiName = "pop_battle_start_elite"
	elseif maxClass == 12 then
		uiName = "pop_battle_start_boss"
	else
		uiName = "pop_battle_start"
	end

	POP_battle_start.super.ctor(self, uiName)

	self.maxClass = maxClass
	self.winType = winType
	self.winParam = winParam

	self:init()
end

function POP_battle_start:init()
	self:initUI()
	self:fadeIn()
	MapEffect.bulletTime("POP_battle_start", 0.4, 30)

	local mask = self:getComponentByTag("mask")
	local outTime = 45

	if self.winType == 1 then
		outTime = 60
	end

	Looper.setTimeout(function ()
		self:fadeOut()
		transition.fadeTo(mask, {
			easing = "sineOut",
			opacity = 0,
			time = 0.2,
			onComplete = function ()
				mask:setVisible(false)
			end
		})
	end, outTime, self)
	transition.fadeTo(mask, {
		easing = "sineIn",
		time = 0.2,
		opacity = 64
	})
end

function POP_battle_start:initUI()
	local mask = self:getComponentByTag("mask")

	mask:setOpacity(0)

	if self.winType == 1 then
		self:replaceLabelOnFlag("flag_name", nil, Time.formatMinite(self.winParam / 60))
	end
end

function POP_battle_start:fadeIn()
	local line1 = self:getComponentByTag("line_1")
	local line2 = self:getComponentByTag("line_2")
	local lineWidth = line1.width
	local countMax = 15
	local count = 0

	local function updateLineAnimate(elapsed_time)
		if count < countMax then
			count = math.min(countMax, count + 60 * elapsed_time)
			local widthPercent = (countMax / 2 * count - count * count / 2) / countMax / countMax * 8
			local width = lineWidth * (1 + widthPercent)

			line1:setSize(width)
			line2:setSize(width)

			local line1x = display.cx * count / countMax

			line1:setPos(line1x - width / 2)

			local line2x = display.cx * (1 - count / countMax) + display.cx

			line2:setPos(line2x - width / 2)
		else
			self:removeEnterFrame("updateLineAnimate")
		end
	end

	self:addEnterFrame("updateLineAnimate", updateLineAnimate)
end

function POP_battle_start:fadeOut()
	local line1 = self:getComponentByTag("line_1")
	local line2 = self:getComponentByTag("line_2")
	local lineWidth = line1.width

	transition.moveTo(line1, {
		easing = "sineOut",
		time = 0.3,
		x = display.width + lineWidth / 2
	})
	transition.moveTo(line2, {
		easing = "sineOut",
		time = 0.3,
		x = -lineWidth / 2
	})
	transition.fadeTo(self, {
		easing = "sineOut",
		opacity = 0,
		time = 0.3,
		onComplete = function ()
			self:removeSelf()
		end
	})
end

return POP_battle_start
