local UI_base = import("..UI_base")
local FRAME_actv = class("FRAME_actv", UI_base)

function FRAME_actv.countRedot()
	local redotCount = 0
	local arr = FRAME_actv.getList()

	for i, obj in ipairs(arr) do
		if obj.countRedot then
			redotCount = redotCount + obj.countRedot()
		end
	end

	return redotCount
end

function FRAME_actv.getList()
	local items = {}
	local actvArr = InfoActv.getViewList()

	for i, actvData in ipairs(actvArr) do
		local obj = {
			type = 0,
			isMain = true,
			label = Localization.getTextByLang(actvData.title),
			uiClass = FRAME_actv_main,
			data = actvData,
			countRedot = function ()
				return 0
			end
		}

		table.insert(items, obj)

		local opening = InfoActvStage.checkOpening(actvData.id)

		if opening then
			local csv = InfoActvStage.getCurrentCSV(actvData.id)

			if csv then
				local label = Localization.getUiLabel("FRAME_actv.list_" .. GameConfig.ACTV_TYPE.stage)

				if csv.type == 4 then
					label = Localization.getSrcText("试玩副本")
				end

				local obj = {
					uiName = "iframe_actv_stage",
					type = GameConfig.ACTV_TYPE.stage,
					label = label,
					uiClass = FRAME_actv_stage,
					data = {
						actv_id = actvData.id
					},
					countRedot = function ()
						return InfoActvStage.countRedot(actvData.id)
					end
				}

				table.insert(items, obj)
			end
		end

		local opening = InfoActvAchieve.checkOpening(actvData.id, GameConfig.ACTV_TYPE.achieve)

		if opening then
			local targetList = InfoActvAchieve.getTargetList(actvData.id, GameConfig.ACTV_TYPE.achieve)

			if #targetList > 0 then
				local obj = {
					type = GameConfig.ACTV_TYPE.achieve,
					label = Localization.getUiLabel("FRAME_actv.list_" .. GameConfig.ACTV_TYPE.achieve),
					uiClass = FRAME_actv_achieve,
					data = {
						actv_id = actvData.id,
						actv_type = GameConfig.ACTV_TYPE.achieve
					},
					countRedot = function ()
						return InfoActvAchieve.countRedot(actvData.id, GameConfig.ACTV_TYPE.achieve)
					end
				}

				table.insert(items, obj)
			end
		end

		local opening = InfoActvRecord.checkOpening(actvData.id)

		if opening then
			local data = InfoActvRecord.getData(actvData.id)

			if data then
				local obj = {
					uiName = "iframe_actv_sign",
					type = GameConfig.ACTV_TYPE.record,
					label = Localization.getUiLabel("FRAME_actv.list_" .. GameConfig.ACTV_TYPE.record),
					uiClass = FRAME_actv_sign,
					data = {
						actv_id = actvData.id
					},
					countRedot = function ()
						return InfoActvRecord.countRedot(actvData.id)
					end
				}

				table.insert(items, obj)
			end
		end

		local opening = InfoActvAchieve.checkOpening(actvData.id, GameConfig.ACTV_TYPE.achieve_full)

		if opening then
			local targetList = InfoActvAchieve.getTargetList(actvData.id, GameConfig.ACTV_TYPE.achieve_full)

			if #targetList > 0 then
				local obj = {
					type = GameConfig.ACTV_TYPE.achieve_full,
					label = Localization.getUiLabel("FRAME_actv.list_" .. GameConfig.ACTV_TYPE.achieve_full),
					uiClass = FRAME_actv_achieve,
					data = {
						actv_id = actvData.id,
						actv_type = GameConfig.ACTV_TYPE.achieve_full
					},
					countRedot = function ()
						return InfoActvAchieve.countRedot(actvData.id, GameConfig.ACTV_TYPE.achieve_full)
					end
				}

				table.insert(items, obj)
			end
		end

		local opening = InfoCharge.checkOpening(actvData.id)

		if opening then
			local chargeList = InfoCharge.getList(actvData.id)

			if #chargeList > 0 then
				local obj = {
					type = GameConfig.ACTV_TYPE.charge,
					label = Localization.getUiLabel("FRAME_actv.list_" .. GameConfig.ACTV_TYPE.charge),
					uiClass = FRAME_charge_gift,
					data = {
						actv_id = actvData.id
					},
					countRedot = function ()
						return InfoCharge.countRedot(actvData.id)
					end
				}

				table.insert(items, obj)
			end
		end

		local opening = InfoActvMonster.checkOpening(actvData.id)

		if opening then
			local monsterArr = InfoActvMonster.getMonsterList(actvData.id)

			if #monsterArr > 0 then
				local obj = {
					type = GameConfig.ACTV_TYPE.monster,
					label = Localization.getUiLabel("FRAME_actv.list_" .. GameConfig.ACTV_TYPE.monster),
					uiClass = FRAME_actv_monster,
					data = {
						actv_id = actvData.id
					},
					countRedot = function ()
						return 0
					end
				}

				table.insert(items, obj)
			end
		end

		local opening = InfoProbup.checkOpening(actvData.id)

		if opening then
			local probupList = InfoProbup.getList(nil, actvData.id)

			if #probupList > 0 then
				local obj = {
					uiName = "iframe_probup_campaign",
					type = GameConfig.ACTV_TYPE.probup,
					label = Localization.getUiLabel("FRAME_actv.list_" .. GameConfig.ACTV_TYPE.probup),
					uiClass = FRAME_probup_campaign,
					data = {
						actv_id = actvData.id
					},
					countRedot = function ()
						return 0
					end
				}

				table.insert(items, obj)
			end
		end

		local opening = InfoActvTurntable.checkOpening(actvData.id)

		if opening then
			local data = InfoActvTurntable.getData(actvData.id)

			if data then
				local obj = {
					uiName = "iframe_actv_turntable",
					type = GameConfig.ACTV_TYPE.turntable,
					label = Localization.getUiLabel("FRAME_actv.list_" .. GameConfig.ACTV_TYPE.turntable),
					uiClass = FRAME_actv_turntable,
					data = {
						actv_id = actvData.id
					},
					countRedot = function ()
						return InfoActvTurntable.countRedot(actvData.id)
					end
				}

				table.insert(items, obj)
			end
		end
	end

	return items
end

function FRAME_actv.open(id)
	local ui = FRAME_actv.new(id)

	PopManager.open(ui)
end

function FRAME_actv:ctor(id)
	FRAME_actv.super.ctor(self, "frame_actv", UIManager.BIG_TYPE.POP)

	self.id = id

	self:init()
end

function FRAME_actv:init()
	self:initUI()
	self:refreshTab()
	self.labelList:setSelectedIndex(1)

	self.selectedIndex = 1
	local items = self.labelList.items

	for i, v in ipairs(items) do
		if v.type == 0 and v.data and self.id and v.data.id == self.id then
			self.labelList:setSelectedIndex(i)

			self.selectedIndex = i

			self.labelList:scrollToIndex(i)

			break
		end
	end

	self:refresh()
	ManagerInfo.onDataChange(self, {
		"actv",
		"charge",
		"actv_achieve",
		"actv_record"
	}, nil, function ()
		self:refreshTab()
		self:refresh()
	end)
	ManagerInfo.onDataChange(self, {
		"item",
		"actv_turntable"
	}, nil, function ()
		self:refreshTab()
	end)
end

function FRAME_actv:refreshTab()
	local items = FRAME_actv.getList()

	self.labelList:setItems(items, true)
end

function FRAME_actv:refresh()
	local index = self.selectedIndex
	local tabData = self.labelList.items[index]

	if not tabData then
		return
	end

	local type = tabData.type
	self.iframes = self.iframes or {}

	if (type == GameConfig.ACTV_TYPE.stage or type == GameConfig.ACTV_TYPE.record) and self.iframes[type] then
		self.iframes[type]:removeSelf()

		self.iframes[type] = nil
	end

	if not self.iframes[type] then
		local ui = tabData.uiClass.new(tabData.uiName, tabData.data)
		ui.uiClass = tabData.uiClass
		local flag = self:getFlagByTag("flag_iframe")

		ui:setPosition(flag.x, flag.y)
		self:addChild(ui, 10000)

		self.iframes[type] = ui
	elseif self.iframes[type].resetData then
		self.iframes[type]:resetData(tabData.data)
	end

	for k, ui in pairs(self.iframes) do
		ui:setVisible(k == type)
	end
end

function FRAME_actv:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local function tapListener(ui, data, index)
		if index ~= self.selectedIndex then
			self.selectedIndex = index

			self:refresh()
		end
	end

	self.labelList = self:createListOnFlag("flag_tag_list", LIST_actv_tag, tapListener)

	self.labelList:setTapGroup("list_click")
end

return FRAME_actv
