local InfoNaraka = {}
local rawData, shopList = nil
local shopRefreshIndex = 0

function InfoNaraka.init()
	Connection.listen("naraka_sync", InfoNaraka.sync)
end

app:addToAppEnterCall(InfoNaraka.init)

function InfoNaraka.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoNaraka.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("naraka_query", callback)
end

function InfoNaraka.onQuery(rcvData)
	rawData = rcvData
end

function InfoNaraka.sync(syncData)
	for k, v in pairs(syncData) do
		rawData[k] = v
	end

	ManagerInfo.dataChange("naraka")
end

function InfoNaraka.enterStage(stage_id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			local result = rcvData.dungeon_result
			local title, subTitle = InfoDungeon.getTitle(result.type, result.dungeon_id, result.quest_id, result.abyss_seed)

			Transition.setTitle(title, subTitle)
			Transition.leave(function ()
				if onSuccess then
					onSuccess(result)
				end
			end)
		end
	end

	Connection.request("naraka_stage", {
		stage_id = stage_id
	}, callback)
end

function InfoNaraka.isOpen(id)
	local csv = CsvParser.getCsvData("naraka_stage", id)

	return InfoDungeon.isAreaFinished(csv.abyss_area)
end

function InfoNaraka.getList()
	local csvList = CsvParser.getCsvList("naraka_stage")
	local chapterID = InfoChapter.getID()
	local arr = {}

	for i, v in ipairs(csvList) do
		local areaCSV = CsvParser.getCsvData("abyss_area", v.abyss_area)

		if areaCSV.chapter == chapterID then
			table.insert(arr, v)
		end
	end

	table.sort(arr, function (a, b)
		local openA = InfoNaraka.isOpen(a.id) and 1 or 0
		local openB = InfoNaraka.isOpen(b.id) and 1 or 0

		if openA == openB then
			return b.abyss_area < a.abyss_area
		else
			return openB < openA
		end
	end)

	return arr
end

function InfoNaraka.inNarakaBoss()
	if InfoDungeon.inDungeon() and InfoDungeon.getType() == InfoDungeon.TYPE.STAGE then
		local stageType = InfoDungeon.getStage()

		return stageType == InfoDungeon.STAGE_TYPE.NARAKA_BOSS
	end
end

function InfoNaraka.getNarakaCSV()
	local stageType, stageID = InfoDungeon.getStage()

	if stageType == InfoDungeon.STAGE_TYPE.NARAKA_PREPARE or stageType == InfoDungeon.STAGE_TYPE.NARAKA_BOSS then
		return CsvParser.getCsvData("naraka_stage", stageID)
	end
end

function InfoNaraka.countRedot()
	local redotCount = 0

	return redotCount
end

function InfoNaraka.getModes()
	local modeArr = string.split(rawData.mode_arr, ",")
	local arr = {}

	for i, v in ipairs(modeArr) do
		if not empty(v) then
			local mode = tonumber(v)

			if mode then
				table.insert(arr, mode)
			end
		end
	end

	return arr
end

function InfoNaraka.getPoints()
	local csvList = CsvParser.getCsvList("naraka_mode")
	local openMap = {}
	local modes = InfoNaraka.getModes()

	for i, v in ipairs(modes) do
		openMap[tonumber(v)] = true
	end

	local starNum = 0
	local starMax = 0

	for i, v in ipairs(csvList) do
		if openMap[v.id] then
			starNum = starNum + v.reward_score
		end

		starMax = starMax + v.reward_score
	end

	return starNum, starMax
end

function InfoNaraka.getModeAffixAdd()
	local affixAddNum = 0

	if not empty(rawData.mode_arr) then
		local modeArr = string.split(rawData.mode_arr, ",")

		for i, v in ipairs(modeArr) do
			local csv = CsvParser.getCsvData("naraka_mode", v)

			if not empty(csv.affix_add) then
				affixAddNum = affixAddNum + csv.affix_add
			end
		end
	end

	return affixAddNum
end

function InfoNaraka.getModeBuffs()
	local buffs = {}

	if not empty(rawData.mode_arr) then
		local modeArr = string.split(rawData.mode_arr, ",")

		for i, v in ipairs(modeArr) do
			local csv = CsvParser.getCsvData("naraka_mode", v)

			if not empty(csv.buff) then
				table.insert(buffs, csv.buff)
			end
		end
	end

	return buffs
end

function InfoNaraka.getModeExLevel()
	local exLevel = 0

	if not empty(rawData.mode_arr) then
		local modeArr = string.split(rawData.mode_arr, ",")

		for i, v in ipairs(modeArr) do
			local csv = CsvParser.getCsvData("naraka_mode", v)

			if not empty(csv.ex_level) then
				exLevel = exLevel + csv.ex_level
			end
		end
	end

	return exLevel
end

function InfoNaraka.getModeExDifficulty()
	local exDifficulty = 0

	if not empty(rawData.mode_arr) then
		local modeArr = string.split(rawData.mode_arr, ",")

		for i, v in ipairs(modeArr) do
			local csv = CsvParser.getCsvData("naraka_mode", v)

			if not empty(csv.ex_difficulty) then
				exDifficulty = exDifficulty + csv.ex_difficulty
			end
		end
	end

	return exDifficulty
end

function InfoNaraka.getRewardTimes()
	local reward_count = rawData.reward_count

	if RefreshManager.checkTimePassed(RefreshManager.TYPE.NAKARA, Time.now(), rawData.reward_time) then
		reward_count = 0
	end

	local nakara_reward_times = CsvParser.getCsvData("config", "nakara_reward_times").value

	return nakara_reward_times - reward_count, nakara_reward_times
end

function InfoNaraka.getShopLabels()
	local shopCSVList = CsvParser.getCsvList("naraka_shop_label")

	return shopCSVList
end

function InfoNaraka.clearOnReconnect()
	shopList = nil
end

function InfoNaraka.getShopList(_callback)
	local needQuery = shopList == nil

	if not needQuery and rawData.shop_refresh_time < Time.now() then
		needQuery = true
	end

	if needQuery then
		local function callback(rcvData)
			if rcvData.err then
				-- Nothing
			else
				shopRefreshIndex = shopRefreshIndex + 1
				shopList = rcvData.items

				if _callback then
					_callback(shopList)
				end
			end
		end

		Connection.request("naraka_shop_list", callback)
	else
		_callback(shopList)
	end
end

function InfoNaraka.getShopItems()
	local abyssLevel = InfoDungeon.getAbyssMaxLevel()
	local arr = {}
	local multiLabel = nil
	local shopCSVList = CsvParser.getCsvList("naraka_shop_label")

	if #shopCSVList > 1 then
		local labelMap = {}

		for i, v in ipairs(shopList) do
			local shopCSV = CsvParser.getCsvData("naraka_shop", v.shop_id, nil, true)

			if shopCSV and shopCSV.abyss_level_min <= abyssLevel and abyssLevel <= shopCSV.abyss_level_max and (shopCSV.no_supply ~= 1 or v.soldout < shopCSV.times) then
				if not labelMap[shopCSV.label] then
					labelMap[shopCSV.label] = {}
				end

				table.insert(labelMap[shopCSV.label], v)
			end
		end

		for i, v in ipairs(shopCSVList) do
			local itemArr = labelMap[v.id]

			if itemArr then
				table.sort(itemArr, function (a, b)
					return a.shop_id < b.shop_id
				end)

				local obj = {
					label = v,
					items = itemArr
				}

				table.insert(arr, obj)
			end
		end

		multiLabel = true
	else
		local abyssLevel = InfoDungeon.getAbyssMaxLevel()

		for i, v in ipairs(shopList) do
			local shopCSV = CsvParser.getCsvData("naraka_shop", v.shop_id, nil, true)

			if shopCSV and shopCSV.abyss_level_min <= abyssLevel and abyssLevel <= shopCSV.abyss_level_max and (shopCSV.no_supply ~= 1 or v.soldout < shopCSV.times) then
				table.insert(arr, v)
			end
		end

		table.sort(arr, function (a, b)
			return a.shop_id < b.shop_id
		end)

		multiLabel = false
	end

	return arr, multiLabel
end

function InfoNaraka.buy(shop_id, num, onSuccess, onFailure)
	local preIndex = shopRefreshIndex

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if rcvData.item then
				local item = rcvData.item

				if preIndex == shopRefreshIndex then
					for i, v in ipairs(shopList) do
						if v.shop_id == item.shop_id then
							for k1, v1 in pairs(item) do
								v[k1] = v1
							end
						end
					end
				end
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("naraka_shop_buy", {
		shop_id = shop_id,
		num = num
	}, callback)
end

function InfoNaraka.getShopCSV()
	return "naraka_shop"
end

function InfoNaraka.getCostNeed()
	return CsvParser.getCsvData("config", "naraka_shop_need").value
end

function InfoNaraka.getShopName()
	return "naraka_shop"
end

function InfoNaraka.getShopTime()
	return rawData.shop_refresh_time, RefreshManager.getNextTime(RefreshManager.TYPE.NARAKA_SHOP, Time.now())
end

function InfoNaraka.getRefreshType()
	return RefreshManager.TYPE.NARAKA_SHOP
end

return InfoNaraka
