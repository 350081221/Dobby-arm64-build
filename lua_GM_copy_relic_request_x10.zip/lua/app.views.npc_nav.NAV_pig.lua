local NAV_base = import(".NAV_base")
local NAV_pig = class("NAV_pig", NAV_base)

function NAV_pig.open(npc)
	local ui = NAV_pig.new(npc)

	return ui
end

function NAV_pig:ctor(npc)
	NAV_pig.super.ctor(self, npc, "nav_pig")
end

function NAV_pig:init()
	NAV_pig.super.init(self)
	self:refresh()
end

function NAV_pig:refresh()
	local index = 1
	local ui = self.buttons[index].ui
	local button = self.buttons[index].button
	local likeCount, rewardCount = InfoLikes.likesDaily()
	local daily_reward_list = CsvParser.getCsvList("likes_daily_reward")
	local progress = ui:getComponentByTag("progress")

	if rewardCount > #daily_reward_list - 1 then
		self:setButtonName(ui, Localization.getSrcText("今日已领"))
		progress:setVisible(false)
	else
		local daily_reward = daily_reward_list[rewardCount + 1]

		if likeCount < daily_reward.count then
			local str = Localization.getSrcText("点赞{1}次")

			self:setButtonName(ui, StringUtil.replace(str, daily_reward.count - likeCount))
			progress:setVisible(false)
		else
			self:setButtonName(ui, Localization.getSrcText("可领奖"))
			progress:setColor(NAV_base.COLOR.HIGH)
			progress:setVisible(true)
		end
	end
end

function NAV_pig:onTap(index)
	NAV_pig.super.onTap(self, index)

	if index == 1 then
		local likeCount, rewardCount = InfoLikes.likesDaily()
		local daily_reward_list = CsvParser.getCsvList("likes_daily_reward")

		if rewardCount > #daily_reward_list - 1 then
			Alert.open(Localization.getSrcText("今天已经领过啦"))
		else
			local daily_reward = daily_reward_list[rewardCount + 1]

			if likeCount < daily_reward.count then
				local str = Localization.getSrcText("再送出{1}次点赞后可以领奖")

				Alert.open(StringUtil.replace(str, daily_reward.count - likeCount))
				CampUtils.goNpc(10005)
			else
				InfoLikes.dailyReward(function (rcvData)
					local rewards = rcvData.rewards

					if rewards and #rewards > 0 then
						self:showRewards(daily_reward, rewards)
					end

					self:refresh()
				end)
			end
		end
	end
end

function NAV_pig:showRewards(daily_reward, rewards)
	local chest = Unit.new()

	chest:load(daily_reward.model)
	chest:display(global.map, self.npc.x, self.npc.y)

	local units = TeamManager.getTeam()

	for i, unit in ipairs(units) do
		local effectGen = unit:getEffectGen()

		if effectGen then
			effectGen:fadeTo(30, 0, "outQuad")
		end
	end

	local mapX, mapY = global.map:tileToMap(self.npc.tile.x + 1, self.npc.tile.y)

	local function onJumpComplete()
		MapEffect.quake()

		local function onRewardClose()
			for i, unit in ipairs(units) do
				local effectGen = unit:getEffectGen()

				if effectGen then
					effectGen:fadeTo(30, 255, "outQuad")
				end
			end

			global.map:tweenViewZoom(1, 10, nil, , "outQuad")
			global.map:tweenFov(global.player.x, global.player.y, 10, "outQuad")
			global.map:tweenScrollTo(global.player.x, global.player.y, 10, function ()
				global.player:setGoDirectionLocked("NAV_pig", false)
			end, "outQuad")
		end

		chest:setAction("open", 1, function ()
			chest:setAction("opened")
			POP_reward.openMixed(rewards, function ()
				chest:removeSelf()
				onRewardClose()
			end, Localization.getSrcText("感谢支持"))
		end)
	end

	local scale = 0.2

	chest:setScale(0)

	chest.z = 48

	chest:setBmpY()

	local function onJumpUpdate()
		scale = math.min(1, scale + 0.15)

		chest:setScale(scale)
	end

	chest:jump({
		x = mapX,
		y = mapY
	}, 5, 10, onJumpComplete, nil, onJumpUpdate)
	global.player:setGoDirectionLocked("NAV_pig", true)
	global.map:tweenViewZoom(1.5, 10, nil, , "outQuad")
	global.map:tweenFov(mapX - 96, mapY - 96, 10, "outQuad")
	global.map:tweenScrollTo(mapX - 96, mapY - 96, 10, nil, "outQuad")
end

return NAV_pig
