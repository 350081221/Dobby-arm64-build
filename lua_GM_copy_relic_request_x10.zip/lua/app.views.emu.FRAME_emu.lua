import("...lib.BEZ")

local UI_base = import("..UI_base")
local FRAME_emu = class("FRAME_emu", UI_base)

function FRAME_emu:ctor()
	FRAME_emu.super.ctor(self, "frame_emu")
	self:init()
end

function FRAME_emu:init()
	if app.sceneData and app.sceneData.myteam then
		self.myteam = true
	end

	self.params = {
		equip_times = 1000
	}
	local _params = Cookie.get("emu_params")

	if _params then
		for k, v in pairs(_params) do
			if self.params[k] then
				self.params[k] = v
			end
		end
	end

	for k, v in pairs(self.params) do
		if self:getComponentByTag("eb_" .. k) then
			local eb = self:createEditBoxOnComponent("eb_" .. k, function (event, editbox)
				if event == "ended" then
					local text = editbox:getText()
					self.params[k] = tonumber(text) or 0

					Cookie.set("emu_params", self.params, true)
					Emu.setParams(self.params)
				end
			end)

			eb:setText(self.params[k])
		end
	end

	Emu.init(self.params)
	self:initUI()

	if self.myteam then
		self.myteamUI:setVisible(true)
		self:loadMyteam()
	end
end

function FRAME_emu:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local bt_equip_clear = self:getComponentByTag("bt_equip_clear")

	bt_equip_clear:toTouchable()
	bt_equip_clear:addTap(function ()
		Emu.clearEquipCache()
	end)

	local bt_overlevel = self:getComponentByTag("bt_overlevel")

	bt_overlevel:toTouchable()
	bt_overlevel:addTap(function ()
		self.overlevelUI:setVisible(true)
		self:loadOverlevel()
	end)

	local bt_fixed = self:getComponentByTag("bt_fixed")

	bt_fixed:toTouchable()
	bt_fixed:addTap(function ()
		self.fixedUI:setVisible(true)
		self:loadFixed()
	end)

	global.noEffect = Cookie.get("emu_no_effect")

	if global.noEffect == nil then
		global.noEffect = true
	end

	self.listHidden = Cookie.get("emu_hide_list")
	local controlUI = UIManager.getUI("frame_emu_control")

	self:addChild(controlUI, 900)

	self.controlUI = controlUI
	self.speedRatio = Cookie.get("emu_speed_ratio") or 10
	local eb = controlUI:createEditBoxOnComponent("eb_ratio", function (event, editbox)
		if event == "ended" then
			local text = editbox:getText()
			self.speedRatio = tonumber(text) or self.speedRatio
			self.speedRatio = math.max(1, math.min(100, math.floor(self.speedRatio)))

			Cookie.set("emu_speed_ratio", self.speedRatio, true)
			MapFrameManager.setSuperTimeRatio(self.speedRatio)
		end
	end)

	eb:setText(tostring(self.speedRatio))

	local bt_hide_list = controlUI:getComponentByTag("bt_hide_list")
	local hide_list = controlUI:getComponentByTag("hide_list")

	bt_hide_list:toTouchable()
	bt_hide_list:addTap(function ()
		self.listHidden = not self.listHidden

		hide_list:setVisible(not self.listHidden)
		Cookie.set("emu_hide_list", self.listHidden, true)
		self:refreshHideList()
	end)
	hide_list:setVisible(not self.listHidden)

	local bt_no_effect = controlUI:getComponentByTag("bt_no_effect")
	local no_effect = controlUI:getComponentByTag("no_effect")

	bt_no_effect:toTouchable()
	bt_no_effect:addTap(function ()
		global.noEffect = not global.noEffect

		no_effect:setVisible(global.noEffect)
		Cookie.set("emu_no_effect", global.noEffect, true)
	end)
	no_effect:setVisible(global.noEffect)

	local fixedUI = UIManager.getUI("frame_emu_fixed")

	self:addChild(fixedUI, 1000)
	fixedUI:setVisible(false)

	self.fixedUI = fixedUI
	local bg = fixedUI:getComponentByTag("bg")

	bg:toTouchable()

	local bt_start = fixedUI:getComponentByTag("bt_start")

	bt_start:toTouchable()
	bt_start:addTap(function ()
		if self.doing then
			self:fixedStop()
			fixedUI:setVisible(false)
		else
			self:fixedStart()
		end
	end)

	local params = {
		init_hero = 1,
		mutate = 0,
		monster_create_id = 100,
		pass = 1,
		times = 1,
		monster_level = 80,
		equip_level = 1
	}
	local _params = Cookie.get("emu_fixed_params")

	if _params then
		for k, v in pairs(_params) do
			if params[k] then
				params[k] = v
			end
		end
	end

	for k, v in pairs(params) do
		if fixedUI:getComponentByTag("eb_" .. k) then
			local eb = fixedUI:createEditBoxOnComponent("eb_" .. k, function (event, editbox)
				if event == "ended" then
					local text = editbox:getText()
					params[k] = tonumber(text) or 0

					Cookie.set("emu_fixed_params", params, true)
				end
			end)

			eb:setText(params[k])
		end
	end

	self.fixedParams = params

	for i = 1, 2 do
		local bt = fixedUI:getComponentByTag("bt_equip_level_" .. i)

		bt:toTouchable()
		bt:addTap(function ()
			params.equip_level = i

			Cookie.set("emu_fixed_params", params, true)
			self:fixedRefreshEquipLevel()
		end)
	end

	self:fixedRefreshEquipLevel()

	self.fixedList = fixedUI:createListOnFlag("flag_list", LIST_emu_overlevel)
	local holder = fixedUI:getComponentByTag("holder")

	holder:setOpacity(100)
	self.fixedList:setHolders({
		holder
	}, true)

	local overlevelUI = UIManager.getUI("frame_emu_overlevel")

	self:addChild(overlevelUI, 1000)
	overlevelUI:setVisible(false)

	self.overlevelUI = overlevelUI
	local bg = overlevelUI:getComponentByTag("bg")

	bg:toTouchable()

	local bt_start = overlevelUI:getComponentByTag("bt_start")

	bt_start:toTouchable()
	bt_start:addTap(function ()
		if self.doing then
			self:overlevelStop()
			overlevelUI:setVisible(false)
		else
			self:overlevelStart()
		end
	end)

	local params = {
		lvup = 1,
		equip_level = 1,
		init_hero = 1,
		pass = 80,
		times = 100,
		timeout = 10800,
		lvup_jump = 10,
		init_abyss = 1
	}
	local _params = Cookie.get("emu_overlevel_params")

	if _params then
		for k, v in pairs(_params) do
			if params[k] then
				params[k] = v
			end
		end
	end

	for k, v in pairs(params) do
		if overlevelUI:getComponentByTag("eb_" .. k) then
			local eb = overlevelUI:createEditBoxOnComponent("eb_" .. k, function (event, editbox)
				if event == "ended" then
					local text = editbox:getText()
					params[k] = tonumber(text) or 0

					Cookie.set("emu_overlevel_params", params, true)
				end
			end)

			eb:setText(params[k])
		end
	end

	self.overlevelParams = params

	for i = 1, 2 do
		local bt = overlevelUI:getComponentByTag("bt_equip_level_" .. i)

		bt:toTouchable()
		bt:addTap(function ()
			params.equip_level = i

			Cookie.set("emu_overlevel_params", params, true)
			self:overlevelRefreshEquipLevel()
		end)
	end

	self:overlevelRefreshEquipLevel()

	self.overlevelList = overlevelUI:createListOnFlag("flag_list", LIST_emu_overlevel)
	local holder = overlevelUI:getComponentByTag("holder")

	holder:setOpacity(100)
	self.overlevelList:setHolders({
		holder
	}, true)

	local myteamUI = UIManager.getUI("frame_emu_myteam")

	self:addChild(myteamUI, 1000)
	myteamUI:setVisible(false)

	self.myteamUI = myteamUI
	local bg = myteamUI:getComponentByTag("bg")

	bg:toTouchable()

	local bt_start = myteamUI:getComponentByTag("bt_start")

	bt_start:toTouchable()
	bt_start:addTap(function ()
		if self.doing then
			self:myteamStop()
		else
			self:myteamStart()
		end
	end)

	local params = {
		monster_level_max = 80,
		lvup_jump = 1,
		monster_create_id = 100,
		times = 1,
		monster_level = 80
	}
	local _params = Cookie.get("emu_myteam_params")

	if _params then
		for k, v in pairs(_params) do
			if params[k] then
				params[k] = v
			end
		end
	end

	for k, v in pairs(params) do
		if myteamUI:getComponentByTag("eb_" .. k) then
			local eb = myteamUI:createEditBoxOnComponent("eb_" .. k, function (event, editbox)
				if event == "ended" then
					local text = editbox:getText()
					params[k] = tonumber(text) or 0

					Cookie.set("emu_myteam_params", params, true)
				end
			end)

			eb:setText(params[k])
		end
	end

	self.myteamParams = params
	self.myteamList = myteamUI:createListOnFlag("flag_list", LIST_emu_myteam)
	local holder = myteamUI:getComponentByTag("holder")

	holder:setOpacity(100)
	self.myteamList:setHolders({
		holder
	}, true)
	self:refreshHideList()
end

function FRAME_emu:onBattleReady()
end

function FRAME_emu:refreshHideList()
	if self.fixedList then
		self.fixedList:setVisible(not self.listHidden)
	end

	if self.overlevelList then
		self.overlevelList:setVisible(not self.listHidden)
	end

	if self.myteamList then
		self.myteamList:setVisible(not self.listHidden)
	end

	local mask = self.controlUI:getComponentByTag("mask")

	if self.listHidden then
		mask:setOpacity(100)
	else
		mask:setOpacity(255)
	end
end

function FRAME_emu:fixedRefreshDoing()
	local bt_start = self.fixedUI:getComponentByTag("bt_start")

	if self.doing then
		bt_start:addLabel("停止")
	else
		bt_start:addLabel("开始")
	end
end

function FRAME_emu:fixedRefreshLevel()
	self.fixedUI:createLabelOnFlag("flag_level", self.fixedData.currentLevel)
end

function FRAME_emu:fixedRefreshHeroList()
	self.fixedList:setItems(self.fixedTeamData, true)
	self.fixedList:setSelectedIndex(self.fixedData.currentTeamIndex)
end

function FRAME_emu:fixedRefreshEquipLevel()
	for i = 1, 2 do
		local equip_level = self.fixedUI:getComponentByTag("equip_level_" .. i)

		equip_level:setVisible(self.fixedParams.equip_level == i)
	end
end

function FRAME_emu:fixedStart()
	local monster_create_id = self.fixedParams.monster_create_id
	local monster_create_csv = CsvParser.getCsvData("monster_create", monster_create_id, nil, true)

	if not monster_create_csv then
		Alert.open("monster_create不存在")

		return
	end

	local mutateCSV = nil

	if not empty(self.fixedParams.mutate) then
		mutateCSV = CsvParser.getCsvData("abyss_mutate", self.fixedParams.mutate, nil, true)

		if not mutateCSV then
			Alert.open("mutate不存在")

			return
		end
	end

	self.fixedData = {
		currentTeamIndex = 1,
		monster_create_id = self.fixedParams.monster_create_id,
		currentLevel = self.fixedParams.monster_level,
		maxLevel = CsvParser.getMaxID("emu_pay_index"),
		mutateCSV = mutateCSV,
		battleSeedMap = {}
	}
	local teamCsvList = CsvParser.getCsvList("emu_team_fixed", "__line")
	self.fixedTeamData = {}

	for i, v in ipairs(teamCsvList) do
		local teamData = {
			id = v.id,
			teamLevel = self.fixedParams.init_hero,
			passRecord = {},
			battleCount = 0,
			winCount = 0,
			winBattleTime = 0
		}

		table.insert(self.fixedTeamData, teamData)
	end

	self:addEnterFrame("fixedLoop", function ()
		self:fixedLoop()
	end)

	self.doing = true

	self:fixedRefreshDoing()
end

function FRAME_emu:fixedStop()
	self:removeEnterFrame("fixedLoop")

	self.doing = false

	self:fixedRefreshDoing()
	POP_confirm.open("模拟结束")
end

function FRAME_emu:fixedLoop()
	local teamLevelMax = CsvParser.getMaxID("hero_base_num")

	if not self.isBattle then
		local teamData = self.fixedTeamData[self.fixedData.currentTeamIndex]
		local overCount = 0

		while teamData.isLevelMax or teamData.passLevel do
			overCount = overCount + 1

			if overCount > #self.fixedTeamData then
				self:fixedStop()

				return
			end

			self.fixedData.currentTeamIndex = self.fixedData.currentTeamIndex + 1

			if self.fixedData.currentTeamIndex > #self.fixedTeamData then
				self.fixedData.currentTeamIndex = 1
			end

			teamData = self.fixedTeamData[self.fixedData.currentTeamIndex]
		end

		local abyssLevel = self.fixedData.currentLevel
		local heroLevel = teamData.teamLevel
		local heroID = teamData.id
		local seed = self.fixedData.battleSeedMap[tostring(teamData.battleCount)]

		if not seed then
			seed = math.random(1, 65535)
			self.fixedData.battleSeedMap[tostring(teamData.battleCount)] = seed
		end

		local monsterCreateID = self.fixedData.monster_create_id
		local monsterGroups = MapEventManager.getMonsterGroup(monsterCreateID, Random.new(seed), 1, 1, abyssLevel, self.fixedData.mutateCSV)

		print("$$$ 战斗 等级：", abyssLevel, "队伍：", self.fixedData.currentTeamIndex, "队伍等级：", teamData.teamLevel, "场次：", teamData.winCount .. "/" .. teamData.battleCount)

		local function onBattleOver(isWin)
			WarMachine.event_on = false

			global.map:battleOff()

			local teamData = self.fixedTeamData[self.fixedData.currentTeamIndex]
			teamData.battleCount = teamData.battleCount + 1

			if isWin then
				teamData.winCount = teamData.winCount + 1
				teamData.winBattleTime = teamData.winBattleTime + WarMachine.preFrame
			end

			local loseCount = teamData.battleCount - teamData.winCount
			local passPercent = math.floor((self.fixedParams.times - loseCount) / self.fixedParams.times * 100)

			if passPercent < self.fixedParams.pass then
				if teamLevelMax <= teamData.teamLevel then
					teamData.isLevelMax = true
					self.fixedData.currentTeamIndex = self.fixedData.currentTeamIndex + 1

					if self.fixedData.currentTeamIndex > #self.fixedTeamData then
						self.fixedData.currentTeamIndex = 1
					end
				else
					teamData.teamLevel = teamData.teamLevel + 1
					teamData.winCount = 0
					teamData.winBattleTime = 0
					teamData.battleCount = 0
				end
			else
				local passPercent = math.floor(teamData.winCount / self.fixedParams.times * 100)

				if self.fixedParams.pass <= passPercent then
					local passData = {
						level = teamData.teamLevel,
						score = teamData.score,
						time = math.floor(teamData.winBattleTime / teamData.winCount)
					}
					teamData.passRecord[tostring(abyssLevel)] = passData
					teamData.passLevel = abyssLevel
					self.fixedData.currentTeamIndex = self.fixedData.currentTeamIndex + 1

					self:exportFixed()

					if self.fixedData.currentTeamIndex > #self.fixedTeamData then
						self.fixedData.currentTeamIndex = 1
					end
				end
			end

			self:fixedRefreshHeroList()
			self:performWithDelay(function ()
				local units = ClipOnMap.getUnitList("monster", "hero", "hero_copy", "pet", "summoned")

				for i, unit in ipairs(units) do
					unit:die()
				end

				self:performWithDelay(function ()
					self.isBattle = nil
				end, 0.2)
			end, 0.1)
		end

		self.isBattle = true
		local equipLevel = nil

		if self.fixedParams.equip_level == 1 then
			equipLevel = self.fixedData.currentLevel
		else
			equipLevel = heroLevel
		end

		print("$$$ equipLevel", equipLevel)

		local copy = self:startAbyss(abyssLevel, heroLevel, heroID, equipLevel, seed, monsterGroups, onBattleOver, monsterCreateID)
		teamData.score = CopyAttr.getScore(copy)

		self:fixedRefreshHeroList()
		self:fixedSave()
	end
end

function FRAME_emu:fixedSave()
	local params = self.fixedParams
	local data = self.fixedData
	local teamData = self.fixedTeamData
	local saveData = {
		params = params,
		data = data,
		teamData = teamData
	}
	local path = cc.FileUtils:getInstance():getWritablePath() .. "emu_fixed_state.txt"

	io.writefile(path, json.encode(saveData))
end

function FRAME_emu:loadFixed()
	local path = cc.FileUtils:getInstance():getWritablePath() .. "emu_fixed_state.txt"
	local obj = nil

	if io.exists(path) then
		local contents = getFileString(path)
		obj = json.decode(contents)
	end

	if obj and obj.params and obj.data and obj.teamData then
		local function fixedResume()
			self.fixedParams = obj.params
			self.fixedData = obj.data
			self.fixedTeamData = obj.teamData
			local params = obj.params

			for k, v in pairs(params) do
				local eb = self.fixedUI:getEditBoxByTag("eb_" .. k)

				if eb then
					eb:setText(v)
				end
			end

			Cookie.set("emu_fixed_params", params, true)
			self:fixedRefreshEquipLevel()
			self:fixedRefreshLevel()
			self:addEnterFrame("fixedLoop", function ()
				self:fixedLoop()
			end)
		end

		POP_notice.open("继续之前的测试？", fixedResume)
	end
end

function FRAME_emu:exportFixed()
	local str = "挑战等级,队伍id,队伍名字,通关等级,通关战力,战斗时间"
	local levelStr = tostring(self.fixedData.currentLevel)

	for i, teamData in ipairs(self.fixedTeamData) do
		str = str .. "\r\n"
		local csv = CsvParser.getCsvData("emu_hero_team", teamData.id)

		if teamData.passRecord and teamData.passRecord[levelStr] then
			str = str .. levelStr
			str = str .. "," .. csv.id
			str = str .. "," .. csv.name
			local record = teamData.passRecord[levelStr]
			str = str .. "," .. record.level
			str = str .. "," .. record.score
			str = str .. "," .. math.floor(record.time / 60 * 10) / 10
		end
	end

	local fileName = "emu_fixed_record equip_by_"

	if self.fixedParams.equip_level == 1 then
		fileName = fileName .. "abyss.csv"
	else
		fileName = fileName .. "hero.csv"
	end

	local path = cc.FileUtils:getInstance():getWritablePath() .. fileName

	io.writefile(path, str)
end

function FRAME_emu:overlevelRefreshDoing()
	local bt_start = self.overlevelUI:getComponentByTag("bt_start")

	if self.doing then
		bt_start:addLabel("停止")
	else
		bt_start:addLabel("开始")
	end
end

function FRAME_emu:overlevelRefreshLevel()
	self.overlevelUI:createLabelOnFlag("flag_level", self.overlevelData.currentLevel)
end

function FRAME_emu:overlevelRefreshHeroList()
	self.overlevelList:setItems(self.overlevelTeamData, true)
	self.overlevelList:setSelectedIndex(self.overlevelData.currentTeamIndex)
end

function FRAME_emu:overlevelRefreshEquipLevel()
	for i = 1, 2 do
		local equip_level = self.overlevelUI:getComponentByTag("equip_level_" .. i)

		equip_level:setVisible(self.overlevelParams.equip_level == i)
	end
end

function FRAME_emu:overlevelStart()
	self.overlevelData = {
		clearPass = true,
		currentTeamIndex = 1,
		levelOver = true,
		isStartJump = true,
		currentLevel = self.overlevelParams.init_abyss,
		maxLevel = CsvParser.getMaxID("emu_pay_index")
	}
	local teamCsvList = CsvParser.getCsvList("emu_team_overlevel", "__line")
	self.overlevelTeamData = {}

	for i, v in ipairs(teamCsvList) do
		local teamData = {
			id = v.id,
			teamLevel = self.overlevelParams.init_hero,
			passRecord = {},
			battleCount = 0,
			winCount = 0,
			winBattleTime = 0
		}

		table.insert(self.overlevelTeamData, teamData)
	end

	self:addEnterFrame("overlevelLoop", function ()
		self:overlevelLoop()
	end)

	self.doing = true

	self:overlevelRefreshDoing()
end

function FRAME_emu:overlevelStop()
	self:removeEnterFrame("overlevelLoop")

	self.doing = false

	self:overlevelRefreshDoing()
	POP_confirm.open("模拟结束")
end

function FRAME_emu:overlevelOnLevelOver()
	local isJump = false

	if self.overlevelData.isStartJump and self.overlevelData.clearPass then
		isJump = true
	end

	if not isJump then
		self.overlevelData.isStartJump = false
		self.overlevelData.currentLevel = self.overlevelData.currentLevel + 1
	else
		self.overlevelData.currentLevel = self.overlevelData.currentLevel + self.overlevelParams.lvup_jump
	end
end

function FRAME_emu:overlevelLoop()
	local teamLevelMax = CsvParser.getMaxID("hero_base_num")

	if not self.isBattle then
		if self.overlevelData.levelOver then
			self.overlevelData.levelOver = nil

			for i, teamData in ipairs(self.overlevelTeamData) do
				teamData.battleCount = 0
				teamData.winCount = 0
				teamData.winBattleTime = 0
			end

			if self.overlevelData.maxLevel < self.overlevelData.currentLevel then
				self:overlevelStop()

				return
			end

			local allMaxLevel = true

			for i, teamData in ipairs(self.overlevelTeamData) do
				if not teamData.maxLevel then
					allMaxLevel = false

					break
				end
			end

			if allMaxLevel then
				self:overlevelStop()

				return
			end

			print("= 新一层 =", self.overlevelData.currentLevel)

			self.overlevelData.seed = math.random(1, 65535)
			self.overlevelData.monsterGroupArr = Emu.createMonsterTeam(self.overlevelData.seed, self.overlevelData.currentLevel, 0, self.overlevelParams.times, self.overlevelParams.times)

			self:overlevelRefreshLevel()
			self:overlevelRefreshHeroList()

			self.overlevelData.seedArr = {}

			for i = 1, self.overlevelParams.times do
				table.insert(self.overlevelData.seedArr, math.random(1, 65535))
			end
		end

		local teamData = self.overlevelTeamData[self.overlevelData.currentTeamIndex]
		local maxLevelCount = 0

		while teamData.isLevelMax do
			maxLevelCount = maxLevelCount + 1

			if maxLevelCount > #self.overlevelTeamData then
				self:overlevelStop()

				return
			end

			self.overlevelData.currentTeamIndex = self.overlevelData.currentTeamIndex + 1

			if self.overlevelData.currentTeamIndex > #self.overlevelTeamData then
				self.overlevelData.currentTeamIndex = 1
			end

			teamData = self.overlevelTeamData[self.overlevelData.currentTeamIndex]
		end

		local abyssLevel = self.overlevelData.currentLevel
		local heroLevel = teamData.teamLevel
		local heroID = teamData.id
		local seed = self.overlevelData.seedArr[teamData.battleCount + 1]
		local monsterGroupsObj = self.overlevelData.monsterGroupArr[teamData.battleCount + 1]
		local monsterGroups = monsterGroupsObj.groups
		local monsterCreateID = monsterGroupsObj.monsterCreateID

		print("$$$ 战斗 等级：", abyssLevel, "队伍：", self.overlevelData.currentTeamIndex, "队伍等级：", teamData.teamLevel, "场次：", teamData.winCount .. "/" .. teamData.battleCount)

		local function onBattleOver(isWin)
			WarMachine.event_on = false

			global.map:battleOff()

			local teamData = self.overlevelTeamData[self.overlevelData.currentTeamIndex]
			teamData.battleCount = teamData.battleCount + 1

			if isWin then
				teamData.winCount = teamData.winCount + 1
				teamData.winBattleTime = teamData.winBattleTime + WarMachine.preFrame

				print("$$$ teamData.winBattleTime", teamData.winBattleTime)
			end

			local loseCount = teamData.battleCount - teamData.winCount
			local passPercent = math.floor((self.overlevelParams.times - loseCount) / self.overlevelParams.times * 100)

			if passPercent < self.overlevelParams.pass then
				if teamLevelMax <= teamData.teamLevel then
					teamData.isLevelMax = true
					self.overlevelData.currentTeamIndex = self.overlevelData.currentTeamIndex + 1

					if self.overlevelData.currentTeamIndex > #self.overlevelTeamData then
						self.overlevelData.currentTeamIndex = 1
						self.overlevelData.levelOver = true
					end
				else
					teamData.teamLevel = teamData.teamLevel + 1
					self.overlevelData.clearPass = false
					teamData.winCount = 0
					teamData.winBattleTime = 0
					teamData.battleCount = 0
				end
			else
				local passPercent = math.floor(teamData.winCount / self.overlevelParams.times * 100)

				if self.overlevelParams.pass <= passPercent then
					local passData = {
						level = teamData.teamLevel,
						score = teamData.score,
						time = math.floor(teamData.winBattleTime / teamData.winCount)
					}
					teamData.passRecord[tostring(self.overlevelData.currentLevel)] = passData
					teamData.passLevel = self.overlevelData.currentLevel
					self.overlevelData.currentTeamIndex = self.overlevelData.currentTeamIndex + 1

					self:exportOverlevel()

					if self.overlevelData.currentTeamIndex > #self.overlevelTeamData then
						self:overlevelOnLevelOver()

						self.overlevelData.currentTeamIndex = 1
						self.overlevelData.levelOver = true
						self.overlevelData.clearPass = true

						self:overlevelRefreshLevel()
					end
				end
			end

			self:overlevelRefreshHeroList()
			self:performWithDelay(function ()
				local units = ClipOnMap.getUnitList("monster", "hero", "hero_copy", "pet", "summoned")

				for i, unit in ipairs(units) do
					unit:die()
				end

				self:performWithDelay(function ()
					self.isBattle = nil
				end, 0.2)
			end, 0.1)
		end

		local equipLevel = nil

		if self.overlevelParams.equip_level == 1 then
			equipLevel = self.overlevelData.currentLevel
		else
			equipLevel = heroLevel
		end

		self.isBattle = true
		local copy = self:startAbyss(abyssLevel, heroLevel, heroID, equipLevel, seed, monsterGroups, onBattleOver, monsterCreateID)
		teamData.score = CopyAttr.getScore(copy)

		self:overlevelRefreshHeroList()
		self:overlevelSave()
	end
end

function FRAME_emu:overlevelSave()
	local params = self.overlevelParams
	local data = self.overlevelData
	local teamData = self.overlevelTeamData
	local saveData = {
		params = params,
		data = data,
		teamData = teamData
	}
	local path = cc.FileUtils:getInstance():getWritablePath() .. "emu_overlevel_state.txt"

	io.writefile(path, json.encode(saveData))
end

function FRAME_emu:loadOverlevel()
	local path = cc.FileUtils:getInstance():getWritablePath() .. "emu_overlevel_state.txt"
	local obj = nil

	if io.exists(path) then
		local contents = getFileString(path)
		obj = json.decode(contents)
	end

	if obj and obj.params and obj.data and obj.teamData then
		local function overlevelResume()
			self.overlevelParams = obj.params
			self.overlevelData = obj.data
			self.overlevelTeamData = obj.teamData
			local params = obj.params

			for k, v in pairs(params) do
				local eb = self.overlevelUI:getEditBoxByTag("eb_" .. k)

				if eb then
					eb:setText(v)
				end
			end

			Cookie.set("emu_overlevel_params", params, true)
			self:overlevelRefreshEquipLevel()
			self:overlevelRefreshLevel()
			self:addEnterFrame("overlevelLoop", function ()
				self:overlevelLoop()
			end)
		end

		POP_notice.open("继续之前的测试？", overlevelResume)
	end
end

function FRAME_emu:exportOverlevel()
	local str = "深渊等级"
	local minLevel, maxLevel = nil

	for i, teamData in ipairs(self.overlevelTeamData) do
		local csv = CsvParser.getCsvData("emu_hero_team", teamData.id)
		str = str .. ",通关等级_" .. csv.id .. ",通关战力_" .. csv.id .. ",战斗时间_" .. csv.id

		if teamData.passRecord then
			for levelStr, record in pairs(teamData.passRecord) do
				local level = tonumber(levelStr)

				if not minLevel or level < minLevel then
					minLevel = level
				end

				if not maxLevel or maxLevel < level then
					maxLevel = level
				end
			end
		end
	end

	if minLevel and maxLevel then
		for level = minLevel, maxLevel do
			local levelStr = tostring(level)
			str = str .. "\r\n" .. level

			for i, teamData in ipairs(self.overlevelTeamData) do
				if teamData.passRecord and teamData.passRecord[levelStr] then
					local record = teamData.passRecord[levelStr]
					str = str .. "," .. record.level
					str = str .. "," .. record.score
					str = str .. "," .. math.floor(record.time / 60 * 10) / 10
				else
					str = str .. ",,,"
				end
			end
		end

		local fileName = "emu_overlevel_record equip_by_"

		if self.overlevelParams.equip_level == 1 then
			fileName = fileName .. "abyss.csv"
		else
			fileName = fileName .. "hero.csv"
		end

		local path = cc.FileUtils:getInstance():getWritablePath() .. fileName

		io.writefile(path, str)
	end
end

function FRAME_emu:myteamRefreshDoing()
	local bt_start = self.myteamUI:getComponentByTag("bt_start")

	if self.doing then
		bt_start:addLabel("停止")
	else
		bt_start:addLabel("开始")
	end
end

function FRAME_emu:myteamRefreshLevel()
	self.controlUI:createLabelOnFlag("flag_level", self.myteamData.currentLevel)
end

function FRAME_emu:myteamRefreshHeroList()
	self.myteamList:setItems(self.myteamResult, true)
end

function FRAME_emu:myteamStart()
	local monster_create_id = self.myteamParams.monster_create_id
	local monster_create_csv = CsvParser.getCsvData("monster_create", monster_create_id, nil, true)

	if not monster_create_csv then
		Alert.open("monster_create不存在")

		return
	end

	self.myteamData = {
		winCount = 0,
		battleCount = 0,
		timeCount = 0,
		hasLose = false,
		dieCount = 0,
		dieTotal = 0,
		hpCount = 0,
		hpTotal = 0,
		timeTotal = 0,
		monster_create_id = self.myteamParams.monster_create_id,
		currentLevel = self.myteamParams.monster_level,
		maxLevel = self.myteamParams.monster_level_max,
		times = self.myteamParams.times,
		battleSeedMap = {}
	}
	self.myteamResult = {}

	self:addEnterFrame("myteamLoop", function ()
		self:myteamLoop()
	end)

	self.doing = true

	self:myteamRefreshDoing()
	self:myteamRefreshLevel()
end

function FRAME_emu:myteamStop()
	self:removeEnterFrame("myteamLoop")

	self.doing = false

	self:myteamRefreshDoing()
	POP_confirm.open("模拟结束")
end

function FRAME_emu:myteamLoop()
	local teamLevelMax = CsvParser.getMaxID("hero_base_num")

	if not self.isBattle then
		local abyssLevel = self.myteamData.currentLevel
		local seed = math.random(1, 65535)
		local monsterCreateID = self.myteamData.monster_create_id
		local monsterGroups = MapEventManager.getMonsterGroup(monsterCreateID, Random.new(seed), 1, 1, abyssLevel, self.myteamData.mutateCSV)

		print("$$$ 战斗 等级：", abyssLevel, "场次：", self.myteamData.winCount .. "/" .. self.myteamData.battleCount)

		local function onBattleOver(isWin)
			WarMachine.event_on = false

			global.map:battleOff()

			self.myteamData.battleCount = self.myteamData.battleCount + 1

			if isWin then
				self.myteamData.winCount = self.myteamData.winCount + 1
			end

			self.myteamData.timeTotal = self.myteamData.timeTotal + WarMachine.preFrame
			self.myteamData.timeCount = self.myteamData.timeCount + 1
			local units = self.battleHeros
			local hp = 0
			local maxHp = 0
			local die = 0

			for i, unit in ipairs(units) do
				hp = hp + math.max(0, unit.battleData.hp)
				maxHp = maxHp + unit.attrs.hp

				if unit.battleData.hp <= 0 then
					die = die + 1
				end
			end

			self.myteamData.hpTotal = self.myteamData.hpTotal + 1 - hp / maxHp
			self.myteamData.hpCount = self.myteamData.hpCount + 1
			self.myteamData.dieTotal = self.myteamData.dieTotal + die / #units
			self.myteamData.dieCount = self.myteamData.dieCount + 1
			local result = {
				level = abyssLevel,
				battleCount = self.myteamData.battleCount,
				winCount = self.myteamData.winCount,
				time = math.floor(self.myteamData.timeTotal / self.myteamData.timeCount / 60 * 100) / 100 .. "S",
				hp = math.floor(self.myteamData.hpTotal / self.myteamData.hpCount * 10000) / 100 .. "%",
				die = math.floor(self.myteamData.dieTotal / self.myteamData.dieCount * 10000) / 100 .. "%"
			}

			if self.myteamData.battleCount == 1 then
				table.insert(self.myteamResult, 1, result)
			else
				local data = self.myteamResult[1]

				for k, v in pairs(result) do
					data[k] = v
				end
			end

			if self.myteamData.times <= self.myteamData.battleCount then
				if self.myteamData.maxLevel < self.myteamData.currentLevel then
					self:myteamStop()
				else
					if self.myteamData.winCount < self.myteamData.battleCount then
						self.myteamData.hasLose = true
					end

					if self.myteamData.hasLose then
						self.myteamData.currentLevel = self.myteamData.currentLevel + 1
					else
						self.myteamData.currentLevel = self.myteamData.currentLevel + self.myteamParams.lvup_jump
					end
				end

				self.myteamData.winCount = 0
				self.myteamData.battleCount = 0
				self.myteamData.timeTotal = 0
				self.myteamData.timeCount = 0
				self.myteamData.hpTotal = 0
				self.myteamData.hpCount = 0
				self.myteamData.dieTotal = 0
				self.myteamData.dieCount = 0
			end

			self:myteamRefreshHeroList()
			self:myteamRefreshLevel()
			self:exportMyteam()
			self:performWithDelay(function ()
				local units = ClipOnMap.getUnitList("monster", "hero", "hero_copy", "pet", "summoned")

				for i, unit in ipairs(units) do
					unit:die()
				end

				self:performWithDelay(function ()
					self.isBattle = nil
				end, 0.2)
			end, 0.1)
		end

		self.isBattle = true
		local copy = self:startAbyss(abyssLevel, 1, 1, 1, seed, monsterGroups, onBattleOver, monsterCreateID)
		local score = CopyAttr.getScore(copy)

		self.myteamUI:createLabelOnFlag("flag_score", "总战力（不含图鉴）：" .. score)

		local nameStr = ""

		for i, heroInfo in ipairs(copy.hero) do
			if nameStr ~= "" then
				nameStr = nameStr .. " | "
			end

			nameStr = nameStr .. heroInfo.name
		end

		local petIndex = copy.petIndex or 1
		local petInfo = copy.pet[petIndex]

		if petInfo then
			if nameStr ~= "" then
				nameStr = nameStr .. " | "
			end

			local petName = petInfo.name

			if empty(petName) then
				local petCSV = CsvParser.getCsvData("pet", petInfo.base_id)
				petName = petCSV.name
			end

			nameStr = nameStr .. petName
		end

		self.myteamUI:createLabelOnFlag("flag_team", nameStr)

		self.myteamDesc = "队伍：" .. nameStr .. ",总战力（不含图鉴）：" .. score

		self:myteamRefreshHeroList()
		self:myteamSave()
	end
end

function FRAME_emu:myteamSave()
	local params = self.myteamParams
	local data = self.myteamData
	local result = self.myteamResult
	local saveData = {
		params = params,
		data = data,
		result = result
	}
	local path = cc.FileUtils:getInstance():getWritablePath() .. "emu_myteam_state.txt"

	io.writefile(path, json.encode(saveData))
end

function FRAME_emu:loadMyteam()
	local path = cc.FileUtils:getInstance():getWritablePath() .. "emu_myteam_state.txt"
	local obj = nil

	if io.exists(path) then
		local contents = getFileString(path)
		obj = json.decode(contents)
	end

	if obj and obj.params and obj.data and obj.result then
		local function myteamResume()
			self.myteamParams = obj.params
			self.myteamData = obj.data
			self.myteamResult = obj.result
			local params = obj.params

			for k, v in pairs(params) do
				local eb = self.myteamUI:getEditBoxByTag("eb_" .. k)

				if eb then
					eb:setText(v)
				end
			end

			Cookie.set("emu_myteam_params", params, true)
			self:myteamRefreshLevel()
			self:addEnterFrame("myteamLoop", function ()
				self:myteamLoop()
			end)
		end

		POP_notice.open("继续之前的测试？", myteamResume)
	end
end

function FRAME_emu:exportMyteam()
	local str = ""

	if not empty(self.myteamDesc) then
		str = self.myteamDesc .. "\r\n"
	end

	str = str .. "挑战等级,平均时长,血量损耗,平均阵亡,胜负"

	for i, result in ipairs(self.myteamResult) do
		str = str .. "\r\n"
		str = str .. result.level
		str = str .. "," .. result.time
		str = str .. "," .. result.hp
		str = str .. "," .. result.die
	end

	local fileName = "emu_myteam_record.csv"
	local path = cc.FileUtils:getInstance():getWritablePath() .. fileName

	io.writefile(path, str)
end

function FRAME_emu:startBattle(seed, onBattleOver, monsterCreateID, pack, copy, petIndex)
	MapFrameManager.setSuperTimeRatio(self.speedRatio)

	if self.overlevelParams and not empty(self.overlevelParams.timeout) then
		WarMachine.setLoseTimeout(self.overlevelParams.timeout)
	else
		WarMachine.clearLoseTimeout()
	end

	local battleCenter = MapEventManager.getEventByTagOne("battle-center")
	local centerTile = global.map:getTile(battleCenter.x, battleCenter.y)
	local createParams = {
		isCopy = true,
		seed = seed,
		monsterCreateID = monsterCreateID,
		pack = pack,
		onBattleWin = function ()
			onBattleOver(true)
		end,
		onBattleLose = function ()
			onBattleOver(false)
		end
	}
	local petIndexMap = {}
	local copyMap = {
		copy
	}
	petIndexMap[1] = petIndex

	global.map:prepareBattleEmu(centerTile, 0, battleCenter, createParams, copyMap, petIndexMap)

	if self.petInfo then
		local petInfo = self.petInfo
		local petIndex = 1
		local camp = petInfo.camp
		petInfo.name = ""
		petInfo.id = camp * 100 + petIndex
		petInfo.isCopy = true
		local battleCenter = MapEventManager.getEventByTagOne("battle-center")
		local centerTile = global.map:getTile(battleCenter.x, battleCenter.y)
		local playerEvent = MapEventManager.getEventByTagOne("player_" .. camp)
		local playerTile = global.map:getTile(playerEvent.x, playerEvent.y)
		local playerAngle = math.atan2(battleCenter.y - playerEvent.y, battleCenter.x - playerEvent.x)

		WarMachine.preparePet(camp, centerTile, playerTile, playerAngle)

		if petInfo then
			WarMachine.addPetReady(camp, petInfo)
		end
	end
end

local team_pos = {
	{
		2
	},
	{
		1,
		3
	},
	{
		1,
		2,
		3
	}
}

function FRAME_emu:startAbyss(abyssLevel, heroLevel, heroID, equipLevel, seed, monsterGroups, onBattleOver, monsterCreateID)
	local units = ClipOnMap.getUnitList("monster", "hero", "hero_copy", "pet", "summoned")

	for i, unit in ipairs(units) do
		if unit.removeFromMap then
			unit:removeFromMap()
		end

		unit:removeSelf()
	end

	MapFrameManager.clear()
	global.map.baseLayer:removeAllChildren()
	global.map.lowLayer:removeAllChildren()
	global.map.highLayer:removeAllChildren()
	global.map.hudHighLayer:removeAllChildren()

	local random = Random.new(seed)

	CopyAttr.setAttrLevel(abyssLevel)
	MapEventManager.setCustomLevel(abyssLevel)

	local anchorEvent = MapEventManager.getEventByTagOne("anchor_emu")
	anchorEvent.seed = random:getInt(1, 65535)
	local setData = ConfParser.parse(anchorEvent.info)
	setData.time = setData.time or 0
	setData.power = setData.power or 0
	local pack = {
		visibleCount = 0,
		activeCD = 0,
		index = 1,
		activeCount = 0,
		active = 0,
		setData = setData,
		eventData = anchorEvent,
		custom_level = abyssLevel
	}

	MapEventManager.makeMonsterGroups(monsterGroups, pack)

	local copy = nil

	if self.myteam then
		copy = Emu.createMyTeam()
	else
		local equipClassMap = Emu.getEquipMap(equipLevel)
		copy = Emu.createHeroTeam(heroID, heroLevel, equipClassMap)
	end

	local camp = 1
	local fCount = 0
	local bCount = 0

	for j, heroInfo in ipairs(copy.hero) do
		local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)

		if heroCSV.class == 1 then
			fCount = fCount + 1
		else
			bCount = bCount + 1
		end
	end

	local f_pos = team_pos[fCount]
	local b_pos = team_pos[bCount]
	local fCount = 0
	local bCount = 0
	self.battleHeros = {}

	for j, heroInfo in ipairs(copy.hero) do
		heroInfo.id = heroInfo.id or camp * 100 + j
		local hero = HeroCopy.new()
		hero.camp = camp
		hero.seed = random:getInt(1, 65535)
		hero.random = Random.new(hero.seed)

		hero:setDieout(true)
		hero:setInfo(heroInfo, copy)

		local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)
		local posLine, posIndex = nil

		if heroCSV.class == 1 then
			fCount = fCount + 1
			posLine = 1
			posIndex = f_pos[fCount]
		else
			bCount = bCount + 1
			posLine = 2
			posIndex = b_pos[bCount]
		end

		local posEvent = MapEventManager.getEventByTagOne("pos_" .. camp .. "_" .. posLine .. "_" .. posIndex)
		local mapX, mapY = global.map:tileToMap(posEvent.x, posEvent.y)

		hero:display(global.map, mapX, mapY)

		if camp == 1 then
			hero.angle = math.pi
		end

		hero:setDieout(false)
		table.insert(self.battleHeros, hero)
	end

	local petIndex = copy.petIndex or 1
	self.petInfo = copy.pet[petIndex]

	if self.petInfo then
		self.petInfo.camp = camp
	end

	self:startBattle(seed, onBattleOver, monsterCreateID, pack, copy, petIndex)

	return copy
end

function FRAME_emu:initArena()
	FRAME_emu.seed = math.random(1, 65535)
	local random = Random.new(FRAME_emu.seed)

	print("$$$ initArena", FRAME_emu.seed)

	local abyssLevel = 67
	self.teams = {}
	self.petReady = {}
	self.petTeamInfo1 = {}

	CopyAttr.setAttrLevel(abyssLevel)

	for camp = 1, 2 do
		local copy = Emu.createHeroTeam(1, abyssLevel)
		local fCount = 0
		local bCount = 0

		for j, heroInfo in ipairs(copy.hero) do
			local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)

			if heroCSV.class == 1 then
				fCount = fCount + 1
			else
				bCount = bCount + 1
			end
		end

		local f_pos = team_pos[fCount]
		local b_pos = team_pos[bCount]
		local fCount = 0
		local bCount = 0
		self.teams[camp] = {}

		for j, heroInfo in ipairs(copy.hero) do
			heroInfo.id = heroInfo.id or camp * 100 + j
			local hero = HeroCopy.new()
			hero.camp = camp
			hero.seed = random:getInt(1, 65535)
			hero.random = Random.new(hero.seed)

			hero:setInfo(heroInfo, copy)

			local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)
			local posLine, posIndex = nil

			if heroCSV.class == 1 then
				fCount = fCount + 1
				posLine = 1
				posIndex = f_pos[fCount]
			else
				bCount = bCount + 1
				posLine = 2
				posIndex = b_pos[bCount]
			end

			local posEvent = MapEventManager.getEventByTagOne("pos_" .. camp .. "_" .. posLine .. "_" .. posIndex)
			local mapX, mapY = global.map:tileToMap(posEvent.x, posEvent.y)

			hero:display(global.map, mapX, mapY)

			if camp == 1 then
				hero.angle = math.pi
			end

			table.insert(self.teams[camp], hero)
		end
	end
end

return FRAME_emu
