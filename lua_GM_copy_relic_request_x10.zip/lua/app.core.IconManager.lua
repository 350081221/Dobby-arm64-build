local IconManager = {}

local function checkFilePath(path, _path)
	if path == _path then
		return isFileExist("res/" .. path)
	else
		return not empty(path)
	end
end

local function checkPath(_path, defaultIcon)
	local path = nil

	if type(_path) == "table" then
		local found = false

		for i, v in ipairs(_path) do
			path = getFinalRes(v)

			if checkFilePath(path, v) then
				found = true

				break
			end
		end

		if not found then
			path = getFinalRes(defaultIcon or "image/pic/0.png")
		end
	else
		path = getFinalRes(_path)

		if not checkFilePath(path, _path) then
			path = getFinalRes(defaultIcon or "image/pic/0.png")
		end
	end

	return path
end

function IconManager.checkPath(_path, defaultIcon)
	return checkPath(_path, defaultIcon)
end

local imageSizeMap = nil

function IconManager.getImageRect(path)
	if not imageSizeMap then
		imageSizeMap = {}
		local str = getFileString("res/image/rects.txt")

		if str then
			local lines = str:split("\n")

			for i, line in ipairs(lines) do
				local values = line:split(",")
				local url = getFinalRes("image/" .. values[1])
				imageSizeMap[url] = cc.rect(tonumber(values[2]), tonumber(values[3]), tonumber(values[4]), tonumber(values[5]))
			end
		end
	end

	return imageSizeMap[path]
end

function IconManager.getEquipIcon(id)
	local equipData = CsvParser.getCsvData("equip", id)
	local path = "image/pic/equip/icon/" .. equipData.pic .. ".png"

	return checkPath(path)
end

function IconManager.getItemIcon(id)
	local itemData = CsvParser.getCsvData("item", id)
	local paths = {}

	if itemData then
		table.insert(paths, "image/pic/item/icon/" .. itemData.pic .. ".png")
		table.insert(paths, "image/pic/equip/icon/" .. itemData.pic .. ".png")
	end

	return checkPath(paths)
end

function IconManager.getSkillIcon(id)
	local skillData = CsvParser.getCsvData("skill", id)
	local path = "image/pic/skill/icon/" .. skillData.pic .. ".png"

	return checkPath(path)
end

function IconManager.getSkillIconPath(name)
	local path = "image/pic/skill/icon/" .. name .. ".png"

	return checkPath(path)
end

function IconManager.getCardIcon(id)
	local cardData = CsvParser.getCsvData("card", id)
	local path = "image/pic/card/icon/" .. cardData.pic .. ".png"

	return checkPath(path)
end

function IconManager.getCardPic(id)
	local cardData = CsvParser.getCsvData("card", id)
	local path = "image/pic/card/pic/" .. cardData.pic .. ".png"

	return checkPath(path)
end

function IconManager.getSkillMinicon(id)
	local skillData = CsvParser.getCsvData("skill", id)
	local path = "image/pic/skill/minicon/" .. skillData.pic .. ".png"

	return checkPath(path, "image/pic/minicon_default.png")
end

function IconManager.getQuestIcon(id)
	local questData = CsvParser.getCsvData("quest", id)
	local path = "image/pic/quest/icon/" .. questData.pic .. ".png"

	return checkPath(path)
end

function IconManager.getBuffIcon(id)
	local buffData = CsvParser.getCsvData("buff", id)
	local path = "image/pic/buff/icon/" .. buffData.pic .. ".png"

	return checkPath(path)
end

function IconManager.getUnionBuffIcon(id)
	local buffData = CsvParser.getCsvData("union_buff", id)
	local path = "image/pic/buff/icon/" .. buffData.pic .. ".png"

	return checkPath(path)
end

function IconManager.getBuffIconPic(pic)
	local path = "image/pic/buff/icon/" .. pic .. ".png"

	return checkPath(path)
end

function IconManager.getMirrorIcon(id)
	local mirrorData = CsvParser.getCsvData("mirror_skill", id)
	local path = ""

	if mirrorData then
		path = "image/pic/mirror/icon/" .. mirrorData.pic .. ".png"
	end

	return checkPath(path)
end

function IconManager.getHead(id, emoji)
	local headData = CsvParser.getCsvData("head", id)

	if empty(emoji) then
		emoji = 1
	end

	local path = ""

	if headData then
		path = "image/pic/head/" .. headData["emoji_" .. emoji] .. ".png"
	end

	return checkPath(path)
end

function IconManager.getIcon(path)
	return checkPath(path)
end

function IconManager.getHeadPic(headName)
	return getFinalRes("res/image/pic/head/" .. headName .. ".png")
end

function IconManager.getMiscIcon(name)
	return getFinalRes("res/image/pic/misc/icon/" .. name .. ".png")
end

function IconManager.getMiscFarm(name)
	return getFinalRes("res/image/pic/misc/farm/" .. name .. ".png")
end

function IconManager.getAchieveIcon(id)
	local achieveData = CsvParser.getCsvData("achievement", id)
	local path = ""

	if achieveData then
		path = "image/pic/achieve/icon/" .. achieveData.pic .. ".png"
	end

	return checkPath(path)
end

function IconManager.getAchievePic(pic)
	local path = "image/pic/achieve/icon/" .. pic .. ".png"

	return checkPath(path)
end

function IconManager.getWildPic(id)
	local spotData = CsvParser.getCsvData("wild_spot", id)
	local path = ""

	if spotData then
		path = "image/pic/wild/pic/" .. spotData.pic .. ".png"
	end

	return checkPath(path)
end

function IconManager.getWildIcon(id)
	local spotData = CsvParser.getCsvData("wild_spot", id)
	local path = ""

	if spotData then
		path = "image/pic/wild/icon/" .. spotData.pic .. ".png"
	end

	return checkPath(path)
end

function IconManager.getGachaPic(id)
	local gachaData = CsvParser.getCsvData("gacha", id)
	local path = ""

	if gachaData then
		path = "image/pic/gacha/pic/" .. gachaData.pic .. ".png"
	end

	return checkPath(path)
end

function IconManager.getArenaDivisionIcon(id)
	local divisionData = CsvParser.getCsvData("arena_division", id)
	local path = ""

	if divisionData then
		path = "image/pic/arena/division/" .. divisionData.pic .. ".png"
	end

	return checkPath(path)
end

function IconManager.getArenaDivisionStar(id)
	local divisionData = CsvParser.getCsvData("arena_division", id)
	local path = ""

	if divisionData then
		path = "image/pic/arena/division/star" .. divisionData.star .. ".png"
	end

	return checkPath(path)
end

function IconManager.getArenaTargetIcon(id)
	local targetData = CsvParser.getCsvData("arena_target", id)
	local path = ""

	if targetData then
		path = "image/pic/arena/target/" .. targetData.pic .. ".png"
	end

	return checkPath(path)
end

function IconManager.getAbyssTerrainPic(id)
	local terrainData = CsvParser.getCsvData("abyss_terrain", id)
	local path = ""

	if terrainData then
		path = "image/pic/abyss/terrain/" .. terrainData.pic .. ".png"
	end

	return checkPath(path)
end

function IconManager.getFishingPic(id)
	local spotData = CsvParser.getCsvData("fishing_spot", id)
	local path = ""

	if spotData then
		path = "image/pic/fishing/pic/" .. spotData.pic .. ".png"
	end

	return checkPath(path)
end

function IconManager.getCampaignPic(pic)
	local path = "image/pic/campaign/pic/" .. pic .. ".png"

	return checkPath(path)
end

function IconManager.getDustPic(pic)
	local path = "image/pic/dust/pic/" .. pic .. ".png"

	return checkPath(path)
end

function IconManager.getItemPic(pic)
	local path = "image/pic/item/icon/" .. pic .. ".png"

	return checkPath(path)
end

function IconManager.getBookIcon(id)
	local bookData = CsvParser.getCsvData("books_catalog", id)
	local path = ""

	if bookData then
		path = "image/pic/book/icon/" .. bookData.pic .. ".png"
	end

	return checkPath(path)
end

function IconManager.getAbyssAreaIcon(id)
	local areaData = CsvParser.getCsvData("abyss_area", id)
	local path = ""

	if areaData then
		path = "image/pic/abyss/area/icon/" .. areaData.pic .. ".png"
	end

	return checkPath(path)
end

function IconManager.getNarakaIcon(id)
	local narakaData = CsvParser.getCsvData("naraka_stage", id)

	return IconManager.getAbyssAreaIcon(narakaData.abyss_area)
end

function IconManager.getSpheroStand(id)
	local spData = CsvParser.getCsvData("hero_sp", id)
	local path = ""

	if spData then
		path = "image/pic/stand/sp/" .. spData.pic .. ".png"
	end

	return checkPath(path)
end

function IconManager.getNarakaMode(id)
	local modeData = CsvParser.getCsvData("naraka_mode", id)
	local path = ""

	if modeData then
		path = "image/pic/abyss/naraka_mode/" .. modeData.pic .. ".png"
	end

	return checkPath(path)
end

function IconManager.getFaqPic(id)
	local faqData = CsvParser.getCsvData("service_faq", id)
	local path = ""

	if faqData then
		path = "image/pic/faq/pic/" .. faqData.pic .. ".png"
	end

	return checkPath(path)
end

function IconManager.getSnsIcon(id)
	local snsData = CsvParser.getCsvData("service_sns", id)
	local path = ""

	if snsData then
		path = "image/pic/sns/icon/" .. snsData.pic .. ".png"
	end

	return checkPath(path)
end

function IconManager.getActvAchieveIcon(id)
	local achieveData = CsvParser.getCsvData("actv_achieve", id)
	local path = ""

	if achieveData then
		path = "image/pic/achieve/icon/" .. achieveData.pic .. ".png"
	end

	return checkPath(path)
end

function IconManager.getUnionFlagPic(id)
	local csv = CsvParser.getCsvData("union_flag", id)

	if csv.pic ~= "" then
		local path = "image/pic/union/flag/" .. csv.pic .. ".png"

		return checkPath(path)
	end
end

function IconManager.getUnionFlagRaw(pic)
	local path = "image/pic/union/flag/" .. pic .. ".png"

	return checkPath(path)
end

function IconManager.getUnionFlag(obj)
	local bgFlag = obj.icon1
	local bgColor = obj.icon2
	local iconFlag = obj.icon3
	local iconColor = obj.icon4

	if empty(bgFlag) then
		bgFlag = MiscConfig.default_union_flag_bg
	end

	if empty(bgColor) then
		bgColor = MiscConfig.default_union_color_bg
	end

	if empty(iconFlag) then
		iconFlag = MiscConfig.default_union_flag_icon
	end

	if empty(iconColor) then
		iconColor = MiscConfig.default_union_color_icon
	end

	local bgPath, iconPath, colorBg1, colorBg2, colorIcon = nil
	local csv = CsvParser.getCsvData("union_flag", bgFlag)

	if csv and csv.pic ~= "" then
		bgPath = "image/pic/union/flag/" .. csv.pic .. ".png"
	end

	local csv = CsvParser.getCsvData("union_flag", iconFlag)

	if csv then
		iconPath = "image/pic/union/flag/" .. csv.pic .. ".png"
	end

	local csv = CsvParser.getCsvData("union_flag_color", bgColor)

	if csv then
		colorBg1 = ColorUtil.getC3B(csv.color_1)
		colorBg2 = ColorUtil.getC3B(csv.color_2)
	end

	local csv = CsvParser.getCsvData("union_flag_color", iconColor)

	if csv then
		colorIcon = ColorUtil.getC3B(csv.color_1)
	end

	local _bgPath = nil

	if bgPath then
		_bgPath = checkPath(bgPath)
	end

	return _bgPath, checkPath(iconPath), colorBg1, colorBg2, colorIcon
end

function IconManager.getBpPic(pic)
	local path = "image/pic/bp/pic/" .. pic .. ".png"

	return checkPath(path)
end

function IconManager.getBpIcon(id)
	local csv = CsvParser.getCsvData("bp", id)

	if csv.icon ~= "" then
		local path = "image/pic/bp/icon/" .. csv.icon .. ".png"

		return checkPath(path)
	end
end

function IconManager.getHeroIcon(pic)
	local path = "image/pic/hero/icon/" .. pic .. ".png"

	return checkPath(path)
end

function IconManager.getArtifactIcon(pic)
	return checkPath("image/pic/artifact/icon/" .. pic .. ".png")
end

function IconManager.getArtifactPic(pic)
	return checkPath("image/pic/artifact/pic/" .. pic .. ".png")
end

function IconManager.getCorePic(pic)
	local path = "image/pic/core/pic/" .. pic .. ".png"

	return checkPath(path)
end

return IconManager
