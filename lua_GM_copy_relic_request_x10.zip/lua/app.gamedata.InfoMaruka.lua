local InfoMaruka = {}
local rawData = nil

function InfoMaruka.init()
	Connection.listen("maruka_sync", InfoMaruka.sync)
end

app:addToAppEnterCall(InfoMaruka.init)

function InfoMaruka.query(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "maruka_query")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoMaruka.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("maruka_query", callback)
end

function InfoMaruka.onQuery(rcvData)
	rawData = rcvData
end

function InfoMaruka.sync(syncData)
	for k, v in pairs(syncData) do
		rawData[k] = v
	end

	ManagerInfo.dataChange("maruka")
end

function InfoMaruka.getReward(id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "maruka_get_reward")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("maruka_get_reward", {
		id = id
	}, callback)
end

function InfoMaruka.hasReward()
	local abyssLevel = InfoDungeon.getAbyssMaxLevel()
	local csvRaw = CsvParser.getCsvRaw("abyss_reward")

	for k, v in pairs(csvRaw) do
		if rawData.already_id < v.id and v.id <= abyssLevel then
			return true
		end
	end

	return false
end

function InfoMaruka.getDailyProgress()
	local _count = 0
	local _total = 0

	if InfoBuilding.getBuildingLevel(InfoBuilding.TAG.KANBAN) > 0 then
		local point, pointMax = InfoKanban.getQuestTargetPoints()
		point = math.min(point, pointMax)

		if pointMax <= point then
			_count = _count + 1
		end

		_total = _total + 1
	end

	if InfoBuilding.getBuildingLevel(InfoBuilding.TAG.TRAVEL) > 0 then
		local travel_hours = CsvParser.getCsvData("config", "travel_hours").value
		local hourLeft = InfoTravel.getHourLeft()
		hourLeft = travel_hours - hourLeft

		if travel_hours <= hourLeft then
			_count = _count + 1
		end

		_total = _total + 1
	end

	if InfoArena.isActived() then
		local count, max = InfoArena.getRewardCount()
		count = math.min(count, max)

		math.min(count, max)

		if max <= count then
			_count = _count + 1
		end

		_total = _total + 1
	end

	if InfoFunction.checkFuncOpen(10110) then
		local count, max = InfoTower.getTotalTimes()
		count = math.max(0, max - count)
		count = math.min(count, max)

		if max <= count then
			_count = _count + 1
		end

		_total = _total + 1
	end

	if InfoFunction.checkFuncOpen(10190) then
		local count, max = InfoNaraka.getRewardTimes()
		count = math.max(0, max - count)
		count = math.min(count, max)

		if max <= count then
			_count = _count + 1
		end

		_total = _total + 1
	end

	return _count, _total
end

function InfoMaruka.getDailyRewardAlready(id)
	if not RefreshManager.checkTimePassed(RefreshManager.TYPE.MARUKA_REWARD, Time.now(), rawData["reward_time_" .. id]) then
		return true
	end
end

function InfoMaruka.countRedot()
	local redotCount = 0
	redotCount = redotCount + InfoAchieve.countRedot()
	local dailyTargets = CsvParser.getCsvList("maruka_reward")
	local point, pointMax = InfoMaruka.getDailyProgress()

	for i, v in ipairs(dailyTargets) do
		if v.point <= point and not InfoMaruka.getDailyRewardAlready(v.id) then
			redotCount = redotCount + 1
		end
	end

	return redotCount
end

return InfoMaruka
