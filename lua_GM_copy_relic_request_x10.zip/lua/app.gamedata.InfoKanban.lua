local InfoKanban = {}
local rawData = nil

function InfoKanban.init()
	Connection.listen("kanban_sync", InfoKanban.sync)
end

app:addToAppEnterCall(InfoKanban.init)

function InfoKanban.clear()
	rawData = nil
end

function InfoKanban.query(onSuccess, onFailure)
	if rawData and Time.now() < rawData.refresh_time then
		if onSuccess then
			onSuccess()
		end

		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoKanban.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("kanban_query", callback)
end

function InfoKanban.onQuery(rcvData)
	rawData = rcvData
end

function InfoKanban.sync(data)
	for k, v in pairs(data) do
		rawData[k] = v
	end

	ManagerInfo.dataChange("kanban", data)
end

function InfoKanban.getData()
	return rawData
end

function InfoKanban.countRedot()
	local redotCount = 0
	local questTargets = InfoKanban.getQuestTargets()
	local point, pointMax = InfoKanban.getQuestTargetPoints()

	for i, v in ipairs(questTargets) do
		if v.point <= point and InfoKanban.getRewardRecord(v.point) == 0 then
			redotCount = redotCount + 1
		end
	end

	return redotCount
end

function InfoKanban.getNextRefreshTime()
	return RefreshManager.getNextTime(RefreshManager.TYPE.KANBAN, Time.now())
end

function InfoKanban.getActPoints()
	local kanbanCSV = CsvParser.getCsvData("kanban", rawData.level)
	local act_count = rawData.act_count

	if RefreshManager.checkTimePassed(RefreshManager.TYPE.KANBAN, Time.now(), rawData.act_time) then
		act_count = 0
	end

	local actpoint = kanbanCSV.actpoint

	if InfoOrder.inSeason() then
		actpoint = actpoint + InfoOrder.getSeasonFunc(1)
	end

	return actpoint - act_count, act_count, actpoint
end

function InfoKanban.getRewardRecord(point)
	local recordNum = rawData.reward_record

	if RefreshManager.checkTimePassed(RefreshManager.TYPE.KANBAN, Time.now(), rawData.target_reward_time) then
		recordNum = 0
	end

	return BitUtil.getBitByIndex(recordNum, point)
end

local questTargetCache = nil

function InfoKanban.getQuestTargets()
	if not questTargetCache then
		questTargetCache = {}
		local csvRaw = CsvParser.getCsvRaw("quest_target")
		local mapByPoint = {}

		for k, csv in pairs(csvRaw) do
			mapByPoint[csv.point] = mapByPoint[csv.point] or {}

			table.insert(mapByPoint[csv.point], csv)
		end

		for point, arr in pairs(mapByPoint) do
			if #arr > 1 then
				table.sort(arr, function (a, b)
					return b.level < a.level
				end)
			end

			table.insert(questTargetCache, arr)
		end

		table.sort(questTargetCache, function (a, b)
			return a[1].point < b[1].point
		end)
	end

	local abyssLevel = math.max(1, InfoDungeon.getAbyssMaxLevel())
	local questTargets = {}

	for i, arr in ipairs(questTargetCache) do
		for j, csv in ipairs(arr) do
			if csv.level < abyssLevel then
				table.insert(questTargets, csv)

				break
			end
		end
	end

	return questTargets
end

function InfoKanban.getQuestTargetPoints()
	local points = rawData.points

	if RefreshManager.checkTimePassed(RefreshManager.TYPE.KANBAN, Time.now(), rawData.act_time) then
		points = 0
	end

	local questTargets = InfoKanban.getQuestTargets()
	local pointsMax = questTargets[#questTargets].point

	return math.min(pointsMax, points), pointsMax
end

function InfoKanban.getQuestTargetReward(targetID, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("kanban_get_target_reward", {
		target_id = targetID
	}, callback)
end

function InfoKanban.refresh(mode, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("kanban_refresh", {
		mode = mode
	}, callback)
end

function InfoKanban.getLevelUpCost()
	local levelData = CsvParser.getCsvData("kanban", rawData.level, "level")

	return SheetUtil.getColumnList(levelData, {
		"lvup_cost_id_",
		"lvup_cost_num_"
	}, {
		"id",
		"num"
	})
end

function InfoKanban.levelUp(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Http.request("kanban/levelup", callback)
end

function InfoKanban.getCount()
	return rawData.count
end

return InfoKanban
