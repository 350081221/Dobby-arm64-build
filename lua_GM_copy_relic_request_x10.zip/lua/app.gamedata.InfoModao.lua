local InfoModao = {}
local rawData = {}

function InfoModao.init()
	Connection.listen("modao_sync", InfoModao.sync)
end

app:addToAppEnterCall(InfoModao.init)

function InfoModao.enabled()
	return InfoBuilding.getBuildingLevel(InfoBuilding.TAG.MONO) > 0
end

function InfoModao.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoModao.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("modao_query", callback)
end

function InfoModao.onQuery(rcvData)
	rawData = {}

	for i = 1, #rcvData.list do
		local data = rcvData.list[i]
		rawData[data.base_id] = data
	end
end

function InfoModao.sync(data)
	dump(data, "$$$ InfoModao.sync")

	for i, syncData in ipairs(data.list) do
		local base_id = syncData.base_id

		if not rawData[base_id] then
			rawData[base_id] = syncData
		else
			for k, v in pairs(syncData) do
				rawData[base_id][k] = v
			end
		end
	end

	ManagerInfo.dataChange("modao", data)
end

local modaoData, currentModaoMp, currentMpStartFrame, isBattle = nil

function InfoModao.initDungeon(_isBattle)
	isBattle = _isBattle

	InfoModao.refreshModaoData()

	currentModaoMp = InfoDungeon.getModaoMP()
	currentMpStartFrame = WarMachine.getFrame()
end

function InfoModao.checkModaoAttr(attrList)
	for i, v in ipairs(attrList) do
		local attrCSV = CsvParser.getCsvData("attr", v.attr)

		if attrCSV.type == CombatAttr.TYPE.MODAO then
			return true
		end
	end
end

function InfoModao.refreshModaoData()
	if WarMachine.on and modaoData then
		InfoModao.balanceMp()
	end

	modaoData = CombatAttr.getModaoData()
end

function InfoModao.getModaoData()
	return modaoData
end

function InfoModao.battleOver()
	local mpCurrent, mpMax = InfoModao.getMp()
	currentModaoMp = mpCurrent
	currentMpStartFrame = 0
end

function InfoModao.getMp()
	if global.inEmu then
		return 0, 0
	end

	if not modaoData then
		return 0, 0
	end

	local currentMp = nil

	if isBattle then
		local passed = WarMachine.getFrame() - currentMpStartFrame
		local speed = modaoData.mp_resume * (1 + modaoData.mp_resume_rate / 100)
		currentMp = currentModaoMp + speed / 60 * passed
	else
		currentMp = currentModaoMp
	end

	currentMp = math.max(0, math.min(currentMp, InfoModao.getMpMax()))

	return currentMp, InfoModao.getMpMax()
end

function InfoModao.getMpMax()
	return math.max(0, modaoData.mp + InfoDungeon.getModaoMax())
end

function InfoModao.getMpDepth()
	return 0
end

function InfoModao.checkMp(value)
	local mpDepth = InfoModao.getMpDepth()
	local mpCurrent, mpMax = InfoModao.getMp()
	local minMp = -mpDepth * mpMax
	local newMp = mpCurrent - value

	if minMp <= newMp then
		return true
	else
		return false
	end

	return true
end

function InfoModao.balanceMp()
	local mpCurrent, mpMax = InfoModao.getMp()
	currentModaoMp = math.max(0, mpCurrent)
	currentMpStartFrame = WarMachine.getFrame()

	notify.dispatch("modao_mana")
end

function InfoModao.useMp(value)
	if InfoModao.checkMp(value) then
		local mpCurrent, mpMax = InfoModao.getMp()
		currentModaoMp = math.max(0, mpCurrent - value)
		currentMpStartFrame = WarMachine.getFrame()

		notify.dispatch("modao_mana")

		return true
	end

	return false
end

function InfoModao.addMp(value)
	local mpCurrent, mpMax = InfoModao.getMp()
	currentModaoMp = math.max(0, mpCurrent + value)
	currentMpStartFrame = WarMachine.getFrame()

	notify.dispatch("modao_mana")
end

function InfoModao.fakeMp(value)
	currentModaoMp = value

	notify.dispatch("modao_mana", currentModaoMp)
end

function InfoModao.refreshMp(maxChanged)
	if maxChanged then
		notify.dispatch("modao_mana_max")
	end

	if not WarMachine.on then
		currentModaoMp = InfoDungeon.getModaoMP()

		notify.dispatch("modao_mana", currentModaoMp)
	end
end

function InfoModao.addMpKill(monsterInfo)
	if modaoData then
		local monsterCSV = CsvParser.getCsvData("monster", monsterInfo.base_id)
		local value = modaoData.mp_resume_kill * monsterCSV.getkill_mpadd_ratio * (1 + modaoData.mp_resume_rate / 100)

		InfoModao.addMp(value)
	end
end

function InfoModao.addMpKillTD(_value)
	if modaoData then
		local value = _value * (1 + modaoData.mp_resume_rate / 100)

		InfoModao.addMp(value)
	end
end

function InfoModao.addMpGetKill(heroInfo)
	if modaoData then
		local value = modaoData.mp_resume_getkill * (1 + modaoData.mp_resume_rate / 100)

		InfoModao.addMp(value)
	end
end

function InfoModao.checkLvupResource(checkItemID)
	local csvRaw = CsvParser.getCsvRaw("skill")

	for k, v in pairs(csvRaw) do
		if not empty(v.category) and v.cost_id ~= checkItemID then
			return false
		end
	end

	return true
end

function InfoModao.countLvup()
	local currentBuildingData = InfoBuilding.getBuildingData(InfoBuilding.TAG.MONO)
	local arr = InfoModao.getSkills()
	local count = 0

	for i, data in ipairs(arr) do
		local level, maxLevel = InfoModao.getSkillLevel(data.base_id)
		local modaoCSV = CsvParser.getCsvData("modao_skill", data.base_id)

		if data.level > 0 and level < maxLevel and data.level < currentBuildingData.value2 then
			local skillData = CsvParser.getFilteredData("skill", {
				category = modaoCSV.skill_id,
				level = level
			})
			local costInfo = {
				base_id = skillData.cost_id,
				num = skillData.cost
			}
			local itemNum = InfoItem.getNum(costInfo.base_id)

			if costInfo.num <= itemNum then
				count = count + 1
			end
		end
	end

	return count
end

function InfoModao.getSkills()
	local arr = CsvParser.getCsvList("modao_skill")
	local items = {}

	for i, v in ipairs(arr) do
		local info = rawData[v.id]

		if info then
			table.insert(items, {
				base_id = v.id,
				index = v.index,
				level = info.level,
				pos = info.pos
			})
		else
			table.insert(items, {
				level = 0,
				pos = 0,
				base_id = v.id,
				index = v.index
			})
		end
	end

	table.sort(items, function (a, b)
		return a.index < b.index
	end)

	return items
end

function InfoModao.getSkill(base_id)
	local info = rawData[base_id]

	if info then
		return info
	end
end

local maxLevelMap = nil

function InfoModao.getSkillLevel(base_id)
	if not maxLevelMap then
		maxLevelMap = {}
		local modao_csv_raw = CsvParser.getCsvList("modao_skill")

		for k, modao_csv in pairs(modao_csv_raw) do
			local skill_id = modao_csv.skill_id
			local skillDatas = CsvParser.getCsvList("skill", "level", {
				category = modao_csv.skill_id
			})
			local maxLevel = skillDatas[#skillDatas].level
			maxLevelMap[modao_csv.id] = maxLevel
		end
	end

	local info = rawData[base_id]
	local maxLevel = maxLevelMap[base_id]

	if info then
		return math.min(info.level, maxLevel), maxLevel
	else
		return 0, maxLevel
	end
end

function InfoModao.getPosBySkill(id)
	for base_id, v in pairs(rawData) do
		if base_id == id then
			return v.pos
		end
	end
end

function InfoModao.getSkillByPos(pos)
	for base_id, v in pairs(rawData) do
		if v.pos == pos then
			return v
		end
	end
end

function InfoModao.equipSkill(baseID, pos, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("modao_equip", {
		base_id = baseID,
		pos = pos
	}, callback)
end

function InfoModao.skillLvup(baseID, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("modao_lvup", {
		base_id = baseID
	}, callback)
end

function InfoModao.refill()
	InfoDungeon.debugSetModaoMP(InfoModao.getMpMax())

	currentModaoMp = InfoModao.getMpMax()

	notify.dispatch("modao_mana", currentModaoMp)
end

return InfoModao
