local FRAME_battle_lose = class("FRAME_battle_lose", UI_base)
local OPEN_TYPE = {
	SAFE = 1,
	MOON = 3,
	TP = 2
}
FRAME_battle_lose.OPEN_TYPE = OPEN_TYPE

function FRAME_battle_lose.open(onComplete)
	global.map:tweenViewZoom(1.2, 30)

	local ui = FRAME_battle_lose.new(onComplete)

	PopManager.open(ui, nil, , PopManager.ANIM_TYPE.JUMP, 100)
end

function FRAME_battle_lose:ctor(onComplete)
	local uiName = nil

	if InfoDungeon.getType() == InfoDungeon.TYPE.ABYSS or InfoDungeon.inDust() then
		local isTp = InfoBag.getItemNum(GameConfig.tp_item) > 0

		if isTp then
			uiName = "frame_battle_lose_tp"
			self.openType = OPEN_TYPE.TP
		else
			uiName = "frame_battle_lose_moon"
			self.openType = OPEN_TYPE.MOON
		end
	else
		uiName = "frame_battle_lose_safe"
		self.openType = OPEN_TYPE.SAFE
	end

	FRAME_battle_lose.super.ctor(self, uiName, UIManager.BIG_TYPE.POP)

	self.onComplete = onComplete
	self.ui_title = "frame_battle_lose_abyss"

	self:init()
end

function FRAME_battle_lose:init()
	self.noCloseByKey = true

	self:initUI()
	self:refreshMoon()
	ManagerInfo.onDataChange(self, "order", nil, function ()
		self:refreshMoon()
	end)

	if InfoDungeon.getType() == InfoDungeon.TYPE.ABYSS then
		InfoGuide.triggerFree(10)
	end
end

function FRAME_battle_lose:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local mask = self:getComponentByTag("mask")

	mask:toTouchable()
	mask:setOpacity(0)

	local moonCSV = CsvParser.getCsvData("rmb_member", GameConfig.moonID)

	local function onRetry()
		if self.onComplete then
			self.onComplete()
		end

		InfoDungeon.retry()
	end

	local retryBtn = self:getComponentByTag("bt_retry")

	retryBtn:toTouchable()
	retryBtn:addTap(onRetry)
	retryBtn:setTapGroup("button_click")

	if self.openType == OPEN_TYPE.SAFE then
		local str = Localization.getSrcText("这不会是你旅程的终点。\n即使失败了，重新再来就行。")
		str = string.gsub(str, "\\n", "\n")

		self:createLabelOnFlag("flag_desc", str, {
			wrap = true
		})

		local exitBtn = self:getComponentByTag("bt_exit")

		exitBtn:toTouchable()
		exitBtn:setTapGroup("button_click")
		exitBtn:addTap(function ()
			if self.onComplete then
				self.onComplete()
			end

			InfoDungeon.exit(0, function (rcvData)
				InfoDungeon.onLeave(rcvData)
			end)
		end)
	else
		local str = Localization.getSrcText("这不会是你旅程的终点。\n即使失败了，重新再来就行。")
		str = string.gsub(str, "\\n", "\n")

		self:createLabelOnFlag("flag_desc", str, {
			wrap = true
		})

		local function doExit(type)
			InfoDungeon.exit(type, function (rcvData)
				FRAME_dungeon_result.open(rcvData, FRAME_dungeon_result.OPEN_TYPE.EXIT)
				InfoBag.clearBagItemInfo()
			end)
		end

		local function onExitAbyss(type)
			if self.onComplete then
				self.onComplete()
			end

			InfoBag.saveBagItemInfo()

			if type == 0 then
				POP_notice.open(Localization.getSrcText("有损返回会损失背包内物品，是否返回？"), function ()
					doExit(type)
				end)
			else
				doExit(type)
			end
		end

		if self.openType == OPEN_TYPE.TP then
			local str = Localization.getSrcText([[
这不会是你旅程的终点。
即使战败，小浮石也可以最大限度地挽回你的损失。

它会将收获安全送回营地。]])
			str = string.gsub(str, "\\n", "\n")

			self:createLabelOnFlag("flag_desc", str, {
				wrap = true
			})

			local tpBG = self:getComponentByTag("tp_bg")

			tpBG:toTouchable()
			tpBG:setTapGroup("bg_click")
			tpBG:addTap(function ()
				FRAME_item_detail.open({
					base_id = GameConfig.tp_item,
					num = tpItemNum
				})
			end)
			self:createIconOnFlag("icon_tp", IconManager.getItemIcon(GameConfig.tp_item), nil, true)

			local tpItemNum = InfoBag.getItemNum(GameConfig.tp_item)
			local style = nil

			if tpItemNum == 0 then
				style = {
					color = Style.red
				}
			end

			self:createLabelOnFlag("flag_tp", tpItemNum, style)

			local exitBtn = self:getComponentByTag("bt_exit")

			exitBtn:toTouchable()
			exitBtn:setTapGroup("button_click")
			exitBtn:addTap(function ()
				onExitAbyss(1)
			end)
		elseif self.openType == OPEN_TYPE.MOON then
			local str = Localization.getSrcText([[
这不会是你旅程的终点。
即使战败，月之钥或小浮石也可以最大限度地挽回你的损失。

它们会将收获安全送回营地。]])
			str = string.gsub(str, "\\n", "\n")

			self:createLabelOnFlag("flag_desc", str, {
				wrap = true
			})

			local icon = self:createIconOnFlag("icon_moon", IconManager.getIcon("image/pic/item/icon/" .. moonCSV.pic .. ".png"), 100, false)
			local iconFlag = self:getFlagByTag("icon_moon")
			local iconSize = icon:getContentSize()

			icon:setScale(iconFlag.height / iconSize.height)

			local function openMoodcard()
				FRAME_mooncard.open(true)
			end

			local moon_bg = self:getComponentByTag("moon_bg")

			moon_bg:toTouchable()
			moon_bg:setTapGroup("bg_click")
			moon_bg:addTap(openMoodcard)

			local exitBtn = self:getComponentByTag("bt_exit")

			exitBtn:toTouchable()
			exitBtn:setTapGroup("button_click")
			exitBtn:addTap(function ()
				onExitAbyss(0)
			end)

			local bt_moon = self:getComponentByTag("bt_moon")
			local bt_moon_disable = self:getComponentByTag("bt_moon_disable")

			bt_moon_disable:toTouchable()
			bt_moon_disable:setTapGroup("button_click")
			bt_moon_disable:addTap(function ()
				if InfoOrder.inMoon() then
					Alert.open(Localization.getSrcText("今日次数已用完"))
				else
					POP_notice.open(Localization.getSrcText("购买月之钥吗?\n可立即安全返回营地"), openMoodcard)
				end
			end)
			bt_moon:toTouchable()
			bt_moon:setTapGroup("button_click")
			bt_moon:addTap(function ()
				onExitAbyss(3)
			end)
		end
	end
end

function FRAME_battle_lose:refreshMoon()
	if self.openType == OPEN_TYPE.MOON then
		local bt_moon = self:getComponentByTag("bt_moon")
		local bt_moon_disable = self:getComponentByTag("bt_moon_disable")
		local safeTimes = InfoOrder.checkMoonSafe()
		local style = nil

		if safeTimes == 0 then
			style = {
				color = Style.red
			}
		end

		self:createLabelOnFlag("flag_moon", safeTimes, style)

		if safeTimes > 0 then
			bt_moon:setVisible(true)
			bt_moon_disable:setVisible(false)
		else
			bt_moon_disable:setVisible(true)
			bt_moon:setVisible(false)
		end
	end
end

return FRAME_battle_lose
