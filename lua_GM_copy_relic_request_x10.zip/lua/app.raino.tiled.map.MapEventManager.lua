local MapEventManager = class("MapEventManager")

function MapEventManager.clear()
	MapEventManager.eventMapByTag = {}
	MapEventManager.eventMapByIndex = {}
	MapEventManager.eventMapByTile = {}
	MapEventManager.monsterSetIndex = 1
	MapEventManager.monsterSetMap = {}
	MapEventManager.monsterSetIndexMap = {}
	MapEventManager.monsterTrapMap = {}
	MapEventManager.monsterTileMap = {}
	MapEventManager.monsterEventGroup = {}
	MapEventManager.pressArray = {}
	MapEventManager.tileTriggerMap = {
		stand = {},
		enter = {},
		leave = {}
	}
	MapEventManager.tileTriggerActiveMap = {
		stand = {},
		enter = {},
		leave = {}
	}
	MapEventManager.tileLeaveTriggerMap = {}
	MapEventManager.tileTriggerListener = nil
	MapEventManager.tileClipMap = {}
	MapEventManager.tileAssetMap = {}
	MapEventManager.clipInstanceMap = {}
	MapEventManager.npcDisableMap = {}
end

MapEventManager.clear()

function MapEventManager.getDungeonTypes(anchorTag, anchorNum, type, dungeonData, quest_map_csv, random)
	local numArr = {}
	local absoluteTotalNum = 0
	local weightArr = {}
	local weightTypeArr = {}
	local typeArr = nil

	if type == InfoDungeon.TYPE.QUEST then
		typeArr = SheetUtil.getColumnList(quest_map_csv, {
			anchorTag .. "_id_",
			anchorTag .. "_num_"
		}, {
			"id",
			"num"
		})
	elseif type == InfoDungeon.TYPE.TASK then
		typeArr = SheetUtil.getColumnList(quest_map_csv, {
			anchorTag .. "_id_",
			anchorTag .. "_num_"
		}, {
			"id",
			"num"
		})
	elseif type == InfoDungeon.TYPE.STAGE then
		typeArr = SheetUtil.getColumnList(dungeonData, {
			anchorTag .. "_id_",
			anchorTag .. "_num_"
		}, {
			"id",
			"num"
		})
	elseif type == InfoDungeon.TYPE.ABYSS then
		typeArr = SheetUtil.getColumnList(dungeonData, {
			anchorTag .. "_id_",
			anchorTag .. "_num_"
		}, {
			"id",
			"num"
		})
	end

	if not typeArr then
		return {}
	end

	local probup_map = InfoDungeon.getProbup(4)

	for i, typeObj in ipairs(typeArr) do
		local numStr = typeObj.num

		if not empty(numStr) then
			if string.sub(numStr, 1, 1) == "#" then
				if absoluteTotalNum < anchorNum then
					local num = nil

					if probup_map[typeObj.id] then
						num = SheetUtil.getNumberUp(string.sub(numStr, 2), random, probup_map[typeObj.id])
					else
						num = SheetUtil.getNumber(string.sub(numStr, 2), random)
					end

					num = math.min(num, anchorNum - absoluteTotalNum)

					table.insert(numArr, {
						id = typeObj.id,
						num = num
					})

					absoluteTotalNum = absoluteTotalNum + num
				end
			else
				local num = SheetUtil.getNumber(numStr, random)

				if probup_map[typeObj.id] then
					num = num * (1 + probup_map[typeObj.id] / 100)
				end

				table.insert(weightArr, num)
				table.insert(weightTypeArr, typeObj.id)
			end
		else
			table.insert(numArr, {
				num = 0,
				id = typeObj.id
			})
		end
	end

	if absoluteTotalNum < anchorNum then
		local devidedArr = MathUtil.integerDivision(anchorNum - absoluteTotalNum, weightArr)

		for i, num in ipairs(devidedArr) do
			table.insert(numArr, {
				id = weightTypeArr[i],
				num = num
			})
		end
	end

	return numArr
end

function MapEventManager.getAnchorIdTemplete(eventData)
	local info = ConfParser.parse(eventData.info)
	local templeteData = CsvParser.getCsvData("abyss_event", info.id)

	if templeteData then
		local random = Random.new(eventData.seed)
		local power_arr = SheetUtil.getColumnListFull(templeteData, {
			"info_",
			"power_"
		}, {
			"info",
			"power"
		})
		local powerIndex = SheetUtil.getPowerRandomIndex(power_arr, random, "power")

		if empty(powerIndex) then
			powerIndex = 1
		end

		return templeteData.tag, templeteData["info_" .. powerIndex]
	else
		error("!!!!!! MapEventManager.getAnchorIdTemplete none")
	end
end

function MapEventManager.getAnchorTemplete(eventData, anchorID, anchorIndex)
	local templeteData = CsvParser.getCsvData("abyss_event", anchorID)

	return templeteData.tag, templeteData["info_" .. anchorIndex] .. "\r" .. eventData.info
end

function MapEventManager.findEvent(id, findFunc)
	for index, eventData in pairs(MapEventManager.eventMapByIndex) do
		local info = ConfParser.parse(eventData.info)

		if findFunc(eventData, info) then
			return eventData
		end
	end
end

local typeMap = {
	shrine = true,
	gather = true,
	monster = true,
	npc = true,
	go_next = true,
	["hero-get"] = true,
	chance = true
}
local map, max_depth = nil

function MapEventManager.makeMap(_map, mapObj, mapName, map_seed)
	map = _map
	max_depth = mapObj.maxDepth or 1
	local map_seed = InfoDungeon.getMapSeed()
	local linkMap = {}

	for tag, data in pairs(mapObj.eventLinkData) do
		for i = 1, 2 do
			local node = data.nodes[i]
			local otherNode = data.nodes[3 - i]

			if linkMap[node.x .. "_" .. node.y] == nil then
				linkMap[node.x .. "_" .. node.y] = {}
			end

			table.insert(linkMap[node.x .. "_" .. node.y], otherNode)
		end
	end

	local dungeon_csv, quest_map_csv = InfoDungeon.getDungeonCSV()

	if InfoDungeon.inGap() then
		dungeon_csv = CsvParser.getCsvData("stage", InfoDungeon.getGapID())
	end

	local event_anchor_map = {}
	local anchorReadyMap = {}
	local anchorReadyArr = {}

	for index, eventData in ipairs(mapObj.eventData) do
		if eventData.tag == "anchor" then
			local eventInfoObj = ConfParser.parse(eventData.info)
			local replaced = false

			if eventData.abyssEventID then
				local abyssEventCSV = CsvParser.getCsvData("abyss_event", eventData.abyssEventID)

				if abyssEventCSV.replace_group == eventInfoObj.group then
					eventData.tag = "anchor-id"
					eventData.info = "id=" .. eventData.abyssEventID
					replaced = true
				end
			end

			if not replaced then
				local anchorGroup = eventInfoObj.group

				if InfoDungeon.getCurrentType() == InfoDungeon.TYPE.ABYSS and anchorGroup == "battle1" then
					local isFirst = dungeon_csv and InfoDungeon.getAbyssMaxLayer() <= dungeon_csv.layer
					local preFirst = isFirst

					if isFirst and dungeon_csv then
						local isBossNeo = InfoDungeon.isBossNeoLayer(InfoDungeon.getEnterLayer())

						if isBossNeo and dungeon_csv.level <= InfoDungeon.getAbyssMaxLevel() then
							isFirst = false
						end
					end

					print("$$$ isFirst", preFirst, isFirst)

					if isFirst then
						anchorGroup = "battle0"
					end
				end

				if not empty(anchorGroup) then
					if not anchorReadyMap[anchorGroup] then
						anchorReadyMap[anchorGroup] = {}

						table.insert(anchorReadyArr, {
							tag = anchorGroup,
							arr = anchorReadyMap[anchorGroup]
						})
					end

					table.insert(anchorReadyMap[anchorGroup], {
						depth = eventData.depth or 1,
						index = index
					})
				end
			end
		end
	end

	local templete_cache = {}
	local random = Random.new(map_seed)

	for j, anchorObj in ipairs(anchorReadyArr) do
		local anchorTag = anchorObj.tag
		local anchorArr = anchorObj.arr
		local typeNumArr = MapEventManager.getDungeonTypes(anchorTag, #anchorArr, InfoDungeon.getCurrentType(), dungeon_csv, quest_map_csv, random)
		local templete_ready_arr = {}

		for i, typeObj in ipairs(typeNumArr) do
			local typeID = typeObj.id
			local typeNum = typeObj.num

			if typeID ~= 0 and typeNum > 0 then
				for _ = 1, typeNum do
					local templete_data = templete_cache[typeID]

					if not templete_data then
						templete_data = CsvParser.getCsvData("abyss_event", typeID)
						templete_cache[typeID] = templete_data
					end

					local power_arr = SheetUtil.getColumnListFull(templete_data, {
						"info_",
						"power_"
					}, {
						"info",
						"power"
					})
					local power_index = SheetUtil.getPowerRandomIndex(power_arr, random, "power")

					if empty(power_index) then
						power_index = 1
					end

					table.insert(templete_ready_arr, {
						id = templete_data.id,
						index = power_index,
						depth = templete_data["depth_" .. power_index]
					})
				end
			end
		end

		table.sort(templete_ready_arr, function (a, b)
			return b.depth < a.depth
		end)
		table.sort(anchorArr, function (a, b)
			return b.depth < a.depth
		end)

		local closed_map = {}

		for ii, templete_ready in ipairs(templete_ready_arr) do
			local templete_depth = templete_ready.depth * max_depth / 100
			local ready_arr = {}

			for jj, event_ready in ipairs(anchorArr) do
				if not closed_map[event_ready.index] and templete_depth <= event_ready.depth then
					table.insert(ready_arr, event_ready)
				end
			end

			if #ready_arr == 0 then
				for jj, event_ready in ipairs(anchorArr) do
					if not closed_map[event_ready.index] then
						table.insert(ready_arr, event_ready)
					end
				end
			end

			if #ready_arr > 0 then
				local event_ready = ready_arr[random:getInt(1, #ready_arr)]
				closed_map[event_ready.index] = true
				event_anchor_map[event_ready.index] = templete_ready
			else
				error("!!!!!! event anchor none")
			end
		end
	end

	print("= map event log =", mapName)

	for index, eventData in ipairs(mapObj.eventData) do
		local log1 = Log.startMeter("mapObj.eventData_" .. index)
		local eventInfo = InfoDungeon.getEventInfo(index)
		eventInfo.data = eventData

		if dungeon_csv then
			eventData.layer = dungeon_csv.layer
		end

		eventData.mapName = mapName
		eventData.index = index
		eventData.seed = eventInfo.seed
		eventData.fin = eventInfo.fin
		eventData.link = linkMap[eventData.ox .. "_" .. eventData.oy]

		if eventData.tag == "anchor-id" then
			local tag, info = MapEventManager.getAnchorIdTemplete(eventData)
			eventData.tag = tag
			eventData.info = info
		end

		if event_anchor_map[index] then
			local templete_ready = event_anchor_map[index]
			local tag, info = MapEventManager.getAnchorTemplete(eventData, templete_ready.id, templete_ready.index)
			eventData.tag = tag
			eventData.info = info
			eventData.abyss_event_id = templete_ready.id
		end

		eventData.info = StringUtil.replaceTag(eventData.info, function (tag)
			if tag == "level" then
				return InfoDungeon.getLevel()
			end
		end)
	end

	for index, eventData in ipairs(mapObj.eventData) do
		eventData.done = nil
		eventData.actived = nil
		eventData.disabled = nil
		eventData.id = index
		MapEventManager.eventMapByIndex[index] = eventData

		if not MapEventManager.eventMapByTag[eventData.tag] then
			MapEventManager.eventMapByTag[eventData.tag] = {}
		end

		table.insert(MapEventManager.eventMapByTag[eventData.tag], eventData)

		if not MapEventManager.eventMapByTile[eventData.ox .. "_" .. eventData.oy] then
			MapEventManager.eventMapByTile[eventData.ox .. "_" .. eventData.oy] = {}
		end

		table.insert(MapEventManager.eventMapByTile[eventData.ox .. "_" .. eventData.oy], eventData)
	end

	for index, eventData in ipairs(mapObj.eventData) do
		local links = linkMap[eventData.ox .. "_" .. eventData.oy]

		if links then
			eventData.link = {}

			for j = 1, #links do
				local link = links[j]
				local events = MapEventManager.eventMapByTile[link.x .. "_" .. link.y]

				if events then
					for m = 1, #events do
						table.insert(eventData.link, events[m])
					end
				else
					Log.warn("empty eventData.link", eventData.tag, link.x, link.y)
				end
			end
		end
	end

	MapEventManager.initEventData(mapObj.eventData)
end

function MapEventManager.initEventData(eventDataArr)
	MapEventManager.enter = {}
	local monsterEventArr = {}

	for index, eventData in ipairs(eventDataArr) do
		if eventData.tag == "monster" then
			table.insert(monsterEventArr, eventData.index)
		end
	end

	InfoDungeon.initActvMonster(monsterEventArr)

	for index, eventData in ipairs(eventDataArr) do
		eventData._conditionReady = MapEventManager.checkEventCondition(eventData)
		local triggerLinkArr = MapEventManager.findLinkBridge(eventData, {
			"link-target",
			"link-trigger"
		})
		local allTriggerFin = true

		if triggerLinkArr then
			for j, triggerLink in ipairs(triggerLinkArr) do
				if triggerLink.fin ~= 1 then
					allTriggerFin = false

					break
				end
			end
		end

		if allTriggerFin and eventData._conditionReady then
			MapEventManager.prepareEvent(eventData)
		end
	end
end

function MapEventManager.getEventByTile(x, y, tag)
	local events = MapEventManager.eventMapByTile[x .. "_" .. y]

	if events then
		for i, eventData in ipairs(events) do
			if eventData.tag == tag then
				return eventData
			end
		end
	end
end

function MapEventManager.getEventsByTile(x, y)
	local events = MapEventManager.eventMapByTile[x .. "_" .. y]

	return events
end

function MapEventManager.active(eventData)
	eventData._conditionReady = MapEventManager.checkEventCondition(eventData)

	if eventData._conditionReady then
		MapEventManager.prepareEvent(eventData)
	end
end

function MapEventManager.prepareEventHub(eventData)
	local links = MapEventManager.findLinkAll(eventData)
	local powerArr = {}

	for i, data in ipairs(links) do
		local info = ConfParser.parse(data.info)

		table.insert(powerArr, info.hub_power or 1)
	end

	local random = Random.new(eventData.seed)
	local index = SheetUtil.getPowerRandomIndex(powerArr, random)
	local trueEventData = links[index]

	if trueEventData then
		local info = ConfParser.parse(trueEventData.info)

		if info.hub_pos == 1 then
			trueEventData = clone(trueEventData)
			trueEventData.x = eventData.x
			trueEventData.y = eventData.y
			trueEventData.w = eventData.w
			trueEventData.h = eventData.h
			trueEventData.ox = eventData.ox
			trueEventData.oy = eventData.oy
		end

		MapEventManager.prepareEvent(trueEventData, nil, true)
	end
end

function MapEventManager.isNpcDisable(tile)
	if type(tile) == "string" then
		return MapEventManager.npcDisableMap[tile]
	else
		return MapEventManager.npcDisableMap[tile.tag]
	end
end

function MapEventManager.prepareEvent(eventData, isLinkTrigger, isHubTrigger)
	if eventData.actived then
		return
	end

	if not isHubTrigger and MapEventManager.findLinkOne(eventData, "hub") then
		return
	end

	eventData.actived = true

	if eventData.tag == "hub" then
		if eventData.fin ~= 1 then
			MapEventManager.prepareEventHub(eventData)
		end
	elseif eventData.tag == "enter" then
		table.insert(MapEventManager.enter, eventData)
	elseif eventData.tag == "enter_tag" then
		table.insert(MapEventManager.enter, eventData)
	elseif eventData.tag == "monster" then
		if eventData.fin ~= 1 then
			MapEventManager.makeMonsterSet(eventData, MapEventManager.monsterSetIndex)

			MapEventManager.monsterSetIndex = MapEventManager.monsterSetIndex + 1
			local info = ConfParser.parse(eventData.info)

			if info.is_ambush == 1 then
				for i = 1, eventData.w do
					for j = 1, eventData.h do
						local tile = map:getTile(eventData.x + i - 1, eventData.y + j - 1)

						if tile then
							MapEventManager.tileTriggerMap.enter[tile:getTag()] = eventData
						end
					end
				end
			end
		end
	elseif eventData.tag == "light" then
		local light = 1
		local lightRadius = 0
		local info = ConfParser.parse(eventData.info)
		light = info.light
		lightRadius = info.radius
		local lightRGB = nil

		if not empty(info.rgb) then
			lightRGB = ColorUtil.getC3B(info.rgb)
		end

		local lightID = "light_" .. eventData.x .. "_" .. eventData.y
		local mapX, mapY = map:tileToMap(eventData.x, eventData.y)

		if lightRGB then
			map:addColorMask(lightID, mapX, mapY, lightRGB, lightRadius, light)
		else
			map:addColorMask(lightID, mapX, mapY, cc.c3b(255, 255, 255), lightRadius, light)
		end

		local maxRange = math.ceil(lightRadius)

		for i = eventData.x - maxRange, eventData.x + eventData.w + maxRange do
			for j = eventData.y - maxRange, eventData.y + eventData.h + maxRange do
				local tile = map:getTile(i, j)

				if tile then
					if eventData.x <= i and i < eventData.x + eventData.w and eventData.y <= j and j < eventData.y + eventData.h then
						tile:addClipLight(lightID, light, lightRGB)
					else
						local range = math.sqrt(math.pow(i - (eventData.x + (eventData.w - 1) / 2), 2) + math.pow(j - (eventData.y + (eventData.h - 1) / 2), 2))

						if eventData.w > 1 or eventData.h > 1 then
							range = range - math.sqrt(math.pow((eventData.w - 1) / 2, 2) + math.pow((eventData.h - 1) / 2, 2))
						end

						local lightValue = math.max(0, light * math.pow(math.max(0, 1 - range / lightRadius), 0.7))

						tile:addClipLight(lightID, lightValue, lightRGB)
					end

					tile:refreshLightSum()
				end
			end
		end
	else
		if eventData.tag == "dynamic-light" then
			local info = ConfParser.parse(eventData.info)
			local paramArray = string.split(eventData.param, ",")
			local lightID = "dynamic-light_" .. eventData.x .. "_" .. eventData.y
			local dynamicLightObj = {}
			local minLight, maxLight = StringUtil.getMinMax(info.light)
			local minRadius, maxRadius = StringUtil.getMinMax(info.radius)
			local time = tonumber(info.time) / (math.pi * 2)
			local starttime = info.starttime or 0
			local chaos = tonumber(info.chaos)

			local function clearDynamicLight()
				if dynamicLightObj.maxRange then
					local maxRange = dynamicLightObj.maxRange

					for i = eventData.x - maxRange, eventData.x + eventData.w + maxRange do
						for j = eventData.y - maxRange, eventData.y + eventData.h + maxRange do
							local tile = map:getTile(i, j)

							if tile then
								tile:removeClipLight(lightID)
							end
						end
					end
				end
			end

			local function refreshDynamicLight(light, lightRadius, _lightRGB)
				local maxRange = math.ceil(lightRadius)

				if light ~= dynamicLightObj.light or lightRadius ~= dynamicLightObj.lightRadius then
					if dynamicLightObj.maxRange ~= maxRange then
						clearDynamicLight()
					end

					dynamicLightObj.light = light
					dynamicLightObj.lightRadius = lightRadius
					dynamicLightObj.maxRange = maxRange

					for i = eventData.x - maxRange, eventData.x + eventData.w + maxRange do
						for j = eventData.y - maxRange, eventData.y + eventData.h + maxRange do
							local tile = map:getTile(i, j)

							if tile then
								if eventData.x <= i and i < eventData.x + eventData.w and eventData.y <= j and j < eventData.y + eventData.h then
									tile:addClipLight(lightID, light, _lightRGB)
								else
									local range = math.sqrt(math.pow(i - (eventData.x + (eventData.w - 1) / 2), 2) + math.pow(j - (eventData.y + (eventData.h - 1) / 2), 2))

									if eventData.w > 1 or eventData.h > 1 then
										range = range - math.sqrt(math.pow((eventData.w - 1) / 2, 2) + math.pow((eventData.h - 1) / 2, 2))
									end

									local lightValue = math.max(0, light * math.pow(math.max(0, 1 - range / lightRadius), 0.7))

									tile:addClipLight(lightID, lightValue, _lightRGB)
								end
							end
						end
					end
				end
			end

			local dynamicLightCount = MapFrameManager.getFrame() % time + starttime
			local lightRGB = nil

			if not empty(info.rgb) then
				lightRGB = ColorUtil.getC3B(info.rgb)
			end

			local lightMask = nil
			local mapX, mapY = map:tileToMap(eventData.x, eventData.y)

			if lightRGB then
				lightMask = map:addColorMask(lightID, mapX, mapY, lightRGB, minRadius, (minLight + maxLight) / 2)
			else
				lightMask = map:addColorMask(lightID, mapX, mapY, cc.c3b(255, 255, 255), minRadius, (minLight + maxLight) / 2)
			end

			local function dynamicLightLoop(_, frame, passed, sharp)
				local light = minLight + (maxLight - minLight) * (math.cos(dynamicLightCount / time) + 1) / 2
				local lightRadius = minRadius + (maxRadius - minRadius) * (math.cos(dynamicLightCount / time) + 1) / 2

				refreshDynamicLight(light, lightRadius, lightRGB)

				if chaos == 0 then
					dynamicLightCount = dynamicLightCount + passed
				else
					dynamicLightCount = dynamicLightCount + passed * (1 - chaos + math.random() * chaos * 2)
				end

				lightMask:setScale(lightRadius)
			end

			MapFrameManager.startLoop(MapEventManager, dynamicLightLoop)

			return
		end

		if eventData.tag == "teleport" or eventData.tag == "exit" or eventData.tag == "leave" or eventData.tag == "go_map" or eventData.tag == "go_next" or eventData.tag == "leave_tag" then
			for i = 1, eventData.w do
				for j = 1, eventData.h do
					local tile = map:getTile(eventData.x + i - 1, eventData.y + j - 1)

					if tile then
						MapEventManager.tileTriggerMap.stand[tile:getTag()] = eventData

						if eventData.tag == "teleport" then
							local info = ConfParser.parse(eventData.info)

							if info.mode ~= 2 then
								MapEventManager.addTileAsset(tile, "event_teleport")
							end
						else
							MapEventManager.addTileAsset(tile, "event_exit")
						end
					end
				end
			end

			if eventData.tag == "go_next" and map.mapType == Map.TYPE.SINGLE and InfoGuide.getFreeRecord(5) == 0 then
				local mapX, mapY = map:tileToMap(eventData.x, eventData.y)

				InfoGuide.guideFree(5, {
					x = mapX,
					y = mapY
				}, nil, map, 9)
			end
		elseif eventData.tag == "inquire-dialog" or eventData.tag == "inquire-aside" or eventData.tag == "fishing_ready" then
			for i = 1, eventData.w do
				for j = 1, eventData.h do
					local tile = map:getTile(eventData.x + i - 1, eventData.y + j - 1)

					if tile then
						MapEventManager.tileTriggerMap.enter[tile:getTag()] = eventData
						MapEventManager.tileTriggerMap.leave[tile:getTag()] = eventData
					end
				end
			end
		elseif eventData.tag == "skill_test_start" or eventData.tag == "skill_test_end" then
			for i = 1, eventData.w do
				for j = 1, eventData.h do
					local tile = map:getTile(eventData.x + i - 1, eventData.y + j - 1)

					if tile then
						MapEventManager.tileTriggerMap.leave[tile:getTag()] = eventData
					end
				end
			end
		elseif eventData.tag == "effect" then
			for i = 1, eventData.w do
				for j = 1, eventData.h do
					local tile = map:getTile(eventData.x + i - 1, eventData.y + j - 1)

					if tile then
						MapEventManager.addTileClip(eventData)
					end
				end
			end
		elseif eventData.tag == "npc" then
			MapEventManager.addTileClip(eventData, isLinkTrigger)

			local info = ConfParser.parse(eventData.info)
			local tile = map:getTile(eventData.x, eventData.y)

			if info.id == 10032 then
				map:setEventTopType(tile.tag, Rantile.MAP_TYPE.ASAKA_MCT, eventData.index)
			elseif info.id == 10105 then
				map:setEventTopType(tile.tag, Rantile.MAP_TYPE.GATE, eventData.index)
			elseif info.id == 10033 then
				map:setEventTopType(tile.tag, Rantile.MAP_TYPE.DUST_MCT, eventData.index)
			elseif info.id == 10405 then
				map:setEventTopType(tile.tag, Rantile.MAP_TYPE.HOME, eventData.index)
			elseif info.id == 10034 then
				map:setEventTopType(tile.tag, Rantile.MAP_TYPE.SHADOW_MCT, eventData.index)
			end
		elseif eventData.tag == "actv_npc" then
			local info = ConfParser.parse(eventData.info)
			local npcArr = InfoFestival.getNpsListByPos(info.pos)

			dump(npcArr, "$$$ getNpsListByPos")

			for index, npcID in ipairs(npcArr) do
				local _eventData = ObjUtil.clone(eventData)
				_eventData.tag = "npc"
				_eventData.info = _eventData.info .. "\n" .. "id=" .. npcID

				MapEventManager.addTileClip(_eventData, isLinkTrigger)
			end
		elseif eventData.tag == "npc_disable" then
			for i = 1, eventData.w do
				for j = 1, eventData.h do
					local tile = map:getTile(eventData.x + i - 1, eventData.y + j - 1)

					if tile then
						MapEventManager.npcDisableMap[tile.tag] = true
					end
				end
			end
		elseif eventData.tag == "door" then
			MapEventManager.addTileClip(eventData, isLinkTrigger)
		elseif eventData.tag == "fishing_target" then
			local fishingEvent = MapEventManager.findLinkOne(eventData, "fishing")

			if InfoFishing.isAvailable(fishingEvent) then
				MapEventManager.addTileClip(eventData, isLinkTrigger)
			end
		elseif eventData.tag == "pet" or eventData.tag == "gather" or eventData.tag == "shrine" or eventData.tag == "chance" or eventData.tag == "hero-get" or eventData.tag == "mooncard_chest" then
			local tile = map:getTile(eventData.x, eventData.y)

			MapEventManager.addTileClip(eventData, isLinkTrigger)

			if eventData.tag == "chance" then
				local info = ConfParser.parse(eventData.info)
				local chanceID = nil

				if info.id then
					chanceID = info.id
				else
					local random = Random.new(eventData.seed)
					local drop_rare = 0
					chanceID = DropManager.dropLibChance(info.drop_id, InfoDungeon.getLevel(), drop_rare, random)
				end

				local chanceCSV = CsvParser.getCsvData("chance", chanceID)

				if chanceCSV.type == 1 then
					map:setEventTopType(tile.tag, Rantile.MAP_TYPE.EQUIP_SAVE, eventData.index)
				elseif chanceCSV.type == 6 then
					if empty(chanceCSV.value1) then
						map:setEventTopType(tile.tag, Rantile.MAP_TYPE.ENEGY, eventData.index)
					else
						map:setEventTopType(tile.tag, Rantile.MAP_TYPE.LIFE, eventData.index)
					end
				elseif chanceCSV.type == 7 then
					map:setEventTopType(tile.tag, Rantile.MAP_TYPE.MINE, eventData.index)
				elseif chanceCSV.type == 10 then
					map:setEventTopType(tile.tag, Rantile.MAP_TYPE.EQUIP_SHOP, eventData.index)
				elseif chanceCSV.type == 11 then
					map:setEventTopType(tile.tag, Rantile.MAP_TYPE.GLADIATOR, eventData.index)
				elseif chanceCSV.type == 13 then
					map:setEventTopType(tile.tag, Rantile.MAP_TYPE.CHEST, eventData.index)
				elseif chanceCSV.type == 14 then
					map:setEventTopType(tile.tag, Rantile.MAP_TYPE.CHEST, eventData.index)
				elseif chanceCSV.type == 8 then
					map:setEventTopType(tile.tag, Rantile.MAP_TYPE.EQUIP_EX, eventData.index)
				elseif chanceCSV.type == 2 then
					map:setEventTopType(tile.tag, Rantile.MAP_TYPE.DELIVER, eventData.index)
				elseif chanceCSV.type == 17 then
					map:setEventTopType(tile.tag, Rantile.MAP_TYPE.RUNE, eventData.index)
				end
			elseif eventData.tag == "shrine" then
				map:setEventTopType(tile.tag, Rantile.MAP_TYPE.SHRINE, eventData.index)
			elseif eventData.tag == "gather" then
				local info = ConfParser.parse(eventData.info)
				local gatherID = nil

				if info.id then
					gatherID = info.id
				else
					local random = Random.new(eventData.seed)
					local drop_rare = 0
					gatherID = DropManager.dropLibGather(info.drop_id, InfoDungeon.getLevel(), drop_rare, random)
				end

				local gatherCSV = CsvParser.getCsvData("gather", gatherID)

				if gatherCSV.class == 1 then
					map:setEventTopType(tile.tag, Rantile.MAP_TYPE.CHEST, eventData.index)
				end
			end
		elseif eventData.tag == "eventset" then
			local tile = map:getTile(eventData.x, eventData.y)

			MapEventManager.addTileClip(eventData, isLinkTrigger)
		elseif eventData.tag == "press" then
			table.insert(MapEventManager.pressArray, eventData)
		elseif eventData.tag == "walk" then
			local info = ConfParser.parse(eventData.info)

			for i = 1, eventData.w do
				for j = 1, eventData.h do
					local tile = map:getTile(eventData.x + i - 1, eventData.y + j - 1)

					if tile then
						tile:setForceWalk("eventData", tonumber(info.level))
					end
				end
			end
		elseif eventData.tag == "drama" then
			for i = 1, eventData.w do
				for j = 1, eventData.h do
					local tile = map:getTile(eventData.x + i - 1, eventData.y + j - 1)

					if tile then
						MapEventManager.tileTriggerMap.enter[tile:getTag()] = eventData
					end
				end
			end
		elseif eventData.tag == "drama-resume" then
			for i = 1, eventData.w do
				for j = 1, eventData.h do
					local tile = map:getTile(eventData.x + i - 1, eventData.y + j - 1)

					if tile then
						MapEventManager.tileTriggerMap.enter[tile:getTag()] = eventData
					end
				end
			end
		elseif eventData.tag == "particle" then
			local info = ConfParser.parse(eventData.info)

			for i = 1, eventData.w do
				for j = 1, eventData.h do
					local tile = map:getTile(eventData.x + i - 1, eventData.y + j - 1)

					if tile then
						MapEffect.addParticle(tile, info)
					end
				end
			end
		elseif eventData.tag == "spine" then
			local info = ConfParser.parse(eventData.info)

			for i = 1, eventData.w do
				for j = 1, eventData.h do
					local tile = map:getTile(eventData.x + i - 1, eventData.y + j - 1)

					if tile then
						MapEffect.addSpine(tile, info)
					end
				end
			end
		elseif eventData.tag == "focus" then
			local mapX, mapY = map:tileToMap(eventData.x, eventData.y)
			mapX = mapX + (eventData.w - 1) * map.ptPerTile / 2
			mapY = mapY + (eventData.h - 1) * map.ptPerTile / 2

			map:lockScroll(mapX, mapY)
		elseif eventData.tag == "quest-accept" then
			for i = 1, eventData.w do
				for j = 1, eventData.h do
					local tile = map:getTile(eventData.x + i - 1, eventData.y + j - 1)

					if tile then
						MapEventManager.tileTriggerMap.enter[tile:getTag()] = eventData
					end
				end
			end
		elseif eventData.tag == "pet-whisper" then
			for i = 1, eventData.w do
				for j = 1, eventData.h do
					local tile = map:getTile(eventData.x + i - 1, eventData.y + j - 1)

					if tile then
						MapEventManager.tileTriggerMap.enter[tile:getTag()] = eventData
					end
				end
			end
		elseif eventData.tag == "mission-trigger" then
			for i = 1, eventData.w do
				for j = 1, eventData.h do
					local tile = map:getTile(eventData.x + i - 1, eventData.y + j - 1)

					if tile then
						MapEventManager.tileTriggerMap.enter[tile:getTag()] = eventData
					end
				end
			end
		end
	end
end

function MapEventManager.addTileAsset(tile, assetName)
	MapEventManager.tileAssetMap[tile:getTag()] = assetName

	tile:setHasEvent(true)

	if tile:getVisible() then
		MapEventManager.tileCheckAsset(tile)
	end
end

function MapEventManager.addTileClip(eventData, isLinkTrigger)
	local centerX = eventData.x + math.floor((eventData.w - 1) / 2)
	local centerY = eventData.y + math.floor((eventData.h - 1) / 2)
	local centerTag = centerX .. "_" .. centerY

	if not MapEventManager.tileClipMap[centerTag] then
		MapEventManager.tileClipMap[centerTag] = {}
	end

	table.insert(MapEventManager.tileClipMap[centerTag], eventData)

	local centerTile = map:getTile(centerX, centerY)

	if centerTile then
		centerTile:setHasEvent(true)

		if centerTile:getVisible() then
			MapEventManager.tileCheckClip(centerTile, isLinkTrigger)
		end
	end
end

function MapEventManager.checkTileHasTrigger(tile, specializedType)
	local eventTypes = {
		"enter",
		"leave",
		"stand"
	}

	for i, eventType in ipairs(eventTypes) do
		if (specializedType == nil or specializedType == eventType) and MapEventManager.tileTriggerMap[eventType][tile.tag] then
			return true
		end
	end

	return false
end

function MapEventManager.tileTriggerRetile(player, preTile, tile)
	local eventTypes = {
		"enter",
		"leave",
		"stand"
	}
	local inEventDatas = {}
	local outEventDatas = {}

	for i = 1, #eventTypes do
		local eventType = eventTypes[i]
		local preEventDataID = 0
		local currEventDataID = 0

		if preTile then
			local preEventData = MapEventManager.tileTriggerMap[eventType][preTile:getTag()]

			if preEventData then
				preEventDataID = preEventData.id
			end
		end

		if tile then
			local currEventData = MapEventManager.tileTriggerMap[eventType][tile:getTag()]

			if currEventData then
				currEventDataID = currEventData.id
			end
		end

		if preEventDataID ~= currEventDataID then
			if currEventDataID ~= 0 and eventType ~= "stand" and not MapEventManager.tileTriggerActiveMap[eventType][currEventDataID] then
				MapEventManager.tileTriggerActiveMap[eventType][currEventDataID] = true

				if eventType == "enter" then
					table.insert(inEventDatas, currEventDataID)
				end
			end

			if preEventDataID ~= 0 and MapEventManager.tileTriggerActiveMap[eventType][preEventDataID] then
				MapEventManager.tileTriggerActiveMap[eventType][preEventDataID] = nil

				if eventType == "leave" then
					table.insert(outEventDatas, preEventDataID)
				end
			end
		end
	end

	for i = 1, #inEventDatas do
		local eventData = MapEventManager.eventMapByIndex[inEventDatas[i]]

		if MapEventManager.tileTriggerListener then
			MapEventManager.tileTriggerListener(eventData, "enter", tile)
		end
	end

	for i = 1, #outEventDatas do
		local eventData = MapEventManager.eventMapByIndex[outEventDatas[i]]

		if MapEventManager.tileTriggerListener then
			MapEventManager.tileTriggerListener(eventData, "leave", tile)
		end
	end
end

function MapEventManager.tileTriggerStop(tile)
	local eventData = MapEventManager.tileTriggerMap.stand[tile:getTag()]

	if eventData then
		MapEventManager.tileTriggerActiveMap.stand[eventData.id] = true

		if MapEventManager.tileTriggerListener then
			MapEventManager.tileTriggerListener(eventData, "stand", tile)
		end
	end
end

function MapEventManager.getTileTrigger(x, y, tag)
	local tile = map:getTile(x, y)

	if tile then
		local tileTag = tile.tag

		for _, triggers in pairs(MapEventManager.tileTriggerMap) do
			for _tileTag, eventData in pairs(triggers) do
				if _tileTag == tileTag and eventData.name == tag then
					return eventData
				end
			end
		end
	end
end

function MapEventManager.setTileTriggerListener(func)
	MapEventManager.tileTriggerListener = func
end

function MapEventManager.tileCheckAsset(tile)
	local assetName = MapEventManager.tileAssetMap[tile:getTag()]

	if assetName then
		tile:openAsset(assetName)
	end
end

function MapEventManager.tileRemoveAsset(tile)
	local assetName = MapEventManager.tileAssetMap[tile:getTag()]

	if assetName then
		tile:closeAsset(assetName)
	end
end

function MapEventManager.getTileClip(tag, info, seed, eventData)
	local clip = nil

	if tag == "effect" then
		clip = Effect.new()

		clip:load(info.id)
	elseif tag == "fishing_target" then
		local fishEvent = MapEventManager.findLinkOne(eventData, "fishing")
		local info = ConfParser.parse(fishEvent.info)
		local pondCSV = CsvParser.getCsvData("fishing_pond", info.id)
		local model = pondCSV.point_effect
		clip = Effect.new()

		clip:load(model)
		InfoFishing.setFishingEffect(eventData.index, clip)

		if InfoDungeon.getCurrentType() == InfoDungeon.TYPE.STAGE and InfoGuide.getFreeRecord(31) == 0 then
			InfoGuide.guideFree(31, clip, nil, clip, 16)
		end
	elseif tag == "npc" or tag == "pet" or tag == "gather" or tag == "shrine" or tag == "chance" or tag == "door" or tag == "hero-get" or tag == "mooncard_chest" then
		clip = Npc.new()

		if tag == "npc" then
			clip:setID(info.id, eventData)
		elseif tag == "pet" then
			clip:setPetID(info.id)
		elseif tag == "gather" then
			local gatherID = nil

			if info.id then
				gatherID = info.id
			else
				local random = Random.new(seed)
				local max_quality = 1
				local drop_rare = 0
				local mirrorData = InfoMirror.getCurrent(3)

				if mirrorData then
					if not empty(mirrorData.value2) then
						max_quality = mirrorData.value2
					end

					if not empty(mirrorData.value1) then
						drop_rare = mirrorData.value1
					end
				end

				local probup_map = InfoDungeon.getProbup(5)
				gatherID = DropManager.dropLibGather(info.drop_id, InfoDungeon.getLevel(), drop_rare, random, max_quality, probup_map)
			end

			clip:setGatherID(gatherID, eventData)
		elseif tag == "mooncard_chest" then
			clip:setMooncardChest(eventData)
		elseif tag == "shrine" then
			local shrineID = nil

			if info.id then
				shrineID = info.id
			else
				local random = Random.new(seed)
				local max_quality = 1
				local drop_rare = 0
				local dropLibData = CsvParser.getCsvData("drop_lib", info.drop_id)
				local mirrorType = nil

				if dropLibData.subtype == 1 then
					mirrorType = 2
				else
					mirrorType = 4
				end

				local mirrorData = InfoMirror.getCurrent(mirrorType)

				if mirrorData then
					if not empty(mirrorData.value2) then
						max_quality = mirrorData.value2
					end

					if not empty(mirrorData.value1) then
						drop_rare = mirrorData.value1
					end
				end

				shrineID = DropManager.dropLibShrine(info.drop_id, InfoDungeon.getLevel(), drop_rare, random, max_quality)
			end

			clip:setShrineID(shrineID, eventData)
		elseif tag == "chance" then
			local chanceID = nil

			if info.id then
				chanceID = info.id
			else
				local random = Random.new(seed)
				local drop_rare = 0
				chanceID = DropManager.dropLibChance(info.drop_id, InfoDungeon.getLevel(), drop_rare, random)
			end

			clip:setChanceID(chanceID, eventData)
		elseif tag == "door" then
			clip:setDoorID(info.id, eventData)
		elseif tag == "hero-get" then
			clip:setHeroTempleteID(info.id, eventData)
		end

		if eventData.w > 1 or eventData.h > 1 then
			local tileMap = {}

			for i = eventData.x, eventData.x + eventData.w - 1 do
				for j = eventData.y, eventData.y + eventData.h - 1 do
					local tile = map:getTile(i, j)

					if tile then
						tileMap[tile.tag] = true
					end
				end
			end

			clip:setPatrolArea(tileMap)
		end

		if info.freeAngle and info.freeAngle ~= "" then
			clip:setFreeAngle(tonumber(info.freeAngle))
		elseif info.fixedAngle and info.fixedAngle ~= "" then
			clip:setFixedAngle(tonumber(info.fixedAngle))
		end

		if info.fixedLight and info.fixedLight ~= "" then
			clip.fixedLight = info.fixedLight

			clip:refreshVisible(true)
		end

		if isLinkTrigger and clip and clip.data then
			local triggerEffect = clip.data.trigger_effect

			if not empty(triggerEffect) then
				local effectGen = clip:getEffectGen()

				if effectGen then
					effectGen:castEffect(triggerEffect, clip)
				end
			end
		end

		if tag == "pet" then
			clip.eventInfo = info
		end
	end

	if info.no_fill and info.no_fill == 1 then
		clip.noFillTile = true
	end

	if info.fixedLight and info.fixedLight ~= "" then
		clip.fixedLight = info.fixedLight

		clip:refreshVisible(true)
	end

	if not empty(info.height) then
		local z = math.floor(info.height / global.map.config.scale.unit)
		clip.zorderOffset = z
		clip.zOffset = z
		clip.highStand = true

		clip:setBmpY()

		if clip.setAvatarZ then
			clip:setAvatarZ()
		end

		if clip.shadow then
			clip:refreshShadow(true)
			clip:draw()
		end
	end

	MapEventManager.initClipWithInfo(clip, info)

	return clip
end

function MapEventManager.getEventsetPos(eventData, num)
	local seed = eventData.seed
	local random = Random.new(seed)
	local cx, cy = MapEventManager.getEventCenter(eventData)
	local centerTile = map:mapToTile(cx, cy)
	local posArr = {}

	if num == 1 then
		for i = 1, num do
			table.insert(posArr, {
				x = x,
				y = y
			})
		end
	elseif num == 2 then
		local angle = random:getInt(0, 1) * math.pi / 2
		local distance = map.ptPerTile

		for i = 1, 2 do
			local a = angle + math.pi * i
			local x = math.cos(a) * distance + cx
			local y = math.sin(a) * distance + cy

			table.insert(posArr, {
				x = x,
				y = y
			})
		end
	elseif num == 4 then
		local offsetArr = {
			{
				-1,
				-1
			},
			{
				-1,
				1
			},
			{
				1,
				-1
			},
			{
				1,
				1
			}
		}

		for i, v in ipairs(offsetArr) do
			local tile = map:getTile(centerTile.x + v[1], centerTile.y + v[2])
			local x, y = map:tileToMap(tile)

			table.insert(posArr, {
				x = x,
				y = y
			})
		end
	else
		local angle = random:getInt(0, 3) * math.pi / 2
		local distance = map.ptPerTile

		for i = 1, num do
			local a = angle + math.pi * 2 / num * i
			local x = math.cos(a) * distance + cx
			local y = math.sin(a) * distance + cy

			table.insert(posArr, {
				x = x,
				y = y
			})
		end
	end

	posArr = random:order(posArr)

	return posArr
end

function MapEventManager.getEventsetID(info, random)
	local eventsetID = nil

	if info.id then
		eventsetID = info.id
	else
		local drop_rare = 0
		eventsetID = DropManager.dropLibEventset(info.drop_id, InfoDungeon.getLevel(), drop_rare, random)
	end

	return eventsetID
end

function MapEventManager.tileCheckClip(tile, isLinkTrigger)
	local eventDatas = MapEventManager.tileClipMap[tile:getTag()]

	if eventDatas then
		for _, eventData in ipairs(eventDatas) do
			local info = ConfParser.parse(eventData.info)

			if eventData.tag == "eventset" then
				local random = Random.new(eventData.seed)
				local eventsetCSV = CsvParser.getCsvData("eventset", MapEventManager.getEventsetID(info, random))
				local events = SheetUtil.getColumnList(eventsetCSV, {
					"tag_",
					"info_",
					"button_name_"
				}, {
					"tag",
					"info",
					"button_name"
				})
				local posArr = MapEventManager.getEventsetPos(eventData, #events)
				local eventsetArr = {}

				for i, v in ipairs(events) do
					local clip = MapEventManager.getTileClip(v.tag, ConfParser.parse(v.info), random:getInt(1, 65535), eventData)
					local pos = posArr[i]
					local x = pos.x
					local y = pos.y
					local xoffset = tonumber(info.xoffset) or 0
					local yoffset = tonumber(info.yoffset) or 0

					if info.alwaysVisible and info.alwaysVisible ~= "" then
						clip.alwaysVisible = info.alwaysVisible == 1
					end

					clip:display(map, x + xoffset, y + yoffset)

					if not MapEventManager.clipInstanceMap[tile.tag] then
						MapEventManager.clipInstanceMap[tile.tag] = {}
					end

					table.insert(MapEventManager.clipInstanceMap[tile.tag], clip)
					table.insert(eventsetArr, clip)

					clip.eventsetArr = eventsetArr
					clip.eventsetIndex = i
					clip.eventsetButtonName = v.button_name

					clip:refreshOpened(false)
				end

				local x, y = MapEventManager.getEventCenter(eventData)
				local effect = Effect.new()
				effect.alwaysVisible = true

				effect:load(MiscConfig.eventset_model)
				effect:display(map, x, y)

				if not MapEventManager.clipInstanceMap[tile.tag] then
					MapEventManager.clipInstanceMap[tile.tag] = {}
				end

				table.insert(MapEventManager.clipInstanceMap[tile.tag], effect)
			else
				local clip = MapEventManager.getTileClip(eventData.tag, info, eventData.seed, eventData)
				local x, y = map:tileToMap(eventData.x, eventData.y)

				if eventData.tag == "pet" or eventData.tag == "gather" or eventData.tag == "shrine" or eventData.tag == "chance" or eventData.tag == "hero-get" or eventData.tag == "fishing_target" or eventData.tag == "mooncard_chest" then
					x, y = MapEventManager.getEventCenter(eventData)
				elseif eventData.w > 1 or eventData.h > 1 then
					local tiles = {}

					for i = eventData.x, eventData.x + eventData.w - 1 do
						for j = eventData.y, eventData.y + eventData.h - 1 do
							local tile = map:getTile(i, j)

							if tile and tile:getWalkable(0, clip) then
								table.insert(tiles, tile)
							end
						end
					end

					if #tiles > 0 then
						local tile = tiles[math.random(1, #tiles)]
						x, y = map:tileToMap(tile)
					end
				end

				local xoffset = tonumber(info.xoffset) or 0
				local yoffset = tonumber(info.yoffset) or 0

				if info.alwaysVisible and info.alwaysVisible ~= "" then
					clip.alwaysVisible = info.alwaysVisible == 1
				end

				clip:display(map, x + xoffset, y + yoffset)

				if not MapEventManager.clipInstanceMap[tile.tag] then
					MapEventManager.clipInstanceMap[tile.tag] = {}
				end

				table.insert(MapEventManager.clipInstanceMap[tile.tag], clip)

				local info = ConfParser.parse(eventData.info)

				if not empty(info.drama) and not DramaManager.opening then
					DramaManager.start(info.drama)
				end
			end
		end

		return true
	end
end

function MapEventManager.initClipWithInfo(clip, info)
	if info.effect then
		local effectGen = clip:getEffectGen()

		if effectGen then
			effectGen:castEffect(info.effect)
		end
	end

	if info.style then
		clip:setStyle(info.style)
	end
end

function MapEventManager.onDrawTile(tile)
	MapEventManager.tileCheckClip(tile)
	MapEventManager.tileCheckAsset(tile)
	MapEventManager.onDrawTileEvent(tile)
end

function MapEventManager.onEraseTile(tile)
	if MapEventManager.clipInstanceMap[tile:getTag()] then
		for _, clip in ipairs(MapEventManager.clipInstanceMap[tile:getTag()]) do
			clip:removeSelf()
		end

		MapEventManager.clipInstanceMap[tile:getTag()] = nil
	end

	MapEventManager.tileRemoveAsset(tile)
	MapEventManager.onRemoveTileEvent(tile)
end

function MapEventManager.makeMonsterSet(eventData, index, forceCheck, customSetData)
	eventData.monsterGroupID = index
	local setData = customSetData or ConfParser.parse(eventData.info)
	setData.time = setData.time or 0
	setData.power = setData.power or 0
	local pack = {
		activeCount = 0,
		visibleCount = 0,
		activeCD = 0,
		active = 0,
		setData = setData,
		eventData = eventData,
		index = index
	}
	MapEventManager.monsterSetIndexMap[index] = pack
	local visibleTile, anyTile = nil

	for i = 0, eventData.w - 1 do
		for j = 0, eventData.h - 1 do
			local x = eventData.x + i
			local y = eventData.y + j
			local tile = map:getTile(x, y)

			if tile then
				if MapEventManager.monsterSetMap[tile:getTag()] == nil then
					MapEventManager.monsterSetMap[tile:getTag()] = {}
				end

				table.insert(MapEventManager.monsterSetMap[tile:getTag()], pack)
				tile:setHasEvent(true)

				if tile:getVisible() then
					visibleTile = tile
				end

				anyTile = tile
			end
		end
	end

	if forceCheck then
		if anyTile then
			MapEventManager.checkMonsterSet(anyTile.x, anyTile.y)
		end
	elseif visibleTile then
		MapEventManager.checkMonsterSet(visibleTile.x, visibleTile.y)
	end

	return pack
end

function MapEventManager.getMonsterSetByIndex(index)
	return MapEventManager.monsterSetIndexMap[index]
end

function MapEventManager.clearMonsterSet(eventData)
	local pack = nil

	for i = 0, eventData.w - 1 do
		for j = 0, eventData.h - 1 do
			local x = eventData.x + i
			local y = eventData.y + j
			local tile = map:getTile(x, y)

			if tile and MapEventManager.monsterSetMap[tile.tag] then
				pack = MapEventManager.monsterSetMap[tile.tag]
				MapEventManager.monsterSetMap[tile.tag] = nil
			end
		end
	end

	return pack
end

function MapEventManager.hasMonster()
	return table.nums(MapEventManager.monsterSetMap) > 0
end

function MapEventManager.getMonsterGroup(id, random, depth, custom_max_depth, custom_abyss_level, custom_mutate_csv)
	print("$$$ getMonsterGroup", id)

	custom_max_depth = custom_max_depth or max_depth
	custom_abyss_level = custom_abyss_level or InfoDungeon.getLevel()
	local mutateCSV = custom_mutate_csv or InfoDungeon.getMutateMonster()
	local monsterCreateCSV = CsvParser.getCsvData("monster_create", id)
	local waves = SheetUtil.getNumber(monsterCreateCSV.battle_times, random)
	local waveRatios = SheetUtil.getTableArray(monsterCreateCSV.battle_ratio)
	local waveTimes = SheetUtil.getTableValue(monsterCreateCSV.battle_time)
	local waveRatio = waveRatios[tostring(waves)] or {}
	local tempWaveTime = 600
	local fixedDropStr, randomDropStr, isRandom = nil

	local function makeGroup(i)
		local group = {}
		local maxClass = 1

		if i > 1 then
			tempWaveTime = waveTimes[tostring(i)] or tempWaveTime
			group.time = tempWaveTime
		end

		local base_difficulty = SheetUtil.getNumber(monsterCreateCSV.base_difficulty, random)
		local deep_ratio = SheetUtil.getNumber(monsterCreateCSV.deep_ratio, random)
		local depth_percent = 0

		if depth and custom_max_depth then
			depth_percent = math.min(1, depth / custom_max_depth)
		end

		local difficulty = base_difficulty * (waveRatio[i] or 1) * (1 + depth_percent * deep_ratio)

		if monsterCreateCSV["drop_battle" .. i] ~= nil and monsterCreateCSV["drop_battle" .. i] ~= "" or monsterCreateCSV["is_random_battle" .. i] ~= nil and monsterCreateCSV["is_random_battle" .. i] ~= "" or monsterCreateCSV["random_drop_battle" .. i] ~= nil and monsterCreateCSV["random_drop_battle" .. i] ~= "" then
			fixedDropStr = monsterCreateCSV["drop_battle" .. i]
			randomDropStr = monsterCreateCSV["random_drop_battle" .. i]
			isRandom = monsterCreateCSV["is_random_battle" .. i]
		end

		local monsterMap = {}

		if fixedDropStr then
			local fixedDropIDs = SheetUtil.getArray(fixedDropStr)

			for j, fixedDropID in ipairs(fixedDropIDs) do
				if not empty(fixedDropID) then
					local baseID, monsterCSV = DropManager.dropLibMonster(fixedDropID, custom_abyss_level, 0, random)

					if baseID then
						if not monsterMap[baseID] then
							monsterMap[baseID] = 0
						end

						monsterMap[baseID] = monsterMap[baseID] + 1
						local difficulty_value = monsterCSV.difficulty_value

						if mutateCSV and not empty(mutateCSV["difficulty_multi_" .. monsterCSV.class]) then
							difficulty_value = difficulty_value * mutateCSV["difficulty_multi_" .. monsterCSV.class]
						end

						difficulty = difficulty - difficulty_value
						maxClass = math.max(maxClass, monsterCSV.class)
					end
				end
			end
		end

		local randomDropID = randomDropStr

		if not empty(randomDropID) then
			if isRandom == 1 then
				local baseID, monsterCSV = DropManager.dropLibMonster(randomDropID, custom_abyss_level, 0, random)

				if baseID then
					while difficulty > 0 do
						if not monsterMap[baseID] then
							monsterMap[baseID] = 0
						end

						monsterMap[baseID] = monsterMap[baseID] + 1
						local difficulty_value = monsterCSV.difficulty_value

						if mutateCSV and not empty(mutateCSV["difficulty_multi_" .. monsterCSV.class]) then
							difficulty_value = difficulty_value * mutateCSV["difficulty_multi_" .. monsterCSV.class]
						end

						difficulty = difficulty - difficulty_value
						maxClass = math.max(maxClass, monsterCSV.class)
					end
				end
			else
				while difficulty > 0 do
					local baseID, monsterCSV = DropManager.dropLibMonster(randomDropID, custom_abyss_level, 0, random)

					if baseID then
						if not monsterMap[baseID] then
							monsterMap[baseID] = 0
						end

						monsterMap[baseID] = monsterMap[baseID] + 1
						local difficulty_value = monsterCSV.difficulty_value

						if mutateCSV and not empty(mutateCSV["difficulty_multi_" .. monsterCSV.class]) then
							difficulty_value = difficulty_value * mutateCSV["difficulty_multi_" .. monsterCSV.class]
						end

						difficulty = difficulty - difficulty_value
						maxClass = math.max(maxClass, monsterCSV.class)
					else
						break
					end
				end
			end
		end

		local bmArr = SheetUtil.getColumnList(monsterCreateCSV, {
			"battle_monster_",
			"battle_monster_num_"
		}, {
			"id",
			"num"
		})

		for i, v in ipairs(bmArr) do
			if not monsterMap[v.id] then
				monsterMap[v.id] = 0
			end

			monsterMap[v.id] = monsterMap[v.id] + v.num
			local monsterCSV = CsvParser.getCsvData("monster", v.id)
			maxClass = math.max(maxClass, monsterCSV.class)
		end

		if mutateCSV then
			local addIndex = 1

			if maxClass == 11 then
				addIndex = 2
			elseif maxClass == 12 then
				addIndex = 3
			end

			if not empty(mutateCSV["monster" .. addIndex .. "_add"]) then
				local monsterDropID = mutateCSV["monster" .. addIndex .. "_add"]
				local baseID, monsterCSV = DropManager.dropLibMonster(monsterDropID, custom_abyss_level, 0, random)

				if baseID then
					if not monsterMap[baseID] then
						monsterMap[baseID] = 0
					end

					monsterMap[baseID] = monsterMap[baseID] + 1
					maxClass = math.max(maxClass, monsterCSV.class)
				end
			end
		end

		local ex_difficulty = 0

		if mutateCSV and not empty(mutateCSV.ex_difficulty) then
			ex_difficulty = ex_difficulty + SheetUtil.getNumber(mutateCSV.ex_difficulty, random)
		end

		if InfoNaraka.inNarakaBoss() then
			ex_difficulty = ex_difficulty + InfoNaraka.getModeExDifficulty()
		end

		local exMonsterMap = {}

		if ex_difficulty > 0 then
			local base_difficulty = ex_difficulty
			local difficulty = base_difficulty * (waveRatio[i] or 1) * (1 + depth_percent * deep_ratio)
			local m_fixedDropStr = monsterCreateCSV.mutate_drop_battle
			local m_randomDropStr = monsterCreateCSV.mutate_is_random_battle
			local m_isRandom = monsterCreateCSV.mutate_random_drop_battle

			if not empty(m_fixedDropStr) then
				local fixedDropIDs = SheetUtil.getArray(m_fixedDropStr)

				for j, fixedDropID in ipairs(fixedDropIDs) do
					if not empty(fixedDropID) then
						local baseID, monsterCSV = DropManager.dropLibMonster(fixedDropID, custom_abyss_level, 0, random)

						if baseID then
							if not exMonsterMap[baseID] then
								exMonsterMap[baseID] = 0
							end

							exMonsterMap[baseID] = exMonsterMap[baseID] + 1
							local difficulty_value = monsterCSV.difficulty_value

							if mutateCSV and not empty(mutateCSV["difficulty_multi_" .. monsterCSV.class]) then
								difficulty_value = difficulty_value * mutateCSV["difficulty_multi_" .. monsterCSV.class]
							end

							difficulty = difficulty - difficulty_value
						end
					end
				end
			end

			local randomDropID = m_randomDropStr

			if not empty(randomDropID) then
				if m_isRandom == 1 then
					local baseID, monsterCSV = DropManager.dropLibMonster(randomDropID, custom_abyss_level, 0, random)

					if baseID then
						while difficulty > 0 do
							if not exMonsterMap[baseID] then
								exMonsterMap[baseID] = 0
							end

							exMonsterMap[baseID] = exMonsterMap[baseID] + 1
							local difficulty_value = monsterCSV.difficulty_value

							if mutateCSV and not empty(mutateCSV["difficulty_multi_" .. monsterCSV.class]) then
								difficulty_value = difficulty_value * mutateCSV["difficulty_multi_" .. monsterCSV.class]
							end

							difficulty = difficulty - difficulty_value
						end
					end
				else
					while difficulty > 0 do
						local baseID, monsterCSV = DropManager.dropLibMonster(randomDropID, custom_abyss_level, 0, random)

						if baseID then
							if not exMonsterMap[baseID] then
								exMonsterMap[baseID] = 0
							end

							exMonsterMap[baseID] = exMonsterMap[baseID] + 1
							local difficulty_value = monsterCSV.difficulty_value

							if mutateCSV and not empty(mutateCSV["difficulty_multi_" .. monsterCSV.class]) then
								difficulty_value = difficulty_value * mutateCSV["difficulty_multi_" .. monsterCSV.class]
							end

							difficulty = difficulty - difficulty_value
						else
							break
						end
					end
				end
			end
		end

		local monsterArr = {}

		for baseID, num in pairs(monsterMap) do
			table.insert(monsterArr, {
				id = baseID,
				num = num
			})
		end

		table.sort(monsterArr, function (a, b)
			return a.id < b.id
		end)

		local exMonsterArr = {}

		for baseID, num in pairs(exMonsterMap) do
			table.insert(exMonsterArr, {
				id = baseID,
				num = num
			})
		end

		table.sort(exMonsterArr, function (a, b)
			return a.id < b.id
		end)

		for j, v in ipairs(exMonsterArr) do
			table.insert(monsterArr, v)
		end

		group.monsters = monsterArr

		return group, maxClass
	end

	local groups = {}
	local allMaxClass = 1

	for i = 1, waves do
		local group, maxClass = makeGroup(i)
		allMaxClass = math.max(allMaxClass, maxClass)

		table.insert(groups, group)
	end

	if mutateCSV then
		local wave_add = mutateCSV["wave_add_" .. allMaxClass]

		if not empty(wave_add) then
			local waveAddNum = SheetUtil.getNumber(wave_add, random)
			local currentGroupNum = #groups

			for i = 1, waves do
				local group = makeGroup(currentGroupNum + i)

				table.insert(groups, group)
			end
		end
	end

	return groups
end

function MapEventManager.checkMonsterSet(x, y, checkAmbush)
	local packs = MapEventManager.monsterSetMap[x .. "_" .. y]

	if packs ~= nil then
		for i, pack in ipairs(packs) do
			if pack.visibleCount == 0 and (pack.setData.is_ambush ~= 1 or checkAmbush) and (pack.active == 0 or pack.active == 2 and tonumber(pack.setData.time) ~= 0 and pack.activeCD < MapFrameManager.getSecond()) then
				local setData = pack.setData
				local eventData = pack.eventData

				if setData.id then
					local random = Random.new(eventData.seed)
					local groupID = SheetUtil.getString(setData.id, random)
					local groups = MapEventManager.getMonsterGroup(groupID, random, eventData.depth)

					MapEventManager.makeMonsterGroups(groups, pack, groupID)

					pack.active = 1
				end
			end

			pack.visibleCount = pack.visibleCount + 1
		end
	end
end

function MapEventManager.checkMonsterSetRemove(x, y)
	local packs = MapEventManager.monsterSetMap[x .. "_" .. y]

	if packs ~= nil then
		for i, pack in ipairs(packs) do
			pack.visibleCount = math.max(0, pack.visibleCount - 1)

			if pack.visibleCount == 0 then
				pack.activeCD = MapFrameManager.getSecond() + SheetUtil.getNumber(pack.setData.time)
			end
		end
	end
end

local waveGroupsMap = {}
local waveMonsters = {}

function MapEventManager.prepareNextWave(groupIDs)
	local hasNext = false

	for i, groupID in ipairs(groupIDs) do
		if MapEventManager.prepareMonsterWave(groupID) then
			hasNext = true
		end
	end

	return hasNext
end

function MapEventManager.startNextWave()
	for i, monster in ipairs(waveMonsters) do
		local effectGen = monster:getEffectGen()

		if effectGen then
			effectGen:castEffect(MiscConfig.effect_nextwave_start, monster)
		end

		WarMachine.addUnit(monster, 2, "MapEventManager.startNextWave")
	end
end

function MapEventManager.setWaves(pack, groups)
	local groupID = pack.index
	waveGroupsMap[groupID] = {
		index = 1,
		pack = pack,
		groups = groups
	}
end

function MapEventManager.getWaveList(groupIDs)
	local sortStack = {}
	local minIndex = nil

	for i, groupID in ipairs(groupIDs) do
		if groupID ~= "non-grouped" then
			local waveObj = waveGroupsMap[groupID]
			local waveIndex = waveObj.index + 1

			while waveObj.groups[waveIndex] do
				local groupData = waveObj.groups[waveIndex]
				local index = 1
				local bestClass, bestMonster = nil

				while true do
					local monsterObj = groupData.monsters[index]

					if monsterObj then
						local monsterInfo = MapEventManager.getMonsterInfo(monsterObj.id)
						local monsterData = CsvParser.getCsvData("monster", monsterInfo.base_id)

						if not bestClass or bestClass < monsterData.class then
							bestClass = monsterData.class
							bestMonster = monsterInfo.base_id
						end

						index = index + 1
					else
						break
					end
				end

				if bestClass then
					if not sortStack[waveIndex] then
						sortStack[waveIndex] = {}
					end

					minIndex = minIndex or waveIndex

					table.insert(sortStack[waveIndex], {
						time = groupData.time,
						index = waveIndex,
						class = bestClass,
						monsterID = bestMonster
					})

					waveIndex = waveIndex + 1
				else
					break
				end
			end
		end
	end

	local index = minIndex
	local arr = {}

	while true do
		local indexArr = sortStack[index]

		if indexArr then
			local bestClass, bestObj = nil

			for i, obj in ipairs(indexArr) do
				if not bestClass or bestClass < obj.class then
					bestClass = obj.class
					bestObj = obj
				end
			end

			table.insert(arr, bestObj)

			index = index + 1
		else
			break
		end
	end

	return arr
end

function MapEventManager.getMaxCLass(groupIDs)
	local maxClass = 1
	local eliteExistMap = {}

	for i, groupID in ipairs(groupIDs) do
		if groupID ~= "non-grouped" then
			local waveObj = waveGroupsMap[groupID]

			for i, groupData in ipairs(waveObj.groups) do
				local index = 1

				while true do
					local monsterObj = groupData.monsters[index]

					if monsterObj then
						local monsterInfo = MapEventManager.getMonsterInfo(monsterObj.id)
						local monsterData = CsvParser.getCsvData("monster", monsterInfo.base_id)
						maxClass = math.max(monsterData.class, maxClass)
						index = index + 1
					else
						break
					end
				end
			end
		end
	end

	return maxClass
end

function MapEventManager.prepareMonsterWave(groupID)
	if waveGroupsMap[groupID] then
		local waveObj = waveGroupsMap[groupID]
		local waveIndex = waveObj.index + 1
		local pack = waveObj.pack
		local groupData = waveObj.groups[waveIndex]

		if groupData then
			waveObj.index = waveIndex
			waveMonsters = MapEventManager.makeMonsterGroup(groupData, pack, true)

			for i, monster in ipairs(waveMonsters) do
				local effectGen = monster:getEffectGen()

				if effectGen then
					effectGen:castEffect(MiscConfig.effect_nextwave_prepare, monster)
				end
			end

			return true
		end
	end
end

function MapEventManager.makeMonsterGroups(groups, pack, monsterCreateID)
	local eventData = pack.eventData
	local random = Random.new(eventData.seed)

	for i, groupData in ipairs(groups) do
		groupData.seed = random:getInt(1, 65535)
	end

	MapEventManager.setWaves(pack, groups)

	if groups[1] then
		MapEventManager.makeMonsterGroup(groups[1], pack, nil, monsterCreateID)
	end
end

function MapEventManager.getMonsterGroupDrop(groupID, pack)
	local itemStack = {}

	if waveGroupsMap[groupID] then
		local waveObj = waveGroupsMap[groupID]

		for kk, groupData in pairs(waveObj.groups) do
			local eventData = pack.eventData
			local eventInfo = ConfParser.parse(eventData.info)
			local random = Random.new(groupData.seed)
			local index = 1
			local monsterObj = groupData.monsters[index]

			if monsterObj then
				local num = SheetUtil.getNumber(monsterObj.num, random)

				for j = 1, num do
					local monsterInfo = MapEventManager.getMonsterInfo(monsterObj.id)
					local monsterData = CsvParser.getCsvData("monster", monsterInfo.base_id)

					assert(monsterData, "monster miss id:" .. monsterInfo.base_id)

					local monsterSeed = random:getInt(1, 65535)
					local _itemArr = WarMachine.getDropItemStack(monsterInfo, monsterSeed)

					for i, v in ipairs(_itemArr) do
						table.insert(itemStack, v)
					end
				end

				index = index + 1
			else
				break
			end
		end
	end

	return itemStack
end

function MapEventManager.makeMonsterGroup(groupData, pack, isNextWave, monsterCreateID)
	local eventData = pack.eventData
	local eventInfo = ConfParser.parse(eventData.info)
	local random = Random.new(groupData.seed)
	local randomPos = nil
	local posArray = {}

	local function generatePosArray()
		if isNextWave then
			randomPos = Random.new(math.random(1, 65535))
			local battlefield = WarMachine.getAreaTileMap()
			local center = global.map.battleCenterTile

			for tag, tile in pairs(battlefield) do
				if tile:getWalkable(0) then
					local distance = math.sqrt(math.pow(center.y - tile.y, 2) + math.pow(center.x - tile.x, 2))

					table.insert(posArray, {
						x = tile.x,
						y = tile.y,
						distance = distance
					})
				end
			end

			table.sort(posArray, function (a, b)
				return a.distance < b.distance
			end)
		else
			for i = 0, eventData.w - 1 do
				for j = 0, eventData.h - 1 do
					local tile = map:getTile(eventData.x + i, eventData.y + j)

					if tile and tile:getWalk() == 0 then
						table.insert(posArray, {
							x = eventData.x + i,
							y = eventData.y + j
						})
					end
				end
			end
		end
	end

	generatePosArray()

	local monsterInfoArr = {}
	local index = 1
	local mutateCSV = InfoDungeon.getMutateMonster()
	local maxClass = 0
	local eliteReadyArr = {}

	while #posArray > 0 do
		local monsterObj = groupData.monsters[index]

		if monsterObj then
			local num = SheetUtil.getNumber(monsterObj.num, random)

			for j = 1, num do
				local monsterInfo = MapEventManager.getMonsterInfo(monsterObj.id)

				if pack.custom_level then
					monsterInfo.level = pack.custom_level
				end

				local monsterData = CsvParser.getCsvData("monster", monsterInfo.base_id)

				assert(monsterData, "monster miss id:" .. monsterInfo.base_id)

				local monsterSeed = random:getInt(1, 65535)
				local pos = nil

				if isNextWave then
					pos = table.remove(posArray, math.floor(randomPos:nextGauss() * #posArray) + 1)
				else
					pos = table.remove(posArray, math.random(1, #posArray))
				end

				table.insert(monsterInfoArr, {
					monsterInfo = monsterInfo,
					pos = pos,
					seed = monsterSeed
				})

				maxClass = math.max(maxClass, monsterData.class)

				if mutateCSV and monsterData.class == 11 then
					table.insert(eliteReadyArr, monsterObj.id)
				end

				if #posArray == 0 then
					generatePosArray()
				end
			end

			index = index + 1
		else
			break
		end
	end

	if mutateCSV and maxClass == 11 and not empty(mutateCSV.elite_num_add) and #eliteReadyArr > 0 then
		local elite_num_add = SheetUtil.getNumber(mutateCSV.elite_num_add, random)

		for i = 1, elite_num_add do
			local pos = nil

			if isNextWave then
				pos = table.remove(posArray, math.floor(randomPos:nextGauss() * #posArray) + 1)
			else
				pos = table.remove(posArray, math.random(1, #posArray))
			end

			local monsterID = eliteReadyArr[random:getInt(1, #eliteReadyArr)]
			local monsterInfo = MapEventManager.getMonsterInfo(monsterID)

			if pack.custom_level then
				monsterInfo.level = pack.custom_level
			end

			local monsterSeed = random:getInt(1, 65535)

			table.insert(monsterInfoArr, {
				monsterInfo = monsterInfo,
				pos = pos,
				seed = monsterSeed
			})

			if #posArray == 0 then
				generatePosArray()
			end
		end
	end

	if not isNextWave and monsterCreateID then
		local monsterCreateCSV = CsvParser.getCsvData("monster_create", monsterCreateID)

		if monsterCreateCSV and monsterCreateCSV.no_actv_monster ~= 1 then
			local actvMonsterID = InfoDungeon.getActvMonster(eventData.index)

			if actvMonsterID then
				local csv = CsvParser.getCsvData("actv_monster", actvMonsterID)

				if csv then
					local num = SheetUtil.getNumber(csv.num, random)

					for i = 1, num do
						local pos = table.remove(posArray, math.random(1, #posArray))
						local monsterID = csv.id
						local monsterInfo = MapEventManager.getMonsterInfo(monsterID)

						if csv.is_max_level == 1 then
							monsterInfo.level = InfoDungeon.getAbyssMaxLevel()
						end

						local monsterSeed = random:getInt(1, 65535)

						table.insert(monsterInfoArr, {
							noMutate = true,
							monsterInfo = monsterInfo,
							pos = pos,
							seed = monsterSeed
						})

						if #posArray == 0 then
							generatePosArray()
						end
					end
				end
			end
		end
	end

	local monsters = {}
	local isBoss = nil

	for i, v in ipairs(monsterInfoArr) do
		local monsterInfo = v.monsterInfo
		local pos = v.pos
		local seed = v.seed
		local monster = Monster.new(pack.index)
		monster.seed = seed
		monster.random = Random.new(monster.seed)

		monster:setInfo(monsterInfo)
		monster:setEventPack(pack)

		monster.noMutate = v.noMutate
		monster.isNextWave = isNextWave
		local eventData = pack.eventData
		MapEventManager.monsterEventGroup[eventData.index] = pack.index

		if not empty(eventInfo.rush_type) then
			local effectGen = monster:getEffectGen()

			if effectGen then
				effectGen:fadeTo(0, 0)
			end
		else
			local tileMap = {}
			local enterEvent = eventData.enterEvent
			local patrolRatio = MiscConfig.MONSTAR_PATROL_RATIO

			if not enterEvent then
				enterEvent = MapEventManager.getEventByTagOne("enter")
				patrolRatio = MiscConfig.BOSS_PATROL_RATIO
			end

			if enterEvent and patrolRatio < 1 then
				local enterX = enterEvent.x + (enterEvent.w - 1) / 2
				local enterY = enterEvent.y + (enterEvent.h - 1) / 2
				local tileArr = {}

				for i = eventData.x, eventData.x + eventData.w - 1 do
					for j = eventData.y, eventData.y + eventData.h - 1 do
						local tile = map:getTile(i, j)

						if tile then
							local distance = math.sqrt(math.pow(tile.x - enterX, 2) + math.pow(tile.y - enterY, 2))

							table.insert(tileArr, {
								tile = tile,
								distance = distance
							})
						end
					end
				end

				table.sort(tileArr, function (a, b)
					return b.distance < a.distance
				end)

				local tileCount = math.min(#tileArr, math.max(1, math.ceil(#tileArr * patrolRatio)))

				for i = 1, tileCount do
					local tile = tileArr[i].tile
					tileMap[tile.tag] = true
				end

				local posTile = tileArr[math.random(1, tileCount)].tile
				pos = {
					x = posTile.x,
					y = posTile.y
				}
			else
				for i = eventData.x, eventData.x + eventData.w - 1 do
					for j = eventData.y, eventData.y + eventData.h - 1 do
						local tile = map:getTile(i, j)

						if tile then
							tileMap[tile.tag] = true
						end
					end
				end
			end

			monster:setPatrolArea(tileMap)
		end

		monster:addEventListener("sleep", MapEventManager.handleMonsterEvent)
		monster:addEventListener("wake", MapEventManager.handleMonsterEvent)
		monster:addEventListener("battle_start", MapEventManager.handleMonsterEvent)

		local x, y = map:tileToMap(pos.x, pos.y)

		monster:display(map, x, y)
		table.insert(monsters, monster)

		if monster.data.class == 12 then
			isBoss = true
		end

		local onlineAnchor = {
			map_index = InfoDungeon.getMapIndex(),
			event_index = eventData.index,
			index = i
		}
		monster.onlineAnchor = onlineAnchor

		if OnlineCamp.inRoom() == 2 then
			OnlineCamp.syncMonster(onlineAnchor, monster)
		end
	end

	print("$$$ #monsters", #monsters)

	if #monsters > 0 then
		monsters[math.random(1, #monsters)].is_lucky_one = true
	end

	if not empty(eventInfo.drama) and not DramaManager.opening then
		DramaManager.start(eventInfo.drama)
	end

	return monsters
end

function MapEventManager.removeMonsterGroup(eventData, pack)
end

function MapEventManager.handleMonsterEvent(event)
	local monster = event.target
	local pack = monster.eventPack

	if event.name == "wake" then
		if pack.activeCount == 0 then
			pack.active = 1
		end

		pack.activeCount = pack.activeCount + 1
	elseif event.name == "sleep" or event.name == "die" then
		pack.activeCount = pack.activeCount - 1

		if pack.activeCount == 0 then
			pack.active = 2
			pack.activeCD = MapFrameManager.getSecond() + SheetUtil.getNumber(pack.setData.time)
		end
	elseif event.name == "battle_start" then
		global.player:stop()
		global.player:stopMoveDirection()
		map:prepareBattle(event.center, nil, event.eventData, event.monster)
	end
end

local customLevel = nil

function MapEventManager.setCustomLevel(level)
	customLevel = level
end

function MapEventManager.clearCustomLevel()
	customLevel = nil
end

function MapEventManager.getMonsterInfo(id)
	return {
		base_id = id,
		level = customLevel or InfoDungeon.getLevel()
	}
end

function MapEventManager.makeEverMonster(dropID, random, pack)
	local battleArea = WarMachine.getAreaTileMap()
	local tiles = {}

	for k, tile in pairs(battleArea) do
		if tile:isEmpty() then
			table.insert(tiles, tile)
		end
	end

	local tile = tiles[math.random(1, #tiles)]

	if not tile then
		return
	end

	local baseID, monsterCSV = DropManager.dropLibMonster(dropID, InfoDungeon.getLevel(), 0, random)

	if baseID then
		local monsterInfo = MapEventManager.getMonsterInfo(baseID)
		local monster = Monster.new(pack.index)
		monster.seed = random:getInt(1, 65535)
		monster.random = Random.new(monster.seed)

		monster:setInfo(monsterInfo)
		monster:setEventPack(pack)
		monster:addEventListener("sleep", MapEventManager.handleMonsterEvent)
		monster:addEventListener("wake", MapEventManager.handleMonsterEvent)
		monster:addEventListener("battle_start", MapEventManager.handleMonsterEvent)

		local x, y = map:tileToMap(tile)

		monster:display(map, x, y)

		local effectGen = monster:getEffectGen()

		if effectGen then
			effectGen:castEffect(MiscConfig.effect_nextwave_start, monster)
		end

		WarMachine.addUnit(monster, 2, "MapEventManager.startNextWave")

		return monster
	else
		print("未找到怪物 掉落id：" .. dropID, "等级：", InfoDungeon.getLevel())
	end
end

function MapEventManager.onRemoveTileEvent(tile)
	MapEventManager.checkMonsterSetRemove(tile.x, tile.y)
end

function MapEventManager.onDrawTileEvent(tile)
	MapEventManager.checkMonsterSet(tile.x, tile.y)
end

function MapEventManager.getRandomPress()
	local pressData = MapEventManager.pressArray[math.random(1, #MapEventManager.pressArray)]
	local textData, fovData = nil

	for i = 1, #pressData.link do
		local eventData = pressData.link[i]

		if eventData.name == "press_fov" then
			fovData = eventData
		elseif eventData.name == "press_text" then
			textData = eventData
		end
	end

	return pressData, fovData or pressData, textData or pressData
end

function MapEventManager.hasMapEnter()
	return MapEventManager.enter and table.nums(MapEventManager.enter) > 0
end

function MapEventManager.getMapEnter(tag, fixedEnter, fixedIndex)
	local sortList = {}

	for i, enterData in ipairs(MapEventManager.enter) do
		local info = ConfParser.parse(enterData.info)

		if info.tag == tag then
			local destData, sitData, faceData, type = nil

			if enterData.link then
				local destLink = MapEventManager.findLinkOne(enterData, "enter_dest")

				if destLink then
					destData = destLink
					type = 1
				else
					local sitLinkExitedMap = {}
					local sitLink = MapEventManager.findLinkOne(enterData, "enter_sit")

					if sitLink then
						faceData = MapEventManager.findLinkOne(enterData, "sit_face")
						sitData = {}

						while sitLink do
							table.insert(sitData, sitLink)

							sitLinkExitedMap[sitLink.x .. "_" .. sitLink.y] = true
							local links = MapEventManager.findLinkAll(sitLink, "enter_sit")
							sitLink = nil

							for _, link in ipairs(links) do
								if not sitLinkExitedMap[link.x .. "_" .. link.y] then
									sitLink = link
								end
							end
						end
					end

					type = 2
				end
			end

			local obj = {
				type = type or 0,
				enterData = enterData,
				destData = destData,
				sitData = sitData,
				faceData = faceData
			}

			if not empty(fixedEnter) and fixedEnter == enterData.x .. "," .. enterData.y then
				return obj.enterData, obj.destData, obj.sitData, obj.faceData
			elseif not empty(fixedIndex) and fixedIndex == info.index then
				return obj.enterData, obj.destData, obj.sitData, obj.faceData
			else
				table.insert(sortList, obj)
			end
		end
	end

	if #sortList > 0 then
		table.sort(sortList, function (a, b)
			return a.type < b.type
		end)

		local info = ConfParser.parse(sortList[1].enterData.info)
		sortList[1].enterData.mode = info.mode or 0

		return sortList[1].enterData, sortList[1].destData, sortList[1].sitData, sortList[1].faceData
	end
end

function MapEventManager.getEventByIndex(tag)
	return MapEventManager.eventMapByIndex[tag]
end

function MapEventManager.getEventByTagArray(tag)
	return MapEventManager.eventMapByTag[tag]
end

function MapEventManager.getEventByTagOne(tag)
	local eventArray = MapEventManager.eventMapByTag[tag]

	if eventArray then
		return eventArray[1]
	end
end

function MapEventManager.getEventByTagRandom(tag)
	local eventArray = MapEventManager.eventMapByTag[tag]

	if eventArray then
		return eventArray[math.random(1, #eventArray)]
	end
end

function MapEventManager.findLinkOne(eventData, tag)
	if eventData.link then
		for i = 1, #eventData.link do
			local linkData = eventData.link[i]

			if linkData.tag == tag then
				return linkData
			end
		end
	end
end

function MapEventManager.findLinkOneOrStack(eventData, tag)
	local eventData = MapEventManager.findLinkOne(eventData, tag)
	eventData = eventData or MapEventManager.getEventByTile(eventData.x, eventData.y, tag)

	return eventData
end

function MapEventManager.findLinkAll(eventData, tag)
	local links = {}

	if eventData.link then
		for i = 1, #eventData.link do
			local linkData = eventData.link[i]

			if tag == nil or linkData.tag == tag then
				table.insert(links, linkData)
			end
		end
	end

	return links
end

function MapEventManager.findLinkAllOrStack(eventData, tag)
	local links = {}

	if eventData.link then
		for i = 1, #eventData.link do
			local linkData = eventData.link[i]

			if tag == nil or linkData.tag == tag then
				table.insert(links, linkData)
			end
		end
	end

	local stackEvent = MapEventManager.getEventByTile(eventData.x, eventData.y, tag)

	if stackEvent then
		table.insert(links, stackEvent)
	end

	return links
end

function MapEventManager.findLinkBridge(eventData, tags)
	if not eventData.link then
		return
	end

	local oldMap = {
		[eventData.index] = true
	}
	local findArr = {}

	table.insert(findArr, {
		tagIndex = 0,
		event = eventData
	})

	local okArr = {}
	local linkArr = {}

	while #findArr > 0 do
		local findObj = table.remove(findArr, 1)
		local currentEvent = findObj.event
		local tagIndex = findObj.tagIndex + 1

		for i = 1, #currentEvent.link do
			local linkData = currentEvent.link[i]

			if not oldMap[linkData.index] then
				oldMap[linkData.index] = true

				if tagIndex > #tags then
					table.insert(okArr, linkData)
				elseif linkData.tag == tags[tagIndex] then
					table.insert(linkArr, linkData)
					table.insert(findArr, {
						event = linkData,
						tagIndex = tagIndex
					})
				end
			end
		end
	end

	return okArr, linkArr
end

function MapEventManager.findLinkTo(eventData, finalTag, bridgeTag)
	if not eventData.link then
		return
	end

	local readyArr = {
		eventData
	}
	local closedMap = {
		[eventData.index] = true
	}
	local parentMap = {}
	local finalEvent = nil
	local found = false

	while #readyArr > 0 do
		for i, currentData in ipairs(readyArr) do
			if currentData.link then
				for j, linkData in ipairs(currentData.link) do
					if not closedMap[linkData.index] then
						if linkData.tag == finalTag then
							parentMap[linkData.index] = currentData
							finalEvent = linkData
							found = true

							break
						elseif linkData.tag == bridgeTag then
							parentMap[linkData.index] = currentData
							closedMap[linkData.index] = linkData

							table.insert(readyArr, linkData)
						end
					end
				end
			end
		end

		if found then
			break
		end
	end

	if finalEvent then
		local path = {}
		local node = finalEvent

		while node do
			table.insert(path, 1, node)

			node = parentMap[node.index]
		end

		return path
	end
end

function MapEventManager.linkTrigger(eventData)
	local eventDataArr, linkArr = MapEventManager.findLinkBridge(eventData, {
		"link-trigger",
		"link-target"
	})

	if eventDataArr then
		local linkData = linkArr[2]

		for i, eventData in ipairs(eventDataArr) do
			Log.verbose("linkTrigger", eventData.tag, eventData._conditionReady)

			if eventData._conditionReady then
				local function triggerEvent()
					MapEventManager.prepareEvent(eventData, true)
				end

				local linkInfo = ConfParser.parse(linkData.info)

				if not linkInfo.delay or linkInfo.delay <= 0 then
					triggerEvent()
				else
					MapFrameManager.setTimeout(triggerEvent, linkInfo.delay, map)
				end
			end
		end
	end
end

function MapEventManager.checkEventCondition(eventData)
	if not empty(eventData.condition) then
		return Condition.checkText(eventData.condition)
	end

	return true
end

function MapEventManager.getEventCenter(eventData)
	local mapX, mapY = map:tileToMap(eventData)
	mapX = mapX + (eventData.w - 1) * map.ptPerTile / 2
	mapY = mapY + (eventData.h - 1) * map.ptPerTile / 2

	return mapX, mapY
end

function MapEventManager.getEventCenterTile(eventData)
	local mapX, mapY = map:tileToMap(eventData)
	local tile = map:mapToTile(mapX, mapY)

	return tile
end

function MapEventManager.checkBossKilled(isAll)
	local bossCount = 0
	local killCount = 0

	for eventIndex, groupID in pairs(MapEventManager.monsterEventGroup) do
		local _event_data = MapEventManager.getEventByIndex(eventIndex)
		local info = ConfParser.parse(_event_data.info)
		local _event_info = InfoDungeon.getEventInfo(eventIndex)

		if _event_data.tag == "monster" then
			local _seed = _event_info.seed
			local _random = Random.new(_seed)
			local monsterCreateID = SheetUtil.getString(info.id, _random)
			local groups = MapEventManager.getMonsterGroup(monsterCreateID, _random, _event_data.depth)

			for i, groupData in ipairs(groups) do
				local _index = 1
				local group_seed = _random:getInt(1, 65535)
				local group_random = Random.new(group_seed)

				while true do
					local monsterObj = groupData.monsters[_index]

					if monsterObj then
						local monster_id = monsterObj.id
						local monster_data = CsvParser.getCsvData("monster", monster_id)

						if monster_data.class == 12 then
							bossCount = bossCount + 1

							if _event_info.fin > 0 then
								killCount = killCount + 1
							end
						end

						_index = _index + 1
					else
						break
					end
				end
			end
		end
	end

	print("$$$ checkBossKilled", bossCount, killCount)

	if isAll then
		return bossCount <= killCount
	else
		return math.min(bossCount, 1) <= killCount
	end
end

function MapEventManager.countTagAll(tag)
	local finCount = 0
	local allCount = 0
	local eventArray = MapEventManager.eventMapByTag[tag]

	if eventArray then
		allCount = #eventArray

		for i, eventData in ipairs(eventArray) do
			local eventInfo = InfoDungeon.getEventInfo(eventData.index)

			if eventInfo.fin > 0 then
				finCount = finCount + 1
			end
		end
	end

	return finCount, allCount
end

return MapEventManager
