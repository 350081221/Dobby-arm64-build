local DmgCount = {}
local totalDmg = 0
local heroDmg = {}
local petDmg = {}
local modaoDmg = 0

function DmgCount.reset()
	totalDmg = 0
	heroDmg = {}
	petDmg = {}
	modaoDmg = 0

	if global.tongji then
		DmgCount.refreshUI()
	end
end

function DmgCount.getHeroDmg(heroID)
	local dmg = 0

	if heroDmg[heroID] then
		dmg = heroDmg[heroID].s + heroDmg[heroID].a + heroDmg[heroID].h
	end

	return dmg
end

function DmgCount.addHeroDmg(heroID, dmg, isSkill)
	if not heroID then
		return
	end

	if not heroDmg[heroID] then
		heroDmg[heroID] = {
			h = 0,
			s = 0,
			a = 0
		}
	end

	totalDmg = totalDmg + dmg

	if isSkill then
		heroDmg[heroID].s = heroDmg[heroID].s + dmg
	else
		heroDmg[heroID].a = heroDmg[heroID].a + dmg
	end

	if global.tongji then
		DmgCount.refreshUI()
	end
end

function DmgCount.addHeroHeal(heroID, healValue)
	if not heroID then
		return
	end

	if not heroDmg[heroID] then
		heroDmg[heroID] = {
			h = 0,
			s = 0,
			a = 0
		}
	end

	heroDmg[heroID].h = heroDmg[heroID].h + healValue
end

function DmgCount.addPetDmg(petID, dmg, isSkill)
	if not petID then
		return
	end

	if not petDmg[petID] then
		petDmg[petID] = {
			a = 0,
			s = 0
		}
	end

	totalDmg = totalDmg + dmg

	if isSkill then
		petDmg[petID].s = petDmg[petID].s + dmg
	else
		petDmg[petID].a = petDmg[petID].a + dmg
	end

	if global.tongji then
		DmgCount.refreshUI()
	end
end

function DmgCount.addModaoDmg(dmg)
	totalDmg = totalDmg + dmg
	modaoDmg = modaoDmg + dmg

	if global.tongji then
		DmgCount.refreshUI()
	end
end

function DmgCount.refreshUI()
	if global.battleUI then
		for heroID, data in pairs(heroDmg) do
			global.battleUI.headUI:setHeroDmg(heroID, totalDmg, heroDmg[heroID].s, heroDmg[heroID].a)
		end

		for petID, data in pairs(petDmg) do
			global.battleUI.headUI:setPetDmg(petID, totalDmg, petDmg[petID].s, petDmg[petID].a)
		end

		global.battleUI:coutDmg(totalDmg, modaoDmg)
	end
end

function DmgCount.refreshAdvUI()
	if global.adventureUI then
		for heroID, data in pairs(heroDmg) do
			global.adventureUI.headUI:setHeroDmg(heroID, totalDmg, heroDmg[heroID].s, heroDmg[heroID].a)
		end

		for petID, data in pairs(petDmg) do
			global.adventureUI.headUI:setPetDmg(petID, totalDmg, petDmg[petID].s, petDmg[petID].a)
		end

		global.adventureUI:coutDmg(totalDmg, modaoDmg)
	end
end

function DmgCount.transNumber(num)
	if num > 1000000 then
		return tostring(math.floor(num / 100000) / 10) .. "m"
	elseif num > 1000 then
		return tostring(math.floor(num / 100) / 10) .. "k"
	else
		return num
	end
end

return DmgCount
