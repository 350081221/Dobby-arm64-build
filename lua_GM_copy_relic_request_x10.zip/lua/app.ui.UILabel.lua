local UILabel = class("UILabel", function (text, style)
	local sprite = display.newNode()

	sprite:setAnchorPoint(cc.p(0.5, 0.5))

	return sprite
end)

function UILabel:ctor(text, style)
	self:setTouchSwallowEnabled(false)
	self:setCascadeOpacityEnabled(true)
	self:setCascadeColorEnabled(true)
	event_listener.extendMethods(self, true)

	style.align = Style.left
	local label, labelWidth, labelHeight = self:addLabel(text, style)
	self.width = labelWidth
	self.height = labelHeight

	self:setContentSize(cc.size(labelWidth, labelHeight))
end

function UILabel:removeTouchable()
	if self._isTouchable then
		self:setTouchSwallowEnabled(false)

		self._isTouchable = nil

		self:removeNodeEventListener(cc.NODE_TOUCH_EVENT)
		self:setTouchEnabled(false)
	end
end

function UILabel:toTouchable()
	if not self._isTouchable then
		self:setTouchSwallowEnabled(true)

		self._isTouchable = true

		self:addNodeEventListener(cc.NODE_TOUCH_EVENT, function (event)
			local eventName = event.name

			if eventName == "cancelled" then
				eventName = "ended"
			end

			return self:onTouch(eventName, event.x, event.y)
		end)
		self:setTouchEnabled(true)
	end
end

function UILabel:forceTouch(event, x, y)
	if self.touchHandler and event then
		self:onTouch(event, x, y)
	end
end

function UILabel:forceTap(x, y)
	if self.tapHandler then
		self.tapHandler(x, y)
	end
end

function UILabel:addTouch(handler)
	self.touchHandler = handler
end

function UILabel:removeTouch()
	self.touchHandler = nil
end

function UILabel:addTap(handler)
	self.tapHandler = handler
end

function UILabel:removeTap()
	self.tapHandler = nil
end

function UILabel:clearTouch()
	self.touchHandler = nil
	self.tapHandler = nil
end

function UILabel:onTouch(event, x, y)
	local touchOver = nil

	local function getTouchOver()
		if touchOver == nil then
			local pos = cc.p(x, y)
			pos = self:getParent():convertToNodeSpace(pos)
			local comX, comY = self:getPosition()

			if pos.x >= comX - self.width / 2 and pos.x <= comX + self.width / 2 and pos.y >= comY - self.height / 2 and pos.y <= comY + self.height / 2 then
				touchOver = true
			else
				touchOver = false
			end

			return touchOver
		else
			return touchOver
		end
	end

	if event == "ended" and self.tapHandler and getTouchOver() then
		UIManager.callTapCallback(self.tapGroupName, self)
		self.tapHandler(x, y)
	end

	if self.touchHandler then
		self.touchHandler(event, x, y)
	end

	return true
end

function UILabel:getTouchOver(x, y)
	local pos = cc.p(x, y)
	pos = self:getParent():convertToNodeSpace(pos)
	local comX, comY = self:getPosition()

	if pos.x >= comX - self.width / 2 and pos.x <= comX + self.width / 2 and pos.y >= comY - self.height / 2 and pos.y <= comY + self.height / 2 then
		return true
	else
		return false
	end
end

function UILabel:getGlobalPosition()
	local x, y = self:getPosition()
	local pos = cc.p(x, y)
	pos = self:getParent():convertToWorldSpace(pos)

	return pos.x - self.width / 2, pos.y + self.height / 2
end

function UILabel:addLabel(text, style)
	self:removeLabel()

	self.text = text
	local label, labelWidth, labelHeight = UIManager.createLabel(0, 0, 0, 0, text, style)
	self.label = label

	label:setPositionY(labelHeight / 2)
	self:addChild(label)

	return label, labelWidth, labelHeight
end

function UILabel:removeLabel()
	if self.label then
		self.label:removeSelf()

		self.label = nil
	end
end

function UILabel:refreshLocalization()
	if self.originalText then
		local text = Localization.getUiText(self.originalText)

		self:addLabel(text)
	end
end

function UILabel:setTapGroup(groupName)
	self.tapGroupName = groupName
end

function UILabel:onEnter()
end

function UILabel:onExit()
	self.touchHandler = nil
	self.tapHandler = nil

	self:setTouchEnabled(false)
	self:removeAllNodeEventListeners()
end

return UILabel
