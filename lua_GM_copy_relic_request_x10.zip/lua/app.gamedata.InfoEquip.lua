local InfoEquip = {}
local rawData = {}
local disableColor = cc.c4b(168, 40, 13, 255)
InfoEquip.disableColor = disableColor

function InfoEquip.init()
	InfoEquip.initDust()
	Connection.listen("equip_sync", InfoEquip.sync)
	Connection.listen("equip_sync_remove", InfoEquip.syncRemove)
end

app:addToAppEnterCall(InfoEquip.init)

function InfoEquip.query(onSuccess, onFailure)
	rawData = {}
	local nextIndex, queryNext = nil

	function queryNext()
		local function callback(rcvData)
			if rcvData.err then
				if onFailure then
					onFailure()
				end
			else
				for i, data in ipairs(rcvData.list) do
					if data.base_id ~= 0 then
						rawData[data.id] = data
					end
				end

				if rcvData.next_index then
					nextIndex = rcvData.next_index

					queryNext()
				elseif onSuccess then
					onSuccess()
				end
			end
		end

		Connection.request("equip_query", {
			start_index = nextIndex
		}, callback)
	end

	queryNext()
end

function InfoEquip.sync(data)
	dump(data, "$$$ InfoEquip.sync")

	local newEquips = {}
	local changedIdStack = {}

	for i, syncData in ipairs(data.list) do
		if syncData.base_id ~= 0 then
			local id = syncData.id

			if not rawData[id] then
				rawData[id] = syncData

				table.insert(newEquips, id)
			else
				for k, v in pairs(syncData) do
					rawData[id][k] = v
				end
			end

			changedIdStack[id] = rawData[id]
		end
	end

	ManagerInfo.dataChange("equip", changedIdStack)

	if #newEquips > 0 then
		notify.dispatch("new_equip", newEquips)
	end
end

function InfoEquip.syncRemove(data)
	dump(data, "$$$ InfoEquip.syncRemove")

	local teamChanged = false
	local changedIdStack = {}

	for i, id in ipairs(data.list) do
		if rawData[id] then
			changedIdStack[id] = rawData[id]
			rawData[id] = nil
		end
	end

	ManagerInfo.dataChange("equip", changedIdStack)
end

function InfoEquip.getIDBybaseID(baseID)
	for id, equipInfo in pairs(rawData) do
		if equipInfo.base_id == baseID then
			return equipInfo.id
		end
	end
end

function InfoEquip.getInfo(equipID)
	return rawData[equipID]
end

function InfoEquip.isEquipLevelAvailable(heroInfo, equipInfo)
	local equipData = CsvParser.getCsvData("equip", equipInfo.base_id)

	return equipData.level <= heroInfo.level
end

function InfoEquip.checkEquipsOnHero(heroID, idMap)
	for id, equipInfo in pairs(rawData) do
		if equipInfo.hero_id == heroID and idMap[equipInfo.id] then
			return true
		end

		if equipInfo.show_hero_id == heroID and idMap[equipInfo.id] then
			return true
		end
	end

	return false
end

function InfoEquip.checkEquipForHero(heroInfo, equipInfo)
	local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)
	local equipClass = heroCSV.equip_class
	equipClass = string.split(equipClass, ",")
	local equipClassMap = {}

	for i = 1, #equipClass do
		equipClassMap[tonumber(equipClass[i])] = true
	end

	local equipData = CsvParser.getCsvData("equip", equipInfo.base_id)

	if equipData.avatar_gender ~= "" then
		local genderArr = string.split(tostring(equipData.avatar_gender), ",")
		local genderMap = {}

		for i, v in ipairs(genderArr) do
			if tonumber(v) then
				genderMap[tonumber(v)] = true
			end
		end

		if not genderMap[heroInfo.gender] then
			return false
		end
	end

	if equipData.avatar_job ~= "" then
		local jobArr = string.split(tostring(equipData.avatar_job), ",")
		local jobMap = {}

		for i, v in ipairs(jobArr) do
			if tonumber(v) then
				jobMap[tonumber(v)] = true
			end
		end

		if not jobMap[heroCSV.class] then
			return false
		end
	end

	if (equipInfo.hero_id == 0 or not InfoEquip.getEquipedHero(equipInfo)) and (equipInfo.show_hero_id == 0 or not InfoEquip.getShowEquipedHero(equipInfo)) and equipClassMap[equipData.class] then
		return true
	end
end

function InfoEquip.getShowEquipListOnHero(heroID)
	local arr = {}

	if type(heroID) == "table" then
		heroID = heroID.id
	end

	if not empty(heroID) then
		for id, equipInfo in pairs(rawData) do
			if equipInfo.show_hero_id == heroID then
				table.insert(arr, equipInfo)
			end
		end
	end

	table.sort(arr, function (a, b)
		local equipDataA = CsvParser.getCsvData("equip", a.base_id)
		local equipDataB = CsvParser.getCsvData("equip", b.base_id)

		return equipDataA.equip_pos < equipDataB.equip_pos
	end)

	return arr
end

function InfoEquip.getEquipListOnHero(heroID)
	local arr = {}

	if type(heroID) == "table" then
		heroID = heroID.id
	end

	if not empty(heroID) then
		for id, equipInfo in pairs(rawData) do
			if equipInfo.hero_id == heroID then
				table.insert(arr, equipInfo)
			end
		end
	end

	table.sort(arr, function (a, b)
		local equipDataA = CsvParser.getCsvData("equip", a.base_id)
		local equipDataB = CsvParser.getCsvData("equip", b.base_id)

		return equipDataA.equip_pos < equipDataB.equip_pos
	end)

	return arr
end

function InfoEquip.getDisplayListOnHero(heroID)
	local equipMap = {}

	if type(heroID) == "table" then
		heroID = heroID.id
	end

	if not empty(heroID) then
		for id, equipInfo in pairs(rawData) do
			if equipInfo.show_hero_id == heroID then
				local equipData = CsvParser.getCsvData("equip", equipInfo.base_id)
				equipMap[equipData.equip_pos] = equipInfo.base_id
			end

			if equipInfo.hero_id == heroID then
				local equipData = CsvParser.getCsvData("equip", equipInfo.base_id)

				if not equipMap[equipData.equip_pos] then
					equipMap[equipData.equip_pos] = equipInfo.base_id
				end
			end
		end
	end

	local idArr = {}

	for i, pos in ipairs(GameConfig.display_equip_arr) do
		if equipMap[pos] then
			table.insert(idArr, pos .. "_" .. equipMap[pos])
		end
	end

	return table.concat(idArr, "~")
end

function InfoEquip.checkEquipDuplicated()
	local existMap = {}
	local duplicated = {}

	for id, equipInfo in pairs(rawData) do
		if equipInfo.hero_id ~= 0 then
			local equipData = CsvParser.getCsvData("equip", equipInfo.base_id)
			local code = equipInfo.hero_id .. "_" .. equipData.equip_pos

			if duplicated[code] then
				table.insert(duplicated[code], equipInfo.id)
			elseif not existMap[code] then
				existMap[code] = equipInfo.id
			else
				duplicated[code] = {}

				table.insert(duplicated[code], existMap[code])
				table.insert(duplicated[code], equipInfo.id)

				existMap[code] = nil
			end
		end
	end

	if not empty(duplicated) then
		dump(duplicated, "$$$ checkEquipDuplicated")
	end

	InfoEquip.buffScoreStart()

	for code, idArr in pairs(duplicated) do
		table.sort(idArr, function (a, b)
			local equipInfoA = InfoEquip.getInfo(a)
			local equipInfoB = InfoEquip.getInfo(b)
			local scoreA = InfoEquip.getScore(equipInfoA)
			local scoreB = InfoEquip.getScore(equipInfoB)

			return scoreB < scoreA
		end)

		for i = 2, #idArr do
			local id = idArr[i]

			InfoEquip.equipoff(id)
		end
	end

	InfoEquip.buffScoreOver()
end

function InfoEquip.getShowEquipOnHero(heroID, equipPos)
	if type(heroID) == "table" and heroID.showEquips then
		local heroInfo = heroID

		for i, v in ipairs(heroInfo.showEquips) do
			local equipData = CsvParser.getCsvData("equip", v.base_id)

			if equipData and equipData.equip_pos == equipPos then
				return v
			end
		end
	else
		if type(heroID) == "table" then
			heroID = heroID.id
		end

		if not empty(heroID) then
			for id, equipInfo in pairs(rawData) do
				local equipData = CsvParser.getCsvData("equip", equipInfo.base_id)

				if equipInfo.show_hero_id == heroID and equipData.equip_pos == equipPos then
					return equipInfo
				end
			end
		end
	end
end

function InfoEquip.getEquipOnHero(heroID, equipPos)
	if type(heroID) == "table" and heroID.equips then
		local heroInfo = heroID

		for i, v in ipairs(heroInfo.equips) do
			local equipData = CsvParser.getCsvData("equip", v.base_id)

			if equipData and equipData.equip_pos == equipPos then
				return v
			end
		end
	else
		if type(heroID) == "table" then
			heroID = heroID.id
		end

		if not empty(heroID) then
			for id, equipInfo in pairs(rawData) do
				local equipData = CsvParser.getCsvData("equip", equipInfo.base_id)

				if equipInfo.hero_id == heroID and equipData.equip_pos == equipPos then
					return equipInfo
				end
			end
		end
	end
end

function InfoEquip.equipon(equipID, heroID, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			local heroInfo = InfoHero.getHero(heroID)

			if heroInfo and heroInfo.pos > 0 then
				local equipInfo = rawData[equipID]

				if equipInfo then
					local equipData = CsvParser.getCsvData("equip", equipInfo.base_id)

					if (equipData.equip_pos == 1 or equipData.equip_pos >= 5) and OnlineCamp.inRoom() then
						OnlineCamp.updateAppear(heroID)
					end
				end
			end

			InfoFirstAchieve.fxxkCheck300(heroInfo.id)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("equip_on", {
		hero_id = heroID,
		equip_id = equipID
	}, callback)
end

function InfoEquip.equipoff(equipID, bag_index, onSuccess, onFailure)
	local needUpdateAppear = false
	local heroID = nil
	local equipInfo = rawData[equipID]

	if equipInfo and equipInfo.hero_id > 0 then
		heroID = equipInfo.hero_id
		local heroInfo = InfoHero.getHero(heroID)

		if heroInfo and heroInfo.pos > 0 then
			local equipData = CsvParser.getCsvData("equip", equipInfo.base_id)

			if (equipData.equip_pos == 1 or equipData.equip_pos >= 5) and OnlineCamp.inRoom() then
				needUpdateAppear = true
			end
		end
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			if needUpdateAppear then
				OnlineCamp.updateAppear(heroID)
			end

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("equip_off", {
		equip_id = equipID,
		bag_index = bag_index
	}, callback)
end

function InfoEquip.showEquipon(equipID, heroID, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			local heroInfo = InfoHero.getHero(heroID)

			if heroInfo and heroInfo.pos > 0 then
				local equipInfo = rawData[equipID]

				if equipInfo then
					local equipData = CsvParser.getCsvData("equip", equipInfo.base_id)

					if equipData.equip_pos >= 5 and OnlineCamp.inRoom() then
						OnlineCamp.updateAppear(heroID)
					end
				end
			end

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("equip_show_on", {
		hero_id = heroID,
		equip_id = equipID
	}, callback)
end

function InfoEquip.showEquipoff(equipID, bag_index, onSuccess, onFailure)
	local needUpdateAppear = false
	local heroID = nil
	local equipInfo = rawData[equipID]

	if equipInfo and equipInfo.show_hero_id > 0 then
		heroID = equipInfo.show_hero_id
		local heroInfo = InfoHero.getHero(heroID)

		if heroInfo and heroInfo.pos > 0 then
			local equipData = CsvParser.getCsvData("equip", equipInfo.base_id)

			if (equipData.equip_pos == 5 or equipData.equip_pos == 6 or equipData.equip_pos == 7) and OnlineCamp.inRoom() then
				needUpdateAppear = true
			end
		end
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			if needUpdateAppear then
				OnlineCamp.updateAppear(heroID)
			end

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("equip_show_off", {
		equip_id = equipID,
		bag_index = bag_index
	}, callback)
end

function InfoEquip.identify(equipID, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Http.request("equip/identify", {
		equip_id = equipID
	}, callback)
end

function InfoEquip.needIdentify(equipInfo)
	if equipInfo.identified == 0 and not empty(equipInfo.affix_quality) then
		return true
	end

	return false
end

function InfoEquip.getIdentifyCost(equipInfo)
	local equipData = CsvParser.getCsvData("equip", equipInfo.base_id)
	local needCrys = (equipData.level + 10) * InfoEquip.getQuality(equipInfo)

	return {
		{
			id = GameConfig.crystal_item,
			num = needCrys
		}
	}
end

function InfoEquip.getNameDisplay(equipInfo, adjustColor)
	local equipData = CsvParser.getCsvData("equip", equipInfo.base_id)
	local name = equipData.name

	if empty(equipData.suit_id) then
		if equipInfo.best_prefix and equipInfo.best_prefix ~= 0 and equipInfo.best_suffix and equipInfo.best_suffix ~= 0 then
			local prefix = CsvParser.getCsvData("affix", equipInfo.best_prefix)
			local suffix = CsvParser.getCsvData("affix", equipInfo.best_suffix)
			name = StringUtil.replace(Localization.getSrcText("{3}之{2}的{1}"), name, prefix.name, suffix.name)
		elseif equipInfo.best_prefix and equipInfo.best_prefix ~= 0 then
			local prefix = CsvParser.getCsvData("affix", equipInfo.best_prefix)
			name = StringUtil.replace(Localization.getSrcText("{2}的{1}"), name, prefix.name)
		elseif equipInfo.best_suffix and equipInfo.best_suffix ~= 0 then
			local suffix = CsvParser.getCsvData("affix", equipInfo.best_suffix)
			name = StringUtil.replace(Localization.getSrcText("{2}之{1}"), name, suffix.name)
		end
	end

	local names = {
		name
	}
	local affixColor = InfoEquip.getQualityColor(equipInfo)
	local outline, styles = nil

	if affixColor then
		styles = {
			{
				color = affixColor,
				outline = outline
			}
		}
	else
		styles = {
			{
				outline = 0
			}
		}
	end

	return names, styles, equipInfo.quality
end

function InfoEquip.getQualityColor(equipInfo)
	local equipData = CsvParser.getCsvData("equip", equipInfo.base_id)

	if equipInfo.dust_id and equipInfo.dust_id > 0 then
		return Style.fontDust
	elseif not empty(equipData.suit_id) then
		return Style.fontSuit
	else
		local quality = equipInfo.quality

		if equipData.is_avatar == 1 then
			quality = equipData.quality_min
		end

		local affixColor = InfoHero.getQualityColor(quality)

		return affixColor
	end
end

function InfoEquip.getQuality(equipInfo)
	local equipData = CsvParser.getCsvData("equip", equipInfo.base_id)
	local quality = equipInfo.quality

	if equipData.is_avatar == 1 then
		quality = equipData.quality_min
	end

	return quality
end

function InfoEquip.getQualityExcellent(equipInfo)
	local quality = InfoEquip.getQuality(equipInfo)

	if not empty(equipInfo.excellent) then
		quality = quality + equipInfo.excellent
	end

	return quality
end

local classEquipPos = {
	1,
	1,
	1,
	2,
	2,
	2,
	3,
	4
}

function InfoEquip.getClassDesc(equipInfo)
	local equipData = CsvParser.getCsvData("equip", equipInfo.base_id or equipInfo.id)
	local classData = CsvParser.getCsvData("equip_class", equipData.class)

	return classData.name
end

function InfoEquip.getEquipForPlayer(equipsStr)
	local equipArr = string.split(equipsStr, ",")
	local equipClass = CsvParser.getCsvData("hero", InfoHero.getHero().base_id).equip_class
	equipClass = string.split(equipClass, ",")
	local equipClassMap = {}

	for i = 1, #equipClass do
		equipClassMap[tonumber(equipClass[i])] = true
	end

	for i = 1, #equipArr do
		local equipData = CsvParser.getCsvData("equip", equipArr[i])

		if equipClassMap[equipData.class] then
			return equipData
		end
	end
end

function InfoEquip.getListForRune()
	local sortList = {}

	for id, equipInfo in pairs(rawData) do
		local equipData = CsvParser.getCsvData("equip", equipInfo.base_id)

		if not InfoEquip.needIdentify(rawData) then
			-- Nothing
		end
	end

	local function sortMethod(a, b)
		local idA = a.hero_id
		local idB = b.hero_id

		if idA ~= 0 or idB ~= 0 then
			if idA == 0 then
				return false
			end

			if idB == 0 then
				return true
			end

			if idA ~= idB then
				return idA < idB
			end
		end

		local equipDataA = CsvParser.getCsvData("equip", a.base_id)
		local equipDataB = CsvParser.getCsvData("equip", b.base_id)

		if equipDataA.equip_pos == equipDataB.equip_pos then
			local affixA = InfoEquip.getQuality(a)
			local affixB = InfoEquip.getQuality(b)

			if affixA == affixB then
				if equipDataA.level == equipDataB.level then
					return equipDataA.id < equipDataB.id
				else
					return equipDataB.level < equipDataA.level
				end
			else
				return affixB < affixA
			end
		else
			return equipDataA.equip_pos < equipDataB.equip_pos
		end
	end

	table.sort(sortList, sortMethod)

	return sortList
end

function InfoEquip.getOwnerName(equipInfo)
	if equipInfo.hero_id ~= 0 then
		local heroInfo = InfoHero.getHero(equipInfo.hero_id)

		if heroInfo and heroInfo.pos > 0 then
			return InfoHero.getName(heroInfo)
		end
	end
end

function InfoEquip.getBagList()
	local arr = {}

	for id, equipInfo in pairs(rawData) do
		if equipInfo.hero_id == 0 and equipInfo.show_hero_id == 0 and equipInfo.in_dungeon == 1 then
			table.insert(arr, equipInfo)
		end
	end

	return arr
end

local scoreBuff = nil

function InfoEquip.buffScoreStart()
	scoreBuff = {}
end

function InfoEquip.buffScoreOver()
	scoreBuff = nil
end

function InfoEquip.getScore(equipInfo, noEnhance, valueModify)
	if scoreBuff and scoreBuff[equipInfo.id] then
		return scoreBuff[equipInfo.id]
	end

	local attr = CombatAttr.getEquipAttr(equipInfo, nil, noEnhance)
	local attr_raw = CsvParser.getCsvRaw("attr")
	local addTotal = 0

	for k, v in pairs(attr_raw) do
		if attr[k] and v.ability_value1 ~= 0 then
			if valueModify then
				addTotal = addTotal + valueModify(k, attr[k] * v.ability_value1)
			else
				addTotal = addTotal + attr[k] * v.ability_value1
			end
		end
	end

	local score = math.floor(addTotal)

	if scoreBuff then
		scoreBuff[equipInfo.id] = score
	end

	return score
end

local equipClassSort = {
	1,
	2,
	3,
	6,
	5,
	4,
	7,
	8,
	10,
	11,
	12,
	9,
	13,
	14,
	15,
	16,
	17,
	18,
	19,
	20
}

function InfoEquip.getClassSort()
	local equipClassSortMap = {}

	for i, v in ipairs(equipClassSort) do
		equipClassSortMap[v] = i
	end

	return equipClassSortMap
end

local function defaultSort(a, b)
	local equipClassSortMap = InfoEquip.getClassSort()
	local dataA = CsvParser.getCsvData("equip", a.info.base_id)
	local dataB = CsvParser.getCsvData("equip", b.info.base_id)
	local classSortA = equipClassSortMap[dataA.class]
	local classSortB = equipClassSortMap[dataB.class]

	if classSortA == classSortB then
		local qualityA = a.info.quality
		local qualityB = b.info.quality

		if not empty(dataA.suit_id) then
			qualityA = qualityA + 0.1
		end

		if not empty(dataB.suit_id) then
			qualityB = qualityB + 0.1
		end

		if not empty(a.info.excellent) then
			qualityA = qualityA + a.info.excellent * 0.1
		end

		if not empty(b.info.excellent) then
			qualityB = qualityB + b.info.excellent * 0.1
		end

		if qualityA == qualityB then
			local scoreA = InfoEquip.getScore(a.info)
			local scoreB = InfoEquip.getScore(b.info)

			if scoreA == scoreB then
				if a.info.base_id == b.info.base_id then
					return a.info.id < b.info.id
				else
					return a.info.base_id < b.info.base_id
				end
			else
				return scoreB < scoreA
			end
		else
			return qualityB < qualityA
		end
	else
		return classSortA < classSortB
	end
end

function InfoEquip.getSelectList(filterFunc)
	local arr = {}

	for id, equipInfo in pairs(rawData) do
		local equipCSV = CsvParser.getCsvData("equip", equipInfo.base_id)

		if equipCSV.is_avatar ~= 1 then
			local affixArr = InfoEquip.getAffixList(equipInfo)

			if #affixArr > 0 then
				local tempData = {
					type = DropManager.TYPE.EQUIP,
					info = equipInfo,
					heroInfo = InfoEquip.getEquipedHero(equipInfo)
				}

				if not filterFunc or filterFunc(tempData) then
					table.insert(arr, tempData)
				end
			end
		end
	end

	InfoEquip.sortForgableList(arr)

	return arr
end

function InfoEquip.getAllList(filterFunc, sortFunc)
	local arr = {}

	for id, equipInfo in pairs(rawData) do
		local tempData = {
			type = DropManager.TYPE.EQUIP,
			info = equipInfo
		}

		if not filterFunc or filterFunc(tempData) then
			table.insert(arr, tempData)
		end
	end

	local sortMethod = sortFunc or defaultSort

	InfoEquip.buffScoreStart()
	table.sort(arr, sortMethod)
	InfoEquip.buffScoreOver()

	return arr
end

function InfoEquip.getWareList(filterFunc, sortFunc)
	local arr = {}

	for id, equipInfo in pairs(rawData) do
		if not InfoEquip.getEquipedHero(equipInfo) then
			local tempData = {
				type = DropManager.TYPE.EQUIP,
				info = equipInfo
			}

			if not filterFunc or filterFunc(tempData) then
				table.insert(arr, tempData)
			end
		end
	end

	local sortMethod = sortFunc or defaultSort

	InfoEquip.buffScoreStart()
	table.sort(arr, sortMethod)
	InfoEquip.buffScoreOver()

	return arr
end

function InfoEquip.getShowList()
	local arr = {}

	for id, equipInfo in pairs(rawData) do
		local tempData = {
			type = DropManager.TYPE.EQUIP,
			info = equipInfo
		}

		table.insert(arr, tempData)
	end

	InfoEquip.buffScoreStart()
	table.sort(arr, function (a, b)
		local equipInfoA = a.info
		local equipInfoB = b.info
		local equipA = InfoEquip.getEquipedHero(equipInfoA) ~= nil and 2 or 0
		local equipB = InfoEquip.getEquipedHero(equipInfoB) ~= nil and 2 or 0

		if equipA == equipB then
			if equipInfoA.locked == equipInfoB.locked then
				if equipInfoA.enhance_level == equipInfoB.enhance_level then
					if equipInfoA.quality == equipInfoB.quality then
						local scoreA = InfoEquip.getScore(equipInfoA)
						local scoreB = InfoEquip.getScore(equipInfoB)

						if scoreA == scoreB then
							return equipInfoA.id < equipInfoB.id
						else
							return scoreB < scoreA
						end
					else
						return equipInfoB.quality < equipInfoA.quality
					end
				else
					return equipInfoB.enhance_level < equipInfoA.enhance_level
				end
			else
				return equipInfoB.locked < equipInfoA.locked
			end
		else
			return equipB < equipA
		end
	end)
	InfoEquip.buffScoreOver()

	return arr
end

function InfoEquip.getShowEquipedHero(equipInfo)
	if not empty(equipInfo.show_hero_id) then
		return InfoHero.getHero(equipInfo.show_hero_id)
	end
end

function InfoEquip.getEquipedHero(equipInfo)
	if not empty(equipInfo.hero_id) then
		return InfoHero.getHero(equipInfo.hero_id)
	end
end

function InfoEquip.isEnhanceMat(data)
	if data.type == DropManager.TYPE.EQUIP then
		if InfoEquip.getEquipedHero(data.info) then
			return false
		end

		if data.info.locked == 1 then
			return false
		end
	end

	return true
end

function InfoEquip.sortForgableList(arr)
	InfoEquip.buffScoreStart()
	table.sort(arr, function (a, b)
		local equipInfoA = a.info
		local equipInfoB = b.info
		local firstA = 1
		local firstB = 1
		local heroPosA = 1000
		local heroPosB = 1000

		if a.type == DropManager.TYPE.EQUIP then
			if a.heroInfo then
				if a.heroInfo.pos > 0 then
					firstA = 3
				else
					firstA = 2
				end

				heroPosA = a.heroInfo.pos
			else
				firstA = 0
			end
		end

		if b.type == DropManager.TYPE.EQUIP then
			if b.heroInfo then
				if b.heroInfo.pos > 0 then
					firstB = 3
				else
					firstB = 2
				end

				heroPosB = b.heroInfo.pos
			else
				firstB = 0
			end
		end

		if firstA == firstB then
			if heroPosA == heroPosB then
				if a.type == DropManager.TYPE.EQUIP then
					if equipInfoA.locked == equipInfoB.locked then
						if equipInfoA.enhance_level == equipInfoB.enhance_level then
							if equipInfoA.quality == equipInfoB.quality then
								local scoreA = InfoEquip.getScore(equipInfoA)
								local scoreB = InfoEquip.getScore(equipInfoB)

								if scoreA == scoreB then
									return equipInfoA.id < equipInfoB.id
								else
									return scoreB < scoreA
								end
							else
								return equipInfoB.quality < equipInfoA.quality
							end
						else
							return equipInfoB.enhance_level < equipInfoA.enhance_level
						end
					else
						return equipInfoB.locked < equipInfoA.locked
					end
				else
					local itemInfoA = a.info
					local itemInfoB = b.info
					local itemDataA = CsvParser.getCsvData("item", itemInfoA.base_id)
					local itemDataB = CsvParser.getCsvData("item", itemInfoB.base_id)

					return itemDataB.quality < itemDataA.quality
				end
			else
				return heroPosA < heroPosB
			end
		else
			return firstB < firstA
		end
	end)
	InfoEquip.buffScoreOver()

	return arr
end

function InfoEquip.getEnhanceList(cols)
	local rowOccupied = {}
	local arr = {}

	for id, equipInfo in pairs(rawData) do
		local equipCSV = CsvParser.getCsvData("equip", equipInfo.base_id)

		if equipCSV.is_avatar ~= 1 then
			local tempData = {
				type = DropManager.TYPE.EQUIP,
				info = equipInfo,
				heroInfo = InfoEquip.getEquipedHero(equipInfo)
			}

			table.insert(arr, tempData)
		end
	end

	local stoneItems = InfoItem.getList(1, 11)

	for i, itemInfo in ipairs(stoneItems) do
		local tempData = {
			type = DropManager.TYPE.ITEM,
			info = itemInfo
		}

		table.insert(arr, tempData)
	end

	return InfoEquip.sortForgableList(arr)
end

function InfoEquip.getGemed(equipInfo)
	for i = 1, GameConfig.equip_gem_max do
		if equipInfo["gem" .. i] ~= 0 then
			return 1
		end
	end

	return 0
end

function InfoEquip.getGemableList()
	local arr = {}

	for id, equipInfo in pairs(rawData) do
		local equipCSV = CsvParser.getCsvData("equip", equipInfo.base_id)

		if equipCSV.is_avatar ~= 1 and equipInfo.slot > 0 then
			local tempData = {
				type = DropManager.TYPE.EQUIP,
				info = equipInfo,
				heroInfo = InfoEquip.getEquipedHero(equipInfo)
			}

			table.insert(arr, tempData)
		end
	end

	return InfoEquip.sortForgableList(arr)
end

function InfoEquip.getReformList()
	local arr = {}

	for id, equipInfo in pairs(rawData) do
		local equipCSV = CsvParser.getCsvData("equip", equipInfo.base_id)

		if equipCSV.is_avatar ~= 1 then
			local affixArr = InfoEquip.getAffixList(equipInfo)

			if #affixArr > 0 then
				local tempData = {
					type = DropManager.TYPE.EQUIP,
					info = equipInfo,
					heroInfo = InfoEquip.getEquipedHero(equipInfo)
				}

				table.insert(arr, tempData)
			end
		end
	end

	return InfoEquip.sortForgableList(arr)
end

function InfoEquip.getEnhanceMax()
	local buildingCSV = InfoBuilding.getBuildingData(InfoBuilding.TAG.FORGE)

	if buildingCSV then
		return buildingCSV.value1
	end

	return 0
end

function InfoEquip.enhance(equipID, matItems, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if CONFIG.is_ta then
				local equipInfo = InfoEquip.getInfo(equipID)
				local params = {
					equip_id = equipID,
					after_level = equipInfo.enhance_level or 0
				}

				TaHelper.taTrack("equip_strength", params)
			end

			local equipInfo = InfoEquip.getInfo(equipID)
			local heroInfo = InfoEquip.getEquipedHero(equipInfo)

			if heroInfo then
				InfoFirstAchieve.fxxkCheck300(heroInfo.id)
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	local mats = {}

	for i, matItem in ipairs(matItems) do
		if matItem.type == DropManager.TYPE.EQUIP then
			table.insert(mats, {
				type = matItem.type,
				equip_id = matItem.info.id
			})
		elseif matItem.type == DropManager.TYPE.ITEM then
			table.insert(mats, {
				type = matItem.type,
				item_id = matItem.info.base_id,
				item_num = matItem.info.num
			})
		end
	end

	Connection.request("equip_enhance", {
		equip_id = equipID,
		mats = mats
	}, callback)
end

function InfoEquip.getNeedSaveList()
	local arr = {}

	for id, equipInfo in pairs(rawData) do
		if equipInfo.saved ~= 1 then
			local tempData = {
				type = DropManager.TYPE.EQUIP,
				info = equipInfo
			}

			table.insert(arr, tempData)
		end
	end

	table.sort(arr, function (a, b)
		local equipInfoA = a.info
		local equipInfoB = b.info
		local equipedA = InfoEquip.getEquipedHero(equipInfoA) ~= nil and 1 or 0
		local equipedB = InfoEquip.getEquipedHero(equipInfoB) ~= nil and 1 or 0

		if equipedA == equipedB then
			if equipInfoA.enhance_level == equipInfoB.enhance_level then
				if equipInfoA.quality == equipInfoB.quality then
					return equipInfoA.id < equipInfoB.id
				else
					return equipInfoB.quality < equipInfoA.quality
				end
			else
				return equipInfoB.enhance_level < equipInfoA.enhance_level
			end
		else
			return equipedB < equipedA
		end
	end)

	return arr
end

function InfoEquip.getUnsaved()
	local arr = {}

	for id, equipInfo in pairs(rawData) do
		if equipInfo.saved ~= 1 then
			table.insert(arr, equipInfo)
		end
	end

	return arr
end

function InfoEquip.getIsnew()
	local arr = {}

	for id, equipInfo in pairs(rawData) do
		if equipInfo.is_new == 1 then
			table.insert(arr, equipInfo)
		end
	end

	return arr
end

function InfoEquip.gemOn(equipID, index, item_id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if CONFIG.is_ta then
				local equipInfo = InfoEquip.getInfo(equipID)
				local params = {
					inlay_type = 1,
					stone_id = item_id,
					equip_id = equipID
				}

				TaHelper.taTrack("stone_inlay", params)
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("equip_gem_onoff", {
		equip_id = equipID,
		index = index,
		item_id = item_id
	}, callback)
end

function InfoEquip.gemOff(equipID, index, onSuccess, onFailure)
	local equipInfo = InfoEquip.getInfo(equipID)
	local preGemID = equipInfo["gem" .. index]

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if CONFIG.is_ta then
				local params = {
					inlay_type = 2,
					stone_id = preGemID,
					equip_id = equipID
				}

				TaHelper.taTrack("stone_inlay", params)
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("equip_gem_onoff", {
		item_id = 0,
		equip_id = equipID,
		index = index
	}, callback)
end

local affixMainAttrMap = {}

function InfoEquip.getAffixMainAttr(affixData)
	if not affixMainAttrMap[affixData.id] then
		local prefix, attr = nil
		local desc = StringUtil.replaceTag(affixData.desc, function (str, embedded, tag)
			prefix = string.sub(str, 1, 10)
			local index = string.sub(str, 11)

			if prefix == "add_value_" then
				attr = affixData["attr_add_" .. index]
			elseif prefix == "mul_value_" then
				attr = affixData["attr_mul_" .. index]
			end
		end, affixData)
		affixMainAttrMap[affixData.id] = {
			attr = attr,
			prefix = prefix
		}
	end

	return affixMainAttrMap[affixData.id].prefix, affixMainAttrMap[affixData.id].attr
end

function InfoEquip.replaceAttrDesc(str, random, affixData, equipInfo, seed, floatNum)
	local agenData = CsvParser.getCsvData("affix_gen", affixData.quality)
	local prefix = string.sub(str, 1, 10)
	local index = string.sub(str, 11)

	if prefix == "add_value_" then
		if not empty(affixData["attr_add_" .. index]) then
			local attrStr = affixData["attr_add_" .. index]
			local equipAffixLevel = CsvParser.getCsvData("affix_add_level", equipInfo.level)[attrStr]
			local value = nil

			if not empty(equipInfo.excellent) then
				value = SheetUtil.getLinearNumber(agenData.affix_attr_range, seed / 65536)
			else
				value = SheetUtil.getNumber(agenData.affix_attr_range, random)
			end

			local valueAdd = equipAffixLevel * value * agenData.affix_quality_ratio / 100

			if not empty(floatNum) then
				local floatBase = math.pow(10, floatNum)

				return math.round(valueAdd * floatBase) / floatBase
			else
				return math.ceil(valueAdd)
			end
		end
	elseif prefix == "mul_value_" and not empty(affixData["attr_mul_" .. index]) then
		local attrStr = affixData["attr_mul_" .. index]
		local equipAffixLevel = CsvParser.getCsvData("affix_mul_level", equipInfo.level)[attrStr]
		local value = nil

		if not empty(equipInfo.excellent) then
			value = SheetUtil.getLinearNumber(agenData.affix_attr_range, seed / 65536)
		else
			value = SheetUtil.getNumber(agenData.affix_attr_range, random)
		end

		local valueMul = equipAffixLevel * value * agenData.affix_quality_ratio / 100

		if not empty(floatNum) then
			local floatBase = math.pow(10, floatNum)

			return math.round(valueMul * floatBase) / floatBase
		else
			return math.ceil(valueMul)
		end
	end
end

function InfoEquip.getAffixList(equipInfo)
	local arr = {}

	for i = 1, GameConfig.equip_affix_max do
		local prefix = equipInfo["prefix_" .. i]
		local preran = equipInfo["preran_" .. i]

		if prefix ~= 0 then
			local random = Random.new(preran)
			local affixData = CsvParser.getCsvData("affix", prefix)
			local value = nil
			local desc = StringUtil.replaceTag(affixData.desc, function (str)
				value = InfoEquip.replaceAttrDesc(str, random, affixData, equipInfo, preran, affixData.decimal_len)

				return value
			end, affixData)

			table.insert(arr, {
				pos = 1,
				data = affixData,
				desc = desc,
				index = i,
				value = value,
				equipQuality = equipInfo.quality,
				equipLevel = equipInfo.level
			})
		end
	end

	for i = 1, GameConfig.equip_affix_max do
		local suffix = equipInfo["suffix_" .. i]
		local sufran = equipInfo["sufran_" .. i]

		if suffix ~= 0 then
			local random = Random.new(sufran)
			local affixData = CsvParser.getCsvData("affix", suffix)
			local value = nil
			local desc = StringUtil.replaceTag(affixData.desc, function (str)
				value = InfoEquip.replaceAttrDesc(str, random, affixData, equipInfo, sufran, affixData.decimal_len)

				return value
			end, affixData)

			table.insert(arr, {
				pos = 2,
				data = affixData,
				desc = desc,
				index = i,
				value = value,
				equipQuality = equipInfo.quality,
				equipLevel = equipInfo.level
			})
		end
	end

	return arr
end

function InfoEquip.getAffixMinMax(quality, level, affixID)
	local affixData = CsvParser.getCsvData("affix", affixID)
	local affixGenMin = CsvParser.getCsvData("affix_gen", 0)
	local affixGenMax = CsvParser.getCsvData("affix_gen", CsvParser.getMaxID("affix_gen"))
	local prefix, attr = InfoEquip.getAffixMainAttr(affixData)
	local min, max, equipAffixLevel = nil

	if prefix == "add_value_" then
		equipAffixLevel = CsvParser.getCsvData("affix_add_level", level)[attr]
	elseif prefix == "mul_value_" then
		equipAffixLevel = CsvParser.getCsvData("affix_mul_level", level)[attr]
	end

	local _min, _ = SheetUtil.getMinMax(affixGenMin.affix_attr_range)
	local _, _max = SheetUtil.getMinMax(affixGenMax.affix_attr_range)
	min = math.ceil(_min * equipAffixLevel * affixGenMin.affix_quality_ratio / 100)
	max = math.ceil(_max * equipAffixLevel * affixGenMax.affix_quality_ratio / 100)

	return min, max
end

function InfoEquip.reform(equipID, lockArr, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if CONFIG.is_ta then
				local params = {
					equip_id = equipID
				}

				TaHelper.taTrack("equip_refine", params)
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("equip_reform", {
		equip_id = equipID,
		locked = lockArr
	}, callback)
end

function InfoEquip.getGemList(equipInfo)
	local arr = {}

	for i = 1, GameConfig.equip_gem_max do
		if equipInfo["gem" .. i] ~= 0 then
			table.insert(arr, equipInfo["gem" .. i])
		end
	end

	return arr
end

function InfoEquip.getGemAt(equipInfo, index)
	return equipInfo["gem" .. index]
end

function InfoEquip.count(notEquiped)
	local count = 0

	for id, equipInfo in pairs(rawData) do
		if not notEquiped or not InfoEquip.getEquipedHero(equipInfo) then
			count = count + 1
		end
	end

	local equip_count_max = CsvParser.getCsvData("config", "equip_count_max").value

	return count, equip_count_max
end

function InfoEquip.lock(equipID, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("equip_lock", {
		equip_id = equipID
	}, callback)
end

function InfoEquip.getIllutionList()
	local arr = {}

	for id, equipInfo in pairs(rawData) do
		local equipCSV = CsvParser.getCsvData("equip", equipInfo.base_id)

		if equipCSV.can_illusion == 1 then
			local tempData = {
				type = DropManager.TYPE.EQUIP,
				info = equipInfo,
				heroInfo = InfoEquip.getEquipedHero(equipInfo)
			}

			table.insert(arr, tempData)
		end
	end

	return InfoEquip.sortForgableList(arr)
end

function InfoEquip.getAvatar(equipInfo)
	local equipData = nil

	if not empty(equipInfo.illusion) then
		equipData = CsvParser.getCsvData("equip", equipInfo.illusion)
	else
		equipData = CsvParser.getCsvData("equip", equipInfo.base_id)
	end

	if not empty(equipData.avatar) then
		return equipData.avatar, equipData.avatar_id
	end
end

function InfoEquip.getBestExist(baseID)
	local bestLevel = nil

	for id, equipInfo in pairs(rawData) do
		if equipInfo.base_id == baseID and (not bestLevel or bestLevel < equipInfo.level) then
			bestLevel = equipInfo.level
		end
	end

	return bestLevel
end

function InfoEquip.initForge()
	local forgeEquipMaps = CacheData.get("InfoEquip_forgeEquipMaps")

	if not forgeEquipMaps then
		local forgeEquipMaps = {}
		local forgeSuitMap = {}
		local forgeEquipClassMap = {}
		local csvList = CsvParser.getCsvList("equip")

		for i, csv in ipairs(csvList) do
			if not empty(csv.forge_item) then
				if not forgeEquipMaps[csv.forge_item] then
					forgeEquipMaps[csv.forge_item] = {}
				end

				table.insert(forgeEquipMaps[csv.forge_item], csv)

				if not empty(csv.suit_id) then
					forgeSuitMap[csv.forge_item] = csv.suit_id
				end

				if not forgeEquipClassMap[csv.forge_item] then
					forgeEquipClassMap[csv.forge_item] = {}
				end

				forgeEquipClassMap[csv.forge_item][csv.class] = csv
			end
		end

		CacheData.set("InfoEquip_forgeEquipMaps", forgeEquipMaps)
		CacheData.set("InfoEquip_forgeSuitMap", forgeSuitMap)
		CacheData.set("InfoEquip_forgeEquipClassMap", forgeEquipClassMap)
	end
end

function InfoEquip.getForgeSuit(forge_item)
	InfoEquip.initForge()

	local forgeSuitMap = CacheData.get("InfoEquip_forgeSuitMap")

	return forgeSuitMap[forge_item]
end

function InfoEquip.getForgeEquips(forge_item)
	InfoEquip.initForge()

	local forgeEquipMaps = CacheData.get("InfoEquip_forgeEquipMaps")

	return forgeEquipMaps[forge_item]
end

function InfoEquip.getForgeClassMap(forge_item)
	InfoEquip.initForge()

	local forgeEquipClassMap = CacheData.get("InfoEquip_forgeEquipClassMap")

	return forgeEquipClassMap[forge_item] or {}
end

function InfoEquip.getSuitCount(forge_item)
	InfoEquip.initForge()

	local forgeSuitMap = CacheData.get("InfoEquip_forgeSuitMap")
	local suitID = forgeSuitMap[forge_item]

	if suitID then
		local suitCSV = CsvParser.getCsvData("suit", suitID)
		local count = 0
		local existMap = {}

		for id, equipInfo in pairs(rawData) do
			local equipCSV = CsvParser.getCsvData("equip", equipInfo.base_id)

			if equipCSV.suit_id == suitID and not existMap[equipCSV.equip_pos] then
				existMap[equipCSV.equip_pos] = true
				count = count + 1
			end
		end

		return count, suitCSV.suit_max
	end
end

function InfoEquip.getForgeList()
	local csvList = CsvParser.getCsvList("item", nil, {
		type = 33
	})
	local arr = {}

	for i, csv in ipairs(csvList) do
		if InfoItem.getNum(csv.id) > 0 then
			local equips = InfoEquip.getForgeEquips(csv.id)

			if equips and #equips > 0 then
				table.insert(arr, csv)
			end
		end
	end

	table.sort(arr, function (a, b)
		if a.subtype == b.subtype then
			return b.id < a.id
		else
			return b.subtype < a.subtype
		end
	end)

	return arr
end

function InfoEquip.getSampleEquip(baseID, isMinLevel)
	local equipCSV = CsvParser.getCsvData("equip", baseID)
	local equipInfo = {
		drop_rare = 0,
		dust_id = 0,
		identified = 0,
		drop_level = 0,
		slot_max = 0,
		ran = 0,
		best_suffix = 0,
		best_prefix = 0,
		slot = 0,
		base_id = baseID,
		quality = equipCSV.quality_min,
		level = isMinLevel and InfoDungeon.getMinEquipLevel() or InfoDungeon.getMaxEquipLevel(),
		equip_pos = equipCSV.equip_pos
	}

	for i = 1, GameConfig.equip_affix_max do
		equipInfo["prefix_" .. i] = 0
		equipInfo["preran_" .. i] = 0
		equipInfo["suffix_" .. i] = 0
		equipInfo["sufran_" .. i] = 0
	end

	for i = 1, GameConfig.equip_gem_max do
		equipInfo["gem" .. i] = 0
	end

	return equipInfo
end

function InfoEquip.getSuitCost(base_id, level)
	local equipData = CsvParser.getCsvData("equip", base_id)
	local equipBaseNum = CsvParser.getCsvData("equip_base_num", level)
	local num = equipData.suit_recovery * equipBaseNum.suit_exchange_ratio
	local plusData = InfoBuilding.getPlusData(InfoBuilding.TAG.FORGE, 102)

	if plusData then
		num = num * math.max(0, 1 - plusData.value1 / 100)
	end

	num = math.floor(num)

	return MathUtil.cutDigit(num, 2)
end

function InfoEquip.forge(base_id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("equip_forge", {
		base_id = base_id
	}, callback)
end

function InfoEquip.gemUpgrade(equip_id, gem_index, onSuccess, onFailure)
	print("$$$ InfoEquip.forge", equip_id, gem_index)

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("equip_gem_upgrade", {
		equip_id = equip_id,
		index = gem_index
	}, callback)
end

local dustBaseMap, dustAttrLimitCache = nil

function InfoEquip.initDust()
	dustBaseMap = {}
	local csvRaw = CsvParser.getCsvRaw("dust_attr_base_num")

	for k, v in pairs(csvRaw) do
		local code = v.dust_id .. "_" .. v.level
		dustBaseMap[code] = v
	end
end

function InfoEquip.getDustBase(equipInfo, index)
	local dust_id = equipInfo.dust_id
	local level = equipInfo["dust_level_" .. index]
	local code = dust_id .. "_" .. level

	return dustBaseMap[code]
end

function InfoEquip.getDustLimitAttr(equipInfo, index)
	if not dustAttrLimitCache then
		dustAttrLimitCache = {}
		local csvRaw = CsvParser.getCsvRaw("dust_attr_limit")

		for k, v in pairs(csvRaw) do
			if not dustAttrLimitCache[v.dust_attr_id] then
				dustAttrLimitCache[v.dust_attr_id] = {}
			end

			dustAttrLimitCache[v.dust_attr_id][v.limit] = v
		end
	end

	local dust_attr_id = equipInfo["dust_id_" .. index]
	local baseNum = InfoEquip.getDustBase(equipInfo, index)

	if baseNum then
		local limit = baseNum.limit

		if dustAttrLimitCache[dust_attr_id] then
			return dustAttrLimitCache[dust_attr_id][limit]
		end
	end
end

function InfoEquip.countDustAttr(equipInfo)
	local count = 0

	for i = 1, GameConfig.equip_dust_max do
		if equipInfo["dust_id_" .. i] > 0 then
			count = count + 1
		end
	end

	return count
end

function InfoEquip.dustRemake(equip_id, lock_arr, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "equip_dust_remake")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("equip_dust_remake", {
		equip_id = equip_id,
		lock_arr = lock_arr
	}, callback)
end

function InfoEquip.dustReplace(from_equip_id, from_attr_index, to_equip_id, to_attr_index, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "equip_dust_replace")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("equip_dust_replace", {
		from_equip_id = from_equip_id,
		from_attr_index = from_attr_index,
		to_equip_id = to_equip_id,
		to_attr_index = to_attr_index
	}, callback)
end

function InfoEquip.dustDisplace(from_equip_id, from_attr_index, to_equip_id, to_attr_index, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "equip_dust_displace")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("equip_dust_displace", {
		from_equip_id = from_equip_id,
		from_attr_index = from_attr_index,
		to_equip_id = to_equip_id,
		to_attr_index = to_attr_index
	}, callback)
end

function InfoEquip.dustDisplaceEnhance(from_equip_id, to_equip_id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "equip_dust_displace")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("equip_dust_displace_enhance", {
		from_equip_id = from_equip_id,
		to_equip_id = to_equip_id
	}, callback)
end

function InfoEquip.refinePreview(equip_id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("equip_dust_refine_preview", {
		equip_id = equip_id
	}, callback)
end

function InfoEquip.refineConfirm(equip_id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("equip_dust_refine_confirm", {
		equip_id = equip_id
	}, callback)
end

function InfoEquip.suitExcellentOpen(equip_id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("equip_suit_excellent_open", {
		equip_id = equip_id
	}, callback)
end

function InfoEquip.hasSuitExcellent(equipInfo)
	if not empty(equipInfo.excellent) then
		local excellentCSV = CsvParser.getCsvData("equip_excellent", equipInfo.excellent)

		return excellentCSV.suit_excellent == 1
	end

	return false
end

return InfoEquip
