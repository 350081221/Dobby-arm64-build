local require = require
local assert = assert
local ipairs = ipairs
local pairs = pairs
local floor = math.floor
local tostring = tostring
local setmetatable = setmetatable

local function f_min(a, b)
	return a < b
end

local function indexOf(t, v)
	for i = 1, #t do
		if t[i] == v then
			return i
		end
	end

	return nil
end

local function percolate_up(self, index)
	local pIndex = nil

	if index > 1 then
		pIndex = floor(index / 2)

		if self._heap[pIndex] then
			if not self.sort(self._heap[pIndex].value, self._heap[index].value) then
				self._heap[index] = self._heap[pIndex]
				self._heap[pIndex] = self._heap[index]

				percolate_up(self, pIndex)
			end
		else
			return
		end
	end
end

local function percolate_down(self, index)
	local lfIndex, rtIndex, minIndex = nil
	lfIndex = 2 * index
	rtIndex = lfIndex + 1

	if self.size < rtIndex then
		if self.size < lfIndex then
			return
		else
			minIndex = lfIndex
		end
	elseif self.sort(self._heap[lfIndex].value, self._heap[rtIndex].value) then
		minIndex = lfIndex
	else
		minIndex = rtIndex
	end

	if not self.sort(self._heap[index].value, self._heap[minIndex].value) then
		self._heap[minIndex] = self._heap[index]
		self._heap[index] = self._heap[minIndex]

		percolate_down(self, minIndex)
	end
end

local function newHeap(class, comp)
	return setmetatable({
		size = 0,
		_heap = {},
		sort = comp or f_min
	}, class)
end

local heap = setmetatable({}, {
	__call = function (self, ...)
		return newHeap(self, ...)
	end
})
heap.__index = heap

function heap:empty()
	return self.size == 0
end

function heap:getSize()
	return self.size
end

function heap:clear()
	self._heap = {}
	self.size = 0

	return self
end

function heap:leftChildIndex(index)
	return 2 * index
end

function heap:rightChildIndex(index)
	return 2 * index + 1
end

function heap:parentIndex(index)
	return floor(index / 2)
end

function heap:top()
	assert(not self:empty(), "Heap is empty")

	return self._heap[1].value, self._heap[1].data
end

function heap:insert(value, data)
	self.size = self.size + 1
	self._heap[self.size] = {
		value = value,
		data = data
	}

	percolate_up(self, self.size)

	return self
end

heap.add = heap.insert

function heap:pop()
	assert(not self:empty(), "Heap is empty.")

	local root = self._heap[1]
	self._heap[1] = self._heap[self.size]
	self._heap[self.size] = nil
	self.size = self.size - 1

	if self.size > 1 then
		percolate_down(self, 1)
	end

	return root.value, root.data
end

function heap:checkIndex(index)
	return self._heap[index] or nil
end

function heap:replace(value, data)
	assert(not self:empty(), "heap is empty, use insert()")

	local root = self._heap[1]
	self._heap[1] = {
		value = value,
		data = data
	}

	percolate_down(self, 1)

	return root.value, root.data
end

function heap:reset(comp)
	self.sort = comp or self.sort
	local _heap = self._heap
	self._heap = {}
	self.size = 0

	for i in pairs(_heap) do
		self:insert(_heap[i].value, _heap[i].data)
	end

	return self
end

function heap:merge(other)
	assert(self:isValid(), "Self heap is not a valid heap")
	assert(other:isValid(), "Argument is not a valid heap")
	assert(self.sort(1, 2) == other.sort(1, 2), "Heaps must have the same sort functions")

	for i, node in ipairs(other._heap) do
		self:insert(node.value, node.data)
	end

	return self
end

function heap.__add(h1, h2)
	local h = heap()

	h:merge(h1)
	h:merge(h2)

	return h
end

function heap:isValid()
	if self.size <= 1 then
		return true
	end

	local i = 1
	local lfIndex, rtIndex = nil

	for i = 1, floor(self.size / 2) do
		lfIndex = 2 * i
		rtIndex = lfIndex + 1

		if self:checkIndex(lfIndex) and not self.sort(self._heap[i].value, self._heap[lfIndex].value) then
			return false
		end

		if self:checkIndex(rtIndex) and not self.sort(self._heap[i].value, self._heap[rtIndex].value) then
			return false
		end
	end

	return true
end

function heap:heap(item)
	if self.size == 0 then
		return
	end

	if item then
		local i = indexOf(self.__heap, item)

		if i then
			percolate_down(self, i)
			percolate_up(self, i)
		end

		return
	end

	for i = floor(self.size / 2), 1, -1 do
		percolate_down(self, i)
	end

	return self
end

function heap:__tostring()
	local out = ""

	for k in ipairs(self._heap) do
		out = out .. ("Element %d - Value : %s\n"):format(k, tostring(self._heap[k].value))
	end

	return out
end

return heap
