local json = require("framework.json")
local YdHelper = {}
local tokenTimeCache = {}

function YdHelper.check(index, isTimeInterval)
	if DEV_MODE then
		Log.debug("YdHelper.check", index)
	end

	local nowTime = math.floor(Time.time())

	if not isTimeInterval or not tokenTimeCache[index] or nowTime > tokenTimeCache[index] + 300 then
		local function _callback(result)
			if DEV_MODE then
				dump(result, "$$$ YdHelper.check")
			end

			tokenTimeCache[index] = nowTime

			InfoUser.ydCheck(index, result.token, "")
		end

		LuaBridge.call("luaYdToken", {
			index = index
		}, _callback)
	end
end

function YdHelper.ioctl(index, onSuccess)
	local function _callback(result)
		if DEV_MODE then
			dump(result, "$$$ YdHelper.ioctl")
		end

		if onSuccess then
			onSuccess(result.rs)
		end
	end

	LuaBridge.call("luaYdIoctl", {
		index = index
	}, _callback)
end

function YdHelper.dataSign(dataStr, onSuccess)
	local function _callback(result)
		if DEV_MODE then
			dump(result, "$$$ YdHelper.dataSign")
		end

		if onSuccess then
			onSuccess(result.rs)
		end
	end

	LuaBridge.call("luaYdDataSign", {
		data = dataStr
	}, _callback)
end

return YdHelper
