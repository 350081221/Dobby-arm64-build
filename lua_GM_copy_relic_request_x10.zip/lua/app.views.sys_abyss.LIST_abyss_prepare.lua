local LIST_abyss_prepare = import("...ui.List")
local LIST_abyss_prepare = class("LIST_abyss_prepare", LIST_abyss_prepare)
UP_PERCENT = 0.25

function LIST_abyss_prepare:ctor(rect, direction)
	LIST_abyss_prepare.super.ctor(self, rect, direction)

	self.noEmptyText = true

	self:setCols(3)
	self:setCellName("cell_abyss_prepare")
	self:setSpace(5, 5)

	if direction == List.DIRECTION_HORIZONTAL then
		self:setCellSize(cc.size(90, self.touchRect.height))
	else
		self:setCellSize(cc.size(self.touchRect.width, 90))
	end
end

function LIST_abyss_prepare:setAbyssLevel(level)
	self.abyssLevel = level
end

function LIST_abyss_prepare:onCellInit(ui, data)
	if not ui.slot then
		ui.slot = DropSlot.new(ui:getFlagByTag("flag_slot"), "slot_01")

		ui:addChild(ui.slot, 100)
	end

	ui.slot:setAlwaysShowNumber(false)
	ui.slot:setOpacity(200)
	ui.slot:setDrop(data.type, data.info)
	ui.slot:setVisible(not empty(data.type))

	local isEquip = false

	if data.type == DropManager.TYPE.ITEM then
		local itemCSV = CsvParser.getCsvData("item", data.info.base_id)

		if itemCSV.type == 5 and itemCSV.subtype == 1 then
			isEquip = true
		end
	end

	local equip_level_bg = ui:getComponentByTag("equip_level_bg")

	equip_level_bg:setVisible(isEquip)
	equip_level_bg:setLocalZOrder(200)
	ui:removeLabelOnFlag("flag_equip_level_1")
	ui:removeLabelOnFlag("flag_equip_level")

	if isEquip then
		local abyssBaseCSV = CsvParser.getCsvData("abyss_base_num", self.abyssLevel)
		local rareArr = SheetUtil.getColumnList(abyssBaseCSV, {
			"equip_level_",
			"equip_rare_"
		}, {
			"level",
			"rare"
		})
		local maxLevel, minLevel = nil

		for i, v in ipairs(rareArr) do
			if v.rare > 0 then
				if not maxLevel or maxLevel < v.level then
					maxLevel = v.level
				end

				if not minLevel or v.level < minLevel then
					minLevel = v.level
				end
			end
		end

		if minLevel == maxLevel then
			ui:replaceLabelOnFlag("flag_equip_level_1", nil, maxLevel)
		else
			ui:replaceLabelOnFlag("flag_equip_level", nil, minLevel, maxLevel)
		end
	end
end

return LIST_abyss_prepare
