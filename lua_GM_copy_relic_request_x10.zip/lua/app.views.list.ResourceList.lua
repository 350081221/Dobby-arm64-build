local List = import("...ui.List")
local ResourceList = class("ResourceList", List)

function ResourceList:ctor(rect, cellName, cellHeight)
	ResourceList.super.ctor(self, rect)

	self.isBounc = false
	self.noEmptyText = true

	self:setCellName(cellName or "cell_cost")
	self:setCellSize(cc.size(self.touchRect.width, cellHeight or 35))
	self:addEventListener("onTapListIcon", function (event)
		DropManager.popDetail(DropManager.TYPE.ITEM, event.data)
	end)
end

function ResourceList:setResource(...)
	self.itemIdArr = {
		...
	}

	for i, itemID in ipairs(self.itemIdArr) do
		ManagerInfo.onDataChange(self, "item", itemID, function ()
			self:refreshItems()
		end)
	end

	self:refreshItems()
end

function ResourceList:refreshItems()
	local items = {}

	for i, itemID in ipairs(self.itemIdArr) do
		table.insert(items, {
			base_id = itemID,
			num = InfoItem.getNum(itemID)
		})
	end

	self:setItems(items)
end

function ResourceList:onCellInit(ui, data)
	local id = data.id or data.base_id
	local costData = CsvParser.getCsvData("item", id)
	local costPic = IconManager.getItemIcon(costData.id)

	if ui:getFlagByTag("flag_num") then
		ui:createLabelOnFlag("flag_num", data.num)
	end

	local icon = ui:createIconOnFlag("flag_icon", costPic, 100, true)
	local shadow = ui:createIconOnFlag("flag_shadow", costPic, 90, true)

	shadow:setColor(cc.c3b(0, 0, 0))
	shadow:setOpacity(100)
end

return ResourceList
