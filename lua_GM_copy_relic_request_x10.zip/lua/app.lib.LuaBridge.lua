local json = require("framework.json")
local LuaBridge = {}

function LuaBridge.register(methodName, callback)
	if device.platform == "android" then
		LuaBridge.registerAndroid(methodName, callback)
	elseif device.platform == "ios" then
		LuaBridge.registerIos(methodName, callback)
	end
end

function LuaBridge.registerAndroid(methodName, callback)
	local javaClassName = "com.gasura.general.LuaBridge"
	local javaMethodName = "luaRegister"
	local javaParams = {
		methodName,
		function (paramsJson)
			if callback then
				local paramsObj = json.decode(paramsJson)

				callback(paramsObj)
			end
		end
	}
	local javaMethodSig = "(Ljava/lang/String;I)V"

	luaj.callStaticMethod(javaClassName, javaMethodName, javaParams, javaMethodSig)
end

function LuaBridge.registerIos(methodName, callback)
	local function _callback(ret)
		dump(ret, "$$$ LuaBridge.registerIos")
		callback(ret)
	end

	local params = {
		event = methodName,
		listener = _callback
	}

	luaoc.callStaticMethod("AppController", "registerScriptHandler", params)
end

function LuaBridge.call(methodName, params, callback)
	if device.platform == "android" then
		LuaBridge.callAndroid(methodName, params, callback)
	elseif device.platform == "ios" then
		LuaBridge.callIos(methodName, params, callback)
	end
end

function LuaBridge.callAndroid(methodName, params, callback)
	local javaClassName = "com.gasura.general.LuaBridge"
	local javaMethodName = methodName
	params = params or {}

	if type(params) == "table" then
		params = json.encode(params)
	elseif type(params) == "number" then
		params = tostring(params)
	end

	local javaParams = {
		params,
		function (paramsJson)
			if callback then
				local paramsObj = json.decode(paramsJson)

				callback(paramsObj)
			end
		end
	}
	local javaMethodSig = "(Ljava/lang/String;I)V"

	luaj.callStaticMethod(javaClassName, javaMethodName, javaParams, javaMethodSig)
end

function LuaBridge.callIos(methodName, params, callback)
	local function _callback(ret)
		dump(ret, "$$$ LuaBridge.callIos")
		callback(ret)
	end

	params = (type(params) == "string" or type(params) == "number") and {
		param = params
	} or params or {}
	params.event = methodName
	params.listener = _callback
	local ok, ret = luaoc.callStaticMethod("AppController", methodName, params)

	if ok then
		print("$$$ LuaBridge.callIos ok", methodName)
	else
		print(string.format("LuaBridge %s - call API failure, error code: %s", methodName, tostring(ret)))
	end
end

function LuaBridge.initEnter()
	if A_wing then
		local already = Cookie.get("wingsdk_init_enter_once")

		if already ~= 1 then
			Cookie.set("wingsdk_init_enter_once", 1, true)

			local params = {}

			LuaBridge.call("lua_init_enter", params, function (result)
			end)
		end
	end
end

return LuaBridge
