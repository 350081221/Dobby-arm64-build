local DungeonEvent = {}

function DungeonEvent.onMapTrigger(eventData, eventType, tile)
	if eventData.disabled then
		return
	end

	if eventData.name == "teleport" then
		DungeonEvent.teleport(eventData)
	elseif eventData.name == "leave" or eventData.name == "go_map" then
		DungeonEvent.go(eventData)
	elseif eventData.name == "go_next" then
		DungeonEvent.goNext(eventData)
	elseif eventData.name == "exit" then
		DungeonEvent.exit(eventData)
	elseif eventData.name == "drama" then
		DungeonEvent.drama(eventData)
	elseif eventData.name == "drama-resume" then
		DungeonEvent.dramaResume(eventData)
	elseif eventData.name == "quest-accept" then
		DungeonEvent.questAccept(eventData)
	elseif eventData.name == "team-whisper" then
		DungeonEvent.teamWhisper(eventData)
	elseif eventData.name == "monster" then
		DungeonEvent.monsterAmbush(eventData)
	elseif eventData.name == "inquire-aside" then
		DungeonEvent.inquire(eventData, eventType)
	elseif eventData.name == "inquire-dialog" then
		DungeonEvent.inquire(eventData, eventType)
	elseif eventData.name == "skill_test_start" then
		DungeonEvent.setSkillTest(eventData, true)
	elseif eventData.name == "skill_test_end" then
		DungeonEvent.setSkillTest(eventData, false)
	elseif eventData.name == "mission-trigger" then
		DungeonEvent.triggerMission(eventData)
	elseif eventData.name == "fishing_ready" then
		DungeonEvent.triggerFishing(eventData, eventType)
	end
end

function DungeonEvent.triggerFishing(eventData, eventType)
	InfoFishing.onFishingReady(eventType == "enter", eventData)
end

function DungeonEvent.inquire(eventData, eventType)
	local info = ConfParser.parse(eventData.info)

	local function onTouch()
		if info.angle and info.angle ~= "" then
			global.player.angle = info.angle * math.pi / 180
		end

		if eventData.tag == "inquire-aside" then
			POP_aside.open(info.id)
		elseif eventData.tag == "inquire-dialog" then
			POP_dialog.open(info.id)
		end
	end

	local tag = eventData.tag .. "#" .. eventData.x .. "_" .. eventData.y

	if eventType == "enter" then
		if global.ui and global.ui.addInquireNpcUI then
			global.ui:addInquireNpcUI(tag, info, onTouch)
		end
	elseif (eventType == "leave" or eventType == "go_map") and global.ui and global.ui.removeInquireNpcUI then
		global.ui:removeInquireNpcUI(tag)
	end
end

function DungeonEvent.dramaResume(eventData)
	local info = ConfParser.parse(eventData.info)
	local currentDrama = DramaManager.current and DramaManager.current.name or nil

	if (empty(info.id) or tostring(info.id) == tostring(currentDrama)) and not eventData.done then
		eventData.done = true

		DramaManager.setFreeze(false)
	end
end

function DungeonEvent.monsterAmbush(eventData)
	if global.map.isBattle then
		return
	end

	if global.ignore then
		return
	end

	if InfoDungeon.getSneakPoint() > 0 then
		return
	end

	if global.player:isGoDirectionLocked() then
		return
	end

	MapEventManager.checkMonsterSet(x, y, true)
end

function DungeonEvent.teamWhisper(eventData)
	local info = ConfParser.parse(eventData.info)
	local tag = "pet-whisper_" .. global.map.mapName .. "_" .. eventData.x .. "_" .. eventData.y

	if UserCookie.get(tag) ~= 1 and not empty(info.text) then
		local units = TeamManager.getUnits()

		if not empty(units) then
			local unit = units[math.random(1, #units)]

			if unit then
				unit:say(info.text, 180)
				UserCookie.set(tag, 1, true)
			end
		end
	end
end

function DungeonEvent.questAccept(eventData)
	local info = ConfParser.parse(eventData.info)
	local questID = info.id

	if InfoQuest.canAccept(questID) and not DungeonEvent.questAccepting then
		DungeonEvent.questAccepting = true

		local function callback(...)
			DungeonEvent.questAccepting = nil
		end

		InfoQuest.accept(questID, callback, callback)
	end
end

function DungeonEvent.teleport(eventData)
	local info = ConfParser.parse(eventData.info)

	if info.mode == 2 then
		return
	end

	local finData = MapEventManager.findLinkOne(eventData, "go_next")

	if finData and InfoGuide.isAbyssNextLocked() then
		Alert.open(Localization.getSrcText("请先返回营地继续引导"))

		return
	end

	global.player:setMapTouchEnabled(false)
	global.player:setGoDirectionLocked("teleport", true)

	Monster.noCheckBattle = true
	local pathArr = {
		global.map:getTile(eventData.x, eventData.y)
	}
	local finData = MapEventManager.findLinkOne(eventData, "teleport")
	local otherDest = nil

	if finData then
		local angle = math.atan2(finData.y - eventData.y, finData.x - eventData.x) * 180 / math.pi

		if angle < 0 then
			angle = angle + 360
		end

		local offsets = {}
		local teamCount = math.max(2, #TeamManager.getUnits())

		if angle >= 45 and angle < 135 then
			table.insert(pathArr, global.map:getTile(finData.x, finData.y - 1))
			table.insert(pathArr, global.map:getTile(finData.x, finData.y - 1 + teamCount))
		elseif angle >= 135 and angle < 225 then
			table.insert(pathArr, global.map:getTile(finData.x + 1, finData.y))
			table.insert(pathArr, global.map:getTile(finData.x + 1 - teamCount, finData.y))
		elseif angle >= 225 and angle < 315 then
			table.insert(pathArr, global.map:getTile(finData.x, finData.y + 1))
			table.insert(pathArr, global.map:getTile(finData.x, finData.y + 1 - teamCount))
		else
			table.insert(pathArr, global.map:getTile(finData.x - 1, finData.y))
			table.insert(pathArr, global.map:getTile(finData.x - 1 + teamCount, finData.y))
		end
	else
		local otherDestTags = {
			"go_next"
		}

		for i, tag in ipairs(otherDestTags) do
			local finData = MapEventManager.findLinkOne(eventData, tag)

			if finData then
				table.insert(pathArr, global.map:getTile(finData.x, finData.y))

				otherDest = finData

				if InfoGuide.getFreeRecord(1) == 0 then
					TaHelper.taGuideDetail(11200)
				end

				break
			end
		end
	end

	local teleportSpeed = info.speed or Player.normalSpeed
	local currentSpeed = Player.normalSpeed
	local trains = global.player:getTrainUnits()

	if otherDest then
		local fadeTime = global.map.ptPerTile / currentSpeed
		global.player.speed = currentSpeed

		global.player:goPath({
			pathArr[2]
		}, true)

		local function releaseFromTeleport()
			Log.verbose("teleport releaseFromTeleport")
			global.player:setMapTouchEnabled(true)
			global.player:setGoDirectionLocked("teleport", false)

			Monster.noCheckBattle = false
			local monsters = Monster.getAllMonster()

			for i = 1, #monsters do
				monsters[i]:checkBattle()
			end

			DungeonEvent.onMapTrigger(otherDest)

			global.player.inTeleport = nil
		end

		global.player:setPathFinishedCallback(releaseFromTeleport)

		for i = 1, #trains do
			local trainUnit = trains[i]

			local function trainUnitFade()
				local effectGen = trainUnit:getEffectGen()

				if effectGen then
					effectGen:fadeTo(fadeTime / 2, 0, "inQuart")
					effectGen:darkTo(fadeTime / 2, 0)
				end
			end

			MapFrameManager.setTimeout(trainUnitFade, fadeTime * (i - 1), trainUnit)
		end

		local function trainUnitFade()
			currentSpeed = teleportSpeed
		end

		MapFrameManager.setTimeout(trainUnitFade, fadeTime * (#trains - 1.5), global.player)

		return
	end

	local function outTeleport(path)
		Log.verbose("teleport outTeleport")

		global.player.speed = Player.normalSpeed
		local mapX, mapY = global.map:tileToMap(path[1])

		global.player:draw(mapX, mapY, true)
		Unit.setFocusUnit(global.player)
		global.player:goPath({
			path[2]
		}, true)

		local function releaseFromTeleport()
			Log.verbose("teleport releaseFromTeleport")
			global.player:setMapTouchEnabled(true)
			global.player:setGoDirectionLocked("teleport", false)

			Monster.noCheckBattle = false
			local monsters = Monster.getAllMonster()

			for i = 1, #monsters do
				monsters[i]:checkBattle()
			end

			notify.dispatch("guide_rantile")

			global.player.inTeleport = nil
		end

		global.player:setPathFinishedCallback(releaseFromTeleport)

		local fadeTime = global.map.ptPerTile / Player.normalSpeed

		for i = 1, #trains do
			local trainUnit = trains[i]

			local function trainUnitFade()
				if info.mode == 1 then
					MapEffect.quake(5)
				else
					local effectGen = trainUnit:getEffectGen()

					if effectGen then
						effectGen:fadeTo(fadeTime / 2, 255, "inQuart")
						effectGen:darkTo(fadeTime / 2, trainUnit.darkness)
					end
				end
			end

			MapFrameManager.setTimeout(trainUnitFade, fadeTime * (i - 1), trainUnit)
		end
	end

	local pathIndex = 2
	local toNext = nil
	local startPoint = {
		x = global.player.x,
		y = global.player.y
	}
	local moveTime = 0

	function toNext()
		Log.verbose("teleport toNext", pathIndex, #pathArr)

		if pathIndex == #pathArr then
			outTeleport({
				pathArr[#pathArr - 1],
				pathArr[#pathArr]
			})

			return
		end

		if pathIndex <= #pathArr - 1 then
			local mapX, mapY = global.map:tileToMap(pathArr[pathIndex])
			local distance = math.sqrt(math.pow(startPoint.y - mapY, 2) + math.pow(startPoint.x - mapX, 2))
			local time = distance / currentSpeed
			startPoint.x = mapX
			startPoint.y = mapY
			pathIndex = pathIndex + 1

			global.map:tweenScrollTo(mapX, mapY, time, toNext, "linear", nil, function (x, y)
				global.map:setMaskPosition(x, y)
			end)

			moveTime = time
		end
	end

	toNext()
	Log.verbose("teleport start")
	Unit.setFocusUnit(nil)

	global.player.inTeleport = true
	local fadeTime = global.map.ptPerTile / currentSpeed
	global.player.speed = currentSpeed

	global.player:goPath({
		pathArr[2]
	}, true)

	for i = 1, #trains do
		local trainUnit = trains[i]

		local function trainUnitFade()
			local effectGen = trainUnit:getEffectGen()

			if effectGen then
				if info.mode == 1 then
					effectGen:updown(math.max(moveTime, fadeTime), info.height)
				else
					effectGen:fadeTo(fadeTime / 2, 0, "inQuart")
					effectGen:darkTo(fadeTime / 2, 0)
				end
			end
		end

		MapFrameManager.setTimeout(trainUnitFade, fadeTime * (i - 1), trainUnit)
	end

	local function trainUnitFade()
		currentSpeed = teleportSpeed
	end

	MapFrameManager.setTimeout(trainUnitFade, fadeTime * (#trains - 1.5), global.player)
end

function DungeonEvent.go(eventData)
	if global.player:isGoDirectionLocked() then
		return
	end

	notify.dispatch("exit_map")

	local info = ConfParser.parse(eventData.info)

	DungeonScene.enterMap(DungeonScene.ENTER_TYPE.NEW, info.map_id, info)
end

function DungeonEvent.goNext(eventData)
	local stageType, stageID = InfoDungeon.getStage()

	if InfoDungeon.inDust() then
		FRAME_dust_next.open(eventData.index)
	else
		if global.player:isGoDirectionLocked() then
			return
		end

		if InfoGuide.isAbyssNextLocked() then
			Alert.open(Localization.getSrcText("请先返回营地继续引导"))

			return
		end

		if InfoGuide.isAbyssExitGuide() and InfoGuide.triggerFree(23) then
			return
		end

		if InfoDungeon.getAbyssLayer() == 1 then
			TaHelper.taGuideDetail(11700)
		elseif InfoDungeon.getAbyssLayer() == 2 then
			TaHelper.taGuideDetail(11900)
		elseif InfoDungeon.getAbyssLayer() == 3 then
			TaHelper.taGuideDetail(12400)
		end

		local function onSuccess(rcvData)
			DungeonScene.enterDungeon(DungeonScene.ENTER_TYPE.NEW, rcvData)
		end

		InfoDungeon.goNext(eventData.index, eventData.layer, onSuccess)
	end
end

function DungeonEvent.exit(eventData)
	local info = ConfParser.parse(eventData.info)

	if not empty(info.tag) then
		InfoDungeon.toMap(info.tag)
	else
		InfoDungeon.toMap()
	end
end

function DungeonEvent.drama(eventData)
	local info = ConfParser.parse(eventData.info)
	local once = info.once
	local code = nil

	if once == 1 then
		code = "drama_#" .. DungeonScene.currentMap .. "," .. eventData.x .. "," .. eventData.y
	end

	if empty(code) or empty(UserCookie.get(code)) then
		local function delayEnterDrama()
			if not DramaManager.opening then
				DramaManager.start(info.id, nil, , function ()
					if not empty(code) then
						UserCookie.set(code, 1, true)
					end
				end, eventData)
			end
		end

		global.map:performWithDelay(delayEnterDrama, 0.2)
	end
end

function DungeonEvent.checkBattleUnit(str)
	local arr = string.split(str, ":")

	if arr[1] == "hero" then
		return CsvParser.getCsvData("hero_templete", arr[2], nil, true) ~= nil
	elseif arr[1] == "monster" then
		return CsvParser.getCsvData("monster", arr[2], nil, true) ~= nil
	end
end

function DungeonEvent.makeBattleUnit(eventData, str)
	local arr = string.split(str, ":")

	if arr[1] == "hero" then
		local attacker = Hero.new()

		attacker:setUndeadable(true)
		attacker:setHeroTempleteID(arr[2])

		return attacker
	elseif arr[1] == "monster" then
		local monster = Monster.new()

		monster:setUndeadable(true)
		monster:setInfo({
			level = 1,
			id = math.random(1, 65535),
			base_id = arr[2]
		})
		monster:setEventPack({
			eventData = eventData
		})

		return monster
	end
end

function DungeonEvent.makeBattleUnits(eventData)
	local attackerStr = Cookie.get("POP_skill_test_attacker")
	local targetStr = Cookie.get("POP_skill_test_target")

	if not attackerStr or not DungeonEvent.checkBattleUnit(attackerStr) then
		Alert.open("请输入攻击方信息")

		return
	end

	if not targetStr or not DungeonEvent.checkBattleUnit(targetStr) then
		Alert.open("请输入受击方信息")

		return
	end

	return DungeonEvent.makeBattleUnit(eventData, attackerStr), DungeonEvent.makeBattleUnit(eventData, targetStr), targetStr
end

local skillTestObj = nil

function DungeonEvent.clearBattle(eventData)
	POP_skill_test.clearUnits()
	WarMachine.clean()
	WarMachine.clear()
	WarMachine.over()

	global.fake_battle = nil

	if skillTestObj then
		skillTestObj.attacker:removeSelf()

		if skillTestObj.target.die then
			skillTestObj.target:die()
		end

		for i, unit in ipairs(skillTestObj.otherTargets) do
			if unit.removeSelf then
				unit:removeSelf()
			end
		end

		notify.unregister("map_tap", skillTestObj.map_tap_id)

		skillTestObj = nil
	end
end

function DungeonEvent.makeBattle(eventData)
	print("= 技能测试场 =")
	InfoModao.initDungeon(true)
	DungeonEvent.clearBattle(eventData)

	local battleCenter = MapEventManager.findLinkOne(eventData, "battle-center")
	local centerTile = global.map:getTile(battleCenter.x, battleCenter.y)
	local attackerEvent = MapEventManager.findLinkOne(eventData, "skill_test_attacker")
	local targetEvent = MapEventManager.findLinkOne(eventData, "skill_test_target")
	local attacker, target, targetStr = DungeonEvent.makeBattleUnits(eventData)

	if not attacker then
		return
	end

	local mapX, mapY = global.map:tileToMap(attackerEvent.x, attackerEvent.y)

	attacker:display(global.map, mapX, mapY)

	local mapX, mapY = global.map:tileToMap(targetEvent.x, targetEvent.y)

	target:display(global.map, mapX, mapY)
	target:faceTo(attacker)
	attacker:faceTo(target)

	attacker.speed = 0
	target.speed = 0
	attacker.isTestBattle = true
	attacker.thinkFreezed = true
	target.isTestBattle = true
	target.thinkFreezed = true
	attacker.random = Random.new(math.random(1, 65535))
	target.random = Random.new(math.random(1, 65535))
	local otherTargets = {}
	local others = MapEventManager.findLinkAll(targetEvent, "skill_test_target")

	for i, otherEvent in ipairs(others) do
		local mapX, mapY = global.map:tileToMap(otherEvent.x, otherEvent.y)
		local other = DungeonEvent.makeBattleUnit(eventData, targetStr)

		other:display(global.map, mapX, mapY)
		other:faceTo(attacker)

		other.speed = 0
		other.thinkFreezed = true
		other.random = Random.new(math.random(1, 65535))
		other.isTestBattle = true

		table.insert(otherTargets, other)
	end

	if attacker.data.class == 1 and attacker:hasAction("atk_w") then
		attacker:setMappedAction("attack", "atk_w")
	end

	if attacker.data.class == 2 and attacker:hasAction("atk_a") then
		attacker:setMappedAction("attack", "atk_a")
	end

	if attacker.data.class == 3 and attacker:hasAction("atk_m") then
		attacker:setMappedAction("attack", "atk_m")
	end

	if attacker:hasAction("attack") then
		attacker:setMappedAction("atk_w", "attack")
		attacker:setMappedAction("atk_a", "attack")
		attacker:setMappedAction("atk_m", "attack")
	end

	WarMachine.clear()
	WarMachine.addEventData(eventData)

	WarMachine.random = Random.new(math.random(1, 65535))
	local areaTiles, outTiles, borderTiles = MapUtils.spreadArea(global.map, centerTile, 6, 10000, 0)

	WarMachine.setAreaTileMap(areaTiles)
	WarMachine.addUnit(attacker, 1, "DungeonEvent.setSkillTest")
	WarMachine.addUnit(target, 2, "DungeonEvent.setSkillTest")

	for i, unit in ipairs(otherTargets) do
		WarMachine.addUnit(unit, 2, "DungeonEvent.setSkillTest")
	end

	WarMachine.start()

	global.fake_battle = true
	skillTestObj = {
		attacker = attacker,
		target = target,
		otherTargets = otherTargets
	}
	skillTestObj.map_tap_id = notify.safeRegister(global.player, "map_tap", function (x, y)
		attacker:draw(x, y, true)

		if target and target.x then
			attacker:faceTo(target)
		end
	end)
	attacker.thinkFreezed = true
	target.thinkFreezed = true

	for i, otherTarget in ipairs(otherTargets) do
		otherTarget.thinkFreezed = true
	end

	POP_skill_test.setUnits(attacker, target, otherTargets)
end

function DungeonEvent.setSkillTest(eventData, enabled)
	if enabled then
		global.isTestBattle = true

		if not POP_skill_test.isOpening() then
			local battleCenter = MapEventManager.findLinkOne(eventData, "battle-center")
			local mapX, mapY = global.map:tileToMap(battleCenter.x, battleCenter.y)

			global.map:tweenScrollTo(mapX, mapY, 15)
			global.map:setFov(mapX, mapY)
			global.ui.headUI:setVisible(false)
			global.ui:setOpacity(0)
			global.player:stop()

			local units = TeamManager.getUnits()

			for i, unit in ipairs(units) do
				unit.battleData.die = true
			end

			POP_skill_test.open(eventData, function ()
				DungeonEvent.makeBattle(eventData)
			end)
			Unit.setFocusUnit(nil)
			DungeonEvent.makeBattle(eventData)
		end
	else
		global.isTestBattle = nil

		if POP_skill_test.isOpening() then
			local units = TeamManager.getUnits()

			for i, unit in ipairs(units) do
				unit.battleData.die = false
			end

			global.ui.headUI:setVisible(true)
			global.ui:setOpacity(255)
			POP_skill_test.close()
			Unit.setFocusUnit(global.player)
			global.map:scrollTo(global.player.x, global.player.y)
			DungeonEvent.clearBattle(eventData)
		end
	end
end

function DungeonEvent.triggerMission(eventData)
	local info = ConfParser.parse(eventData.info)
	local tile = nil
	local presetEvent = MapEventManager.findLinkOne(eventData, "mission-preset")

	if presetEvent then
		tile = global.map:getTile(presetEvent.x, presetEvent.y)
	else
		local centerX = math.floor(eventData.x + (eventData.w - 1) / 2)
		local centerY = math.floor(eventData.y + (eventData.h - 1) / 2)
		tile = global.map:getTile(centerX, centerY)
	end

	local params = {
		tile = tile,
		eventIndex = eventData.index
	}

	InfoMission.trigger(info.cpoint, info.param, params)
end

return DungeonEvent
