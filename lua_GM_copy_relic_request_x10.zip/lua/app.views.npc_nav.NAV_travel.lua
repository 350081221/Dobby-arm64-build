local NAV_base = import(".NAV_base")
local NAV_travel = class("NAV_travel", NAV_base)

function NAV_travel.open(npc)
	local ui = NAV_travel.new(npc)

	return ui
end

function NAV_travel:ctor(npc)
	NAV_travel.super.ctor(self, npc, "nav_travel")
end

function NAV_travel:init()
	NAV_travel.super.init(self)

	local index = 1
	local ui = self.buttons[index].ui
	local redotCount = InfoTravel.countRedot()
	local redot = ui:getComponentByTag("redot")

	redot:setVisible(redotCount > 0)
	self:refresh()
	ManagerInfo.onDataChange(self, "union", nil, function ()
		self:refresh()
	end)
end

function NAV_travel:refresh()
	local opening = InfoParams.getValue("union")
	local index = 3
	local funcCSV = InfoFunction.checkFuncOpen(10500)

	if opening == 1 and funcCSV then
		if InfoUnion.hasUnion() then
			self:setButtonVisible(3, false)
			self:setButtonVisible(4, true)
		else
			self:setButtonVisible(3, true)
			self:setButtonVisible(4, false)
		end
	else
		self:setButtonVisible(3, false)
		self:setButtonVisible(4, false)
	end
end

function NAV_travel:onTap(index)
	NAV_travel.super.onTap(self, index)

	if index == 1 then
		FRAME_travel.open(self.npc)
	elseif index == 2 then
		FRAME_big_shop.open(InfoFishing, self.npc)
	elseif index == 3 then
		local funcCSV = InfoFunction.checkFuncOpen(10500)
		local opening = InfoParams.getValue("union")

		if opening == 1 and funcCSV and not InfoUnion.hasUnion() then
			FRAME_union_create.open(self.npc)
		end
	elseif index == 4 then
		local funcCSV = InfoFunction.checkFuncOpen(10500)
		local opening = InfoParams.getValue("union")

		if opening == 1 and funcCSV and InfoUnion.hasUnion() then
			InfoUnion.enterMap(true)
		end
	end
end

return NAV_travel
