local InfoPaygift = {}
local rawData, shopMap = nil
local openGroupMap = {}
local open101Map = {}

function InfoPaygift.init()
	Connection.listen("paygift_sync", InfoPaygift.sync)
	Connection.listen("paygift_open_sync", InfoPaygift.syncOpen)
end

app:addToAppEnterCall(InfoPaygift.init)

function InfoPaygift.clear()
	rawData = nil
end

function InfoPaygift.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoPaygift.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("paygift_query", callback)
end

function InfoPaygift.onQuery(rcvData)
	rawData = rcvData
	shopMap = {}

	for i, v in ipairs(rcvData.list) do
		shopMap[v.shop_id] = v
	end

	openGroupMap = {}

	for i, v in ipairs(rcvData.open_list) do
		openGroupMap[v.id] = v.open
	end

	open101Map = {}

	for i, v in ipairs(rcvData.open_101_list) do
		open101Map[v.id] = v.open
	end

	dump(rcvData.open_list, "$$$ data.open_list")
end

function InfoPaygift.sync(data)
	dump(data, "InfoPaygift.sync")

	for k, v in pairs(data) do
		if k ~= "list" then
			rawData[k] = v
		end
	end

	if data.list then
		for i, syncData in ipairs(data.list) do
			local shop_id = syncData.shop_id

			if shopMap[shop_id] then
				for k, v in pairs(syncData) do
					shopMap[shop_id][k] = v
				end
			else
				shopMap[shop_id] = syncData
			end
		end
	end

	notify.dispatch("campaign_changed")
	ManagerInfo.dataChange("paygift", data)
end

function InfoPaygift.syncOpen(data)
	dump(data, "$$$ InfoPaygift.syncOpen")

	openGroupMap = {}

	for i, v in ipairs(data.open_list) do
		openGroupMap[v.id] = v.open
	end

	open101Map = {}

	for i, v in ipairs(data.open_101_list) do
		open101Map[v.id] = v.open
	end

	ManagerInfo.dataChange("paygift_open")
end

function InfoPaygift.buy(shop_id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if CONFIG.is_ta then
				local csv = CsvParser.getCsvData("payment_gift", shop_id)
				local params = {
					buy_num = 1,
					shop_id = shop_id,
					item_id = shop_id,
					item_price = csv.cost_num,
					cost_type = csv.cost_id
				}

				TaHelper.taTrack("buy_item", params)
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("paygift_buy", {
		shop_id = shop_id
	}, callback)
end

function InfoPaygift.getNextRefreshTime(type)
	return RefreshManager.getNextTime(RefreshManager.TYPE["GIFT_SHOP_" .. type], Time.now())
end

function InfoPaygift.getRefreshInfo(type)
	local refresh_time = rawData["refresh_time_" .. type]

	return refresh_time
end

function InfoPaygift.getLabels()
	local csvList = CsvParser.getCsvList("payment_gift_label")
	local arr = {}

	for i, csv in ipairs(csvList) do
		if #InfoPaygift.getItems(csv.id) > 0 then
			table.insert(arr, csv)
		end
	end

	table.sort(arr, function (a, b)
		return a.index < b.index
	end)

	return arr
end

function InfoPaygift.getItems(label)
	local dungeonLevel = InfoDungeon.getAbyssMaxLevel()
	local nowTime = Time.now()
	local arr = {}
	local csvList = CsvParser.getCsvList("payment_gift", "index", {
		label = label
	})

	for i, csv in ipairs(csvList) do
		if csv.level_min <= dungeonLevel and dungeonLevel <= csv.level_max and InfoPaygift.checkOpen(csv) then
			local shopData = shopMap[csv.id]

			if shopData then
				local unlockCheck = true

				if not empty(csv.unlock_id) then
					local unlock_data = shopMap[csv.unlock_id]

					if unlock_data then
						local soldout = unlock_data.soldout

						if soldout <= 0 then
							unlockCheck = false
						end
					else
						unlockCheck = false
					end
				end

				if unlockCheck then
					if csv.type == 5 then
						if csv.times <= shopData.soldout then
							unlockCheck = false
						end
					elseif csv.type == 4 then
						if empty(csv.festival_id) then
							unlockCheck = false
						elseif not InfoFestival.checkOpening(csv.festival_id) then
							unlockCheck = false
						end
					end
				end

				if not empty(csv.festival_id) and not InfoFestival.checkOpening(csv.festival_id) then
					unlockCheck = false
				end

				if unlockCheck then
					table.insert(arr, shopData)
				end
			end
		end
	end

	local soldoutCache = {}

	local function isSoldout(data)
		if not soldoutCache[data.shop_id] then
			local soldout = data.soldout
			local csv = CsvParser.getCsvData("payment_gift", data.shop_id)

			if not empty(csv.item_check) and InfoItem.getNum(csv.item_check) > 0 then
				soldoutCache[data.shop_id] = 2
			elseif not empty(csv.times) and csv.times <= soldout then
				soldoutCache[data.shop_id] = 1
			else
				soldoutCache[data.shop_id] = 0
			end
		end

		return soldoutCache[data.shop_id]
	end

	table.sort(arr, function (a, b)
		local soldoutA = isSoldout(a)
		local soldoutB = isSoldout(b)

		if soldoutA == soldoutB then
			local csvA = CsvParser.getCsvData("payment_gift", a.shop_id)
			local csvB = CsvParser.getCsvData("payment_gift", b.shop_id)

			if csvA.index == csvB.index then
				return a.shop_id < b.shop_id
			else
				return csvA.index < csvB.index
			end
		else
			return soldoutA < soldoutB
		end
	end)

	return arr
end

function InfoPaygift.checkSoldout(id)
	local data = shopMap[id]

	if data then
		local soldout = data.soldout
		local csv = CsvParser.getCsvData("payment_gift", data.shop_id)

		if not empty(csv.item_check) and InfoItem.getNum(csv.item_check) > 0 then
			return true
		elseif not empty(csv.times) and csv.times <= soldout then
			return true
		else
			return false
		end
	end

	return true
end

function InfoPaygift.countNotSoldout(items)
	local notSoldoutCount = 0

	for i, item in ipairs(items) do
		if not InfoPaygift.checkSoldout(item.shop_id) then
			notSoldoutCount = notSoldoutCount + 1
		end
	end

	return notSoldoutCount
end

function InfoPaygift.countRedot(label)
	local dungeonLevel = InfoDungeon.getAbyssMaxLevel()
	local nowTime = Time.now()
	local redotCount = 0
	local csvList = CsvParser.getCsvList("payment_gift", "index", {
		label = label
	})

	for i, csv in ipairs(csvList) do
		local shopData = shopMap[csv.id]

		if shopData and (empty(csv.times) or shopData.soldout < csv.times) and (empty(csv.start_time) or csv.start_time <= nowTime) and (empty(csv.end_time) or nowTime <= csv.end_time) and csv.level_min <= dungeonLevel and dungeonLevel <= csv.level_max and csv.pay_type == 1 and empty(csv.cost_num) then
			redotCount = redotCount + 1
		end
	end

	return redotCount
end

function InfoPaygift.isNewList(label)
	local items = InfoPaygift.getItems(label)

	for i, v in ipairs(items) do
		if InfoPaygift.isNew(v.shop_id) then
			return true
		end
	end

	return false
end

function InfoPaygift.isNew(shop_id)
	local csv = CsvParser.getCsvData("payment_gift", shop_id)

	if csv.is_show_new == 1 then
		local newMap = UserCookie.get("paygift_new")

		if newMap and newMap[tostring(shop_id)] == 1 then
			return false
		end

		return true
	else
		return false
	end
end

function InfoPaygift.markNewList(label)
	local items = InfoPaygift.getItems(label)
	local newMap = UserCookie.get("paygift_new") or {}
	local changed = false

	for i, v in ipairs(items) do
		if InfoPaygift.isNew(v.shop_id) then
			local csv = CsvParser.getCsvData("payment_gift", v.shop_id)

			if csv.is_show_new == 1 then
				newMap[tostring(v.shop_id)] = 1
				changed = true
			end
		end
	end

	if changed then
		UserCookie.set("paygift_new", newMap, true)
		notify.dispatch("campaign_changed")
	end
end

function InfoPaygift.checkOpen(csv)
	local checkOK = false

	if empty(csv.group) then
		checkOK = true
	elseif openGroupMap[csv.group] then
		checkOK = openGroupMap[csv.group] == 1
	end

	if checkOK and csv.label == 101 and open101Map[csv.id] == 0 then
		checkOK = false
	end

	return checkOK
end

function InfoPaygift.clearNew()
	UserCookie.set("paygift_new", nil, true)
	notify.dispatch("campaign_changed")
end

return InfoPaygift
