local InfoQuickSlots = {}
local rawData = nil

function InfoQuickSlots.init()
	Connection.listen("quick_slots_sync", InfoQuickSlots.sync)
end

app:addToAppEnterCall(InfoQuickSlots.init)

function InfoQuickSlots.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoQuickSlots.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("quick_slots_query", callback)
end

function InfoQuickSlots.onQuery(rcvData)
	rawData = rcvData
end

function InfoQuickSlots.sync(data)
	for k, v in pairs(data) do
		rawData[k] = v
	end

	ManagerInfo.dataChange("quick_slots", data)
end

function InfoQuickSlots.getRuneMap()
	local bagItemArr, bagItemMap = InfoBag.getItemTypeList(MiscConfig.rune_type)
	local bagItemIndex = 1

	local function getNewItem()
		if #bagItemArr == 0 then
			return 0
		end

		local startIndex = bagItemIndex
		bagItemIndex = bagItemIndex + 1

		if bagItemIndex > #bagItemArr then
			bagItemIndex = 1
		end

		while true do
			if bagItemArr[bagItemIndex].num > 0 then
				bagItemArr[bagItemIndex].num = bagItemArr[bagItemIndex].num - 1

				return bagItemArr[bagItemIndex].base_id
			else
				bagItemIndex = bagItemIndex + 1

				if bagItemIndex > #bagItemArr then
					bagItemIndex = 1
				end

				if bagItemIndex == startIndex then
					break
				end
			end
		end

		return 0
	end

	local slotMap = {}

	for i = 1, GameConfig.rune_num do
		local currentItem = rawData["rune_" .. i]

		if not empty(currentItem) and bagItemMap[currentItem] and bagItemMap[currentItem].num > 0 then
			slotMap[i] = currentItem
			bagItemMap[currentItem].num = bagItemMap[currentItem].num - 1
		end
	end

	for i = 1, GameConfig.rune_num do
		if not slotMap[i] then
			slotMap[i] = getNewItem()
		end
	end

	return slotMap
end

function InfoQuickSlots.get(index)
	return rawData["slot_" .. index]
end

function InfoQuickSlots.set(index, id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("quick_slots_set", {
		index = index,
		id = id
	}, callback)
end

function InfoQuickSlots.setRune(arr, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "quick_slots_set")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	local params = {}

	for i = 1, GameConfig.rune_num do
		if arr[i] then
			params["rune_" .. i] = arr[i]
		end
	end

	Connection.request("quick_slots_set_rune", params, callback)
end

function InfoQuickSlots.getPetIndex()
	if InfoDungeon.isFixedTeam() then
		return StageUtils.getFixedIndex()
	end

	local petCount = #InfoPet.getTeam()

	return math.max(1, math.min(GameConfig.pet_team_num, math.min(petCount, rawData.pet_index)))
end

function InfoQuickSlots.setPet(index, onSuccess, onFailure)
	if InfoDungeon.isFixedTeam() then
		StageUtils.setFixedIndex(index)

		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("quick_slots_set_pet", {
		index = index
	}, callback)
end

function InfoQuickSlots.getItemMap()
	local itemMap = {}

	for index = 1, GameConfig.quick_slots_num do
		itemMap[InfoQuickSlots.get(index)] = true
	end

	return itemMap
end

function InfoQuickSlots.findItem(itemID)
	for index = 1, GameConfig.quick_slots_num do
		if InfoQuickSlots.get(index) == itemID then
			return index
		end
	end
end

function InfoQuickSlots.getFreePosList()
	local posArr = {}

	for index = 1, GameConfig.quick_slots_num do
		if empty(InfoQuickSlots.get(index)) then
			table.insert(posArr, index)
		end
	end

	return posArr
end

return InfoQuickSlots
