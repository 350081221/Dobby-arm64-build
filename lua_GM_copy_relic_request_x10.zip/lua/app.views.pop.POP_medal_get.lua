local POP_medal_get = class("POP_medal_get", UI_base)

function POP_medal_get.open(itemInfo, onClose)
	local ui = POP_medal_get.new(itemInfo)

	Sound.playSound("gotitem")

	local mask = ui:getComponentByTag("mask")

	PopManager.open(ui, function ()
		mask:setVisible(false)
	end, onClose, PopManager.ANIM_TYPE.CENTER)
end

function POP_medal_get:ctor(itemInfo)
	POP_medal_get.super.ctor(self, "pop_medal_get", UIManager.BIG_TYPE.POP)

	self.itemInfo = itemInfo

	self:init()
end

function POP_medal_get:init()
	self:initUI()
end

function POP_medal_get:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local mask = self:getComponentByTag("mask")

	mask:setOpacity(0)
	mask:toTouchable()

	local itemInfo = self.itemInfo
	local itemCSV = CsvParser.getCsvData("item", itemInfo.base_id)
	local slot = DropSlot.new(self:getFlagByTag("flag_slot"), "slot_01")

	self:addChild(slot, 100)
	slot:setDrop(DropManager.TYPE.ITEM, itemInfo)
	slot:setDetailEnabled(true)
	self:createLabelOnFlag("flag_name", itemCSV.name)
end

return POP_medal_get
