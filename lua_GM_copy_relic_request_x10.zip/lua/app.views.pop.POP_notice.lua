local POP_notice = class("POP_notice", UI_base)
local BUTTON_STYLE = {
	BLUE = 1,
	RED = 3,
	GREEN = 2
}
POP_notice.BUTTON_STYLE = BUTTON_STYLE

function POP_notice.open(msg, confirmFunc, cancelFunc, confirmDesc, cancelDesc, confirmButtonStyle, cancelButtonStyle)
	local ui = POP_notice.new(msg, confirmFunc, cancelFunc, confirmDesc, cancelDesc, confirmButtonStyle, cancelButtonStyle)

	display.getRunningScene():addChild(ui, LayerConfig.notice)
end

function POP_notice:ctor(msg, confirmFunc, cancelFunc, confirmDesc, cancelDesc, confirmButtonStyle, cancelButtonStyle)
	POP_notice.super.ctor(self, "pop_notice", UIManager.BIG_TYPE.POP)

	self.msg = msg
	self.confirmFunc = confirmFunc
	self.cancelFunc = cancelFunc
	self.confirmDesc = confirmDesc
	self.cancelDesc = cancelDesc
	self.confirmButtonStyle = confirmButtonStyle or BUTTON_STYLE.BLUE
	self.cancelButtonStyle = cancelButtonStyle or BUTTON_STYLE.BLUE

	self:init()
end

function POP_notice:init()
	self:initUI()

	if not self.cancelDesc then
		app:setKeyBackCallback(function ()
			local cancelFunc = self.cancelFunc

			self:removeSelf()

			if cancelFunc ~= nil then
				cancelFunc()
			end
		end)
	end
end

function POP_notice:initUI()
	local mask = self:getComponentByTag("mask")

	mask:toTouchable()
	self:createUbbOnFlag("flag_msg", self.msg, {
		wrap = true,
		align = Style.center,
		valign = Style.vcenter
	}, true)

	for k, index in pairs(BUTTON_STYLE) do
		local confirmPB = self:getComponentByTag("confirm_pb_" .. index)

		confirmPB:setVisible(self.confirmButtonStyle == index)

		local cancelPB = self:getComponentByTag("cancel_pb_" .. index)

		cancelPB:setVisible(self.cancelButtonStyle == index)
	end

	local confirmPB = self:getComponentByTag("confirm_pb_" .. self.confirmButtonStyle)

	if self.confirmDesc then
		confirmPB:addLabel(self.confirmDesc)
	end

	confirmPB:toTouchable()
	confirmPB:setTapGroup("button_click")

	local function handleConfirm()
		local confirmFunc = self.confirmFunc

		self:removeSelf()

		if confirmFunc ~= nil then
			confirmFunc()
		end
	end

	confirmPB:addTap(handleConfirm)

	local cancelPB = self:getComponentByTag("cancel_pb_" .. self.cancelButtonStyle)

	if self.cancelDesc then
		cancelPB:addLabel(self.cancelDesc)
	end

	cancelPB:toTouchable()
	cancelPB:setTapGroup("button_click")

	local function handleCancel()
		local cancelFunc = self.cancelFunc

		self:removeSelf()

		if cancelFunc ~= nil then
			cancelFunc()
		end
	end

	cancelPB:addTap(handleCancel)
end

function POP_notice:onExit()
	app:clearKeyBackCallback()
	POP_notice.super.onExit(self)
end

return POP_notice
