local AstarTile = class("AstarTile")
AstarTile.resetIndex = 0

function AstarTile:ctor(x, y)
	self.x = x
	self.y = y
	self.walk = 0

	self:reset()
end

function AstarTile:reset()
	self.inOpen = false
	self.closed = false
	self.gUp = false
	self.h = 0
	self.g = 0
	self.cost = 1
	self.inOpenIndex = 0
	self.closedIndex = 0
	self.parentIndex = 0
	self.gUpIndex = 0
	self.hIndex = 0
	self.gIndex = 0
end

function AstarTile:getClosed()
	if self.closedIndex == AstarTile.resetIndex then
		return self.closed
	else
		return false
	end
end

function AstarTile:setClosed()
	self.inOpen = false
	self.closed = true
	self.inOpenIndex = AstarTile.resetIndex
	self.closedIndex = AstarTile.resetIndex
end

function AstarTile:getOpen()
	if self.inOpenIndex == AstarTile.resetIndex then
		return self.inOpen
	else
		return false
	end
end

function AstarTile:setOpen()
	self.inOpen = true
	self.closed = false
	self.inOpenIndex = AstarTile.resetIndex
	self.closedIndex = AstarTile.resetIndex
end

function AstarTile:getCost()
	if self.gUpIndex == AstarTile.resetIndex then
		if self.gUp then
			return self.cost * 1.4142
		else
			return self.cost
		end
	else
		return self.cost
	end
end

function AstarTile:costUp()
	self.gUp = true
	self.gUpIndex = AstarTile.resetIndex
end

function AstarTile:costDown()
	self.gUp = false
	self.gUpIndex = AstarTile.resetIndex
end

function AstarTile:setH(ex, ey)
	self.h = math.abs(ex - self.x) + math.abs(ey - self.y)
	self.hIndex = AstarTile.resetIndex
end

function AstarTile:setG(g)
	self.g = g + self:getCost()
	self.gIndex = AstarTile.resetIndex
end

function AstarTile:getH()
	if self.hIndex == AstarTile.resetIndex then
		return self.h
	else
		return 0
	end
end

function AstarTile:getG()
	if self.gIndex == AstarTile.resetIndex then
		return self.g
	else
		return 0
	end
end

function AstarTile:getF()
	return self:getH() + self:getG()
end

function AstarTile:setParent(tile)
	self.parent = tile
	self.parentIndex = AstarTile.resetIndex
end

function AstarTile:getParent(tile)
	if self.parentIndex == AstarTile.resetIndex then
		return self.parent
	else
		return nil
	end
end

return AstarTile
