local List = import("...ui.List")
local LIST_dps = class("LIST_dps", List)

function LIST_dps:ctor(rect)
	LIST_dps.super.ctor(self, rect)
	self:setCellName("cell_dps")

	self.isBounc = false

	self:setCellSize(cc.size(self.touchRect.width, 40))
end

function LIST_dps:onCellInit(ui, data, index)
	if not ui.head then
		ui.head = HeadSlot.new(ui:getFlagByTag("flag_head"))

		ui:addChild(ui.head, 100)
	end

	ui.head:setHead({
		icon = data.user_info.head,
		frame = data.user_info.head_frame
	})

	local style = {}

	if not empty(data.user_info.nicklang) then
		style.lang = data.user_info.nicklang
		style.font = Localization.getFont(data.user_info.nicklang)
	end

	ui:createLabelOnFlag("flag_name", data.user_info.nickname, style)
	ui:createLabelOnFlag("flag_percent", math.floor(data.percent * 100) .. "%")

	local bar = ui:getComponentByTag("bar")

	bar:setColor(Style.golden)
	bar:setSize(bar.originalWidth * data.percent)
end

return LIST_dps
