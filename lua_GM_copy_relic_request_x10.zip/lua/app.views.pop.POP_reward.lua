local POP_reward = class("POP_reward", UI_base)

function POP_reward.open(rewardList, onClose, title)
	local ui = POP_reward.new(rewardList, title)

	Sound.playSound("gotitem")

	local mask = ui:getComponentByTag("mask")

	PopManager.open(ui, function ()
		mask:setVisible(false)
	end, onClose, PopManager.ANIM_TYPE.CENTER)
end

function POP_reward.openMixed(rewards, onClose, title, isStackItems)
	local rewardList = {}
	local medalList = {}

	if isStackItems then
		local newRewards = {}
		local stackItemMap = {}

		for i, v in ipairs(rewards) do
			if v.type == DropManager.TYPE.ITEM then
				if stackItemMap[v.item_id] then
					stackItemMap[v.item_id].item_num = stackItemMap[v.item_id].item_num + v.item_num
				else
					stackItemMap[v.item_id] = ObjUtil.copy(v)

					table.insert(newRewards, stackItemMap[v.item_id])
				end
			else
				table.insert(newRewards, v)
			end
		end

		rewards = newRewards
	end

	for i, v in ipairs(rewards) do
		local rewardInfo = DropManager.getRewardInfo(v)
		local isMedal = false

		if rewardInfo.type == DropManager.TYPE.ITEM then
			local itemCSV = CsvParser.getCsvData("item", rewardInfo.info.base_id)

			if itemCSV.type == 20 then
				isMedal = true
			end
		end

		if isMedal then
			table.insert(medalList, rewardInfo.info)
		else
			table.insert(rewardList, rewardInfo)
		end
	end

	if #rewardList > 0 then
		POP_reward.open(rewardList, onClose, title)
	end

	if #medalList > 0 then
		for i, itemInfo in ipairs(medalList) do
			POP_medal_get.open(itemInfo)
		end
	end
end

local maxCol = 6
local spaceX = 150
local spaceY = 144

function POP_reward:ctor(rewardList, title)
	local uiName = "pop_reward"

	if #rewardList > maxCol * 2 then
		uiName = "pop_reward_big"
		self.isBig = true
	end

	POP_reward.super.ctor(self, uiName, UIManager.BIG_TYPE.CENTER)

	self.rewardList = rewardList
	self.title = title

	self:init()
end

function POP_reward:init()
	self:initUI()
end

function POP_reward:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local mask = self:getComponentByTag("mask")

	mask:setOpacity(0)
	mask:toTouchable()

	if self.isBig then
		local function tapListener(ui, data, index, x, y)
			DropManager.popDetail(data.type, data.info)
		end

		self.list = self:createListOnFlag("flag_list", function (rect)
			return LIST_pop_reward.new(rect, maxCol)
		end, tapListener)

		self.list:setTapGroup("list_click")

		local holder = self:getComponentByTag("holder")

		self.list:setHolders({
			holder
		}, nil, 5)
		self.list:setItems(self.rewardList)
	else
		local centerFlag = self:getFlagByTag("flag_center")
		local row = math.ceil(#self.rewardList / maxCol)
		local col = math.ceil(#self.rewardList / row)
		local bg = self:getComponentByTag("bg")
		local bgHeight = bg.originalHeight + (row - 1) * spaceY
		local bgY = bg.y - (row - 1) * spaceY / 2

		bg:setSize(nil, bgHeight)
		bg:setPos(nil, bgY)

		for i, rewardInfo in ipairs(self.rewardList) do
			local bagSlot = DropSlot.new(centerFlag, "slot_02")

			bagSlot:setAlwaysShowNumber(true)
			bagSlot:setDrop(rewardInfo.type, rewardInfo.info)
			bagSlot:setDetailEnabled(true)

			local x = (i - 1) % col
			local y = math.floor((i - 1) / col)

			bagSlot:setPosition(centerFlag.x + spaceX * (x - (col - 1) / 2), centerFlag.y - spaceY * (y - (row - 1) / 2))
			self:addChild(bagSlot, 100)
		end

		local titleFlag = self:getFlagByTag("flag_title")
		titleFlag.y = bgY + bgHeight + 50
		local label_continue = self:getComponentByTag("label_continue")

		label_continue:setPositionY(bgY - 50)
	end

	if not empty(self.title) then
		self:createLabelOnFlag("flag_title", self.title)
	else
		self:removeLabelOnFlag("flag_title")
	end
end

return POP_reward
