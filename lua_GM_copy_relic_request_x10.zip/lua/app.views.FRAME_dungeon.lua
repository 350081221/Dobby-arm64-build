local UI_base = import(".UI_base")
local FRAME_dungeon = class("FRAME_dungeon", UI_base)
local CONTROL_TYPE = {
	PAD = 1,
	FULL = 2
}
local CONTROL = CONTROL_TYPE.FULL
local topMapRatio = 0.6
local SLOT_NUM = 6

function FRAME_dungeon:ctor()
	FRAME_dungeon.super.ctor(self, "frame_dungeon")

	global.newgiftSeason = InfoParams.getValue("newgift") or 1

	self:init()
end

function FRAME_dungeon:init()
	self:initUI()
	self:initController()
	self:initNpcUI()

	local notifyFlag = self:getFlagByTag("flag_notify")

	if notifyFlag then
		local popNotify = POP_notify.new(notifyFlag, {
			0
		})
		self.popNotify = popNotify

		display.getRunningScene():addChild(popNotify, LayerConfig.notify)
	end

	if InfoDungeon.isCamp() then
		InfoFarm.resetSort()

		local function delayEnter()
			self:removeEnterFrame("delayEnter")

			local preScene = InfoVars.get("scene")

			if preScene == 2 and InfoParams.getValue("union_pve") == 1 and InfoUnion.checkPveOpen() then
				FRAME_union_pve.open(nil, function ()
					InfoVars.set("scene", 0)
					self:initEnter()
				end)
			elseif preScene == 1 then
				Sound.playMusic("overworld")
				FRAME_wild.open()
			else
				if preScene == 2 then
					InfoVars.set("scene", 0)
				end

				self:initEnter()
			end
		end

		self:addEnterFrame("delayEnter", delayEnter)
	else
		self:initEnter()
	end

	if InfoUnion.inMap() then
		local preScene = InfoVars.get("scene")

		if preScene == 2 and InfoParams.getValue("union_pve") == 1 and InfoUnion.checkPveOpen() then
			FRAME_union_pve.open(nil, function ()
				InfoVars.set("scene", 0)
			end)
		end
	end

	if InfoDungeon.inNoSafe() then
		self:initTopMap()
	end

	self:initTeamScore()
	notify.safeRegister(self, "sneak_point_changed", function ()
		self:refreshSneakPoint()
	end)
	self:refreshSneakPoint()

	if InfoNaraka.inNarakaBoss() then
		self:initNaraka()
	end

	self:refreshLiuhai()
	notify.safeRegister(self, "liuhai_change", function ()
		self:refreshLiuhai()
	end)

	if global.autodown then
		self:refreshAutoDown()
	end

	if InfoDungeon.isHome() then
		UserCookie.set("main_map", "home", true)
	elseif InfoUnion.inMap() then
		UserCookie.set("main_map", "union", true)
	else
		UserCookie.set("main_map", nil, true)
	end

	if InfoDungeon.isCamp() then
		UserCookie.set("from_map", "camp", true)
	elseif InfoDungeon.isHome() then
		UserCookie.set("from_map", "home", true)
	elseif InfoUnion.inMap() then
		UserCookie.set("from_map", "union", true)
	end

	if InfoDungeon.isCamp() or InfoDungeon.inDungeonSafe() or InfoUnion.inMap() then
		InfoUnion.checkJoinList(function ()
			self:refreshUnion()
		end)
	end

	self:initSafeCheck()
end

function FRAME_dungeon:initSafeCheck()
	local preTime = nil

	local function checkSafe(isForce)
		if global.player and not global.player.inTeleport and not global.player:isGoDirectionLocked() then
			local nowTime = Time.time()

			if isForce or not preTime or nowTime > preTime + 1 then
				preTime = nowTime

				if global.player.tile then
					local checkOK = MapUtils.checkSafe(global.player.tile)

					self:enableSafeRecover(not checkOK)

					if not checkOK then
						print("$$$ checkSafe", checkOK)
					end
				end
			end
		end
	end

	if global.player then
		notify.safeRegister(global.player, "player_retile", function ()
			checkSafe(true)
		end)
		self:addEnterFrame("check_stuck", function ()
			checkSafe(false)
		end)
	end
end

function FRAME_dungeon:enableSafeRecover(enabled)
	if enabled then
		if not self.safeRecoverUI then
			local ui = UIManager.getUI("frame_recover_safe")

			self:addChild(ui, 1000)
			ui:setOpacity(0)
			transition.fadeTo(ui, {
				time = 0.2,
				easing = "sineOut",
				opacity = 255
			})

			local hint = ui:getComponentByTag("hint")

			Style.makePuyo(hint)

			local bg = ui:getComponentByTag("bg")

			bg:toTouchable()
			bg:setTapGroup("bg_click")
			bg:addTap(function ()
				POP_msg.open(Localization.getSrcText("您已离开探索区域\n点击返回正确的地图位置"))
			end)

			local bt_recover = ui:getComponentByTag("bt_recover")

			bt_recover:toTouchable()
			bt_recover:setTapGroup("button_click")
			bt_recover:addTap(function ()
				global.player:stop()
				MapUtils.recoverSafe()
			end)

			self.safeRecoverUI = ui
		end
	elseif self.safeRecoverUI then
		self.safeRecoverUI:removeSelf()

		self.safeRecoverUI = nil
	end
end

function FRAME_dungeon:refreshAutoDown()
	if not DEV_MODE then
		return
	end

	if global.autodown then
		self:addEnterFrame("auto_down", function ()
			if Transition.isOpening() then
				return
			end

			if global.player then
				if not self.autoDownDest then
					local mapX, mapY, eventIndex = CampUtils.getNpcGo(10105)

					if mapX and mapY then
						local tile = global.map:mapToTile(mapX, mapY)
						self.autoDownDest = {
							type = 1,
							tile = tile,
							eventIndex = eventIndex,
							x = mapX,
							y = mapY
						}
					end

					if not self.autoDownDest then
						local mapX, mapY, eventIndex = CampUtils.getGoNext()

						if mapX and mapY then
							local tile = global.map:mapToTile(mapX, mapY)
							self.autoDownDest = {
								type = 2,
								tile = tile,
								eventIndex = eventIndex,
								x = mapX,
								y = mapY
							}
						end
					end
				end

				if self.autoDownDest and not global.player.moving then
					if self.autoDownDest.type == 1 then
						if math.abs(global.player.tile.x - self.autoDownDest.tile.x) > 1 or math.abs(global.player.tile.y - self.autoDownDest.tile.y) > 1 then
							local path = MapUtils.getPathClose(self.autoDownDest.x, self.autoDownDest.y)

							if path then
								global.player:goPath(path, true)
							else
								local mapX, mapY = global.map:tileToMap(self.autoDownDest.tile.x, self.autoDownDest.tile.y + 1)

								global.player:draw(mapX, mapY, true)
							end
						else
							self:removeEnterFrame("auto_down")

							local function onSuccess(result)
								InfoDungeon.enterStage(result)
								DungeonScene.enterDungeon(DungeonScene.ENTER_TYPE.NEW, result)
							end

							InfoDust.enterNext(self.autoDownDest.eventIndex, 0, InfoDust.getCurrLevel(), onSuccess, nil, true)
						end
					elseif self.autoDownDest.type == 2 then
						if not global.player.tile ~= self.autoDownDest.tile then
							local path = MapUtils.getPathTo(self.autoDownDest.x, self.autoDownDest.y)

							if path then
								global.player:goPath(path, true)
							else
								local mapX, mapY = global.map:tileToMap(self.autoDownDest.tile.x, self.autoDownDest.tile.y)

								global.player:draw(mapX, mapY, true)
							end
						else
							self:removeEnterFrame("auto_down")
						end
					end
				end
			end
		end)
	else
		self:removeEnterFrame("auto_down")
	end
end

function FRAME_dungeon:refreshLiuhai()
	print("$$$ refreshLiuhai", self.exitUI, self.shrineUI, UIManager.getLiuhai())

	if self.exitUI then
		if UIManager.getLiuhai() == "right" then
			self.exitUI:setPositionX(-UIManager.LIUHAI_WIDTH)
		else
			self.exitUI:setPositionX(0)
		end
	end

	if self.shrineUI then
		if UIManager.getLiuhai() == "right" then
			self.shrineUI:setPositionX(-UIManager.LIUHAI_WIDTH)
		else
			self.shrineUI:setPositionX(0)
		end
	end
end

function FRAME_dungeon:refreshSneakPoint()
	local point = InfoDungeon.getSneakPoint()

	if point > 0 then
		self.mainUI:replaceLabelOnFlag("flag_sneak_point", nil, point)
	else
		self.mainUI:removeLabelOnFlag("flag_sneak_point")
	end
end

function FRAME_dungeon:onWildClose()
	self:playBgm()

	if InfoGuide.isFin() then
		InfoVars.set("scene", 0)
	end

	self:initEnter()
	self:refreshBardPosition()
end

function FRAME_dungeon:initEnter()
	if self.alreadyEnter then
		return
	end

	self.alreadyEnter = true
	local popCaution = POP_caution.new()

	self:addChild(popCaution)

	if InfoDungeon.isCamp() then
		if global.dungeonVersionDiffData then
			FRAME_dungeon_result.open(global.dungeonVersionDiffData, FRAME_dungeon_result.OPEN_TYPE.VERSION)

			global.dungeonVersionDiffData = nil
		end

		InfoDungeon.checkExit()
	elseif InfoDungeon.inNoSafe() then
		self:initShrine()
		notify.safeRegister(self, "shrine_changed", function ()
			self:refreshShrine()
		end)
		self:refreshShrine()
	end

	InfoOrder.recover(function (rcvData)
		local rewards = rcvData.rewards

		if #rewards > 0 then
			POP_reward.openMixed(rewards, nil, Localization.getSrcText("充值补单到账"))
		end

		if rcvData.order_info and #rcvData.order_info > 0 then
			local str = ""

			for i, orderInfo in ipairs(rcvData.order_info) do
				if not empty(orderInfo.goods_id) then
					local csv = CsvParser.getCsvData("rmb_cost", orderInfo.goods_id, nil, true)

					if csv then
						str = str .. "\n" .. csv.name
					end
				end
			end

			if str ~= "" then
				str = "[color=238,199,111]" .. Localization.getSrcText("充值补单到账") .. "[/color]" .. str

				POP_msg.open(str, {
					align = Style.left
				})
			end
		end
	end)
	InfoUser.creditRecover(function (rcvData)
		if rcvData.amount_100 and rcvData.amount_100 > 0 then
			local str = "[color=254,174,14]{1}[/color][color=238,199,111]" .. Localization.getSrcText("代金券到账") .. "[/color]"

			POP_msg.open(StringUtil.replace(str, rcvData.amount_100 / 100), {
				align = Style.center
			})
		end
	end)

	if InfoParams.getValue("union_gwar") == 1 then
		InfoUnion.triggerCheck()
	end

	if InfoParams.getValue("union_pve") == 1 then
		InfoUnion.triggerCheckPVE()
	end

	InfoActvRecord.trySign()

	local function startGuide()
		print("$$$ startGuide")

		if InfoGuide.isFin() and InfoGuide.getFreeRecord(28) == 0 then
			print("28号自由引导未完成处理")
			InfoGuide.finishFree(28)
		end

		if not self:initGuide() then
			local function onFunctionGuideComplete()
				self:initGuidePoint()
			end

			if InfoDungeon.isCamp() then
				local buildList = InfoBuilding.getBuildGuideList()

				if #buildList > 0 then
					DungeonScene.stopChat()
					global.player:setGoDirectionLocked("build_guide", true)
					Looper.setTimeout(function ()
						self:initBuildingGuide(buildList, function ()
							self:initFunctionGuide(onFunctionGuideComplete)
						end)
					end, 30, self)
				else
					self:initFunctionGuide(onFunctionGuideComplete)
				end
			else
				self:initGuidePoint()
			end

			return
		end

		self:initGuidePoint()
	end

	if InfoDungeon.isCamp() then
		self:showFirstReport(startGuide)
		self:initStall()
		InfoArena.battleOverCheck()

		if not InfoUser.refreshHeadFrameArena() then
			InfoUser.checkHead(function (rcvData)
				local changed = rcvData.changed

				if changed and #changed > 0 then
					local arr = {}
					local hasHead = false
					local hasFrame = false

					for i, itemID in ipairs(changed) do
						local itemCSV = CsvParser.getCsvData("item", itemID)

						table.insert(arr, {
							base_id = itemID
						})

						if itemCSV.type == 18 then
							hasHead = true
						elseif itemCSV.type == 19 then
							hasFrame = true
						end
					end

					if hasHead and hasFrame then
						POP_show_item.open(arr, Localization.getSrcText("头像和头像框过期"))
					elseif hasHead then
						POP_show_item.open(arr, Localization.getSrcText("头像过期"))
					else
						POP_show_item.open(arr, Localization.getSrcText("头像框过期"))
					end
				end
			end)
		end
	elseif InfoDungeon.isHome() then
		self:initHome()
	elseif InfoUnion.inMap() then
		if InfoGuide.getFreeRecord(38) == 0 and global.player then
			InfoGuide.guideFree(38, global.player)
		end
	else
		startGuide()
	end

	if InfoDungeon.isCamp() or InfoDungeon.inDustPrepare() then
		if InfoArena.isActived() then
			InfoArena.checkSeason()
		end

		InfoCampfire.checkSeason()
		InfoSigil.autoOff()
		InfoActvStage.checkRankingReward()
	end

	InfoHero.autoOff()
	InfoPet.autoOff()
	InfoDust.checkSeason()
	LuaBridge.initEnter()
end

function FRAME_dungeon:initHome()
	if InfoHome.isSelf() then
		InfoHome.getTips(function (rcvData)
			local rewards = rcvData.rewards

			if rewards and #rewards > 0 then
				POP_reward.openMixed(rewards, nil, Localization.getSrcText("其他玩家留下的使用费"))
			end
		end)
		InfoHome.checkVisitor(function (rcvData)
			local hasNew = rcvData.visit_get_time < rcvData.last_visit_time

			if hasNew then
				local deviceID = InfoBuilding.getDeviceByBuilding(InfoBuilding.TAG.HOME_POSTBOX)
				local postbox = Npc.getDevice(deviceID)

				if postbox then
					postbox:setAction("opened")
				end
			end
		end)
	else
		local npcID = InfoBuilding.getNpcByBuilding(InfoBuilding.TAG.HOME_POSTBOX)
		local postbox = Npc.getInstance(npcID)

		if postbox then
			postbox:setAction("opened")
		end
	end

	if InfoHome.isSelf() then
		InfoPetFeed.checkReward(function (rcvData)
			if rcvData.visit_feed and rcvData.visit_feed > 0 then
				local str = Localization.getSrcText("收获访客投喂[color=238,199,111]{1}[/color]点")

				POP_msg.open(StringUtil.replace(str, rcvData.visit_feed))
			end
		end)
	end

	local petArea = MapEventManager.getEventByTagOne("pet_area")

	if petArea then
		local petArr = nil

		if InfoHome.isSelf() then
			petArr = InfoPetFeed.getPetList()
		else
			petArr = {}
			local pets = InfoHome.getFeedPets()

			for i, v in ipairs(pets) do
				local petInfo = {
					level = 1,
					base_id = v.pet_base_id,
					quality = v.pet_quality,
					pet_name = v.pet_name
				}
				local feedData = v

				table.insert(petArr, {
					petInfo = petInfo,
					feedData = feedData
				})
			end
		end

		Map.walkOnVislble = false
		local freeTileArr, tileMap = MapUtils.findFreeTile(petArea.x, petArea.y, petArea.w, petArea.h)
		Map.walkOnVislble = true
		freeTileArr = Random.randomOrder(freeTileArr)

		for i, v in ipairs(petArr) do
			if #freeTileArr > 0 then
				local freeTile = table.remove(freeTileArr, 1)
				local petInfo = v.petInfo
				local unit = Npc.new()

				unit:setPetID(petInfo.base_id)

				unit.angle = 90
				unit.isBlock = false
				unit.noBlock = true
				unit.alwaysVisible = true

				unit:randomizeFrame()

				local mapX, mapY = global.map:tileToMap(freeTile)

				unit:display(global.map, mapX, mapY)

				unit.feedData = v
				unit.priority = -100
				local petCSV = CsvParser.getCsvData("pet", petInfo.base_id)

				unit:setPatrolData(petCSV.patrol_step, petCSV.patrol_wait, petCSV.patrol_way)
				unit:setPatrolArea(tileMap)
				unit:wake()
				unit:waitForPatrol(true)
			else
				break
			end
		end
	end
end

function FRAME_dungeon:initGuidePoint()
	print("$$$ initGuidePoint")

	if InfoGuide.isFin() then
		if InfoDungeon.isCamp() then
			if InfoGuide.getFreeRecord(18) == 0 and InfoItem.getNum(113000) > 0 then
				InfoGuide.triggerFree(18)

				return
			end

			InfoRebate.checkReward()
		elseif InfoDungeon.inDungeon() and InfoDungeon.getType() == InfoDungeon.TYPE.ABYSS and InfoGuide.getFreeRecord(34) == 0 then
			local petTeam = InfoPet.getTeam()

			if #petTeam > 1 then
				InfoGuide.triggerFree(34)
			end
		end
	else
		if InfoDungeon.inDungeon() and InfoGuide.getFreeRecord(28) == 0 then
			notify.safeRegister(self, "battle_over_drama", function ()
				GuideManager.free28()
			end)
		end

		self:refreshGuidePoint()
		ManagerInfo.onDataChange(self, "main_guide", nil, function ()
			self:refreshGuidePoint()
		end)

		if InfoDungeon.getEnterLayer() == 0 then
			GuideManager.tryGuideRantile()
			ManagerInfo.onDataChange(self, "main_guide", nil, function ()
				GuideManager.tryGuideRantile()
			end)
			notify.safeRegister(self, "guide_rantile", function ()
				local function delayCall()
					self:removeEnterFrame("delay_guide_rantile")
					GuideManager.tryGuideRantile()
				end

				self:addEnterFrame("delay_guide_rantile", delayCall)
			end)
		end
	end
end

function FRAME_dungeon:refreshGuidePoint()
	if InfoDungeon.isCamp() then
		GuideManager.removeGuideMove()
	end

	GuideManager.stopChangeHero()
	GuideManager.stopBuilding()
	GuideManager.stopEquipEnhance()
	GuideManager.stopHeroTransfer()
	GuideManager.stopMirror()
	GuideManager.stopCardOn()
	GuideManager.stopWild()

	local guideCSV = nil
	local currentGuide = InfoGuide.getCurrent()

	if currentGuide then
		if currentGuide == 1030 then
			local team = InfoHero.getTeam()

			if #team >= 3 then
				InfoGuide.finish(currentGuide)
				InfoGuide.setID(currentGuide)

				currentGuide = InfoGuide.getCurrent()

				ManagerInfo.dataChange("main_guide")
			end
		end

		if currentGuide == 7040 then
			local bagItems = InfoItem.getWareList(3)
			local blueIndex, checkBlueLevel = nil
			local team = InfoHero.getTeam()

			for i, heroInfo in ipairs(team) do
				if heroInfo.quality >= 2 then
					blueIndex = i

					if heroInfo.level >= 20 then
						checkBlueLevel = true
					end

					break
				end
			end

			if #bagItems == 0 or checkBlueLevel then
				InfoGuide.finish(currentGuide)
				InfoGuide.setID(currentGuide)

				currentGuide = InfoGuide.getCurrent()
			end

			if currentGuide == 7040 then
				print("$$$ blueIndex", blueIndex)

				if blueIndex then
					DramaManager.presetHintReplace({
						blueIndex
					})
				end
			end
		end

		local csv = CsvParser.getCsvData("guide", currentGuide)

		if csv then
			if InfoDungeon.isCamp() then
				if not empty(csv.change_hero) then
					GuideManager.startChangeHero(csv)
				elseif csv.fin_type == 2 or csv.fin_type == 3 then
					GuideManager.startBuilding(csv)
				elseif csv.easy_guide == 1 then
					local onHintOver = nil

					if csv.id == 5030 then
						function onHintOver()
							GuideManager.fingerDrag(csv.hint_1, 2)
						end
					end

					if not empty(csv.point_type) then
						GuideManager.startBuilding(csv, onHintOver)
					else
						GuideManager.startEasy(csv, onHintOver)
					end
				elseif csv.id == 11010 then
					GuideManager.startWild(csv)
				elseif csv.id == 8010 then
					GuideManager.startHeroTransfer(csv)
				elseif csv.id == 10020 then
					GuideManager.startCardOn(csv)
				elseif not empty(csv.point_type) then
					GuideManager.goPointNpc(csv)
				end
			end

			guideCSV = csv
		end
	end
end

function FRAME_dungeon:initFunctionGuide(onComplete)
	local guideList = InfoFunction.getGuideList()

	if #guideList > 0 then
		DungeonScene.stopChat()

		local tags = {}
		local guideNext = nil

		function guideNext()
			if #guideList > 0 then
				local funcCSV = table.remove(guideList, 1)

				DramaManager.start(funcCSV.open_drama, nil, , guideNext)
				global.player:setGoDirectionLocked("function_guide", true)
				table.insert(tags, funcCSV.id)
			else
				global.player:setGoDirectionLocked("function_guide", false)
				InfoFunction.setGuided(tags)

				if onComplete then
					onComplete()
				end
			end
		end

		guideNext()

		return
	end

	if onComplete then
		onComplete()
	end
end

function FRAME_dungeon:initBuildingGuide(buildList, onComplete)
	local playerX = global.player.x
	local playerY = global.player.y
	local tags = {}
	local guideNext = nil

	function guideNext()
		if #buildList > 0 then
			local tag = table.remove(buildList, 1)

			table.insert(tags, tag)

			local npcID, x, y = CampUtils.findBuldingNpc(tag)

			if x and y then
				local _, _, buildingCSV = InfoBuilding.getBuildingLevel(tag)
				local mapX, mapY = global.map:tileToMap(x, y)

				global.map:tweenFov(mapX, mapY, 60)
				global.map:tweenScrollTo(mapX, mapY, 60, function ()
					HintManager.open(buildingCSV.build_hint, guideNext)
				end)

				return
			end

			print("没找到建筑引导坐标", tag)

			if global.player then
				global.player:clearGoDirectionLocked()
			end
		else
			global.map:tweenFov(playerX, playerY, 60)
			global.map:tweenScrollTo(playerX, playerY, 60, function ()
				global.player:setGoDirectionLocked("build_guide", false)
				InfoBuilding.setGuided(tags)

				if onComplete then
					onComplete()
				end
			end)
		end
	end

	guideNext()
end

function FRAME_dungeon:initGuide()
	notify.safeRegister(self, "guide_drama_over", function ()
		InfoGuide.tryTrigger(1010, 1020, 1040)
	end)

	if InfoDungeon.inDungeon() and InfoGuide.getFreeRecord(5) == 0 then
		notify.safeRegister(self, "player_move", function ()
			if InfoGuide.getFreeRecord(5) == 0 then
				TaHelper.taGuideDetail(11000)
			end
		end)
	end

	if InfoDungeon.isCamp() then
		notify.safeRegister(self, "drama_open_nickname", function ()
			FRAME_nickname.open(function ()
				TaHelper.taGuideDetail(10300)
				DramaManager.resumeFromEvent()
			end)
		end)
		notify.safeRegister(self, "drama_open_tavern", function ()
			local npc = Npc.getInstance(10003)

			FRAME_tavern.open(npc, function ()
				DramaManager.resumeFromEvent()
			end)
		end)

		return InfoGuide.tryTrigger(1000, 1010, 1020, 1040)
	elseif InfoDungeon.inDungeon() and InfoDungeon.getType() == InfoDungeon.TYPE.ABYSS and InfoDungeon.getDungeonCSV().layer == 4 then
		return InfoGuide.triggerFree(9)
	end

	return false
end

function FRAME_dungeon:ready()
	InfoModao.initDungeon(false)

	if InfoDungeon.inNoSafe() then
		self:initModao()
	end

	self:playBgm()

	if self.popNotify then
		self.popNotify:setActive(true)
	end

	self:refreshBardPosition()
end

function FRAME_dungeon:playBgm()
	if global.map and not empty(global.map.params.new_bgm) then
		Sound.playMusic(global.map.params.new_bgm)

		return
	end

	if OnlineCamp.isOnline() then
		if InfoDungeon.isHome() and InfoHome.initMusic() then
			return
		end

		Sound.playMusic(MiscConfig.bgm_camp)
	else
		local terrainCSV = InfoDungeon.getTerrainCSV()

		if terrainCSV then
			Sound.playMusic(terrainCSV.bgm_normal)
		end
	end
end

function FRAME_dungeon:out()
	self:stopControl()

	if self.popNotify then
		self.popNotify:setActive(false)
	end
end

function FRAME_dungeon:initStall()
	if not global.player then
		return
	end

	local stallEvents = {}
	local events = MapEventManager.getEventByTagArray("stall")

	for i, v in ipairs(events) do
		local info = ConfParser.parse(v.info)
		stallEvents[info.pos] = v
	end

	self.stallTileMap = {}

	InfoExchange.getStalls(self:safeFunc(function (rcvData)
		for i, v in ipairs(rcvData.stalls) do
			local event = stallEvents[i]

			if event then
				self:makeStall(event, v)
			end
		end
	end))

	local function checkStall()
		if global.player and global.player.tile then
			local obj = self.stallTileMap[global.player.tile.x .. "_" .. global.player.tile.y]

			if obj then
				if not self.npcUI or self.npcUI.stallObj ~= obj then
					if self.npcUI and self.npcUI.stallObj then
						self.npcUI:close(true)

						self.npcUI = nil
					end

					local ui = NAV_stall.open(obj.npc, obj.stallData)
					ui.stallObj = obj
					self.npcUI = ui
				end
			elseif self.npcUI and self.npcUI.stallObj then
				self.npcUI:close()

				self.npcUI = nil
			end
		end
	end

	global.player:addEventListener("retile", function ()
		self:performWithDelay(checkStall, 0.1)
	end)
end

function FRAME_dungeon:makeStall(eventData, stallData)
	local apprData = json.decode(stallData.appr)

	if apprData then
		local name = stallData.name
		local mapX, mapY = global.map:tileToMap(eventData)
		local hero = nil

		if apprData.hero then
			local data = apprData.hero
			local unit = OnlinePlayer.new()
			local info = {
				level = 1,
				body = data.b,
				hair = data.h,
				quality = data.q,
				base_id = data.id
			}

			unit:setInfo(info)

			unit.angle = 90
			unit.isBlock = true
			unit.alwaysVisible = true

			unit:randomizeFrame()
			unit:display(global.map, mapX, mapY)
			unit:setAction("sit")
			unit:setTitleStr(name or "", 0)

			hero = unit
		else
			return
		end

		local unit = Effect.new()
		local blanketModel = nil

		if apprData.blanket then
			blanketModel = InfoExchange.getBlanketByItem(apprData.blanket.id)
		else
			blanketModel = InfoExchange.getBlanketByItem()
		end

		unit:load(blanketModel)

		unit.alwaysVisible = true

		unit:display(global.map, mapX, mapY, global.map.lightLayer)
		unit:setScale(1 / global.map.config.scale.unit)

		if apprData.pet then
			local data = apprData.pet
			local unit = Pet.new()
			local info = {
				level = 1,
				base_id = data.id,
				quality = data.q
			}

			unit:setInfo(info)

			unit.angle = 90
			unit.isBlock = true
			unit.alwaysVisible = true

			unit:randomizeFrame()

			local mapX, mapY = global.map:tileToMap(eventData.x + 1, eventData.y)

			unit:display(global.map, mapX, mapY)
		end

		local obj = {
			npc = hero,
			stallData = stallData
		}
		self.stallTileMap[eventData.x .. "_" .. eventData.y + 1] = obj
		self.stallTileMap[eventData.x + 1 .. "_" .. eventData.y + 1] = obj
	end
end

function FRAME_dungeon:getBottomUiName()
	if InfoDungeon.isCamp() then
		return "frame_dungeon_nav_camp"
	elseif InfoDungeon.isHome() then
		if InfoHome.isSelf() then
			return "frame_dungeon_nav_home"
		else
			return "frame_dungeon_nav_visit"
		end
	elseif InfoUnion.inMap() then
		return "frame_dungeon_nav_union"
	elseif InfoDungeon.inDungeonSafe() then
		if InfoDungeon.inDustPrepare() then
			return "frame_dungeon_nav_dust_prepare"
		else
			return "frame_dungeon_nav_safe"
		end
	elseif InfoDungeon.inDust() then
		return "frame_dungeon_nav_dust"
	else
		return "frame_dungeon_nav_dungeon"
	end
end

function FRAME_dungeon:initNaraka()
	local ui = FRAME_naraka_main.new()

	self:addChild(ui)
end

function FRAME_dungeon:initTeamScore()
	local preScore = InfoHero.getTeamScore()

	ManagerInfo.onDataChange(self, {
		"hero",
		"equip",
		"pet",
		"card",
		"sigil",
		"artifact"
	}, nil, function ()
		local newScore = InfoHero.getTeamScore()

		if preScore < newScore then
			POP_team_score.open(preScore, newScore)
		end

		preScore = newScore
	end)
end

function FRAME_dungeon:initUI()
	self.mainUI = UIManager.getUI("frame_dungeon_main", UIManager.BIG_TYPE.BOTTOM)

	self:addChild(self.mainUI)

	self.headUI = FRAME_main_head.new(nil, function (type, info)
		if type == DropManager.TYPE.HERO then
			if InfoDungeon.isFixedTeam() then
				FRAME_hero.openDetail(info)
			else
				FRAME_hero.open(info)
			end
		elseif type == DropManager.TYPE.PET then
			if InfoDungeon.isFixedTeam() then
				FRAME_pet.openDetail(info)
			else
				FRAME_pet.open(info)
			end
		end
	end)

	self:addChild(self.headUI)

	local bg = self.mainUI:getComponentByTag("bg")

	bg:setOpacity(0)
	bg:setLocalZOrder(-1)
	bg:setVisible(false)

	local buildingMatList = InfoBuilding.getBuildingMatList()
	local moneyList = {
		GameConfig.zuan_item,
		GameConfig.coin_item,
		GameConfig.farm_item
	}
	local resourceCount = #buildingMatList + #moneyList
	local bottomUI = nil

	if InfoDungeon.isCampHome() or InfoDungeon.inDungeonSafe() or InfoUnion.inMap() then
		local arr = {}

		for i, v in ipairs(moneyList) do
			table.insert(arr, v)
		end

		for i, v in ipairs(buildingMatList) do
			table.insert(arr, v)
		end

		if InfoDungeon.inDungeonSafe() then
			global.resource = FRAME_main_resource.new("frame_main_resource", resourceCount, unpack(moneyList))
		else
			global.resource = FRAME_main_resource.new("frame_main_resource", resourceCount, unpack(arr))
		end

		self:addChild(global.resource)

		if InfoDungeon.isCamp() then
			self.mainTaskUI = FRAME_main_task.new(FRAME_main_task.TYPE.CAMP)

			self:addChild(self.mainTaskUI)
		elseif InfoDungeon.isHome() then
			self:addChild(FRAME_main_home.new())
		elseif InfoUnion.inMap() then
			-- Nothing
		end

		if InfoDungeon.inDungeonSafe() or InfoUnion.inMap() then
			local uiName = "frame_main_exit_stage_2"

			if InfoUnion.inMap() then
				uiName = "frame_main_exit_union"
			end

			local exitUI = UIManager.getUI(uiName, UIManager.BIG_TYPE.TOP)

			self:addChild(exitUI)

			local buttonExit = exitUI:getComponentByTag("bt_exit")

			buttonExit:toTouchable()
			buttonExit:setTapGroup("button_click")

			local function onExit()
				FRAME_dungeon_exit.open(FRAME_dungeon_exit.OPEN_TYPE.SAFE, "是否离开当前地图？", function ()
					InfoDungeon.exit(0, function (rcvData)
						InfoDungeon.onLeave(rcvData)
					end)
				end)
			end

			buttonExit:addTap(onExit)

			local buttonCount = 0

			if InfoParams.getValue("union_gwar") == 1 and InfoUnion.inWarSeason() then
				local bt_union_war = exitUI:getComponentByTag("bt_union_war")

				if bt_union_war then
					bt_union_war:toTouchable()
					bt_union_war:setTapGroup("button_click")
					bt_union_war:addTap(function ()
						if InfoUnion.inWarSeason() then
							local step = InfoUnion.checkUnionWarSeason()

							if step == InfoUnion.UNION_WAR_STEP.ENROLL then
								Alert.open(Localization.getSrcText("联盟会战报名中，等待开启"))
							else
								FRAME_union_war_zone.open(0)
							end
						else
							Alert.open(Localization.getSrcText("不在联盟会战赛季中"))
						end
					end)

					buttonCount = buttonCount + 1
				end
			else
				exitUI:removeComponentByTag("bt_union_war")
			end

			if InfoParams.getValue("union_pve") == 1 and InfoUnion.checkPveOpen() then
				local bt_union_pve = exitUI:getComponentByTag("bt_union_pve")

				if bt_union_pve then
					bt_union_pve:toTouchable()
					bt_union_pve:setTapGroup("button_click")
					bt_union_pve:addTap(function ()
						if InfoUnion.checkPveOpen() then
							FRAME_union_pve.open()
						else
							Alert.open(Localization.getSrcText("猩红之月未开启"))
						end
					end)

					if Localization.isAlphabet() then
						local label = bt_union_pve.label

						if label then
							label:setLineHeight(18)
						end
					end

					if buttonCount == 1 then
						if not bt_union_pve.preX then
							bt_union_pve.preX = bt_union_pve.x
						end

						bt_union_pve:setPos(bt_union_pve.preX - 80)
					end
				end
			else
				exitUI:removeComponentByTag("bt_union_pve")
			end

			self.exitUI = exitUI
		end
	else
		self.shrineUI = UIManager.getUI("frame_dungeon_shrine", UIManager.BIG_TYPE.TOP)

		self:addChild(self.shrineUI)

		local map_mutate_bg = self.shrineUI:getComponentByTag("map_mutate_bg")

		map_mutate_bg:setVisible(false)
		map_mutate_bg:setOpacity(0)

		local icon_mutate = self.shrineUI:getComponentByTag("icon_mutate")

		icon_mutate:setVisible(false)
		icon_mutate:setOpacity(200)

		local icon_terrain = self.shrineUI:getComponentByTag("icon_terrain")

		icon_terrain:setVisible(false)
		icon_terrain:setOpacity(200)

		if not empty(InfoDungeon.getID()) then
			if InfoDungeon.getType() == InfoDungeon.TYPE.TASK then
				local task_id = InfoDungeon.getQuestDbID()
				local taskInfo = InfoTaskQuest.getData(task_id)
				local dungeonID = taskInfo.dungeon_id
				local taskCSV = CsvParser.getCsvData("task", taskInfo.base_id)
				local mapData = CsvParser.getCsvData("task_quest_map", dungeonID .. "_" .. taskCSV.quest_id)

				self.shrineUI:createLabelOnFlag("flag_map_name", mapData.target_text)
			else
				local dungeonCSV = InfoDungeon.getDungeonCSV()
				local mutateCSV = InfoDungeon.getMutate()
				local terrainCSV = InfoDungeon.getTerrain()
				local style = {}

				if terrainCSV then
					style.color = Style.font2
				end

				local name = dungeonCSV.name

				if InfoDungeon.inDust() then
					local str = Localization.getSrcText("{1}层")
					name = name .. " " .. StringUtil.replace(str, InfoDust.getCurrLevel())
				end

				local namelabel, nameLabelWidth = self.shrineUI:createLabelOnFlag("flag_map_name", name, style)

				if mutateCSV or terrainCSV then
					local x = nil

					if mutateCSV then
						local mutatelabel, mutateLabelWidth = self.shrineUI:createLabelOnFlag("flag_map_mutate", mutateCSV.name)
						x = math.min(namelabel:getPositionX() - nameLabelWidth / 2, mutatelabel:getPositionX() - mutateLabelWidth / 2)

						icon_mutate:setVisible(true)
						icon_mutate:setScale(0.9)
						icon_mutate:setPos(mutatelabel:getPositionX() - mutateLabelWidth / 2 - 18)
					else
						x = namelabel:getPositionX() - nameLabelWidth / 2
					end

					if terrainCSV then
						icon_terrain:setVisible(true)
						icon_terrain:setPos(namelabel:getPositionX() - nameLabelWidth / 2 - 30)
					end

					map_mutate_bg:setVisible(true)

					local mutateBgX = display.width - x
					local bigScale = UIManager.getBigScale()

					if bigScale ~= 1 then
						mutateBgX = display.width / bigScale - x
					end

					map_mutate_bg:setSize(mutateBgX)
					map_mutate_bg:setPos(x)
					map_mutate_bg:toTouchable()
					map_mutate_bg:setTapGroup("bg_click")
					map_mutate_bg:addTap(function ()
						FRAME_abyss_mutate.open(dungeonCSV, mutateCSV, terrainCSV)
					end)
				end
			end
		end

		global.resource = FRAME_main_resource.new("frame_main_resource", resourceCount, unpack(moneyList))

		self:addChild(global.resource)

		local exitUI = nil

		if InfoDungeon.getType() == InfoDungeon.TYPE.ABYSS or InfoDungeon.inDust() then
			exitUI = UIManager.getUI("frame_main_exit_abyss", UIManager.BIG_TYPE.TOP)

			self:addChild(exitUI)
			exitUI:createIconOnFlag("icon_tp", IconManager.getItemIcon(GameConfig.tp_item), nil, true)

			local function doExit(type)
				InfoDungeon.exit(type, function (rcvData)
					FRAME_dungeon_result.open(rcvData, FRAME_dungeon_result.OPEN_TYPE.EXIT)
					InfoBag.clearBagItemInfo()
				end)
			end

			local function onExitAbyss(type)
				InfoBag.saveBagItemInfo()

				if type == 2 then
					TaHelper.taGuideDetail(14400)
				end

				if type == 0 then
					POP_notice.open(Localization.getSrcText("有损返回会损失背包内物品，是否返回？"), function ()
						doExit(type)
					end)
				else
					doExit(type)
				end
			end

			local function onExit()
				if InfoGuide.isAbyssExitLocked() then
					Alert.open(Localization.getSrcText("当前深渊无法使用"))

					return
				end

				FRAME_dungeon_exit.open(FRAME_dungeon_exit.OPEN_TYPE.MOON, "放弃战利品返回营地\n或者使用月之钥安全返回", function ()
					onExitAbyss(0)
				end, function ()
					onExitAbyss(3)
				end)
			end

			local exitBtn = exitUI:getComponentByTag("bt_exit")

			exitBtn:toTouchable()
			exitBtn:addTap(onExit)
			exitBtn:setTapGroup("button_click")

			local function onExitTp()
				if InfoGuide.isAbyssExitLocked() then
					Alert.open(Localization.getSrcText("当前深渊无法使用"))

					return
				end

				if InfoDungeon.isLayerSafe() then
					FRAME_dungeon_exit.open(FRAME_dungeon_exit.OPEN_TYPE.SAFE, "安全返回营地吗？", function ()
						onExitAbyss(2)
					end)
				else
					FRAME_dungeon_exit.open(FRAME_dungeon_exit.OPEN_TYPE.TP, "使用小浮石安全返回营地？", function ()
						onExitAbyss(1)
					end)
				end
			end

			local exitTpBtn = exitUI:getComponentByTag("bt_exit_tp")

			exitTpBtn:toTouchable()
			exitTpBtn:addTap(onExitTp)
			exitTpBtn:setTapGroup("button_click")
		elseif InfoDungeon.getType() == InfoDungeon.TYPE.STAGE then
			local stageType, stageID = InfoDungeon.getStage()
			local stageCSV = InfoDungeon.getDungeonCSV()

			if stageType == InfoDungeon.STAGE_TYPE.ACTV then
				local actvStageCSV = CsvParser.getCsvData("actv_stage", stageID)

				if actvStageCSV and actvStageCSV.type == 3 then
					local function updateTimeUsed()
						local str1 = Localization.getSrcText("用时")
						local isNewRecord = InfoActvStage.checkNewRecord(stageID)

						if isNewRecord then
							str1 = Localization.getSrcText("新纪录")
						end

						local timeUsed = nil

						if InfoDungeon.isPassed() then
							local data = InfoActvStage.getData(InfoActvStage.getActvID(stageID))
							timeUsed = data.level_time_mark
						else
							timeUsed = InfoDungeon.getTimeUsed()
						end

						local str2 = Time.showSec(timeUsed)

						if str1 ~= self.timeUsedStr1 or str2 ~= self.timeUsedStr2 then
							self.timeUsedStr1 = str1
							self.timeUsedStr2 = str2
							local style1 = {
								color = isNewRecord and Style.golden or Style.font1
							}
							local style2 = {
								color = Style.font3
							}

							self.shrineUI:createLabelGroupOnFlag("flag_time_used", {
								str1,
								str2
							}, {
								style1,
								style2
							})
						end
					end

					self:addEnterFrame("updateTimeUsed", updateTimeUsed)
				end
			end

			if not empty(stageCSV.mark) then
				exitUI = UIManager.getUI("frame_main_exit_stage", UIManager.BIG_TYPE.TOP)

				self:addChild(exitUI)

				local buttonExit = exitUI:getComponentByTag("bt_exit")
				local buttonFinish = exitUI:getComponentByTag("bt_finish")

				local function onExit()
					FRAME_dungeon_exit.open(FRAME_dungeon_exit.OPEN_TYPE.SAFE, "是否放弃当前关卡？", function ()
						InfoDungeon.exit(0, function (rcvData)
							if CONFIG.is_ta then
								local stageType, stageID = InfoDungeon.getStage()

								if stageType == InfoDungeon.STAGE_TYPE.NARAKA_BOSS then
									TaHelper.taTrack("dailyboss_lose", {
										stage_id = stageID,
										hero_info = TaHelper.getHeroInfoAll(),
										diffpoint = InfoNaraka.getPoints()
									})
								end
							end

							InfoDungeon.onLeave(rcvData)
						end)
					end)
				end

				local function onFinish()
					FRAME_dungeon_exit.open(FRAME_dungeon_exit.OPEN_TYPE.SAFE, "完成关卡，离开当前地图？", function ()
						InfoDungeon.finishStage(function (rcvData)
							if CONFIG.is_ta then
								local stageType, stageID = InfoDungeon.getStage()

								if stageType == InfoDungeon.STAGE_TYPE.NARAKA_BOSS then
									TaHelper.taTrack("dailyboss_win", {
										stage_id = stageID,
										hero_info = TaHelper.getHeroInfoAll(),
										diffpoint = InfoNaraka.getPoints()
									})
								end
							end

							local rewards = rcvData.rewards

							if rewards and #rewards > 0 then
								POP_reward.openMixed(rewards, function ()
									InfoDungeon.onLeave(rcvData)
								end)
							else
								InfoDungeon.onLeave(rcvData)
							end
						end)
					end)
				end

				buttonExit:toTouchable()
				buttonExit:addTap(onExit)
				buttonFinish:toTouchable()
				buttonFinish:addTap(onFinish)
				buttonExit:setTapGroup("button_click")
				buttonFinish:setTapGroup("button_click")
			else
				exitUI = UIManager.getUI("frame_main_exit_stage_2", UIManager.BIG_TYPE.TOP)

				self:addChild(exitUI)

				local buttonExit = exitUI:getComponentByTag("bt_exit")

				buttonExit:toTouchable()
				buttonExit:setTapGroup("button_click")

				local function onExit()
					FRAME_dungeon_exit.open(FRAME_dungeon_exit.OPEN_TYPE.SAFE, "是否离开当前地图？", function ()
						InfoDungeon.exit(0, function (rcvData)
							InfoDungeon.onLeave(rcvData)
						end)
					end)
				end

				buttonExit:addTap(onExit)
			end
		elseif InfoDungeon.getType() == InfoDungeon.TYPE.QUEST or InfoDungeon.getType() == InfoDungeon.TYPE.TASK then
			exitUI = UIManager.getUI("frame_main_exit_quest", UIManager.BIG_TYPE.TOP)

			self:addChild(exitUI)

			local questBtn = exitUI:getComponentByTag("bt_quest")
			local questFinishBtn = exitUI:getComponentByTag("bt_quest_finish")

			local function onOpenQuest()
				if not InfoDungeon.getID() then
					FRAME_dungeon_exit.open(FRAME_dungeon_exit.OPEN_TYPE.SAFE, "回到营地？", function ()
						InfoDungeon.enterCamp()
					end)

					return
				end

				if InfoDungeon.getType() == InfoDungeon.TYPE.QUEST then
					FRAME_quest.open()
				elseif InfoDungeon.getType() == InfoDungeon.TYPE.TASK then
					FRAME_task.open()
				end
			end

			questBtn:toTouchable()
			questBtn:addTap(onOpenQuest)
			questFinishBtn:toTouchable()
			questFinishBtn:addTap(onOpenQuest)
			questBtn:setTapGroup("button_click")
			questFinishBtn:setTapGroup("button_click")
		end

		self.exitUI = exitUI
	end

	local bottomUI = UIManager.getUI(self:getBottomUiName(), UIManager.BIG_TYPE.BOTTOM)

	self:addChild(bottomUI)

	self.bottomUI = bottomUI

	if InfoDungeon.inDustPrepare() then
		local bt_pass = bottomUI:getComponentByTag("bt_pass")

		bt_pass:toTouchable()
		bt_pass:setTapGroup("button_click")
		bt_pass:addTap(function ()
			FRAME_dust_pass.open()
		end)

		local redot_pass = bottomUI:getComponentByTag("redot_pass")
		local bigScale = UIManager.getBigScale()

		if bigScale ~= 1 then
			local bigY = display.height * (1 / bigScale - 1)

			bt_pass:setPos(nil, bt_pass.y + bigY)
			redot_pass:setPos(nil, redot_pass.y + bigY)
		end
	end

	if InfoDungeon.inNoSafe() then
		self:initQuickItem()
		self:initRune()
	end

	if InfoDungeon.isCamp() or InfoDungeon.isHome() or InfoDungeon.inDungeonSafe() or InfoUnion.inMap() then
		local marukaBt = bottomUI:getComponentByTag("bt_maruka")

		marukaBt:toTouchable()
		marukaBt:setTapGroup("button_click")
		marukaBt:addTap(function ()
			FRAME_maruka.open()
		end)
		ManagerInfo.onDataChange(self, {
			"achieve",
			"likes",
			"travel",
			"arena",
			"tower",
			"naraka",
			"kanban"
		}, nil, function ()
			self:refreshMaruka()
		end)
		self:refreshMaruka()

		local emojiButton = self.bottomUI:getComponentByTag("bt_emoji")

		emojiButton:toTouchable()
		emojiButton:addTap(function ()
			FRAME_emoji.open()
		end)
		emojiButton:setTapGroup("button_click")
	end

	if InfoDungeon.isCamp() or InfoDungeon.inDungeonSafe() or InfoUnion.inMap() then
		local paygiftButton = self.bottomUI:getComponentByTag("bt_paygift")

		paygiftButton:toTouchable()
		paygiftButton:addTap(function ()
			FRAME_paygift.open()
		end)
		paygiftButton:setTapGroup("button_click")
		ManagerInfo.onDataChange(self, {
			"paygift",
			"main_guide"
		}, nil, function ()
			self:refreshPaygift()
		end)
		self:refreshPaygift()

		local teamBt = bottomUI:getComponentByTag("bt_team")

		teamBt:toTouchable()
		teamBt:setTapGroup("button_click")
		teamBt:addTap(function ()
			if not InfoGuide.isFin() and not InfoGuide.isAfter(1030) then
				Alert.open(Localization.getSrcText("请先完成前序引导"))

				return
			end

			FRAME_team.open()
		end)

		local petBt = bottomUI:getComponentByTag("bt_pet")

		petBt:toTouchable()
		petBt:setTapGroup("button_click")
		petBt:addTap(function ()
			FRAME_team_pet.open()
		end)

		local unionBt = bottomUI:getComponentByTag("bt_union")

		unionBt:toTouchable()
		unionBt:setTapGroup("button_click")
		unionBt:addTap(function ()
			local unionID = InfoUnion.getUnionID()

			FRAME_union_info.open(unionID, true, FRAME_union_info.TYPE.MY)
		end)
		self:refreshUnion()
	end

	if InfoDungeon.isHome() and InfoHome.isSelf() then
		local deviceBt = bottomUI:getComponentByTag("bt_device")

		deviceBt:toTouchable()
		deviceBt:setTapGroup("button_click")
		deviceBt:addTap(function ()
			if FRAME_main_home.instance then
				FRAME_main_home.instance:setDeviceOpen(true)
			end
		end)

		local managerBt = bottomUI:getComponentByTag("bt_manager")

		managerBt:toTouchable()
		managerBt:setTapGroup("button_click")
		managerBt:addTap(function ()
			FRAME_home_manager.open()
		end)

		local bt_home_shop = bottomUI:getComponentByTag("bt_home_shop")

		bt_home_shop:toTouchable()
		bt_home_shop:setTapGroup("button_click")
		bt_home_shop:addTap(function ()
			FRAME_big_shop.open(InfoHome)
		end)

		local bt_pet_feed = bottomUI:getComponentByTag("bt_pet_feed")

		bt_pet_feed:toTouchable()
		bt_pet_feed:setTapGroup("button_click")
		bt_pet_feed:addTap(function ()
			if InfoParams.getValue("home_pet") == 1 then
				FRAME_pet_feed.open()
			else
				Alert.open(Localization.getSrcText("功能尚未开放"))
			end
		end)
	end

	if InfoDungeon.isCamp() then
		local wildBt = bottomUI:getComponentByTag("bt_wild")

		wildBt:toTouchable()
		wildBt:setTapGroup("button_click")
		wildBt:addTap(function ()
			local currentGuide = InfoGuide.getCurrent()

			if currentGuide and currentGuide < 11010 then
				Alert.open(Localization.getSrcText("请先完成前序引导"))

				return
			end

			Sound.playMusic("overworld")
			POP_mask.open(15, 255, nil, , function ()
				FRAME_wild.open()
				POP_mask.open(30, 0)
			end)
		end)

		local dustBt = bottomUI:getComponentByTag("bt_dust")

		dustBt:toTouchable()
		dustBt:setTapGroup("button_click")
		dustBt:addTap(function ()
			FRAME_dust.open()
		end)
	end

	if InfoDungeon.isCamp() or InfoDungeon.inDungeonSafe() or InfoUnion.inMap() then
		self:refreshNavButtons()
		ManagerInfo.onDataChange(self, {
			"building",
			"item",
			"main_guide",
			"pet",
			"dust",
			"union",
			"params"
		}, nil, function ()
			self:refreshNavButtons()
		end)
		ManagerInfo.onDataChange(self, {
			"union_answer",
			"union"
		}, nil, function ()
			self:refreshUnion()
		end)

		if InfoDungeon.inDustPrepare() then
			self:refreshDustButtons()
			ManagerInfo.onDataChange(self, {
				"dust",
				"dust_achieve",
				"dust_pass",
				"dust_attr_manual"
			}, nil, function ()
				self:refreshDustButtons()
			end)
		end
	elseif InfoDungeon.isHome() then
		local bt_emoji = bottomUI:getComponentByTag("bt_emoji")
		self.bottomX = bt_emoji:getPositionX() - bt_emoji.width / 2
	end

	if InfoDungeon.inNoSafe() then
		local bagBt = bottomUI:getComponentByTag("bt_bag")

		bagBt:toTouchable()
		bagBt:setTapGroup("button_click")
		bagBt:addTap(function ()
			if InfoDungeon.isFixedTeam() then
				FRAME_hero.openDetail(global.player.info)
			else
				FRAME_hero.open(global.player.info, FRAME_hero.OPEN_TYPE.BAG)
			end
		end)

		if InfoDungeon.inDust() then
			local bt_dust_team = bottomUI:getComponentByTag("bt_dust_team")

			bt_dust_team:toTouchable()
			bt_dust_team:setTapGroup("button_click")
			bt_dust_team:addTap(function ()
				FRAME_dust_team.open()
			end)
		end

		local battleSetupBt = self.shrineUI:getComponentByTag("bt_battle_setup")

		battleSetupBt:toTouchable()
		battleSetupBt:setTapGroup("button_click")
		battleSetupBt:addTap(function ()
			FRAME_battle_setup.open()
		end)

		local bt_top_map = self.shrineUI:getComponentByTag("bt_top_map")

		bt_top_map:toTouchable()
		bt_top_map:setTapGroup("button_click")
		bt_top_map:addTap(function ()
			FRAME_top.open()
		end)

		local bigScale = UIManager.getBigScale()

		if bigScale ~= 1 then
			local bigY = display.height * (1 / bigScale - 1)

			battleSetupBt:setPos(nil, battleSetupBt.y - bigY)
			bt_top_map:setPos(nil, bt_top_map.y - bigY)
		end

		bottomUI.bt_battle_setup = battleSetupBt
		bottomUI.bt_top_map = bt_top_map

		if InfoDungeon.getType() == InfoDungeon.TYPE.QUEST or InfoDungeon.getType() == InfoDungeon.TYPE.TASK or InfoDungeon.getType() == InfoDungeon.TYPE.STAGE and not InfoDungeon.inDust() then
			notify.safeRegister(self, "pass_changed", function ()
				self:refreshExitUI()
			end)
			self:refreshExitUI()
		elseif InfoDungeon.getType() == InfoDungeon.TYPE.ABYSS or InfoDungeon.inDust() then
			ManagerInfo.onDataChange(self, "bag", nil, function ()
				self:refreshExitUI()
			end)
			notify.safeRegister(self, "layer_safe_changed", function ()
				self:refreshExitUI()
			end)
			self:refreshExitUI()
		end
	end
end

function FRAME_dungeon:refreshDustButtons()
	local bottomUI = self.bottomUI
	local bt_pass = bottomUI:getComponentByTag("bt_pass")
	local redot_pass = bottomUI:getComponentByTag("redot_pass")

	if bt_pass then
		local dustState, dustID = InfoDust.getState()
		local redotCount = 0

		if InfoDust.STATE.TO_BEGIN <= dustState and dustState < InfoDust.STATE.ENDED then
			redotCount = FRAME_dust_pass.countRedot(dustID)
		end

		redot_pass:setVisible(redotCount > 0)
	end
end

function FRAME_dungeon:refreshNavButtons(isSelfCall)
	local bottomUI = self.bottomUI
	local unionBt = bottomUI:getComponentByTag("bt_union")
	local dustBt = bottomUI:getComponentByTag("bt_dust")
	local wildBt = bottomUI:getComponentByTag("bt_wild")
	local teamBt = bottomUI:getComponentByTag("bt_team")
	local petBt = bottomUI:getComponentByTag("bt_pet")
	local marukaBt = bottomUI:getComponentByTag("bt_maruka")
	local paygiftButton = self.bottomUI:getComponentByTag("bt_paygift")
	local redot_paygift = self.bottomUI:getComponentByTag("redot_paygift")

	if redot_paygift and paygiftButton then
		paygiftButton.redot = redot_paygift
	end

	local redot_union = self.bottomUI:getComponentByTag("redot_union")

	if redot_union and unionBt then
		unionBt.redot = redot_union
	end

	if not self.buttonStartX then
		self.buttonStartX = marukaBt.x
	end

	local startX = self.buttonStartX
	local offsetX = 95
	local buttonArr = {
		marukaBt,
		petBt,
		teamBt,
		wildBt,
		paygiftButton,
		unionBt,
		dustBt
	}
	local openArr = {}
	local allArr = {}

	if marukaBt then
		table.insert(allArr, marukaBt)

		if InfoGuide.isFin() then
			table.insert(openArr, marukaBt)
			marukaBt:setVisible(true)
		else
			marukaBt:setVisible(false)
		end
	end

	if petBt then
		table.insert(allArr, petBt)

		if InfoBuilding.getBuildingLevel(InfoBuilding.TAG.PET) > 0 or InfoPet.count() > 0 then
			table.insert(openArr, petBt)
			petBt:setVisible(true)
		else
			petBt:setVisible(false)
		end
	end

	if teamBt then
		table.insert(allArr, teamBt)
		table.insert(openArr, teamBt)
	end

	if wildBt then
		table.insert(allArr, wildBt)

		if InfoFunction.checkFuncOpen(10110) then
			table.insert(openArr, wildBt)
			wildBt:setVisible(true)
		else
			wildBt:setVisible(false)
		end
	end

	if paygiftButton then
		table.insert(allArr, paygiftButton)

		if InfoGuide.isFin() then
			table.insert(openArr, paygiftButton)
			paygiftButton:setVisible(true)
		else
			paygiftButton:setVisible(false)
		end
	end

	if unionBt then
		local showUnion = false

		table.insert(allArr, unionBt)

		local opening = InfoParams.getValue("union")

		if opening == 1 and InfoUnion.hasUnion() then
			table.insert(openArr, unionBt)

			showUnion = true

			unionBt:setVisible(true)
		else
			unionBt:setVisible(false)
		end

		if showUnion then
			unionBt:resetLabel(nil, 100)

			if not unionBt.unionFlag then
				unionBt.unionFlag = UnionFlag.new({
					width = 81,
					x = 0,
					y = 17,
					height = 81
				})

				unionBt:addChild(unionBt.unionFlag)
			end

			local unionInfo = InfoUnion.getUnionInfo()

			unionBt.unionFlag:setFlag(unionInfo.union_icon)
		elseif unionBt.unionFlag then
			unionBt.unionFlag:removeSelf()

			unionBt.unionFlag = nil
		end
	end

	local dustState, dustID, dustNextTime = InfoDust.getState()

	if dustBt then
		local showDust = false

		table.insert(allArr, dustBt)

		if InfoDust.showNav() then
			table.insert(openArr, dustBt)

			showDust = true

			dustBt:setVisible(true)
		else
			dustBt:setVisible(false)
		end

		if showDust then
			dustBt:resetLabel(nil, 100)

			if not dustBt.spine then
				local spine = Effect.new()

				spine:loadSpine("ui_dust")
				spine:refreshSpine()
				spine:setPosition(dustBt.width / 2, dustBt.height / 2 + 12)
				dustBt:addChild(spine)

				dustBt.spine = spine
			end

			local spine = dustBt.spine

			if dustState == InfoDust.STATE.TO_BEGIN or not InfoDust.isAreaReady(dustID) then
				spine:setAction("idle")
			else
				spine:setAction("opened")
			end
		elseif dustBt.spine then
			dustBt.spine:removeSelf()

			dustBt.spine = nil
		end
	end

	for i, button in ipairs(openArr) do
		button:setVisible(true)

		local buttonX = startX - (i - 1) * offsetX

		button:setPos(buttonX)

		if button.redot then
			local offx = button.redot.originalX - button.originalX

			button.redot:setPos(button.x + offx)
		end

		if button.subFlags then
			for j, tag in ipairs(button.subFlags) do
				local flag = self:getFlagByTag(tag)

				if flag then
					local offx = flag.originalX - button.originalX
					flag.x = button.x + offx
				end
			end
		end
	end

	local leftestButton, leftestButtonX = nil

	for i, button in ipairs(allArr) do
		local buttonX = startX - (i - 1) * offsetX

		if not leftestButtonX or buttonX < leftestButtonX then
			leftestButton = button
			leftestButtonX = buttonX
		end
	end

	if dustBt and dustBt:isVisible() then
		self:removeEnterFrame("dustBt_refresh_loop")

		if dustState == InfoDust.STATE.BEGAN then
			-- Nothing
		elseif dustState == InfoDust.STATE.TO_BEGIN or dustState == InfoDust.STATE.TO_END then
			local function refreshTime()
				local timeLeft = dustNextTime - Time.now()

				if timeLeft >= 0 then
					-- Nothing
				end
			end

			if not isSelfCall then
				refreshTime()
			end

			self:addEnterFrame("dustBt_refresh_loop", refreshTime)
		end
	end

	local emojiButton = self.bottomUI:getComponentByTag("bt_emoji")
	local smallOffsetX = leftestButton.originalX - emojiButton.originalX
	local smallArr = {
		emojiButton
	}

	for i, v in ipairs(smallArr) do
		v:setPos(startX - (#openArr - 1) * offsetX - i * smallOffsetX)
	end

	self.bottomX = startX - (#openArr - 1) * offsetX - #smallArr * smallOffsetX

	self:refreshMaruka()
	self:refreshBardPosition()
end

function FRAME_dungeon:refreshUnion()
	local redot_union = self.bottomUI:getComponentByTag("redot_union")

	redot_union:setVisible(InfoUnion.hasJoinList())
end

function FRAME_dungeon:refreshPaygift()
	local redot_paygift = self.bottomUI:getComponentByTag("redot_paygift")

	redot_paygift:setVisible(false)
end

function FRAME_dungeon:refreshMaruka()
	if InfoGuide.isFin() then
		local redot_maruka = self.bottomUI:getComponentByTag("redot_maruka")

		redot_maruka:setVisible(InfoMaruka.countRedot() > 0)

		local count, total = InfoMaruka.getDailyProgress()
		local style = {}

		if total <= count then
			style.color = Style.enableColor
		end

		self.bottomUI:replaceLabelOnFlag("flag_maruka", style, math.min(count, total), total)
	else
		local redot_maruka = self.bottomUI:getComponentByTag("redot_maruka")

		redot_maruka:setVisible(false)
		self.bottomUI:removeLabelOnFlag("flag_maruka")
	end
end

function FRAME_dungeon:showFirstReport(onClose)
	local popCount = 0

	InfoCharge.recoverGift()

	local function onCloseOne()
		popCount = popCount - 1

		print("$$$ popCount", popCount)

		if popCount <= 0 then
			onClose()
		end
	end

	if InfoAbyssReward.hasReward() then
		popCount = popCount + 1

		InfoAbyssReward.getReward(function (rcvData)
			local rewards = rcvData.rewards
			local exp = rcvData.exp

			if rewards and #rewards > 0 or exp > 0 then
				print("$$$ FRAME_abyss_reward", rewards, exp)
				FRAME_abyss_reward.openMixed(rewards, exp, onCloseOne)
			end
		end, onCloseOne)
	end

	local reportArr = {}

	local function onLoadComplete()
		popCount = popCount + 1

		FRAME_first_report.open(reportArr, onCloseOne)
	end

	local loader = AsyncLoader.new()
	local checkList = InfoItem.getDropCheckList()

	if #checkList > 0 then
		loader:add(function (complete_callback, error_callback)
			InfoItem.dropCheck(checkList, function (rcvData)
				for i, v in ipairs(rcvData.list) do
					table.insert(reportArr, {
						type = FRAME_first_report.TYPE.DROP_CHECK,
						base_id = v
					})
				end

				complete_callback()
			end, error_callback)
		end, "补贵重品")
	end

	if InfoGuide.isFin() then
		local currentDay = Time.getDay(time)

		if not global.marukaDay or global.marukaDay < currentDay then
			global.marukaDay = currentDay

			Log.debug("登录报告")

			local likesOffline = InfoLikes.countLikesOffline()

			if likesOffline > 0 then
				loader:add(function (complete_callback, error_callback)
					InfoLikes.harvest(function (rcvData)
						table.insert(reportArr, {
							type = FRAME_first_report.TYPE.LIKES,
							data = rcvData
						})
						complete_callback()
					end, error_callback)
				end, "收取离线点赞")
			end

			local mygiftArr = InfoMygift.getJumpList()

			if #mygiftArr > 0 then
				for i, data in ipairs(mygiftArr) do
					if not InfoMygift.checkIgnore(data.id) then
						popCount = popCount + 1

						FRAME_mygift.open(data.id, onCloseOne)
					end
				end
			end

			local recordArr = InfoActvRecord.getJumpList()

			if #recordArr > 0 then
				for i, data in ipairs(recordArr) do
					popCount = popCount + 1

					FRAME_actv_sign.open("frame_sign_week", {
						actv_id = data.actv_id,
						actv_type = GameConfig.ACTV_TYPE.record
					}, onCloseOne)
				end
			end

			if InfoRecordMonth.countRedot() > 0 then
				popCount = popCount + 1

				FRAME_record_month.open(onCloseOne)
			end

			if InfoRecordFest.isActived(InfoRecordFest.TYPE.WEEK) and InfoRecordFest.countRedot(InfoRecordFest.TYPE.WEEK) > 0 then
				popCount = popCount + 1

				FRAME_record_week.open(onCloseOne)
			end

			local giftArr = InfoOrder.getNewgiftList(true, global.newgiftSeason)

			if #giftArr > 0 then
				popCount = popCount + 1

				FRAME_newgift.open(onCloseOne, true, global.newgiftSeason)
			end
		end
	end

	if loader:count() > 0 then
		loader:start(function ()
			onLoadComplete()
		end, function ()
		end, function (index, total, msg)
		end)
	elseif popCount == 0 then
		onClose()
	end
end

function FRAME_dungeon:initController()
	local controlPadArr = nil

	if CONTROL == CONTROL_TYPE.FULL then
		local circleRadius = 60
		local tapThreshold = 10
		local speedAdjust = 0.7
		local controlPadV, controlPadTile = nil
		local bg = self.mainUI:getComponentByTag("bg")

		bg:setVisible(true)
		bg:toTouchable()
		bg:addTouch(function (event, x, y)
			POP_conn.clearCount()

			if not global.player then
				return
			end

			if event == "began" then
				if controlPadV then
					controlPadV:removeSelf()

					controlPadV = nil
				end

				if controlPadTile then
					controlPadTile:removeSelf()

					controlPadTile = nil
				end

				self.touching = true
				local mapX, mapY = global.map:screenToMap(x, y)
				local tile = global.map:mapToTile(mapX, mapY)

				if not global.player:isGoDirectionLocked() then
					controlPadTile = UIManager.getUI("control_pad_tile")

					global.map.lowLayer:addChild(controlPadTile)

					local fixedX, fixedY = global.map:tileToMap(tile)
					local drawX, drawY = global.map:mapToDraw(fixedX, fixedY)

					controlPadTile:setScale(0)
					transition.scaleTo(controlPadTile, {
						scale = 1,
						time = 0.1,
						easing = "sineOut"
					})
					transition.fadeTo(controlPadTile, {
						time = 0.1,
						easing = "sineOut",
						opacity = 255
					})
					controlPadTile:setPosition(drawX, -drawY)
				end

				self.controlV = {
					isTap = true,
					startX = x,
					startY = y,
					tapTile = tile
				}
			elseif event == "moved" then
				if not self.touching then
					return
				end

				local distance = math.sqrt(math.pow(y - self.controlV.startY, 2) + math.pow(x - self.controlV.startX, 2))

				if self.controlV.isTap and tapThreshold < distance then
					self.controlV.isTap = false
					controlPadV = UIManager.getUI("control_pad_v")

					self:addChild(controlPadV)
					controlPadV:setPosition(self.controlV.startX, self.controlV.startY)
					controlPadV:setOpacity(0)
					transition.fadeTo(controlPadV, {
						time = 0.1,
						easing = "sineOut",
						opacity = 255
					})

					local circle = controlPadV:getComponentByTag("circle")

					circle:setOpacity(100)

					if controlPadTile then
						local tempControlPadTile = controlPadTile
						controlPadTile = nil

						transition.stopTarget(tempControlPadTile)
						transition.fadeTo(tempControlPadTile, {
							time = 0.1,
							easing = "sineOut",
							opacity = 0,
							onComplete = function ()
								tempControlPadTile:removeSelf()
							end
						})
					end

					if not global.player:isGoDirectionLocked() then
						global.player:stop("beforeMove")
					end
				end

				if not self.controlV.isTap and not global.player:isGoDirectionLocked() then
					local angle = math.atan2(y - self.controlV.startY, x - self.controlV.startX)
					local radius = math.min(distance, circleRadius)
					local speedPercent = radius / circleRadius
					global.speedPercent = 1 - speedAdjust + speedAdjust * speedPercent
					local circle = controlPadV:getComponentByTag("circle")

					circle:setOpacity(speedPercent >= 1 and 255 or 100)

					local point = controlPadV:getComponentByTag("point")

					point:setPosition(math.cos(angle) * radius, math.sin(angle) * radius)

					local td = 4
					local perA = math.pi * 2 / td
					local d = math.floor((angle - math.pi / 2) / perA + 3)
					d = 4 - d
					d = d % td + 1
					d = d * 2

					global.player:goDirection(d)
					notify.dispatch("player_go_start")
				end
			elseif event == "ended" then
				if not self.touching then
					if controlPadV then
						controlPadV:removeSelf()

						controlPadV = nil
					end

					if controlPadTile then
						controlPadTile:removeSelf()

						controlPadTile = nil
					end

					return
				end

				global.speedPercent = 1

				self:stopControl()

				if self.controlV.isTap then
					if self.controlV.tapTile and self.controlV.tapTile.x then
						local fixedX, fixedY = global.map:tileToMap(self.controlV.tapTile)

						if not global.player:isGoDirectionLocked() then
							global.player:go(fixedX, fixedY)

							if controlPadTile then
								local tempControlPadTile = controlPadTile
								controlPadTile = nil

								transition.stopTarget(tempControlPadTile)
								transition.scaleTo(tempControlPadTile, {
									scale = 0,
									time = 0.1,
									easing = "linear"
								})
								transition.fadeTo(tempControlPadTile, {
									time = 0.1,
									easing = "sineOut",
									opacity = 0,
									onComplete = function ()
										tempControlPadTile:removeSelf()
									end
								})
							end
						end

						notify.dispatch("map_tap", fixedX, fixedY)
					elseif controlPadTile then
						controlPadTile:removeSelf()

						controlPadTile = nil
					end
				else
					transition.fadeTo(controlPadV, {
						time = 0.1,
						easing = "sineOut",
						opacity = 0
					})

					if controlPadV then
						local tempControlPadV = controlPadV
						controlPadV = nil

						transition.stopTarget(tempControlPadV)
						transition.fadeTo(tempControlPadV, {
							time = 0.1,
							easing = "sineOut",
							opacity = 0,
							onComplete = function ()
								tempControlPadV:removeSelf()
							end
						})
					end
				end

				self.controlV = nil
			end
		end)
	elseif CONTROL == CONTROL_TYPE.PAD then
		local controlPadUI = self:createUIOnFlag("flag_control_pad", "control_pad", 10)
		local controlPad = controlPadUI:getComponentByTag("control_pad")
		controlPadArr = {}

		for i = 1, 4 do
			controlPadArr[i] = controlPadUI:getComponentByTag("control_pad_" .. i)

			controlPadArr[i]:setVisible(false)
		end

		controlPad:toTouchable()
		controlPad:addTouch(function (event, x, y)
			POP_conn.clearCount()

			if event == "began" or event == "moved" then
				if event == "began" then
					self.touching = true
				elseif event == "moved" and not self.touching then
					return
				end

				if global.freemove then
					local padX, padY = controlPad:getPosition()
					local x, y = global.map:drawToMap(x - padX, -(y - padY))
					local angle = math.atan2(y, x)
					local freeDirection = angle

					global.player:goFreeDirection(freeDirection)
				else
					local padX, padY = controlPad:getPosition()
					local angle = math.atan2(y - padY, x - padX)
					local td = 4
					local perA = math.pi * 2 / td
					local d = math.floor((angle - math.pi / 2) / perA + 3)
					d = 4 - d
					local currentControlPad = controlPadArr[d]

					if self.highLightControlPad ~= currentControlPad then
						if self.highLightControlPad then
							self.highLightControlPad:setVisible(false)
						end

						self.highLightControlPad = currentControlPad

						self.highLightControlPad:setOpacity(0)
						transition.fadeIn(self.highLightControlPad, {
							easing = "sineOut",
							time = 0.1
						})
						self.highLightControlPad:setVisible(true)
					end

					d = d % td + 1
					d = d * 2

					global.player:goDirection(d)
					notify.dispatch("player_go_start")
				end
			elseif event == "ended" then
				self:stopControl()
			end
		end)
	end

	if device.platform == "windows" then
		local pressQueue = {}
		local wasd = {
			[146.0] = 2,
			[124.0] = 3,
			[127.0] = 1,
			[142.0] = 0
		}

		self:addNodeEventListener(cc.KEYPAD_EVENT, function (event)
			if wasd[event.code] then
				if event.type == "Pressed" then
					table.insert(pressQueue, event.code)

					self.touching = true
				elseif event.type == "Released" then
					for i, v in ipairs(pressQueue) do
						if v == event.code then
							table.remove(pressQueue, i)

							break
						end
					end
				end

				if #pressQueue > 0 then
					local td = 4
					local perA = math.pi * 2 / td
					local d = wasd[pressQueue[#pressQueue]]
					d = 4 - d

					if controlPadArr then
						local currentControlPad = controlPadArr[d]

						if self.highLightControlPad ~= currentControlPad then
							if self.highLightControlPad then
								self.highLightControlPad:setVisible(false)
							end

							self.highLightControlPad = currentControlPad

							self.highLightControlPad:setOpacity(0)
							transition.fadeIn(self.highLightControlPad, {
								easing = "sineOut",
								time = 0.1
							})
							self.highLightControlPad:setVisible(true)
						end
					end

					d = d % td + 1
					d = d * 2

					global.player:goDirection(d)
					notify.dispatch("player_go_start")
				else
					self:stopControl()
				end
			elseif event.code == 59 and event.type == "Released" then
				PopManager.closeAll(true)
			end
		end)
		self:setKeypadEnabled(true)
	end
end

function FRAME_dungeon:refreshExitUI()
	if not InfoDungeon.getID() then
		return
	end

	if InfoDungeon.getType() == InfoDungeon.TYPE.ABYSS or InfoDungeon.inDust() then
		local exitBtn = self.exitUI:getComponentByTag("bt_exit")
		local exitTpBtn = self.exitUI:getComponentByTag("bt_exit_tp")
		local tpBG = self.exitUI:getComponentByTag("tp_bg")
		local tpItemNum = InfoBag.getItemNum(GameConfig.tp_item)
		local isSafe = InfoDungeon.isLayerSafe() or tpItemNum > 0

		exitTpBtn:setVisible(isSafe)
		exitBtn:setVisible(not isSafe)
		self.exitUI:createLabelOnFlag("flag_tp", tpItemNum)
	elseif InfoDungeon.getType() == InfoDungeon.TYPE.STAGE then
		local stageType, stageID = InfoDungeon.getStage()
		local stageCSV = InfoDungeon.getDungeonCSV()

		if not empty(stageCSV.mark) then
			local isPassed, count, total = nil

			if stageType > 100 then
				isPassed, count, total = OnlineCamp.isPassed()
			else
				isPassed, count, total = InfoDungeon.isPassed()
			end

			local exitButton = self.exitUI:getComponentByTag("bt_exit")
			local finishButton = self.exitUI:getComponentByTag("bt_finish")

			exitButton:setVisible(not isPassed)
			finishButton:setVisible(isPassed)
			self.exitUI:replaceLabelOnFlag("flag_passed", nil, count, total)

			if isPassed then
				if not OnlineCamp.inRoom() then
					self:performWithDelay(function ()
						POP_quest_finish.open()
					end, 1.5)
				end

				InfoGuide.triggerFree(26)
			end
		end
	elseif InfoDungeon.getType() == InfoDungeon.TYPE.QUEST or InfoDungeon.getType() == InfoDungeon.TYPE.TASK then
		local isPassed, count, total = InfoDungeon.isPassed()
		local questBtn = self.exitUI:getComponentByTag("bt_quest")
		local questFinishBtn = self.exitUI:getComponentByTag("bt_quest_finish")
		local questBG = self.exitUI:getComponentByTag("quest_bg")

		if self.exitButtonHidden then
			questBG:setVisible(false)
			questBtn:setVisible(false)
			questFinishBtn:setVisible(false)
			self.exitUI:removeLabelOnFlag("flag_quest")
			self.exitUI:removeLabelGroupOnFlag("flag_quest")
		else
			questBG:setVisible(true)
			questBtn:setVisible(not isPassed)
			questFinishBtn:setVisible(isPassed)
			self.exitUI:replaceLabelOnFlag("flag_quest", nil, count, total)
		end

		if isPassed then
			if not OnlineCamp.inRoom() then
				self:performWithDelay(function ()
					POP_quest_finish.open()
				end, 1.5)
			end

			if InfoDungeon.getType() == InfoDungeon.TYPE.QUEST then
				InfoGuide.triggerFree(24)
			elseif InfoDungeon.getType() == InfoDungeon.TYPE.TASK then
				InfoGuide.triggerFree(25)
			end
		end
	end
end

function FRAME_dungeon:setExitButtonVisible(b)
	self.exitButtonHidden = not b

	self:refreshExitUI()
end

function FRAME_dungeon:stopControl()
	if not self.touching then
		return
	end

	if not global.player then
		return
	end

	self.touching = nil

	if global.freemove then
		global.player:stopFreeDirection(true)
	else
		global.player:stopDirection(true)
	end

	if self.highLightControlPad then
		self.highLightControlPad:setVisible(false)

		self.highLightControlPad = nil
	end
end

function FRAME_dungeon:initRune()
	if InfoFunction.checkFuncOpen(10170) then
		local bigScale = UIManager.getBigScale()
		local rune_bg = self.shrineUI:getComponentByTag("rune_bg")
		local flag_rune = self.shrineUI:getFlagByTag("flag_rune")

		if bigScale ~= 1 then
			local bigY = display.height * (1 / bigScale - 1)

			rune_bg:setPos(nil, rune_bg.y - bigY)

			flag_rune.y = flag_rune.y - bigY
		end

		local function tapListener(ui, data, index, x, y)
			FRAME_rune.open()
		end

		self.runelist = self.shrineUI:createListOnFlag("flag_rune", LIST_rune_small, tapListener)

		self.runelist:setTapGroup("list_click")
		self:refreshRune()
		ManagerInfo.onDataChange(self, {
			"bag",
			"quick_slots"
		}, nil, function ()
			self:refreshRune()
		end)
	else
		self.shrineUI:removeComponentByTag("rune_bg")
	end
end

function FRAME_dungeon:refreshRune()
	if self.runelist then
		local itemMap = InfoQuickSlots.getRuneMap()
		local items = {}

		for i = 1, GameConfig.rune_num do
			table.insert(items, {
				base_id = itemMap[i]
			})
		end

		self.runelist:setItems(items)
	end
end

function FRAME_dungeon:initQuickItem()
	self.quickSlots = {}
	self.realQuickSlots = {}

	for i = 1, SLOT_NUM do
		local slot = DungeonSlot.new(self.bottomUI:getRectByFlag("flag_item_" .. i))

		slot:toTouchable()
		slot:addTouch(function (event, x, y)
			if InfoFishing.inPond() then
				return self:touchSlotFishing(slot, i, event, x, y)
			else
				return self:touchSlot(slot, i, event, x, y)
			end
		end)
		self.bottomUI:addChild(slot, 100)
		table.insert(self.quickSlots, slot)
		slot:toTouchable()
	end

	self:refreshQuickSlots()
	ManagerInfo.onDataChange(self, {
		"bag",
		"quick_slots",
		"fishing"
	}, nil, function ()
		self:refreshQuickSlots()
	end)
	notify.safeRegister(self, "fishing_start", function ()
		self:refreshQuickSlots()
	end)
	notify.safeRegister(self, "fishing_over", function ()
		self:refreshQuickSlots()
	end)
end

function FRAME_dungeon:setQuickSlot(index, baseID)
	if InfoFishing.inPond() then
		return
	end

	InfoQuickSlots.set(index - self.quickStartIndex + 1, baseID)
end

function FRAME_dungeon:refreshQuickSlots()
	local fishingBG = self.bottomUI:getComponentByTag("fishing_bg")
	local fishnetBG = self.bottomUI:getComponentByTag("fishnet_bg")

	fishingBG:setVisible(InfoFishing.inPond())
	fishnetBG:setVisible(InfoFishing.inPond())

	local bottomX = nil
	self.realQuickSlots = {}

	if InfoFishing.inPond() then
		local fin, amount = InfoFishing.getFishAmount()

		if fin and amount then
			if amount == 0 then
				self.bottomUI:createLabelOnFlag("flag_fishing_amount", Localization.getSrcText("充足的鱼群"))
			elseif amount <= fin then
				self.bottomUI:createLabelOnFlag("flag_fishing_amount", Localization.getSrcText("鱼群已经离开"), {
					color = Style.weakRed
				})
			else
				local str = Localization.getSrcText("鱼群剩余：{1}")

				self.bottomUI:createLabelOnFlag("flag_fishing_amount", StringUtil.replace(str, amount - fin))
			end
		else
			self.bottomUI:removeLabelOnFlag("flag_fishing_amount")
		end

		local pondCSV = InfoFishing.getPondCSV()

		if empty(pondCSV.open_time) then
			self.bottomUI:createLabelOnFlag("flag_fishing_time", Localization.getSrcText("全天开放"))
		else
			local style = {}

			if not RefreshManager.checkOpenTime(pondCSV.open_time, Time.now()) then
				style.color = Style.weakRed
			end

			self.bottomUI:createLabelOnFlag("flag_fishing_time", RefreshManager.getDesc(pondCSV.open_time), style)
		end

		local rodCSV = InfoFishing.getRod()

		if rodCSV then
			local rodItemID = rodCSV.item_id

			if not self.rodSlot then
				self.rodSlot = DropSlot.new(self.bottomUI:getFlagByTag("flag_rod"), "slot_01")

				self.bottomUI:addChild(self.rodSlot, 100)
				self.rodSlot:toTouchable()
				self.rodSlot:setTapGroup("button_click")
				self.rodSlot:addTap(function ()
					local rodArr = InfoFishing.getRodList()

					if #rodArr > 0 then
						FRAME_fishing_rod.open()
					else
						Alert.open(Localization.getSrcText("没有钓鱼竿"))
					end
				end)
			end

			self.rodSlot:setDrop(DropManager.TYPE.ITEM, {
				base_id = rodItemID
			})
		end

		local netInfo = InfoFishing.getFishnet()

		if netInfo then
			if not self.fishnetSlot then
				local slot = DropSlot.new(self.bottomUI:getFlagByTag("flag_fishnet"), "slot_01")

				self.bottomUI:addChild(slot, 100)
				slot:setAlwaysShowNumber(true)
				slot:toTouchable()
				slot:addTouch(function (event, x, y)
					return self:touchSlotFishing(slot, i, event, x, y, netInfo.base_id)
				end)

				self.fishnetSlot = slot
			end

			self.fishnetSlot:setVisible(true)
			fishnetBG:setVisible(true)
			self.fishnetSlot:setDrop(DropManager.TYPE.ITEM, netInfo)
		else
			if self.fishnetSlot then
				self.fishnetSlot:setVisible(false)
			end

			fishnetBG:setVisible(false)
		end

		local baitList = InfoFishing.getBaitList()
		local startIndex = math.max(0, SLOT_NUM - #baitList) + 1
		self.quickStartIndex = startIndex
		local baitNum = 0

		for i = 1, SLOT_NUM do
			local bg = self.bottomUI:getComponentByTag("item_bg_" .. i)

			bg:setVisible(startIndex <= i)

			local slot = self.quickSlots[i]

			slot:setVisible(startIndex <= i)

			if startIndex <= i then
				local baitIndex = i - startIndex + 1
				local itemInfo = baitList[baitIndex]

				slot:setDrop(DropManager.TYPE.ITEM, itemInfo)

				self.realQuickSlots[baitIndex] = slot
				local x = slot:getPositionX()

				if not bottomX or x < bottomX then
					bottomX = x
				end

				if baitIndex == 1 then
					baitNum = InfoItem.getNum(itemInfo.base_id)
				end
			else
				slot:clearDrop()
			end
		end

		if InfoDungeon.getType() == InfoDungeon.TYPE.STAGE and baitNum > 0 and InfoGuide.getFreeRecord(32) == 0 then
			InfoGuide.triggerFree(32)
		end
	else
		self.bottomUI:removeLabelOnFlag("flag_fishing_amount")
		self.bottomUI:removeLabelOnFlag("flag_fishing_time")

		if self.rodSlot then
			self.rodSlot:removeSelf()

			self.rodSlot = nil
		end

		if self.fishnetSlot then
			self.fishnetSlot:removeSelf()

			self.fishnetSlot = nil
		end

		local startIndex = math.max(0, SLOT_NUM - GameConfig.quick_slots_num) + 1
		self.quickStartIndex = startIndex

		for i = 1, SLOT_NUM do
			local bg = self.bottomUI:getComponentByTag("item_bg_" .. i)

			bg:setVisible(startIndex <= i)

			local slot = self.quickSlots[i]

			slot:setVisible(startIndex <= i)

			if startIndex <= i then
				local baseID = InfoQuickSlots.get(i - startIndex + 1)

				if baseID == 0 then
					slot:clearDrop()
				else
					slot:setDrop(DropManager.TYPE.ITEM, {
						base_id = baseID,
						num = InfoBag.getItemNum(baseID)
					})
				end

				self.realQuickSlots[i - startIndex + 1] = slot
				local x = slot:getPositionX()

				if not bottomX or x < bottomX then
					bottomX = x
				end
			else
				slot:clearDrop()
			end
		end
	end

	self.bottomX = bottomX

	self:refreshBardPosition()
end

function FRAME_dungeon:refreshBardPosition()
	if global.main_bard then
		local y = 0

		global.main_bard:refreshPosition(self.bottomX, y)
	end
end

function FRAME_dungeon:initModao()
	if InfoModao.enabled() then
		self:initModaoUI()
		notify.safeRegister(self, "modao_mana_max", function (mana)
			self:updateModaoMax()
		end)
		notify.safeRegister(self, "modao_mana", function (mana)
			self:updateModaoMana(mana)
		end)
		self:updateModaoMana()
	else
		self:hideModaoUI()
	end
end

function FRAME_dungeon:clearModaoBlock()
	self.bottomUI:clearDuplicated("mana_block")
	self.bottomUI:clearDuplicated("mana_shadow")
	self.bottomUI:clearDuplicated("mana_light")

	self.manaBlocks = nil
	self.manaLights = nil
end

function FRAME_dungeon:hideModaoUI()
	self.isHideModao = true

	self:clearModaoBlock()
	self.bottomUI:removeComponentByTag("mana_bg")
	self.bottomUI:removeComponentByTag("mana_block")
	self.bottomUI:removeComponentByTag("mana_shadow")
	self.bottomUI:removeComponentByTag("mana_light")
	self.bottomUI:removeComponentByTag("mana_left")
	self.bottomUI:removeComponentByTag("mana_right")
	self.bottomUI:removeComponentByTag("mana_hightlight")
end

function FRAME_dungeon:initModaoUI()
	if self.isHideModao then
		return
	end

	self:updateModaoMax()
end

function FRAME_dungeon:updateModaoMax()
	if InfoModao.enabled() then
		self:clearModaoBlock()

		local mana_left = self.bottomUI:getComponentByTag("mana_left")
		local mana_right = self.bottomUI:getComponentByTag("mana_right")

		mana_right:setScaleX(-1)

		local mana_hightlight = self.bottomUI:getComponentByTag("mana_hightlight")

		mana_hightlight:setVisible(false)
		mana_hightlight:setLocalZOrder(1000)

		local manaBg = self.bottomUI:getComponentByTag("mana_bg")
		local manaFlag = self.bottomUI:getFlagByTag("flag_mana")
		local maxMp = InfoModao.getMpMax()
		local blockSpaceX = 2
		local blockSpaceY = 20
		local blockPerLine = 5
		local manaBlock = self.bottomUI:getComponentByTag("mana_block")
		local manaShadow = self.bottomUI:getComponentByTag("mana_shadow")
		local manaLight = self.bottomUI:getComponentByTag("mana_light")
		local blockWidth = (manaFlag.width - blockSpaceX * (blockPerLine - 1)) / blockPerLine
		local manaBlockNum = math.ceil(maxMp / MiscConfig.MP_BLOCK)
		local lines = math.ceil(manaBlockNum / blockPerLine)
		self.manaBlocks = self.bottomUI:duplicateComponent("mana_block", manaBlockNum - 1, 0, 0)
		self.manaLights = self.bottomUI:duplicateComponent("mana_light", manaBlockNum - 1, 0, 0)
		local manaShadows = self.bottomUI:duplicateComponent("mana_shadow", manaBlockNum - 1, 0, 0)
		local bgHeight = blockSpaceY * (lines - 1)

		manaBg:setSize(nil, manaBg.originalHeight + bgHeight)
		mana_left:setPos(nil, mana_left.originalY + bgHeight / 2)
		mana_right:setPos(nil, mana_right.originalY + bgHeight / 2)

		for i = 1, manaBlockNum do
			local blockX = (i - 1) % blockPerLine
			local blockY = math.floor((i - 1) / blockPerLine)
			local block = self.manaBlocks[i]
			local light = self.manaLights[i]
			local shadow = manaShadows[i]
			local x = manaFlag.x - blockWidth / 2 + blockX * (blockWidth + blockSpaceX)

			block:setSize(blockWidth - 6)
			block:setAnchorPoint(cc.p(0, 0.5))
			block:setLocalZOrder(100)
			block:setPos(x + 6, manaBlock.y + blockY * blockSpaceY)
			light:setSize(blockWidth + 14)
			light:setAnchorPoint(cc.p(0, 0.5))
			light:setLocalZOrder(100)
			light:setPos(x - 14, manaLight.y + blockY * blockSpaceY)
			shadow:setSize(blockWidth)
			shadow:setAnchorPoint(cc.p(0, 0.5))
			shadow:setLocalZOrder(90)
			shadow:setPos(x, manaShadow.y + blockY * blockSpaceY)

			if maxMp < i * MiscConfig.MP_BLOCK then
				shadow:setScaleX((maxMp - MiscConfig.MP_BLOCK * (i - 1)) / MiscConfig.MP_BLOCK)
			end
		end
	end
end

function FRAME_dungeon:updateModaoMana(mana)
	if self.isHideModao then
		return
	end

	if InfoModao.enabled() then
		local currentMp = nil

		if mana then
			currentMp = mana
		else
			currentMp = InfoModao.getMp()
		end

		local mana_hightlight = self.bottomUI:getComponentByTag("mana_hightlight")

		mana_hightlight:setVisible(false)

		local absMana = math.abs(currentMp)

		if self.manaBlocks then
			for i, block in ipairs(self.manaBlocks) do
				local block = self.manaBlocks[i]
				local light = self.manaLights[i]

				if absMana <= (i - 1) * MiscConfig.MP_BLOCK then
					block:setVisible(false)
					light:setVisible(false)
				else
					block:setVisible(true)

					if absMana >= i * MiscConfig.MP_BLOCK then
						light:setVisible(true)
						block:setScaleX(1)
					else
						light:setVisible(false)

						local scaleX = (absMana - (i - 1) * MiscConfig.MP_BLOCK) / MiscConfig.MP_BLOCK

						block:setScaleX(scaleX)
						mana_hightlight:setVisible(true)

						local x, y = block:getPosition()

						mana_hightlight:setPosition(x + scaleX * block.width, y)
					end
				end
			end
		end
	end
end

local nearNpcStack = {}
local nearInquireStack = {}

function FRAME_dungeon:initNpcUI()
	notify.safeRegister(self, "near_npc_change", function (_nearNpcStack, force)
		nearNpcStack = _nearNpcStack

		self:refreshNpcUI(force)
		self:refreshFestivalItem(force)
	end)
end

function FRAME_dungeon:refreshFestivalItem(force)
	if not InfoDungeon.isCamp() then
		return
	end

	if not InfoGuide.isFin() then
		return
	end

	if self.festivalItemUI then
		self.festivalItemUI:close()

		self.festivalItemUI = nil
	end

	local festItems = InfoFestival.getCampItems()

	if not self.npcUI and #festItems > 0 then
		self.festivalItemUI = FRAME_festival_item.new()
	end
end

function FRAME_dungeon:refreshNpcUI(force)
	local preNpcUI = nil

	if self.npcUI then
		if force then
			preNpcUI = self.npcUI
			self.npcUI = nil
		else
			local nearNpcMap = {}

			for i, npc in ipairs(nearNpcStack) do
				nearNpcMap[npc] = true
			end

			if nearNpcMap[self.npcUI.npc] then
				return
			else
				preNpcUI = self.npcUI
				self.npcUI = nil
			end
		end
	end

	if preNpcUI then
		preNpcUI:close(#nearNpcStack > 0)
	end

	if #nearNpcStack > 0 then
		table.sort(nearNpcStack, function (a, b)
			return (a.priority or 0) > (b.priority or 0)
		end)

		local npc = nearNpcStack[1]
		local npcUI = self:createNpcNav(npc)
		self.npcUI = npcUI
	end
end

function FRAME_dungeon:createNpcNav(npc)
	if global.map.isBattle then
		return
	end

	local ui = NavUtil.createNpcNav(npc)

	return ui
end

function FRAME_dungeon:initShrine()
	local shrineFlag = self.shrineUI:getFlagByTag("flag_shrine")
	local baseX = shrineFlag.x
	local baseY = shrineFlag.y

	print("$$$ initShrine", baseX, baseY)

	local spaceX = 60
	self.unionBuffSlots = {}
	local unionBuff = InfoDungeon.getUnionBuff()

	for i, buffID in ipairs(unionBuff) do
		local com = UIManager.getUI("com_union_buff")

		self.shrineUI:addChild(com, 100)
		com:setPosition(baseX, baseY)

		baseX = baseX - spaceX

		com:setOpacity(200)

		local csv = CsvParser.getCsvData("union_buff", buffID)
		local pic = IconManager.getUnionBuffIcon(buffID)

		com:createIconOnFlag("flag_icon", pic, 100, true)

		local frame = com:getComponentByTag("frame")

		frame:setLocalZOrder(200)

		local buffQuality = csv.quality

		if empty(buffQuality) then
			buffQuality = 0
		end

		frame:setColor(InfoHero.getQualityColor(buffQuality))

		local bg = com:getComponentByTag("bg")

		bg:toTouchable()
		bg:addTap(function ()
			FRAME_union_buff_detail.open(buffID)
		end)
		bg:setTapGroup("bg_click")

		self.unionBuffSlots[i] = com
	end

	self.shrineSlots = {}
	local shrine_max = InfoDungeon.getShrineMax()

	for i = 1, shrine_max do
		local com = UIManager.getUI("com_shrine")

		self.shrineUI:addChild(com, 100)
		com:setPosition(baseX, baseY)

		baseX = baseX - spaceX
		local slot = DropSlot.new(com:getFlagByTag("flag_icon"), "slot_04")

		com:addChild(slot, 100)

		com.slot = slot

		slot:setOpacity(200)

		local bg = com:getComponentByTag("bg")

		bg:toTouchable()
		bg:addTap(function ()
			local shrineData = InfoDungeon.getShrineData()

			if shrineData[i] then
				FRAME_shrine_detail.open(shrineData[i])
			end
		end)
		bg:setTapGroup("bg_click")

		local big_bg = com:getComponentByTag("big_bg")

		big_bg:setOpacity(0)

		self.shrineSlots[i] = com
	end
end

function FRAME_dungeon:refreshShrine()
	local shrineData = InfoDungeon.getShrineData()
	local shrine_max = InfoDungeon.getShrineMax()

	for i = 1, shrine_max do
		local com = self.shrineSlots[i]
		local slot = com.slot
		local data = shrineData[i]
		local lifeBG = com:getComponentByTag("life_bg")

		if data then
			slot:setVisible(true)
			slot:setDrop(DropManager.TYPE.BUFF, data)

			if data.life_time then
				com:createLabelOnFlag("flag_life_time", data.life_time)
				lifeBG:setVisible(true)
			else
				com:removeLabelOnFlag("flag_life_time")
				lifeBG:setVisible(false)
			end
		else
			slot:setVisible(false)
			slot:clearDrop()
			com:removeLabelOnFlag("flag_life_time")
			lifeBG:setVisible(false)
		end
	end
end

function FRAME_dungeon:gmView()
	if not DEV_MODE then
		return
	end

	if self.topAlreadyMap then
		local topMap = global.map.top.map
		local tileMap = global.map.top.tile

		for k, v in pairs(topMap) do
			self.topViewMap[tostring(k)] = 1
			self.topAlreadyMap[tostring(k)] = 1
		end

		self:scrollTop(true)
	end
end

function FRAME_dungeon:akasaView()
	if not DEV_MODE then
		return
	end

	if self.topAlreadyMap then
		local topMap = global.map.top.map
		local tileMap = global.map.top.tile

		for k, v in pairs(topMap) do
			self.topViewMap[tostring(k)] = 1
		end

		self:scrollTop(true)
	end
end

function FRAME_dungeon:initTopMap()
	local topBG = self.shrineUI:getComponentByTag("top_bg")

	if global.map.top then
		local topInfo = DungeonState.getMapTop(global.map.mapName)
		self.topAlreadyMap = topInfo.already
		self.topViewMap = topInfo.view
		self.topAlreadyIconMap = {}

		self:createTopUI()
		notify.safeRegister(global.player, "player_retile", function ()
			self:scrollTop()
		end)
		notify.safeRegister(self, "refresh_top", function ()
			self:scrollTop(true)
		end)
		self:scrollTop(true)
		topBG:setOpacity(0)

		if global.all_view then
			local delayCount = 30

			self:addEnterFrame("delay_all_view", function ()
				if delayCount <= 0 then
					self:removeEnterFrame("delay_all_view")
					self:gmView()
				else
					delayCount = delayCount - 1
				end
			end)

			return
		end

		if InfoDungeon.isAkasa() then
			-- Nothing
		end
	else
		topBG:setVisible(false)
	end
end

function FRAME_dungeon:scrollTop(isFirst)
	local tile = global.player.tile
	local topMap = global.map.top.map
	local tileMap = global.map.top.tile
	local corpseMap = DungeonState.getCorpseTop()
	local rect = self.shrineUI:getRectByFlag("flag_top")
	local centerIndex = tileMap[tile.tag]
	local centerObj = topMap[centerIndex]

	if centerIndex and (self.topCenterIndex ~= centerIndex or isFirst) then
		local isNewMap = self.topAlreadyMap[centerIndex] ~= 1
		self.topAlreadyMap[centerIndex] = 1
		local w, h, xOffset, yOffset = self:getTopSize(centerObj)
		local centerX = centerObj.x + xOffset
		local centerY = centerObj.y + yOffset
		local centerIsoX, centerIsoY = self:getTopIsoPos(centerX, centerY)

		for index, obj in pairs(self.topIconMap) do
			local node = obj.node
			local icon = obj.icon
			local info = obj.info
			local x = info.x
			local y = info.y
			local distance = math.sqrt(math.pow(centerX - x, 2) + math.pow(centerY - y, 2))
			local opac = math.max(0, 255 - distance * 70)

			if not self.topViewMap[index] and (self.topAlreadyMap[index] == 1 or centerX == x and math.abs(centerY - y) <= 1 or centerY == y and math.abs(centerX - x) <= 1) then
				self.topViewMap[index] = 1
			end

			if self.topViewMap[index] ~= 1 then
				opac = 0
			end

			transition.stopTarget(node)

			if self.topCenterIndex then
				transition.fadeTo(node, {
					time = 0.3,
					easing = "sineOut",
					opacity = opac
				})
			else
				node:setOpacity(opac)
			end

			if self.topAlreadyMap[index] == 1 and not self.topAlreadyIconMap[index] then
				local w, h, xOffset, yOffset = self:getTopSize(info)
				local isoX, isoY = self:getTopIsoPos(x + xOffset, y + yOffset)
				local icon = self:getTopIcon("#map_assets_top_block", w * 45, h * 45)

				self.topCanvas:addChild(icon)
				icon:setPosition(isoX, isoY)

				self.topAlreadyIconMap[index] = icon
			end

			local icon = self.topAlreadyIconMap[index]

			if icon then
				icon:setOpacity(math.floor(opac / 3 * 1.25))

				if index == centerIndex then
					icon:setColor(MiscConfig.top_center)
				elseif corpseMap[index] then
					icon:setColor(MiscConfig.top_die)
				else
					icon:setColor(MiscConfig.top_already)
				end
			end
		end

		local canvasX = rect.x + rect.width / 2 - centerIsoX
		local canvasY = rect.y + rect.height / 2 - centerIsoY

		transition.stopTarget(self.topCanvas)

		if self.topCenterIndex then
			transition.moveTo(self.topCanvas, {
				time = 0.3,
				easing = "sineOut",
				x = canvasX,
				y = canvasY
			})
		else
			self.topCanvas:setPosition(canvasX, canvasY)
		end

		self.topCenterIndex = centerIndex

		if not global.map.isBattle then
			local notifyID = nil

			local function onTopMoved()
				notify.unregister("recover_godirection", notifyID)
				DungeonState.flushOnTop(not isFirst)

				if (global.map.mapType == Map.TYPE.RANTILE or global.map.mapType == Map.TYPE.FIXTILE) and InfoGuide.getFreeRecord(33) == 0 and InfoDungeon.getLevel() >= 18 and centerObj and centerObj.depth and centerObj.depth >= 2 then
					InfoGuide.triggerFree(33)
				end
			end

			if global.player:isGoDirectionLocked() then
				notifyID = notify.safeRegister(self, "recover_godirection", function ()
					Log.verbose("flushOnTop 2")
					onTopMoved()
				end)
			else
				onTopMoved()
			end
		end
	end
end

function FRAME_dungeon:createTopUI()
	local topMap = global.map.top.map
	local exTopType = global.map.top.exTopType
	local rect = self.shrineUI:getRectByFlag("flag_top")
	local panel = display.newClippingRectangleNode(rect)

	panel:setCascadeOpacityEnabled(true)
	self.shrineUI:addChild(panel, 100)

	local canvas = display.newNode()

	canvas:setCascadeOpacityEnabled(true)
	canvas:setPosition(rect.x + rect.width / 2, rect.y + rect.height / 2)
	panel:addChild(canvas)

	self.topCanvas = canvas
	self.topIconMap = {}

	for index, obj in pairs(topMap) do
		local link = obj.link
		local x = obj.x
		local y = obj.y
		local w, h, xOffset, yOffset = self:getTopSize(obj)
		local isoX, isoY = self:getTopIsoPos(x + xOffset, y + yOffset)
		local topNode = display.newNode()

		topNode:setCascadeOpacityEnabled(true)
		topNode:setPosition(isoX, isoY)
		canvas:addChild(topNode, 100)

		local topIcon = self:getTopIcon("#map_assets_top_" .. link, w * 50, h * 50)

		topIcon:setOpacity(200)
		topNode:addChild(topIcon, 100)

		self.topIconMap[index] = {
			node = topNode,
			icon = topIcon,
			info = obj
		}
		local mapType = obj.type

		if not mapType and exTopType[index] then
			mapType = exTopType[index].type
		end

		if mapType then
			local icon = display.newSprite("#map_assets_top_" .. mapType)
			local scale = 0.6

			icon:setScaleX(scale)
			icon:setScaleY(scale)
			topNode:addChild(icon)

			topNode.eventIcon = icon
		end
	end

	self:refreshTopEvent()
	notify.safeRegister(self, "top_map_refresh", function ()
		self:refreshTopEvent()
	end)
end

function FRAME_dungeon:refreshTopEvent()
	if not global.map or not global.map.top then
		return
	end

	local exTopType = global.map.top.exTopType

	for index, v in pairs(exTopType) do
		if self.topIconMap[index] then
			local topNode = self.topIconMap[index].node
			local eventIcon = topNode.eventIcon
			local topType = v.type
			local eventIndex = v.eventIndex
			local eventFin = 0
			local eventInfo = InfoDungeon.getEventInfo(eventIndex)

			if eventInfo then
				eventFin = eventInfo.fin
			end

			local finished = false

			if topType == Rantile.MAP_TYPE.GLADIATOR then
				if GameConfig.gladiator_max < eventInfo.fin then
					local finalRelic = InfoDungeon.getFinalRelic(eventIndex)

					if not finalRelic or finalRelic.fin ~= 0 then
						finished = true
					end
				end
			elseif topType == Rantile.MAP_TYPE.MINE then
				local dungeon_csv = InfoDungeon.getDungeonCSV()
				local mine_index = dungeon_csv.mine_index
				local already = InfoFurnace.getMineRecord(mine_index) > 0

				if eventFin <= 0 then
					finished = already

					if already then
						finished = false

						if false then
							finished = true
						end
					end
				end
			elseif topType == Rantile.MAP_TYPE.CHEST and eventInfo.data.tag == "chance" then
				finished = eventFin > 1
			else
				finished = eventFin > 0
			end

			if finished then
				eventIcon:setColor(Style.gray)
				eventIcon:setOpacity(100)
			else
				eventIcon:setColor(Style.white)
				eventIcon:setOpacity(255)
			end
		end
	end
end

function FRAME_dungeon:getTopIsoPos(x, y)
	local isoX = math.round((x - y) * 75.9 / 2)
	local isoY = -math.round((x + y) * 46.2 / 2)

	return isoX, isoY
end

function FRAME_dungeon:getTopIcon(name, width, height)
	local sprt = display.newSprite(name)

	sprt:setScaleX(width / 50)
	sprt:setScaleY(height / 50)
	sprt:setRotation(45)

	local node = display.newNode()

	node:setCascadeOpacityEnabled(true)
	node:setCascadeColorEnabled(true)
	node:addChild(sprt)
	node:setScaleY(topMapRatio)

	node.icon = sprt

	return node
end

function FRAME_dungeon:getTopSize(obj)
	local x = obj.x
	local y = obj.y
	local w = 1
	local h = 1
	local xOffset = 0
	local yOffset = 0

	if obj.others then
		local minX = x
		local maxX = x
		local minY = y
		local maxY = y

		for i, other in ipairs(obj.others) do
			minX = math.min(minX, other.x)
			maxX = math.max(maxX, other.x)
			minY = math.min(minY, other.y)
			maxY = math.max(maxY, other.y)
		end

		xOffset = (maxX + minX) / 2 - x
		yOffset = (maxY + minY) / 2 - y
		w = maxX - minX + 1
		h = maxY - minY + 1
	end

	return w, h, xOffset, yOffset
end

local selectConfig = {
	xScale = 2,
	cancelFlag = "flag_cancel_right",
	yScale = 2,
	z = 20,
	x = display.width - 250,
	y = display.height / 4
}
local selectionArrow, skillCancelUI = nil
local enabledTilesMap = {}
local disabledTilesMap = {}
local selectedTilesMap = {}
local selectedUnitsMap = {}
local selectedTarget, selectionClip = nil

function FRAME_dungeon:startSelectionLoop()
	local function checkSkillSelectionLoop()
		local distance = math.sqrt(math.pow(self.touchData.pos[1].y - self.touchData.y, 2) + math.pow(self.touchData.pos[1].x - self.touchData.x, 2))
		self.touchData.speed = self.touchData.speed * 0.5 + distance * 0.5

		table.insert(self.touchData.pos, {
			x = self.touchData.x,
			y = self.touchData.y
		})

		if #self.touchData.pos > 5 then
			table.remove(self.touchData.pos, 1)
		end

		local mapX1, mapY1 = self:fingerToMap(self.touchData.pos[1].x, self.touchData.pos[1].y)
		local mapX2, mapY2 = self:fingerToMap(self.touchData.x, self.touchData.y)
		self.touchData.angle = math.atan2(mapY2 - mapY1, mapX2 - mapX1)
	end

	self:addEnterFrame("checkSkillSelectionLoop", checkSkillSelectionLoop)
end

function FRAME_dungeon:stopSelectionLoop()
	self:removeEnterFrame("checkSkillSelectionLoop")
end

function FRAME_dungeon:refreshSelectArea(tiles)
	local newSelectTiles = {}
	local newSelectUnits = {}

	for i = 1, #tiles do
		local tile = tiles[i]
		local tag = tile:getTag()

		if tile:getVisible() then
			if not selectedTilesMap[tag] then
				local newSprite = tile:openAsset("skill_select")

				if newSprite then
					newSprite:setScale(0)
					transition.scaleTo(newSprite, {
						time = 0.1,
						scale = 1,
						easing = "sineOut"
					})
				end
			end

			selectedTilesMap[tag] = nil
		end

		newSelectTiles[tag] = tile
	end

	for k, tile in pairs(selectedTilesMap) do
		tile:closeAsset("skill_select")
	end

	for k, unit in pairs(selectedUnitsMap) do
		unit:closeSkillSelect()
	end

	selectedTilesMap = newSelectTiles
	selectedUnitsMap = newSelectUnits
end

function FRAME_dungeon:clearSelectArea()
	for k, tile in pairs(selectedTilesMap) do
		tile:closeAsset("skill_select")
	end

	for k, unit in pairs(selectedUnitsMap) do
		unit:closeSkillSelect()
	end

	selectedTilesMap = {}
	selectedUnitsMap = {}
end

function FRAME_dungeon:clearRangeArea()
	for k, tile in pairs(enabledTilesMap) do
		tile:closeAsset("skill_range")
	end

	for k, tile in pairs(disabledTilesMap) do
		tile:closeAsset("skill_range_disable")
	end

	enabledTilesMap = {}
	disabledTilesMap = {}
end

function FRAME_dungeon:refreshRangeArea(caster, itemData)
	if itemData.use_type == 6 then
		local tiles = MapUtils.spreadAreaForCampfire(global.map, global.player.tile, 1, nil, 5)

		for i, tile in ipairs(tiles) do
			enabledTilesMap[tile.tag] = tile

			tile:openAsset("skill_range")
		end
	end
end

function FRAME_dungeon:isTileWalkable(tile, unit)
	local walkLevel = 1
	local preBlock = nil
	local size = 1

	if unit then
		walkLevel = unit.walkLevel
		preBlock = unit.isBlock
		unit.isBlock = false
		size = unit.size
	end

	local result = false

	if size == 1 then
		result = tile:getWalkable(walkLevel)
	else
		for i = 0, size - 1 do
			for j = 0, size - 1 do
				local tempTile = global.map:getTile(tile.x + i, tile.y + j)

				if tempTile ~= nil and not tile:getWalkable(walkLevel) then
					result = false
				end
			end
		end

		result = true
	end

	if unit then
		unit.isBlock = preBlock
	end

	return result
end

local selectedSkillIndex, skillSelectUnit, skillSelectPack = nil
local skillSelectionShowing = false
local touchThreshold = 20

function FRAME_dungeon:checkTouchFlyout()
	if self.touchData then
		return self.touchData.speed > 30
	else
		return false
	end
end

function FRAME_dungeon:checkCancelUI(x, y)
	if skillCancelUI then
		local bigScale = self.bottomUI:getBigScale()
		x = x / bigScale
		y = y / bigScale
		local centerX, centerY = self.bottomUI:getFlagCenterByTag(selectConfig.cancelFlag)
		local distance = math.sqrt(math.pow(x - centerX, 2) + math.pow(y - centerY, 2))

		return distance <= 150
	end
end

function FRAME_dungeon:setCastDisabled(b)
	self.castDisabled = b
end

function FRAME_dungeon:getQuickItemIndex(itemID)
	for i, slot in ipairs(self.quickSlots) do
		if slot.type == DropManager.TYPE.ITEM and slot.info.base_id == itemID then
			return i
		end
	end
end

function FRAME_dungeon:touchSlot(slot, skillIndex, event, x, y, isGuide, isGuideCast)
	selectedSkillIndex = skillIndex
	local itemID = InfoQuickSlots.get(skillIndex - self.quickStartIndex + 1)

	if event == "began" then
		local slotX, slotY = slot:getPosition()
		self.touchData = {
			speed = 0,
			isTap = true,
			angle = 0,
			startX = x,
			startY = y,
			slotX = slotX,
			slotY = slotY,
			x = x,
			y = y,
			pos = {
				{
					x = x,
					y = y
				}
			}
		}
		skillSelectionShowing = false
	elseif event == "moved" then
		if not self.touchData then
			return
		end

		if not self:isVisible() then
			self.touchData = nil

			return
		end

		if self.touchData.isTap and (touchThreshold <= math.abs(y - self.touchData.startY) or touchThreshold <= math.abs(x - self.touchData.startX)) then
			self.touchData.isTap = false
		end

		if not self.touchData.isTap and not empty(itemID) then
			if not skillSelectionShowing then
				local itemNum = InfoBag.getItemNum(itemID)

				if itemNum > 0 then
					skillSelectionShowing = true

					self:startSelectionLoop()
					self:clearSkillSelection(x, y)

					local itemData = CsvParser.getCsvData("item", itemID)
					local itemIconPath = IconManager.getItemIcon(itemID)

					self:createSkillSelection(x, y, itemIconPath)
					POP_control_tip.open(itemData.use_tip)
				end
			else
				self.touchData.x = x
				self.touchData.y = y

				self:refreshSkillSelection(x, y)
			end
		end
	elseif event == "ended" then
		if not self.touchData then
			return
		end

		if not self.touchData.isTap then
			if not empty(itemID) then
				self:stopSelectionLoop()

				local mapX, mapY = self:fingerToMap(x, y)
				local isCast = not self.castDisabled
				local isFlyout = false

				if self:checkTouchFlyout() then
					isCast = false
					isFlyout = true

					self:skillSelectArrowFlyout(mapX, mapY, self.touchData.speed, self.touchData.angle)
				end

				if isCast and skillCancelUI and self:checkCancelUI(x, y) then
					isCast = false
				end

				if isGuideCast then
					isCast = true
					isFlyout = false
				end

				if isCast then
					local itemID = InfoQuickSlots.get(selectedSkillIndex - self.quickStartIndex + 1)
					local select_type, affectUnits, hasTarget, itemData = InfoItem.getUseTarget(itemID, mapX, mapY)

					if not hasTarget then
						isCast = false
					end
				end

				self:clearSkillSelection(x, y, isCast, isFlyout)
			end
		elseif not self.castDisabled and InfoGuide.getFreeRecord(28) > 0 then
			local currentItemID = InfoQuickSlots.get(skillIndex - self.quickStartIndex + 1)
			local currentItem = nil

			if not empty(currentItemID) then
				currentItem = {
					base_id = currentItemID,
					num = InfoBag.getItemNum(currentItemID)
				}
			end

			local itemList = InfoBag.getCarryItemList(currentItemID)
			local existMap = InfoQuickSlots.getItemMap()
			local availableItems = {}

			for i, itemInfo in ipairs(itemList) do
				if not existMap[itemInfo.base_id] then
					table.insert(availableItems, itemInfo)
				end
			end

			if currentItem then
				table.insert(availableItems, 1, currentItem)
			end

			if #availableItems > 0 then
				local uiType = nil

				if InfoGuide.getFreeRecord(28) == 0 then
					uiType = FRAME_item_select.OPEN_TYPE.NONE
				elseif empty(currentItemID) then
					uiType = FRAME_item_select.OPEN_TYPE.QUICK_EMPTY
				else
					uiType = FRAME_item_select.OPEN_TYPE.QUICK
				end

				FRAME_item_select.open(availableItems, currentItem, uiType, function (_ui, itemInfo)
					self:setQuickSlot(skillIndex, itemInfo.base_id)
					PopManager.closeTo(_ui)
				end, function (_ui, itemInfo)
					self:setQuickSlot(skillIndex, 0)
					PopManager.closeTo(_ui)
				end)
			else
				Alert.open(Localization.getSrcText("没有快捷使用道具"))
			end
		end

		slot:setVisible(true)
		transition.stopTarget(slot)
		transition.moveTo(slot, {
			time = 0.1,
			easing = "sineOut",
			x = self.touchData.slotX,
			y = self.touchData.slotY
		})

		self.touchData = nil

		POP_control_tip.close()
	end

	if selectionArrow then
		selectionArrow:setVisible(not inArea)
	end
end

function FRAME_dungeon:touchSlotFishing(slot, skillIndex, event, x, y, netID)
	selectedSkillIndex = skillIndex
	local itemID = netID or InfoFishing.getBaitItem(skillIndex - self.quickStartIndex + 1)

	if event == "began" then
		local slotX, slotY = slot:getPosition()
		self.touchData = {
			speed = 0,
			isTap = true,
			angle = 0,
			startX = x,
			startY = y,
			slotX = slotX,
			slotY = slotY,
			x = x,
			y = y,
			pos = {
				{
					x = x,
					y = y
				}
			}
		}
		skillSelectionShowing = false
	elseif event == "moved" then
		if not self.touchData then
			return
		end

		if self.touchData.isTap and (touchThreshold <= math.abs(y - self.touchData.startY) or touchThreshold <= math.abs(x - self.touchData.startX)) then
			self.touchData.isTap = false
		end

		if not self.touchData.isTap and not empty(itemID) then
			if not skillSelectionShowing then
				local itemNum = InfoItem.getNum(itemID)

				if itemNum > 0 then
					skillSelectionShowing = true

					self:startSelectionLoop()
					self:clearSkillSelection(x, y)

					local itemData = CsvParser.getCsvData("item", itemID)
					local itemIconPath = IconManager.getItemIcon(itemID)

					self:createSkillSelection(x, y, itemIconPath, netID)
					POP_control_tip.open(itemData.use_tip)
				end
			else
				self.touchData.x = x
				self.touchData.y = y

				self:refreshSkillSelection(x, y, netID)
			end
		end
	elseif event == "ended" then
		if not self.touchData then
			return
		end

		if not self.touchData.isTap then
			if not empty(itemID) then
				self:stopSelectionLoop()

				local isCast = true
				local isFlyout = false

				if self:checkTouchFlyout() then
					isCast = false
					isFlyout = true
					local mapX, mapY = self:fingerToMap(x, y)

					self:skillSelectArrowFlyout(mapX, mapY, self.touchData.speed, self.touchData.angle)
				end

				self:clearSkillSelection(x, y, isCast, isFlyout, netID)
			end
		else
			local itemInfo = {
				base_id = itemID
			}

			if itemID ~= default_bait then
				itemInfo.num = InfoItem.getNum(itemID)
			end

			FRAME_item_detail.open(itemInfo)
		end

		slot:setVisible(true)
		transition.stopTarget(slot)
		transition.moveTo(slot, {
			time = 0.1,
			easing = "sineOut",
			x = self.touchData.slotX,
			y = self.touchData.slotY
		})

		self.touchData = nil

		POP_control_tip.close()
	end

	if selectionArrow then
		selectionArrow:setVisible(not inArea)
	end
end

function FRAME_dungeon:fingerToMap(x, y)
	local emuMode = Cookie.get("emuMode") or 0
	local screenX, screenY = nil

	if emuMode == 1 then
		screenX = x
		screenY = y
	else
		screenX = (x - selectConfig.x) * selectConfig.xScale + selectConfig.x
		screenY = (y - selectConfig.y) * selectConfig.yScale + selectConfig.y
	end

	local mapX, mapY = global.map:screenToMap(screenX, screenY)

	return mapX, mapY
end

function FRAME_dungeon:mapToFinger(x, y)
	local emuMode = Cookie.get("emuMode") or 0
	local screenX, screenY = global.map:mapToScreen(x, y)
	local fingerX, fingerY = nil

	if emuMode == 1 then
		fingerX = screenX
		fingerY = screenY
	else
		fingerX = (screenX - selectConfig.x) / selectConfig.xScale + selectConfig.x
		fingerY = (screenY - selectConfig.y) / selectConfig.yScale + selectConfig.y
	end

	return fingerX, fingerY
end

function FRAME_dungeon:createSkillSelection(x, y, customItemIconPath, netID)
	if InfoFishing.inPond() then
		local itemID = netID or InfoFishing.getBaitItem(selectedSkillIndex - self.quickStartIndex + 1)
		local itemData = CsvParser.getCsvData("item", itemID)

		MapFrameManager.pause()
		notify.dispatch("battle_freeze", true)

		selectionArrow = Effect.new()

		if customItemIconPath then
			selectionArrow:loadPic(customItemIconPath)
		else
			selectionArrow:load(MiscConfig.battle_arrow)
		end

		selectionArrow.alwaysVisible = true
		selectionArrow.layer = 2

		selectionArrow:display(global.map)
		selectionArrow:selfUpdate()

		local fishingEvent, targetEvent = InfoFishing.getFishingEvent()
		local maxX, mapY = MapEventManager.getEventCenter(targetEvent)
		selectionClip = Effect.new()

		selectionClip:load("fishing_target")

		selectionClip.alwaysVisible = true
		selectionClip.fixedLight = 255
		selectionClip.layer = 2

		selectionClip:display(global.map, maxX, mapY)
		selectionClip:selfUpdate()

		for i = targetEvent.x, targetEvent.x + targetEvent.w - 1 do
			for j = targetEvent.y, targetEvent.y + targetEvent.h - 1 do
				local tile = global.map:getTile(i, j)
				enabledTilesMap[tile.tag] = tile

				tile:openAsset("skill_range")
			end
		end
	else
		skillSelectUnit = global.player
		local itemID = InfoQuickSlots.get(selectedSkillIndex - self.quickStartIndex + 1)
		local itemData = CsvParser.getCsvData("item", itemID)

		MapFrameManager.pause()
		notify.dispatch("battle_freeze", true)

		selectionArrow = Effect.new()

		if customItemIconPath then
			selectionArrow:loadPic(customItemIconPath)
		else
			selectionArrow:load(MiscConfig.battle_arrow)
		end

		selectionArrow.alwaysVisible = true
		selectionArrow.layer = 2

		selectionArrow:display(global.map)
		selectionArrow:selfUpdate()
		self:refreshRangeArea(skillSelectUnit, itemData)
	end

	self:refreshSkillSelection(x, y, netID)

	local centerX, centerY = self.bottomUI:getFlagCenterByTag(selectConfig.cancelFlag)
	skillCancelUI = UIManager.getUI("com_skill_cancel")

	skillCancelUI:setPosition(centerX, centerY)
	self.bottomUI:addChild(skillCancelUI, 1000)

	local bg = skillCancelUI:getComponentByTag("bg")

	bg:setScale(0)
	skillCancelUI:setOpacity(0)
	transition.scaleTo(bg, {
		scale = 3,
		time = 0.2,
		easing = "sineOut"
	})
	transition.fadeTo(skillCancelUI, {
		time = 0.2,
		easing = "sineOut",
		opacity = 150
	})
end

function FRAME_dungeon:refreshSkillSelection(x, y, netID)
	local mapX, mapY = self:fingerToMap(x, y)

	selectionArrow:draw(mapX, mapY, true)
	selectionArrow:clearRefreshVisibleFrame()
	selectionArrow:retile()
	self:refreshSkillArea(mapX, mapY, netID)

	if skillCancelUI then
		local cancelIn = self:checkCancelUI(x, y)

		if cancelIn ~= skillCancelUI.cancelIn then
			skillCancelUI.cancelIn = cancelIn

			transition.stopTarget(skillCancelUI)

			if cancelIn then
				transition.fadeTo(skillCancelUI, {
					time = 0.1,
					easing = "sineOut",
					opacity = 255
				})
			else
				transition.fadeTo(skillCancelUI, {
					time = 0.1,
					easing = "sineOut",
					opacity = 150
				})
			end
		end
	end
end

function FRAME_dungeon:refreshSkillArea(mapX, mapY, netID)
	if InfoFishing.inPond() then
		local itemID = netID or InfoFishing.getBaitItem(selectedSkillIndex - self.quickStartIndex + 1)
		local itemData = CsvParser.getCsvData("item", itemID)
		local tile = global.map:mapToTile(mapX, mapY)

		if tile and enabledTilesMap[tile:getTag()] then
			selectionClip:setOpacity(255)
		else
			selectionClip:setOpacity(100)
		end
	else
		local itemID = InfoQuickSlots.get(selectedSkillIndex - self.quickStartIndex + 1)
		local select_type, affectUnits, hasTarget, itemData = InfoItem.getUseTarget(itemID, mapX, mapY)

		if select_type == 0 then
			local x, y = global.map:tileToMap(skillSelectUnit.tile)
			selectedTarget = {
				x = x,
				y = y
			}
		elseif select_type == 1 then
			local bestUnit, bestDistance = nil

			for i = 1, #affectUnits do
				local affectUnit = affectUnits[i]
				local distance = math.sqrt(math.pow(affectUnit.y - mapY, 2) + math.pow(affectUnit.x - mapX, 2))
				local mhdRange = math.abs(skillSelectUnit.tile.x - affectUnit.tile.x) + math.abs(skillSelectUnit.tile.y - affectUnit.tile.y)

				if bestDistance == nil or distance < bestDistance then
					bestDistance = distance
					bestUnit = affectUnit
				end
			end

			if bestUnit ~= selectedTarget then
				if selectedTarget then
					selectedTarget:closeSkillSelect()
				end

				selectedTarget = bestUnit

				if selectedTarget then
					local params = {
						type = "use_item",
						itemData = itemData
					}

					selectedTarget:openSkillSelect(params)
				end
			end
		elseif select_type == 2 then
			local tile = global.map:mapToTile(mapX, mapY)

			if tile and not enabledTilesMap[tile:getTag()] then
				local bestTile, bestScore = nil

				for tag, inTile in pairs(enabledTilesMap) do
					local inTileX, inTileY = global.map:tileToMap(inTile)
					local range = math.sqrt(math.pow(mapY - inTileY, 2) + math.pow(mapX - inTileX, 2))
					local score = range

					if bestTile == nil or score < bestScore then
						bestTile = inTile
						bestScore = score
					end
				end

				tile = bestTile
			end

			if tile then
				local x, y = global.map:tileToMap(tile)
				selectedTarget = {
					x = x,
					y = y
				}

				self:refreshSelectArea({
					tile
				})
			end
		end
	end
end

function FRAME_dungeon:clearSkillSelection(x, y, isCast, isFlyout, netID)
	if InfoFishing.inPond() then
		if isCast then
			local mapX, mapY = self:fingerToMap(x, y)

			if netID then
				if self.fishnetSlot then
					local netInfo = self.fishnetSlot.info
					local tile = global.map:mapToTile(mapX, mapY)

					if tile and enabledTilesMap[tile:getTag()] then
						InfoFishing.startFishnet(netInfo)
					end
				end
			else
				local itemIndex = selectedSkillIndex - self.quickStartIndex + 1
				local itemID = InfoFishing.getBaitItem(itemIndex)
				local itemData = CsvParser.getCsvData("item", itemID)
				local tile = global.map:mapToTile(mapX, mapY)

				if tile and enabledTilesMap[tile:getTag()] then
					InfoFishing.startFishing(itemID, itemIndex)
				end
			end
		end
	else
		local target = selectedTarget

		if isCast and target then
			local itemIndex = selectedSkillIndex - self.quickStartIndex + 1
			local itemID = InfoQuickSlots.get(itemIndex)

			if itemID then
				local bag_index = InfoBag.getItemUseIndex(itemID)

				if bag_index then
					local itemData = CsvParser.getCsvData("item", itemID)

					if itemData.use_type == 1 then
						local preHP = target.battleData.hp

						InfoItem.use(itemID, 1, bag_index, target.info.id, function ()
							local effectGen = target:getEffectGen()

							if effectGen then
								effectGen:castEffect(itemData.use_effect, target, nil, target.angle, target)
							end

							local healValue = target.battleData.hp - preHP

							target:jumpWord(healValue, "font_heal_", nil, , -10, true)
						end)
					elseif itemData.use_type == 2 then
						InfoItem.use(itemID, 1, bag_index, nil, function ()
							local units = TeamManager.getTeam()

							for i, unit in ipairs(units) do
								local effectGen = unit:getEffectGen()

								if effectGen then
									effectGen:castEffect(itemData.use_effect, unit, nil, unit.angle, unit)
								end
							end
						end)
					elseif itemData.use_type == 6 then
						local tile = global.map:mapToTile(target.x, target.y)

						FRAME_fire.start(tile, itemID, bag_index)
					elseif itemData.use_type == 7 then
						local heroID = target.info.id

						InfoItem.use(itemID, 1, bag_index, heroID, function ()
							local function afterFlash()
								print("$$$ afterFlash", afterFlash)
								target:removeSelf()
								TeamManager.refreshTeam(true)

								local unit = TeamManager.getHeroByID(heroID)
								local effectGen = unit:getEffectGen()

								if effectGen then
									effectGen:castEffect(itemData.use_effect, unit, nil, unit.angle, unit)
								end
							end

							POP_mask.openFlash(global.player, afterFlash)
						end)
					elseif itemData.use_type == 21 then
						local heroID = nil

						if itemData.use_value1 == 1 then
							heroID = target.info.id
						end

						InfoItem.use(itemID, 1, bag_index, heroID, function ()
							if itemData.use_value1 == 1 then
								local effectGen = target:getEffectGen()

								if effectGen then
									effectGen:castEffect(itemData.use_effect, target, nil, target.angle, target)
								end
							else
								local units = TeamManager.getTeam()

								for i, unit in ipairs(units) do
									local effectGen = unit:getEffectGen()

									if effectGen then
										effectGen:castEffect(itemData.use_effect, unit, nil, unit.angle, unit)
									end
								end
							end
						end)
					elseif itemData.use_type == 22 then
						InfoItem.use(itemID, 1, bag_index, nil, function ()
						end)
					elseif itemData.use_type == 23 then
						InfoItem.use(itemID, 1, bag_index, nil, function ()
						end)
					elseif itemData.use_type == 24 then
						InfoItem.use(itemID, 1, bag_index, nil, function ()
						end)
					elseif itemData.use_type == 25 then
						InfoItem.use(itemID, 1, bag_index, nil, function ()
						end)
					elseif itemData.use_type == 26 then
						local params = {
							mIdx = InfoDungeon.getMapIndex(),
							eIdx = target.eventIndex,
							rIdx = target.relicIndex
						}

						InfoItem.use(itemID, 1, bag_index, nil, function ()
						end, nil, params)
					end
				end
			end
		end
	end

	if selectedTarget and selectedTarget.closeFoot then
		selectedTarget:closeSkillSelect()
	end

	self:clearSelection()

	selectedTarget = nil
	skillSelectUnit = nil
	skillSelectPack = nil

	MapFrameManager.resume()
	notify.dispatch("battle_freeze", false)
end

function FRAME_dungeon:clearSelection()
	self:clearRangeArea()
	self:clearSelectArea()

	if selectionArrow then
		if not isFlyout then
			selectionArrow:removeSelf()
		end

		selectionArrow = nil
	end

	if selectionClip then
		selectionClip:removeSelf()

		selectionClip = nil
	end

	if skillCancelUI then
		local ui = skillCancelUI
		local bg = ui:getComponentByTag("bg")

		transition.stopTarget(ui)
		transition.stopTarget(bg)
		transition.scaleTo(bg, {
			scale = 0,
			time = 0.2,
			easing = "sineOut"
		})
		transition.fadeTo(ui, {
			time = 0.2,
			easing = "sineOut",
			opacity = 0,
			onComplete = function ()
				ui:removeSelf()
			end
		})

		skillCancelUI = nil
	end
end

function FRAME_dungeon:skillSelectArrowFlyout(x, y, speed, angle)
	if not selectionArrow then
		return
	end

	local arrow = selectionArrow
	selectionArrow = nil
	arrow.x = x
	arrow.y = y
	local arrowMoveLoop = nil

	function arrowMoveLoop(obj, frame, passed, sharp)
		local x = arrow.x + math.cos(angle) * speed * passed
		local y = arrow.y + math.sin(angle) * speed * passed
		local tile = global.map:mapToTile(x, y)

		if not tile or not tile:getVisible() then
			Looper.stopLoop(arrow, arrowMoveLoop)
			arrow:removeSelf()
		else
			arrow.x = x
			arrow.y = y

			arrow:draw()
		end
	end

	Looper.startLoop(arrow, arrowMoveLoop)
end

function FRAME_dungeon:popItems(center, items, onComplete)
	if not self.itemPops then
		self.itemPops = {}
		self.itemPopsCount = 0
	end

	self.itemPopOnComplete = onComplete
	self.itemPopsCount = self.itemPopsCount + #items

	for i, v in ipairs(items) do
		local dropItem = DropItem.new()

		dropItem:setDrop(v)
		dropItem:setScale(0.4)

		dropItem.z = math.random(5, 30)

		dropItem:display(global.map, center.x, center.y)

		dropItem.speed = math.random() * 5 + 3
		dropItem.angle = math.random() * math.pi * 2
		dropItem.zspeed = math.random() * 15 + 15
		dropItem.getLocked = true

		dropItem:setVisible(false)

		dropItem.startCount = i * 5

		table.insert(self.itemPops, dropItem)
	end

	self:addEnterFrame("pop_items", function ()
		self:popItemsLoop()
	end)
end

function FRAME_dungeon:popItemsLoop()
	local gravity = 3
	local speedDecay = 0.97
	local groundDecay = 0.6
	local threshold = 8
	local index = 1
	local loop = #self.itemPops

	while index <= loop do
		local dropItem = self.itemPops[index]

		if dropItem.startCount > 0 then
			dropItem.startCount = dropItem.startCount - 1
			index = index + 1
		else
			if dropItem.startCount == 0 then
				dropItem:setVisible(true)

				dropItem.startCount = dropItem.startCount - 1
			end

			local x = dropItem.x + math.cos(dropItem.angle) * dropItem.speed
			local y = dropItem.y + math.sin(dropItem.angle) * dropItem.speed
			dropItem.speed = dropItem.speed * speedDecay
			dropItem.zspeed = dropItem.zspeed - gravity
			dropItem.z = dropItem.z + dropItem.zspeed
			local over = false

			if dropItem.z <= 0 then
				dropItem.z = -dropItem.z
				dropItem.zspeed = -dropItem.zspeed * groundDecay
				over = true
			end

			dropItem:draw(x, y, true)

			if over then
				dropItem:flyToResource(function ()
					self.itemPopsCount = self.itemPopsCount - 1

					if self.itemPopsCount == 0 then
						-- Nothing
					end
				end)
				table.remove(self.itemPops, index)

				loop = loop - 1
			else
				index = index + 1
			end
		end
	end

	if loop == 0 then
		self:removeEnterFrame("pop_items")

		if self.itemPopOnComplete then
			self.itemPopOnComplete()
		end
	end
end

function FRAME_dungeon:flyCoins(center, items, onComplete, offset)
	if not self.coins then
		self.coins = {}
		self.coinsCount = 0
	end

	self.flyCoinOnComplete = onComplete
	local resourceLockArr = {}
	local resourceLockExistMap = {}
	self.coinsCount = self.coinsCount + #items

	for i, v in ipairs(items) do
		local dropItem = DropItem.new()

		dropItem:setDrop(v)

		if v.customPic then
			dropItem:loadPic(v.customPic)
		end

		dropItem:setScale(0.4)

		dropItem.z = math.random(5, 30)
		offset = offset or {
			x = math.random(48, 64),
			y = math.random(-12, 12)
		}

		dropItem:display(global.map, center.x + offset.x, center.y + offset.y)

		dropItem.speed = math.random() * 5 + 5
		dropItem.angle = math.random(-60, 60) * math.pi / 180
		dropItem.zspeed = math.random() * 15 + 8
		dropItem.getLocked = true

		dropItem:setVisible(false)

		dropItem.startCount = i

		table.insert(self.coins, dropItem)

		local itemID = v.info.base_id

		if not resourceLockExistMap[itemID] then
			resourceLockExistMap[itemID] = true

			table.insert(resourceLockArr, itemID)
		end
	end

	self.flyCoinOnLockArr = resourceLockArr

	self:addEnterFrame("coin_move", function (dt)
		self:flyCoinsLoop(dt)
	end)
end

function FRAME_dungeon:flyCoinsLoop(dt)
	local timeScale = dt * 60
	local gravity = 2
	local speedDecay = 0.97
	local groundDecay = 0.6
	local threshold = 8
	local index = 1
	local loop = #self.coins
	local allStarted = true

	while index <= loop do
		local dropItem = self.coins[index]

		if dropItem.startCount > 0 then
			dropItem.startCount = dropItem.startCount - 1
			index = index + 1
			allStarted = false
		else
			if dropItem.startCount == 0 then
				dropItem:setVisible(true)

				dropItem.startCount = dropItem.startCount - 1
			end

			local x = dropItem.x + math.cos(dropItem.angle) * dropItem.speed
			local y = dropItem.y + math.sin(dropItem.angle) * dropItem.speed
			dropItem.speed = dropItem.speed * speedDecay
			dropItem.zspeed = dropItem.zspeed - gravity * timeScale
			dropItem.z = dropItem.z + dropItem.zspeed * timeScale
			local over = false

			if dropItem.z <= 0 then
				dropItem.z = -dropItem.z
				dropItem.zspeed = -dropItem.zspeed * groundDecay

				if math.abs(dropItem.zspeed) <= threshold then
					over = true
				end
			end

			dropItem:draw(x, y, true)

			if over then
				dropItem:flyToResource(function ()
					self.coinsCount = self.coinsCount - 1

					if self.coinsCount == 0 and self.flyCoinOnLockArr then
						for i, itemID in ipairs(self.flyCoinOnLockArr) do
							global.resource:unlockResource(itemID)
						end

						self.flyCoinOnLockArr = nil
					end
				end)
				table.remove(self.coins, index)

				loop = loop - 1
			else
				index = index + 1
			end
		end
	end

	if allStarted then
		if self.flyCoinOnComplete then
			self.flyCoinOnComplete()
		end

		self.flyCoinOnComplete = nil
	end

	if loop == 0 then
		self:removeEnterFrame("coin_move")
	end
end

function FRAME_dungeon:coutDmg(total, dmg)
	local str = nil

	if total == 0 then
		str = 0
	else
		str = math.round(dmg / total * 100)
	end

	self:createLabelOnFlag("flag_count_dmg", "mdskill " .. str .. "%")
end

function FRAME_dungeon:openNarakaPrepare()
	local eventData = MapEventManager.getEventByTagOne("selector")

	if eventData then
		local function refresh(eventIndex)
			if not eventIndex or eventIndex == eventData.index then
				local info = ConfParser.parse(eventData.info)
				local eventInfo = InfoDungeon.getEventInfo(eventData.index)
				local times = math.max(0, info.num - eventInfo.fin)

				if times > 0 then
					local str = Localization.getSrcText("选择{1}个神龛或符文石")

					self.mainUI:createLabelOnFlag("label_tip", StringUtil.replace(str, times))
				else
					self.mainUI:removeLabelOnFlag("label_tip")
				end
			end
		end

		notify.safeRegister(self, "event_fin", refresh)
		refresh()
	end
end

function FRAME_dungeon:openOpMode()
	self:createLabelOnFlag("label_tip", Localization.getSrcText("观察者模式"))
	self:hideModaoUI()
	transition.fadeTo(self.bottomUI, {
		time = 0.2,
		opacity = 0,
		onComplete = function ()
			self.bottomUI:setVisible(false)
		end
	})
	self:initMapConrol()
end

function FRAME_dungeon:initMapConrol()
	local bg = self.mainUI:getComponentByTag("bg")

	bg:setOpacity(0)
	bg:toTouchable()
	bg:addTouch(function (event, x, y)
		self:onMapTouch(event, x, y)
	end)
end

function FRAME_dungeon:onMapTouch(event, x, y)
	local map = global.map

	if event == "began" then
		self:stopMapScroll()

		self.drag = {
			speed = 0,
			dragging = false,
			angle = 0,
			startX = x,
			startY = y,
			startMapX = map.x,
			startMapY = map.y,
			preX = map.x,
			preY = map.y,
			currentX = map.x,
			currentY = map.y
		}

		local function mapDragLoop()
			local distance = math.sqrt(math.pow(self.drag.currentY - self.drag.preY, 2) + math.pow(self.drag.currentX - self.drag.preX, 2))

			if self.drag.speed == 0 then
				self.drag.speed = distance
			else
				self.drag.speed = self.drag.speed * 0.5 + distance * 0.5
			end

			if self.drag.preX ~= self.drag.currentX or self.drag.preY ~= self.drag.currentY then
				self.drag.angle = math.atan2(self.drag.currentY - self.drag.preY, self.drag.currentX - self.drag.preX)
				self.drag.preX = self.drag.currentX
				self.drag.preY = self.drag.currentY
			end
		end

		mapDragLoop()
		self:addEnterFrame("map_drag_test_speed", mapDragLoop)
	elseif event == "moved" then
		if not self.drag.dragging then
			local distance = math.sqrt(math.pow(y - self.drag.startY, 2) + math.pow(x - self.drag.startX, 2))

			if distance > 20 then
				self.drag.dragging = true
			end
		end

		if self.drag.dragging then
			local mapX1, mapY1 = map:screenToMap(self.drag.startX, self.drag.startY, true)
			local mapX2, mapY2 = map:screenToMap(x, y, true)
			local offsetX = mapX1 - mapX2
			local offsetY = mapY1 - mapY2
			self.drag.currentX = self.drag.startMapX + offsetX
			self.drag.currentY = self.drag.startMapY + offsetY

			if self.drag.speed == 0 then
				self.drag.speed = math.sqrt(math.pow(offsetX, 2) + math.pow(offsetY, 2))
				self.drag.angle = math.atan2(offsetY, offsetX)
			end

			map:scrollTo(self.drag.currentX, self.drag.currentY)
			map:setFov(map.x, map.y)
		end
	elseif event == "ended" then
		self:removeEnterFrame("map_drag_test_speed")

		if self.drag.dragging then
			self.drag.allScrolled = 0

			local function inertialScroll()
				self.drag.speed = self.drag.speed * 0.9
				self.drag.allScrolled = self.drag.allScrolled + self.drag.speed
				local offsetX = math.cos(self.drag.angle) * self.drag.allScrolled
				local offsetY = math.sin(self.drag.angle) * self.drag.allScrolled

				map:scrollTo(self.drag.currentX + offsetX, self.drag.currentY + offsetY)
				map:setFov(map.x, map.y)

				if self.drag.speed < 1 then
					self:removeEnterFrame("map_inertial_scroll")
				end
			end

			self:addEnterFrame("map_inertial_scroll", inertialScroll)
		else
			self:onMapTap(x, y)
		end
	end

	return true
end

function FRAME_dungeon:onMapTap(x, y)
	if self.battleUI then
		self.battleUI:onMapTap(x, y)
	end

	notify.dispatch("onMapTap", {
		x = x,
		y = y
	})
end

function FRAME_dungeon:stopMapScroll()
	self:removeEnterFrame("map_inertial_scroll")
end

function FRAME_dungeon:onExit()
	FRAME_dungeon.super.onExit(self)
	TeamManager.clearUnitChangeListener()

	nearNpcStack = {}
	nearInquireStack = {}
end

return FRAME_dungeon
