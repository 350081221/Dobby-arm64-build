local POP_focus = class("POP_focus", UI_base)
local BORDER = 20
local INNER = 10
local SLOT_BORDER = 40

function POP_focus.open(time, endParams, startPrams, easing, onTap, onComplete, touch_mode, onTouch, exTap)
	LayerConfig.setPopLocked("POP_focus", true)

	local ui = nil

	if POP_focus.ui then
		ui = POP_focus.ui
	else
		ui = POP_focus.new()

		display.getRunningScene():addChild(ui, LayerConfig.focus)

		POP_focus.ui = ui
	end

	ui:show(time, endParams.x, endParams.y, endParams.width, endParams.height, endParams.opacity, easing, startPrams.x, startPrams.y, startPrams.width, startPrams.height, startPrams.opacity, onTap, onComplete, touch_mode, onTouch, exTap)
end

function POP_focus.openBlackMask(opacity)
	LayerConfig.setPopLocked("POP_focus", true)

	local ui = nil

	if POP_focus.ui then
		ui = POP_focus.ui
	else
		ui = POP_focus.new()

		display.getRunningScene():addChild(ui, LayerConfig.focus)

		POP_focus.ui = ui
	end

	ui:blackMask(opacity)
end

function POP_focus.hide()
	if POP_focus.ui then
		local slot = POP_focus.ui:getComponentByTag("slot")

		slot:setOpacity(0)
		POP_focus.ui:setOpacity(0)
	end
end

function POP_focus.close(time)
	if POP_focus.ui then
		POP_focus.ui:destroy(time)
		LayerConfig.setPopLocked("POP_focus", false)
	end
end

function POP_focus.openOnNode(node, opacity, time, onTap, onComplete, fromZero, touch_mode, onTouch, onReset, close_event)
	local fitX, fitY = nil

	if fromZero then
		POP_focus.openBlackMask(opacity)
	end

	local exTap = nil

	if touch_mode == 2 and node.onFocusTap then
		function exTap()
			if node.onFocusTap then
				node:onFocusTap()
			elseif onReset then
				onReset()
			end
		end

		touch_mode = 1
	end

	if touch_mode == 3 and onTap then
		node:addNodeEventListener(cc.NODE_EVENT, function (event)
			local name = event.name

			if event.name == "cleanup" then
				onTap()
			end
		end)
	end

	if onTap and not empty(close_event) then
		local notify_id = nil
		notify_id = notify.safeRegister(node, close_event, function ()
			notify.unregister(close_event, notify_id)
			onTap()
		end)
	end

	local function onPositionFit()
		local size = node:getContentSize()
		local anchor = node:getAnchorPoint()
		local scale = UIManager.getBigScale()
		local endParams = {
			x = fitX + (0.5 - anchor.x) * size.width * scale,
			y = fitY + (0.5 - anchor.y) * size.height * scale,
			width = (size.width - INNER * 2) * scale,
			height = (size.height - INNER * 2) * scale,
			opacity = opacity
		}
		local startPrams = nil

		if fromZero then
			startPrams = {
				height = 0,
				width = 0,
				opacity = opacity
			}
		else
			startPrams = {
				width = display.width * 2,
				height = display.width * 2,
				opacity = opacity
			}
		end

		POP_focus.open(time or 15, endParams, startPrams, "outQuad", onTap, onComplete, touch_mode, onTouch, exTap)
	end

	local fitPositionLoop = nil

	function fitPositionLoop()
		if tolua.isnull(node) then
			Looper.stopLoop(POP_focus, fitPositionLoop)

			if onReset then
				onReset()
			end

			return
		end

		local x, y = node:getPosition()
		local pt = node:getParent():convertToWorldSpace(cc.p(x, y))

		if fitX == pt.x and fitY == pt.y then
			Looper.stopLoop(POP_focus, fitPositionLoop)
			onPositionFit()
		else
			fitX = pt.x
			fitY = pt.y
		end
	end

	Looper.startLoop(POP_focus, fitPositionLoop)
end

function POP_focus.openOnRect(parent, rect, opacity, time, onTap, onComplete, fromZero, touch_mode)
	local pt = parent:convertToWorldSpace(cc.p(rect.x, rect.y))
	local endParams = {
		x = pt.x + 0.5 * rect.width,
		y = pt.y + 0.5 * rect.height,
		width = rect.width - INNER * 2,
		height = rect.height - INNER * 2,
		opacity = opacity
	}
	local startPrams = nil

	if fromZero then
		startPrams = {
			height = 0,
			width = 0,
			opacity = opacity
		}
	else
		startPrams = {
			width = display.width * 2,
			height = display.width * 2,
			opacity = opacity
		}
	end

	POP_focus.open(time or 15, endParams, startPrams, "outQuad", onTap, onComplete, touch_mode)
end

function POP_focus.closeOnNode()
	if POP_focus.ui then
		local ui = POP_focus.ui
		POP_focus.ui = nil

		ui:show(10, ui.data.x, ui.data.y, ui.data.width + 100, ui.data.height + 100, 0, "outQuad", nil, , , , , , function ()
			ui:destroy()
		end)
	end
end

function POP_focus.isOpening()
	return POP_focus.ui ~= nil
end

function POP_focus:ctor()
	POP_focus.super.ctor(self, "pop_focus")
	self:init()
end

function POP_focus:init()
	local slot = self:getComponentByTag("slot")

	slot:retain()
	slot:removeFromParent()
	display.getRunningScene():addChild(slot, 1000)
	slot:release()
	POP_focus.makePuyo(slot)
end

function POP_focus.makePuyo(node, timeRatio)
	local animationStep1, animationStep2, animationStep3 = nil
	local border = 12
	timeRatio = timeRatio or 1

	function animationStep1()
		local size = node:getContentSize()
		local width = math.max(border, size.width)
		local height = math.max(border, size.height)
		local xScale = (border + width) / width
		local yScale = (border + height) / height

		transition.scaleTo(node, {
			easing = "sineOut",
			scaleX = xScale,
			scaleY = yScale,
			time = 0.5 * timeRatio,
			onComplete = animationStep2
		})
	end

	function animationStep2()
		transition.scaleTo(node, {
			easing = "sineOut",
			scaleY = 1,
			scaleX = 1,
			time = 0.5 * timeRatio,
			onComplete = animationStep1
		})
	end

	animationStep1()
end

function POP_focus:destroy(time)
	if self.data then
		Looper.stopTween(self.data.tweenID)
	end

	if not time or time <= 0 then
		self:removeSelf()
	else
		transition.fadeTo(self, {
			time = time,
			onComplete = function ()
				self:removeSelf()
			end
		})
	end
end

function POP_focus:blackMask(opacity)
	if self.data then
		Looper.stopTween(self.data.tweenID)
	end

	self:setOpacity(opacity)
	self:setFocus(0, 0, 0, 0)
end

function POP_focus:show(time, x, y, width, height, opacity, easing, startX, startY, startWidth, startHeight, startOpacity, onTap, onComplete, touch_mode, onTouch, exTap)
	if not easing or easing == "" then
		easing = "linear"
	end

	if self.data then
		Looper.stopTween(self.data.tweenID)
	end

	touch_mode = touch_mode or 1
	x = x or display.width / 2
	y = y or display.height / 2
	width = width or 100
	height = height or 100
	opacity = opacity or 255

	if not self.data then
		self.data = {
			x = startX or x,
			y = startY or y,
			width = startWidth or width,
			height = startHeight or height,
			opacity = startOpacity or opacity
		}
	end

	if time == 0 then
		self.data = {
			x = x,
			y = y,
			width = width,
			height = height,
			opacity = opacity
		}

		self:setOpacity(self.data.opacity)
		self:setFocus(x, y, width, height)
	else
		local touchMask = self:getComponentByTag("t5")

		local function onTweenUpdate()
			self:setOpacity(self.data.opacity)
			self:setFocus(self.data.x, self.data.y, self.data.width, self.data.height)
		end

		local function onTweenComplete()
			touchMask:setTouchEnabled(false)

			if onComplete then
				onComplete()
			end
		end

		onTweenUpdate()

		self.data.tweenID = Looper.tween(time, self.data, {
			x = x,
			y = y,
			width = width,
			height = height,
			opacity = opacity
		}, easing, onTweenComplete, onTweenUpdate)

		touchMask:toTouchable()
	end

	local block = self:getComponentByTag("5")

	if touch_mode == 3 or touch_mode == 4 then
		block:removeTouchable()
	else
		block:toTouchable()
		block:clearTouch()

		local tapLocked, exTapLocked = nil

		block:addTap(function ()
			if exTap and not exTapLocked then
				exTapLocked = true

				exTap()
			end

			if onTap and not tapLocked then
				tapLocked = true

				onTap()
			end

			block:setTouchSwallowEnabled(true)
		end)

		if onTouch then
			block:addTouch(function (event, x, y)
				onTouch(event, x, y)
			end)
		end
	end

	if touch_mode == 1 then
		block:setTouchSwallowEnabled(true)
	else
		block:setTouchSwallowEnabled(false)
	end
end

local function getBlockPosition(i, x, y, _width, _height)
	local blockX, blockY, width, height = nil

	if i == 1 then
		blockX = 0
		blockY = 0
		width = x - _width / 2
		height = display.height
	elseif i == 2 then
		blockX = x - _width / 2
		blockY = y + _height / 2
		width = _width
		height = display.height - blockY
	elseif i == 3 then
		blockX = x + _width / 2
		blockY = 0
		width = display.width - blockX
		height = display.height
	elseif i == 4 then
		blockX = x - _width / 2
		blockY = 0
		width = _width
		height = y - _height / 2
	end

	return blockX, blockY, width, height
end

function POP_focus:setFocus(x, y, _width, _height)
	local bigScale = UIManager.getBigScale()
	local slotBorder = SLOT_BORDER * bigScale
	local border = BORDER * bigScale

	for i = 1, 5 do
		local block = self:getComponentByTag(tostring(i))

		if i == 5 then
			block:setOpacity(0)
			block:setPos(x - _width / 2, y - _height / 2)
			block:setSize(_width, _height)

			local touchMask = self:getComponentByTag("t" .. tostring(i))

			touchMask:setOpacity(0)
			touchMask:setPos(x - _width / 2, y - _height / 2)
			touchMask:setSize(_width, _height)
		else
			local blockX, blockY, width, height = getBlockPosition(i, x, y, _width + border * 2, _height + border * 2)

			block:setPos(blockX, blockY)
			block:setSize(width, height)

			local blockX, blockY, width, height = getBlockPosition(i, x, y, _width, _height)
			local touchMask = self:getComponentByTag("t" .. tostring(i))

			touchMask:toTouchable()
			touchMask:setOpacity(0)
			touchMask:setPos(blockX, blockY)
			touchMask:setSize(width, height)
		end
	end

	local corner1 = self:getComponentByTag("corner_1")

	corner1:setScale(border / corner1.width)
	corner1:setPosition(x - _width / 2 - border / 2, y + _height / 2 + border / 2)

	local corner2 = self:getComponentByTag("corner_2")

	corner2:setScale(border / corner2.width)
	corner2:setPosition(x + _width / 2 + border / 2, y + _height / 2 + border / 2)

	local corner3 = self:getComponentByTag("corner_3")

	corner3:setScale(border / corner3.width)
	corner3:setPosition(x + _width / 2 + border / 2, y - _height / 2 - border / 2)

	local corner4 = self:getComponentByTag("corner_4")

	corner4:setScale(border / corner4.width)
	corner4:setPosition(x - _width / 2 - border / 2, y - _height / 2 - border / 2)

	local border1 = self:getComponentByTag("border_1")

	border1:setScaleX(border / border1.width)
	border1:setScaleY(_height / border1.height)
	border1:setPosition(x - _width / 2 - border / 2, y)

	local border2 = self:getComponentByTag("border_2")

	border2:setScaleX(_width / border2.width)
	border2:setScaleY(border / border2.height)
	border2:setPosition(x, y + _height / 2 + border / 2)

	local border3 = self:getComponentByTag("border_3")

	border3:setScaleX(border / border3.width)
	border3:setScaleY(_height / border3.height)
	border3:setPosition(x + _width / 2 + border / 2, y)

	local border4 = self:getComponentByTag("border_4")

	border4:setScaleX(_width / border4.width)
	border4:setScaleY(border / border4.height)
	border4:setPosition(x, y - _height / 2 - border / 2)

	local slot = self:getComponentByTag("slot")

	slot:setSize(_width + slotBorder, _height + slotBorder)
	slot:setPos(x - (_width + slotBorder) / 2, y - (_height + slotBorder) / 2)
end

function POP_focus:onExit()
	POP_focus.super.onExit(self)

	if not app.sceneChanging then
		local slot = self:getComponentByTag("slot")

		slot:removeSelf()
	end

	POP_focus.ui = nil
end

return POP_focus
