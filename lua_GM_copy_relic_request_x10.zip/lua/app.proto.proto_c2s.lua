local c2s = [[
	
handshake 1 {
	response {
		msg 0  : string
	}
}
auth_ok 2 {}
quit 4 {}


#压测开搞
bench_init 10001 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
	}
}

#压测战斗
bench_fight 10002 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
	}
}

#压测刷新酒馆
bench_tavern_refresh 10003 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
	}
}

#压测抽卡
bench_gacha 10004 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
	}
}












gm_log_error 9901 {
	request {
		beat 100 : integer
		
		tag 0 : string
		content 1 : string
		version 2 : string
	}
	response {
		err 0 : string
	}
}






gm_drop_test 9911 {
	request {
		beat 100 : integer
		
		loop 0 : integer
		equip_level 1 : integer
		mf 2 : integer
	}
	response {
		err 0 : string
		.Result {
			id 0 : integer
			times 1 : integer
		}
		results 5 : *Result
	}
}

gm_set_item 9912 {
	request {
		beat 100 : integer
		
		id 0 : integer
		num 1 : integer
	}
	response {
		err 0 : string
	}
}

gm_set_hero 9913 {
	request {
		beat 100 : integer
		
		id 0 : integer
		base_id 1 : integer
		level 2 : integer
	}
	response {
		err 0 : string
	}
}

gm_drop 9914 {
	request {
		beat 100 : integer
		
		drop_id 0 : string
		level 1 : integer
		rare 2 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

gm_set_pet 9915 {
	request {
		beat 100 : integer
		
		id 0 : integer
		name 1 : string
		base_id 2 : integer
		level 3 : integer
	}
	response {
		err 0 : string
	}
}

gm_building_level 9916 {
	request {
		beat 100 : integer
		
		tag 0 : integer
		level 1 : integer
	}
	response {
		err 0 : string
	}
}


gm_guide 9917 {
	request {
		beat 100 : integer
		
		id 0 : integer
	}
	response {
		err 0 : string
	}
}

gm_guide_free 9918 {
	request {
		beat 100 : integer
		
		id 0 : integer
		is_fin 1 : integer
	}
	response {
		err 0 : string
	}
}

gm_mission 9919 {
	request {
		beat 100 : integer
		
		id 0 : integer
		is_fin 1 : integer
	}
	response {
		err 0 : string
	}
}

gm_attrs 9920 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
		.Attr {
			id 0 : string
			value 1 : integer
			hero_id 2 : integer
			pet_id 3 : integer
		}
		attr 1 : *Attr
	}
}

gm_mine 9921 {
	request {
		beat 100 : integer
		
		mine_index 0 : integer
		is_active 1 : integer
	}
	response {
		err 0 : string
	}
}

gm_task_reset 9922 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
	}
}

gm_bag_item 9923 {
	request {
		beat 100 : integer
		
		id 0 : integer
		num 1 : integer
	}
	response {
		err 0 : string
	}
}

gm_bag_card 9924 {
	request {
		beat 100 : integer
		
		id 0 : integer
	}
	response {
		err 0 : string
	}
}

gm_mirror_set_level 9925 {
	request {
		beat 100 : integer
		
		type 0 : integer
		level 1 : integer
	}
	response {
		err 0 : string
	}
}

gm_equip_remove_unequiped 9926 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
	}
}

gm_task_time_clear 9927 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
	}
}



gm_drop_item 9928 {
	request {
		beat 100 : integer
		
		id 0 : integer
		num 1 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}


gm_set_abyss 9929 {
	request {
		beat 100 : integer
		
		max_layer 0 : integer
		max_level 1 : integer
		autopick_time 2 : integer
		autopick_curr 3 : integer
	}
	response {
		err 0 : string
	}
}




gm_dungeon_enter 9930 {
	request {
		beat 100 : integer
		
		layer 1 : integer
		enter_layer 2 : integer
	}
	response {
		err 0 : string
		type 1 : integer
		dungeon_id 2 : string
		level 3 : integer
		seed 4 : integer
		map_seeds 5 : *integer
		quest_id 6 : integer
		quest_seed 7 : integer
		pass_count 8 : integer
		pass_total 9 : integer
		abyss_seed 10 : integer
		quest_level 11 : integer
		version 12 : string

		mission_id 13 : integer
		quest_db_id 14 : integer
		stage_type 15 : integer
		stage_id 16 : integer
		stage_params 17 : string

		prob_up 18 : *Probup
	
		speedup 19 : integer

		layer_safe 20 : integer

		mutate_type 21 : integer
		mutate_id 22 : integer
		mutate_time 23 : integer
		akasa_mutate_time 24 : integer
		abyss_layer 25 : integer
		enter_layer 26 : integer

		actv_monster 27 : *ActvMonster

		terrain_type 28 : integer
		terrain_id 29 : integer

		autopick_curr 41 : integer
		time_used 42 : integer

		session 100 : string
	}
}


gm_dungeon_monster 9931 {
	request {
		beat 100 : integer
		
		map_index 0 : integer
		event_index 1 : integer
	}
	response {
		err 0 : string
		pass_count 1 : integer
		relic 2 : *RelicData
		shrine 3 : *ShrineData
	}
}

gm_checksum_free 9932 {
	request {
		beat 100 : integer
		
		value 0 : integer
	}
	response {
		err 0 : string
	}
}



gm_gacha_test 9933 {
	request {
		beat 100 : integer
		
		loop 0 : integer
		gacha_id 1 : integer

		weight_arr 2 : *integer
	}
	response {
		err 0 : string
		.Result {
			id 0 : integer
			times 1 : integer
			variance 2 : integer
		}
		results 5 : *Result
		per_gacha 6 : integer

		.CardResult {
			id 0 : integer
			num 1 : integer
		}
		card_result 1 : *CardResult
	}
}


gm_gacha_test_clear 9934 {
	request {
		beat 100 : integer

		gacha_id 0 : integer
	}
	response {
		err 0 : string
	}
}




gm_card_remove_unequiped 9935 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
	}
}


gm_book 9936 {
	request {
		beat 100 : integer
		
		base_id 0 : integer
		id 1 : integer
		record 2 : integer
	}
	response {
		err 0 : string
	}
}

gm_clear_nonexist_item 9937 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
		count 1 : integer
	}
}


gm_hero_dismiss_nonpos 9938 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}


gm_refresh_tavern 9939 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
	}
}


gm_gacha_info 9940 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
		.ScoreData {
			group 0 : integer
			score 1 : integer
			hide_count 2 : integer
		}
		score_group 1 : *ScoreData
	}
}

gm_test 9941 {
	request {
		beat 100 : integer
		
		id 0 : integer
	}
	response {
		err 0 : string

		result 1 : string
	}
}

gm_drop_limit 9942 {
	request {
		beat 100 : integer
		
		value 0 : integer
	}
	response {
		err 0 : string
	}
}

gm_set_item_limit 9943 {
	request {
		beat 100 : integer
		
		id 0 : integer
		num 1 : integer
	}
	response {
		err 0 : string
	}
}

gm_set_arena 9944 {
	request {
		beat 100 : integer
		
		season 0 : integer
		points 1 : integer
		vs_points 2 : integer
	}
	response {
		err 0 : string
	}
}

gm_order_reset 9945 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
	}
}

gm_init_item 9946 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
	}
}

gm_dust_modify 9947 {
	request {
		beat 100 : integer

		equip_id 1 : integer

		dust_id_1 51 : integer
		dust_ran_1 52 : integer
		dust_level_1 54 : integer
		dust_exp_1 55 : integer

		dust_id_2 61 : integer
		dust_ran_2 62 : integer
		dust_level_2 64 : integer
		dust_exp_2 65 : integer

		dust_id_3 71 : integer
		dust_ran_3 72 : integer
		dust_level_3 74 : integer
		dust_exp_3 75 : integer
	}
	response {
		err 0 : string
	}
}

gm_ranking_add 9948 {
	request {
		beat 100 : integer

		type 1 : integer
		points 2 : integer
		user_id 3 : integer
	}
	response {
		err 0 : string
	}
}

#usedrop万测机
gm_item_usedrop 9949 {
	request {
		beat 100 : integer

		item_id 1 : integer
		num 2 : integer
	}
	response {
		err 0 : string
	}
}

# 给公会增加钱和资源
gm_union_set_money_and_res 9950 {
	request {
		beat 100 : integer
		money 0 : integer
		res 1 : integer
	}
	response {
		err 0 : string
	}
}

#drop万测机
gm_drop_check 9951 {
	request {
		beat 100 : integer

		drop_id 1 : integer
		num 2 : integer
	}
	response {
		err 0 : string
	}
}


#usedrop实测
gm_item_usedrop_ui 9952 {
	request {
		beat 100 : integer

		item_id 1 : integer
		num 2 : integer
	}
	response {
		err 0 : string

		.DropItemData {
			base_id 0 : integer
			times 1 : integer
			num 2 : integer
		}
		item_list 1 : *DropItemData
		equip_list 2 : *DropItemData
		card_list 3 : *DropItemData

		.DropData {
			min 0 : integer
			max 1 : integer
			min_count 2 : integer
			max_count 3 : integer
		}
		item_drop 11 : DropData
		equip_drop 12 : DropData
		card_drop 13 : DropData
	}
}

#测试变量
gm_var 9953 {
	request {
		beat 100 : integer
		name 1 : string
	}
	response {
		err 0 : string
		json_str 1 : string
	}
}



#注册
auth_register 102 {
	request {
		beat 100 : integer
		
		username 0 : string
		password 1 : string
		mark 2 : string

		lang 20 : string
		sys_lang 21 : string
		sys_country 22 : string
		ta_device_id 23 : string
		ta_distinct_id 24 : string

		appsflyer_id 30 : string
		client_os 31 : string
		pack_tag 32 : string
		local_time 33 : integer
		time_zone 34 : integer
		platform 35 : string
	}
	response {
		err 0 : string
		id 1 : integer
		time 2 : integer
		timezone_offset 3 : integer
		version 4 : string

		server_id 11 : integer
		original_id 12 : integer

		is_neo 13 : integer
		is_bench 14 : integer
	}
}

#登录
auth_login 103 {
	request {
		beat 100 : integer
		
		username 0 : string
		password 1 : string
		is_reconn 2 : integer
		mark 3 : string
		
		lang 20 : string

		appsflyer_id 30 : string
		client_os 31 : string
		pack_tag 32 : string
		local_time 33 : integer
		time_zone 34 : integer
		platform 35 : string
	}
	response {
		err 0 : string
		id 1 : integer
		time 2 : integer
		timezone_offset 3 : integer
		version 4 : string
		msg 10 : string

		server_id 11 : integer
		original_id 12 : integer

		is_neo 13 : integer
		is_bench 14 : integer

		ban_type 30 : integer
	}
}

#渠道登录
auth_login_qudao 104 {
	request {
		beat 100 : integer
		
		code 0 : integer
		user_id 1 : integer
		user_name 2 : string
		token 3 : string
		channel_type 4 : integer
		is_reconn 5 : integer
		mark 6 : string

		lang 20 : string
		sys_lang 21 : string
		sys_country 22 : string
		ta_device_id 23 : string
		ta_distinct_id 24 : string

		appsflyer_id 30 : string
		client_os 31 : string
		pack_tag 32 : string
		local_time 33 : integer
		time_zone 34 : integer
		platform 35 : string
	}
	response {
		err 0 : string
		id 1 : integer
		time 2 : integer
		timezone_offset 3 : integer
		is_create 4 : integer
		version 5 : string
		msg 10 : string

		server_id 11 : integer
		original_id 12 : integer

		is_neo 13 : integer
		is_bench 14 : integer
		
		ban_type 30 : integer
	}
}

#逻辑服登录
auth_login_gate 105 {
	request {
		beat 100 : integer
		
		token 0 : string
		is_reconn 1 : integer
		scode 2 : string

		lang 20 : string
		sys_lang 21 : string
		sys_country 22 : string
		ta_device_id 23 : string
		ta_distinct_id 24 : string

		appsflyer_id 30 : string
		client_os 31 : string
		pack_tag 32 : string
		local_time 33 : integer
		time_zone 34 : integer
		platform 35 : string
	}
	response {
		err 0 : string
		id 1 : integer
		time 2 : integer
		timezone_offset 3 : integer
		is_create 4 : integer
		version 5 : string
		msg 10 : string

		server_id 11 : integer
		original_id 12 : integer

		is_neo 13 : integer
		is_bench 14 : integer

		gateName 20 : string
		line_id 21 : integer

		ban_type 30 : integer
	}
}

#激活码激活账号
auth_active 106 {
	request {
		beat 100 : integer
		
		user_id 0 : integer
		active_code 1 : string
	}
	response {
		err 0 : string
	}
}

# 取得服务器有哪些服（线）可用
game_line_list 107 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
		current_line_id 1 : integer				# 玩家当前在哪条线
		all_line_info 2 : *LineData				# 服务器所有的线（不包含服务器地址信息）
	}
}

# 玩家请求切线 (注意 请求这条协议，也意味的服务器的 token 已经改变了)
user_request_change_line 108 {
	request {
		beat 100 : integer
		line_id 0 : integer 
	}
	response {
		err 0 : string
		line_addr 1 : string					# 用来连接的 ip 和 port 地址
		token 2 : string 						# 客户端直接用这个 token 登陆 line_addr 即可登这个逻辑
	}
}

# 客户端询问，当前所有的线是否被忽略（需要迁移到别的逻辑服）
user_request_curr_line_state 109 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
		is_ignore 1 : integer 						# 0 当前线路正常，不需要做任何处理， 1当前线路被忽略，需要切线
		line_addr 2 : string						# is_ignore为1时，才有值
		token 3 : string
	}
}



#玩家初始化
user_query 110 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
		nickname 1 : string
		nicklang 2 : string
		login_time 3 : integer
		total_time 4 : integer
		create_time 5 : integer
		head 6 : integer
		head_frame 7 : integer
		mute_time 8 : integer
		credit_100 9 : integer
		ban_credit 10 : integer
	}
}

#首次输入玩家昵称
user_nickname 111 {
	request {
		beat 100 : integer
		
		nickname 0 : string
		lang 1 : string
	}
	response {
		err 0 : string
	}
}

#实名制（失效）
user_realname 112 {
	request {
		beat 100 : integer
		
		name 0 : string
		sfz 1 : string
	}
	response {
		err 0 : string
	}
}

#设置头像和头像框
user_head 113 {
	request {
		beat 100 : integer
		
		head 0 : integer
		head_frame 1 : integer
		is_arena_frame 2 : integer
	}
	response {
		err 0 : string
		head 1 : integer
		head_frame 2 : integer
	}
}

user_report 114 {
	request {
		beat 100 : integer
		
		code 0 : integer
	}
	response {
		err 0 : string
	}
}

#使用兑换码
user_redeem 115 {
	request {
		beat 100 : integer
		
		code 0 : string
	}
	response {
		err 0 : string
		msg 1 : string

		rewards 2 : *RewardData
	}
}

#获得网关列表
user_gate_list 116 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
		.GateData {
			name 0 : string
			player_num 1 : integer
			agent_num 2 : integer
		}
		gate_list 5 : *GateData
	}
}

#非首次输入昵称
user_set_name 117 {
	request {
		beat 100 : integer
		
		name 0 : string
		lang 1 : string
	}
	response {
		err 0 : string
	}
}

#
user_yd_check 118 {
	request {
		beat 100 : integer

		type 0 : integer
		token 1 : string
		platform 2 : string
		appVersion 3 : string
		version 4 : string
		deviceId 5 : string
	}
	response {
		err 0 : string

		result 1 : integer
	}
}

#检查过期头像
user_head_check 119 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
		changed 1 : *integer
	}
}

#初始化一揽子加载
user_init_query 120 {
	request {
		beat 100 : integer
		
	}
	response {
		.ServiceQuery{
			.SnsData {
				id 0 : integer
				sns_id 1 : integer
				text 2 : string
				url 3 : string
			}
			sns_list 0 : *SnsData

			.FeedbackData {
				id 0 : integer
				text 1 : string
				reply 2 : string
				is_read 3 : integer
			}
			feedback_list 1 : *FeedbackData
			
			review_reward 2 : integer
		}
		service_query 1 : ServiceQuery


		.AbyssAreaQuery{
			list 1 : *AbyssAreaData
		}
		abyss_area_query 2 : AbyssAreaQuery


		.DelayItemQuery{
			.DelayItemData {
				id 0 : integer
				type 1 : integer
				start_time 2 : integer
				end_time 3 : integer
				item_id 4 : integer
				item_num 5 : integer
			}
			list 0 : *DelayItemData
		}
		delay_item_query 3 : DelayItemQuery


		.HomeQuery{
			map_id 0 : integer
			is_public 1 : integer
			visiting_user 2 : integer

			shop_refresh_time 10 : integer
		}
		home_query 4 : HomeQuery


		.ManualRewardQuery{
			record_1 0 : integer
			record_2 1 : integer
		}
		manual_reward_query 5 : ManualRewardQuery


		.UserShowQuery{
			.UserShowData {
				type 0 : integer
				index 1 : integer
				id 2 : integer
			}
			list 1 : *UserShowData
		}
		user_show_query 6 : UserShowQuery


		.MarukaQuery{
			reward_time_1 0 : integer
		}
		maruka_query 7 : MarukaQuery


		.NarakaQuery{
			reward_count 0 : integer
			reward_time 1 : integer
			mode_arr 2 : string

			shop_refresh_time 10 : integer
		}
		naraka_query 8 : NarakaQuery


		.ItemShopQuery{
			list 1 : *ItemShop
		}
		item_shop_query 9 : ItemShopQuery


		.BookQuery{
			.BookData {
				base_id 0 : integer
				create_time 1 : integer
				update_time 2 : integer
				reward_already 3 : integer
				seed 4 : integer
				read_count 5 : integer
				record_1 11 : integer
				record_2 12 : integer
				record_3 13 : integer
				record_4 14 : integer
			}

			list 1 : *BookData
		}
		book_query 10 : BookQuery


		.HeroSpQuery{
			.HeroSpData {
				base_id 0 : integer
				story_id 1 : integer
			}
			list 1 : *HeroSpData
		}
		hero_sp_query 11 : HeroSpQuery


		.AbyssRewardQuery{
			already_id 1 : integer
			area_id 2 : integer
		}
		abyss_reward_query 12 : AbyssRewardQuery


		.AbyssPassQuery{
			free_record_1 1 : integer
			free_record_2 2 : integer
			free_record_3 3 : integer
			free_record_4 4 : integer
			free_record_5 5 : integer
			free_record_6 6 : integer
			free_record_7 7 : integer
			free_record_8 8 : integer
			free_record_9 9 : integer
			free_record_10 10 : integer
			free_record_11 11 : integer
			free_record_12 12 : integer
			free_record_13 13 : integer
			free_record_14 14 : integer
			free_record_15 15 : integer
			free_record_16 16 : integer
			free_record_17 17 : integer
			free_record_18 18 : integer
			free_record_19 19 : integer
			free_record_20 20 : integer

			pay_record_1 21 : integer
			pay_record_2 22 : integer
			pay_record_3 23 : integer
			pay_record_4 24 : integer
			pay_record_5 25 : integer
			pay_record_6 26 : integer
			pay_record_7 27 : integer
			pay_record_8 28 : integer
			pay_record_9 29 : integer
			pay_record_10 30 : integer
			pay_record_11 31 : integer
			pay_record_12 32 : integer
			pay_record_13 33 : integer
			pay_record_14 34 : integer
			pay_record_15 35 : integer
			pay_record_16 36 : integer
			pay_record_17 37 : integer
			pay_record_18 38 : integer
			pay_record_19 39 : integer
			pay_record_20 40 : integer

			paid_1 41 : integer
			paid_2 42 : integer
			paid_3 43 : integer
			paid_4 44 : integer
			paid_5 45 : integer
			paid_6 46 : integer
			paid_7 47 : integer
			paid_8 48 : integer
			paid_9 49 : integer
			paid_10 50 : integer
		}
		abyss_pass_query 13 : AbyssPassQuery


		.TowerQuery{
			err 0 : string
			list 1 : *TowerData
		}
		tower_query 14 : TowerQuery


		.CampfireQuery{
			season_id 0 : integer
			season_time 1 : integer
			base_id 2 : integer

			season 10 : integer
			score 11 : integer
			exp_times 12 : integer
			exp_time 13 : integer 
		}
		campfire_query 15 : CampfireQuery


		.ProbupQuery{
			list 0 : *ProbupData
		}
		probup_query 16 : ProbupQuery


		.VarsQuery{
			language 0 : string
			scene 1 : integer
			ignore_record 2 : string
			autolock 3 : integer
			nodrop_saved 4 : integer
		}
		vars_query 17 : VarsQuery


		.ConsumeQuery{
			bag_unlock 0 : integer
			armory_unlock 1 : integer
		}
		consume_query 18 : ConsumeQuery


		.IllusionQuery{
			list 0 : *integer
		}
		illusion_query 19 : IllusionQuery


		.RankingQuery{
			list 0 : *RankingData
		}
		ranking_query 20 : RankingQuery


		.AbyssGiftQuery{
			progress 0 : integer
			reward_time 1 : integer
			shop_refresh_time 2 : integer
		}
		abyss_gift_query 21 : AbyssGiftQuery


		.FishingQuery{
			shop_refresh_time 0 : integer
			rod_id 1 : integer
			list 2 : *FishingData
			ponds 3 : *FishingPondData
		}
		fishing_query 22 : FishingQuery


		.ManualMonsterQuery{
			list 0 : *ManualMonsterData
		}
		manual_monster_query 23 : ManualMonsterQuery


		.GachaQuery{
			shop_refresh_time 0 : integer
			.ScoreData {
				group 0 : integer
				score 1 : integer
			}
			score_group 1 : *ScoreData

			.OpenData {
				id 0 : integer
				open 1 : integer
			}
			list 2 : *OpenData
			shop_list 3 : *OpenData
		}
		gacha_query 24 : GachaQuery


		.WildQuery{
			list 0 : *WildData
		}
		wild_query 25 : WildQuery


		.ExchangeQuery{
			list 0 : *ExchangeData
			appr 1 : string
			stall_name 2 : string
			catalog_select 3 : string
			score 4 : integer
		}
		exchange_query 26 : ExchangeQuery


		.FarmQuery{
			sort_seed 0 : integer
			sort_arr 1 : string
			tile_num 2 : integer
			cash 3 : integer
			cash_time 4 : integer
			speedup_time 5 : integer
			farm_seed 6 : integer

			shop_refresh_time 7 : integer
		}
		farm_query 27 : FarmQuery


		.LikesQuery{
			likes 0 : integer
			likes_offline 1 : integer
			like_time 2 : integer
			like_count 3 : integer
			daily_reward_count 4 : integer
			daily_reward_time 5 : integer
		}
		likes_query 28 : LikesQuery


		.PaygiftQuery{
			refresh_time_1 0 : integer
			refresh_time_2 1 : integer
			refresh_time_3 2 : integer

			list 3 : *ShopItem

			.OpenData {
				id 0 : integer
				open 1 : integer
			}
			open_list 4 : *OpenData
			open_101_list 5 : *OpenData
		}
		paygift_query 29 : PaygiftQuery


		.RecordMonthQuery{
			turn 0 : integer
			login_time 1 : integer
			login_days 2 : integer
			reward_record 3 : integer
			reward_time 4 : integer
		}
		record_month_query 30 : RecordMonthQuery

		.RecordFestQuery{
			.RecordFest {
				type 0 : integer
				start_time 1 : integer
				login_time 2 : integer
				login_days 3 : integer
				reward_record 4 : integer
			}
			list 0 : *RecordFest
		}
		record_fest_query 32 : RecordFestQuery


		.AchieveQuery{
			list 1 : *AchieveData
		}
		achieve_query 33 : AchieveQuery


		.ArenaQuery{
			season_id 0 : integer
			season_time 1 : integer
			actived 2 : integer

			season 10 : integer
			season_battle 11 : integer
			points 12 : integer
			score 13 : integer
			combo 14 : integer
			combo_season 15 : integer
			battle_index_start 16 : integer
			battle_index_over 17 : integer
			vs_points 18 : integer

			refresh_time 20 : integer
			refresh_count 21 : integer
			refresh_count_time 22 : integer
			battle_count 23 : integer
			battle_time 24 : integer
			reward_already 25 : integer
			reward_time 26 : integer
			week_reward_already 27 : integer
			week_reward_time 28 : integer
			battle_buy_count 29 : integer
			battle_buy_time 30 : integer

			shop_refresh_time 31 : integer

			ranking_level 32 : integer  					# 1,2,3 对应 a,b,c 三个档次的排行榜
			max_ranking_level 33 : integer
		}
		arena_query 34 : ArenaQuery


		.TravelQuery{
			list 0 : *TravelData
			hour_used 1 : integer
			refresh_time 2 : integer
		}
		travel_query 35 : TravelQuery


		.FunctionQuery{
			list 0 : *FunctionData
		}
		function_query 36 : FunctionQuery


		.MirrorQuery{
			list 0 : *MirrorData
		}
		mirror_query 37 : MirrorQuery


		.TaskQuestQuery{
			list 0 : *TaskQuestData
		}
		task_quest_query 38 : TaskQuestQuery


		.OrderQuery{
			first_1 0 : integer
			first_2 1 : integer
			first_3 2 : integer
			first_4 3 : integer
			first_5 4 : integer
			first_6 5 : integer
			mooncard_day 6 : integer
			mooncard_zuan_day 7 : integer
			seasoncard_day 8 : integer
			total_pay_100 9 : integer
			first_pay_time 10 : integer
			last_pay_time 11 : integer
			daily_order_time 12 : integer
			daily_order_reward_time 13 : integer
			gift_record 14 : integer
			free_gacha_day 15 : integer
			safe_return_used 16 : integer
			safe_return_day 17 : integer
			once_1 18 : integer
			once_2 19 : integer
			once_3 20 : integer
			once_4 21 : integer
			once_5 22 : integer
			once_6 23 : integer
			daily_1 24 : integer
			daily_2 25 : integer
			daily_3 26 : integer
			daily_4 27 : integer
			daily_5 28 : integer
			daily_6 29 : integer
			daily_level 30 : integer
			daily_level_time 31 : integer
		}
		order_query 39 : OrderQuery


		.QuickSlotsQuery{
			slot_1 0 : integer
			slot_2 1 : integer
			slot_3 2 : integer
			slot_4 3 : integer
			pet_index 4 : integer
			rune_1 5 : integer
			rune_2 6 : integer
			rune_3 7 : integer
			rune_4 8 : integer
		}
		quick_slots_query 40 : QuickSlotsQuery


		.BagQuery{
			list 0 : *BagData
			amount 1 : integer
		}
		bag_query 41 : BagQuery


		.ModaoQuery{
			.ModaoData {
				base_id 0 : integer
				level 1 : integer
				pos 2 : integer
			}
			list 0 : *ModaoData
		}
		modao_query 42 : ModaoQuery


		.ShopQuery{
			refresh_time_1 0 : integer
			refresh_count_1 1 : integer
			refresh_count_time_1 2 : integer
			refresh_time_2 3 : integer
			refresh_count_2 4 : integer
			refresh_count_time_2 5 : integer
			opening_3 6 : integer
		}
		shop_query 43 : ShopQuery


		.TavernQuery{
			list 0 : *TavernHeroData
			refresh_time 1 : integer
			refresh_count 2 : integer
			refresh_count_time 3 : integer
			count 4 : integer
			target_quality 5 : integer
		}
		tavern_query 44 : TavernQuery


		.FurnaceQuery{
			cash 0 : integer
			cash_time 1 : integer
			mine_num 2 : integer
			record_1 3 : integer
			record_2 4 : integer
			record_3 5 : integer
			record_4 6 : integer
			record_5 7 : integer
			record_6 8 : integer
			record_7 9 : integer
			record_8 10 : integer
			record_9 11 : integer
			record_10 12 : integer
		}
		furnace_query 45 : FurnaceQuery


		.GatherQuery{
			list 1 : *GatherData
		}
		gather_query 47 : GatherQuery


		.MissionQuery{
			record_1 1 : integer
			record_2 2 : integer
			record_3 3 : integer
			record_4 4 : integer
			record_5 5 : integer
			record_6 6 : integer
			record_7 7 : integer
			record_8 8 : integer
			record_9 9 : integer
			record_10 10 : integer

			record_11 11 : integer
			record_12 12 : integer
			record_13 13 : integer
			record_14 14 : integer
			record_15 15 : integer
			record_16 16 : integer
			record_17 17 : integer
			record_18 18 : integer
			record_19 19 : integer
			record_20 20 : integer

			record_21 21 : integer
			record_22 22 : integer
			record_23 23 : integer
			record_24 24 : integer
			record_25 25 : integer
			record_26 26 : integer
			record_27 27 : integer
			record_28 28 : integer
			record_29 29 : integer
			record_30 30 : integer

			record_31 31 : integer
			record_32 32 : integer
			record_33 33 : integer
			record_34 34 : integer
			record_35 35 : integer
			record_36 36 : integer
			record_37 37 : integer
			record_38 38 : integer
			record_39 39 : integer
			record_40 40 : integer

			record_41 41 : integer
			record_42 42 : integer
			record_43 43 : integer
			record_44 44 : integer
			record_45 45 : integer
			record_46 46 : integer
			record_47 47 : integer
			record_48 48 : integer
			record_49 49 : integer
			record_50 50 : integer

			record_51 51 : integer
			record_52 52 : integer
			record_53 53 : integer
			record_54 54 : integer
			record_55 55 : integer
			record_56 56 : integer
			record_57 57 : integer
			record_58 58 : integer
			record_59 59 : integer
			record_60 60 : integer

			record_61 61 : integer
			record_62 62 : integer
			record_63 63 : integer
			record_64 64 : integer
			record_65 65 : integer
			record_66 66 : integer
			record_67 67 : integer
			record_68 68 : integer
			record_69 69 : integer
			record_70 70 : integer

			record_71 71 : integer
			record_72 72 : integer
			record_73 73 : integer
			record_74 74 : integer
			record_75 75 : integer
			record_76 76 : integer
			record_77 77 : integer
			record_78 78 : integer
			record_79 79 : integer
			record_80 80 : integer

			record_81 81 : integer
			record_82 82 : integer
			record_83 83 : integer
			record_84 84 : integer
			record_85 85 : integer
			record_86 86 : integer
			record_87 87 : integer
			record_88 88 : integer
			record_89 89 : integer
			record_90 90 : integer

			record_91 91 : integer
			record_92 92 : integer
			record_93 93 : integer
			record_94 94 : integer
			record_95 95 : integer
			record_96 96 : integer
			record_97 97 : integer
			record_98 98 : integer
			record_99 99 : integer
			record_100 100 : integer
		}
		mission_query 48 : MissionQuery


		.QuestQuery{
			list 0 : *QuestData
		}
		quest_query 49 : QuestQuery


		.KanbanQuery{
			refresh_time 0 : integer
			refresh_count 1 : integer
			refresh_count_time 2 : integer
			level 3 : integer
			points 4 : integer
			act_count 5 : integer
			act_time 6 : integer
			reward_record 7 : integer
			target_reward_time 8 : integer
		}
		kanban_query 50 : KanbanQuery


		.BuildingQuery{
			list 0 : *BuildingData
		}
		building_query 51 : BuildingQuery


		.GuideQuery{
			guide_id 0 : integer
			free_1 1 : integer
			free_2 2 : integer
			free_3 3 : integer
			free_4 4 : integer
			free_5 5 : integer
			pet_state 6 : integer
			pet_time 7 : integer
		}
		guide_query 52 : GuideQuery


		.ItemLimitQuery{
			list 1 : *ItemLimitData
		}
		item_limit_query 53 : ItemLimitQuery



		.ArmoryQuery{
			list 0 : *ArmoryData
			amount 1 : integer
		}
		armory_query 54 : ArmoryQuery


		.RebateQuery{
		}
		rebate_query 55 : RebateQuery


		.WorldQuery{
			.World {
				id 0 : string
				value 1 : integer
			}
			list 1 : *World
		}
		world_query 56 : WorldQuery


		.ParamsQuery{
			.Param {
				code 0 : string
				value 1 : integer
				value_str 2 : string
			}
			list 1 : *Param
		}
		params_query 57 : ParamsQuery


		.ManualQuery{
			list 0 : *ManualData
		}
		manual_query 58 : ManualQuery


		.LangQuery{
			.Lang {
				id 0 : string
				open 1 : integer
			}
			list 1 : *Lang
		}
		lang_query 65 : LangQuery



		.FirstAchieveQuery{
			.FirstAchieveData {
				base_id 0 : integer
				count 1 : integer
				step 2 : integer
				rewarded 3 : integer
			}
			list 1 : *FirstAchieveData
			
			start_time 2 : integer
			reward_record 3 : integer
			paid 4 : integer
			paid_reward_record 5 : integer
		}
		first_achieve_query 66 : FirstAchieveQuery


		.UnionQuery {
			base_info 0 : UnionBaseInfo
			private_info 1 : UnionPrivateInfo
			building_info 2 : *UnionBuildingInfo
			buff_info 3 : UnionBuffInfo

			shop_refresh_time 10 : integer
		}
		union_query 70 : UnionQuery
	}
}


#初始化一揽子加载（尘封）
user_init_query_dust 121 {
	request {
		beat 100 : integer
		
	}
	response {
		.DustQuery{
			list 1 : *DustData
			gm_list 2 : *DustGM
		}
		dust_query 1 : DustQuery


		.DustAchieveQuery{
			list 1 : *DustAchieveData

			day_refresh 2 : integer
			day_rewarded 3 : integer
			day_rewarded_time 4 : integer
			week_refresh 5 : integer
			week_rewarded 6 : integer
			week_rewarded_time 7 : integer
		}
		dust_achieve_query 2 : DustAchieveQuery



		.DustPassQuery{
			free_record_1 1 : integer
			free_record_2 2 : integer
			free_record_3 3 : integer
			free_record_4 4 : integer
			free_record_5 5 : integer
			free_record_6 6 : integer
			free_record_7 7 : integer
			free_record_8 8 : integer
			free_record_9 9 : integer
			free_record_10 10 : integer
			free_record_11 11 : integer
			free_record_12 12 : integer
			free_record_13 13 : integer
			free_record_14 14 : integer
			free_record_15 15 : integer
			free_record_16 16 : integer
			free_record_17 17 : integer
			free_record_18 18 : integer
			free_record_19 19 : integer
			free_record_20 20 : integer

			pay_record_1 21 : integer
			pay_record_2 22 : integer
			pay_record_3 23 : integer
			pay_record_4 24 : integer
			pay_record_5 25 : integer
			pay_record_6 26 : integer
			pay_record_7 27 : integer
			pay_record_8 28 : integer
			pay_record_9 29 : integer
			pay_record_10 30 : integer
			pay_record_11 31 : integer
			pay_record_12 32 : integer
			pay_record_13 33 : integer
			pay_record_14 34 : integer
			pay_record_15 35 : integer
			pay_record_16 36 : integer
			pay_record_17 37 : integer
			pay_record_18 38 : integer
			pay_record_19 39 : integer
			pay_record_20 40 : integer

			paid_1 41 : integer
			paid_2 42 : integer
			paid_3 43 : integer
			paid_4 44 : integer
			paid_5 45 : integer
			paid_6 46 : integer
			paid_7 47 : integer
			paid_8 48 : integer
			paid_9 49 : integer
			paid_10 50 : integer
		}
		dust_pass_query 3 : DustPassQuery
		
		.DustAttrManualQuery {
			.AttrManualData {
				base_id 0 : integer
				rewarded 1 : integer
			}
			list 1 : *AttrManualData
		}
		dust_attr_manual_query 4 : DustAttrManualQuery
	}
}


#初始化一揽子加载（活动）
user_init_query_actv 122 {
	request {
		beat 100 : integer
		
	}
	response {
		.ChargeQuery{
			list 0 : *ChargeData
		}
		charge_query 1 : ChargeQuery


		.FestivalQuery{
			.Festival {
				actv_id 0 : integer
				base_id 1 : integer
			}
			list 1 : *Festival
			current_list 2 : *Festival
		}
		festival_query 2 : FestivalQuery


		.MygiftQuery{
			list 0 : *MygiftData
		}
		mygift_query 3 : MygiftQuery


		.ActvQuery{
			list 0 : *ActvData
			bind_list 1 : *ActvBindData
		}
		actv_query 4 : ActvQuery


		.ActvAchieveQuery{
			list 1 : *ActvAchieveData
	
			config_day 2 : *ActvAchieveConfig
			config_full 3 : *ActvAchieveConfig
		}
		actv_achieve_query 5 : ActvAchieveQuery


		.ActvMonsterQuery{
			list 1 : *ActvMonsterData
			config_list 2 : *ActvMonsterConfig
		}
		actv_monster_query 6 : ActvMonsterQuery


		.ActvStageQuery{
			list 0 : *ActvStageData
		}
		actv_stage_query 7 : ActvStageQuery


		.ActvRecordQuery {
			list 0 : *ActvRecordData
		}
		actv_record_query 8 : ActvRecordQuery

		.BpOverallQuery {
			pre_session 0 : integer
			heat 1 : integer
		}
		bp_overall_query 9 : BpOverallQuery

		.BpQuery {
			list 0 : *BpData
		}
		bp_query 10 : BpQuery

		
		.BpAchieveQuery {
			list 1 : *BpAchieveData

			bp_id 2 : integer
			day_refresh 3 : integer
			week_refresh 4 : integer
		}
		bp_achieve_query 11 : BpAchieveQuery

		.ActvTurntableQuery {
			list 0 : *ActvTurntableData
		}
		actv_turntable_query 12 : ActvTurntableQuery


		.BackQuery {
			list 0 : *BackData
		}
		back_query 13 : BackQuery

		
		.BackRecordQuery {
			list 0 : *BackRecordData
		}
		back_record_query 14 : BackRecordQuery


		.BackAchieveQuery {
			list 0 : *BackAchieveData
		}
		back_achieve_query 15 : BackAchieveQuery


		.PetFeedQuery{
			list 0 : *PetFeedData
		}
		pet_feed_query 16 : PetFeedQuery


		.CoreQuery{
			list 0 : *CoreData
		}
		core_query 17 : CoreQuery

	}
}


#补发代金券
user_credit_recover 131 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
		amount_100 1 : integer
	}
}







#佣兵初始化
hero_query 201 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
		list 1 : *HeroData
	}
}

#佣兵解雇
hero_dismiss 202 {
	request {
		beat 100 : integer
		
		id 0 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

#佣兵上阵
hero_setpos 203 {
	request {
		beat 100 : integer
		
		.Pos {
			id 0 : integer
			pos 1 : integer
		}
		queue 0 : *Pos
	}
	response {
		err 0 : string
	}
}

#佣兵转职
hero_transfer 204 {
	request {
		beat 100 : integer
		
		id 0 : integer
		enc 1 : integer
	}
	response {
		err 0 : string
	}
}

#设置自动技能开启关闭
hero_auto_skill 205 {
	request {
		beat 100 : integer
		
		id 0 : integer
		is_auto 1 : integer
	}
	response {
		err 0 : string
	}
}

#佣兵技能重置
hero_reborn 206 {
	request {
		beat 100 : integer
		
		id 0 : integer
		enc_list 1 : *integer
	}
	response {
		err 0 : string
	}
}

#设置佣兵名字
hero_set_name 207 {
	request {
		beat 100 : integer
		
		id 0 : integer
		name 1 : string
	}
	response {
		err 0 : string
	}
}

#佣兵洗点预览
hero_wash_preview 208 {
	request {
		beat 100 : integer
		
		id 0 : integer
	}
	response {
		err 0 : string

		hp_seed 1 : integer
		atk_seed 2 : integer
		def_seed 3 : integer
	}
}

#佣兵洗点
hero_wash_confirm 209 {
	request {
		beat 100 : integer
		
		id 0 : integer
	}
	response {
		err 0 : string
	}
}

#佣兵置换
hero_exchange 210 {
	request {
		beat 100 : integer
		
		id_low 0 : integer
		id_high 1 : integer
		enc_list 2 : *integer
	}
	response {
		err 0 : string
	}
}

#重选佣兵性格
hero_set_affix 211 {
	request {
		beat 100 : integer
		
		id 0 : integer
		affix_id 1 : integer
		item_id 2 : integer
	}
	response {
		err 0 : string
	}
}

#佣兵隐藏时装
hero_avatar_hide 212 {
	request {
		beat 100 : integer
		
		id 0 : integer
		pos 1 : integer
	}
	response {
		err 0 : string
	}
}

#尘封系统预选技能
hero_dust_skill 213 {
	request {
		beat 100 : integer
		
		id 0 : integer
		enc_list 1 : *integer
	}
	response {
		err 0 : string
	}
}

#佣兵锁定
hero_lock 214 {
	request {
		beat 100 : integer
		
		hero_id 0 : integer
	}
	response {
		err 0 : string
	}
}

#佣兵升潜能
hero_peak_up 215 {
	request {
		beat 100 : integer
		
		hero_id 0 : integer
	}
	response {
		err 0 : string
	}
}

#佣兵选择perk
hero_perk_select 216 {
	request {
		beat 100 : integer
		
		hero_id 0 : integer
		perk_id 1 : integer
	}
	response {
		err 0 : string
	}
}

#设置魔纹槽颜色
hero_sigil_color 217 {
	request {
		beat 100 : integer
		
		hero_id 0 : integer
		pos 1 : integer
	}
	response {
		err 0 : string
	}
}









#道具初始化
item_query 301 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
		list 1 : *ItemData
	}
}

#使用道具
item_use 302 {
	request {
		beat 100 : integer
		
		item_id 0 : integer
		item_num 1 : integer
		bag_index 2 : integer
		target_id 3 : integer
		params 4 : string
	}
	response {
		err 0 : string
	}
}

#合成道具
item_compose 303 {
	request {
		beat 100 : integer
		
		item_id 0 : integer
		bag_index 1 : integer
		num 2 : integer
	}
	response {
		err 0 : string
		card_list 1 : *CardData
		item_list 2 : *ItemData
	}
}

#合成宝石
item_compose_gem 304 {
	request {
		beat 100 : integer
		
		gem_id 0 : integer
		num 1 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

#道具分解
item_separate 305 {
	request {
		beat 100 : integer
		
		item_id 0 : integer
		bag_index 1 : integer
	}
	response {
		err 0 : string
		item_list 2 : *ItemData
	}
}

#补偿贵重道具
item_drop_check 306 {
	request {
		beat 100 : integer
		
		list 0 : *integer
	}
	response {
		err 0 : string

		list 1 : *integer
	}
}

#选取可选物品
item_choose 307 {
	request {
		beat 100 : integer
		
		item_id 0 : integer
		bag_index 1 : integer
		choose_item 2 : integer
		num 3 : integer
	}
	response {
		err 0 : string
		item_list 2 : *ItemData
	}
}

#仓库使用道具
item_usedrop 308 {
	request {
		beat 100 : integer
		
		item_id 0 : integer
		bag_index 1 : integer
		num 2 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

#合成宠物装备
item_compose_pet_equip 309 {
	request {
		beat 100 : integer
		
		pet_equip_id 0 : integer
		num 1 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}








#装备初始化
equip_query 401 {
	request {
		beat 100 : integer
		start_index 0 : integer
	}
	response {
		err 0 : string
		list 1 : *EquipData
		next_index 2 : integer
	}
}

#装备装上身
equip_on 402 {
	request {
		beat 100 : integer
		
		equip_id 0 : integer
		hero_id 1 : integer
	}
	response {
		err 0 : string
	}
}

#装备卸下
equip_off 403 {
	request {
		beat 100 : integer
		
		equip_id 0 : integer
		bag_index 1 : integer
	}
	response {
		err 0 : string
	}
}

#装备强化
equip_enhance 404 {
	request {
		beat 100 : integer
		
		equip_id 0 : integer
		.MatData {
			type 0 : integer
			item_id 1 : integer
			item_num 2 : integer
			equip_id 3 : integer
		}
		mats 1 : *MatData
	}
	response {
		err 0 : string
		lucky 1 : integer
	}
}

#装备上装卸宝石
equip_gem_onoff 405 {
	request {
		beat 100 : integer
		
		equip_id 0 : integer
		index 1 : integer
		item_id 2 : integer
	}
	response {
		err 0 : string
	}
}

#装备改造
equip_reform 406 {
	request {
		beat 100 : integer
		
		equip_id 0 : integer
		.Pos {
			pos 0 : integer
			index 1 : integer
		}
		locked 1 : *Pos
	}
	response {
		err 0 : string
	}
}

#装备锁定
equip_lock 407 {
	request {
		beat 100 : integer
		
		equip_id 0 : integer
	}
	response {
		err 0 : string
	}
}

#制作套装
equip_forge 408 {
	request {
		beat 100 : integer
		
		base_id 0 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

#装备宝石直接升级
equip_gem_upgrade 409 {
	request {
		beat 100 : integer
		
		equip_id 0 : integer
		index 1 : integer
	}
	response {
		err 0 : string
	}
}

#装备时装外观
equip_show_on 410 {
	request {
		beat 100 : integer
		
		equip_id 0 : integer
		hero_id 1 : integer
	}
	response {
		err 0 : string
	}
}

#卸下时装外观
equip_show_off 411 {
	request {
		beat 100 : integer
		
		equip_id 0 : integer
		bag_index 1 : integer
	}
	response {
		err 0 : string
	}
}

#尘封属性升级
equip_dustup 412 {
	request {
		beat 100 : integer

		equip_id 0 : integer
		dust_index 1 : integer
		
		.MatData {
			base_id 0 : integer
			num 1 : integer
		}
		mats 2 : *MatData
	}
	response {
		err 0 : string
	}
}

#尘封属性突破
equip_dustup_limit 413 {
	request {
		beat 100 : integer
		
		equip_id 0 : integer
		dust_index 1 : integer
	}
	response {
		err 0 : string
	}
}

#尘封属性重铸
equip_dust_remake 414 {
	request {
		beat 100 : integer
		
		equip_id 0 : integer
		lock_arr 1 : *integer
	}
	response {
		err 0 : string
	}
}

#尘封属性替换
equip_dust_replace 415 {
	request {
		beat 100 : integer

		from_equip_id 0 : integer
		from_attr_index 1 : integer
		
		to_equip_id 2 : integer
		to_attr_index 3 : integer
	}
	response {
		err 0 : string
	}
}

#尘封属性置换
equip_dust_displace 416 {
	request {
		beat 100 : integer

		from_equip_id 0 : integer
		from_attr_index 1 : integer
		
		to_equip_id 2 : integer
		to_attr_index 3 : integer
	}
	response {
		err 0 : string
	}
}

#强化属性置换
equip_dust_displace_enhance 417 {
	request {
		beat 100 : integer

		from_equip_id 0 : integer
		to_equip_id 1 : integer
	}
	response {
		err 0 : string
	}
}

#装备洗练预览
equip_dust_refine_preview 418 {
	request {
		beat 100 : integer

		equip_id 0 : integer
	}
	response {
		err 0 : string

		ran 1 : integer
		dust_sp_ran 2 : integer
	}
}

#装备洗练
equip_dust_refine_confirm 419 {
	request {
		beat 100 : integer

		equip_id 0 : integer
	}
	response {
		err 0 : string
	}
}

#荒传套装激活
equip_suit_excellent_open 420 {
	request {
		beat 100 : integer

		equip_id 0 : integer
	}
	response {
		err 0 : string
	}
}






#（失效）
axis_query 501 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
		axis_id 1 : integer
		points 2 : integer
	}
}



#地城初始化
dungeon_query 601 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
		type 1 : integer
		dungeon_id 2 : string
		level 3 : integer
		seed 4 : integer
		quest_id 5 : integer
		quest_seed 6 : integer
		pass_count 7 : integer
		pass_total 8 : integer
		abyss_max_layer 9 : integer
		abyss_max_level 10 : integer
		abyss_seed 11 : integer
		quest_level 12 : integer
		version 13 : string
		mission_id 14 : integer
		quest_db_id 15 : integer
		stage_type 16 : integer
		stage_id 17 : integer

		autopick_time 18 : integer
		
		gap_id 51 : string
		gap_map_seeds 52 : *integer
		gap_events 53 : string
		gap_relic 54 : string
	}
}

#进入地城
dungeon_enter 602 {
	request {
		beat 100 : integer
		
		type 0 : integer
		layer 1 : integer
		quest_id 2 : integer

		speedup 3 : integer
		akasa_level 4 : integer
	}
	response {
		err 0 : string
		type 1 : integer
		dungeon_id 2 : string
		level 3 : integer
		seed 4 : integer
		map_seeds 5 : *integer
		quest_id 6 : integer
		quest_seed 7 : integer
		pass_count 8 : integer
		pass_total 9 : integer
		abyss_seed 10 : integer
		quest_level 11 : integer
		version 12 : string

		mission_id 13 : integer
		quest_db_id 14 : integer
		stage_type 15 : integer
		stage_id 16 : integer
		stage_params 17 : string

		prob_up 18 : *Probup

		speedup 19 : integer

		layer_safe 20 : integer

		mutate_type 21 : integer
		mutate_id 22 : integer
		mutate_time 23 : integer
		akasa_mutate_time 24 : integer
		abyss_layer 25 : integer
		enter_layer 26 : integer

		actv_monster 27 : *ActvMonster

		terrain_type 28 : integer
		terrain_id 29 : integer

		union_buff 30 : *integer

		autopick_curr 41 : integer
		time_used 42 : integer

		session 100 : string
	}
}

#返回地城
dungeon_recover 603 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
		type 1 : integer
		dungeon_id 2 : string
		level 3 : integer
		seed 4 : integer
		map_seeds 5 : *integer
		quest_id 6 : integer
		quest_seed 7 : integer
		pass_count 8 : integer
		pass_total 9 : integer
		events 10 : string
		relic 11 : string
		team_state 12 : string
		shrine 13 : *ShrineData
		abyss_seed 14 : integer
		quest_level 15 : integer
		version 16 : string

		mission_id 17 : integer
		quest_db_id 18 : integer
		stage_type 19 : integer
		stage_id 20 : integer
		stage_params 21 : string

		prob_up 22 : *Probup

		speedup 23 : integer

		layer_safe 24 : integer
		
		mutate_type 25 : integer
		mutate_id 26 : integer
		mutate_time 27 : integer
		akasa_mutate_time 28 : integer

		abyss_layer 29 : integer
		enter_layer 30 : integer

		actv_monster 31 : *ActvMonster

		terrain_type 32 : integer
		terrain_id 33 : integer

		union_buff 34 : *integer

		autopick_curr 41 : integer
		time_used 42 : integer
		
		gap_id 51 : string
		gap_map_seeds 52 : *integer
		gap_events 53 : string
		gap_relic 54 : string

		session 100 : string
	}
}

#更新地城状态
dungeon_state 604 {
	request {
		beat 100 : integer
		
		is_all 0 : integer
		is_top 1 : integer
		state 2 : TeamState
		
		abyss_layer 3 : integer
	}
	response {
		err 0 : string
	}
}

#地城战斗
dungeon_finish_monster 605 {
	request {
		beat 100 : integer
		
		map_index 0 : integer
		event_index 1 : integer
		state 2 : TeamState
		hero_hp_1 3 : integer
		hero_hp_2 4 : integer
		hero_hp_3 5 : integer
		hero_hp_lose_1 6 : integer
		hero_hp_lose_2 7 : integer
		hero_hp_lose_3 8 : integer
		hero_dmg_1 9 : integer
		hero_dmg_2 10 : integer
		hero_dmg_3 11 : integer
		item_used 12 : *ItemUsed
		modao_mp 13 : integer
		hash 14 : string
		redun  15 : string
	}
	response {
		err 0 : string
		pass_count 1 : integer
		relic 2 : *RelicData
		shrine 3 : *ShrineData

		session 100 : string
	}
}

#地城战利品预览
dungeon_get_relic_info 606 {
	request {
		beat 100 : integer
		
		map_index 0 : integer
		event_index 1 : integer
		relic_index 2 : integer
	}
	response {
		err 0 : string

		drop_equips 1 : *InfoEquipData
		drop_items 2 : *InfoItemData
		drop_cards 3 : *InfoCardData
		drop_sigils 4 : *InfoSigilData
	}
}

#地城战利品获取
dungeon_get_relic 607 {
	request {
		beat 100 : integer
		
		map_index 0 : integer
		event_index 1 : integer
		relic_index 2 : integer
		state 3 : TeamState
		bag 4 : *GetBagData
	}
	response {
		err 0 : string

		gap_id 1 : string
		gap_map_seeds 2 : *integer
	}
}

#地城获得神龛buff
dungeon_get_shrine 608 {
	request {
		beat 100 : integer
		
		map_index 0 : integer
		event_index 1 : integer
		state 2 : TeamState

		eventset_index 10 : integer
	}
	response {
		err 0 : string
		pass_count 1 : integer
		shrine 2 : *ShrineData

		eventset_index 10 : integer
	}
}

#地城移除神龛buff
dungeon_shrine_remove 609 {
	request {
		beat 100 : integer
		
		index 0 : string
	}
	response {
		err 0 : string
		shrine 1 : *ShrineData
	}
}

#地城拾取地上道具
dungeon_get_drop_item 610 {
	request {
		beat 100 : integer
		
		map_index 0 : integer
		event_index 1 : integer
		.DropItemData {
			base_id 0 : integer
			num 1 : integer
		}
		items 2 : *DropItemData
	}
	response {
		err 0 : string
	}
}

#地城下一层
dungeon_abyss_next 611 {
	request {
		beat 100 : integer
		
		map_index 0 : integer
		event_index 1 : integer
		layer 2 : integer

		score 3 : integer
	}
	response {
		err 0 : string
		type 1 : integer
		dungeon_id 2 : string
		level 3 : integer
		seed 4 : integer
		map_seeds 5 : *integer
		quest_id 6 : integer
		quest_seed 7 : integer
		pass_count 8 : integer
		pass_total 9 : integer
		shrine 10 : *ShrineData
		abyss_max_layer 11 : integer
		abyss_max_level 12 : integer
		abyss_seed 13 : integer
		quest_level 14 : integer
		version 15 : string

		mission_id 16 : integer
		stage_type 17 : integer
		stage_id 18 : integer
		stage_params 19 : string
		
		prob_up 20 : *Probup

		speedup 21 : integer

		layer_safe 22 : integer
		
		mutate_type 23 : integer
		mutate_id 24 : integer
		mutate_time 25 : integer
		akasa_mutate_time 26 : integer
		abyss_layer 27 : integer
		enter_layer 28 : integer

		actv_monster 29 : *ActvMonster

		terrain_type 30 : integer
		terrain_id 31 : integer

		union_buff 32 : *integer

		session 100 : string
	}
}

#地城返回营地
dungeon_abyss_home 612 {
	request {
		beat 100 : integer
		
		map_index 0 : integer
		event_index 1 : integer
	}
	response {
		err 0 : string

		.Item {
			id 0 : integer
			num 1 : integer
		}
		.Bag {
			type 0 : integer
			id 1 : integer
			num 2 : integer
		}

		reward_resource 1 : *Item
		reward_got 2 : *Bag
		reward_lost 3 : *Bag
		reward_sell 4 : *Item
		reward_sell_reward 5 : *Item
		safe 6 : integer

		hero_dmg_1 16 : integer
		hero_dmg_2 17 : integer
		hero_dmg_3 18 : integer

		time_used 20 : integer
		enter_layer 21 : integer
		enter_max_layer 22 : integer
	}
}

#离开地城
dungeon_exit 613 {
	request {
		beat 100 : integer
		
		safe_type 0 : integer
		score 1 : integer
	}
	response {
		err 0 : string

		.Item {
			id 0 : integer
			num 1 : integer
		}
		.Bag {
			type 0 : integer
			id 1 : integer
			num 2 : integer
		}

		reward_resource 1 : *Item
		reward_got 2 : *Bag
		reward_lost 3 : *Bag
		reward_sell 4 : *Item
		reward_sell_reward 5 : *Item
		safe 6 : integer
		
		hero_dmg_1 16 : integer
		hero_dmg_2 17 : integer
		hero_dmg_3 18 : integer

		time_used 20 : integer
		enter_layer 21 : integer
		enter_max_layer 22 : integer
	}
}

#采集品（道中箱子）预览
dungeon_get_gather_info 614 {
	request {
		beat 100 : integer
		
		map_index 0 : integer
		event_index 1 : integer

		eventset_index 10 : integer
	}
	response {
		err 0 : string

		drop_equips 1 : *InfoEquipData
		drop_items 2 : *InfoItemData
		drop_cards 3 : *InfoCardData
		drop_sigils 4 : *InfoSigilData

		eventset_index 10 : integer
	}
}

#采集品（道中箱子）获取
dungeon_get_gather 615 {
	request {
		beat 100 : integer
		
		map_index 0 : integer
		event_index 1 : integer
		state 2 : TeamState
		bag 3 : *GetBagData

		eventset_index 10 : integer
	}
	response {
		err 0 : string
		items 1 : *ItemData

		eventset_index 10 : integer
	}
}

#完成看板任务
dungeon_finish_quest 616 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

#完成机会事件
dungeon_get_chance 617 {
	request {
		beat 100 : integer
		
		map_index 0 : integer
		event_index 1 : integer
		state 2 : TeamState
		params 3 : string

		hero_hp_1 13 : integer
		hero_hp_2 14 : integer
		hero_hp_3 15 : integer
		hero_hp_lose_1 16 : integer
		hero_hp_lose_2 17 : integer
		hero_hp_lose_3 18 : integer
		hero_dmg_1 19 : integer
		hero_dmg_2 20 : integer
		hero_dmg_3 21 : integer
		item_used 22 : *ItemUsed
		modao_mp 23 : integer

		hash 24 : string

		eventset_index 40 : integer
	}
	response {
		err 0 : string
		result 1 : string
		fin 2 : integer

		rewards 3 : *RewardData

		pass_count 11 : integer
		relic 12 : *RelicData
		shrine 13 : *ShrineData

		drop_items 21 : *ItemData

		info_drop_equips 31 : *InfoEquipData
		info_drop_items 32 : *InfoItemData
		info_drop_cards 33 : *InfoCardData
		info_drop_sigils 34 : *InfoSigilData

		eventset_index 40 : integer

		dungeon_result 50 : DungeonSpotResult


		session 100 : string
	}
}

#（失效）
dungeon_get_hero_temp 618 {
	request {
		beat 100 : integer
		
		map_index 0 : integer
		event_index 1 : integer
		state 2 : TeamState
	}
	response {
		err 0 : string
	}
}

#神秘商人预览
dungeon_get_merchant_info 619 {
	request {
		beat 100 : integer
		
		map_index 0 : integer
		event_index 1 : integer
		state 2 : TeamState
		type 3 : integer
	}
	response {
		err 0 : string

		items 1 : *ShopItem
	}
}

#神秘商人购买
dungeon_get_merchant 620 {
	request {
		beat 100 : integer
		
		map_index 0 : integer
		event_index 1 : integer
		type 2 : integer
		shop_id 3 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
		
		item 2 : ShopItem
	}
}

#检查地城版本（版本变动返回营地）
dungeon_check_version 621 {
	request {
		beat 100 : integer
		
	}
	response {
		is_diff 0 : integer

		.Item {
			id 0 : integer
			num 1 : integer
		}
		.Bag {
			type 0 : integer
			id 1 : integer
			num 2 : integer
		}

		reward_resource 1 : *Item
		reward_got 2 : *Bag
		reward_lost 3 : *Bag
		reward_sell 4 : *Item
		reward_sell_reward 5 : *Item
		safe 6 : integer
	}
}

#挑战事件移除血球
dungeon_remove_blood 622 {
	request {
		beat 100 : integer
		
		map_index 0 : integer
		event_index 1 : integer
	}
	response {
		err 0 : string
		.RelicIndex {
			index 0 : integer
		}
		list 1 : *RelicIndex
	}
}

#装备商店预览
dungeon_get_equip_shop_info 623 {
	request {
		beat 100 : integer
		
		map_index 0 : integer
		event_index 1 : integer
	}
	response {
		err 0 : string
		list 1 : *EquipShop
		best_id 2 : integer
	}
}

#装备商店购买
dungeon_get_equip_shop_buy 624 {
	request {
		beat 100 : integer
		
		map_index 0 : integer
		event_index 1 : integer
		index 2 : integer
		cost_type 3 : integer
		state 4 : TeamState
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
		fin 2 : integer
	}
}

#完成独立关卡
dungeon_finish_stage 625 {
	request {
		beat 100 : integer
		
		score 0 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
		
		time_used 20 : integer
	}
}

#开始钓鱼
dungeon_fishing_start 626 {
	request {
		beat 100 : integer
		
		map_index 0 : integer
		event_index 1 : integer
		bait_id 2 : integer
		bait_index 3 : integer
		rod_id 4 : integer
	}
	response {
		err 0 : string
		fish_id 1 : integer
	}
}

#结束钓鱼
dungeon_fishing_over 627 {
	request {
		beat 100 : integer
		
		map_index 0 : integer
		event_index 1 : integer
		state 2 : TeamState
		succ 3 : integer
	}
	response {
		err 0 : string
		fin 1 : integer
		rewards 2 : *RewardData
		fish_id 3 : integer
		weight 4 : integer
		new_type 5 : integer
		pond_id 6 : integer
	}
}

#使用渔网
dungeon_fishnet 628 {
	request {
		beat 100 : integer
		
		map_index 0 : integer
		event_index 1 : integer
		bait_id 2 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
		fish_id_arr 2 : *integer
		weight_arr 3 : *integer
		new_type_arr 4 : *integer
		pond_id 5 : integer
	}
}

#地城返回营地
dungeon_exit_gap 629 {
	request {
		beat 100 : integer
		
		map_index 0 : integer
		event_index 1 : integer
	}
	response {
		err 0 : string
	}
}

#增加自动拾取时长
dungeon_autopick_add 630 {
	request {
		beat 100 : integer

		num 0 : integer
	}
	response {
		err 0 : string
	}
}

#检查并离开地城
dungeon_check_exit 631 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
	}
}





#（失效）
quest_query 701 {
	request {
		beat 100 : integer
		
	}
	response {
		list 0 : *QuestData
	}
}




#酒馆初始化
tavern_query 801 {
	request {
		beat 100 : integer
		
	}
	response {
		list 0 : *TavernHeroData
		refresh_time 1 : integer
		refresh_count 2 : integer
		refresh_count_time 3 : integer
		count 4 : integer
		target_quality 5 : integer
	}
}

#购买佣兵
tavern_hire 802 {
	request {
		beat 100 : integer
		
		index 0 : integer
		hash 1 : string
	}
	response {
		err 0 : string
		index 1 : integer
		count 2 : integer
		hero_id 3 : integer
	}
}

#酒馆刷新
tavern_refresh 803 {
	request {
		beat 100 : integer
		
		mode 0 : integer
	}
	response {
		err 0 : string
	}
}

#设置酒馆自动刷新目标品质
tavern_target_quality 804 {
	request {
		beat 100 : integer
		
		target_quality 0 : integer
	}
	response {
		err 0 : string
	}
}







#背包初始化
bag_query 901 {
	request {
		beat 100 : integer
		
	}
	response {
		list 0 : *BagData
		amount 1 : integer
	}
}

#整理背包
bag_sort 902 {
	request {
		beat 100 : integer
		
		list 0 : *BagData
	}
	response {
		err 0 : string
	}
}

#丢弃背包物品
bag_remove 903 {
	request {
		beat 100 : integer
		
		index 0 : integer
	}
	response {
		err 0 : string
	}
}



#看板初始化
kanban_query 1001 {
	request {
		beat 100 : integer
		
	}
	response {
		refresh_time 0 : integer
		refresh_count 1 : integer
		refresh_count_time 2 : integer
		level 3 : integer
		points 4 : integer
		act_count 5 : integer
		act_time 6 : integer
		reward_record 7 : integer
		target_reward_time 8 : integer
	}
}

#看板任务刷新
kanban_refresh 1002 {
	request {
		beat 100 : integer
		
		mode 0 : integer
	}
	response {
		err 0 : string
	}
}

#获得看板目标奖励
kanban_get_target_reward 1003 {
	request {
		beat 100 : integer
		
		target_id 0 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}





#建筑初始化
building_query 1101 {
	request {
		beat 100 : integer
		
	}
	response {
		list 0 : *BuildingData
	}
}

#建筑升级
building_levelup 1102 {
	request {
		beat 100 : integer
		
		tag 0 : integer
	}
	response {
		err 0 : string
	}
}

#完成建筑引导
building_guide 1103 {
	request {
		beat 100 : integer
		
		.Data {
			tag 0 : integer
			auto 1 : integer
		}
		tag_arr 0 : *Data
	}
	response {
		err 0 : string
	}
}

#设置建筑插件
building_plus_set 1104 {
	request {
		beat 100 : integer
		
		tag 0 : integer
		index 1 : integer
		item_id 2 : integer
	}
	response {
		err 0 : string
		class_removed 1 : integer
	}
}





#魔晶炉初始化
furnace_query 1201 {
	request {
		beat 100 : integer
		
	}
	response {
		cash 0 : integer
		cash_time 1 : integer
		mine_num 2 : integer
		record_1 3 : integer
		record_2 4 : integer
		record_3 5 : integer
		record_4 6 : integer
		record_5 7 : integer
		record_6 8 : integer
		record_7 9 : integer
		record_8 10 : integer
		record_9 11 : integer
		record_10 12 : integer
	}
}

#魔晶炉激活矿脉
furnace_get_mine 1202 {
	request {
		beat 100 : integer
		
		mine_index 0 : integer
	}
	response {
		err 0 : string
	}
}

#魔晶炉收取金币
furnace_harvest 1203 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
		num 1 : integer
		rewards 2 : *RewardData
	}
}





#营地商店刷新
shop_query 1301 {
	request {
		beat 100 : integer
		
	}
	response {
		refresh_time_1 0 : integer
		refresh_count_1 1 : integer
		refresh_count_time_1 2 : integer
		refresh_time_2 3 : integer
		refresh_count_2 4 : integer
		refresh_count_time_2 5 : integer
		opening_3 6 : integer
	}
}

#获得营地商店列表
shop_list 1302 {
	request {
		beat 100 : integer
		
		type 0 : integer
	}
	response {
		err 0 : string

		items 1 : *ShopItem
	}
}

#刷新营地商店列表
shop_refresh 1303 {
	request {
		beat 100 : integer
		
		type 0 : integer
	}
	response {
		err 0 : string

		items 1 : *ShopItem
	}
}

#营地商店购买
shop_buy_market 1304 {
	request {
		beat 100 : integer
		
		type 0 : integer
		shop_id 1 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData

		item 2 : ShopItem
	}
}

#营地商店出售
shop_sell 1305 {
	request {
		beat 100 : integer
		
		type 0 : integer
		index 1 : integer
		list 2 : *SellData
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}







#魔导技初始化
modao_query 1401 {
	request {
		beat 100 : integer
		
	}
	response {
		.ModaoData {
			base_id 0 : integer
			level 1 : integer
			pos 2 : integer
		}
		list 0 : *ModaoData
	}
}

#魔导技装配
modao_equip 1402 {
	request {
		beat 100 : integer
		
		base_id 0 : integer
		pos 1 : integer
	}
	response {
		err 0 : string
	}
}

#魔导技升级
modao_lvup 1403 {
	request {
		beat 100 : integer
		
		base_id 0 : integer
		current_skill_id 1 : integer
		next_skill_id 2 : integer
	}
	response {
		err 0 : string
	}
}









#怪物卡初始化
card_query 1501 {
	request {
		beat 100 : integer
		start_index 0 : integer
	}
	response {
		list 0 : *CardData
		next_index 1 : integer
	}
}

#怪物卡装配
card_on 1502 {
	request {
		beat 100 : integer
		
		card_id 0 : integer
		hero_id 1 : integer
		pos 2 : integer
	}
	response {
		err 0 : string
	}
}

#怪物卡卸下
card_off 1503 {
	request {
		beat 100 : integer
		
		card_id 0 : integer
		bag_index 1 : integer
	}
	response {
		err 0 : string
	}
}

#怪物卡升级
card_levelup 1504 {
	request {
		beat 100 : integer

		card_id 0 : integer
		
		.MatData {
			id 0 : integer
			bag_index 1 : integer
		}
		mats 1 : *MatData

		.MatItemData {
			base_id 0 : integer
			num 1 : integer
		}
		mats_item 2 : *MatItemData
	}
	response {
		err 0 : string
	}
}

#怪物卡升星
card_starup 1505 {
	request {
		beat 100 : integer
		
		card_id 0 : integer
	}
	response {
		err 0 : string
	}
}

#怪物卡锁定
card_lock 1506 {
	request {
		beat 100 : integer
		
		card_id 0 : integer
	}
	response {
		err 0 : string
	}
}

#怪物卡突破
card_limitup 1507 {
	request {
		beat 100 : integer
		
		card_id 0 : integer
	}
	response {
		err 0 : string
	}
}

#怪物卡成长升级
card_growthup 1508 {
	request {
		beat 100 : integer

		card_id 0 : integer
		
		mat_card_id 1 : integer
		mat_item_id 2 : integer
	}
	response {
		err 0 : string
	}
}

#怪物卡置换
card_exchange 1509 {
	request {
		beat 100 : integer

		card_id_1 0 : integer
		card_id_2 1 : integer
	}
	response {
		err 0 : string
	}
}





#邮件初始化
mail_query 1601 {
	request {
		beat 100 : integer
	}
	response {
		list 0 : *MailData
	}
}

#邮件标记已阅
mail_mark_read 1602 {
	request {
		beat 100 : integer
		
		mail_id 0 : integer
	}
	response {
		err 0 : string
	}
}

#领取邮件奖励
mail_get_award 1603 {
	request {
		beat 100 : integer
		
		id_arr 0 : *integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}







#宠物孵化初始化
pet_hatch_query 1701 {
	request {
		beat 100 : integer
		
	}
	response {
		list 0 : *PetHatchData
	}
}

#宠物孵化开槽
pet_hatch_create 1702 {
	request {
		beat 100 : integer
		
		pos 0 : integer
	}
	response {
		err 0 : string
	}
}

#宠物孵化开始
pet_hatch_put 1703 {
	request {
		beat 100 : integer
		
		pos 0 : integer
		item_id 1 : integer
	}
	response {
		err 0 : string
	}
}

#宠物孵化完成
pet_hatch_born 1704 {
	request {
		beat 100 : integer
		
		pos 0 : integer
		is_acc 1 : integer
	}
	response {
		err 0 : string
		is_born 1 : integer
		id 2 : integer
	}
}


#宠物初始化
pet_query 1801 {
	request {
		beat 100 : integer
		
	}
	response {
		list 0 : *PetData
	}
}

#宠物上阵
pet_setpos 1802 {
	request {
		beat 100 : integer
		
		.Pos {
			id 0 : integer
			pos 1 : integer
		}
		queue 0 : *Pos
	}
	response {
		err 0 : string
	}
}

#宠物喂食
pet_feed 1803 {
	request {
		beat 100 : integer
		
		id 0 : integer
		item_id 1 : integer
		bag_index 2 : integer
	}
	response {
		err 0 : string
	}
}

#宠物解雇
pet_dismiss 1804 {
	request {
		beat 100 : integer
		
		id 0 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

#宠物设置名字
pet_set_name 1805 {
	request {
		beat 100 : integer
		
		id 0 : integer
		name 1 : string
	}
	response {
		err 0 : string
	}
}

#宠物进化
pet_transfer 1806 {
	request {
		beat 100 : integer
		
		id 0 : integer
	}
	response {
		err 0 : string
	}
}

#装上宠物装备
pet_equip_on 1807 {
	request {
		beat 100 : integer
		
		equip_id 0 : integer
		pet_id 1 : integer
	}
	response {
		err 0 : string
	}
}

#卸下宠物装备
pet_equip_off 1808 {
	request {
		beat 100 : integer
		
		equip_id 0 : integer
		pet_id 1 : integer
	}
	response {
		err 0 : string
	}
}

#宠物融合
pet_synth 1809 {
	request {
		beat 100 : integer
		
		id 0 : integer
		synth_id 1 : integer
	}
	response {
		err 0 : string
		
		rewards 1 : *RewardData
	}
}


#宠物置换
pet_exchange 1810 {
	request {
		beat 100 : integer
		
		id_1 0 : integer
		id_2 1 : integer
	}
	response {
		err 0 : string
	}
}

#宠物锁定
pet_lock 1811 {
	request {
		beat 100 : integer
		
		pet_id 0 : integer
	}
	response {
		err 0 : string
	}
}

#宠物升品质
pet_quality_up 1812 {
	request {
		beat 100 : integer
		
		id 0 : integer
	}
	response {
		err 0 : string
	}
}

#宠物批量解雇
pet_sell 1813 {
	request {
		beat 100 : integer
		
		ids 0 : *integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

#宠物升潜能
pet_peak_up 1814 {
	request {
		beat 100 : integer
		
		id 0 : integer
	}
	response {
		err 0 : string
	}
}

#宠物激活天赋
pet_passive_up 1815 {
	request {
		beat 100 : integer
		
		id 0 : integer
	}
	response {
		err 0 : string
	}
}






#引导初始化
guide_query 1901 {
	request {
		beat 100 : integer
		
	}
	response {
		guide_id 0 : integer
		free_1 1 : integer
		free_2 2 : integer
		free_3 3 : integer
		free_4 4 : integer
		free_5 5 : integer
		pet_state 6 : integer
		pet_time 7 : integer
	}
}

#完成一条新手引导
guide_finish 1902 {
	request {
		beat 100 : integer
		
		guide_id 0 : integer
	}
	response {
		err 0 : string
	}
}

#完成一条自由引导
guide_free_finish 1903 {
	request {
		beat 100 : integer
		
		guide_id 0 : integer
	}
	response {
		err 0 : string
	}
}

#获得引导宠物
guide_pet_get 1904 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
		id 1 : integer
	}
}





#快捷道具初始化
quick_slots_query 2001 {
	request {
		beat 100 : integer
		
	}
	response {
		slot_1 0 : integer
		slot_2 1 : integer
		slot_3 2 : integer
		slot_4 3 : integer
		pet_index 4 : integer
		rune_1 5 : integer
		rune_2 6 : integer
		rune_3 7 : integer
		rune_4 8 : integer
	}
}

#快捷道具设置
quick_slots_set 2002 {
	request {
		beat 100 : integer
		
		index 0 : integer
		id 1 : integer
	}
	response {
		err 0 : string
	}
}

#设置首发宠物
quick_slots_set_pet 2003 {
	request {
		beat 100 : integer
		
		index 0 : integer
	}
	response {
		err 0 : string
	}
}

#设置待用符文石
quick_slots_set_rune 2004 {
	request {
		beat 100 : integer
		
		rune_1 0 : integer
		rune_2 1 : integer
		rune_3 2 : integer
		rune_4 3 : integer
	}
	response {
		err 0 : string
	}
}




#采集品初始化
gather_query 2101 {
	request {
		beat 100 : integer
		
	}
	response {
		list 1 : *GatherData
	}
}



#吟游诗人聆听
bard_listen 2201 {
	request {
		beat 100 : integer
		
	}
	response {
		id 0 : integer
		hash 1 : string
		user_id 2 : integer
		type 3 : integer
		likes 4 : integer
		pack 5 : string
		seed 6 : integer
		liked 7 : integer
		like_names 8 : string
	}
}

#吟游诗人点赞
bard_like 2202 {
	request {
		beat 100 : integer
		
		id 0 : integer
		hash 1 : string
	}
	response {
		err 0 : string
	}
}



#付钱初始化
order_query 2301 {
	request {
		beat 100 : integer
		
	}
	response {
		first_1 0 : integer
		first_2 1 : integer
		first_3 2 : integer
		first_4 3 : integer
		first_5 4 : integer
		first_6 5 : integer
		mooncard_day 6 : integer
		mooncard_zuan_day 7 : integer
		seasoncard_day 8 : integer
		total_pay_100 9 : integer
		first_pay_time 10 : integer
		last_pay_time 11 : integer
		daily_order_time 12 : integer
		daily_order_reward_time 13 : integer
		gift_record 14 : integer
		free_gacha_day 15 : integer
		safe_return_used 16 : integer
		safe_return_day 17 : integer
		once_1 18 : integer
		once_2 19 : integer
		once_3 20 : integer
		once_4 21 : integer
		once_5 22 : integer
		once_6 23 : integer
		daily_1 24 : integer
		daily_2 25 : integer
		daily_3 26 : integer
		daily_4 27 : integer
		daily_5 28 : integer
		daily_6 29 : integer
		daily_level 30 : integer
		daily_level_time 31 : integer
	}
}

#付费创建订单
order_create 2302 {
	request {
		beat 100 : integer
		
		goods_id 0 : string
		mygift_id 1 : integer
	}
	response {
		err 0 : string
		order_id 1 : string
	}
}

#付费补单
order_recover 2303 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
		rewards 1 : *RewardData

		.OrderInfo {
			purchase_id 0 : string
			token 1 : string
			goods_id 2 : string
			mygift_id 3 : integer
		}
		order_info 2 : *OrderInfo
	}
}

#月卡进入奖励
order_moon_today 2304 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

#付费累充奖励
order_get_gift 2305 {
	request {
		beat 100 : integer
		
		id 0 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

#领取每日首充奖励
order_get_daily_order_reward 2306 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

#重置每日等级，作为每日特惠的依据
order_daily_level 2307 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
		
		daily_level 30 : integer
		daily_level_time 31 : integer
	}
}

#代币创建-结算订单
order_credit 2308 {
	request {
		beat 100 : integer
		
		goods_id 0 : string
		mygift_id 1 : integer
	}
	response {
		err 0 : string
		order_id 1 : string
	}
}




#主线初始化
mission_query 2401 {
	request {
		beat 100 : integer
		
	}
	response {
		record_1 1 : integer
		record_2 2 : integer
		record_3 3 : integer
		record_4 4 : integer
		record_5 5 : integer
		record_6 6 : integer
		record_7 7 : integer
		record_8 8 : integer
		record_9 9 : integer
		record_10 10 : integer

		record_11 11 : integer
		record_12 12 : integer
		record_13 13 : integer
		record_14 14 : integer
		record_15 15 : integer
		record_16 16 : integer
		record_17 17 : integer
		record_18 18 : integer
		record_19 19 : integer
		record_20 20 : integer

		record_21 21 : integer
		record_22 22 : integer
		record_23 23 : integer
		record_24 24 : integer
		record_25 25 : integer
		record_26 26 : integer
		record_27 27 : integer
		record_28 28 : integer
		record_29 29 : integer
		record_30 30 : integer

		record_31 31 : integer
		record_32 32 : integer
		record_33 33 : integer
		record_34 34 : integer
		record_35 35 : integer
		record_36 36 : integer
		record_37 37 : integer
		record_38 38 : integer
		record_39 39 : integer
		record_40 40 : integer

		record_41 41 : integer
		record_42 42 : integer
		record_43 43 : integer
		record_44 44 : integer
		record_45 45 : integer
		record_46 46 : integer
		record_47 47 : integer
		record_48 48 : integer
		record_49 49 : integer
		record_50 50 : integer

		record_51 51 : integer
		record_52 52 : integer
		record_53 53 : integer
		record_54 54 : integer
		record_55 55 : integer
		record_56 56 : integer
		record_57 57 : integer
		record_58 58 : integer
		record_59 59 : integer
		record_60 60 : integer

		record_61 61 : integer
		record_62 62 : integer
		record_63 63 : integer
		record_64 64 : integer
		record_65 65 : integer
		record_66 66 : integer
		record_67 67 : integer
		record_68 68 : integer
		record_69 69 : integer
		record_70 70 : integer

		record_71 71 : integer
		record_72 72 : integer
		record_73 73 : integer
		record_74 74 : integer
		record_75 75 : integer
		record_76 76 : integer
		record_77 77 : integer
		record_78 78 : integer
		record_79 79 : integer
		record_80 80 : integer

		record_81 81 : integer
		record_82 82 : integer
		record_83 83 : integer
		record_84 84 : integer
		record_85 85 : integer
		record_86 86 : integer
		record_87 87 : integer
		record_88 88 : integer
		record_89 89 : integer
		record_90 90 : integer

		record_91 91 : integer
		record_92 92 : integer
		record_93 93 : integer
		record_94 94 : integer
		record_95 95 : integer
		record_96 96 : integer
		record_97 97 : integer
		record_98 98 : integer
		record_99 99 : integer
		record_100 100 : integer
	}
}

#主线完成
mission_finish 2402 {
	request {
		beat 100 : integer
		
		record_id 0 : integer
	}
	response {
		err 0 : string
	}
}




#npc任务初始化
task_quest_query 2501 {
	request {
		beat 100 : integer
		
	}
	response {
		list 0 : *TaskQuestData
	}
}

#npc任务完成
task_quest_finish 2502 {
	request {
		beat 100 : integer
		
		id 0 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

#npc任务拒绝
task_quest_reject 2503 {
	request {
		beat 100 : integer
		
		id 0 : integer
	}
	response {
		err 0 : string
	}
}





#（失效）
custom_query 2601 {
	request {
		beat 100 : integer
		
	}
	response {
		value 0 : string
	}
}

#（失效）
custom_set 2602 {
	request {
		beat 100 : integer
		
		value 0 : string
	}
	response {
		err 0 : string
	}
}




#调律初始化
mirror_query 2701 {
	request {
		beat 100 : integer
		
	}
	response {
		list 0 : *MirrorData
	}
}

#调律升级
mirror_lvup 2702 {
	request {
		beat 100 : integer
		
		next_id 2 : integer
	}
	response {
		err 0 : string
	}
}



#功能引导初始化
function_query 2801 {
	request {
		beat 100 : integer
		
	}
	response {
		list 0 : *FunctionData
	}
}

#功能引导
function_guide 2802 {
	request {
		beat 100 : integer
		
		.Data {
			tag 0 : integer
		}
		tag_arr 0 : *Data
	}
	response {
		err 0 : string
	}
}



#派遣初始化
travel_query 2901 {
	request {
		beat 100 : integer
		
	}
	response {
		list 0 : *TravelData
		hour_used 1 : integer
		refresh_time 2 : integer
	}
}

#派遣开始
travel_start 2902 {
	request {
		beat 100 : integer
		
		id 0 : integer
		hero_1 1 : integer
		hero_2 2 : integer
		hero_3 3 : integer
		hour_index 4 : integer
	}
	response {
		err 0 : string
	}
}

#派遣完成
travel_stop 2903 {
	request {
		beat 100 : integer
		
		id 0 : integer
		is_fin 1 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
		exp_add 2 : integer
		.HeroEXP {
			exp 0 : integer
			level 1 : integer
		}
		hero_exp 3 : *HeroEXP
	}
}



#竞技场初始化
arena_query 3001 {
	request {
		beat 100 : integer
		
	}
	response {
		season_id 0 : integer
		season_time 1 : integer
		actived 2 : integer

		season 10 : integer
		season_battle 11 : integer
		points 12 : integer
		score 13 : integer
		combo 14 : integer
		combo_season 15 : integer
		battle_index_start 16 : integer
		battle_index_over 17 : integer
		vs_points 18 : integer

		refresh_time 20 : integer
		refresh_count 21 : integer
		refresh_count_time 22 : integer
		battle_count 23 : integer
		battle_time 24 : integer
		reward_already 25 : integer
		reward_time 26 : integer
		week_reward_already 27 : integer
		week_reward_time 28 : integer
		battle_buy_count 29 : integer
		battle_buy_time 30 : integer

		shop_refresh_time 31 : integer

		ranking_level 32 : integer  					# 1,2,3 对应 a,b,c 三个档次的排行榜
		max_ranking_level 33 : integer
	}
}

#竞技场激活
arena_active 3002 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
	}
}

#竞技场检查赛季
arena_check_season 3003 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string

		season 1 : integer
		points 2 : integer
		ranking_level 3 : integer
		
		week_rewards 4 : *RewardData
		week_points 5 : integer
	}
}

#竞技场对手列表
arena_opp_list 3004 {
	request {
		beat 100 : integer
		
		is_refresh 0 : integer
	}
	response {
		err 0 : string
		opp_list 1 : *ArenaOpp
		season 2 : integer
	}
}

#竞技场战斗开始
arena_battle_start 3005 {
	request {
		beat 100 : integer
		
		index 0 : integer
		type 1 : integer
		id 2 : integer
	}
	response {
		err 0 : string
		seed 1 : integer
		attr_level 2 : integer
		teams 3 : *ArenaTeam
	}
}

#竞技场战斗完成
arena_battle_over 3006 {
	request {
		beat 100 : integer
		
		is_win 0 : integer
		skill_record 1 : string
		
		hash 14 : string
	}
	response {
		err 0 : string
		over_index 1 : integer
		rewards 2 : *RewardData
		points 3 : integer
	}
}

#检查竞技场战斗完成
arena_battle_over_check 3007 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
		points 2 : integer
	}
}

#竞技场查看对手信息
arena_look 3008 {
	request {
		beat 100 : integer
		
		type 0 : integer
		id 1 : integer
	}
	response {
		err 0 : string
		team 1 : ArenaTeam
	}
}

#竞技场查看排行榜
arena_ranking 3009 {
	request {
		beat 100 : integer
		
		start_index 0 : integer
	}
	response {
		err 0 : string
		list 1 : *ArenaOpp
	}
}

#（失效）
arena_check_rank 3010 {
	request {
		beat 100 : integer
		
		rank 0 : integer
	}
	response {
		err 0 : string
	}
}

#获得竞技场奖励
arena_get_reward 3011 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

#竞技场回放列表
arena_replay_list 3012 {
	request {
		beat 100 : integer
		
	}
	response {
		list 0 : *ArenaReplayList
	}
}

#竞技场回放播放
arena_replay 3013 {
	request {
		beat 100 : integer
		
		id 0 : integer
	}
	response {
		err 0 : string
		seed 1 : integer
		attr_level 2 : integer
		is_win 3 : integer
		hero_name 4 : string
		copy_1 5 : string
		copy_2 6 : string
		id_1 7 : integer
		id_2 8 : integer
		name_1 9 : string
		name_2 10 : string
		skill_record 11 : string
		time 12 : integer
	}
}

#竞技场购买挑战次数
arena_buy_battle 3014 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
	}
}

#竞技场商店列表
arena_shop_list 3015 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string

		items 1 : *ShopItem
	}
}

#竞技场商店购买
arena_shop_buy 3016 {
	request {
		beat 100 : integer
		
		shop_id 0 : integer
		num 1 : integer
	}
	response {
		err 0 : string

		rewards 1 : *RewardData

		item 2 : ShopItem
	}
}

#获得竞技场周奖励
arena_get_week_reward 3017 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
		points 2 : integer				#领取周奖励时，当时的积分
	}
}

#竞技场排行开始
arena_ranking_start 3018 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string

		amount 1 : integer
		self_rank 2 : integer
		ranking_level 3 : integer  					# 1,2,3 对应 a,b,c 三个档次的排行榜
	}
}

#竞技场战斗确认开始
arena_battle_confirm 3019 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
	}
}

#获得自定义阵容信息
arena_get_formation 3020 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string

		formations 1 : *ArenaFormation
		copy 2 : ArenaFormationCopy
		copy_1 3 : ArenaFormationCopy
		copy_2 4 : ArenaFormationCopy
	}
}

#设置自定义阵容信息
arena_set_formation 3021 {
	request {
		beat 100 : integer

		side 1 : integer
		custom 2 : integer
		
		.HeroData {
			x 0 : integer
			y 1 : integer
			id 2 : integer
		}
		hero 3 : *HeroData
		pet 4 : *integer
	}
	response {
		err 0 : string
		
		copy_1 3 : ArenaFormationCopy
		copy_2 4 : ArenaFormationCopy
	}
}










#成就初始化
achieve_query 3201 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
		list 1 : *AchieveData
	}
}

#获得成就奖励
achieve_get_reward 3202 {
	request {
		beat 100 : integer
		
		id 0 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}


#（失效）
invest_query 3301 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string

		star1 1 : integer
		star2 2 : integer
		star3 3 : integer
		reward1_time 4 : integer
		reward2_time 5 : integer
		reward3_time 6 : integer
		reward1_already 7 : integer
		reward2_already 8 : integer
		reward3_already 9 : integer

		.Record {
			invest_id 0 : integer
			life_left 1 : integer
		}
		record 10 : *Record
	}
}

#（失效）
invest_battle_over 3302 {
	request {
		beat 100 : integer
		
		is_win 0 : integer
		life_left 1 : integer
		invest_id 2 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

#（失效）
invest_get_area_reward 3303 {
	request {
		beat 100 : integer
		
		area_id 0 : integer
		csv_id 1 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}



#签到初始化
record_fest_query 3401 {
	request {
		beat 100 : integer
		
	}
	response {
		.RecordFest {
			type 0 : integer
			start_time 1 : integer
			login_time 2 : integer
			login_days 3 : integer
			reward_record 4 : integer
		}
		list 0 : *RecordFest
	}
}

#签到领取奖励
record_fest_get_reward 3402 {
	request {
		beat 100 : integer
		
		type 0 : integer
		day 1 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}




#商城初始化
paygift_query 3501 {
	request {
		beat 100 : integer
		
	}
	response {
		refresh_time_1 0 : integer
		refresh_time_2 1 : integer
		refresh_time_3 2 : integer

		list 3 : *ShopItem
		
		.OpenData {
			id 0 : integer
			open 1 : integer
		}
		open_list 4 : *OpenData
		open_101_list 5 : *OpenData
	}
}

#商城购买
paygift_buy 3502 {
	request {
		beat 100 : integer
		
		shop_id 0 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}




#点赞初始化
likes_query 3601 {
	request {
		beat 100 : integer
		
	}
	response {
		likes 0 : integer
		likes_offline 1 : integer
		like_time 2 : integer
		like_count 3 : integer
		daily_reward_count 4 : integer
		daily_reward_time 5 : integer
	}
}

#点赞上线补领
likes_harvest 3602 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
		likes_num 1 : integer
	}
}

#点赞每日奖励
likes_daily_reward 3603 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}






#掉落赎回列表
reclaim_get_list 3701 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string

		equips 1 : *InfoEquipData
		cards 2 : *InfoCardData
		sigils 3 : *InfoSigilData
	}
}

#掉落赎回
reclaim_buy 3702 {
	request {
		beat 100 : integer
		
		index 0 : integer
		price 1 : integer
	}
	response {
		err 0 : string
		type 1 : integer
		id 2 : integer
	}
}












#（失效）
td_query 3801 {
	request {
		beat 100 : integer
		
	}
	response {
		hero_1 0 : integer
		hero_2 1 : integer
		hero_3 2 : integer
		hero_4 3 : integer
		hero_5 4 : integer
		hero_6 5 : integer
	}
}

#（失效）
td_update 3802 {
	request {
		beat 100 : integer
		
		hero_1 0 : integer
		hero_2 1 : integer
		hero_3 2 : integer
		hero_4 3 : integer
		hero_5 4 : integer
		hero_6 5 : integer
	}
	response {
		err 0 : string
	}
}

#（失效）
td_finish_stage 3803 {
	request {
		beat 100 : integer
		
		result 0 : integer
		hash 1 : string
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}






#（失效）
abyss_call_query 3901 {
	request {
		beat 100 : integer
		
	}
	response {
		list 0 : *AbyssCallData
	}
}

#（失效）
abyss_call_receive 3902 {
	request {
		beat 100 : integer
		
		list 0 : *integer
	}
	response {
		err 0 : string
	}
}

#（失效）
abyss_call_read 3903 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
	}
}



#农场初始化
farm_query 4001 {
	request {
		beat 100 : integer
		
	}
	response {
		sort_seed 0 : integer
		sort_arr 1 : string
		tile_num 2 : integer
		cash 3 : integer
		cash_time 4 : integer
		speedup_time 5 : integer
		farm_seed 6 : integer

		shop_refresh_time 7 : integer
	}
}

#农场收获
farm_harvest 4002 {
	request {
		beat 100 : integer
		
		amount 0 : integer
		sort_arr 1 : string
		harvest_arr 2 : string
	}
	response {
		err 0 : string
		num 1 : integer
		rewards 2 : *RewardData
	}
}

#农场投入种子
farm_put_seed 4003 {
	request {
		beat 100 : integer
		
		farm_seed 0 : integer
	}
	response {
		err 0 : string
	}
}

#农场商店列表
farm_shop_list 4004 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string

		items 1 : *ShopItem
	}
}

#农场商店购买
farm_shop_buy 4005 {
	request {
		beat 100 : integer
		
		.ShopData {
			shop_id 0 : integer
			num 1 : integer
		}
		shops 0 : *ShopData
	}
	response {
		err 0 : string
		rewards 1 : *RewardData

		items 2 : *ShopItem
	}
}

#农场检查地块
farm_check_tile_num 4006 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
	}
}




#交易所初始化
exchange_query 4101 {
	request {
		beat 100 : integer
		
	}
	response {
		list 0 : *ExchangeData
		appr 1 : string
		stall_name 2 : string
		catalog_select 3 : string
		score 4 : integer
	}
}

#交易所出售
exchange_sell 4102 {
	request {
		beat 100 : integer
		
		sell_index 0 : integer
		item_id 1 : integer
		num 2 : integer
		price 3 : integer
	}
	response {
		err 0 : string
		price 1 : integer
	}
}

#交易所取回
exchange_takeback 4103 {
	request {
		beat 100 : integer
		
		id 0 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

#（失效）
exchange_mark_need 4104 {
	request {
		beat 100 : integer
		
		catalog 0 : integer
	}
	response {
		err 0 : string
	}
}

#交易所查看商品列表
exchange_get_list 4105 {
	request {
		beat 100 : integer
		
		catalog 0 : integer
		start_index 1 : integer
	}
	response {
		err 0 : string
		list 1 : *ExchangeListData
		fin 2 : integer
		end_index 3 : integer
	}
}

#交易所购买
exchange_buy 4106 {
	request {
		beat 100 : integer
		
		type 0 : integer
		id 1 : integer

		item_id 2 : integer
		item_num 3 : integer
		price 4 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData

		item_id 2 : integer
		item_num 3 : integer
		price 4 : integer
	}
}

#交易所装饰
exchange_set_appr 4107 {
	request {
		beat 100 : integer
		
		appr 0 : string
		stall_name 1 : string
	}
	response {
		err 0 : string
	}
}

#交易所检查系统收回
exchange_check_sys 4108 {
	request {
		beat 100 : integer
		
		list 0 : *integer
		stime 1 : integer
	}
	response {
		err 0 : string
	}
}

#交易所获得摊位信息
exchange_get_stalls 4109 {
	request {
		beat 100 : integer
		

	}
	response {
		.StallData {
			user_id 0 : integer
			name 1 : string
			appr 2 : string
			score 3 : integer
			goods 4 : *ExchangeListData
		}

		err 0 : string
		stalls 1 : *StallData
	}
}

#交易所选择商品分类
exchange_select_catalog 4110 {
	request {
		beat 100 : integer
		
		catalog_select 0 : string
	}
	response {
		err 0 : string
	}
}

#交易所获得价格平价
exchange_get_price 4111 {
	request {
		beat 100 : integer
		
	}
	response {
		.PriceData {
			item_id 0 : integer
			price 1 : integer
		}
		price_arr 1 : *PriceData
	}
}

#交易所统计需求
exchange_need 4112 {
	request {
		beat 100 : integer
		
		list 0 : *integer
	}
	response {
		err 0 : string
	}
}

#交易所自检
exchange_test_fake 4113 {
	request {
		beat 100 : integer
		
		list 0 : *integer
		stime 1 : integer
	}
	response {
		err 0 : string
	}
}













#个人邮件初始化
mail_person_query 4201 {
	request {
		beat 100 : integer
		start_index 0 : integer
	}
	response {
		list 0 : *PersonMailData
		next_index 1 : integer
	}
}

#个人邮件标记已阅
mail_person_mark_read 4202 {
	request {
		beat 100 : integer
		
		id 0 : integer
	}
	response {
		err 0 : string
	}
}

#个人邮件领取奖励
mail_person_get_award 4203 {
	request {
		beat 100 : integer
		
		id_arr 0 : *integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}







#章节初始化
chapter_query 4301 {
	request {
		beat 100 : integer
		
	}
	response {
		chapter_id 0 : integer
		max_id 1 : integer
	}
}



#世界关卡初始化
wild_query 4401 {
	request {
		beat 100 : integer
		
	}
	response {
		list 0 : *WildData
	}
}


#世界关卡信息
.DungeonSpotResult {
	type 1 : integer
	dungeon_id 2 : string
	level 3 : integer
	seed 4 : integer
	map_seeds 5 : *integer
	quest_id 6 : integer
	quest_seed 7 : integer
	pass_count 8 : integer
	pass_total 9 : integer
	abyss_seed 10 : integer
	quest_level 11 : integer
	version 12 : string

	mission_id 13 : integer
	quest_db_id 14 : integer
	stage_type 15 : integer
	stage_id 16 : integer
	stage_params 17 : string

	prob_up 18 : *Probup

	speedup 19 : integer

	layer_safe 20 : integer
		
	mutate_type 21 : integer
	mutate_id 22 : integer
	mutate_time 23 : integer
	akasa_mutate_time 24 : integer
	abyss_layer 25 : integer
	enter_layer 26 : integer

	actv_monster 27 : *ActvMonster

	terrain_type 28 : integer
	terrain_id 29 : integer
	
	shrine 31 : *ShrineData

	union_buff 32 : *integer

	autopick_curr 41 : integer
	time_used 42 : integer

	session 100 : string
}

#（失效）
.TdSpotBattle {
	td_id 0 : string
	stage_type 1 : integer
	stage_id 2 : integer

	session 100 : string
}

#世界关卡战斗
wild_spot_battle 4402 {
	request {
		beat 100 : integer
		
		spot_id 0 : integer
		star_id 1 : integer
	}
	response {
		err 0 : string
		type 1 : integer

		dungeon_result 2 : DungeonSpotResult
		td_result 3 : TdSpotBattle

	}
}

#检查资源自增长
wild_check_growth 4403 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
	}
}




#抽卡初始化
gacha_query 4501 {
	request {
		beat 100 : integer
		
	}
	response {
		shop_refresh_time 0 : integer
		.ScoreData {
			group 0 : integer
			score 1 : integer
		}
		score_group 1 : *ScoreData

		.OpenData {
			id 0 : integer
			open 1 : integer
		}
		list 2 : *OpenData
		shop_list 3 : *OpenData
	}
}

#抽卡
gacha_gacha 4502 {
	request {
		beat 100 : integer
		
		id 0 : integer
		cost_type 1 : integer
	}
	response {
		err 0 : string
		goods 1 : *RewardData
		converts 2 : *RewardData
		heros 3 : *integer
	}
}

#抽卡商店列表
gacha_shop_list 4503 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string

		items 1 : *ShopItem
	}
}

#抽卡商店购买
gacha_shop_buy 4504 {
	request {
		beat 100 : integer
		
		shop_id 0 : integer
		num 1 : integer
	}
	response {
		err 0 : string

		rewards 1 : *RewardData

		item 2 : ShopItem
	}
}




#怪物图鉴初始化
manual_monster_query 4601 {
	request {
		beat 100 : integer
		
	}
	response {
		list 0 : *ManualMonsterData
	}
}

#怪物图鉴发现
manual_monster_meet 4602 {
	request {
		beat 100 : integer
		
		id 0 : integer
		affix_arr 1 : string
	}
	response {
		err 0 : string
		is_new 1 : integer
	}
}

#怪物图鉴标记
manual_monster_mark 4603 {
	request {
		beat 100 : integer
		
		id_arr 0 : *integer
	}
	response {
		err 0 : string
	}
}



#钓鱼初始化
fishing_query 4701 {
	request {
		beat 100 : integer
		
	}
	response {
		shop_refresh_time 0 : integer
		rod_id 1 : integer
		list 2 : *FishingData
		ponds 3 : *FishingPondData
	}
}

#进入钓鱼点
fishing_enter_spot 4702 {
	request {
		beat 100 : integer
		
		spot_id 0 : integer
	}
	response {
		err 0 : string

		dungeon_result 1 : DungeonSpotResult

	}
}

#钓鱼商店列表
fishing_shop_list 4703 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string

		items 1 : *ShopItem
	}
}

#钓鱼商店购买
fishing_shop_buy 4704 {
	request {
		beat 100 : integer
		
		shop_id 0 : integer
		num 1 : integer
	}
	response {
		err 0 : string

		rewards 1 : *RewardData

		item 2 : ShopItem
	}
}

#钓鱼记录
fishing_get_record 4705 {
	request {
		beat 100 : integer
		
		fish_id 0 : integer
	}
	response {
		err 0 : string
		weight 1 : integer
		user_id 2 : integer
		user_name 3 : string
		user_count 4 : integer
	}
}

#钓鱼选择鱼竿
fishing_set_rod 4706 {
	request {
		beat 100 : integer
		
		rod_id 1 : integer
	}
	response {
		err 0 : string
	}
}






#轮回奖励初始化
abyss_gift_query 4801 {
	request {
		beat 100 : integer
		
	}
	response {
		progress 0 : integer
		reward_time 1 : integer
		shop_refresh_time 2 : integer
	}
}

#轮回奖励获得
abyss_gift_get_reward 4802 {
	request {
		beat 100 : integer
		
		id 0 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

#轮回商店列表
abyss_gift_shop_list 4803 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string

		items 1 : *ShopItem
	}
}

#轮回商店购买
abyss_gift_shop_buy 4804 {
	request {
		beat 100 : integer
		
		shop_id 0 : integer
		num 1 : integer
	}
	response {
		err 0 : string

		rewards 1 : *RewardData

		item 2 : ShopItem
	}
}








#通用排行榜初始化
ranking_query 4901 {
	request {
		beat 100 : integer
		
	}
	response {
		list 0 : *RankingData
	}
}

#通用排行榜列表
ranking_ranking 4902 {
	request {
		beat 100 : integer
		
		type 0 : integer
		start_index 1 : integer
	}
	response {
		err 0 : string
		list 1 : *StdRanking
	}
}

#活动副本排行榜开始
ranking_ranking_start 4903 {
	request {
		beat 100 : integer
		
		type 0 : integer
	}
	response {
		err 0 : string

		amount 1 : integer
		self_rank 2 : integer
		self_points 3 : integer
		self_season 4 : integer
		season_data 5 : RankingSeasonData
	}
}





#消费开启初始化
consume_query 5001 {
	request {
		beat 100 : integer
		
	}
	response {
		bag_unlock 0 : integer
		armory_unlock 1 : integer
	}
}

#消费开背包
consume_bag_unlock 5002 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
	}
}

#消费开装备库
consume_armory_unlock 5003 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
	}
}



#个人变量初始化
vars_query 5101 {
	request {
		beat 100 : integer
		
	}
	response {
		language 0 : string
		scene 1 : integer
		ignore_record 2 : string
		autolock 3 : integer
		nodrop_saved 4 : integer
	}
}

#设置个人变量
vars_set 5102 {
	request {
		beat 100 : integer
		
		language 0 : string
		scene 1 : integer
		autolock 3 : integer
		nodrop_saved 4 : integer
	}
	response {
		err 0 : string
	}
}

#设置7日不弹
vars_set_ignore 5103 {
	request {
		beat 100 : integer
		
		index 0 : integer
	}
	response {
		err 0 : string

		time 1 : integer
	}
}





#月签到初始化
record_month_query 5201 {
	request {
		beat 100 : integer
		
	}
	response {
		turn 0 : integer
		login_time 1 : integer
		login_days 2 : integer
		reward_record 3 : integer
		reward_time 4 : integer
	}
}

#月签到获得奖励
record_month_get_reward 5202 {
	request {
		beat 100 : integer
		
		day 0 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

#月签到下一轮
record_month_next_turn 5203 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
	}
}




#武器幻化初始化
illusion_query 5301 {
	request {
		beat 100 : integer
		
	}
	response {
		list 0 : *integer
	}
}

#武器幻化
illusion_do 5302 {
	request {
		beat 100 : integer
		
		equip_id 0 : integer
		illusion_id 1 : integer
	}
	response {
		err 0 : string
	}
}



#节日活动初始化
festival_query 5401 {
	request {
		beat 100 : integer
	}
	response {
		.Festival {
			actv_id 0 : integer
			base_id 1 : integer
		}
		list 1 : *Festival
		current_list 2 : *Festival
	}
}

#节日活动商店列表
festival_shop_list 5402 {
	request {
		beat 100 : integer
		
		actv_id 10 : integer
	}
	response {
		err 0 : string

		items 1 : *ShopItem
	}
}

#节日活动商店购买
festival_shop_buy 5403 {
	request {
		beat 100 : integer
		
		shop_id 0 : integer
		num 1 : integer
		
		actv_id 10 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData

		item 2 : ShopItem
	}
}

#使用节日物品
festival_item_use 5404 {
	request {
		beat 100 : integer
		
		item_index 0 : integer
		item_id 1 : integer
		num 2 : integer
	}
	response {
		err 0 : string
		
		rewards 1 : *RewardData
	}
}

#使用节日物品结束
festival_item_use_over 5405 {
	request {
		beat 100 : integer
		
		item_id 0 : integer
	}
	response {
		err 0 : string
	}
}







#概率提升初始化
probup_query 5501 {
	request {
		beat 100 : integer
		
	}
	response {
		list 0 : *ProbupData
	}
}



#累充初始化
charge_query 5601 {
	request {
		beat 100 : integer
		
	}
	response {
		list 0 : *ChargeData
	}
}

#累充获得奖励
charge_get_gift 5602 {
	request {
		beat 100 : integer
		
		actv_id 0 : integer
		index 1 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

#累充补单奖励
charge_gift_recover 5603 {
	request {
		beat 100 : integer
		
		actv_id 0 : integer
		index_arr 1 : *integer
	}
	response {
		err 0 : string
	}
}



#篝火初始化
campfire_query 5701 {
	request {
		beat 100 : integer
		
	}
	response {
		season_id 0 : integer
		season_time 1 : integer
		base_id 2 : integer

		season 10 : integer
		score 11 : integer
		exp_times 12 : integer
		exp_time 13 : integer 
	}
}

#检查篝火赛季
campfire_check_season 5702 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
		campfire_id 1 : integer
		campfire_level 2 : integer
		personal_score 3 : integer
	}
}

#篝火投入薪柴
campfire_add_wood 5703 {
	request {
		beat 100 : integer
		
		wood_id 0 : integer
		num 1 : integer
	}
	response {
		err 0 : string
		is_new 1 : integer
	}
}

#获得篝火信息
campfire_get_info 5704 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string

		base_id 1 : integer
		score 2 : integer
		score_total 3 : integer
		level 4 : integer
		exp_level 5 : integer
		user_num 6 : integer
	}
}

#篝火领取经验值
campfire_get_exp 5705 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
	}
}








#加入聊天频道
chat_join 5801 {
	request {
		beat 100 : integer
		
		start_index 0 : integer 				#聊天的内容的起始idx
		chat_channel 1 : integer				#要加入哪个聊天频道(CommonDefine.CHAT_CHANNEL), 不填：默认世界频道 
	}
	response {
		err 0 : string
		
		list 1 : *ChatData
	}
}

#离开聊天频道
chat_exit 5802 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
	}
}

#聊天获得玩家名片
chat_get_user_info 5803 {
	request {
		beat 100 : integer

		user_id 0 : integer
	}
	response {
		err 0 : string

		user_id 1 : integer
		nickname 2 : string
		nicklang 3 : string
		head 4 : integer
		head_frame 5 : integer
		likes 6 : integer

		medal_arr 11 : *integer
		fish_arr 12 : *string
		hero_arr 13 : *string
		pet_arr 14 : *string

		arena_points 21 : integer
		arena_ranking_level 22 : integer

		home_map_id 30 : integer
		home_is_public 31 : integer

		union_id 40 : integer
		union_name 41 : string
		union_lang 42 : string
	}
}

#聊天设置玩家名片
chat_set_user_show 5804 {
	request {
		beat 100 : integer

		type 0 : integer
		index 1 : integer
		id 2 : integer
	}
	response {
		err 0 : string
	}
}

#聊天获得装备信息
chat_get_equip_info 5805 {
	request {
		beat 100 : integer

		user_id 0 : integer
		id 1 : integer
	}
	response {
		err 0 : string

		data 1 : EquipData
	}
}

#聊天获得怪物卡信息
chat_get_card_info 5806 {
	request {
		beat 100 : integer

		user_id 0 : integer
		id 1 : integer
	}
	response {
		err 0 : string

		data 1 : CardData
	}
}

#聊天获得佣兵信息
chat_get_hero_info 5807 {
	request {
		beat 100 : integer

		user_id 0 : integer
		id 1 : integer
	}
	response {
		err 0 : string

		data 1 : HeroData
		equips 2 : *EquipData
		cards 3 : *CardData
		sigils 4 : *SigilData
		artifact 5 : ArtifactData
	}
}

#聊天获得宠物信息
chat_get_pet_info 5808 {
	request {
		beat 100 : integer

		user_id 0 : integer
		id 1 : integer
	}
	response {
		err 0 : string

		data 1 : PetData
	}
}

#聊天获得切磋回放
chat_get_battle_replay 5809 {
	request {
		beat 100 : integer

		index 0 : integer
		id 1 : integer
	}
	response {
		err 0 : string

		seed 1 : integer
		attr_level 2 : integer
		teams 3 : *ArenaTeam
		skill_record 4 : string
	}
}

#聊天发言
chat_add_msg 5811 {
	request {
		beat 100 : integer
		
		msg 0 : string
		lang 10 : string
		channel 11: integer		# 参见 CommonDefine.CHAT_CHANNEL
	}
	response {
		err 0 : string

		masked_msg 1 : string
	}
}

#聊天发佣兵
chat_add_hero 5812 {
	request {
		beat 100 : integer
		
		id 0 : integer
		pack 1 : string
		lang 10 : string
		channel 11: integer		# 参见 CommonDefine.CHAT_CHANNEL
	}
	response {
		err 0 : string
	}
}

#聊天发宠物
chat_add_pet 5813 {
	request {
		beat 100 : integer
		
		id 0 : integer
		pack 1 : string
		lang 10 : string
		channel 11: integer		# 参见 CommonDefine.CHAT_CHANNEL
	}
	response {
		err 0 : string
	}
}

#聊天发装备
chat_add_equip 5814 {
	request {
		beat 100 : integer
		
		id 0 : integer
		pack 1 : string
		lang 10 : string
		channel 11: integer		# 参见 CommonDefine.CHAT_CHANNEL
	}
	response {
		err 0 : string
	}
}

#聊天发怪物卡
chat_add_card 5815 {
	request {
		beat 100 : integer
		
		id 0 : integer
		pack 1 : string
		lang 10 : string
		channel 11: integer		# 参见 CommonDefine.CHAT_CHANNEL
	}
	response {
		err 0 : string
	}
}

#聊天发表情
chat_add_emoji 5816 {
	request {
		beat 100 : integer

		id 0 : integer
		channel 11: integer		# 参见 CommonDefine.CHAT_CHANNEL
	}
	response {
		err 0 : string
	}
}

#聊天邀请切磋
chat_add_battle 5817 {
	request {
		beat 100 : integer
		channel 0 : integer		# 参见 CommonDefine.CHAT_CHANNEL
	}
	response {
		err 0 : string
	}
}

#聊天切磋开始
chat_battle_start 5818 {
	request {
		beat 100 : integer

		index 0 : integer
		channel 1 : integer		# 参见 CommonDefine.CHAT_CHANNEL
	}
	response {
		err 0 : string
		seed 1 : integer
		attr_level 2 : integer
		teams 3 : *ArenaTeam
	}
}

#聊天切磋结束
chat_battle_over 5819 {
	request {
		beat 100 : integer
		
		is_win 0 : integer
		skill_record 1 : string
		lang 10 : string
	}
	response {
		err 0 : string
	}
}

#聊天切磋点赞
chat_battle_like 5820 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
	}
}

#（失效）
chat_add_song 5821 {
	request {
		beat 100 : integer

		id 0 : integer
	}
	response {
		err 0 : string
	}
}

#聊天发联机副本邀请
chat_add_tower_room 5822 {
	request {
		beat 100 : integer

		room_id 0 : integer
		inst_id 1 : integer
		channel 10 : integer      # 参见 CommonDefine.CHAT_CHANNEL
	}
	response {
		err 0 : string
	}
}

#聊天黑名单 列表
chat_query 5823 {
	request {
		beat 100 : integer
	}
	response {
		
		blacklist 0 : *BlackUserInfo
	}
}

# 黑名单（加入、删除）
chat_blacklist_add_or_del 5824 {
	request {
		beat 100 : integer
		user_id 0 : integer
		operate 1 : integer			# 1:加入 2:移除
	}
	response {
		err 0 : string
		user_id 1 : integer
		operate 2 : integer				# 1:加入 2:移除
		user_info 3 : BlackUserInfo		# operate为1时, 才有值
	}
}




#联机副本初始化
tower_query 5901 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
		list 1 : *TowerData
	}
}

#联机副本进入房间
tower_enter_room 5902 {
	request {
		beat 100 : integer
		
		room_id 0 : string
		inst_id 1 : integer

		is_private 2 : integer
	}
	response {
		err 0 : string
		inst_id 1 : integer
		is_private 2 : integer
	}
}

#进入联机副本界面
tower_enter_ui 5903 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string

		.RoomData {
			id 0 : integer
			name 1 : string
			room_id 2 : integer
			nickname 3 : string
			nicklang 4 : string
			count 5 : integer
			time 6 : integer
		}
		room_list 1 : *RoomData
	}
}

#离开联机副本界面
tower_leave_ui 5904 {
	request {
		beat 100 : integer

	}
	response {
		err 0 : string
	}
}








#战令初始化
abyss_pass_query 6001 {
	request {
		beat 100 : integer
		
	}
	response {
		free_record_1 1 : integer
		free_record_2 2 : integer
		free_record_3 3 : integer
		free_record_4 4 : integer
		free_record_5 5 : integer
		free_record_6 6 : integer
		free_record_7 7 : integer
		free_record_8 8 : integer
		free_record_9 9 : integer
		free_record_10 10 : integer
		free_record_11 11 : integer
		free_record_12 12 : integer
		free_record_13 13 : integer
		free_record_14 14 : integer
		free_record_15 15 : integer
		free_record_16 16 : integer
		free_record_17 17 : integer
		free_record_18 18 : integer
		free_record_19 19 : integer
		free_record_20 20 : integer

		pay_record_1 21 : integer
		pay_record_2 22 : integer
		pay_record_3 23 : integer
		pay_record_4 24 : integer
		pay_record_5 25 : integer
		pay_record_6 26 : integer
		pay_record_7 27 : integer
		pay_record_8 28 : integer
		pay_record_9 29 : integer
		pay_record_10 30 : integer
		pay_record_11 31 : integer
		pay_record_12 32 : integer
		pay_record_13 33 : integer
		pay_record_14 34 : integer
		pay_record_15 35 : integer
		pay_record_16 36 : integer
		pay_record_17 37 : integer
		pay_record_18 38 : integer
		pay_record_19 39 : integer
		pay_record_20 40 : integer

		paid_1 41 : integer
		paid_2 42 : integer
		paid_3 43 : integer
		paid_4 44 : integer
		paid_5 45 : integer
		paid_6 46 : integer
		paid_7 47 : integer
		paid_8 48 : integer
		paid_9 49 : integer
		paid_10 50 : integer
	}
}

#战令获得奖励
abyss_pass_get_reward 6002 {
	request {
		beat 100 : integer
		
		id 0 : integer
		is_pay 1 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

#获得全部战令奖励
abyss_pass_get_reward_all 6003 {
	request {
		beat 100 : integer

		.RewardData {
			id 0 : integer
			is_pay 1 : integer
		}
		list 1 : *RewardData
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}


#sp佣兵初始化
hero_sp_query 6101 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string

		.HeroSpData {
			base_id 0 : integer
			story_id 1 : integer
		}
		list 1 : *HeroSpData
	}
}

#sp佣兵传记副本
hero_sp_story 6102 {
	request {
		beat 100 : integer
		
		hero_id 0 : integer
		story_id 1 : integer
	}
	response {
		err 0 : string
		
		dungeon_result 1 : DungeonSpotResult
	}
}

#获得sp佣兵奖励
hero_sp_reward 6103 {
	request {
		beat 100 : integer
		
		hero_id 0 : integer
		story_id 1 : integer
	}
	response {
		err 0 : string

		rewards 1 : *RewardData
	}
}



#故事书初始化
book_query 6201 {
	request {
		beat 100 : integer
		
	}
	response {
		.BookData {
			base_id 0 : integer
			create_time 1 : integer
			update_time 2 : integer
			reward_already 3 : integer
			seed 4 : integer
			read_count 5 : integer
			record_1 11 : integer
			record_2 12 : integer
			record_3 13 : integer
			record_4 14 : integer
		}

		list 1 : *BookData
	}
}

#领取故事书奖励
book_get_reward 6202 {
	request {
		beat 100 : integer
		
		base_id 0 : integer
	}
	response {
		err 0 : string

		rewards 1 : *RewardData
	}
}

#故事书阅读
book_read 6203 {
	request {
		beat 100 : integer
		
		base_id 0 : integer
		read_count 1 : integer
	}
	response {
		err 0 : string
	}
}







#浅层深渊奖励初始化
abyss_reward_query 6301 {
	request {
		beat 100 : integer
		
	}
	response {
		already_id 1 : integer
		area_id 2 : integer
	}
}

#浅层深渊奖励获得
abyss_reward_get_reward 6302 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
		exp 2 : integer
	}
}

#浅层深渊奖励开启领域
abyss_reward_open_area 6303 {
	request {
		beat 100 : integer

		area_id 0 : integer
	}
	response {
		err 0 : string
	}
}





#地城商人初始化
item_shop_query 6401 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
		list 1 : *ItemShop
	}
}




#玛露卡初始化
maruka_query 6501 {
	request {
		beat 100 : integer
		
	}
	response {
		reward_time_1 0 : integer
	}
}

#领取玛露卡每日奖励
maruka_get_reward 6502 {
	request {
		beat 100 : integer

		id 0 : integer
	}
	response {
		err 0 : string

		rewards 1 : *RewardData
	}
}


#玩家展示初始化
user_show_query 6601 {
	request {
		beat 100 : integer
		
	}
	response {
		.UserShowData {
			type 0 : integer
			index 1 : integer
			id 2 : integer
		}
		list 1 : *UserShowData
	}
}

#设置玩家展示
user_show_set 6602 {
	request {
		beat 100 : integer

		type 0 : integer
		index 1 : integer
		id 2 : integer
	}
	response {
		err 0 : string
	}
}




#永劫副本初始化
naraka_query 6701 {
	request {
		beat 100 : integer
		
	}
	response {
		reward_count 0 : integer
		reward_time 1 : integer
		mode_arr 2 : string

		shop_refresh_time 10 : integer
	}
}

#进入永劫副本
naraka_stage 6702 {
	request {
		beat 100 : integer
		
		stage_id 0 : integer
	}
	response {
		err 0 : string
		
		dungeon_result 1 : DungeonSpotResult
	}
}

#永劫商店列表
naraka_shop_list 6703 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string

		items 1 : *ShopItem
	}
}

#永劫商店购买
naraka_shop_buy 6704 {
	request {
		beat 100 : integer
		
		shop_id 0 : integer
		num 1 : integer
	}
	response {
		err 0 : string

		rewards 1 : *RewardData

		item 2 : ShopItem
	}
}



#图鉴奖励初始化
manual_reward_query 6801 {
	request {
		beat 100 : integer
		
	}
	response {
		record_1 0 : integer
		record_2 1 : integer
	}
}

#图鉴奖励领取
manual_reward_get_reward 6802 {
	request {
		beat 100 : integer
		
		id 0 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}




#家园初始化
home_query 6901 {
	request {
		beat 100 : integer
		
	}
	response {
		map_id 0 : integer
		is_public 1 : integer
		visiting_user 2 : integer

		shop_refresh_time 10 : integer
	}
}

#进入自己家园
home_enter 6902 {
	request {
		beat 100 : integer
		
		item_id 0 : integer
	}
	response {
		err 0 : string

		data 1 : HomeData
	}
}

#家园访问
home_visit 6903 {
	request {
		beat 100 : integer
		
		user_id 0 : integer
	}
	response {
		err 0 : string

		data 1 : HomeData
		feed_arr 2 : *PetFeedHome
	}
}

#家园装饰保存
home_device_save 6904 {
	request {
		beat 100 : integer
		
		device_str 0 : string
	}
	response {
		err 0 : string
	}
}

#家园设置地契
home_set_map 6905 {
	request {
		beat 100 : integer
		
		item_id 0 : integer
	}
	response {
		err 0 : string
	}
}

#家园设置是否公开
home_set_public 6906 {
	request {
		beat 100 : integer
		
		is_public 0 : integer
	}
	response {
		err 0 : string
	}
}

#家园获得小费
home_get_tips 6907 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string

		rewards 1 : *RewardData
	}
}

#减员访客
home_check_visitor 6908 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string

		last_visit_time 1 : integer
		visit_get_time 2 : integer
	}
}

#家园获得访客列表
home_get_visitors 6909 {
	request {
		beat 100 : integer
		
		user_id 0 : integer
	}
	response {
		err 0 : string

		.VisitorData {
			time 0 : integer
			visitor_id 1 : integer
			nickname 2 : string
			nicklang 3 : string
			head 4 : integer
			head_frame 5 : integer
		}
		list 1 : *VisitorData
	}
}

#家园音乐保存
home_music_save 6910 {
	request {
		beat 100 : integer
		
		music_str 0 : string
	}
	response {
		err 0 : string
	}
}

#家园商店列表
home_shop_list 6920 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string

		items 1 : *ShopItem
	}
}

#家园商店购买
home_shop_buy 6921 {
	request {
		beat 100 : integer
		
		shop_id 0 : integer
		num 1 : integer
	}
	response {
		err 0 : string

		rewards 1 : *RewardData

		item 2 : ShopItem
	}
}

#家园工坊商店列表
home_craft_shop_list 6922 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string

		items 1 : *ShopItem
	}
}

#家园工坊商店购买
home_craft_shop_buy 6923 {
	request {
		beat 100 : integer
		
		shop_id 0 : integer
		num 1 : integer
	}
	response {
		err 0 : string

		item 1 : ShopItem
		delay_item_id 2 : integer
	}
}

#家园工坊商店列表（访客）
home_craft_visit_list 6924 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string

		items 1 : *ShopItem
	}
}

#家园工坊商店购买（访客）
home_craft_visit_buy 6925 {
	request {
		beat 100 : integer
		
		shop_id 0 : integer
		num 1 : integer
	}
	response {
		err 0 : string

		item 1 : ShopItem
		delay_item_id 2 : integer
	}
}

#家园炼金商店列表
home_alchemy_shop_list 6926 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string

		items 1 : *ShopItem
	}
}

#家园炼金商店购买
home_alchemy_shop_buy 6927 {
	request {
		beat 100 : integer
		
		shop_id 0 : integer
		num 1 : integer
	}
	response {
		err 0 : string

		item 1 : ShopItem
		delay_item_id 2 : integer
	}
}

#家园炼金商店列表（访客）
home_alchemy_visit_list 6928 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string

		items 1 : *ShopItem
	}
}

#家园炼金商店购买（访客）
home_alchemy_visit_buy 6929 {
	request {
		beat 100 : integer
		
		shop_id 0 : integer
		num 1 : integer
	}
	response {
		err 0 : string

		item 1 : ShopItem
		delay_item_id 2 : integer
	}
}

#家园工坊列表
home_workshop_shop_list 6930 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string

		items 1 : *ShopItem
	}
}

#家园工坊购买
home_workshop_shop_buy 6931 {
	request {
		beat 100 : integer
		
		shop_id 0 : integer
		num 1 : integer
	}
	response {
		err 0 : string

		item 1 : ShopItem
		delay_item_id 2 : integer
	}
}








#道具制作初始化
delay_item_query 7001 {
	request {
		beat 100 : integer
		
	}
	response {
		.DelayItemData {
			id 0 : integer
			type 1 : integer
			start_time 2 : integer
			end_time 3 : integer
			item_id 4 : integer
			item_num 5 : integer
		}
		list 0 : *DelayItemData
	}
}

#道具制作列表
delay_item_get 7002 {
	request {
		beat 100 : integer
		
		id 0 : integer
	}
	response {
		err 0 : string

		rewards 1 : *RewardData
	}
}

#道具制作取消
delay_item_cancel 7003 {
	request {
		beat 100 : integer
		
		id 0 : integer
	}
	response {
		err 0 : string

		rewards 1 : *RewardData
	}
}







#客服初始化
service_query 7101 {
	request {
		beat 100 : integer

	}
	response {
		.SnsData {
			id 0 : integer
			sns_id 1 : integer
			text 2 : string
			url 3 : string
		}
		sns_list 0 : *SnsData

		.FeedbackData {
			id 0 : integer
			text 1 : string
			reply 2 : string
			is_read 3 : integer
		}
		feedback_list 1 : *FeedbackData

		review_reward 2 : integer
	}
}

#客服反馈
service_feedback 7102 {
	request {
		beat 100 : integer
		
		text 0 : string
	}
	response {
		err 0 : string
	}
}

#客服反馈已阅
service_feedback_read 7103 {
	request {
		beat 100 : integer
		
		id_arr 0 : *integer
	}
	response {
		err 0 : string
	}
}

#聊天举报
service_report 7104 {
	request {
		beat 100 : integer
		
		text 0 : string
		user_id 1 : integer
		nickname 2 : string
		hash 3 : string
		data_json 4 : string
	}
	response {
		err 0 : string
	}
}

#作弊举报 检查
service_report_cheating_precheck 7105 {
	request {
		beat 100 : integer
		user_id 0 : integer
	}
	response {
		err 0 : string
		check_result 1 : integer				# 检查结果 1：确实存在作弊，可以举报   0：该玩家数据没有问题，不需要举报
		token 2 : string						# 提交举报的token
	}
}

# 提交举报
service_report_cheating_submit 7106 {
	request {
		beat 100 : integer
		user_id 0 : integer
		token 1 : string
		content 2 : string
	}
	
	response {
		err 0 : string
	}
}

# 好评奖励
service_review_reward 7107 {
	request {
		beat 100 : integer
	}
	
	response {
		err 0 : string
	}
}

# 好评奖励(仅标记)
service_review_mark 7108 {
	request {
		beat 100 : integer
	}
	
	response {
		err 0 : string
	}
}

#道具掉落限量初始化
item_limit_query 7201 {
	request {
		beat 100 : integer
		
	}
	response {
		list 1 : *ItemLimitData
	}
}



#深渊领域初始化
abyss_area_query 7301 {
	request {
		beat 100 : integer
		
	}
	response {
		list 1 : *AbyssAreaData
	}
}

#深渊领域首通战力
abyss_area_first_average 7302 {
	request {
		beat 100 : integer
		
		base_id 0 : integer
		neo_index 1 : integer
	}
	response {
		first_score 0 : integer
	}
}

#检查领域支援礼包
abyss_area_gift_check 7303 {
	request {
		beat 100 : integer

		ids 1 : *integer
	}
	response {
		err 0 : string
	}
}

#解锁neo boss
abyss_area_neo_open 7304 {
	request {
		beat 100 : integer

		id 1 : integer
	}
	response {
		err 0 : string
	}
}

#保存秘境自选进度
abyss_area_akasa_level 7305 {
	request {
		beat 100 : integer

		base_id 0 : integer
		level 1 : integer
	}
	response {
		err 0 : string
	}
}




#装备库初始化
armory_query 7401 {
	request {
		beat 100 : integer
		
	}
	response {
		list 0 : *ArmoryData
		amount 1 : integer
	}
}

#装备库设置名称
armory_set_name 7402 {
	request {
		beat 100 : integer
		
		index 0 : integer
		hero_class 1 : integer
		
		name 2 : string
	}
	response {
		err 0 : string
	}
}

#装备库保存
armory_save 7403 {
	request {
		beat 100 : integer
		
		index 0 : integer
		hero_class 1 : integer

		equip_1 11 : integer
		equip_2 12 : integer
		equip_3 13 : integer
		equip_4 14 : integer

		card 21 : integer
	}
	response {
		err 0 : string
	}
}



#检查充值返利
rebate_query 7501 {
	request {
		beat 100 : integer
		
	}
	response {

	}
}

# 玩家申请领取返利
rebate_req 7502 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string				# 只返回领取的成功还是失败，  返利物品还是走原来的邮件发放
	}
}


#全局参数
world_query 7601 {
	request {
		beat 100 : integer
		
	}
	response {
		.World {
			id 0 : string
			value 1 : integer
		}
		list 1 : *World
	}
}


#全局变量
params_query 7701 {
	request {
		beat 100 : integer
		
	}
	response {
		.Param {
			code 0 : string
			value 1 : integer
			value_str 2 : string
		}
		list 1 : *Param
	}
}



#sp佣兵图鉴初始化
manual_query 7801 {
	request {
		beat 100 : integer
		
	}
	response {
		list 0 : *ManualData
	}
}

#通用图鉴标记
manual_mark 7802 {
	request {
		beat 100 : integer
		
		type 0 : integer
	}
	response {
		err 0 : string
	}
}

#通用图鉴恢复
manual_recover 7803 {
	request {
		beat 100 : integer
		
		.Data {
			type 0 : integer
			id 1 : integer
		}
		list 1 : *Data
	}
	response {
		err 0 : string
	}
}



#特殊武器图鉴初始化
#manual_weapon_query 7901 {
#	request {
#		beat 100 : integer
#		
#	}
#	response {
#		list 0 : *ManualWeaponData
#	}
#}

#特殊武器图鉴标记
#manual_weapon_mark 7902 {
#	request {
#		beat 100 : integer
#		
#		id_arr 0 : *integer
#	}
#	response {
#		err 0 : string
#	}
#}



#自定义礼包初始化
mygift_query 8001 {
	request {
		beat 100 : integer
		
	}
	response {
		list 0 : *MygiftData
	}
}

#自定义礼包7日不弹
mygift_set_ignore 8002 {
	request {
		beat 100 : integer
		
		id 0 : integer
	}
	response {
		err 0 : string

		time 1 : integer
	}
}


#活动初始化
actv_query 8101 {
	request {
		beat 100 : integer
		
		start_index 0 : integer
	}
	response {
		list 0 : *ActvData
		bind_list 1 : *ActvBindData

		next_index 2 : integer
	}
}

#活动7日不弹
actv_set_ignore 8102 {
	request {
		beat 100 : integer
		
		id 0 : integer
	}
	response {
		err 0 : string

		time 1 : integer
	}
}






#活动每日目标初始化
actv_achieve_query 8201 {
	request {
		beat 100 : integer
		
	}
	response {
		list 1 : *ActvAchieveData

		config_day 2 : *ActvAchieveConfig
		config_full 3 : *ActvAchieveConfig
	}
}

#活动每日/周期目标领取奖励
actv_achieve_get_reward 8202 {
	request {
		beat 100 : integer

		actv_id 1 : integer
		actv_type 2 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}


#活动怪物初始化
actv_monster_query 8301 {
	request {
		beat 100 : integer
		
	}
	response {
		list 1 : *ActvMonsterData
		config_list 2 : *ActvMonsterConfig
	}
}

#活动副本初始化
actv_stage_query 8401 {
	request {
		beat 100 : integer
		
	}
	response {
		list 0 : *ActvStageData
	}
}

#活动副本进入
actv_stage_enter 8402 {
	request {
		beat 100 : integer
		
		stage_id 0 : integer
		level 1 : integer
		sp_index 2 : integer

		actv_id 10 : integer
	}
	response {
		err 0 : string
		
		dungeon_result 1 : DungeonSpotResult
	}
}

#活动副本进入（联机）
actv_stage_enter_room 8403 {
	request {
		beat 100 : integer
		
		room_id 0 : integer
		inst_id 1 : integer

		is_private 2 : integer

		actv_id 10 : integer
	}
	response {
		err 0 : string
		inst_id 1 : integer
		is_private 2 : integer
	}
}

#活动副本设置挑战等级
actv_stage_set_level 8404 {
	request {
		beat 100 : integer
	
		level 0 : integer

		actv_id 10 : integer
	}
	response {
		err 0 : string
	}
}

#活动副本排行榜
actv_stage_ranking 8405 {
	request {
		beat 100 : integer
		
		start_index 0 : integer
		is_area 1 : integer

		actv_id 10 : integer
	}
	response {
		err 0 : string
		list 1 : *StdRanking
	}
}

#活动副本排行榜开始
actv_stage_ranking_start 8406 {
	request {
		beat 100 : integer
		
		is_area 1 : integer
		
		actv_id 10 : integer
	}
	response {
		err 0 : string

		amount 1 : integer
		self_rank 2 : integer
		snapshot 3 : string
	}
}

#活动副本领取排行奖励
actv_stage_ranking_reward 8407 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
	}
}

#活动副本查看对手信息
actv_stage_look 8408 {
	request {
		beat 100 : integer
		
		actv_id 0 : integer
		id 1 : integer
	}
	response {
		err 0 : string
		team 1 : ArenaTeam
	}
}





#（失效）
lang_query 8501 {
	request {
		beat 100 : integer
		
	}
	response {
		.Lang {
			id 0 : string
			open 1 : integer
		}
		list 1 : *Lang
	}
}


#成长任务初始化
first_achieve_query 8601 {
	request {
		beat 100 : integer
		
	}
	response {
		.FirstAchieveData {
			base_id 0 : integer
			count 1 : integer
			step 2 : integer
			rewarded 3 : integer
		}
		list 1 : *FirstAchieveData

		start_time 2 : integer
		reward_record 3 : integer
		paid 4 : integer
		paid_reward_record 5 : integer
	}
}

#成长任务领取奖励
first_achieve_get_reward 8602 {
	request {
		beat 100 : integer
		
		id 0 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

#成长任务领取目标奖励
first_achieve_get_target_reward 8603 {
	request {
		beat 100 : integer
		
		id 0 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

#成长任务自检
first_achieve_fxxk_check 8604 {
	request {
		beat 100 : integer
		
		id 0 : integer
		params 1 : *integer
	}
	response {
		err 0 : string
	}
}

#成长任务领取目标奖励
first_achieve_get_paid_reward 8605 {
	request {
		beat 100 : integer
		
		id 0 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}





#尘封初始化
dust_query 8701 {
	request {
		beat 100 : integer
		
	}
	response {
		list 1 : *DustData
		gm_list 2 : *DustGM
	}
}

#尘封进入准备地图
dust_prepare 8702 {
	request {
		beat 100 : integer
		
		base_id 0 : integer
	}
	response {
		err 0 : string
		
		dungeon_result 1 : DungeonSpotResult
	}
}

#尘封进入副本
dust_enter 8703 {
	request {
		beat 100 : integer
		
		level 0 : integer
		speedup 1 : integer
	}
	response {
		err 0 : string
		
		dungeon_result 1 : DungeonSpotResult
	}
}

#尘封进入副本下一层
dust_next 8704 {
	request {
		beat 100 : integer
		
		map_index 0 : integer
		event_index 1 : integer
		speedup 2 : integer

		curr_level 3 : integer
		enter_index 4 : integer
	}
	response {
		err 0 : string
		
		dungeon_result 1 : DungeonSpotResult
		rewards 2 : *RewardData
		level 3 : integer
		ranking 4 : integer
	}
}

#尘封选择替补
dust_sub_hero 8705 {
	request {
		beat 100 : integer
		
		hero1_1 11 : integer
		hero1_2 12 : integer
		hero2_1 21 : integer
		hero2_2 22 : integer
		hero3_1 31 : integer
		hero3_2 32 : integer
	}
	response {
		err 0 : string
	}
}

#尘封替补上阵
dust_sub_on 8706 {
	request {
		beat 100 : integer
		
		pos 0 : integer
		index 1 : integer
	}
	response {
		err 0 : string
	}
}

#尘封排行榜
dust_ranking 8707 {
	request {
		beat 100 : integer
		
		start_index 0 : integer
	}
	response {
		err 0 : string
		list 1 : *StdRanking
	}
}

#尘封排行榜开始
dust_ranking_start 8708 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string

		amount 1 : integer
		self_rank 2 : integer
	}
}

#尘封领取赛季奖励
dust_check_season 8709 {
	request {
		beat 100 : integer
		
		dust_id 0 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData

		level 2 : integer
		ranking 3 : integer
	}
}

#尘封领取boss每日奖励
dust_boss_daily 8710 {
	request {
		beat 100 : integer
		
		dust_id 0 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

#权能升级
dust_mirror_lvup 8711 {
	request {
		beat 100 : integer
		
		dust_id 1 : integer
		group 2 : integer
	}
	response {
		err 0 : string
	}
}


#尘封商店列表
dust_shop_list 8712 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string

		items 1 : *ShopItem
	}
}

#尘封商店购买
dust_shop_buy 8713 {
	request {
		beat 100 : integer
		
		shop_id 0 : integer
		num 1 : integer
	}
	response {
		err 0 : string

		rewards 1 : *RewardData

		item 2 : ShopItem
	}
}

#尘封修复替补
dust_sub_fix 8714 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string

		changed 1 : integer
	}
}

#尘封上赛季排名
dust_ranking_last 8715 {
	request {
		beat 100 : integer
		
		dust_id 0 : integer
	}
	response {
		err 0 : string

		self_rank 2 : integer
	}
}




#尘封委托初始化
dust_achieve_query 8801 {
	request {
		beat 100 : integer
		
	}
	response {
		list 1 : *DustAchieveData

		day_refresh 2 : integer
		day_rewarded 3 : integer
		day_rewarded_time 4 : integer
		week_refresh 5 : integer
		week_rewarded 6 : integer
		week_rewarded_time 7 : integer
	}
}

#尘封委托刷新
dust_achieve_refresh 8802 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
	}
}

#尘封委托领取奖励
dust_achieve_get_reward 8803 {
	request {
		beat 100 : integer
		
		type 0 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

#尘封委托领取手册经验
dust_achieve_get_exp 8804 {
	request {
		beat 100 : integer
		
		base_id 0 : integer
	}
	response {
		err 0 : string
	}
}




#尘封战令初始化
dust_pass_query 8901 {
	request {
		beat 100 : integer
		
	}
	response {
		free_record_1 1 : integer
		free_record_2 2 : integer
		free_record_3 3 : integer
		free_record_4 4 : integer
		free_record_5 5 : integer
		free_record_6 6 : integer
		free_record_7 7 : integer
		free_record_8 8 : integer
		free_record_9 9 : integer
		free_record_10 10 : integer
		free_record_11 11 : integer
		free_record_12 12 : integer
		free_record_13 13 : integer
		free_record_14 14 : integer
		free_record_15 15 : integer
		free_record_16 16 : integer
		free_record_17 17 : integer
		free_record_18 18 : integer
		free_record_19 19 : integer
		free_record_20 20 : integer

		pay_record_1 21 : integer
		pay_record_2 22 : integer
		pay_record_3 23 : integer
		pay_record_4 24 : integer
		pay_record_5 25 : integer
		pay_record_6 26 : integer
		pay_record_7 27 : integer
		pay_record_8 28 : integer
		pay_record_9 29 : integer
		pay_record_10 30 : integer
		pay_record_11 31 : integer
		pay_record_12 32 : integer
		pay_record_13 33 : integer
		pay_record_14 34 : integer
		pay_record_15 35 : integer
		pay_record_16 36 : integer
		pay_record_17 37 : integer
		pay_record_18 38 : integer
		pay_record_19 39 : integer
		pay_record_20 40 : integer

		paid_1 41 : integer
		paid_2 42 : integer
		paid_3 43 : integer
		paid_4 44 : integer
		paid_5 45 : integer
		paid_6 46 : integer
		paid_7 47 : integer
		paid_8 48 : integer
		paid_9 49 : integer
		paid_10 50 : integer
	}
}

#尘封战令获得奖励
dust_pass_get_reward 8902 {
	request {
		beat 100 : integer
		
		id 0 : integer
		is_pay 1 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

#获得全部尘封战令奖励
dust_pass_get_reward_all 8903 {
	request {
		beat 100 : integer

		.RewardData {
			id 0 : integer
			is_pay 1 : integer
		}
		list 1 : *RewardData
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

#尘封战令购买经验
dust_pass_buy_exp 8904 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
	}
}


#尘封属性图鉴
dust_attr_manual_query 9001 {
	request {
		beat 100 : integer
		
	}
	response {
		.AttrManualData {
			base_id 0 : integer
			rewarded 1 : integer
		}
		list 1 : *AttrManualData
	}
}

#尘封属性图鉴领奖
dust_attr_manual_reward 9002 {
	request {
		beat 100 : integer
		
		base_id 0 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}


#活动签到初始化
actv_record_query 9101 {
	request {
		beat 100 : integer
		
	}
	response {
		list 0 : *ActvRecordData
	}
}

#活动签到领奖 is_recover=1是补签
actv_record_get_reward 9102 {
	request {
		beat 100 : integer
		
		actv_id 0 : integer
		day 1 : integer
		is_recover 2 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

#活动签到 签到
actv_record_sign 9103 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
	}
}


#战令
bp_overall_query 9201 {
	request {
		beat 100 : integer
		
	}
	response {
		pre_session 0 : integer
		heat 1 : integer
	}
}

bp_query 9211 {
	request {
		beat 100 : integer
		
	}
	response {
		list 0 : *BpData
	}
}

#购买战令经验
bp_buy_exp 9212 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
	}
}

#尘封战令获得奖励
bp_get_reward 9213 {
	request {
		beat 100 : integer
		
		index 0 : integer
		is_pay 1 : integer

		bp_id 2 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

#获得全部尘封战令奖励
bp_get_reward_all 9214 {
	request {
		beat 100 : integer

		.RewardData {
			index 0 : integer
			is_pay 1 : integer
		}
		list 1 : *RewardData

		bp_id 2 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}





#战令任务初始化
bp_achieve_query 9301 {
	request {
		beat 100 : integer
		
	}
	response {
		list 1 : *BpAchieveData

		bp_id 2 : integer
		day_refresh 3 : integer
		week_refresh 4 : integer
	}
}

#战令任务刷新
bp_achieve_refresh 9302 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
	}
}

#尘封委托领取手册经验
bp_achieve_get_exp 9303 {
	request {
		beat 100 : integer
		
		base_id 0 : integer
	}
	response {
		err 0 : string
	}
}


#魔纹初始化
sigil_query 9401 {
	request {
		beat 100 : integer
		start_index 0 : integer
	}
	response {
		err 0 : string
		list 1 : *SigilData
		next_index 2 : integer
	}
}

#魔纹装上身
sigil_on 9402 {
	request {
		beat 100 : integer
		
		sigil_id 0 : integer
		hero_id 1 : integer
		pos 2 : integer
	}
	response {
		err 0 : string
	}
}

#魔纹卸下
sigil_off 9403 {
	request {
		beat 100 : integer
		
		sigil_id 0 : integer
		bag_index 1 : integer
	}
	response {
		err 0 : string
	}
}

#魔纹锁定
sigil_lock 9404 {
	request {
		beat 100 : integer
		
		sigil_id 0 : integer
	}
	response {
		err 0 : string
	}
}

#魔纹融合
sigil_fusion 9405 {
	request {
		beat 100 : integer
		
		ids 0 : *integer
	}
	response {
		err 0 : string

		id 1 : integer
	}
}


#魔纹商店列表
sigil_shop_list 9406 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string

		items 1 : *ShopItem
	}
}


#魔纹商店购买
sigil_shop_buy 9407 {
	request {
		beat 100 : integer
		
		shop_id 0 : integer
		num 1 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData

		item 2 : ShopItem
	}
}



# 活动轮盘
actv_turntable_query 9501 {
	request {
		beat 100 : integer
	}

	response {
		list 0 : *ActvTurntableData
	}
}

# 转动轮盘抽奖
actv_turntable_roll 9502 {
	request {
		beat 100 : integer
		actv_id 0 : integer  #活动唯一ID
	}

	response {
		err 0 : string
		cell 1 : integer		#哪个格子被抽中了 (1~8)
		rewards 2 : *RewardData
	}
}


# 轮盘重置进入下一轮
actv_turntable_reset 9503 {
	request {
		beat 100 : integer
		actv_id 0 : integer  	#活动唯一ID
	}

	response {
		err 0 : string
	}
}


# 回归初始化
back_query 9601 {
	request {
		beat 100 : integer
		
	}
	response {
		list 0 : *BackData
	}
}

#回归签到初始化
back_record_query 9611 {
	request {
		beat 100 : integer
		
	}
	response {
		list 0 : *BackRecordData
	}
}

#回归签到领奖
back_record_get_reward 9612 {
	request {
		beat 100 : integer
		
		back_id 0 : integer
		day 1 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

#回归成就初始化
back_achieve_query 9621 {
	request {
		beat 100 : integer
		
	}
	response {
		list 0 : *BackAchieveData
	}
}

#回归成就领取奖励(每日成就)
back_achieve_get_day_reward 9622 {
	request {
		beat 100 : integer
		
		back_id 0 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

#回归成就领取奖励(回归成就)
back_achieve_get_reward 9623 {
	request {
		beat 100 : integer
		
		id 0 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

#回归副本进入
back_stage_enter 9631 {
	request {
		beat 100 : integer

		back_id 0 : integer
	}
	response {
		err 0 : string
		
		dungeon_result 1 : DungeonSpotResult
	}
}

#投喂初始化
pet_feed_query 9701 {
	request {
		beat 100 : integer
		
	}
	response {
		list 0 : *PetFeedData
	}
}

#投喂放上
pet_feed_on 9702 {
	request {
		beat 100 : integer
		
		pos 0 : integer
		pet_id 1 : integer
	}
	response {
		err 0 : string
	}
}

#投喂卸下
pet_feed_off 9703 {
	request {
		beat 100 : integer
		
		pos 0 : integer
	}
	response {
		err 0 : string
	}
}

#投喂
pet_feed_feed 9704 {
	request {
		beat 100 : integer
		
		pos 0 : integer
		item_id 1 : integer
	}
	response {
		err 0 : string
	}
}

#收获确定
pet_feed_check 9705 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string

		visit_feed 1 : integer
	}
}

#收获
pet_feed_reward 9706 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
		
		rewards 1 : *RewardData
	}
}

#访客投喂
pet_feed_visit 9707 {
	request {
		beat 100 : integer
		
		id 0 : integer
		pet_base_id 1 : integer
		item_id 2 : integer
		user_id 3 : integer
	}
	response {
		err 0 : string
		
		rewards 1 : *RewardData
	}
}




#神器初始化
artifact_query 9801 {
	request {
		beat 100 : integer
		start_index 0 : integer
	}
	response {
		list 0 : *ArtifactData
		next_index 1 : integer
	}
}

#神器装配
artifact_on 9802 {
	request {
		beat 100 : integer
		
		artifact_id 0 : integer
		hero_id 1 : integer
	}
	response {
		err 0 : string
	}
}

#神器卸下
artifact_off 9803 {
	request {
		beat 100 : integer
		
		artifact_id 0 : integer
		bag_index 1 : integer
	}
	response {
		err 0 : string
	}
}

#神器升级
artifact_lvup 9804 {
	request {
		beat 100 : integer
		
		artifact_id 0 : integer
	}
	response {
		err 0 : string
	}
}

#神器升星
artifact_starup 9805 {
	request {
		beat 100 : integer
		
		artifact_id 0 : integer
	}
	response {
		err 0 : string
	}
}

#神器更改属性
artifact_change_attr 9806 {
	request {
		beat 100 : integer
		
		artifact_id 0 : integer
		index 1 : integer
		attr 2 : string
	}
	response {
		err 0 : string
	}
}

#神器锁定
artifact_lock 9807 {
	request {
		beat 100 : integer
		
		artifact_id 0 : integer
	}
	response {
		err 0 : string
	}
}

#神器分解
artifact_dismiss 9808 {
	request {
		beat 100 : integer
		
		artifact_id 0 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData
	}
}

#神器商店列表
artifact_shop_list 9809 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string

		items 1 : *ShopItem
	}
}


#神器商店购买
artifact_shop_buy 9810 {
	request {
		beat 100 : integer
		
		shop_id 0 : integer
		num 1 : integer
	}
	response {
		err 0 : string
		rewards 1 : *RewardData

		item 2 : ShopItem
	}
}


#守护核心初始化
core_query 30101 {
	request {
		beat 100 : integer
	}
	response {
		list 0 : *CoreData
	}
}


#守护核心波次开始
core_wave_start 30102 {
	request {
		beat 100 : integer

		week_id 1 : integer
		wave 2 : integer
	}
	response {
		err 0 : string
	}
}


#守护核心波次结束
core_wave_fin 30103 {
	request {
		beat 100 : integer

		week_id 1 : integer
		wave 2 : integer
		hash 10 : string
	}
	response {
		err 0 : string
	}
}


#守护核心选择buff
core_wave_select_buff 30104 {
	request {
		beat 100 : integer

		week_id 1 : integer
		wave 2 : integer
		buff_id 3 : integer
	}
	response {
		err 0 : string
	}
}


#守护核心排行榜
core_ranking 30105 {
	request {
		beat 100 : integer
		
		start_index 0 : integer

		week_id 10 : integer
	}
	response {
		err 0 : string
		list 1 : *StdRanking
	}
}

#守护核心排行榜开始
core_ranking_start 30106 {
	request {
		beat 100 : integer

		week_id 10 : integer
	}
	response {
		err 0 : string

		amount 1 : integer
		self_rank 2 : integer
		snapshot 3 : string
	}
}


#守护核心查看对手信息
core_look 30107 {
	request {
		beat 100 : integer
		
		week_id 0 : integer
		id 1 : integer
	}
	response {
		err 0 : string
		team 1 : ArenaTeam
	}
}

#守护核心领取周奖励
core_reward 30108 {
	request {
		beat 100 : integer
		
		week_id 0 : integer
	}
	response {
		err 0 : string

		rewards 1 : *RewardData
	}
}









#进入联机地图
camp_enter 10101 {
	request {
		beat 100 : integer
		
		map_name 0 : string
		type 1 : integer
		x 2 : integer
		y 3 : integer
	}
	response {
		err 0 : string
	}
}

#离开联机地图
camp_exit 10102 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string
	}
}

#拉入联机地图
camp_summon 10103 {
	request {
		beat 100 : integer
		
		x 1 : integer
		y 2 : integer
	}
	response {
		err 0 : string

		.MonsterHP {
			map_index 0 : integer
			event_index 1 : integer
			index 2 : integer
			hp 3 : integer
		}
		hp_monster 1 : *MonsterHP

		.HeroHP {
			user_id 0 : integer
			pos 1 : integer
			hp 2 : integer
			hpMax 3 : integer
		}
		hp_hero 2 : *HeroHP


		pass_count 3 : integer
		pass_total 4 : integer
	}
}

#返回联机地图
camp_recover 10104 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
	}
}

#联机地图移动广播
camp_move 10111 {
	request {
		beat 100 : integer
		
		x 0 : integer
		y 1 : integer
	}
	response {
		err 0 : string
	}
}

#联机做表情
camp_emoji 10112 {
	request {
		beat 100 : integer
		
		id 1 : integer
	}
	response {
		err 0 : string
	}
}

#（失效）
camp_look 10113 {
	request {
		beat 100 : integer
		
		user_id 1 : integer
	}
	response {
		err 0 : string
		teams 1 : *OnlineTeam
	}
}

#更新联机外观
camp_appear_update 10114 {
	request {
		beat 100 : integer

		hero_id 0 : integer
	}
	response {
		err 0 : string
	}
}

#（失效）
camp_play_song 10115 {
	request {
		beat 100 : integer

		id 0 : integer
	}
	response {
		err 0 : string
	}
}

#联机做动作
camp_action 10116 {
	request {
		beat 100 : integer

		id 0 : integer
		params 1 : string
	}
	response {
		err 0 : string
	}
}

#联机更新勋章
camp_medals_update 10117 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
	}
}





#联机战斗开始
camp_battle_start 10121 {
	request {
		beat 100 : integer
		
		map_index 0 : integer
		event_index 1 : integer
	}
	response {
		err 0 : string
	}
}

#联机战斗结束
camp_battle_over 10122 {
	request {
		beat 100 : integer
		
		map_index 0 : integer
		event_index 1 : integer
	}
	response {
		err 0 : string
	}
}

#联机同步血量
camp_sync_hp 10123 {
	request {
		beat 100 : integer
		
		.MonsterHP {
			map_index 0 : integer
			event_index 1 : integer
			index 2 : integer
			hp_dmg 3 : integer
		}
		hp_monster 0 : *MonsterHP

		.HeroHP {
			user_id 0 : integer
			pos 1 : integer
			hp 2 : integer
		}
		hp_hero 1 : *HeroHP
	}
	response {
		err 0 : string
	}
}

#联机全灭
camp_dieout 10124 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
	}
}











#进入组队房间
room_enter 10201 {
	request {
		beat 100 : integer
		
		room_name 0 : string
		room_id 1 : string
		inst_id 2 : integer

		is_private 3 : integer
	}
	response {
		err 0 : string
		inst_id 1 : integer
	}
}

#离开组队房间
room_exit 10202 {
	request {
		beat 100 : integer

	}
	response {
		err 0 : string
	}
}

#组队开始副本
room_start 10203 {
	request {
		beat 100 : integer

	}
	response {
		err 0 : string
	}
}

#组队准备
room_ready 10204 {
	request {
		beat 100 : integer

		is_ready 1 : integer
	}
	response {
		err 0 : string
	}
}





# -----------------------公会相关协议----------------------------------
#公会初始化（玩家登陆时 会通过 user_init_query协议下发 ）
union_query 10301 {
	request {
		beat 100 : integer
	}
	
	response {
		base_info 0 : UnionBaseInfo     		#结构中的union_id为0,表示没有公会
		private_info 1 : UnionPrivateInfo		#结构中的last_exit_union_time表示上次退出公会的时间
		building_info 2 : *UnionBuildingInfo
		buff_info 3 : UnionBuffInfo
		shop_refresh_time 10 : integer
	}
}

#创建公会 
union_create 10302 {
	request {
		beat 100 : integer
		info 0 : UnionBaseInfo
	}
	
	response {
		err 0 : string
	}
}

#工会信息修改
union_modify 10303 {
	request {
		beat 100 : integer
		info 0 : UnionBaseInfo
	}

	response {
		err 0 : string
	}
}


#公会列表查询
union_list_query 10304 {
	request {
		beat 100 : integer
		union_id 0 : integer			#公会ID		
		union_name 1 : string			#公会名称
		union_type 2 : integer			#公会类型（偏好）
	}

	response {
		.SearchUnionInfo {
			union_info 0 : UnionBaseInfo	#公会基础信息
			request_joined 1 : integer		#是否审请加入 0没有申请， 1有申请
		}
		err 0 : string
		union_infos 1 : *SearchUnionInfo
	}
}


#查看公会信息
union_info 10305 {
	request {
		beat 100 : integer
		union_id 0 : integer
	}

	response {
		err 0 : string
		union_info 1 : UnionBaseInfo			#公会的基础信息
		union_log 2 : *UnionLog					#公会的日志
		union_members 3 : *UnionMember			#公会的成员列表
		join_request_info 4 : *UserInfo			#查看的工会如果是自己的工会 且 自己有审批权限的，可以查看审请列表
	}
}

#申请加入公会
union_join 10306 {
	request {
		beat 100 : integer
		union_id 0 : integer
		is_join 1 : integer 	# 1表示神请加入  0 表示取消神请
	}

	response {
		err 0 : string
		union_id 1 : integer
		is_join 2 : integer
	}
}

# 回应 加入公会的审请 
union_join_answer 10308 {
	request {
		beat 100 : integer
		user_id 0 : integer
		is_pass 1 : integer		# 1通过 2不通过
	}

	response {
		err 0 : string
		user_id 1 : integer
		is_pass 2 : integer		# 1通过 2不通过
	}
}

#公会任命罢免
union_appoint 10309 {
	request {
		beat 100 : integer
		user_id 0 : integer
		official_title 1 : integer	# 任命或罢免后的 官衔
	}

	response {
		err 0 : string
	}
}

#公会踢人
union_kick 10310 {
	request {
		beat 100 : integer
		user_id 0 : integer
	}

	response {
		err 0 : string
	}
}

#退出公会
union_exit 10311 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
	}
}

#职位转让
union_official_transfer 10312 {
	request {
		beat 100 : integer
		user_id 0 : integer   	# 将职位转让给谁
	}
	response {
		err 0 : string
	}
}




#捐献信息 
union_contribution_info 10313 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
	}
}

#玩家捐赠
union_contribution 10314 {
	request {
		beat 100 : integer
		res 0 : *UnionContribution			#损赠了什么东西
	}

	response {
		err 0 : string
	}
}

#公会建筑信息
union_building_info 10320 {
	request {
		beat 100 : integer
		building_tag 0 : integer		#建筑tag
	}

	response {
		err 0 : string
	}
}

#公会建筑升级
union_building_upgrade 10321 {
	request {
		beat 100 : integer
		building_tag 0 : integer			#建筑tag
	}
	response {
		err 0 : string
	}
}

#公会所有建筑的信息
union_all_building_info 10322 {
	request {
		beat 100 : integer
	}

	response {
		err 0 : string
	}
}

#BUFF操作
union_buff_info 10330 {
	request {
		beat 100 : integer
	}

	response {
		err 0 : string

		buff_info 1 : UnionBuffInfo
	}
}

#研究BUFF
union_study_buff 10331 {
	request {
		beat 100 : integer
		buff_id 0 : integer
	}

	response {
		err 0 : string
	}
}

#开启BUFF
union_open_buff 10332 {
	request {
		beat 100 : integer
		buff_id 0 : integer
	}

	response {
		err 0 : string
	}
}

#公会商店
union_shop_info 10340 {
	request {
		beat 100 : integer
	}

	response {
		err 0 : string
		shop_items 1 : *UnionShopItem		#商品列表
	}
}

# 购买
union_shop_buy 10341 {
	request {
		beat 100 : integer
		goods_id 0 : integer		
	}

	response {
		err 0 : string
		shop_item 1 : UnionShopItem
	}
}






#公会个人商店列表
union_member_shop_list 10350 {
	request {
		beat 100 : integer
		
	}
	response {
		err 0 : string

		items 1 : *ShopItem
	}
}

#公会个人商店购买
union_member_shop_buy 10351 {
	request {
		beat 100 : integer
		
		shop_id 0 : integer
		num 1 : integer
	}
	response {
		err 0 : string

		rewards 1 : *RewardData

		item 2 : ShopItem
	}
}



#公会木桩训练
union_mono_stage 10360 {
	request {
		beat 100 : integer
		
		building_id 0 : integer
		is_solo 1 : integer
		solo_hero_id 2 : integer
	}
	response {
		err 0 : string
		
		dungeon_result 1 : DungeonSpotResult
	}
}


# ********************************************************
#公会战相关

# 玩家上线检查 赛季用
union_war_check_season 10370 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
		season 1 : string  # 如：2023.09
		step 2 : integer    #公会战当前处于哪个阶段  参见 服务器代码定义 UnionHelper.UNION_WAR_STEP
		round 3 : integer 	#公会战当前处于哪个轮次  有效值为0~5
	}
}

#公会战是否已报名
union_war_is_enroll 10371 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
		enroll 1 : integer   #1 已报 0 未报
	}
}

#公会战报名
union_war_enroll 10372 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
	}
}


#公会成员设置预备队员
union_war_set_prepare_hero 10373 {
	request {
		beat 100 : integer
		hero_ids 0 : *integer     # 全量设置
	}

	response {
		err 0 : string
		hero_ids 1 : *integer
	}
}

#公会成员 已设置的 预备队员
union_war_get_prepare_hero 10374 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string

		.PrepareHeroData
		{
			hero_id 0 : integer
			flag 1 : integer
		}
		heros 1 : *PrepareHeroData
	}
}

#取得所有 队员 列表 用于排兵布阵
union_war_get_all_hero 10375 {
	request {
		beat 100 : integer
		is_watch 0 : integer		#1：只发送上阵的英雄信息 0:所有
	}
	response {
		err 0 : string
		all_heros 1 : *UnionWarSingleHeroData
	}
}


#公会会长 挑选预备队友，设置出战/应援
union_war_set_hero_in_battle 10377 {
	request {
		beat 100 : integer
		heros 0 : *HeroInBattle 		# 全量设置
	}
	response {
		err 0 : string
		heros 1 : *HeroInBattle 		# 全量设置
	}
}

#-- #公会管理，设置预备队为应援
#-- union_war_set_hero_in_support 10378 {
#-- 	request {
#-- 		beat 100 : integer
#-- 		support_groups 1 : *integer  #支援技能组
#-- 	}
#-- 	response {
#-- 		err 0 : string
#-- 		support_groups 1 : *integer  #支援技能组
#-- 	}
#-- }



# 会长、副会长 操作佣兵之前，需要先申请操作权, 操作完成需要释放控制权
union_war_mutext_holding 10379 {
	request {
		beat 100 : integer
		flag 0 : integer     		# 1 取得控制权 0 释放控制权
	}
	response {
		err 0 : string
	}
}



#查看赛区信息
union_war_view_zone_info 10380 {
	request {
		beat 100 : integer

		zone_id 0 : integer  #赛区ID  与策划文档统一 0:巅峰赛区  zone_id 为 nil 查询自已公会所在的赛区信息
	}
	response {
		err 0 : string
		
		zone_id 1 : integer  							#赛区ID
		step 2 : integer								#公会战进行到哪个阶段了 （对应枚举 UNION_WAR_STEP）
		round 3 : integer								#当前进行到第几轮了
		bet_union_id 4 : integer 						#当前轮是否有下注

		union_infos 10 : *UnionWarSingleUnionInfo  		#此赛季所有公会的信息
		round_1_info 11 : *UnionWarSingleBattleInfo 	#第 1 轮对战信息
		round_2_info 12 : *UnionWarSingleBattleInfo 	#第 2 轮对战信息
		round_3_info 13 : *UnionWarSingleBattleInfo 	#第 3 轮对战信息
		round_4_info 14 : *UnionWarSingleBattleInfo 	#第 4 轮对战信息
		round_5_info 15 : *UnionWarSingleBattleInfo 	#第 5 轮对战信息
	}
}

#查看公会历史战绩
union_war_history 10381 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
		.HistoryData {
			season_id 0 : string		#赛季名称
			zone_id 1 : integer			#所属赛区ID
			win_round 2 : integer		#获胜轮次
		}
		records 1 : *HistoryData
	}
}

# 查看公会战斗回放
union_war_view_battle_replay 10382 {
	request {
		beat 100 : integer

		battle_id 1 : integer
	}
	response {
		err 0 : string

		battle_id 1 : integer
		battle_seed 2 : integer							#演算战斗的随机种子
		who_is_win 3 : integer   						# 获得方的公会ID
		battle_hash 4 : string							# 客户端战斗验证用
		battle_side_a 10 : UnionWarBattleSideInfo   	#对战双方的数据(有英雄列表的快照数据)
		battle_side_b 11 : UnionWarBattleSideInfo 
	}
}

#公会战 竞猜
#-- # 玩家查看自己的下注情况
#-- union_war_user_betting_info 10385 {
#-- 	request {
#-- 		beat 100 : integer
#-- 	}
#-- 	response {
#-- 		err 0 : string
#-- 		season_id 1 : string				#赛季名称
#-- 		bet_times 2 : integer				#本赛季下注总次数
#-- 		bet_union_id 3 : integer			#当前赛季，最后一次下注是下注册的那个公会
#-- 		round 4 : integer					#当前赛季，最后一次下注，是第几轮
#-- 		consecutive_win 5 : integer			#连胜次数
#-- 	}
#-- }

# 玩家查看对战的双方
union_war_view_battle_info 10385 {
	request {
		beat 100 : integer
		battle_id 0 : integer
	}

	response {
		err 0 : string

		battle_id 1 : integer
		round 2 : integer						
		consecutive_win 3 : integer				#预测连胜次数
		who_is_win 4 : integer 					#获胜方的公会ID，如果为0 表示还没开打
		bet_union_id 5 : integer				#这个轮次是否有下注，（0：表示没有下注， >0 表示下注的公会ID）

		battle_side_a 10 : UnionWarBattleSideInfo   #对战双方的数据（无英雄列表的快照）
		battle_side_b 11 : UnionWarBattleSideInfo 
	}

}

# 玩家下注
union_war_user_bet 10386 {
	request {
		beat 100 : integer
		battle_id 2 : integer
		union_id 3 : integer
	}
	response {
		err 0 : string
		battle_id 2 : integer
		union_id 3 : integer
	}
}




# 公会战技能盘BUFF
union_war_battle_buff_list 10390 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
		ids 1 : *integer				#所有开启的技能BUFF
		total_point 2 : integer 		# 预备队人员数量 也就是 技能点数
	}
}

# 技能盘操作 开启或取消一个BUFF
union_war_battle_buff_operate 10391 {
	request {
		beat 100 : integer
		ids 1 : *integer					# 要开启的 battle buff ids
	}
	response {
		err 0 : string
		ids 1 : *integer
	}
}

# 公会战相关检查 （用于：检查是否有公会战奖励，是否有下注奖励，清空上赛季的残留道具等）
union_war_trigger_check 10392 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
	}
}

# 玩家上线检查 赛季用
union_war_check_season_enroll 10399 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
		season 1 : string  	# 如：2023.09
		step 2 : integer    #公会战当前处于哪个阶段  参见 服务器代码定义 UnionHelper.UNION_WAR_STEP
		round 3 : integer 	#公会战当前处于哪个轮次  有效值为0~5
		enroll 4 : integer  #1 已报 0 未报
		self_rank 5 : integer # 战力排名 (结束报名后赛季结束前且有报名的公会 才有值)
	}
}


####################################################
# FAQ 相关

# 取得目录层级列表
faq_get_dir_list 10400 {
	request {
		beat 100 : integer
		lang 0 : string
	}
	response {
		err 0 : string
		dirs 1 : *FAQ_dir
	}
}

# 取得指定目录下的所有文章
faq_get_content_list 10401 {
	request {
		beat 100 : integer
		lang 0 : string
		dir 1 : integer
		onlyTitle 2 : integer    		#1 返回的列表中只有文间的ID和title  0：返回的列表中有ID，title,content
	}
	response {
		err 0 : string
		contents 1 : *FAQ_content
	}
}


# -- 返回 单个 content 的内容
faq_get_content 10402 {
	request {
		beat 100 : integer
		lang 0 : string
		content_id 1 : integer
	}
	response {
		err 0 : string
		content 1 : string
	}
}


####################################################
# 公会PVE

#公会PVE（基础信息）
union_pve_query 10410 {
	request {
		beat 100 : integer
	}

	response {
		err 0 : string

		
		normal_stage_info 1 : *UnionPVENormalStageInfo		#关卡信息（stageID以及是否通关的标识)
		boss_stage_info 2 : *UnionPVEBossStageInfo			#BOSS关卡信息
		active_point 3 : integer							#活跃点数
		active_reward_flag 4 : integer 						#活跃度奖励领取情况（二进制标识）
		support_point 5 : integer							#为公会贡献的支援点数
		union_support_point 6 : integer						#公会当前的支援点数
		
		challenge_times 7 : integer 						#已挑战普通副本的的次数
		last_challenge_time 8 : integer						#最后一次挑战普通副本的时间
		
		season_id 10 : integer								#赛季ID
		step 11 : integer 									#当前阶段 (UnionHelper.UNION_PVE_STEP)

		challenge_boss_times 20 : integer 					#已挑战boss副本的的次数
		challenge_boss_time 21 : integer 					#最后一次挑战boss副本的时间
	}
}

# 公会PVE相关检查 （用于：检查是否有公会PVE奖励发放，清空上赛季的残留数据等, 解发切换赛季 ）
union_pve_trigger_check 10411 {
	request {
		beat 100 : integer
	}
	response {
		err 0 : string
	}
}

#挑战 公会PVE 普通关卡 
union_pve_challenge_normal_stage 10412 {
	request {
		beat 100 : integer
		stage_id 0 : integer 					#关卡ID
	}

	response {
		err 0 : string
		dungeon_result 1 : DungeonSpotResult	
	}
}

#领取活跃度奖励
union_pve_get_active_reward 10413 {
	request {
		beat 100 : integer
		id 0 : integer							#(gwar_achieve_reward表的id)
	}

	response {
		err 0 : string
		
		rewards 1 : *RewardData
		active_reward_flag 2 : integer 			#活跃度奖励领取情况（二进制标识）
		active_point 3 : integer				#活跃点数
	}
}

#挑战公会PVE BOSS
union_pve_challenge_boss 10414 {
	request {
		beat 100 : integer
		stage_id 0 : integer
		fight_type 1 : integer 					# 模拟打0， 正式打1
	}

	response {
		err 0 : string

		stage_id 1 : integer							#boss关卡ID
		battle_id 2 : integer							#战斗的唯一ID
		battle_seed 3 : integer							# 演算战斗的随机种子
		battle_hash 4 : string							# 客户端战斗验证用
		score 5 : integer								# 得分
		
		heros 10 : *UnionWarSingleHeroData   			
		buffs 11 : *integer 
	}
}

#单个BOSS排行榜 开始
union_pve_boss_ranking_start 10415 {
	request {
		beat 100 : integer
		stage_id 0 : integer					#boss关卡ID）
	}

	response {
		err 0 : string
		stage_id 1 : integer					#boss关卡ID
		amount 2 : integer
		self_rank 3 : integer
		self_points 4 : integer
	}
}

#单个BOSS排行榜列表
union_pve_boss_ranking 10416 {
	request {
		beat 100 : integer
		stage_id 0 : integer					#boss关卡ID
		start_index 1 : integer
	}

	response {
		err 0 : string
		list 1 : *UnionPVEBossRankingSingleUnion
	}
}

#总排行榜 开始
union_pve_ranking_start 10417 {
	request {
		beat 100 : integer
	}

	response {
		err 0 : string
		amount 2 : integer
		self_rank 3 : integer
		self_points 4 : integer
	}
}

#总排行榜 列表
union_pve_ranking 10418 {
	request {
		beat 100 : integer
		start_index 0 : integer
	}

	response {
		err 0 : string
		list 1 : *UnionPVETotalRankingSingleUnion
	}
}


#单个BOSS的挑战记录
union_pve_boss_challenge_record 10419 {
	request {
		beat 100 : integer
		stage_id 0 : integer							#boss关卡ID
	}

	response {
		err 0 : string

		.HeroNum {
			hero_type 0 : integer 						#对应hero 表的 class 字段 
			hero_num 1 : integer
		}

		stage_id 1 : integer

		.SingleChallengeData {
			battle_id 0 : integer						#每场战斗的唯一标识
			user_id 1 : integer							#操作人的ID
			nickname 2 : string
			nicklang 3 : string
			official_title 4 : integer					#官衔
			
			create_time 10 : integer
			fight_type 11 : integer 					# 模拟打0， 正式打1
			score 12 : integer
			formation 13 : *HeroNum 					#数组 （战士、法师、弓手）的数量
			buffs 14 : *integer 						#支援BUFF
		}

		records 2 : *SingleChallengeData
	}
}

#查看 pve boss 战的回放
union_pve_boss_challenge_replay 10420 {
	request {
		beat 100 : integer
		stage_id 0 : integer							#boss关卡ID
		battle_id 1 : integer							#战斗的唯一ID
	}

	response {
		err 0 : string

		stage_id 1 : integer							#boss关卡ID
		battle_id 2 : integer							#战斗的唯一ID
		battle_seed 3 : integer							# 演算战斗的随机种子
		battle_hash 4 : string							# 客户端战斗验证用
		
		heros 10 : *UnionWarSingleHeroData   			
		buffs 11 : *integer 
	}
}

]]

return c2s
