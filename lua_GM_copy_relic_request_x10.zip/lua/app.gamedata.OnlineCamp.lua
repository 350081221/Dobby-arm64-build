local OnlineCamp = {}
local TYPE = {
	UNION = 3,
	HOME = 2,
	DEFAULT = 1
}
OnlineCamp.TYPE = TYPE

function OnlineCamp.init()
	Connection.listen("camp_enter", OnlineCamp.onEnter)
	Connection.listen("camp_exit", OnlineCamp.onExit)
	Connection.listen("camp_move", OnlineCamp.onMove)
	Connection.listen("camp_emoji", OnlineCamp.onEmoji)
	Connection.listen("camp_summon", OnlineCamp.onSummon)
	Connection.listen("camp_appear_update", OnlineCamp.onUpdateAppear)
	Connection.listen("camp_medals_update", OnlineCamp.onUpdateMedals)
	Connection.listen("camp_play_song", OnlineCamp.onPlaySong)
	Connection.listen("camp_action", OnlineCamp.onAction)
	Connection.listen("camp_battle_start", OnlineCamp.onBattleStart)
	Connection.listen("camp_battle_over", OnlineCamp.onBattleOver)
	Connection.listen("camp_sync_hp", OnlineCamp.onSyncHP)
	Connection.listen("camp_sync_pass", OnlineCamp.onSyncPass)
end

app:addToAppEnterCall(OnlineCamp.init)

function OnlineCamp.isOnline()
	if InfoDungeon.isCampHome() then
		return true
	end

	if InfoUnion.inMap() then
		return true
	end

	if InfoDungeon.getType() == InfoDungeon.TYPE.STAGE then
		local csv = InfoDungeon.getStageCSV()

		return csv.is_online == 1
	end

	return false
end

function OnlineCamp.isOnlineStage()
	if InfoDungeon.getType() == InfoDungeon.TYPE.STAGE then
		local stageType = InfoDungeon.getStage()

		return stageType > 100
	end

	return false
end

local inRoom = nil
local onlinePlayerMap = {}
local onlineDataMap = {}
local monsterHpInfo, heroHpInfo = nil
local dpsInfo = {}
local pass_count = 0
local pass_total = 0
local battleInfo = nil

function OnlineCamp.syncBattle(user_id)
	local onlinePlayer = onlinePlayerMap[user_id]

	if onlinePlayer then
		local units = onlinePlayer:getTrainUnits()
		local found = false

		if battleInfo[user_id] then
			local map_index = battleInfo[user_id].map_index
			local event_index = battleInfo[user_id].event_index
			local groupID = MapEventManager.monsterEventGroup[event_index]

			if groupID then
				local monsters = Monster.getGroup(groupID)

				if monsters and #monsters > 0 then
					if not onlinePlayer.isFighting then
						for i, unit in ipairs(units) do
							unit:startFight(monsters)

							unit.isFighting = true
						end

						if WarMachine.on then
							OnlineCamp.battleJump(event_index, units)
						end
					end

					found = true
				end
			end
		end

		if not found and onlinePlayer.isFighting then
			for i, unit in ipairs(units) do
				unit:stopFight()

				unit.isFighting = nil
			end

			onlinePlayer:regroupTrain()
		end
	end
end

function OnlineCamp.syncBattleAll()
	for user_id, onlinePlayer in pairs(onlinePlayerMap) do
		OnlineCamp.syncBattle(user_id)
	end
end

function OnlineCamp.battleJump(eventIndex, units)
	local tileMap = WarMachine.getAreaTileMap()

	if not tileMap then
		return
	end

	if not units then
		units = {}

		for user_id, onlinePlayer in pairs(onlinePlayerMap) do
			if battleInfo[user_id] then
				local map_index = battleInfo[user_id].map_index
				local event_index = battleInfo[user_id].event_index

				if eventIndex == event_index then
					local _units = onlinePlayer:getTrainUnits()

					for i, unit in ipairs(_units) do
						if not tileMap[unit.tile.tag] then
							table.insert(units, unit)
						end
					end
				end
			end
		end
	end

	local jumpinSpeed = 10
	local jumpinDelay = 0
	local freeTiles = {}

	for k, tile in pairs(tileMap) do
		if tile:isEmptyUnit() then
			table.insert(freeTiles, tile)
		end
	end

	if #freeTiles < #units then
		freeTiles = {}

		for k, tile in pairs(tileMap) do
			table.insert(freeTiles, tile)
		end
	end

	for i, unit in ipairs(units) do
		if #freeTiles > 0 then
			local bestDistance, bestTile, bestTileIndex = nil

			for j = 1, #freeTiles do
				local tile = freeTiles[j]
				local distance = math.sqrt(math.pow(unit.tile.y - tile.y, 2) + math.pow(unit.tile.x - tile.x, 2))

				if bestDistance == nil or distance < bestDistance then
					bestDistance = distance
					bestTile = tile
					bestTileIndex = j
				end
			end

			if bestTile ~= nil then
				local x, y = global.map:tileToMap(bestTile)

				unit:jump({
					x = x,
					y = y
				}, jumpinSpeed, 20)

				local distance = math.sqrt(math.pow(unit.y - y, 2) + math.pow(unit.x - x, 2))
				jumpinDelay = math.max(jumpinDelay, math.floor(distance / jumpinSpeed))

				table.remove(freeTiles, bestTileIndex)
			end
		end
	end
end

function OnlineCamp.initHpInfo(hp_monster, hp_hero)
	monsterHpInfo = {}

	for i, v in ipairs(hp_monster) do
		if not monsterHpInfo[v.map_index] then
			monsterHpInfo[v.map_index] = {}
		end

		if not monsterHpInfo[v.map_index][v.event_index] then
			monsterHpInfo[v.map_index][v.event_index] = {}
		end

		monsterHpInfo[v.map_index][v.event_index][v.index] = v

		OnlineCamp.syncMonster(v)
	end

	heroHpInfo = {}
	local user_id_map = {}

	for i, v in ipairs(hp_hero) do
		if not heroHpInfo[v.user_id] then
			heroHpInfo[v.user_id] = {}
		end

		heroHpInfo[v.user_id][v.pos] = v
		user_id_map[v.user_id] = 1
	end

	for user_id, v in pairs(user_id_map) do
		OnlineCamp.syncHero(user_id)
	end
end

function OnlineCamp.getMonsterHP(map_index, event_index, index)
	if monsterHpInfo and monsterHpInfo[map_index] and monsterHpInfo[map_index][event_index] and monsterHpInfo[map_index][event_index][index] then
		return monsterHpInfo[map_index][event_index][index].hp
	end
end

function OnlineCamp.getHeroHP(user_id, pos)
	if heroHpInfo[user_id] and heroHpInfo[user_id][pos] then
		return heroHpInfo[user_id][pos].hp, heroHpInfo[user_id][pos].hpMax
	end
end

function OnlineCamp.getMonster(map_index, event_index, index)
	local monsters = Monster.getAllMonster()

	for i, monster in ipairs(monsters) do
		if monster.onlineAnchor then
			local onlineAnchor = monster.onlineAnchor

			if onlineAnchor.map_index == map_index and onlineAnchor.event_index == event_index and onlineAnchor.index == index then
				return monster
			end
		end
	end
end

function OnlineCamp.syncMonster(obj, monster)
	if not OnlineCamp.isOnlineStage() then
		return
	end

	monster = monster or OnlineCamp.getMonster(obj.map_index, obj.event_index, obj.index)

	if monster then
		local hp = obj.hp or OnlineCamp.getMonsterHP(obj.map_index, obj.event_index, obj.index)

		if hp then
			if hp > 0 then
				if not monster.battleData.die and hp < monster.attrs.hp then
					local preHP = monster.battleData.hp
					monster.battleData.hp = math.min(monster.battleData.hp, hp)

					monster:setHudVisible(true)
					monster:hudSetHP(monster.battleData.hp / monster.attrs.hp)

					local offset = monster.battleData.hp - preHP

					WarMachine.onHpChange(monster, monster.battleData.hp, offset, true)
				end
			else
				monster:die()
			end
		end
	end
end

function OnlineCamp.syncHero(user_id)
	local onlinePlayer = onlinePlayerMap[user_id]
	local teamChanged = false
	local newArr = {}

	if onlinePlayer and onlinePlayer.getTrainUnits then
		local units = onlinePlayer:getTrainUnits()

		for i, unit in ipairs(units) do
			if heroHpInfo[user_id] and heroHpInfo[user_id][unit.info.pos] then
				local obj = heroHpInfo[user_id][unit.info.pos]

				if obj and obj.hp and obj.hpMax then
					local hp = obj.hp

					if hp > 0 then
						unit.battleData.hp = hp
						unit.attrs.hp = obj.hpMax

						unit:setHudVisible(true)
						unit:hudSetHP(unit.battleData.hp / unit.attrs.hp)
						table.insert(newArr, unit)
					else
						teamChanged = true

						unit:die(true)
					end
				else
					table.insert(newArr, unit)
				end
			end
		end

		if teamChanged then
			if #newArr > 0 then
				local onlinePlayer = newArr[1]
				onlinePlayerMap[user_id] = onlinePlayer

				onlinePlayer:clearTrain()

				for i = 2, #newArr do
					local unit = newArr[i]

					unit:clearTitle()
					onlinePlayer:addToTrain(unit)
				end

				if not onlinePlayer.inFighting then
					onlinePlayer:regroupTrain()
				end

				if onlinePlayer then
					OnlineCamp.showTitle(onlinePlayer)
				end
			else
				onlinePlayerMap[user_id] = nil
			end
		end
	end
end

function OnlineCamp.isPassed()
	return pass_total <= pass_count, pass_count, pass_total
end

function OnlineCamp.getDpsList(eventIndexArr)
	local dpsMap = {}
	local mapIndex = InfoDungeon.getMapIndex()
	local totalDps = 0

	if dpsInfo[mapIndex] then
		for i, eventIndex in ipairs(eventIndexArr) do
			if dpsInfo[mapIndex][eventIndex] then
				for user_id, dps in pairs(dpsInfo[mapIndex][eventIndex]) do
					if not dpsMap[user_id] then
						if InfoUser.getID() == user_id then
							dpsMap[user_id] = {
								dps = 0,
								user_info = InfoUser.getUserInfo()
							}
						else
							local data = onlineDataMap[user_id]

							if data then
								dpsMap[user_id] = {
									dps = 0,
									user_info = data.user_info
								}
							end
						end
					end

					if dpsMap[user_id] then
						dpsMap[user_id].dps = dpsMap[user_id].dps + dps
						totalDps = totalDps + dps
					end
				end
			end
		end
	end

	local arr = {}

	for user_id, v in pairs(dpsMap) do
		v.percent = v.dps / totalDps

		table.insert(arr, v)
	end

	table.sort(arr, function (a, b)
		return b.dps < a.dps
	end)

	return arr
end

function OnlineCamp.onBattleStart(data)
	dump(data, "$$$ onBattleStart")

	local user_id = data.user_id
	local map_index = data.map_index
	local event_index = data.event_index
	battleInfo[user_id] = {
		map_index = map_index,
		event_index = event_index
	}

	OnlineCamp.syncBattle(user_id)
end

function OnlineCamp.onBattleOver(data)
	dump(data, "$$$ onBattleOver")

	local user_id = data.user_id
	battleInfo[user_id] = nil

	OnlineCamp.syncBattle(user_id)
end

function OnlineCamp.onSyncHP(data)
	local hp_monster = data.hp_monster

	if hp_monster then
		for i, v in ipairs(hp_monster) do
			if not monsterHpInfo[v.map_index] then
				monsterHpInfo[v.map_index] = {}
			end

			if not monsterHpInfo[v.map_index][v.event_index] then
				monsterHpInfo[v.map_index][v.event_index] = {}
			end

			monsterHpInfo[v.map_index][v.event_index][v.index] = v

			OnlineCamp.syncMonster(v)
		end
	end

	local dps_map = data.dps_map

	if dps_map then
		for i, v in ipairs(dps_map) do
			if not dpsInfo[v.map_index] then
				dpsInfo[v.map_index] = {}
			end

			if not dpsInfo[v.map_index][v.event_index] then
				dpsInfo[v.map_index][v.event_index] = {}
			end

			dpsInfo[v.map_index][v.event_index][v.user_id] = v.dps

			if InfoDungeon.getMapIndex() == v.map_index and WarMachine.checkEventIndex(v.event_index) then
				notify.dispatch("dps_changed")
			end
		end
	end

	local hp_hero = data.hp_hero

	if hp_hero then
		local user_id_map = {}

		for i, v in ipairs(hp_hero) do
			if not heroHpInfo[v.user_id] then
				heroHpInfo[v.user_id] = {}
			end

			if heroHpInfo[v.user_id][v.pos] then
				heroHpInfo[v.user_id][v.pos].hp = v.hp
			else
				heroHpInfo[v.user_id][v.pos] = v
			end

			user_id_map[v.user_id] = 1
		end

		for user_id, v in pairs(user_id_map) do
			OnlineCamp.syncHero(user_id)
		end
	end
end

function OnlineCamp.onSyncPass(data)
	pass_count = data.pass_count
	pass_total = data.pass_total

	notify.dispatch("pass_changed")
end

local monsterHpCache, heroHpCache = nil

function OnlineCamp.uploadMonsterHp(v, offset)
	if not monsterHpCache then
		monsterHpCache = {}
	end

	if not monsterHpCache[v.map_index] then
		monsterHpCache[v.map_index] = {}
	end

	if not monsterHpCache[v.map_index][v.event_index] then
		monsterHpCache[v.map_index][v.event_index] = {}
	end

	if not monsterHpCache[v.map_index][v.event_index][v.index] then
		monsterHpCache[v.map_index][v.event_index][v.index] = 0
	end

	monsterHpCache[v.map_index][v.event_index][v.index] = monsterHpCache[v.map_index][v.event_index][v.index] + offset
end

function OnlineCamp.uploadHeroHp(pos, hp, isFlush)
	if not heroHpCache then
		heroHpCache = {}
	end

	local user_id = InfoUser.getID()

	if not heroHpCache[user_id] then
		heroHpCache[user_id] = {}
	end

	if not heroHpCache[user_id][pos] then
		heroHpCache[user_id][pos] = hp
	end

	if isFlush then
		OnlineCamp.flushHP()
	end
end

function OnlineCamp.flushHP()
	if monsterHpCache or heroHpCache then
		local hp_monster = {}
		local hp_hero = {}

		if monsterHpCache then
			for map_index, v1 in pairs(monsterHpCache) do
				for event_index, v2 in pairs(v1) do
					for index, offset in pairs(v2) do
						table.insert(hp_monster, {
							map_index = map_index,
							event_index = event_index,
							index = index,
							hp_dmg = math.max(0, -offset)
						})
					end
				end
			end
		end

		if heroHpCache then
			for user_id, v1 in pairs(heroHpCache) do
				for pos, hp in pairs(v1) do
					table.insert(hp_hero, {
						user_id = user_id,
						pos = pos,
						hp = hp
					})
				end
			end
		end

		monsterHpCache = nil
		heroHpCache = nil

		local function callback(rcvData)
			if rcvData.err then
				if onFailure then
					onFailure()
				end
			elseif onSuccess then
				onSuccess()
			end
		end

		local params = {
			hp_monster = hp_monster,
			hp_hero = hp_hero
		}

		Connection.request("camp_sync_hp", params, callback)
	end
end

local battleLoopTime, battleEventData = nil

function OnlineCamp.battleStart(eventData, onSuccess, onFailure)
	if inRoom == 2 then
		battleEventData = eventData
		battleLoopTime = Time.time()

		Looper.startLoop(OnlineCamp, OnlineCamp.battleUpdate)

		local function callback(rcvData)
			if rcvData.err then
				if onFailure then
					onFailure(rcvData.err)
				end
			elseif onSuccess then
				onSuccess(rcvData)
			end
		end

		OnlineCamp.battleJump(eventData.index)
		Connection.request("camp_battle_start", {
			map_index = InfoDungeon.getMapIndex(),
			event_index = battleEventData.index
		}, callback)
	end
end

function OnlineCamp.battleOver(onSuccess, onFailure)
	if battleEventData then
		Looper.stopLoop(OnlineCamp, OnlineCamp.battleUpdate)
		OnlineCamp.flushHP()

		local function callback(rcvData)
			if rcvData.err then
				if onFailure then
					onFailure(rcvData.err)
				end
			elseif onSuccess then
				onSuccess(rcvData)
			end
		end

		Connection.request("camp_battle_over", {
			map_index = InfoDungeon.getMapIndex(),
			event_index = battleEventData.index
		}, callback)

		battleEventData = nil
	end
end

function OnlineCamp.dieout(onSuccess, onFailure)
	if battleEventData then
		Looper.stopLoop(OnlineCamp, OnlineCamp.battleUpdate)
		OnlineCamp.flushHP()

		local function callback(rcvData)
			if rcvData.err then
				if onFailure then
					onFailure(rcvData.err)
				end
			elseif onSuccess then
				onSuccess(rcvData)
			end
		end

		Connection.request("camp_dieout", callback)

		battleEventData = nil
	end
end

function OnlineCamp.battleUpdate()
	local now = Time.time()

	if now - battleLoopTime >= 0.5 then
		OnlineCamp.flushHP()

		battleLoopTime = now
	end
end

function OnlineCamp.inRoom()
	return inRoom
end

function OnlineCamp.clearOnScene()
	battleInfo = {}
	monsterHpInfo = {}
	heroHpInfo = {}
	pass_count = 0
	pass_total = 0
	onlinePlayerMap = {}
	onlineDataMap = {}
	dpsInfo = {}
end

function OnlineCamp.clearAll()
	for user_id, onlinePlayer in pairs(onlinePlayerMap) do
		if onlinePlayer.getTrainUnits then
			local units = onlinePlayer:getTrainUnits()

			for i, unit in ipairs(units) do
				unit:clear()
				unit:removeSelf()
			end
		end
	end

	onlinePlayerMap = {}

	notify.dispatch("online_player_change")
end

function OnlineCamp.showTitle(onlinePlayer)
	local data = onlinePlayer.onlineData
	local user_info = data.user_info
	local abyss_level = data.abyss_level

	onlinePlayer:setTitle(user_info.nickname, user_info.nicklang, abyss_level, nil, data.medals, data.union_info)
end

function OnlineCamp.onEnter(data)
	data.user_id = data.user_info.user_id
	onlineDataMap[data.user_id] = data

	if onlinePlayerMap[data.user_id] then
		OnlineCamp.onExit(data)
	end

	if data.appear then
		local appearData = json.decode(data.appear)
		local user_info = data.user_info
		local abyss_level = data.abyss_level
		local onlinePlayer = nil

		if appearData then
			local mapX, mapY = global.map:tileToMap(data.x, data.y)
			local tile = global.map:mapToTile(mapX, mapY)

			if tile then
				for i, v in ipairs(appearData.team) do
					v.level = 1
					v.quality = 0

					for i = 1, 5 do
						v["skill_enc_" .. i] = 0
					end

					if i == 1 then
						onlinePlayer = OnlinePlayer.new()

						onlinePlayer:setInfo(v)

						onlinePlayer.onlineData = data

						onlinePlayer:display(global.map, mapX, mapY)
					else
						local unit = OnlinePlayer.new()

						unit:setInfo(v)

						unit.onlineData = data

						unit:display(global.map, mapX, mapY)
						onlinePlayer:addToTrain(unit)
					end
				end

				if onlinePlayer then
					OnlineCamp.showTitle(onlinePlayer)

					onlinePlayerMap[data.user_id] = onlinePlayer

					notify.dispatch("online_player_change")
				end
			end
		end
	end
end

function OnlineCamp.onExit(data)
	if onlinePlayerMap[data.user_id] then
		local onlinePlayer = onlinePlayerMap[data.user_id]

		if onlinePlayer then
			local units = onlinePlayer:getTrainUnits()

			for i, unit in ipairs(units) do
				unit:clear()
				unit:removeSelf()
			end
		end

		onlinePlayerMap[data.user_id] = nil

		notify.dispatch("online_player_change")
	end
end

function OnlineCamp.onMove(data)
	if onlinePlayerMap[data.user_id] then
		local onlinePlayer = onlinePlayerMap[data.user_id]
		local mapX, mapY = global.map:tileToMap(data.x, data.y)

		if onlinePlayer.go then
			Map.walkOnVislble = false
			local result = onlinePlayer:go(mapX, mapY)
			Map.walkOnVislble = true
		end
	end
end

function OnlineCamp.onEmoji(data)
	if onlinePlayerMap[data.user_id] then
		local onlinePlayer = onlinePlayerMap[data.user_id]
		local emojiCSV = CsvParser.getCsvData("emoji", data.id, nil, true)

		if emojiCSV then
			local model = emojiCSV.model

			onlinePlayer:removeLastingEffect(model, true)

			if onlinePlayer.preEmojiModel then
				onlinePlayer:removeLastingEffect(onlinePlayer.preEmojiModel)
			end

			onlinePlayer.preEmojiModel = model
			local effect = onlinePlayer:addLastingEffect(model, MiscConfig.EMOJI_TIME, true)

			if effect then
				effect:rawSetScale(MiscConfig.EMOJI_SCALE)
			end
		end
	end
end

function OnlineCamp.onSummon(data)
	inRoom = 2

	InfoDungeon.reload(data)
end

function OnlineCamp.onUpdateAppear(data)
	local hero_id = data.hero_id
	local onlinePlayer = onlinePlayerMap[data.user_id]

	if onlinePlayer then
		local unit = onlinePlayer:findInTrain(hero_id)

		if unit then
			local v = json.decode(data.appear)
			v.level = 1
			v.quality = 0

			for i = 1, 5 do
				v["skill_enc_" .. i] = 0
			end

			unit:setInfo(v)
		end
	end
end

function OnlineCamp.onUpdateMedals(data)
	local onlinePlayer = onlinePlayerMap[data.user_id]

	if onlinePlayer then
		onlinePlayer.onlineData.medals = data.medals

		OnlineCamp.showTitle(onlinePlayer)
	end
end

function OnlineCamp.onPlaySong(data)
	local itemCSV = CsvParser.getCsvData("item", data.id)
	local songName = itemCSV.use_value1

	if not empty(songName) and Sound.playMusicOnce(songName) then
		POP_notify.add(300001, 10, data.username, itemCSV.name)
	end
end

function OnlineCamp.onAction(data)
	local onlinePlayer = onlinePlayerMap[data.user_id]

	if onlinePlayer then
		local params = {}

		if data.params then
			params = json.decode(data.params)
		end

		onlinePlayer:doAction(data.id, params)
	end
end

function OnlineCamp.getOnlinePlayers()
	local arr = {}

	for user_id, unit in pairs(onlinePlayerMap) do
		table.insert(arr, unit.onlineData)
	end

	table.sort(arr, function (a, b)
		return b.abyss_level < a.abyss_level
	end)

	return arr
end

function OnlineCamp.tryExit()
	if OnlineCamp.inRoom() == 1 then
		OnlineCamp.exit()
	end
end

function OnlineCamp.tryEnter(onSuccess, onFailure)
	if global.player then
		OnlineCamp.clearAll()

		local isOnlineCamp = Cookie.get("isOnlineCamp") or 1

		if isOnlineCamp == 1 and InfoGuide.isFin() then
			local mapName = DungeonScene.currentMap
			local type = TYPE.DEFAULT

			if InfoDungeon.isHome() then
				mapName = InfoHome.getOnlineMapName()
				type = TYPE.HOME
			end

			if InfoUnion.inMap() then
				mapName = InfoUnion.getOnlineMapName()
				type = TYPE.UNION
			end

			OnlineCamp.enter(mapName, type, global.player.tile.x, global.player.tile.y, onSuccess, onFailure)
		end
	end
end

function OnlineCamp.enter(map_name, type, x, y, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			inRoom = 1

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("camp_enter", {
		map_name = map_name,
		type = type,
		x = x,
		y = y
	}, callback)
end

function OnlineCamp.exit(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			inRoom = nil

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("camp_exit", callback)
end

function OnlineCamp.summon(x, y, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			OnlineCamp.initHpInfo(rcvData.hp_monster, rcvData.hp_hero)

			pass_count = rcvData.pass_count
			pass_total = rcvData.pass_total

			notify.dispatch("pass_changed")

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("camp_summon", {
		x = x,
		y = y
	}, callback)
end

function OnlineCamp.recover(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("camp_recover", callback)
end

function OnlineCamp.move(x, y, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("camp_move", {
		x = x,
		y = y
	}, callback)
end

function OnlineCamp.emoji(id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("camp_emoji", {
		id = id
	}, callback)
end

function OnlineCamp.look(id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("camp_look", {
		user_id = id
	}, callback)
end

function OnlineCamp.updateAppear(hero_id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("camp_appear_update", {
		hero_id = hero_id
	}, callback)
end

function OnlineCamp.updateMedals(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "camp_medals_update")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("camp_medals_update", callback)
end

function OnlineCamp.playSong(id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("camp_play_song", {
		id = id
	}, callback)
end

function OnlineCamp.doAction(id, params, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	local obj = {
		id = id
	}

	if params then
		obj.params = json.encode(params)
	end

	Connection.request("camp_action", obj, callback)
end

return OnlineCamp
