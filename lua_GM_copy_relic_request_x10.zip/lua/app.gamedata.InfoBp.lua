local InfoBp = {}
local rawData = {}

function InfoBp.init()
	Connection.listen("bp_sync", InfoBp.sync)
end

app:addToAppEnterCall(InfoBp.init)

function InfoBp.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoBp.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("bp_query", callback)
end

function InfoBp.onQuery(rcvData)
	dump(rcvData, "bp_query")

	rawData = {}

	for i, v in ipairs(rcvData.list) do
		rawData[v.id] = v
	end
end

function InfoBp.sync(data)
	dump(data, "$$$ InfoBp.sync")

	if data.is_all == 1 then
		rawData = {}

		for i, data in ipairs(data.list) do
			rawData[data.id] = data
		end
	else
		for i, data in ipairs(data.list) do
			if not rawData[data.id] then
				rawData[data.id] = data
			else
				for k, v in pairs(data) do
					rawData[data.id][k] = v
				end
			end
		end
	end

	notify.dispatch("campaign_changed")
	ManagerInfo.dataChange("bp")
end

function InfoBp.getCurrent()
	local arr = {}
	local nowTime = math.floor(Time.now())

	for k, v in pairs(rawData) do
		if v.close ~= 1 and v.stime <= nowTime and nowTime < v.etime then
			table.insert(arr, v)
		end
	end

	if #arr > 0 then
		table.sort(arr, function (a, b)
			return b.session < a.session
		end)

		return arr[1]
	end
end

function InfoBp.getRecord(bpData, index, isPay)
	local section, position = BitUtil.split(30, index)
	local recordNum = nil

	if isPay then
		recordNum = bpData["pay_record_" .. section]
	else
		recordNum = bpData["free_record_" .. section]
	end

	return BitUtil.getBitByIndex(recordNum, position)
end

function InfoBp.getExp(bpData)
	return bpData.exp
end

function InfoBp.getPassLevel(bpData)
	local exp = InfoBp.getExp(bpData)
	local csvList = CsvParser.getCsvList("bp_gift", nil, {
		pass_id = bpData.base_id
	})
	local level = 0
	local expLeft = exp
	local expTotal = 100
	local isMax = true

	for i, csv in ipairs(csvList) do
		exp = exp - csv.next_exp

		if exp >= 0 then
			level = csv.pass_level
			expLeft = exp
		else
			expTotal = csv.next_exp
			isMax = false

			break
		end
	end

	return level, expLeft, expTotal, isMax
end

function InfoBp.isPaid(bpData)
	return bpData.paid > 0
end

function InfoBp.getPassExpMax(bpData)
	local exp = 0
	local csvList = CsvParser.getCsvList("bp_gift", nil, {
		pass_id = bpData.base_id
	})

	for i, csv in ipairs(csvList) do
		exp = exp + csv.next_exp
	end

	return exp
end

function InfoBp.getGiftList(bpData)
	local csvList = CsvParser.getCsvList("bp_gift", "id", {
		pass_id = bpData.base_id
	})

	return csvList
end

function InfoBp.getNextSpReward(bpData)
	local csvList = InfoBp.getGiftList(bpData)

	for i, v in ipairs(csvList) do
		if v.pay_reward_sp == 1 and InfoBp.getRecord(bpData, i, true) == 0 then
			return v
		end
	end
end

function InfoBp.countRedot(bpData)
	local redotCount = 0
	local level = InfoBp.getPassLevel(bpData)
	local csvList = InfoBp.getGiftList(bpData)

	for i, v in ipairs(csvList) do
		if v.pass_level <= level then
			local reward_arr = SheetUtil.getColumnList(v, {
				"free_reward_",
				"free_num_"
			}, {
				"base_id",
				"num"
			})
			local hasFree = #reward_arr > 0
			local reward_arr = SheetUtil.getColumnList(v, {
				"pay_reward_",
				"pay_num_"
			}, {
				"base_id",
				"num"
			})
			local hasPay = #reward_arr > 0

			if hasFree and InfoBp.getRecord(bpData, i) == 0 or hasPay and InfoBp.getRecord(bpData, i, true) == 0 and InfoBp.isPaid(bpData) then
				redotCount = redotCount + 1
			end
		else
			break
		end
	end

	return redotCount
end

function InfoBp.getHeat(bpData)
	local myData = InfoBpOverall.getData()
	local heat = 0

	if bpData.session - myData.pre_session <= 1 then
		heat = myData.heat
	else
		heat = math.max(0, myData.heat - (bpData.session - myData.pre_session - 1))
	end

	local csvList = CsvParser.getCsvList("bp_heat")
	local heatCSV = csvList[1]

	for i, csv in ipairs(csvList) do
		if csv.num <= heat then
			heatCSV = csv
		end
	end

	return heat, heatCSV
end

function InfoBp.getReward(bp_id, index, is_pay, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "bp_get_reward")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("bp_get_reward", {
		bp_id = bp_id,
		index = index,
		is_pay = is_pay
	}, callback)
end

function InfoBp.getRewardAll(bpData, onSuccess, onFailure)
	local arr = {}
	local level = InfoBp.getPassLevel(bpData)
	local csvList = InfoBp.getGiftList(bpData)

	for i, v in ipairs(csvList) do
		if v.pass_level <= level then
			local reward_arr = SheetUtil.getColumnList(v, {
				"free_reward_",
				"free_num_"
			}, {
				"base_id",
				"num"
			})
			local hasFree = #reward_arr > 0
			local reward_arr = SheetUtil.getColumnList(v, {
				"pay_reward_",
				"pay_num_"
			}, {
				"base_id",
				"num"
			})
			local hasPay = #reward_arr > 0

			if hasFree and InfoBp.getRecord(bpData, i) == 0 then
				table.insert(arr, {
					is_pay = 0,
					index = i
				})
			end

			if hasPay and InfoBp.getRecord(bpData, i, true) == 0 and InfoBp.isPaid(bpData) then
				table.insert(arr, {
					is_pay = 1,
					index = i
				})
			end
		else
			break
		end
	end

	if #arr > 0 then
		local function callback(rcvData)
			dump(rcvData, "bp_get_reward_all")

			if rcvData.err then
				if onFailure then
					onFailure(rcvData.err)
				end
			elseif onSuccess then
				onSuccess(rcvData)
			end
		end

		Connection.request("bp_get_reward_all", {
			list = arr,
			bp_id = bpData.id
		}, callback)
	end
end

function InfoBp.buyExp(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ bp_buy_exp")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("bp_buy_exp", callback)
end

return InfoBp
