local InfoManualReward = {}
local rawData = {}

function InfoManualReward.init()
	Connection.listen("manual_reward_sync", InfoManualReward.sync)
end

app:addToAppEnterCall(InfoManualReward.init)

function InfoManualReward.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoManualReward.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("manual_reward_query", callback)
end

function InfoManualReward.onQuery(rcvData)
	rawData = rcvData
end

function InfoManualReward.sync(data)
	for k, v in pairs(data) do
		rawData[k] = v
	end

	ManagerInfo.dataChange("manual_reward", data)
end

function InfoManualReward.getReward(id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("manual_reward_get_reward", {
		id = id
	}, callback)
end

function InfoManualReward.getCSV(type, value)
	local csvMap = CacheData.get("InfoManualReward_csvMap")

	if not csvMap then
		csvMap = {}
		local csvRaw = CsvParser.getCsvRaw("manual_reward")

		for k, csv in pairs(csvRaw) do
			csvMap[csv.type .. "_" .. csv.value] = csv
		end

		CacheData.set("InfoManualReward_csvMap", csvMap)
	end

	return csvMap[type .. "_" .. value]
end

function InfoManualReward.getRecord(index)
	local section, position = BitUtil.split(30, index)
	local recordNum = rawData["record_" .. section]

	return BitUtil.getBitByIndex(recordNum, position)
end

function InfoManualReward.getFishNum(value)
	local num = 0
	local max = 0

	if value == 1 then
		local csvList = CsvParser.getCsvList("fishing_fish", nil, {
			type = 1
		})

		for i, csv in ipairs(csvList) do
			if csv.fish_type == 1 or csv.fish_type == 2 then
				max = max + 1
				local myWeight = InfoFishing.getBestWeight(csv.id)

				if myWeight then
					num = num + 1
				end
			end
		end
	elseif value == 2 then
		local fish_king_percent = CsvParser.getCsvData("config", "fish_king_percent").value
		local csvList = CsvParser.getCsvList("fishing_fish", nil, {
			type = 1,
			fish_type = 1
		})

		for i, csv in ipairs(csvList) do
			max = max + 1
			local myWeight = InfoFishing.getBestWeight(csv.id)

			if myWeight then
				local maxWeight = InfoFishing.getMaxWeight(csv.id)

				if fish_king_percent <= myWeight / maxWeight * 100 then
					num = num + 1
				end
			end
		end
	elseif value == 3 then
		local fish_king_percent = CsvParser.getCsvData("config", "fish_king_percent").value
		local csvList = CsvParser.getCsvList("fishing_fish", nil, {
			type = 1,
			fish_type = 2
		})

		for i, csv in ipairs(csvList) do
			max = max + 1
			local myWeight = InfoFishing.getBestWeight(csv.id)

			if myWeight then
				local maxWeight = InfoFishing.getMaxWeight(csv.id)

				if fish_king_percent <= myWeight / maxWeight * 100 then
					num = num + 1
				end
			end
		end
	end

	return num, max
end

function InfoManualReward.countRedot()
	local redotCount = 0

	return redotCount
end

return InfoManualReward
