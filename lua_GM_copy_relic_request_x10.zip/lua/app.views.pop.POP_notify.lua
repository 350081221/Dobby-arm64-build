local POP_notify = class("POP_notify", UI_base)

function POP_notify.add(notice_id, time, ...)
	if POP_notify.instance then
		local data = {
			notice_id = notice_id,
			time = time,
			replace = {
				...
			}
		}

		POP_notify.instance:addOne(data)
	end
end

function POP_notify:ctor(rect, typeArr)
	POP_notify.super.ctor(self, "pop_notify", UIManager.BIG_TYPE.BOTTOM)

	POP_notify.instance = self
	self.rect = rect
	self.spaceY = 32
	self.uiName = "pop_notify_one"
	self.typeMap = {}

	if typeArr then
		for i, v in ipairs(typeArr) do
			self.typeMap[v] = true
		end
	end

	self:setPosition(rect.x, rect.y)
	self:init()
end

function POP_notify:init()
	self.oneStack = {}
	local container = display.newClippingRectangleNode(cc.rect(0, 0, self.rect.width + 1, self.rect.height + 1))

	self:addChild(container, 100)

	self.container = container

	notify.safeRegister(self, "notify_push", function (data)
		if self.actived then
			self:addOne(data)
		end
	end)
end

local defaultStayTime = 5

function POP_notify:addOne(data, customCreateTime)
	local csv = CsvParser.getCsvData("notify", data.notice_id)

	if not csv then
		return
	end

	if not self.typeMap[csv.type] then
		return
	end

	local replaceArr = {}

	if data.replace then
		for i, v in ipairs(data.replace) do
			table.insert(replaceArr, Localization.getTextByLang(v))
		end
	end

	local towerID = nil

	if csv.type == 1 then
		data = ObjUtil.clone(data)
		towerID = tonumber(replaceArr[2])
		local towerCSV = CsvParser.getCsvData("tower", towerID)
		local abyssLevel = InfoDungeon.getAbyssMaxLevel()

		if abyssLevel < towerCSV.unlock_level then
			return
		else
			replaceArr[2] = towerCSV.name
		end
	end

	dump(data, "$$$ addOne")

	local stayTime = data.time or defaultStayTime
	local one = UIManager.getUI(self.uiName)

	if self.upDown then
		one:setPositionY(self.rect.height)
	end

	local bg = one:getComponentByTag("bg")

	bg:setSize(self.rect.width)

	local bg1 = one:getComponentByTag("bg1")

	bg1:setSize(self.rect.width)
	bg1:setOpacity(0)

	if csv.type == 1 then
		bg1:toTouchable()
		bg1:addTap(function ()
			local towerCSV = CsvParser.getCsvData("tower", towerID)
			local inst_id = tonumber(replaceArr[3])

			if towerCSV and inst_id then
				local str = Localization.getSrcText("要加入[color={1}]{2}[/color]房间吗?")

				POP_notice.open(StringUtil.replace(str, Style.goldenStr, InfoUser.encodeID(inst_id)), function ()
					InfoTower.join(towerID, inst_id, function (rcvData)
						FRAME_unified_room.open(towerCSV, rcvData)
					end)
				end)
			end
		end)
	end

	local text = csv.text

	if replaceArr and #replaceArr > 0 then
		text = StringUtil.replace(text, unpack(replaceArr))
	end

	local ubbMap, labels, lines, totalWidth, totalHeight = one:createUbbOnFlag("flag_text", text, {
		align = Style.left,
		valign = Style.vcenter
	})
	local textFlag = one:getFlagByTag("flag_text")

	bg:setSize(math.min(self.rect.width, totalWidth + textFlag.x + 5))

	if not empty(csv.icon) then
		one:createIconOnFlag("flag_icon", IconManager.getMiscIcon(csv.icon), 100, true)
	end

	self.container:addChild(one)
	table.insert(self.oneStack, one)

	one.createTime = customCreateTime or Time.time()
	one.stayTime = stayTime

	self:addEnterFrame("arrange_loop", function ()
		self:arrange()
	end)
end

function POP_notify:arrange()
	local nowTime = Time.time()
	local oneStack = self.oneStack
	local removeArr = {}

	if self.upDown then
		for i, one in ipairs(oneStack) do
			local y = self.rect.height - self.spaceY * (#oneStack - i + 1)
			local currentY = one:getPositionY()

			one:setPositionY((y - currentY) / 2 + currentY)

			if not one.removed and (y < 0 or one.stayTime < nowTime - one.createTime) then
				one.removed = true

				table.insert(removeArr, one)
			end
		end
	else
		for i, one in ipairs(oneStack) do
			local y = self.spaceY * (#oneStack - i)
			local currentY = one:getPositionY()

			one:setPositionY((y - currentY) / 2 + currentY)

			if not one.removed and (self.rect.height < y or one.stayTime < nowTime - one.createTime) then
				one.removed = true

				table.insert(removeArr, one)
			end
		end
	end

	for i, one in ipairs(removeArr) do
		transition.fadeTo(one, {
			easing = "linear",
			time = 0.2,
			opacity = 100,
			onComplete = function ()
				for j, v in ipairs(oneStack) do
					if v == one then
						table.remove(oneStack, j)
					end
				end

				one:removeSelf()
			end
		})
	end

	if #oneStack == 0 then
		self:removeEnterFrame("arrange_loop")
	end
end

function POP_notify:setUpDown(upDown)
	self.upDown = upDown
end

function POP_notify:setActive(actived)
	self.actived = actived
end

function POP_notify:setSpaceY(spaceY)
	self.spaceY = spaceY
end

function POP_notify:setUIName(uiName)
	self.uiName = uiName
end

function POP_notify:addItems(items)
	for i, v in ipairs(items) do
		self:addOne(v.data, v.time)
	end
end

function POP_notify:onExit()
	self:removeEnterFrame("arrange_loop")

	POP_notify.instance = nil

	POP_notify.super.onExit(self)
end

return POP_notify
