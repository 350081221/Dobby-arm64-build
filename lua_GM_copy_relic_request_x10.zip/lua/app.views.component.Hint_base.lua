local UI_base = import("..UI_base")
local Hint_base = class("Hint_base", UI_base)

function Hint_base:ctor(uiName)
	Hint_base.super.ctor(self, uiName)

	local line = self:getComponentByTag("line")

	line:setVisible(false)
end

function Hint_base:addContent(node)
	if not self.contentCount then
		local contentFlag = self:getFlagByTag("flag_content")
		local line = self:getComponentByTag("line")
		self.startY = contentFlag.y + contentFlag.height
		self.currentY = self.startY
		self.spaceY = contentFlag.y - line.y
		self.contentCount = 0
	end

	local size = node:getContentSize()

	node:setPositionY(self.currentY - node:getAnchorPoint().y * size.height)

	if self.contentCount > 0 then
		local line = self:duplicateComponentByTag("line")

		line:setPositionY(self.currentY + line.height / 2)
	end

	self.contentCount = self.contentCount + 1
	self.currentY = self.currentY - size.height - self.spaceY
	local bg = self:getComponentByTag("bg")

	bg:setSize(nil, -(self.currentY + self.startY / 2))
	bg:setPos(nil, self.currentY + self.startY / 2)
end

return Hint_base
