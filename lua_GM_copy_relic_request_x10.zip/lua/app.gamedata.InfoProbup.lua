local InfoProbup = {}
local openMap = {}

function InfoProbup.init()
	Connection.listen("probup_sync", InfoProbup.sync)
end

app:addToAppEnterCall(InfoProbup.init)

function InfoProbup.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoProbup.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("probup_query", callback)
end

function InfoProbup.onQuery(rcvData)
	dump(rcvData, "probup_query")

	openMap = {}

	for i, v in ipairs(rcvData.list) do
		openMap[v.actv_id] = openMap[v.actv_id] or {}
		openMap[v.actv_id][v.id] = v.open
	end
end

function InfoProbup.sync(data)
	dump(data, "InfoProbup.sync")

	openMap = {}

	for i, v in ipairs(data.list) do
		openMap[v.actv_id] = openMap[v.actv_id] or {}
		openMap[v.actv_id][v.id] = v.open
	end

	ManagerInfo.dataChange("probup")
end

function InfoProbup.checkOpening(actv_id)
	local opening = InfoActv.checkBindOpening(actv_id, GameConfig.ACTV_TYPE.probup)

	return opening, actv_id
end

function InfoProbup.getList(typeArr, customeActvID)
	local maxOpenMap = {}

	for actv_id, pMap in pairs(openMap) do
		if (not customeActvID or customeActvID == actv_id) and InfoProbup.checkOpening(actv_id) then
			for id, v in pairs(pMap) do
				if v > 0 then
					if maxOpenMap[id] then
						maxOpenMap[id] = math.max(maxOpenMap[id], v)
					else
						maxOpenMap[id] = v
					end
				end
			end
		end
	end

	local csvList = CsvParser.getCsvList("probup")
	local arr = {}

	for i, csv in ipairs(csvList) do
		local typeOK = false

		if not typeArr then
			typeOK = true
		elseif type(typeArr) == "table" then
			for j, v in ipairs(typeArr) do
				if csv.type == v then
					typeOK = true

					break
				end
			end
		else
			typeOK = csv.type == typeArr
		end

		if typeOK and maxOpenMap[csv.id] and maxOpenMap[csv.id] > 0 then
			table.insert(arr, {
				id = csv.id,
				open = maxOpenMap[csv.id]
			})
		end
	end

	table.sort(arr, function (a, b)
		if a.open == b.open then
			return a.id < b.id
		else
			return b.open < a.open
		end
	end)

	return arr
end

return InfoProbup
