local InfoUnion = {}
local unionShopList, shopList = nil
local shopRefreshIndex = 0
local buildingData = {}
local UNION_WAR_STEP = {
	ROUND_SETTING = 100,
	ENROLL = 1,
	INVALID = 0,
	WAR_END = 999,
	WAR_WATING_END = 998,
	ROUND_FIGHTING = 102,
	ROUND_WATING_START = 101
}
InfoUnion.UNION_WAR_STEP = UNION_WAR_STEP
local UNION_OFFICIAL = {
	MEMBER = 3,
	LEADER_ASSISTANT = 2,
	LEADER = 1
}
InfoUnion.UNION_OFFICIAL = UNION_OFFICIAL
local rawData = nil

function InfoUnion.init()
	Connection.listen("union_base_info_sync", InfoUnion.syncBaseInfo)
	Connection.listen("union_private_info_sync", InfoUnion.syncPrivateInfo)
	Connection.listen("union_building_info_sync", InfoUnion.syncBuildingInfo)
	Connection.listen("union_buff_info_sync", InfoUnion.syncBuffInfo)
	Connection.listen("union_shop_sync", InfoUnion.syncShopInfo)
	Connection.listen("union_pve_info_sync", InfoUnion.syncPveInfo)
end

app:addToAppEnterCall(InfoUnion.init)

function InfoUnion.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoUnion.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("union_query", callback)
end

function InfoUnion.onQuery(rcvData)
	dump(rcvData, "union_query", 10)

	rawData = rcvData
	buildingData = {}

	if rcvData.building_info then
		for i, v in ipairs(rcvData.building_info) do
			buildingData[v.building_tag] = v.building_level
		end
	end
end

function InfoUnion.syncShopInfo(syncData)
	dump(syncData, "syncShopInfo")

	rawData.shop_refresh_time = syncData.shop_refresh_time

	ManagerInfo.dataChange("union")
end

function InfoUnion.syncBuffInfo(syncData)
	dump(syncData, "syncBuffInfo")

	rawData.buff_info = syncData.info

	ManagerInfo.dataChange("union")
end

function InfoUnion.syncBuildingInfo(syncData)
	dump(syncData, "syncBuildingInfo")

	buildingData[syncData.info.building_tag] = syncData.info.building_level

	ManagerInfo.dataChange("union")
end

function InfoUnion.syncBaseInfo(syncData)
	dump(syncData, "syncBaseInfo")

	local info = syncData.info

	if info then
		if rawData.base_info then
			for k, v in pairs(info) do
				rawData.base_info[k] = v
			end
		else
			rawData.base_info = info
		end
	end

	ManagerInfo.dataChange("union")
end

function InfoUnion.syncPrivateInfo(syncData)
	dump(syncData, "syncPrivateInfo")

	local info = syncData.private_info

	if syncData.user_id == InfoUser.getID() then
		local changed = false
		local needGetInfo = false

		if info then
			if rawData.private_info then
				for k, v in pairs(info) do
					rawData.private_info[k] = v
				end
			else
				rawData.private_info = info
			end

			changed = true
		end

		print("$$$ syncPrivateInfo", syncData.union_id, rawData.base_info.union_id)

		if syncData.union_id and syncData.union_id ~= rawData.base_info.union_id then
			rawData.base_info.union_id = syncData.union_id
			changed = true
			needGetInfo = true
		end

		print("$$$ changed", changed)

		if changed then
			if needGetInfo then
				local unionID = rawData.base_info.union_id

				if unionID and unionID > 0 then
					InfoUnion.getInfo(unionID, true, function (rcvData)
						ManagerInfo.dataChange("union")
					end)
				end
			else
				ManagerInfo.dataChange("union")
			end

			InfoUnion.checkLeaveMap()
		end
	end
end

function InfoUnion.checkLeaveMap()
	if not InfoUnion.hasUnion() and InfoUnion.inMap() then
		InfoDungeon.enterCamp()
	end
end

function InfoUnion.create(params, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_create")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			InfoUnion.resetBuilding()

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("union_create", {
		info = params
	}, callback)
end

function InfoUnion.modify(params, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_modify")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("union_modify", {
		info = params
	}, callback)
end

function InfoUnion.search(union_id, union_name, union_type, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_list_query", 10)

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("union_list_query", {
		union_id = union_id,
		union_name = union_name,
		union_type = union_type
	}, callback)
end

local unionInfoCache, unionInfoCacheTime = nil

function InfoUnion.getInfoCache()
	if unionInfoCache and unionInfoCacheTime and Time.time() - unionInfoCacheTime < MiscConfig.union_cache_time then
		return unionInfoCache
	end
end

function InfoUnion.getInfo(union_id, isSelf, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if InfoUnion.hasUnion() and rcvData.union_info.union_id == rawData.base_info.union_id and isSelf then
				rawData.base_info = rcvData.union_info
				rawData.join_request_info = rcvData.join_request_info

				ManagerInfo.dataChange("union_answer")

				unionInfoCache = rcvData
				unionInfoCacheTime = Time.time()
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("union_info", {
		union_id = union_id
	}, callback)
end

function InfoUnion.getSelfInfo(onSuccess, onFailure)
	if InfoUnion.hasUnion() then
		local unionID = rawData.base_info.union_id

		InfoUnion.getInfo(unionID, true, onSuccess, onFailure)
	end
end

function InfoUnion.refreshBuffInfo(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_buff_info", 10)

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if rcvData.buff_info then
				rawData.buff_info = rcvData.buff_info
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("union_buff_info", callback)
end

function InfoUnion.join(union_id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_join 1", 10)

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("union_join", {
		is_join = 1,
		union_id = union_id
	}, callback)
end

function InfoUnion.joinCancel(union_id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_join 0", 10)

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("union_join", {
		is_join = 0,
		union_id = union_id
	}, callback)
end

function InfoUnion.joinPass(user_id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_join_answer 1", 10)

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			InfoUnion.removeFromJoinList(user_id)
			ManagerInfo.dataChange("union")

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("union_join_answer", {
		is_pass = 1,
		user_id = user_id
	}, callback)
end

function InfoUnion.joinReject(user_id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_join_answer 2", 10)

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			InfoUnion.removeFromJoinList(user_id)
			ManagerInfo.dataChange("union_answer")

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("union_join_answer", {
		is_pass = 2,
		user_id = user_id
	}, callback)
end

function InfoUnion.exit(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_exit")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			rawData.base_info.union_id = 0

			ManagerInfo.dataChange("union")
			InfoUnion.checkLeaveMap()

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("union_exit", callback)
end

function InfoUnion.appoint(user_id, official_title, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_appoint")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("union_appoint", {
		user_id = user_id,
		official_title = official_title
	}, callback)
end

function InfoUnion.kick(user_id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_kick")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("union_kick", {
		user_id = user_id
	}, callback)
end

function InfoUnion.officialTransfer(user_id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_official_transfer")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("union_official_transfer", {
		user_id = user_id
	}, callback)
end

function InfoUnion.getConfig(key)
	return CsvParser.getCsvData("union_config", key).value
end

function InfoUnion.hasUnion()
	return rawData.base_info and not empty(rawData.base_info.union_id)
end

function InfoUnion.getUnionInfo()
	return rawData.base_info
end

function InfoUnion.getUnionID()
	if rawData.base_info then
		return rawData.base_info.union_id
	end
end

function InfoUnion.getPrivateInfo()
	return rawData.private_info
end

function InfoUnion.getOfficial()
	if rawData.private_info and rawData.private_info.official_title then
		return rawData.private_info.official_title
	end

	return 0
end

function InfoUnion.getLastExitTime()
	if rawData.private_info and rawData.private_info.last_exit_union_time then
		return rawData.private_info.last_exit_union_time
	end

	return 0
end

function InfoUnion.checkPower(power)
	if InfoUnion.hasUnion() then
		local official = InfoUnion.getOfficial()

		if official > 0 then
			local csv = CsvParser.getCsvData("union_power", official)

			if csv then
				return csv[power] == 1
			end
		end
	end

	return false
end

function InfoUnion.checkJoinList(onSuccess)
	if InfoUnion.hasUnion() and InfoUnion.checkPower("ratify_member") then
		local unionID = InfoUnion.getUnionID()

		InfoUnion.getInfo(unionID, true, function (rcvData)
			if onSuccess then
				onSuccess()
			end
		end)
	end
end

function InfoUnion.hasJoinList()
	if InfoUnion.hasUnion() and InfoUnion.checkPower("ratify_member") and rawData and rawData.join_request_info then
		return #rawData.join_request_info > 0
	end

	return false
end

function InfoUnion.getJoinList()
	if rawData and rawData.join_request_info then
		return rawData.join_request_info
	end

	return {}
end

function InfoUnion.removeFromJoinList(user_id)
	if rawData and rawData.join_request_info then
		for i, v in ipairs(rawData.join_request_info) do
			if v.user_id == user_id then
				table.remove(rawData.join_request_info, i)

				return
			end
		end
	end
end

function InfoUnion.inMap()
	local map = InfoUnion.getConfig("map")

	if map == DungeonScene.currentMap then
		return true
	end
end

function InfoUnion.enterMap(refreshBuilding)
	local function onBuidingInfo()
		notify.dispatch("exit_map")
		Transition.setTitle(Localization.getSrcText("联盟基地"))

		local map = InfoUnion.getConfig("map")

		DungeonState.init()
		DungeonScene.enterMap(DungeonScene.ENTER_TYPE.NEW, map)
	end

	if refreshBuilding then
		InfoUnion.buildingInfoAll(onBuidingInfo)
	else
		onBuidingInfo()
	end
end

function InfoUnion.getOnlineMapName()
	if rawData and rawData.base_info and rawData.base_info.union_id then
		return "union_" .. rawData.base_info.union_id
	end
end

function InfoUnion.clearCache()
	unionInfoCache = nil
	unionInfoCacheTime = nil
end

function InfoUnion.clearOnScene()
	InfoUnion.clearCache()
end

function InfoUnion.resetBuilding()
	local arr = {
		InfoBuilding.TAG.UNION_CENTER,
		InfoBuilding.TAG.UNION_MONO,
		InfoBuilding.TAG.UNION_BUFF_OPEN
	}

	if buildingData then
		for i, tag in ipairs(arr) do
			buildingData[tag] = 1
		end
	end
end

function InfoUnion.getBuildingLevel(tag)
	if InfoUnion.hasUnion() and buildingData[tag] then
		return buildingData[tag]
	end

	return 0
end

function InfoUnion.isBaseLimited(tag)
	if tag ~= InfoBuilding.TAG.UNION_CENTER and InfoUnion.getBuildingLevel(InfoBuilding.TAG.UNION_CENTER) <= InfoUnion.getBuildingLevel(tag) then
		return true
	end

	return false
end

function InfoUnion.getBuildingData(tag, customLevel)
	local buildingLevel = customLevel or InfoUnion.getBuildingLevel(tag)

	if buildingLevel then
		local currentData = CsvParser.getFilteredData("building", {
			tag = tag,
			level = buildingLevel
		})

		if currentData then
			local nextData = CsvParser.getFilteredData("building", {
				tag = tag,
				level = buildingLevel + 1
			})

			return currentData, nextData
		end
	end
end

function InfoUnion.getBuildingFin(id)
	local buildingCSV = CsvParser.getCsvData("building", id)

	if buildingCSV then
		local buildingLevel = InfoUnion.getBuildingLevel(buildingCSV.tag)

		return buildingCSV.level <= buildingLevel
	end
end

function InfoUnion.getBuildingFinAndCsv(id)
	local buildingCSV = CsvParser.getCsvData("building", id)

	if buildingCSV then
		local buildingLevel = InfoUnion.getBuildingLevel(buildingCSV.tag)

		return buildingCSV.level <= buildingLevel, buildingCSV
	end
end

function InfoUnion.buildingLevelup(tag, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_building_upgrade")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			local unionID = InfoUnion.getUnionID()

			if unionID then
				InfoUnion.getInfo(unionID, true, function (rcvData)
					if onSuccess then
						onSuccess()
					end
				end)
			end
		end
	end

	Connection.request("union_building_upgrade", {
		building_tag = tag
	}, callback)
end

function InfoUnion.buildingInfoAll(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_all_building_info")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("union_all_building_info", callback)
end

function InfoUnion.getMonoList()
	local maxLevel = InfoUnion.getBuildingLevel(InfoBuilding.TAG.UNION_MONO)
	local arr = {}

	for level = 1, maxLevel do
		local buildingCSV = InfoUnion.getBuildingData(InfoBuilding.TAG.UNION_MONO, level)

		table.insert(arr, buildingCSV)
	end

	return arr
end

function InfoUnion.enterMonoStage(building_id, isSolo, heroID, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_mono_stage")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			local result = rcvData.dungeon_result
			local title, subTitle = InfoDungeon.getTitle(result.type, result.dungeon_id, result.quest_id, result.abyss_seed)

			Transition.setTitle(title, subTitle)
			Transition.leave(function ()
				if onSuccess then
					onSuccess(result)
				end
			end)
		end
	end

	Connection.request("union_mono_stage", {
		building_id = building_id,
		is_solo = isSolo and 1 or 0,
		solo_hero_id = heroID
	}, callback)
end

local UNION_BUFF_GROUP, UNION_GROUP_MAP, UNION_GROUP_MAX_LEVEL = nil

function InfoUnion.initBuff()
	if not UNION_BUFF_GROUP then
		UNION_BUFF_GROUP = {}
		UNION_GROUP_MAP = {}
		UNION_GROUP_MAX_LEVEL = {}
		local csvList = CsvParser.getCsvList("union_buff")
		local existMap = {}

		for i, csv in ipairs(csvList) do
			if not existMap[csv.group] then
				existMap[csv.group] = true

				table.insert(UNION_BUFF_GROUP, csv.group)
			end

			UNION_GROUP_MAP[csv.group .. "_" .. csv.level] = csv.id

			if not UNION_GROUP_MAX_LEVEL[csv.group] or UNION_GROUP_MAX_LEVEL[csv.group] < csv.level then
				UNION_GROUP_MAX_LEVEL[csv.group] = csv.level
			end
		end
	end
end

function InfoUnion.getBuffMaxLevel(group)
	InfoUnion.initBuff()

	return UNION_GROUP_MAX_LEVEL[group]
end

function InfoUnion.getBuffCsv(group, level)
	InfoUnion.initBuff()

	local id = UNION_GROUP_MAP[group .. "_" .. level]

	return CsvParser.getCsvData("union_buff", id)
end

function InfoUnion.getBuffList()
	InfoUnion.initBuff()

	local levelMap = {}

	if rawData.buff_info and rawData.buff_info.buff_id then
		local buff_id = rawData.buff_info.buff_id

		for i, id in ipairs(buff_id) do
			local csv = CsvParser.getCsvData("union_buff", id)

			if not levelMap[csv.group] then
				levelMap[csv.group] = csv.level
			else
				levelMap[csv.group] = math.max(levelMap[csv.group], csv.level)
			end
		end
	end

	local openMap = {}

	if rawData.buff_info and rawData.buff_info.opening_buff then
		local opening_buff = rawData.buff_info.opening_buff

		for i, v in ipairs(opening_buff) do
			local csv = CsvParser.getCsvData("union_buff", v.buff_id)
			openMap[csv.group] = v.expiration
		end
	end

	local arr = {}
	local alreadyCount = 0
	local openCount = 0

	for i, group in ipairs(UNION_BUFF_GROUP) do
		local data = {
			group = group,
			level = levelMap[group] or 0,
			max = UNION_GROUP_MAX_LEVEL[group],
			open = openMap[group] or 0
		}

		if data.level > 0 then
			alreadyCount = alreadyCount + 1
		end

		if data.open > 0 then
			openCount = openCount + 1
		end

		table.insert(arr, data)
	end

	return arr, alreadyCount, openCount
end

function InfoUnion.getBuffOpenMax()
	local csv = InfoUnion.getBuildingData(InfoBuilding.TAG.UNION_BUFF_OPEN)

	return csv.value1
end

function InfoUnion.getBuffOpenCost()
	local csv = InfoUnion.getBuildingData(InfoBuilding.TAG.UNION_BUFF_OPEN)
	local arr = string.split(csv.value3, ";")

	return {
		base_id = tonumber(arr[1]),
		num = tonumber(arr[2])
	}
end

function InfoUnion.buffStudy(buff_id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_study_buff")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("union_study_buff", {
		buff_id = buff_id
	}, callback)
end

function InfoUnion.buffOpen(buff_id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_open_buff")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("union_open_buff", {
		buff_id = buff_id
	}, callback)
end

function InfoUnion.getMyContribution()
	local privateInfo = InfoUnion.getPrivateInfo()

	if privateInfo then
		return privateInfo.contribution
	end

	return 0
end

function InfoUnion.getUnionRes()
	local union_coin = InfoUnion.getConfig("union_coin")
	local union_res = InfoUnion.getConfig("union_res")
	local arr = {}
	local unionInfo = InfoUnion.getUnionInfo()

	if unionInfo then
		table.insert(arr, {
			base_id = union_coin,
			num = unionInfo.union_money
		})
		table.insert(arr, {
			base_id = union_res,
			num = unionInfo.union_res
		})
	else
		table.insert(arr, {
			num = 0,
			base_id = union_coin
		})
		table.insert(arr, {
			num = 0,
			base_id = union_res
		})
	end

	return arr
end

function InfoUnion.getResourceNum(itemID)
	local union_coin = InfoUnion.getConfig("union_coin")
	local union_res = InfoUnion.getConfig("union_res")
	local unionInfo = InfoUnion.getUnionInfo()

	if unionInfo then
		if itemID == union_coin then
			return unionInfo.union_money
		elseif itemID == union_res then
			return unionInfo.union_res
		end
	end

	return 0
end

function InfoUnion.checkCost(costArr)
	local enough = true
	local lackArr = {}
	local lackStr = ""

	for i, v in ipairs(costArr) do
		local itemID = v.base_id or v.id
		local itemNum = v.num
		local currentNum = InfoUnion.getResourceNum(itemID)

		if currentNum < itemNum then
			enough = false

			table.insert(lackArr, {
				base_id = itemID,
				num = itemNum - currentNum
			})

			local itemData = CsvParser.getCsvData("item", itemID)

			if lackStr ~= "" then
				lackStr = lackStr .. ","
			end

			lackStr = lackStr .. itemData.name .. "x" .. itemNum - currentNum
		end
	end

	if not enough then
		return false, lackArr, lackStr
	end

	return true
end

function InfoUnion.getDonateList()
	local infoMap = {}
	local privateInfo = InfoUnion.getPrivateInfo()

	if privateInfo then
		local infoArr = privateInfo.contribution_info

		for i, v in ipairs(infoArr) do
			infoMap[v.res_type] = v
		end
	end

	local csvArr = CsvParser.getCsvList("union_resource")
	local arr = {}

	for i, csv in ipairs(csvArr) do
		table.insert(arr, {
			base_id = csv.id,
			info = infoMap[csv.id]
		})
	end

	return arr
end

function InfoUnion.donate(itemArr, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_contribution")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	local resArr = {}

	for i, v in ipairs(itemArr) do
		table.insert(resArr, {
			res_type = v.base_id,
			res_num = v.num
		})
	end

	Connection.request("union_contribution", {
		res = resArr
	}, callback)
end

function InfoUnion.getUnionShopList(_callback)
	local needQuery = unionShopList == nil

	if needQuery then
		local function callback(rcvData)
			dump(rcvData, "union_shop_info")

			if rcvData.err then
				-- Nothing
			else
				unionShopList = rcvData.shop_items

				if _callback then
					_callback(unionShopList)
				end
			end
		end

		Connection.request("union_shop_info", callback)
	else
		_callback(unionShopList)
	end
end

function InfoUnion.getUnionShopItems()
	local arr = {}

	for i, v in ipairs(unionShopList) do
		local shopCSV = CsvParser.getCsvData("union_shop", v.goods_id, nil, true)

		if shopCSV then
			table.insert(arr, v)
		end
	end

	table.sort(arr, function (a, b)
		return a.goods_id < b.goods_id
	end)

	return arr
end

function InfoUnion.unionShopbuy(goods_id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_shop_buy")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			local shop_item = rcvData.shop_item

			for i, v in ipairs(unionShopList) do
				if v.goods_id == goods_id then
					for k1, v1 in pairs(shop_item) do
						v[k1] = v1
					end

					break
				end
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("union_shop_buy", {
		goods_id = goods_id
	}, callback)
end

function InfoUnion.getShopLabels()
	local shopCSVList = CsvParser.getCsvList("union_member_shop_label")

	return shopCSVList
end

function InfoUnion.clearOnReconnect()
	shopList = nil
end

function InfoUnion.getShopList(_callback)
	local needQuery = shopList == nil

	if not needQuery and rawData.shop_refresh_time < Time.now() then
		needQuery = true
	end

	if needQuery then
		local function callback(rcvData)
			if rcvData.err then
				-- Nothing
			else
				shopRefreshIndex = shopRefreshIndex + 1
				shopList = rcvData.items

				if _callback then
					_callback(shopList)
				end
			end
		end

		Connection.request("union_member_shop_list", callback)
	else
		_callback(shopList)
	end
end

function InfoUnion.getShopItems()
	local abyssLevel = InfoDungeon.getAbyssMaxLevel()
	local arr = {}
	local multiLabel = nil
	local shopCSVList = CsvParser.getCsvList("union_member_shop_label")

	if #shopCSVList > 1 then
		local labelMap = {}

		for i, v in ipairs(shopList) do
			local shopCSV = CsvParser.getCsvData("union_member_shop", v.shop_id, nil, true)

			if shopCSV and shopCSV.abyss_level_min <= abyssLevel and abyssLevel <= shopCSV.abyss_level_max and (shopCSV.no_supply ~= 1 or v.soldout < shopCSV.times) then
				if not labelMap[shopCSV.label] then
					labelMap[shopCSV.label] = {}
				end

				table.insert(labelMap[shopCSV.label], v)
			end
		end

		for i, v in ipairs(shopCSVList) do
			local itemArr = labelMap[v.id]

			if itemArr then
				table.sort(itemArr, function (a, b)
					return a.shop_id < b.shop_id
				end)

				local obj = {
					label = v,
					items = itemArr
				}

				table.insert(arr, obj)
			end
		end

		multiLabel = true
	else
		local abyssLevel = InfoDungeon.getAbyssMaxLevel()

		for i, v in ipairs(shopList) do
			local shopCSV = CsvParser.getCsvData("union_member_shop", v.shop_id, nil, true)

			if shopCSV and shopCSV.abyss_level_min <= abyssLevel and abyssLevel <= shopCSV.abyss_level_max and (shopCSV.no_supply ~= 1 or v.soldout < shopCSV.times) then
				table.insert(arr, v)
			end
		end

		table.sort(arr, function (a, b)
			return a.shop_id < b.shop_id
		end)

		multiLabel = false
	end

	return arr, multiLabel
end

function InfoUnion.buy(shop_id, num, onSuccess, onFailure)
	local preIndex = shopRefreshIndex

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if rcvData.item then
				local item = rcvData.item

				if preIndex == shopRefreshIndex then
					for i, v in ipairs(shopList) do
						if v.shop_id == item.shop_id then
							for k1, v1 in pairs(item) do
								v[k1] = v1
							end
						end
					end
				end
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("union_member_shop_buy", {
		shop_id = shop_id,
		num = num
	}, callback)
end

function InfoUnion.getShopCSV()
	return "union_member_shop"
end

function InfoUnion.getCostNeed()
	return CsvParser.getCsvData("union_config", "member_shop_need").value
end

function InfoUnion.getShopName()
	return "union_member"
end

function InfoUnion.getShopTime()
	return rawData.shop_refresh_time, RefreshManager.getNextTime(RefreshManager.TYPE.UNION_MEMBER_SHOP, Time.now())
end

function InfoUnion.getRefreshType()
	return RefreshManager.TYPE.UNION_MEMBER_SHOP
end

local LOG_TYPE_CREATE_UNINO = 1001
local LOG_TYPE_BECOMING_LEADER = 1002
local LOG_TYPE_BECOMING_LEADER_ASS = 1003
local LOG_TYPE_BECOMING_MEMBER = 1004
local LOG_TYPE_KICK_MEMBER = 1005
local LOG_TYPE_JOIN_UNION = 1006
local LOG_TYPE_EXIT_UNION = 1007
local LOG_TYPE_CONTRIBUTION = 1008
local LOG_TYPE_UNION_TRANSFER_STAGE = 1009
local LOG_TYPE_UNION_LEADER_ONLINE = 1010
local LOG_TYPE_BUILDING_UPGRADE = 1011
local LOG_TYPE_OPEN_BUFF = 1012
local LOG_TYPE_SUDY_BUFF = 1013
local LOG_TYPE_UNION_WAR_WIN = 1014

local function getLogDesc(data)
	local csv = CsvParser.getCsvData("union_log", data.log_type)
	local log_data = {}

	if not empty(data.log_data) then
		log_data = json.decode(data.log_data) or {}
	end

	local user_info = data.user_info
	local target_user = data.target_user
	local replaceArr = {}
	local styleArr = {}
	local defaultStyle = {
		color = Style.font3
	}

	if data.log_type == LOG_TYPE_CREATE_UNINO then
		table.insert(replaceArr, user_info.nickname or "")
		table.insert(replaceArr, log_data.union_name)

		local style1 = Style.getFontLang(user_info.nicklang)
		style1.color = Style.font3
		local style2 = Style.getFontLang(log_data.lang)
		style2.color = Style.font3

		table.insert(styleArr, style1)
		table.insert(styleArr, style2)
	elseif data.log_type == LOG_TYPE_KICK_MEMBER then
		table.insert(replaceArr, target_user.nickname or "")
		table.insert(replaceArr, user_info.nickname or "")

		local style1 = Style.getFontLang(target_user.nicklang)
		style1.color = Style.font3
		local style2 = Style.getFontLang(user_info.nicklang)
		style2.color = Style.font3

		table.insert(styleArr, style1)
		table.insert(styleArr, style2)
	elseif data.log_type == LOG_TYPE_CONTRIBUTION then
		table.insert(replaceArr, user_info.nickname or "")

		local itemCSV = CsvParser.getCsvData("item", log_data.cost[1].res_type)

		table.insert(replaceArr, itemCSV.name)
		table.insert(replaceArr, log_data.contribution)

		local style1 = Style.getFontLang(user_info.nicklang)
		style1.color = Style.font3

		table.insert(styleArr, style1)
		table.insert(styleArr, defaultStyle)
		table.insert(styleArr, defaultStyle)
	elseif data.log_type == LOG_TYPE_BUILDING_UPGRADE then
		local buildingCSV = InfoBuilding.getBuildingData(log_data.building_tag, log_data.building_level)

		table.insert(replaceArr, buildingCSV.name)
		table.insert(replaceArr, log_data.building_level)
		table.insert(styleArr, defaultStyle)
		table.insert(styleArr, defaultStyle)
	elseif data.log_type == LOG_TYPE_OPEN_BUFF then
		table.insert(replaceArr, user_info.nickname or "")

		local buffCSV = CsvParser.getCsvData("union_buff", log_data.buff_id)

		table.insert(replaceArr, buffCSV.name)
		table.insert(replaceArr, math.floor(log_data.duration / 3600 * 10) / 10)

		local style1 = Style.getFontLang(user_info.nicklang)
		style1.color = Style.font3

		table.insert(styleArr, style1)
		table.insert(styleArr, defaultStyle)
		table.insert(styleArr, defaultStyle)
	elseif data.log_type == LOG_TYPE_SUDY_BUFF then
		local buffCSV = CsvParser.getCsvData("union_buff", log_data.buff_id)

		table.insert(replaceArr, buffCSV.name)
		table.insert(styleArr, defaultStyle)
	elseif data.log_type == LOG_TYPE_UNION_WAR_WIN then
		table.insert(replaceArr, log_data.union_moeny or 0)
		table.insert(styleArr, defaultStyle)
		table.insert(replaceArr, log_data.union_res or 0)
		table.insert(styleArr, defaultStyle)
	elseif user_info then
		table.insert(replaceArr, user_info.nickname or "")

		local style1 = Style.getFontLang(user_info.nicklang)
		style1.color = Style.font3

		table.insert(styleArr, style1)
	end

	return csv.desc, replaceArr, styleArr
end

function InfoUnion.getLogDesc(data)
	local ok, desc, replaceArr, styleArr = pcall(getLogDesc, data)

	if ok then
		return desc, replaceArr, styleArr
	else
		if data.log_type then
			local csv = CsvParser.getCsvData("union_log", data.log_type)

			if csv then
				return csv.desc, {}, {}
			end
		end

		return "", {}, {}
	end
end

function InfoUnion.showInfo()
	dump(unionShopList, "$$$ unionShopList")
	dump(shopList, "$$$ shopList")
	dump(buildingData, "$$$ buildingData")
	dump(rawData, "$$$ rawData")
end

local UNION_PVE_STEP = {
	WATING_END = 998,
	BOSS3 = 300,
	INVALID = 0,
	BOSS1 = 100,
	PREPARE = 1,
	BOSS2 = 200,
	END = 999
}
InfoUnion.UNION_PVE_STEP = UNION_PVE_STEP
local pveData = nil

function InfoUnion.syncPveInfo(syncData)
	dump(syncData, "syncPveInfo")

	if pveData then
		for k, v in pairs(syncData) do
			pveData[k] = v
		end
	end

	ManagerInfo.dataChange("union")
end

function InfoUnion.getPveData()
	return pveData
end

function InfoUnion.countRedotPve()
	local redotCount = 0

	if pveData then
		local csvList = CsvParser.getCsvList("gwar_achieve_reward")

		for i, csv in ipairs(csvList) do
			local opened = csv.point <= pveData.active_point
			local already = BitUtil.getBitByIndex(pveData.active_reward_flag, i) > 0

			if opened and not already then
				redotCount = redotCount + 1
			end
		end
	end

	return redotCount
end

function InfoUnion.pveStep()
	if pveData then
		return pveData.step
	else
		return UNION_PVE_STEP.INVALID
	end
end

function InfoUnion.isBossOpen(index)
	return InfoUnion.pveStep() == UNION_PVE_STEP["BOSS" .. index]
end

function InfoUnion.pveSupportMax()
	local step = InfoUnion.pveStep()

	if UNION_PVE_STEP.BOSS3 <= step then
		return InfoUnion.getConfig("union_pve_boss3_support_max")
	elseif UNION_PVE_STEP.BOSS2 <= step then
		return InfoUnion.getConfig("union_pve_boss2_support_max")
	else
		return InfoUnion.getConfig("union_pve_boss1_support_max")
	end
end

function InfoUnion.pveQuery(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_pve_query")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			pveData = rcvData

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("union_pve_query", callback)
end

function InfoUnion.pveNormal(stage_id, onSuccess, onFailure)
	print("$$$ pveNormal", stage_id)

	local function callback(rcvData)
		dump(rcvData, "union_pve_challenge_normal_stage")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			local result = rcvData.dungeon_result
			local title, subTitle = InfoDungeon.getTitle(result.type, result.dungeon_id, result.quest_id, result.abyss_seed)

			Transition.setTitle(title, subTitle)
			Transition.leave(function ()
				if onSuccess then
					onSuccess(result)
				end
			end)
		end
	end

	Connection.request("union_pve_challenge_normal_stage", {
		stage_id = stage_id
	}, callback)
end

function InfoUnion.pveBoss(stage_id, isEmu, onSuccess, onFailure)
	print("$$$ pveBoss", stage_id, isEmu)

	local function callback(rcvData)
		dump(rcvData, "union_pve_challenge_boss")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("union_pve_challenge_boss", {
		stage_id = stage_id,
		fight_type = isEmu and 0 or 1
	}, callback)
end

function InfoUnion.getActiveReward(id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_pve_get_active_reward " .. id)

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("union_pve_get_active_reward", {
		id = id
	}, callback)
end

function InfoUnion.getBossTimes()
	local challengeTimes = 0

	if pveData and pveData.challenge_boss_times and pveData.challenge_boss_time then
		challengeTimes = pveData.challenge_boss_times

		if RefreshManager.checkTimePassed(RefreshManager.TYPE.UNION_PVE_REFRESH_CHALLENGE_TIMES, Time.now(), pveData.challenge_boss_time) then
			challengeTimes = 0
		end
	end

	local maxTimes = InfoUnion.getConfig("union_pve_boss_times")

	return maxTimes - challengeTimes
end

function InfoUnion.checkBossStep(bossStep)
	if bossStep < 1 or bossStep > 3 then
		return false
	end

	local now = Time.now()
	local sectionType = RefreshManager.TYPE["UNION_PVE_BOSS" .. bossStep]
	local _, _, _, allTimeElements = RefreshManager.getSection(sectionType, now)

	if allTimeElements[1] <= now and now <= allTimeElements[2] then
		return true
	end

	return false
end

function InfoUnion.checkPveOpen(customStep)
	if DEV_MODE then
		return true
	end

	local step = customStep or InfoUnion.pveSeason()

	if InfoUnion.UNION_PVE_STEP.PREPARE <= step and step <= InfoUnion.UNION_PVE_STEP.WATING_END then
		return true
	end

	return false
end

function InfoUnion.pveSeason()
	local currentTime = Time.now()
	local step, startPrepare, endPrepare, allTimeElements = RefreshManager.getSection(RefreshManager.TYPE.UNION_PVE_PREPARE, currentTime)

	if currentTime < startPrepare then
		return UNION_PVE_STEP.INVALID
	end

	if startPrepare <= currentTime and currentTime <= endPrepare then
		return UNION_PVE_STEP.PREPARE
	end

	for bossStep = 1, 3 do
		local isBossStep = InfoUnion.checkBossStep(bossStep)

		if isBossStep then
			if bossStep == 1 then
				return UNION_PVE_STEP.BOSS1
			elseif bossStep == 2 then
				return UNION_PVE_STEP.BOSS2
			elseif bossStep == 3 then
				return UNION_PVE_STEP.BOSS3
			end
		end
	end

	local _, startEndTime, endEndTime, _ = RefreshManager.getSection(RefreshManager.TYPE.UNION_PVE_END, currentTime)

	if startEndTime <= currentTime then
		return UNION_PVE_STEP.END
	else
		return UNION_PVE_STEP.WATING_END
	end
end

local ranking_map_type = {}
local requesting_map_type = {}
local request_time_map_type = {}
local rankingAmount_type = {}
local selfRank_type = {}
local selfPoints_type = {}
local ranking_map = {}
local requesting_map = {}
local request_time_map = {}
local rankingAmount = 0
local selfRank = 0
local selfPoints = 0

function InfoUnion.getMyRank(stage_id)
	if stage_id then
		return selfRank_type[stage_id] or 0, selfPoints_type[stage_id] or 0
	else
		return selfRank or 0, selfPoints or 0
	end
end

function InfoUnion.getRankingAmount(stage_id)
	if stage_id then
		return rankingAmount_type[stage_id] or 0
	else
		return rankingAmount or 0
	end
end

function InfoUnion.startRanking(stage_id, onSuccess, onFailure)
	if stage_id then
		local function callback(rcvData)
			dump(rcvData, "$$$ union_pve_boss_ranking_start")

			if rcvData.err then
				if onFailure then
					onFailure(rcvData.err)
				end
			else
				rankingAmount_type[stage_id] = rcvData.amount
				selfRank_type[stage_id] = rcvData.self_rank
				selfPoints_type[stage_id] = rcvData.self_points

				if onSuccess then
					onSuccess(rcvData)
				end
			end
		end

		Connection.request("union_pve_boss_ranking_start", {
			stage_id = stage_id
		}, callback)
	else
		local function callback(rcvData)
			dump(rcvData, "$$$ union_pve_ranking_start")

			if rcvData.err then
				if onFailure then
					onFailure(rcvData.err)
				end
			else
				rankingAmount = rcvData.amount
				selfRank = rcvData.self_rank
				selfPoints = rcvData.self_points

				if onSuccess then
					onSuccess(rcvData)
				end
			end
		end

		Connection.request("union_pve_ranking_start", callback)
	end
end

function InfoUnion.getRanking(stage_id, page, onSuccess, onFailure)
	local ranking_map, requesting_map, request_time_map = InfoUnion.prepareRanking(stage_id)
	local start_index = (page - 1) * GameConfig.ranking_page + 1
	local union_pve_rank_max = InfoUnion.getConfig("union_pve_rank_max")

	if union_pve_rank_max < start_index then
		return
	end

	if stage_id then
		local function callback(rcvData)
			dump(rcvData, "$$$ union_pve_boss_ranking")

			requesting_map[page] = nil
			request_time_map[page] = Time.time()

			if rcvData.err then
				if onFailure then
					onFailure(rcvData.err)
				end
			else
				local list = rcvData.list

				for i, v in ipairs(list) do
					local rank = start_index + i - 1
					ranking_map[rank] = {
						rank = rank,
						data = v
					}
				end

				if onSuccess then
					onSuccess(rcvData)
				end
			end
		end

		requesting_map[page] = true

		Connection.request("union_pve_boss_ranking", {
			stage_id = stage_id,
			start_index = start_index
		}, callback)
	else
		local function callback(rcvData)
			dump(rcvData, "$$$ union_pve_ranking")

			requesting_map[page] = nil
			request_time_map[page] = Time.time()

			if rcvData.err then
				if onFailure then
					onFailure(rcvData.err)
				end
			else
				local list = rcvData.list

				for i, v in ipairs(list) do
					local rank = start_index + i - 1
					ranking_map[rank] = {
						rank = rank,
						data = v
					}
				end

				if onSuccess then
					onSuccess(rcvData)
				end
			end
		end

		requesting_map[page] = true

		Connection.request("union_pve_ranking", {
			stage_id = stage_id,
			start_index = start_index
		}, callback)
	end
end

function InfoUnion.getRankingData(stage_id, rank)
	local ranking_map, requesting_map, request_time_map = InfoUnion.prepareRanking(stage_id)
	local page = math.floor((rank - 1) / GameConfig.ranking_page) + 1

	if not ranking_map[rank] or GameConfig.ranking_local_time < Time.time() - request_time_map[page] then
		if not requesting_map[page] then
			InfoUnion.getRanking(stage_id, page)
		end
	else
		return ranking_map[rank]
	end
end

function InfoUnion.prepareRanking(stage_id)
	if stage_id then
		if not ranking_map_type[stage_id] then
			ranking_map_type[stage_id] = {}
		end

		if not requesting_map_type[stage_id] then
			requesting_map_type[stage_id] = {}
		end

		if not request_time_map_type[stage_id] then
			request_time_map_type[stage_id] = {}
		end

		return ranking_map_type[stage_id], requesting_map_type[stage_id], request_time_map_type[stage_id]
	else
		return ranking_map, requesting_map, request_time_map
	end
end

function InfoUnion.clearRanking(stage_id)
	if stage_id then
		ranking_map_type[stage_id] = {}
		requesting_map_type[stage_id] = {}
		request_time_map_type[stage_id] = {}
	else
		ranking_map = {}
		requesting_map = {}
		request_time_map = {}
	end
end

function InfoUnion.pveRecord(stage_id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ union_pve_boss_challenge_record")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("union_pve_boss_challenge_record", {
		stage_id = stage_id
	}, callback)
end

function InfoUnion.pveReplay(stage_id, battle_id, onSuccess, onFailure)
	print("$$$ pveReplay", stage_id, battle_id)

	local function callback(rcvData)
		dump(rcvData, "$$$ union_pve_boss_challenge_replay")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("union_pve_boss_challenge_replay", {
		stage_id = stage_id,
		battle_id = battle_id
	}, callback)
end

function InfoUnion.getRoundTime(round, now)
	if round < 1 or round > 5 then
		return
	end

	local sectionType = RefreshManager.TYPE["UNION_WAR_ROUND_" .. round]
	local _, _, _, allTimeElements = RefreshManager.getSection(sectionType, now)
	allTimeElements = allTimeElements or {}

	if #allTimeElements ~= 3 then
		return
	end

	return allTimeElements[2]
end

function InfoUnion.checkRound(round, now)
	if round < 1 or round > 5 then
		return
	end

	local sectionType = RefreshManager.TYPE["UNION_WAR_ROUND_" .. round]
	local _, _, _, allTimeElements = RefreshManager.getSection(sectionType, now)
	allTimeElements = allTimeElements or {}

	if #allTimeElements ~= 3 then
		return
	end

	if now < allTimeElements[1] then
		return InfoUnion.UNION_WAR_STEP.ROUND_SETTING, allTimeElements[1]
	elseif allTimeElements[1] <= now and now <= allTimeElements[2] then
		return InfoUnion.UNION_WAR_STEP.ROUND_WATING_START, allTimeElements[2]
	elseif allTimeElements[2] <= now and now <= allTimeElements[3] then
		return InfoUnion.UNION_WAR_STEP.ROUND_FIGHTING, allTimeElements[3]
	end
end

function InfoUnion.checkUnionWarSeason()
	local currentTime = math.floor(Time.now())
	local _, startEnrollTime, endEnrollTime, allTimeElements = RefreshManager.getSection(RefreshManager.TYPE.UNION_WAR_ENROLL, currentTime)

	if currentTime < startEnrollTime then
		return InfoUnion.UNION_WAR_STEP.INVALID, startEnrollTime
	end

	if startEnrollTime <= currentTime and currentTime <= endEnrollTime then
		return InfoUnion.UNION_WAR_STEP.ENROLL, endEnrollTime
	end

	for round = 1, 5 do
		local _step, _nextTime = InfoUnion.checkRound(round, currentTime)

		if _step then
			return _step, _nextTime, round
		end
	end

	local _, startEndTime, endEndTime, _ = RefreshManager.getSection(RefreshManager.TYPE.UNION_WAR_END, currentTime)
	local startT = Time.mdtFormat(startEndTime)
	local enrollMoments = RefreshManager.getRefreshMoments(RefreshManager.TYPE.UNION_WAR_ENROLL)
	local enrollMoment = enrollMoments[1]
	local nextOpenTime = Time.getFirstWeekTimeInNextMonth(startEndTime) + enrollMoment.start_time

	if currentTime <= startEndTime then
		return InfoUnion.UNION_WAR_STEP.WAR_WATING_END, startEndTime
	end

	return InfoUnion.UNION_WAR_STEP.INVALID, nextOpenTime
end

function InfoUnion.inWarSeason()
	local step = InfoUnion.checkUnionWarSeason()

	if InfoUnion.UNION_WAR_STEP.ENROLL <= step and step <= InfoUnion.UNION_WAR_STEP.WAR_WATING_END then
		return true
	end

	return false
end

local seasonData = nil

function InfoUnion.warGetSeason()
	return seasonData
end

function InfoUnion.warStepBan(key, step)
	local csv = CsvParser.getCsvData("union_battle_step", step, nil, true)

	if not csv then
		return false
	end

	return csv[key] == 1
end

function InfoUnion.pveStepBan(key, step)
	local csv = CsvParser.getCsvData("gwar_step", step, nil, true)

	if not csv then
		return false
	end

	return csv[key] == 1
end

function InfoUnion.warCheckSeason(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_war_check_season_enroll")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			seasonData = rcvData

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("union_war_check_season_enroll", callback)
end

function InfoUnion.warEnroll(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_war_enroll")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("union_war_enroll", callback)
end

function InfoUnion.getPrepareHero(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_war_get_prepare_hero")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("union_war_get_prepare_hero", callback)
end

function InfoUnion.setPrepareHero(hero_ids, onSuccess, onFailure)
	dump(hero_ids, "$$$ setPrepareHero")

	local function callback(rcvData)
		dump(rcvData, "union_war_set_prepare_hero")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("union_war_set_prepare_hero", {
		hero_ids = hero_ids
	}, callback)
end

function InfoUnion.getAllHero(isWatch, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_war_get_all_hero")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("union_war_get_all_hero", {
		is_watch = isWatch and 1 or 0
	}, callback)
end

function InfoUnion.holdMutex(flag, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_war_mutext_holding")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("union_war_mutext_holding", {
		flag = flag
	}, callback)
end

function InfoUnion.setHeroBattle(heroPosArr, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_war_set_hero_in_battle")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("union_war_set_hero_in_battle", {
		heros = heroPosArr
	}, callback)
end

function InfoUnion.warViewZone(zone_id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_war_view_zone_info", 10)

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("union_war_view_zone_info", {
		zone_id = zone_id
	}, callback)
end

function InfoUnion.warBuffList(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_war_battle_buff_list")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("union_war_battle_buff_list", callback)
end

function InfoUnion.warBuffSave(ids, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_war_battle_buff_operate")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("union_war_battle_buff_operate", {
		ids = ids
	}, callback)
end

function InfoUnion.warBattleReplay(battle_id, onSuccess, onFailure)
	print("$$$ warBattleReplay", battle_id)

	local function callback(rcvData)
		dump(rcvData, "union_war_view_battle_replay")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("union_war_view_battle_replay", {
		battle_id = battle_id
	}, callback)
end

function InfoUnion.warBattleInfo(battle_id, onSuccess, onFailure)
	print("$$$ warBattleInfo", battle_id)

	local function callback(rcvData)
		dump(rcvData, "union_war_view_battle_info")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("union_war_view_battle_info", {
		battle_id = battle_id
	}, callback)
end

function InfoUnion.warBet(battle_id, union_id, onSuccess, onFailure)
	print("$$$ warBattleInfo", battle_id, union_id)

	local function callback(rcvData)
		dump(rcvData, "union_war_user_bet")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("union_war_user_bet", {
		battle_id = battle_id,
		union_id = union_id
	}, callback)
end

function InfoUnion.warHistory(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_war_history")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("union_war_history", callback)
end

function InfoUnion.triggerCheck(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_war_trigger_check")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("union_war_trigger_check", callback)
end

function InfoUnion.triggerCheckPVE(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "union_pve_trigger_check")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("union_pve_trigger_check", callback)
end

return InfoUnion
