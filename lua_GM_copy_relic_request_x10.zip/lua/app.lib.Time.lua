local Time = {}
local SECONDS_PER_DAY = 86400
local SECONDS_PER_HOUR = 3600
local SECONDS_PER_MIN = 60
Time.SECONDS_PER_DAY = SECONDS_PER_DAY
Time.SECONDS_PER_HOUR = SECONDS_PER_HOUR
Time.SECONDS_PER_MIN = SECONDS_PER_MIN
local serverTimeOffset = 0
local timezoneOffset = 0
local initTime = nil

function Time.init()
	initTime = socket.gettime()
end

function Time.lifeTime()
	return socket.gettime() - initTime
end

function Time.time()
	return socket.gettime()
end

function Time.getServerTimeOffset()
	return serverTimeOffset
end

function Time.setServerTime(serverTime, _timezoneOffset)
	local localTime = socket.gettime()
	serverTimeOffset = serverTime - localTime
	timezoneOffset = _timezoneOffset or 0
end

function Time.now(isSharpHour)
	local localTime = socket.gettime()

	if isSharpHour then
		return localTime + math.round(serverTimeOffset / SECONDS_PER_HOUR) * SECONDS_PER_HOUR
	else
		return localTime + serverTimeOffset
	end
end

function Time.nowHour()
	local time = Time.now()
	time = time + timezoneOffset
	local hour = time % SECONDS_PER_DAY / SECONDS_PER_HOUR

	return hour
end

function Time.getDay(time)
	time = time or Time.now()

	return math.floor((time + timezoneOffset) / SECONDS_PER_DAY)
end

function Time.getToday()
	return Time.getDay(Time.now())
end

function Time.getTimeByDay(day)
	return day * SECONDS_PER_DAY
end

function Time.getTimezoneOffset()
	return timezoneOffset
end

function Time.getLocalTimezone()
	local nowTime = os.time()
	local timezoneOffset = os.difftime(nowTime, os.time(os.date("!*t", os.time())))

	return timezoneOffset / SECONDS_PER_HOUR
end

function Time.listenDayChange(view, func)
	local startDay = Time.getDay(time)
end

function Time.checkDayPassed(time)
	return Time.getDay(time) < Time.getToday()
end

function Time.checkMomentPassed(time, interval, offset)
	offset = offset or 0
	local moment1 = math.floor((time + offset) / interval + 1)
	local moment2 = math.floor((Time.now() + offset) / interval + 1)

	if moment1 < moment2 then
		return true
	else
		return false
	end
end

function Time.getNextMomentWeek(nowTime, offset)
	offset = offset or 0
	local interval = SECONDS_PER_DAY * 7
	local weekOffset = SECONDS_PER_DAY * 4
	offset = offset + weekOffset
	local nextWeekTime = math.floor((nowTime - offset) / interval + 1) * interval + offset

	return nextWeekTime
end

function Time.getNextMomentMonth(nowTime, offset)
	offset = offset or 0
	local fullyear = os.date("%Y", nowTime)
	local month = tonumber(os.date("%m", nowTime))
	local day = tonumber(os.date("%d", nowTime))
	local nextMonthTime = os.time({
		hour = 0,
		day = 1,
		second = 0,
		minute = 0,
		month = month,
		year = fullyear
	}) + Time.getTimezoneOffset() + offset

	if nowTime >= nextMonthTime then
		month = month + 1

		if month > 12 then
			fullyear = fullyear + 1
			month = 1
		end

		nextMonthTime = os.time({
			hour = 0,
			day = 1,
			second = 0,
			minute = 0,
			month = month,
			year = fullyear
		}) + Time.getTimezoneOffset() + offset
	end

	return nextMonthTime
end

function Time.getNextMomentInterval(nowTime, interval, offset)
	offset = offset or 0

	return math.floor((nowTime - offset) / interval + 1) * interval + offset
end

function Time.showPassed(diff_time)
	local day = math.floor(diff_time / SECONDS_PER_DAY)
	diff_time = diff_time - SECONDS_PER_DAY * day
	local hour = math.floor(diff_time / SECONDS_PER_HOUR)
	diff_time = diff_time - SECONDS_PER_HOUR * hour
	local min = math.floor(diff_time / SECONDS_PER_MIN)
	diff_time = diff_time - SECONDS_PER_MIN * min
	local seconds = math.floor(diff_time)

	if day > 0 then
		return string.format(format or Localization.getSrcText("%d天前"), day)
	elseif hour > 0 then
		return string.format(format or Localization.getSrcText("%d小时前"), hour)
	elseif min > 5 then
		return string.format(format or Localization.getSrcText("%d分钟前"), min)
	else
		return Localization.getSrcText("刚刚")
	end
end

function Time.showSec(diff_time)
	local day = math.floor(diff_time / SECONDS_PER_DAY)
	diff_time = diff_time - SECONDS_PER_DAY * day
	local hour = math.floor(diff_time / SECONDS_PER_HOUR)
	diff_time = diff_time - SECONDS_PER_HOUR * hour
	local min = math.floor(diff_time / SECONDS_PER_MIN)
	diff_time = diff_time - SECONDS_PER_MIN * min
	local seconds = math.floor(diff_time)

	if day > 0 then
		return string.format(format or Localization.getSrcText("%d天%d小时%d分%d秒"), day, hour, min, seconds)
	elseif hour > 0 then
		return string.format(format or Localization.getSrcText("%d小时%d分%d秒"), hour, min, seconds)
	elseif min > 0 then
		return string.format(format or Localization.getSrcText("%d分%d秒"), min, seconds)
	else
		return string.format(format or Localization.getSrcText("%d秒"), seconds)
	end
end

function Time.showMin(diff_time, isSimple)
	local day = math.floor(diff_time / SECONDS_PER_DAY)
	diff_time = diff_time - SECONDS_PER_DAY * day
	local hour = math.floor(diff_time / SECONDS_PER_HOUR)
	diff_time = diff_time - SECONDS_PER_HOUR * hour
	local min = math.floor(diff_time / SECONDS_PER_MIN)
	diff_time = diff_time - SECONDS_PER_MIN * min
	local seconds = math.floor(diff_time)

	if day > 0 then
		if isSimple and min == 0 then
			return string.format(format or Localization.getSrcText("%d天%d小时%d分"), day, hour, min)
		else
			return string.format(format or Localization.getSrcText("%d天%d小时"), day, hour)
		end
	elseif hour > 0 then
		if isSimple and min == 0 then
			return string.format(format or Localization.getSrcText("%d小时"), hour)
		else
			return string.format(format or Localization.getSrcText("%d小时%d分"), hour, min)
		end
	elseif min > 0 then
		return string.format(format or Localization.getSrcText("%d分钟"), min)
	else
		return string.format(format or Localization.getSrcText("%d秒"), seconds)
	end
end

function Time.showDay(diff_time)
	local day = math.floor(diff_time / SECONDS_PER_DAY)

	return string.format(format or Localization.getSrcText("%d天"), day)
end

function Time.format(diff_time)
	if SECONDS_PER_HOUR <= diff_time then
		return Time.formatHour(diff_time)
	else
		return Time.formatMinite(diff_time)
	end
end

function Time.formatHour(diff_time, format)
	local day = math.floor(diff_time / SECONDS_PER_DAY)
	diff_time = diff_time - SECONDS_PER_DAY * day
	local hour = math.floor(diff_time / SECONDS_PER_HOUR)
	diff_time = diff_time - SECONDS_PER_HOUR * hour
	local min = math.floor(diff_time / SECONDS_PER_MIN)
	diff_time = diff_time - SECONDS_PER_MIN * min
	local seconds = math.floor(diff_time)

	return string.format(format or "%d:%02d:%02d", hour, min, seconds)
end

function Time.formatMinite(diff_time, format)
	local min = math.floor(diff_time / SECONDS_PER_MIN)
	local seconds = diff_time - SECONDS_PER_MIN * min

	return string.format(format or "%d:%02d", min, seconds)
end

function Time.showDate(time)
	return os.date("%Y-%m-%d %H:%M", time)
end

function Time.getSharpWeek(nowTime, offset)
	offset = offset or 0
	local interval = SECONDS_PER_DAY * 7
	local weekOffset = SECONDS_PER_DAY * 4
	offset = offset + weekOffset

	return math.floor((nowTime - offset) / interval + 1)
end

function Time.getSharpMonth(nowTime, offset)
	offset = offset or 0
	local fullyear = os.date("%Y", nowTime)
	local month = tonumber(os.date("%m", nowTime))
	local day = tonumber(os.date("%d", nowTime))
	local nextMonthTime = os.time({
		hour = 0,
		day = 1,
		second = 0,
		minute = 0,
		month = month,
		year = fullyear
	}) + Time.getTimezoneOffset() + offset

	if nowTime >= nextMonthTime then
		month = month + 1

		if month > 12 then
			fullyear = fullyear + 1
			month = 1
		end

		nextMonthTime = os.time({
			hour = 0,
			day = 1,
			second = 0,
			minute = 0,
			month = month,
			year = fullyear
		}) + Time.getTimezoneOffset() + offset
	end

	return math.floor(fullyear * 12 + month)
end

function Time.getSharpInterval(nowTime, interval, offset)
	offset = offset or 0

	return math.floor((nowTime - offset) / interval + 1)
end

function Time.getFistDayInMonth(timestamp)
	local nowTime = timestamp or math.floor(skynet.time())
	local fullyear = os.date("%Y", nowTime)
	local month = tonumber(os.date("%m", nowTime))
	local thisMonthFirstDay = os.time({
		hour = 0,
		day = 1,
		second = 0,
		minute = 0,
		month = month,
		year = fullyear
	})

	return thisMonthFirstDay
end

function Time.getFirstDayInNextMonth(timestamp)
	local nowTime = timestamp or math.floor(skynet.time())
	local fullyear = os.date("%Y", nowTime)
	local month = tonumber(os.date("%m", nowTime))
	month = month + 1

	if month > 12 then
		month = 1
		fullyear = fullyear + 1
	end

	local thisMonthFirstDay = os.time({
		hour = 0,
		day = 1,
		second = 0,
		minute = 0,
		month = month,
		year = fullyear
	})

	return thisMonthFirstDay
end

function Time.caculateFirstWeekOffset(timestamp)
	local weekDay = tonumber(os.date("%w", timestamp))
	local weekOffset = 0

	if weekDay == 1 then
		weekOffset = 0
	else
		if weekDay == 0 then
			weekDay = 7
		end

		weekOffset = (7 - weekDay + 1) * SECONDS_PER_DAY
	end

	return weekOffset
end

function Time.getFirstWeekTimeInMonth(timestamp)
	local currMonthFirstDay = Time.getFistDayInMonth(timestamp)
	local weekOffset = Time.caculateFirstWeekOffset(currMonthFirstDay)
	local monthFirstWeekDay = currMonthFirstDay + weekOffset

	return monthFirstWeekDay
end

function Time.getFirstWeekTimeInNextMonth(timestamp)
	local nextMonthFirstDay = Time.getFirstDayInNextMonth(timestamp)
	local weekOffset = Time.caculateFirstWeekOffset(nextMonthFirstDay)
	local monthFirstWeekDay = nextMonthFirstDay + weekOffset

	return monthFirstWeekDay
end

function Time.getFirstWeekTimeNearst(nowTime)
	nowTime = nowTime or math.floor(Time.now())
	local firstWeekDayInCurrMonth = Time.getFirstWeekTimeInMonth(nowTime)

	if nowTime <= firstWeekDayInCurrMonth then
		return firstWeekDayInCurrMonth
	end

	local firstWeekDayInNextMonth = Time.getFirstWeekTimeInNextMonth(nowTime)

	return firstWeekDayInNextMonth
end

function Time.localHour()
	local a = os.date("!*t", os.time())
	local b = os.date("*t", os.time())
	local timeZone = (b.hour - a.hour) * 3600 + (b.min - a.min) * 60
	local time = socket.gettime()
	time = time + timeZone
	local hour = time % SECONDS_PER_DAY / SECONDS_PER_HOUR

	return hour
end

function Time.ymdFormat(seconds, simple)
	return StringUtil.ymdFormat(seconds, simple)
end

function Time.ymdtFormat(seconds, simple)
	return StringUtil.ymdtFormat(seconds, simple)
end

function Time.mdtFormat(seconds, simple)
	return StringUtil.mdtFormat(seconds, simple)
end

return Time
