local InfoBuilding = {}
local TAG = {
	MONO = 5,
	MIRROR = 4,
	KANBAN = 3,
	TAVERN = 2,
	FORGE = 1,
	ARTIFACT = 701,
	SIGIL = 601,
	UNION_GWAR = 507,
	UNION_BUFF_OPEN = 506,
	UNION_MONO = 505,
	UNION_SHOP = 504,
	UNION_RESOURCE = 503,
	UNION_CENTER = 502,
	UNION = 501,
	DUST_KANBAN = 405,
	DUST_MCT = 404,
	DUST_FORGE = 403,
	DUST_ENTER = 402,
	DUST_CAMP = 401,
	FARM_TILE = 302,
	FARM = 301,
	PET = 202,
	PET_HATCH = 201,
	SHADOW_MCT = 106,
	GAP_EXIT = 105,
	DUST_NEXT = 104,
	TELEPORT = 103,
	ABYSS = 102,
	SEAT = 50,
	HOME_WORKSHOP = 30,
	HOME_DJ = 28,
	HOME_POSTBOX = 27,
	HOME_ALCHEMY = 25,
	HOME_CRAFT = 24,
	HOME = 23,
	CAMPFIRE = 22,
	WILD_SHOP = 21,
	GACHA = 20,
	STORAGE = 19,
	EXCHANGE = 17,
	RECLAIM = 16,
	PIG = 15,
	ASAKA_MCT = 14,
	DATABASE = 13,
	TRAVEL = 12,
	ARENA = 11,
	BARD = 10,
	MERCHANT = 9,
	VETERAN = 8,
	FURNACE = 7,
	MARKET = 6
}
InfoBuilding.TAG = TAG
local rawData = {}

function InfoBuilding.init()
	Connection.listen("building_sync", InfoBuilding.sync)
	Connection.listen("building_plus_push", InfoBuilding.onPlusPush)
end

app:addToAppEnterCall(InfoBuilding.init)

function InfoBuilding.sync(data)
	local changedIdStack = {}

	for i, syncData in ipairs(data.list) do
		local tag = syncData.tag

		if not rawData[tag] then
			rawData[tag] = syncData
		else
			for k, v in pairs(syncData) do
				rawData[tag][k] = v
			end
		end

		changedIdStack[tag] = rawData[tag]
	end

	ManagerInfo.dataChange("building", changedIdStack)
end

function InfoBuilding.onPlusPush(data)
	dump(data, "$$$ onPlusPush")
	FRAME_plus_push.open(data.tag, data.item_id, data.pre_item_id)
end

function InfoBuilding.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoBuilding.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("building_query", callback)
end

function InfoBuilding.onQuery(rcvData)
	rawData = {}

	for i, v in ipairs(rcvData.list) do
		rawData[v.tag] = v
	end
end

function InfoBuilding.levelup(tag, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoBuilding.playBuildSfx(tag)

			if CONFIG.is_ta then
				local params = {
					building_id = tag,
					after_level = InfoBuilding.getBuildingLevel(tag)
				}
				local taName = "building_levelup"

				if tag == TAG.HOME_CRAFT or tag == TAG.HOME_ALCHEMY or tag == TAG.HOME_WORKSHOP or tag == TAG.HOME_POSTBOX or tag == TAG.HOME_DJ then
					taName = "furniture_levelup"
				end

				TaHelper.taTrack(taName, params)
			end

			notify.dispatch("building_levelup", tag)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("building_levelup", {
		tag = tag
	}, callback)
end

function InfoBuilding.setGuided(tags, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	local tag_arr = {}

	for i, tag in ipairs(tags) do
		local obj = {
			tag = tag
		}
		local level = 0

		if rawData[tag] then
			level = rawData[tag].level
		end

		local buildingData = CsvParser.getFilteredData("building", {
			tag = tag,
			level = level
		})

		if buildingData.auto_build == 1 then
			obj.auto = 1
		end

		table.insert(tag_arr, obj)
	end

	Connection.request("building_guide", {
		tag_arr = tag_arr
	}, callback)
end

function InfoBuilding.setPlus(tag, index, itemID)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			if global.player then
				global.player:npcChanged(true)
			end

			if rcvData.class_removed == 1 then
				Alert.open(Localization.getSrcText("移除同类插件"))
			end

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("building_plus_set", {
		tag = tag,
		index = index,
		item_id = itemID
	}, callback)
end

function InfoBuilding.getBuildingNPC(tag)
	local npcCsvRaw = CsvParser.getCsvRaw("npc")

	for k, v in pairs(npcCsvRaw) do
		if v.building == tag then
			return v
		end
	end
end

function InfoBuilding.getBuildingFin(id)
	local buildingCSV = CsvParser.getCsvData("building", id)

	if buildingCSV then
		local buildingLevel = InfoBuilding.getBuildingLevel(buildingCSV.tag)

		return buildingCSV.level <= buildingLevel
	end
end

function InfoBuilding.getBuildingLevel(tag)
	local level = 0

	if rawData[tag] then
		level = rawData[tag].level
	end

	local originalLevel = level
	local buildingData = CsvParser.getFilteredData("building", {
		tag = tag,
		level = level
	})

	if not buildingData then
		return
	end

	if buildingData.auto_build == 1 then
		local permitItem = buildingData.permit_item

		if empty(permitItem) or InfoItem.getNum(permitItem) > 0 then
			level = level + 1
		end
	end

	return level, originalLevel, buildingData
end

function InfoBuilding.getBuildingData(tag, customLevel)
	local buildingLevel = customLevel or InfoBuilding.getBuildingLevel(tag)

	if buildingLevel then
		local currentData = CsvParser.getFilteredData("building", {
			tag = tag,
			level = buildingLevel
		})

		if currentData then
			local nextData = CsvParser.getFilteredData("building", {
				tag = tag,
				level = buildingLevel + 1
			})

			return currentData, nextData
		end
	end
end

function InfoBuilding.getNewBuildList()
	local arr = {}

	for k, tag in pairs(TAG) do
		local level, originalLevel, buildingData = InfoBuilding.getBuildingLevel(tag)

		if level and level == 0 then
			local permitItem = buildingData.permit_item

			if empty(permitItem) or InfoItem.getNum(permitItem) > 0 then
				table.insert(arr, tag)
			end
		end
	end

	return arr
end

function InfoBuilding.getBuildGuideList()
	local arr = {}
	local nowTime = Time.now()

	for k, tag in pairs(TAG) do
		local level, originalLevel, buildingData = InfoBuilding.getBuildingLevel(tag)

		if level and originalLevel == 0 then
			local permitItem = buildingData.permit_item

			if (empty(permitItem) or InfoItem.getNum(permitItem) > 0) and not empty(buildingData.build_hint) and rawData[tag] and nowTime > rawData[tag].guided + MiscConfig.build_guide_time then
				table.insert(arr, tag)
			end
		end
	end

	return arr
end

function InfoBuilding.getBuildingList()
	local arr = {}

	for k, tag in pairs(TAG) do
		local buildingData = InfoBuilding.getBuildingData(tag)

		if buildingData then
			table.insert(arr, buildingData)
		end
	end

	table.sort(arr, function (a, b)
		return a.tag < b.tag
	end)

	return arr
end

function InfoBuilding.isPlusLvup(tag, index)
	local itemID = 0

	if rawData[tag] and rawData[tag]["plus_" .. index] then
		itemID = rawData[tag]["plus_" .. index]
	end

	if itemID ~= 0 then
		local itemData = CsvParser.getCsvData("item", itemID)
		local plusArr = CsvParser.getCsvList("building_plus", nil, {
			tag = tag
		})
		local classMap = {}
		local currentClass = nil

		for i, v in ipairs(plusArr) do
			if v.item_id == itemID then
				currentClass = v.class
			end

			if InfoItem.getNum(v.item_id) > 0 and (not classMap[v.class] or classMap[v.class].level < v.level) then
				classMap[v.class] = v
			end
		end

		if currentClass and classMap[currentClass].item_id ~= itemID then
			return true
		end
	end
end

function InfoBuilding.getPlusByItem(itemID)
	local itemToBuildingPlusMap = CacheData.get("InfoBuilding_itemToBuildingPlusMap")

	if not itemToBuildingPlusMap then
		itemToBuildingPlusMap = {}
		local plusRaw = CsvParser.getCsvRaw("building_plus")

		for k, v in pairs(plusRaw) do
			itemToBuildingPlusMap[v.item_id] = v
		end

		CacheData.set("InfoBuilding_itemToBuildingPlusMap", itemToBuildingPlusMap)
	end

	return itemToBuildingPlusMap[itemID]
end

function InfoBuilding.getPlusOpen(tag, num)
	local plusOpenMap = CacheData.get("InfoBuilding_plusOpenMap")

	if not plusOpenMap then
		plusOpenMap = {}
		local csvList = CsvParser.getCsvList("building")

		for i, v in ipairs(csvList) do
			if not plusOpenMap[v.tag] then
				plusOpenMap[v.tag] = {}
			end

			if not plusOpenMap[v.tag][v.building_plus_num] then
				plusOpenMap[v.tag][v.building_plus_num] = v.level
			end
		end

		CacheData.set("InfoBuilding_plusOpenMap", plusOpenMap)
	end

	if plusOpenMap[tag] and plusOpenMap[tag][num] then
		return plusOpenMap[tag][num]
	end

	return 0
end

function InfoBuilding.getPlus(tag)
	local buildingData = InfoBuilding.getBuildingData(tag)
	local plusNum = tonumber(buildingData.building_plus_num) or 0
	local plusList = {}

	for i = 1, plusNum do
		local itemID = 0

		if rawData[tag] and rawData[tag]["plus_" .. i] then
			itemID = rawData[tag]["plus_" .. i]
		end

		plusList[i] = itemID
	end

	local maxLevel = InfoBuilding.getBuildingMaxLevel(tag)
	local buildingData = InfoBuilding.getBuildingData(tag, maxLevel)
	local plusNumMax = tonumber(buildingData.building_plus_num) or 0

	return plusList, plusNum, plusNumMax
end

function InfoBuilding.getAllPlusItems()
	local plusRaw = CsvParser.getCsvRaw("building_plus")
	local classMap = {}

	for k, v in pairs(plusRaw) do
		if InfoItem.getNum(v.item_id) > 0 and (not classMap[v.class] or classMap[v.class].level < v.level) then
			classMap[v.class] = v
		end
	end

	local plusSort = {}

	for k, v in pairs(classMap) do
		table.insert(plusSort, v)
	end

	table.sort(plusSort, function (a, b)
		return a.id < b.id
	end)

	local plusItems = {}

	for i, v in ipairs(plusSort) do
		table.insert(plusItems, {
			num = 1,
			base_id = v.item_id
		})
	end

	return plusItems
end

function InfoBuilding.getPlusCSV(class, level)
	local plusClassLevelMap = CacheData.get("InfoBuilding_plusClassLevelMap")

	if not plusClassLevelMap then
		plusClassLevelMap = {}
		local plusRaw = CsvParser.getCsvRaw("building_plus")
		local classArr = {}
		local classMap = {}

		for i, v in pairs(plusRaw) do
			if not plusClassLevelMap[v.class] then
				plusClassLevelMap[v.class] = {}
			end

			plusClassLevelMap[v.class][v.level] = v
		end

		CacheData.set("InfoBuilding_plusClassLevelMap", plusClassLevelMap)
	end

	if plusClassLevelMap[class] then
		return plusClassLevelMap[class][level]
	end
end

function InfoBuilding.getPlusList(tag)
	local existMap = {}
	local plusList, plusNum = InfoBuilding.getPlus(tag)

	for i, itemID in ipairs(plusList) do
		existMap[itemID] = true
	end

	local buildingData = InfoBuilding.getBuildingData(tag)
	local plusArr = CsvParser.getCsvList("building_plus", nil, {
		tag = tag
	})
	local classArr = {}
	local classMap = {}

	for i, v in ipairs(plusArr) do
		if not classMap[v.class] then
			classMap[v.class] = {
				csv = v,
				tag = tag,
				class = v.class,
				level = v.level
			}
		end

		local data = classMap[v.class]
		local itemExist = InfoItem.getNum(v.item_id) > 0

		if not data.itemID or itemExist and data.level < v.level then
			data.itemID = v.item_id
			data.level = v.level
			data.csv = v
			data.exist = itemExist
		end
	end

	local plusItems = {}

	for k, v in pairs(classMap) do
		table.insert(plusItems, v)
	end

	table.sort(plusItems, function (a, b)
		local existA = a.exist and 1 or 0
		local existB = b.exist and 1 or 0
		local groupA = a.csv.group
		local groupB = b.csv.group

		if empty(groupA) then
			groupA = 0
		end

		if empty(groupB) then
			groupB = 0
		end

		if existA == existB then
			if groupA == groupB then
				return a.class < b.class
			else
				return groupA < groupB
			end
		else
			return existB < existA
		end
	end)

	return plusItems
end

function InfoBuilding.getPlusItem(tag)
end

function InfoBuilding.getPlusFromItem(item_id)
	local itemToPlusMap = CacheData.get("InfoBuilding_itemToPlusMap")

	if not itemToPlusMap then
		itemToPlusMap = {}
		local rawData = CsvParser.getCsvRaw("building_plus")

		for k, v in pairs(rawData) do
			itemToPlusMap[v.item_id] = v
		end

		CacheData.set("InfoBuilding_itemToPlusMap", itemToPlusMap)
	end

	return itemToPlusMap[item_id]
end

function InfoBuilding.getPlusData(tag, plusType)
	for i = 1, GameConfig.building_plug_num do
		local item_id = rawData[tag]["plus_" .. i]

		if not empty(item_id) then
			local plusCSV = InfoBuilding.getPlusFromItem(item_id)

			if plusCSV and plusCSV.type == plusType then
				return plusCSV
			end
		end
	end
end

function InfoBuilding.getPlusDataList(tag, plusType)
	local arr = {}

	for i = 1, GameConfig.building_plug_num do
		local item_id = rawData[tag]["plus_" .. i]

		if not empty(item_id) then
			local plusCSV = InfoBuilding.getPlusFromItem(item_id)

			if plusCSV and plusCSV.type == plusType then
				table.insert(arr, plusCSV)
			end
		end
	end

	return arr
end

function InfoBuilding.initBuildingMatList()
	local buildingMatList = {}
	local matBuildingMap = {}
	local building_csv_raw = CsvParser.getCsvRaw("building")
	local existedMap = {}
	local existedBuidlingMap = {}

	for k, csv in pairs(building_csv_raw) do
		if not empty(csv.mat_id_1) then
			if not existedMap[csv.mat_id_1] then
				existedMap[csv.mat_id_1] = true

				table.insert(buildingMatList, csv.mat_id_1)
			end

			if not existedBuidlingMap[csv.tag] then
				existedBuidlingMap[csv.tag] = true

				if not matBuildingMap[csv.mat_id_1] then
					matBuildingMap[csv.mat_id_1] = {}
				end

				table.insert(matBuildingMap[csv.mat_id_1], csv.tag)
			end
		end
	end

	table.sort(buildingMatList, function (a, b)
		return a < b
	end)

	for itemID, tagArr in pairs(matBuildingMap) do
		table.sort(tagArr, function (a, b)
			return a < b
		end)
	end

	CacheData.set("InfoBuilding_buildingMatList", buildingMatList)
	CacheData.set("InfoBuilding_matBuildingMap", matBuildingMap)
end

function InfoBuilding.getBuildingMatList()
	local buildingMatList = CacheData.get("InfoBuilding_buildingMatList")

	if not buildingMatList then
		InfoBuilding.initBuildingMatList()

		buildingMatList = CacheData.get("InfoBuilding_buildingMatList")
	end

	local arr = {}

	for i, itemID in ipairs(buildingMatList) do
		local itemCSV = CsvParser.getCsvData("item", itemID)

		if itemCSV.is_resource == 1 then
			table.insert(arr, itemID)
		end
	end

	return arr
end

function InfoBuilding.getProgressByMat(itemID)
	local matBuildingMap = CacheData.get("InfoBuilding_matBuildingMap")

	if not matBuildingMap then
		InfoBuilding.initBuildingMatList()

		matBuildingMap = CacheData.get("InfoBuilding_matBuildingMap")
	end

	local arr = {}
	local maxPercent = 0
	local tagArr = matBuildingMap[itemID]

	if not tagArr then
		return maxPercent
	end

	for i, tag in ipairs(tagArr) do
		local buildingData, nextBuildingData = InfoBuilding.getBuildingData(tag)
		local buildingLevel = InfoBuilding.getBuildingLevel(tag)
		local data = {
			tag = tag,
			csv = buildingData,
			level = buildingLevel
		}

		if buildingLevel and buildingLevel > 0 then
			if not nextBuildingData then
				data.isMax = true
			else
				local matList = SheetUtil.getColumnList(buildingData, {
					"mat_id_",
					"mat_num_"
				}, {
					"base_id",
					"num"
				})
				local mat = matList[1]
				local percent = InfoItem.getNum(itemID) / mat.num
				data.percent = percent
				maxPercent = math.max(maxPercent, percent)
			end
		else
			data.isEmpty = true
		end

		table.insert(arr, data)
	end

	return maxPercent, arr
end

function InfoBuilding.getDeviceByBuilding(tag)
	local deviceBuildingMap = CacheData.get("InfoBuilding_deviceBuildingMap")

	if not deviceBuildingMap then
		deviceBuildingMap = {}
		local device_csv_raw = CsvParser.getCsvRaw("device")

		for k, csv in pairs(device_csv_raw) do
			if not empty(csv.building) then
				deviceBuildingMap[csv.building] = csv.id
			end
		end

		CacheData.set("InfoBuilding_deviceBuildingMap", deviceBuildingMap)
	end

	return deviceBuildingMap[tag]
end

function InfoBuilding.getNpcByBuilding(tag)
	local npcBuildingMap = CacheData.get("InfoBuilding_npcBuildingMap")

	if not npcBuildingMap then
		npcBuildingMap = {}
		local npc_csv_raw = CsvParser.getCsvRaw("npc")

		for k, csv in pairs(npc_csv_raw) do
			if not empty(csv.building) then
				npcBuildingMap[csv.building] = csv.id
			end
		end

		CacheData.set("InfoBuilding_npcBuildingMap", npcBuildingMap)
	end

	return npcBuildingMap[tag]
end

function InfoBuilding.getNpcByBuilding0(tag)
	local npcBuildingMap0 = CacheData.get("InfoBuilding_npcBuildingMap0")

	if not npcBuildingMap0 then
		npcBuildingMap0 = {}
		local npc_csv_raw = CsvParser.getCsvRaw("npc")

		for k, csv in pairs(npc_csv_raw) do
			if not empty(csv.building0) then
				npcBuildingMap0[csv.building0] = csv.id
			end
		end

		CacheData.set("InfoBuilding_npcBuildingMap0", npcBuildingMap0)
	end

	return npcBuildingMap0[tag]
end

function InfoBuilding.playOpenSfx(tag)
	local csv = InfoBuilding.getBuildingData(tag)

	if not empty(csv.open_sfx) then
		Sound.playSound(csv.open_sfx)
	end
end

function InfoBuilding.playBuildSfx(tag)
	local csv = InfoBuilding.getBuildingData(tag)

	if not empty(csv.build_sfx) then
		Sound.playSound(csv.build_sfx)
	end
end

function InfoBuilding.getBuildingMaxLevel(tag)
	local buildingMaxLevelMap = CacheData.get("InfoBuilding_buildingMaxLevelMap")

	if not buildingMaxLevelMap then
		buildingMaxLevelMap = {}
		local buildingRaw = CsvParser.getCsvRaw("building")

		for k, v in pairs(buildingRaw) do
			if not buildingMaxLevelMap[v.tag] then
				buildingMaxLevelMap[v.tag] = v.level
			else
				buildingMaxLevelMap[v.tag] = math.max(buildingMaxLevelMap[v.tag], v.level)
			end
		end

		CacheData.set("InfoBuilding_buildingMaxLevelMap", buildingMaxLevelMap)
	end

	return buildingMaxLevelMap[tag]
end

function InfoBuilding.checkLvupResource(tag, isUnion)
	local buildingData = nil

	if isUnion then
		buildingData = InfoUnion.getBuildingData(tag)
	else
		buildingData = InfoBuilding.getBuildingData(tag)
	end

	local matList = SheetUtil.getColumnList(buildingData, {
		"mat_id_",
		"mat_num_"
	}, {
		"base_id",
		"num"
	})

	for i, mat in ipairs(matList) do
		local itemNum = 0

		if isUnion then
			itemNum = InfoUnion.getResourceNum(mat.base_id)
		else
			itemNum = InfoItem.getNum(mat.base_id)
		end

		if itemNum < mat.num then
			return false
		end
	end

	return true
end

return InfoBuilding
