local FRAME_login_wait = class("FRAME_login_wait", UI_base)

function FRAME_login_wait.open(wait_key, wait_time, onWaitSuccess, onWaitReset)
	local ui = FRAME_login_wait.new(wait_key, wait_time, onWaitSuccess, onWaitReset)

	display.getRunningScene():addChild(ui, LayerConfig.sys)
	PopManager.popinAnim(ui, callback, PopManager.ANIM_TYPE.JUMP)
end

function FRAME_login_wait:ctor(wait_key, wait_time, onWaitSuccess, onWaitReset)
	FRAME_login_wait.super.ctor(self, "frame_login_wait")

	self.wait_key = wait_key
	self.wait_time = wait_time
	self.onWaitSuccess = onWaitSuccess
	self.onWaitReset = onWaitReset

	self:init()
end

function FRAME_login_wait:init()
	self:initUI()

	self.nextTime = Time.now() + math.min(math.ceil(self.wait_time / 1000), 5)
	self.finTime = Time.now() + math.ceil(self.wait_time / 1000)

	self:refresh()
	self:addEnterFrame("tik_loop", function (dt)
		self:refresh()

		if self.nextTime < Time.now() then
			self.nextTime = self.nextTime + 60

			Http.request(InfoUser.getHttpHead() .. CONFIG.center_addr .. "/?cmd=auth_queue", {
				key = self.wait_key
			}, function (rcvData)
				dump(rcvData, "$$$ auth_queue")

				if rcvData.err then
					self:removeEnterFrame("tik_loop")
					POP_confirm.open(Localization.getSrcText("排队意外退出或超时"), function ()
						self:retry()
					end, Localization.getSrcText("重新登录"))
				elseif rcvData.wait_time then
					self.wait_time = rcvData.wait_time
					self.finTime = Time.now() + math.ceil(self.wait_time / 1000)
					self.nextTime = Time.now() + math.min(math.ceil(self.wait_time / 1000), 5)
				else
					self:removeEnterFrame("tik_loop")

					local onWaitSuccess = self.onWaitSuccess

					self:removeSelf()

					if onWaitSuccess then
						onWaitSuccess(rcvData)
					end
				end
			end)
		end
	end)
end

function FRAME_login_wait:refresh()
	local sec = math.max(0, self.finTime - Time.now())
	local str = ""

	if Time.SECONDS_PER_HOUR < sec then
		str = Localization.getSrcText("超过一小时")
	else
		str = Time.showSec(sec)
	end

	if self.preStr ~= str then
		self.preStr = str

		self:replaceLabelGroupOnFlag("flag_time", {
			str
		}, {
			{
				size = 28,
				color = Style.font3
			}
		})
	end
end

function FRAME_login_wait:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local mask = self:getComponentByTag("mask")

	mask:toTouchable()

	local bt_reset = self:getComponentByTag("bt_reset")

	bt_reset:toTouchable()
	bt_reset:setTapGroup("button_click")
	bt_reset:addTap(function ()
		self:retry()
	end)
end

function FRAME_login_wait:retry()
	self:removeEnterFrame("tik_loop")

	local onWaitReset = self.onWaitReset
	local wait_key = self.wait_key

	self:removeSelf()
	Http.request(InfoUser.getHttpHead() .. CONFIG.center_addr .. "/?cmd=auth_queue_quit", {
		key = wait_key
	}, function (rcvData)
		dump(rcvData, "$$$ auth_queue_quit")

		if onWaitReset then
			onWaitReset()
		end
	end)
end

return FRAME_login_wait
