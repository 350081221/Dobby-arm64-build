local UI_base = import("..UI_base")
local Transition = class("Transition", UI_base)
local instance, leaveCallback, leaveEasingOver = nil

function Transition.isOpening()
	if instance and instance.getOpacity and instance:getOpacity() > 0 then
		return true
	end

	return false
end

function Transition.openHint(callback)
end

local hintSeed = nil

function Transition.leave(callback)
	LayerConfig.setPopLocked("Transition", true)

	leaveCallback = callback

	local function delayCallback()
		local delayCount = 3

		instance:addEnterFrame("delay", function ()
			if delayCount <= 0 then
				instance:removeEnterFrame("delay")

				if leaveCallback then
					leaveCallback()
				end
			else
				delayCount = delayCount - 1
			end
		end)
	end

	if not instance then
		instance = Transition.new()
		hintSeed = math.random(1, 65535)

		if InfoDungeon.isAbyssEnter then
			AbyssHint.open(true, instance, hintSeed)
		elseif InfoDungeon.isAbyssExit then
			AbyssHint.open(false, instance, hintSeed)
		end

		instance:setOpacity(0)
		display.getRunningScene():addChild(instance, LayerConfig.transition)
		transition.fadeTo(instance, {
			opacity = 255,
			time = 0.2,
			easing = "sineOut",
			onComplete = function ()
				leaveEasingOver = true

				if leaveCallback then
					delayCallback()
				end
			end
		})
	elseif leaveEasingOver and leaveCallback then
		delayCallback()
	end
end

function Transition.enter(waitForOpen, openingTime)
	instance = Transition.new()

	if InfoDungeon.isAbyssEnter then
		AbyssHint.open(true, instance, hintSeed)
	elseif InfoDungeon.isAbyssExit then
		AbyssHint.open(false, instance, hintSeed)
	end

	display.getRunningScene():addChild(instance, LayerConfig.transition)

	if not waitForOpen then
		Transition.enterOpen(openingTime)
	end
end

function Transition.enterOpen(openingTime)
	transition.fadeTo(instance, {
		opacity = 0,
		easing = "sineOut",
		time = openingTime or 0.2,
		onComplete = function ()
			instance:removeSelf()
			Transition.clear()
			LayerConfig.setPopLocked("Transition", false)
		end
	})
end

function Transition.setTitle(title, subTitle)
	Transition.title = title
	Transition.subTitle = subTitle
end

function Transition.getTitle()
	return Transition.title, Transition.subTitle
end

function Transition.clear()
	instance = nil
	leaveCallback = nil
	leaveEasingOver = nil
end

function Transition:ctor()
	Transition.super.ctor(self, "transition")
	self:init()
end

function Transition:init()
	self:initUI()
end

function Transition:initUI()
	local mask = self:getComponentByTag("mask")

	mask:toTouchable()
	self:createLabelOnFlag("flag_title", Transition.title or "")

	if not empty(Transition.subTitle) then
		self:createLabelOnFlag("flag_subtitle", Transition.subTitle)
	else
		self:removeLabelOnFlag("flag_subtitle")
	end
end

return Transition
