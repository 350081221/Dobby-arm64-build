local zlib = require("zlib")
local JsonParser = {}
local cachedStrMap = {}
local cachedDataMap = {}

function JsonParser.getJsonStr(filePath, isZlib)
	local content = cachedStrMap[filePath]

	if not content then
		filePath = getFinalRes(filePath)

		if isZlib then
			content = getFileData(filePath)
			local uncompress = zlib.inflate()
			content = uncompress(content)
		else
			content = getFileString(filePath)
		end
	end

	return content
end

function JsonParser.parse(filePath, isZlib)
	local jsonStr = JsonParser.getJsonStr(filePath, isZlib)

	return JsonParser.parseStr(jsonStr)
end

function JsonParser.parseStr(jsonStr, isNew)
	if isNew then
		return json.decode(jsonStr)
	else
		local md5 = crypto.md5(jsonStr)

		if not cachedDataMap[md5] then
			cachedDataMap[md5] = json.decode(jsonStr)
		end

		return cachedDataMap[md5]
	end
end

function JsonParser.clearOnScene()
	cachedStrMap = {}
	cachedDataMap = {}
end

return JsonParser
