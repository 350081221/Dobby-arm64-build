local NAV_base = import(".NAV_base")
local NAV_dust_enter = class("NAV_dust_enter", NAV_base)

function NAV_dust_enter.open(npc)
	local ui = NAV_dust_enter.new(npc)

	return ui
end

function NAV_dust_enter:ctor(npc)
	NAV_dust_enter.super.ctor(self, npc, "nav_dust_enter")
end

function NAV_dust_enter:init()
	NAV_dust_enter.super.init(self)
end

function NAV_dust_enter:onTap(index)
	NAV_dust_enter.super.onTap(self, index)

	if index == 1 then
		if InfoHero.countTeam() < GameConfig.hero_team_num then
			Alert.open(StringUtil.replace(Localization.getSrcText("队伍不满{1}人"), GameConfig.hero_team_num))

			return
		end

		local _, stageID = InfoDungeon.getStage()

		FRAME_dust_enter.open(stageID)
	elseif index == 2 then
		local _, stageID = InfoDungeon.getStage()

		FRAME_dust_mirror.open(self.npc, stageID)
	end
end

return NAV_dust_enter
