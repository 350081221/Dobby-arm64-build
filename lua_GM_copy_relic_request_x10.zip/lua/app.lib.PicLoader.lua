local PicLoader = {}
local loading_map = {}

local function checkDirOK(path)
	require("lfs")

	local oldpath = lfs.currentdir()

	if lfs.chdir(path) then
		lfs.chdir(oldpath)

		return true
	end

	if lfs.mkdir(path) then
		return true
	end
end

function PicLoader.loadArr(urlArr, callback)
	if #urlArr == 0 and callback then
		callback({})
	end

	local arr = {}
	local index = 1
	local onLoadOne, loadNext = nil

	function onLoadOne(path)
		table.insert(arr, path)

		index = index + 1

		if index > #urlArr then
			if callback then
				callback(arr)
			end
		else
			loadNext()
		end
	end

	function loadNext()
		local url = urlArr[index]

		PicLoader.load(url, onLoadOne)
	end

	loadNext()
end

function PicLoader.load(url, callback)
	url = string.trim(url)
	local dir = cc.FileUtils:getInstance():getWritablePath() .. "picture/"

	checkDirOK(dir)

	local path = dir .. crypto.md5(url)

	if io.exists(path) then
		pcall(callback, path)

		return
	end

	if loading_map[url] then
		table.insert(loading_map[url], callback)

		return
	end

	loading_map[url] = {
		callback
	}
	local request = network.createHTTPRequest(function (event)
		if event.name == "completed" then
			local dataRecv = event.request:getResponseData()
			local result = io.writefile(path, dataRecv)
			local callbackArr = loading_map[url]
			loading_map[url] = nil

			if callbackArr then
				for i, callback in ipairs(callbackArr) do
					pcall(callback, path)
				end
			end
		end
	end, url, "GET")

	if request then
		request:setTimeout(waittime or 60)
		request:start()
	end
end

return PicLoader
