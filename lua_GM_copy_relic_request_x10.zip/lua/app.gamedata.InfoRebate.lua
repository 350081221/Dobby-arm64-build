local InfoRebate = {}
local rawData = {}

function InfoRebate.init()
	Connection.listen("rebate_push", InfoRebate.onPush)
end

app:addToAppEnterCall(InfoRebate.init)

function InfoRebate.query(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "rebate_query")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoRebate.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("rebate_query", callback)
end

function InfoRebate.onQuery(rcvData)
end

function InfoRebate.onPush(data)
	dump(data, "$$$ InfoRebate.onPush")

	rawData = data
end

function InfoRebate.checkReward()
	if rawData and rawData.rebate_num and rawData.rebate_num > 0 then
		POP_notice.open(Localization.getSrcText("返利奖励只能领取一次，是否使用本角色领取？"), function ()
			local function callback(rcvData)
				dump(rcvData, "rebate_req")

				if not rcvData.err then
					Alert.open(Localization.getSrcText("奖励已通过邮件发送，感谢您的支持！"))
				end
			end

			Connection.request("rebate_req", callback)
		end)
	end
end

return InfoRebate
