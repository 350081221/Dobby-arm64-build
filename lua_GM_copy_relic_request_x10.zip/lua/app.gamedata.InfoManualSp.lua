local InfoManualSp = {}
local rawData = {}

function InfoManualSp.init()
	Connection.listen("manual_sp_sync", InfoManualSp.sync)
end

app:addToAppEnterCall(InfoManualSp.init)

function InfoManualSp.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoManualSp.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("manual_sp_query", callback)
end

function InfoManualSp.onQuery(rcvData)
	dump(rcvData, "manual_sp_query")

	rawData = {}

	for i, data in ipairs(rcvData.list) do
		rawData[data.base_id] = data
	end
end

function InfoManualSp.sync(data)
	for i, syncData in ipairs(data.list) do
		local base_id = syncData.base_id

		if rawData[base_id] then
			for k, v in pairs(syncData) do
				rawData[base_id][k] = v
			end
		else
			rawData[base_id] = syncData
		end
	end

	ManagerInfo.dataChange("manual_sp")
end

function InfoManualSp.mark(arr, onSuccess, onFailure)
	local id_arr = {}

	for i, manualID in ipairs(arr) do
		if rawData[manualID] and rawData[manualID].is_new == 1 then
			table.insert(id_arr, manualID)
		end
	end

	if #id_arr == 0 then
		return
	end

	local function callback(rcvData)
		dump(rcvData, "manual_sp_mark")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("manual_sp_mark", {
		id_arr = id_arr
	}, callback)
end

function InfoManualSp.getData(base_id)
	return rawData[base_id]
end

function InfoManualSp.getHeroInfo(sp_id)
	local manualToHeroMap = CacheData.get("InfoManualSp_manualToHeroMap")

	if not manualToHeroMap then
		manualToHeroMap = {}
		local csvList = CsvParser.getCsvList("hero")

		for i, csv in ipairs(csvList) do
			if not empty(csv.sp_id) and not manualToHeroMap[csv.sp_id] then
				manualToHeroMap[csv.sp_id] = csv.id
			end
		end

		CacheData.set("InfoManualSp_manualToHeroMap", manualToHeroMap)
	end

	local spCSV = CsvParser.getCsvData("hero_sp", sp_id)
	local randomHeroCSV = CsvParser.getCsvData("random_hero", spCSV.random_hero)
	local manualCSV = CsvParser.getCsvData("manual_sp", sp_id)
	local heroID = manualCSV.hero_id

	if empty(heroID) then
		heroID = manualToHeroMap[sp_id]
	end

	local gender = SheetUtil.getNumber(randomHeroCSV.gender)
	local heroInfo = {
		level = 1,
		base_id = heroID,
		name = spCSV.name,
		gender = gender,
		quality = spCSV.quality,
		body = SheetUtil.getString(randomHeroCSV["body_" .. gender]),
		hair = SheetUtil.getString(randomHeroCSV["fixed_hair_" .. gender])
	}

	return heroInfo
end

function InfoManualSp.getList()
	local csvList = CsvParser.getCsvList("manual_sp")

	return csvList
end

function InfoManualSp.countRedot()
	local redotCount = 0
	local csvList = CsvParser.getCsvList("manual_sp")
	local existMap = {}

	for i, csv in ipairs(csvList) do
		if rawData[csv.id] and rawData[csv.id].is_new == 1 then
			redotCount = redotCount + 1
		end
	end

	return redotCount
end

return InfoManualSp
