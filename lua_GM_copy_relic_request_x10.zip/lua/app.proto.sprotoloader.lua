local parser = require("sprotoparser")
local core = require("sproto.core")
local sproto = require("sproto")
local loader = {
	register = function (filename, index)
		local f = assert(io.open(filename), "Can't open sproto file")
		local data = f:read("a")

		f:close()

		local sp = core.newproto(parser.parse(data))

		core.saveproto(sp, index)
	end,
	save = function (bin, index)
		local sp = core.newproto(bin)

		core.saveproto(sp, index)
	end,
	load = function (index)
		local sp = core.loadproto(index)

		return sproto.sharenew(sp)
	end
}

return loader
