local CsvParser = import("..lib.CsvParser")
local Localization = {}
local langsArr, langsMap, langSheetTextMap, langUiTextMap, langSrcTextMap, langSpHeroMap, langRobotNameMap = nil

function Localization.getLangArr()
	local langsArr = CsvParser.loadArr("lang", true)
	local arr = {}

	for i, v in ipairs(langsArr) do
		if (DEV_MODE or v.is_dev ~= 1) and (not InfoLang or InfoLang.getOpen(v.id)) then
			table.insert(arr, v)
		end
	end

	return arr
end

function Localization.init(code)
	if Cookie then
		local STD_LANG_READY = Cookie.get("STD_LANG_READY")

		if not STD_LANG_READY then
			local sysLang = Localization.getSysLang()

			Cookie.set("current_language", sysLang, true)

			if InfoVars then
				InfoVars.set("language", sysLang)
				Cookie.set("STD_LANG_READY", true, true)
			end
		end
	end

	langsArr = Localization.getLangArr()
	langsMap = {}

	for i, v in ipairs(langsArr) do
		langsMap[v.id] = v
	end

	langSheetTextMap = {}
	local csvArr = CsvParser.loadArr("lang_sheet_text")

	for i, v in ipairs(csvArr) do
		if not langSheetTextMap[v.sheet] then
			langSheetTextMap[v.sheet] = {}
		end

		if not langSheetTextMap[v.sheet][v.sheet_id] then
			langSheetTextMap[v.sheet][v.sheet_id] = {}
		end

		langSheetTextMap[v.sheet][v.sheet_id][v.column] = v
	end

	langUiTextMap = {}
	local csvArr = CsvParser.loadArr("lang_ui_text")

	for i, v in ipairs(csvArr) do
		langUiTextMap[v.id] = v
	end

	langSrcTextMap = {}
	local csvArr = CsvParser.loadArr("lang_src_text")

	for i, v in ipairs(csvArr) do
		langSrcTextMap[v.id] = v
	end

	langSpHeroMap = {}
	local csvArr = CsvParser.loadArr("lang_sphero_text")

	for i, v in ipairs(csvArr) do
		langSpHeroMap[v.id] = v
	end

	langRobotNameMap = {}
	local csvArr = CsvParser.loadArr("lang_robot_name")

	for i, v in ipairs(csvArr) do
		langRobotNameMap[v.id] = v
	end

	if Cookie then
		local lang = nil

		if InfoVars then
			lang = InfoVars.get("language")

			if lang and lang ~= "" and Cookie.get("current_language") ~= lang then
				Cookie.set("current_language", lang, true)
			end
		end

		if (not lang or lang == "") and not Cookie.get("current_language") then
			Cookie.set("current_language", Localization.getSysLang())
		end
	end

	Localization.refreshFont()
end

function Localization.getSysLang()
	local langsArr = Localization.getLangArr()
	local lang_sys = CONFIG.lang_sys
	local country_sys = CONFIG.country_sys

	if device.platform == "ios" then
		if string.sub(lang_sys, 1, 7) == "zh-Hans" then
			lang_sys = "zh"
		elseif string.sub(lang_sys, 1, 7) == "zh-Hant" then
			lang_sys = "zh"
			country_sys = "TW"
		else
			lang_sys = string.sub(lang_sys, 1, 2)
		end
	end

	local sysLang = GameConfig.std_lang

	for i, csv in ipairs(langsArr) do
		if csv.sys and csv.sys ~= "" then
			local sysArr = string.split(csv.sys, ";")

			for k, sysStr in pairs(sysArr) do
				local arr = string.split(sysStr, "-")

				if arr[2] then
					if arr[1] == lang_sys and arr[2] == country_sys then
						sysLang = csv.id

						break
					end
				elseif sysStr == lang_sys then
					sysLang = csv.id

					break
				end
			end
		end
	end

	if device.platform == "ios" then
		print("$$$ getSysLang", lang_sys, country_sys, sysLang)
	end

	return sysLang
end

local originalSheetTextMap = {}

function Localization.getSheetText(sheet, id, column)
	local lang = Localization.getLang()

	if lang == GameConfig.default_lang or not langSheetTextMap then
		return nil
	end

	if langSheetTextMap[sheet] and langSheetTextMap[sheet][id] and langSheetTextMap[sheet][id][column] then
		local text = langSheetTextMap[sheet][id][column][lang]

		if text and text ~= "" then
			text = string.gsub(text, "\\n", "\n")

			if DEV_MODE then
				originalSheetTextMap[text] = langSheetTextMap[sheet][id][column].text
			end

			return text
		end
	end
end

function Localization.getSheetOrginal(text)
	if DEV_MODE then
		return originalSheetTextMap[text] or text
	else
		return ""
	end
end

function Localization.getUiText(text)
	local lang = Localization.getLang()

	if lang == GameConfig.default_lang or not langUiTextMap then
		return text
	end

	if langUiTextMap[text] then
		local newText = langUiTextMap[text][lang]

		if newText and newText ~= "" then
			newText = string.gsub(newText, "\\n", "\n")

			return newText
		end
	end

	return text
end

function Localization.getSrcText(text)
	text = string.gsub(text, "\n", "\\n")
	local lang = Localization.getLang()

	if lang == GameConfig.default_lang or not langSrcTextMap then
		return text
	end

	if langSrcTextMap[text] then
		local newText = langSrcTextMap[text][lang]

		if newText and newText ~= "" then
			return newText
		end
	end

	return text
end

function Localization.getSpHeroName(id)
	local nameCSV = langSpHeroMap[tostring(id)]

	if nameCSV then
		local lang = Localization.getLang()

		return nameCSV[lang]
	end
end

function Localization.getRobotName(id)
	local nameCSV = langRobotNameMap[tostring(id)]

	if nameCSV then
		local lang = Localization.getLang()

		return nameCSV[lang]
	end
end

function Localization.getLangList()
	return langsArr
end

function Localization.getLang(isUpdate)
	local lang = nil

	if CONFIG.lang_multi or isUpdate then
		if InfoVars then
			local _lang = InfoVars.get("language")

			if _lang and _lang ~= "" then
				lang = _lang
			end
		end

		if not lang and Cookie then
			local _lang = Cookie.get("current_language")

			if _lang and _lang ~= "" then
				lang = _lang
			end
		end

		if not lang then
			lang = CONFIG.lang
		end
	else
		lang = CONFIG.lang
	end

	if lang and lang ~= "" and langsMap[lang] then
		return lang
	end

	return GameConfig.std_lang
end

function Localization.isAlphabet()
	local currentLang = Localization.getLang()

	if langsMap[currentLang] then
		return langsMap[currentLang].is_alphabet == 1
	end
end

function Localization.setLangVar(lang)
	Cookie.set("current_language", lang, true)
	InfoVars.set("language", lang)
end

function Localization.setLang(lang)
	if not langsMap[lang] then
		return
	end

	if Localization.getLang() ~= lang then
		Localization.setLangVar(lang)
		Localization.refreshLocalization()
	end
end

function Localization.getLangName(lang)
	local langCSV = langsMap[lang]
	local currentLang = Localization.getLang()

	if langsMap[currentLang] then
		local csv = langsMap[currentLang]
		local font_name_arr = string.split(csv.font_name, ",")

		for i, v in ipairs(font_name_arr) do
			if v == lang then
				return langCSV.name
			end
		end
	end

	return langCSV.name_en
end

function Localization.getFont(lang)
	local csv = CsvParser.getCsvData("lang", lang)

	if device.platform == "ios" then
		if csv.font_ios and csv.font_ios ~= "" then
			return csv.font_ios
		end
	elseif csv.font and csv.font ~= "" then
		return csv.font
	end
end

function Localization.refreshFont()
	local currentLang = Localization.getLang()

	if langsMap[currentLang] then
		local csv = langsMap[currentLang]

		if device.platform == "ios" then
			if csv.font_ios and csv.font_ios ~= "" then
				Style.defaultFont = csv.font_ios
			end
		elseif csv.font and csv.font ~= "" then
			Style.defaultFont = csv.font
		end

		if global then
			if device.platform == "ios" then
				global.LINE_OFFSET = tonumber(csv.ios_line_offset)
			else
				global.LINE_OFFSET = tonumber(csv.line_offset)
			end
		end
	end

	print("$$ Style.defaultFont", Style.defaultFont)
end

function Localization.refreshLocalization()
	Log.debug("Localization.refreshLocalization", Localization.getLang())
	RefreshManager.clearCache()
	CsvParser.clearCache()
	LinesManager.clearCache()
	CombatAttr.clearCache()
	InfoOrder.clearCache()
	InfoDungeon.clearCache()
	Localization.refreshFont()
	app:resetScene()
end

function Localization.getText(str)
	return str, false
end

function Localization.getTextByLang(str)
	local arr = nil

	if string.find(str, "|") then
		arr = string.split(str, "|")
	else
		arr = {
			str
		}
	end

	local langMap = {}

	for i, str1 in ipairs(arr) do
		local splitIndex = string.find(str1, ":")

		if splitIndex then
			local l = string.sub(str1, 1, splitIndex - 1)
			local s = string.sub(str1, splitIndex + 1)

			if not empty(l) and not empty(s) then
				langMap[l] = s
			end
		end
	end

	local lang = Localization.getLang()

	if langMap[lang] then
		return langMap[lang]
	end

	if langMap[GameConfig.default_lang] then
		return langMap[GameConfig.default_lang]
	end

	return str
end

function Localization.getLoneText(id)
	local csv = CsvParser.getCsvData("lang_long_text", id, nil, true)

	if csv then
		local lang = Localization.getLang()
		local text = csv[lang]

		if empty(text) then
			text = csv[GameConfig.default_lang]
		end

		return text
	end

	return ""
end

function Localization.getUiLabel(id)
	local csv = CsvParser.getCsvData("lang_ui_label", id)

	if csv then
		local lang = Localization.getLang()
		local text = csv[lang]

		if empty(text) then
			text = csv[GameConfig.default_lang]
		end

		return text
	end

	return ""
end

local subSymbolCache = {}

function Localization.checkSubSymbol(char, customLang)
	local lang = customLang or Localization.getLang()
	local symbolMap = subSymbolCache[lang]

	if not symbolMap then
		symbolMap = {}
		subSymbolCache[lang] = symbolMap
		local csv = langsMap[lang]

		if csv and not empty(csv.sub_symbol) then
			local arr = string.split(csv.sub_symbol, ",")

			for i, v in ipairs(arr) do
				symbolMap[v] = true
			end
		end
	end

	return symbolMap[char]
end

function Localization.getNewFrame()
	local lang = Localization.getLang()
	local csv = CsvParser.getCsvData("lang", lang)

	if csv then
		return csv.new_frame
	end

	return 2
end

return Localization
