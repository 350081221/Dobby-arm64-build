local List = import("...ui.List")
local LIST_dungeon_prepare_pet = class("LIST_dungeon_prepare_pet", List)

function LIST_dungeon_prepare_pet:ctor(rect)
	LIST_dungeon_prepare_pet.super.ctor(self, rect)
	self:setCellName("cell_dungeon_prepare_pet")
	self:setSpace(5, 5)
	self:setCellSize(cc.size(self.touchRect.width, 110))
end

function LIST_dungeon_prepare_pet:onCellInit(ui, petInfo)
	local petData = InfoPet.getData(petInfo.base_id)
	ui.pickVisibleArr = {}

	table.insert(ui.pickVisibleArr, ui:getComponentByTag("bg"))
	table.insert(ui.pickVisibleArr, ui:getComponentByTag("border"))

	if not ui.slot then
		local slotFlag = ui:getFlagByTag("flag_slot")
		ui.slot = DropSlot.new(slotFlag, "slot_01")

		ui:addChild(ui.slot, 100)
	end

	local label = ui:replaceLabelOnFlag("flag_name_level", nil, petData.name, petInfo.level)

	table.insert(ui.pickVisibleArr, label)

	local label = ui:replaceLabelOnFlag("flag_score", nil, 1000)

	table.insert(ui.pickVisibleArr, label)

	local label = ui:replaceLabelOnFlag("flag_cost", nil, petData.cost)

	table.insert(ui.pickVisibleArr, label)
	ui.slot:setDrop(DropManager.TYPE.PET, petInfo)
end

function LIST_dungeon_prepare_pet:onCellPicked(ui, data, picked)
	for i, com in ipairs(ui.pickVisibleArr) do
		com:setVisible(not picked)
	end
end

return LIST_dungeon_prepare_pet
