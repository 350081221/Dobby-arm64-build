local NAV_base = import(".NAV_base")
local NAV_home_postbox = class("NAV_home_postbox", NAV_base)

function NAV_home_postbox.open(npc)
	local ui = NAV_home_postbox.new(npc)

	return ui
end

function NAV_home_postbox:ctor(npc)
	NAV_home_postbox.super.ctor(self, npc, "nav_home_postbox")
end

function NAV_home_postbox:init()
	NAV_pet.super.init(self)
end

function NAV_home_postbox:onTap(index)
	NAV_home_postbox.super.onTap(self, index)

	if index == 1 then
		InfoHome.getVisitors(InfoHome.getHosterID(), function (visitorList)
			FRAME_home_visitor.open(visitorList)

			if InfoHome.isSelf() then
				local npcID = InfoBuilding.getNpcByBuilding(InfoBuilding.TAG.HOME_POSTBOX)
				local postbox = Npc.getInstance(npcID)

				if postbox then
					postbox:setAction("idle")
				end
			end
		end)
	end
end

return NAV_home_postbox
