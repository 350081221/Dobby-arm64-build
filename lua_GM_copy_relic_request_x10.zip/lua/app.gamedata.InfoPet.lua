local InfoPet = {}
local rawData = {}

function InfoPet.init()
	Connection.listen("pet_sync", InfoPet.sync)
	Connection.listen("pet_sync_remove", InfoPet.syncRemove)
	Connection.listen("pet_add_exp", InfoPet.onAddExp)
	Connection.listen("pet_born", InfoPet.onBorn)
end

app:addToAppEnterCall(InfoPet.init)

function InfoPet.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			rawData = {}

			for i, data in ipairs(rcvData.list) do
				rawData[data.id] = data
			end

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("pet_query", callback)
end

function InfoPet.onAddExp(data)
	notify.dispatch("pet_add_exp", data)
end

function InfoPet.onBorn(data)
	local petInfo = InfoPet.getPet(data.id)

	if petInfo then
		POP_pet_born.open(petInfo)
	end
end

function InfoPet.sync(data)
	local teamChanged = false
	local changedIdStack = {}

	for i, syncData in ipairs(data.list) do
		local id = syncData.id

		if not rawData[id] then
			rawData[id] = syncData

			if rawData[id].pos > 0 then
				teamChanged = true
			end
		else
			if rawData[id].pos > 0 then
				teamChanged = true
			end

			for k, v in pairs(syncData) do
				rawData[id][k] = v
			end

			if rawData[id].pos > 0 then
				teamChanged = true
			end
		end

		changedIdStack[id] = rawData[id]
	end

	ManagerInfo.dataChange("pet", changedIdStack)
end

function InfoPet.syncRemove(data)
	dump(data, "$$$ InfoPet.syncRemove")

	local teamChanged = false
	local changedIdStack = {}

	for i, id in ipairs(data.list) do
		if rawData[id] then
			changedIdStack[id] = rawData[id]

			if rawData[id].pos > 0 then
				teamChanged = true
			end

			rawData[id] = nil
		end
	end

	ManagerInfo.dataChange("pet", changedIdStack)
end

function InfoHero.getBestQualityIDByFunc(func)
	local bestQuality, bestID = nil

	for id, petInfo in pairs(rawData) do
		if func(petInfo) and (not bestQuality or bestQuality < petInfo.quality) then
			bestQuality = petInfo.quality
			bestID = petInfo.id
		end
	end

	return bestID
end

function InfoPet.getPet(id)
	return rawData[id]
end

function InfoPet.getName(petInfo)
	local name, isDefault = InfoPet.getNameDefault(petInfo)

	return name
end

function InfoPet.getNameDefault(petInfo)
	local name = petInfo.name
	local isDefault = false

	if empty(name) then
		name = CsvParser.getCsvData("pet", petInfo.base_id).name
		isDefault = true
	end

	return name, isDefault
end

local scoreBuff = nil

function InfoPet.buffScoreStart()
	scoreBuff = {}
end

function InfoPet.buffScoreOver()
	scoreBuff = nil
end

function InfoPet.getScore(petInfo)
	if scoreBuff and scoreBuff[petInfo.id] then
		return scoreBuff[petInfo.id]
	end

	local attr = CombatAttr.getPetAttr(petInfo)

	CombatAttr.finalize(attr, nil, true)

	local attr_raw = CsvParser.getCsvRaw("attr")
	local addTotal = 0
	local multiTotal = 0

	for k, v in pairs(attr_raw) do
		if attr[k] then
			if v.ability_value1 ~= 0 then
				addTotal = addTotal + attr[k] * v.ability_value1
			end

			if v.ability_value2 ~= 0 then
				multiTotal = multiTotal + attr[k] * v.ability_value2
			end
		end
	end

	local score = math.floor(addTotal * (1 + multiTotal))

	if scoreBuff then
		scoreBuff[petInfo.id] = score
	end

	return score
end

function InfoPet.getScoreAll()
	if not rawData then
		return 0
	end

	local score = 0

	for pos = 1, GameConfig.pet_team_num do
		local petInfo = InfoPet.getPetByPos(pos)

		if petInfo then
			score = score + InfoPet.getScore(petInfo)
		end
	end

	return score
end

function InfoPet.getPetByPos(pos)
	for id, petInfo in pairs(rawData) do
		if petInfo.pos == pos then
			return petInfo
		end
	end
end

function InfoPet.getPetByIndex(index)
	if InfoDungeon.isFixedTeam() then
		local team = StageUtils.getFixedPet()

		return team[index]
	else
		local team = InfoPet.getTeam()

		return team[index]
	end
end

function InfoPet.getTeam()
	if InfoDungeon.inDungeon() then
		local stageType, stageID, stageParams = InfoDungeon.getStage()

		if stageType == InfoDungeon.STAGE_TYPE.UNION_SOLO then
			return {}
		end
	end

	if InfoDungeon.isFixedTeam() then
		return StageUtils.getFixedPet()
	end

	local team = {}

	for id, petInfo in pairs(rawData) do
		if petInfo.pos ~= 0 then
			table.insert(team, petInfo)
		end
	end

	table.sort(team, function (a, b)
		return a.pos < b.pos
	end)

	return team
end

function InfoPet.getAll(filterFunc, sortFunc)
	local teamList = {}

	for id, petInfo in pairs(rawData) do
		if not filterFunc or filterFunc(petInfo) then
			table.insert(teamList, petInfo)
		end
	end

	table.sort(teamList, sortFunc or function (petInfoA, petInfoB)
		local posA = petInfoA.pos
		local posB = petInfoB.pos

		if posA == 0 and posB == 0 then
			if petInfoA.level == petInfoB.level then
				if petInfoA.quality == petInfoB.quality then
					return petInfoA.id < petInfoB.id
				else
					return petInfoB.quality < petInfoA.quality
				end
			else
				return petInfoB.level < petInfoA.level
			end
		elseif posA ~= 0 and posB ~= 0 then
			return posA < posB
		else
			return posB < posA
		end
	end)

	return teamList
end

function InfoPet.getFoodList(petInfo)
	local petData = CsvParser.getCsvData("pet", petInfo.base_id)
	local foodArr = SheetUtil.getColumnList(petData, {
		"food_id"
	}, {
		"base_id"
	})

	return foodArr
end

function InfoPet.dismiss(id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("pet_dismiss", {
		id = id
	}, callback)
end

function InfoPet.sell(ids, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ pet_sell")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("pet_sell", {
		ids = ids
	}, callback)
end

function InfoPet.setName(id, name, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ pet_set_name")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("pet_set_name", {
		id = id,
		name = name
	}, callback)
end

function InfoPet.autoOff()
	local posMap = {}

	for id, petInfo in pairs(rawData) do
		if petInfo.pos > 0 then
			if not posMap[petInfo.pos] then
				posMap[petInfo.pos] = {}
			end

			table.insert(posMap[petInfo.pos], petInfo)
		end
	end

	local offArr = {}

	for pos, arr in pairs(posMap) do
		if #arr > 1 then
			local _arr = {}

			for i, petInfo in ipairs(arr) do
				table.insert(_arr, {
					id = petInfo.id,
					score = InfoPet.getScore(petInfo)
				})
			end

			table.sort(_arr, function (a, b)
				return b.score < a.score
			end)

			for i = 2, #_arr do
				table.insert(offArr, {
					pos = 0,
					id = _arr[i].id
				})
			end
		end
	end

	if #offArr > 0 then
		dump(offArr, "$$$ InfoPet.autoOff")
		InfoPet.setposQueue(offArr)
	end
end

function InfoPet.setpos(id, pos, onSuccess, onFailure)
	InfoPet.setposQueue({
		{
			id = id,
			pos = pos
		}
	}, onSuccess, onFailure)
end

function InfoPet.setposQueue(queue, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("pet_setpos", {
		queue = queue
	}, callback)
end

function InfoPet.getPosMax()
	local buildingCSV = InfoBuilding.getBuildingData(InfoBuilding.TAG.PET)
	local pos_max = buildingCSV.value3

	return pos_max
end

function InfoPet.getLevelForPos(pos)
	local csv_list = CsvParser.getCsvList("building", nil, {
		tag = InfoBuilding.TAG.PET
	})

	for i, v in ipairs(csv_list) do
		local pos_max = v.value3

		if pos_max == pos then
			return v.level
		end
	end

	return csv_list[#csv_list].level + 1
end

function InfoPet.count()
	local count = 0

	for id, petInfo in pairs(rawData) do
		count = count + 1
	end

	local buildingCSV = InfoBuilding.getBuildingData(InfoBuilding.TAG.PET)

	return count, buildingCSV.value2
end

function InfoPet.getExp(petInfo, customBuildingLevel)
	local expUpg = CsvParser.getCsvData("pet_base_num", petInfo.level).exp
	local petCSV = CsvParser.getCsvData("pet", petInfo.base_id)
	local level = petInfo.level
	local buildingCSV = InfoBuilding.getBuildingData(InfoBuilding.TAG.PET, customBuildingLevel)
	local maxLevel = math.min(petCSV.lv_max, buildingCSV.value1)
	local jobMaxLevel = petCSV.lv_max
	local buildingMax = buildingCSV.value1
	local displayLevel = level

	if petCSV.job_level > 0 then
		local preCSV = CsvParser.getFilteredData("pet", {
			next_id = petInfo.base_id
		})
		displayLevel = level - (preCSV.lv_max - 1)
		jobMaxLevel = jobMaxLevel + 1 - preCSV.lv_max
		buildingMax = buildingMax + 1 - preCSV.lv_max
	end

	local displayMaxLevel = nil

	if InfoDungeon.isFixedTeam() then
		displayMaxLevel = jobMaxLevel
	else
		displayMaxLevel = math.min(jobMaxLevel, buildingMax)
	end

	if InfoPet.isPeak(petInfo) then
		local peakCSV, perkMaxLevel = InfoPet.getPeakCSV(petInfo.level)
		displayLevel = peakCSV.level
		displayMaxLevel = perkMaxLevel
	end

	return petInfo.exp, expUpg, level, maxLevel, displayLevel, displayMaxLevel, jobMaxLevel
end

function InfoPet.getTransferMats(petInfo)
	local petCSV = CsvParser.getCsvData("pet", petInfo.base_id)
	local petQualityCSV = CsvParser.getCsvData("pet_quality", petInfo.quality)
	local all_mat_map = {}
	local itemID = petQualityCSV.star_item
	local itemNumArr = string.split(petQualityCSV.star_num, ",")
	local itemNum = tonumber(itemNumArr[petCSV.job_level + 1])

	if not all_mat_map[itemID] then
		all_mat_map[itemID] = 0
	end

	all_mat_map[itemID] = all_mat_map[itemID] + itemNum
	local itemID = petCSV.patch_id
	local itemNumArr = string.split(petQualityCSV.patch_num, ",")
	local itemNum = tonumber(itemNumArr[petCSV.job_level + 1])

	if not all_mat_map[itemID] then
		all_mat_map[itemID] = 0
	end

	all_mat_map[itemID] = all_mat_map[itemID] + itemNum
	local all_mat_arr = {}

	for base_id, num in pairs(all_mat_map) do
		table.insert(all_mat_arr, {
			base_id = base_id,
			num = num
		})
	end

	table.sort(all_mat_arr, function (a, b)
		return a.base_id < b.base_id
	end)

	return all_mat_arr
end

function InfoPet.transfer(id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ pet_transfer")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("pet_transfer", {
		id = id
	}, callback)
end

function InfoPet.getEquipListOnPet(petInfo)
	if type(petInfo) ~= "table" then
		petInfo = rawData[tonumber(petInfo)]
	end

	local arr = {}

	for i = 1, GameConfig.max_pet_equip do
		local equipID = InfoPet.getEquipOnPet(petInfo, i)

		if not empty(equipID) then
			table.insert(arr, equipID)
		end
	end

	return arr
end

function InfoPet.getEquipOnPet(petInfo, equipPos)
	if type(petInfo) ~= "table" then
		petInfo = rawData[tonumber(petInfo)]
	end

	if not empty(petInfo) then
		local equipID = petInfo["equip_" .. equipPos]

		if not empty(equipID) then
			return equipID
		end
	end
end

function InfoPet.equipon(equipID, petID, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ pet_equip_on")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoFirstAchieve.fxxkCheck380(petID)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("pet_equip_on", {
		pet_id = petID,
		equip_id = equipID
	}, callback)
end

function InfoPet.equipoff(equipID, petID, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ pet_equip_off")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("pet_equip_off", {
		pet_id = petID,
		equip_id = equipID
	}, callback)
end

local scoreBuff = {}

function InfoPet.getEquipScore(equipID)
	if scoreBuff and scoreBuff[equipID] then
		return scoreBuff[equipID]
	end

	local attr = CombatAttr.getPetEquipAttr(equipID)
	local attr_raw = CsvParser.getCsvRaw("attr")
	local addTotal = 0

	for k, v in pairs(attr_raw) do
		if attr[k] and v.ability_value1 ~= 0 then
			addTotal = addTotal + attr[k] * v.ability_value1
		end
	end

	local score = math.floor(addTotal)

	if scoreBuff then
		scoreBuff[equipID] = score
	end

	return score
end

function InfoPet.getEquipClassDesc(equipID)
	local equipData = CsvParser.getCsvData("pet_equip", equipID)
	local classData = CsvParser.getCsvData("pet_equip_class", equipData.class)

	return classData.name
end

local petIndexBattle = nil

function InfoPet.onBattleStart()
	petIndexBattle = nil
end

function InfoPet.getPetIndex()
	if WarMachine.on and petIndexBattle then
		return petIndexBattle
	end

	return InfoQuickSlots.getPetIndex()
end

function InfoPet.setPet(index, onSuccess, onFailure)
	if InfoPet.getPetIndex() == index then
		return
	end

	if WarMachine.on then
		return
	end

	InfoQuickSlots.setPet(index, onSuccess, onFailure)
end

function InfoPet.getJobTree(baseID)
	local prePetCache = CacheData.get("InfoPet_prePetCache")

	if not prePetCache then
		prePetCache = {}
		local pet_raw = CsvParser.getCsvRaw("pet")

		for k, v in pairs(pet_raw) do
			if not empty(v.next_id) then
				prePetCache[v.next_id] = v.id
			end
		end

		CacheData.set("InfoPet_prePetCache", prePetCache)
	end

	local arr = {
		baseID
	}

	while prePetCache[baseID] and prePetCache[baseID] ~= baseID do
		baseID = prePetCache[baseID]

		table.insert(arr, 1, baseID)
	end

	return arr
end

function InfoPet.getBaseJob(baseID)
	local baseID = InfoPet.getJobTree(baseID)[1]

	return baseID
end

function InfoPet.getJoblevel(petInfo, level)
	local petCSV = CsvParser.getCsvData("pet", InfoPet.getBaseJob(petInfo.base_id))
	local jobLevel = petCSV.job_level

	while petCSV do
		if level < petCSV.lv_max then
			break
		end

		if not empty(petCSV.next_id) then
			jobLevel = petCSV.job_level + 1
			petCSV = CsvParser.getCsvData("pet", petCSV.next_id)
		else
			break
		end
	end

	return jobLevel
end

function InfoPet.getAttrRatio(petInfo, attr)
	local petCSV = CsvParser.getCsvData("pet", petInfo.base_id)

	return SheetUtil.getLinearNumber(petCSV[attr .. "_ratio"], (petInfo[attr .. "_seed"] or 0) / 65536)
end

function InfoPet.getAttrRank(petInfo, attr)
	local qualityList = CsvParser.getCsvList("pet_quality")
	local percent = (petInfo[attr .. "_seed"] or 0) / 65536
	local attrRank = nil

	for i, v in ipairs(qualityList) do
		if percent <= v.growth_value then
			attrRank = v

			break
		end
	end

	attrRank = attrRank or qualityList[#qualityList]
	local name = attrRank.name

	if not InfoFunction.checkFuncOpen(10201) then
		name = ""
	end

	return name, InfoHero.getQualityColor(attrRank.id)
end

function InfoPet.getSynthListFor(petInfo)
	local arr = {}
	local preData = {}

	for i, attr in ipairs(CombatAttr.attrs) do
		local attrRatio = InfoPet.getAttrRatio(petInfo, attr)
		preData[attr] = attrRatio
	end

	local baseJob = InfoPet.getBaseJob(petInfo.base_id)

	for id, info in pairs(rawData) do
		if petInfo.id ~= info.id and info.locked ~= 1 and baseJob == InfoPet.getBaseJob(info.base_id) and petInfo.quality == info.quality then
			local hasUp = false
			local newInfo = ObjUtil.clone(info)
			newInfo.base_id = petInfo.base_id
			newInfo.level = petInfo.level

			for i, attr in ipairs(CombatAttr.attrs) do
				local attrRatio = InfoPet.getAttrRatio(newInfo, attr)

				if preData[attr] < attrRatio then
					hasUp = true

					break
				end
			end

			if hasUp then
				table.insert(arr, info)
			end
		end
	end

	return arr
end

function InfoPet.synth(id, synth_id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("pet_synth", {
		id = id,
		synth_id = synth_id
	}, callback)
end

function InfoPet.getPreJob(base_id)
	local preJobCache = CacheData.get("InfoPet_preJobCache")

	if not preJobCache then
		preJobCache = {}
		local csvRaw = CsvParser.getCsvRaw("pet")

		for k, csv in pairs(csvRaw) do
			if not empty(csv.next_id) then
				preJobCache[csv.next_id] = csv.id
			end
		end

		CacheData.set("InfoPet_preJobCache", preJobCache)
	end

	return preJobCache[base_id]
end

function InfoPet.getJobLevelCSV(base_id, jobLevel)
	local csv = CsvParser.getCsvData("pet", base_id)

	while jobLevel < csv.job_level do
		csv = CsvParser.getCsvData("pet", InfoPet.getPreJob(csv.id))
	end

	while csv.job_level < jobLevel do
		csv = CsvParser.getCsvData("pet", csv.next_id)
	end

	return csv
end

function InfoPet.exchange(id_1, id_2, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("pet_exchange", {
		id_1 = id_1,
		id_2 = id_2
	}, callback)
end

function InfoPet.lock(id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("pet_lock", {
		pet_id = id
	}, callback)
end

function InfoPet.getQualityUpMats(petInfo, newPetInfo)
	local infoArr = {
		petInfo,
		newPetInfo
	}
	local matMap = {}

	for i, info in ipairs(infoArr) do
		local petCSV = CsvParser.getCsvData("pet", info.base_id)
		local petQualityCSV = CsvParser.getCsvData("pet_quality", info.quality)
		local all_mat_map = {}
		local itemID = petQualityCSV.star_item
		local itemNumArr = string.split(petQualityCSV.star_num, ",")
		local itemNum = 0

		for j = 1, petCSV.job_level do
			itemNum = itemNum + (tonumber(itemNumArr[j]) or 0)
		end

		if itemNum > 0 then
			if not all_mat_map[itemID] then
				all_mat_map[itemID] = 0
			end

			all_mat_map[itemID] = all_mat_map[itemID] + itemNum
		end

		local itemID = petCSV.patch_id
		local itemNumArr = string.split(petQualityCSV.patch_num, ",")
		local itemNum = 0

		for j = 1, petCSV.job_level do
			itemNum = itemNum + (tonumber(itemNumArr[j]) or 0)
		end

		if itemNum > 0 then
			if not all_mat_map[itemID] then
				all_mat_map[itemID] = 0
			end

			all_mat_map[itemID] = all_mat_map[itemID] + itemNum
		end

		matMap[i] = all_mat_map
	end

	local preMatMap = matMap[1]
	local newMatMap = matMap[2]
	local pet_quality_up_item = CsvParser.getCsvData("config", "pet_quality_up_item").value
	local matArr = {
		{
			num = 1,
			base_id = pet_quality_up_item
		}
	}

	for itemID, itemNum in pairs(newMatMap) do
		if preMatMap[itemID] then
			local num = itemNum - preMatMap[itemID]

			if num > 0 then
				table.insert(matArr, {
					base_id = itemID,
					num = num
				})
			end
		else
			table.insert(matArr, {
				base_id = itemID,
				num = itemNum
			})
		end
	end

	return matArr
end

function InfoPet.qualityUp(id, onSuccess, onFailure)
	print("$$$ InfoPet.qualityUp", id)

	local function callback(rcvData)
		dump(rcvData, "$$$ pet_quality_up")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("pet_quality_up", {
		id = id
	}, callback)
end

function InfoPet.isPeakReady(petInfo)
	return GameConfig.pet_peak_level <= petInfo.level
end

function InfoPet.isPeak(petInfo)
	return GameConfig.pet_peak_level < petInfo.level
end

function InfoPet.peakMaxLevel()
	local maxID = CsvParser.getMaxID("pet_peak_level")
	local csv = CsvParser.getCsvData("pet_peak_level", maxID)

	return csv.pet_level
end

local peakPetLevelCache, peakStarMaxLevelCachePet = nil

function InfoPet.getPeakCSV(petLevel)
	if not peakPetLevelCache then
		peakPetLevelCache = {}
		peakStarMaxLevelCachePet = {}
		local csvList = CsvParser.getCsvList("pet_peak_level")

		for i, csv in ipairs(csvList) do
			peakPetLevelCache[csv.pet_level] = csv.id
			peakStarMaxLevelCachePet[csv.star] = csv.level
		end
	end

	if peakPetLevelCache[petLevel] then
		local csv = CsvParser.getCsvData("pet_peak_level", peakPetLevelCache[petLevel])

		return csv, peakStarMaxLevelCachePet[csv.star]
	end
end

function InfoPet.getStar(petInfo)
	local STAR_TYPE = InfoHero.STAR_TYPE

	if InfoPet.isPeak(petInfo) then
		local peakCSV = InfoPet.getPeakCSV(petInfo.level)

		return STAR_TYPE.PEAK, peakCSV.star
	else
		local petCSV = CsvParser.getCsvData("pet", petInfo.base_id)
		local starNum = petCSV.job_level + 1

		return STAR_TYPE.NORMAL, starNum
	end
end

function InfoPet.getPassiveBuff(petCopy, petCopyIndex)
	local team, petIndex = nil

	if petCopy then
		team = petCopy
		petIndex = petCopyIndex
	else
		if InfoDungeon.isFixedTeam() then
			team = StageUtils.getFixedPet()
		else
			team = InfoPet.getTeam()
		end

		petIndex = InfoPet.getPetIndex()
	end

	local baseMap = {}

	for i, petInfo in ipairs(team) do
		if i ~= petIndex and petInfo.passive_level and petInfo.passive_level > 0 then
			local petCSV = CsvParser.getCsvData("pet", petInfo.base_id)

			if petCSV then
				local passiveList = CsvParser.getCsvList("pet_passive", nil, {
					pet_id = petCSV.base_id
				})
				local passiveCSV = passiveList[petInfo.passive_level]

				if passiveCSV then
					if not baseMap[petCSV.base_id] then
						baseMap[petCSV.base_id] = {
							level = petInfo.passive_level,
							csv = passiveCSV,
							petInfo = petInfo
						}
					elseif baseMap[petCSV.base_id].level < petInfo.passive_level then
						baseMap[petCSV.base_id] = {
							level = petInfo.passive_level,
							csv = passiveCSV,
							petInfo = petInfo
						}
					end
				end
			end
		end
	end

	local allBuffs = {}

	for base_id, v in pairs(baseMap) do
		local passiveCSV = v.csv
		local petInfo = v.petInfo
		local buffArr = SheetUtil.getColumnList(passiveCSV, {
			"buff_",
			"buff_target_",
			"buff_time_"
		}, {
			"id",
			"target",
			"time"
		})

		for j, buffData in ipairs(buffArr) do
			table.insert(allBuffs, {
				buffData = buffData,
				petInfo = petInfo
			})
		end
	end

	return allBuffs
end

function InfoPet.peakUp(id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("pet_peak_up", {
		id = id
	}, callback)
end

function InfoPet.passiveUp(id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("pet_passive_up", {
		id = id
	}, callback)
end

return InfoPet
