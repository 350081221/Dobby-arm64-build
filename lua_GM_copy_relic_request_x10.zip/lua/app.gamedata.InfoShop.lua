local InfoShop = {}
local rawData = nil
local shopListMap = {}
local shopRefreshIndex = {}

function InfoShop.init()
	Connection.listen("shop_sync", InfoShop.sync)
end

app:addToAppEnterCall(InfoShop.init)

function InfoShop.clear()
	shopListMap = {}
	shopRefreshIndex = {}
	rawData = nil
end

function InfoShop.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoShop.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("shop_query", callback)
end

function InfoShop.onQuery(rcvData)
	rawData = rcvData
end

function InfoShop.sync(data)
	dump(data, "$$$ InfoShop.sync")

	for k, v in pairs(data) do
		rawData[k] = v
	end

	ManagerInfo.dataChange("shop", data)
end

function InfoShop.getShopList(type, _callback)
	local needQuery = shopListMap[type] == nil

	if type ~= 3 then
		if not needQuery and rawData["refresh_time_" .. type] < Time.now() then
			needQuery = true
		end
	else
		needQuery = needQuery or rawData["opening_" .. type] == 0
	end

	if needQuery then
		local function callback(rcvData)
			if rcvData.err then
				-- Nothing
			else
				InfoShop.onGetShopList(type, rcvData.items)

				if _callback then
					_callback(shopListMap[type])
				end
			end
		end

		Connection.request("shop_list", {
			type = type
		}, callback)
	else
		_callback(shopListMap[type])
	end
end

function InfoShop.onGetShopList(type, items)
	shopRefreshIndex[type] = (shopRefreshIndex[type] or 0) + 1
	shopListMap[type] = items
end

function InfoShop.refresh(type, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoShop.onGetShopList(type, rcvData.items)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("shop_refresh", {
		type = type
	}, callback)
end

function InfoShop.buyMarket(type, shop_id, onSuccess, onFailure)
	if CONFIG.is_ta then
		local shopCSV = CsvParser.getCsvData("shop", shop_id)

		if shopCSV.type == 1 then
			TaHelper.startAsset("shop_buy_market_1")
		elseif shopCSV.type == 2 then
			TaHelper.startAsset("shop_buy_market_2")
		end
	end

	local preIndex = InfoShop.getRefreshIndex(type)

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if rcvData.item then
				local item = rcvData.item

				InfoShop.onBuyItem(type, item, preIndex)
			end

			if CONFIG.is_ta then
				TaHelper.endAsset()
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("shop_buy_market", {
		type = type,
		shop_id = shop_id
	}, callback)
end

function InfoShop.getRefreshIndex(type)
	return shopRefreshIndex[type] or 0
end

function InfoShop.onBuyItem(type, item, preIndex)
	local refreshIndex = shopRefreshIndex[type] or 0
	local shopList = shopListMap[type]

	if preIndex == refreshIndex then
		for i, v in ipairs(shopList) do
			if v.shop_id == item.shop_id then
				for k1, v1 in pairs(item) do
					v[k1] = v1
				end
			end
		end
	end
end

function InfoShop.getShopItems(type)
	local itemArr = shopListMap[type] or {}

	table.sort(itemArr, function (a, b)
		return a.shop_id < b.shop_id
	end)

	return itemArr
end

function InfoShop.getRefreshInfo(type)
	local refresh_time = rawData["refresh_time_" .. type]
	local refresh_count = rawData["refresh_count_" .. type]
	local refresh_count_time = rawData["refresh_count_time_" .. type]

	return refresh_time, refresh_count, refresh_count_time
end

function InfoShop.getNextRefreshTime(type)
	return RefreshManager.getNextTime(RefreshManager.TYPE["SHOP_" .. type], Time.now())
end

local SELL_TABS = {
	{
		label = "装备",
		index = 1,
		type = DropManager.TYPE.EQUIP
	},
	{
		label = "套装",
		index = 2,
		isSuit = true,
		type = DropManager.TYPE.EQUIP
	},
	{
		label = "卡片",
		index = 3,
		type = DropManager.TYPE.CARD
	},
	{
		label = "道具",
		index = 4,
		type = DropManager.TYPE.ITEM
	},
	{
		label = "时装",
		index = 5,
		isAvatar = true,
		type = DropManager.TYPE.EQUIP
	},
	{
		label = "尘封装备",
		isDust = true,
		index = 6,
		type = DropManager.TYPE.EQUIP,
		checkFunc = function ()
			local opening = InfoParams.getValue("dust")

			return opening == 1
		end
	},
	{
		label = "魔纹",
		index = 7,
		type = DropManager.TYPE.SIGIL,
		checkFunc = function ()
			return InfoParams.getValue("sigil") == 1
		end
	}
}

function InfoShop.sell(type, index, list, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("shop_sell", {
		type = type,
		index = index,
		list = list
	}, callback)
end

function InfoShop.getSellTabs()
	local arr = {}

	for i, v in ipairs(SELL_TABS) do
		if not v.checkFunc or v.checkFunc() then
			table.insert(arr, v)
		end
	end

	return arr
end

function InfoShop.getSellList(tabIndex)
	local list = {}

	if tabIndex == 1 then
		local function filterFunc(data)
			local equipInfo = data.info
			local equipCSV = CsvParser.getCsvData("equip", equipInfo.base_id)

			if empty(equipInfo.dust_id) and equipCSV.is_avatar ~= 1 and equipInfo.locked == 0 and empty(equipCSV.suit_id) and equipInfo.hero_id == 0 then
				return true
			end
		end

		list = InfoEquip.getWareList(filterFunc)
	elseif tabIndex == 2 then
		local function filterFunc(data)
			local equipInfo = data.info
			local equipCSV = CsvParser.getCsvData("equip", equipInfo.base_id)

			if equipCSV.is_avatar ~= 1 and equipInfo.locked == 0 and not empty(equipCSV.suit_id) and equipInfo.hero_id == 0 then
				return true
			end
		end

		list = InfoEquip.getWareList(filterFunc)
	elseif tabIndex == 3 then
		local function filterFunc(data)
			local cardInfo = data.info

			if cardInfo.locked == 0 then
				return true
			end
		end

		list = InfoCard.getWareList(filterFunc)
	elseif tabIndex == 4 then
		local function filterFunc(data)
			local itemInfo = data.info
			local itemCSV = CsvParser.getCsvData("item", itemInfo.base_id)

			return not empty(itemCSV.sell_item) and not empty(itemCSV.sell_num)
		end

		list = InfoItem.getWareList(nil, filterFunc, function (a, b)
			local dataA = CsvParser.getCsvData("item", a.info.base_id)
			local dataB = CsvParser.getCsvData("item", b.info.base_id)
			local pageIndexA = dataA.page_index == "" and 0 or dataA.page_index
			local pageIndexB = dataB.page_index == "" and 0 or dataB.page_index

			if pageIndexA == pageIndexB then
				if dataA.quality == dataB.quality then
					return a.info.base_id < b.info.base_id
				else
					return dataB.quality < dataA.quality
				end
			else
				return pageIndexA < pageIndexB
			end
		end)
	elseif tabIndex == 5 then
		local function filterFunc(data)
			local equipInfo = data.info
			local equipCSV = CsvParser.getCsvData("equip", equipInfo.base_id)

			if equipCSV.is_avatar == 1 and equipInfo.locked == 0 and not empty(equipCSV.avatar_recovery_item) and not empty(equipCSV.avatar_recovery_item_num) and equipInfo.hero_id == 0 and equipInfo.show_hero_id == 0 then
				return true
			end
		end

		list = InfoEquip.getWareList(filterFunc)
	elseif tabIndex == 6 then
		local function filterFunc(data)
			local equipInfo = data.info

			if not empty(equipInfo.dust_id) then
				local dustCSV = CsvParser.getCsvData("dust_equip", equipInfo.base_id)

				if dustCSV and equipInfo.locked == 0 and not empty(dustCSV.recovery_item) and not empty(dustCSV.recovery_item_num) and equipInfo.hero_id == 0 and equipInfo.show_hero_id == 0 then
					return true
				end
			end
		end

		list = InfoEquip.getWareList(filterFunc)
	elseif tabIndex == 7 then
		local function filterFunc(data)
			local sigilInfo = data.info

			if sigilInfo.locked == 0 and sigilInfo.hero_id == 0 then
				return true
			end
		end

		list = InfoSigil.getWareList(filterFunc)
	end

	return list
end

return InfoShop
