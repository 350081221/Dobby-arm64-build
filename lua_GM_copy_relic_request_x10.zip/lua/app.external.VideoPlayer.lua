local VideoPlayer = {}
local videoPlayer, onComplete = nil

function VideoPlayer.playVideo(path, _onComplete)
	onComplete = _onComplete

	if device.platform == "ios" then
		videoPlayer = ccexp.VideoPlayer:create()

		videoPlayer:setPosition(cc.p(display.widthInPixels / 2, display.heightInPixels / 2))
		videoPlayer:setAnchorPoint(cc.p(0.5, 0.5))
		videoPlayer:setContentSize(cc.size(display.widthInPixels, display.heightInPixels))

		local function onVideoEventCallback(sener, eventType)
			print(eventType)

			if eventType == 3 then
				VideoPlayer.stop()
			end
		end

		videoPlayer:addEventListener(onVideoEventCallback)
		videoPlayer:setFileName("res/video/piantou.mp4")
		videoPlayer:setKeepAspectRatioEnabled(true)
		videoPlayer:setFullScreenEnabled(true)
		videoPlayer:setVisible(true)
		display.getRunningScene():addChild(videoPlayer, 2000)
		videoPlayer:play()
	elseif device.platform == "android" then
		local javaClassName = "com.jifen.video.VideoToLua"
		local javaMethodName = "playVideo"
		local javaParams = {
			tostring(path),
			function (event)
				print("video finish", event)

				if finishCallback ~= nil then
					finishCallback()
				end
			end
		}
		local javaMethodSig = "(Ljava/lang/String;I)V"

		luaj.callStaticMethod(javaClassName, javaMethodName, javaParams, javaMethodSig)
	elseif onComplete then
		onComplete()
	end
end

function VideoPlayer.stop()
	if videoPlayer then
		videoPlayer:removeSelf()

		if onComplete then
			onComplete()
		end

		videoPlayer = nil
	end
end

return VideoPlayer
