local Cookie = {}
local kvMap = {}

function Cookie.init()
	local path = cc.FileUtils:getInstance():getWritablePath() .. "game_cookies.txt"

	if io.exists(path) then
		local contents = getFileString(path)
		local obj = json.decode(contents)

		if obj ~= nil then
			kvMap = obj
		end
	end
end

Cookie.init()

function Cookie.set(key, value, doFlush)
	kvMap[key] = value

	if doFlush then
		Cookie.flush()
	end
end

function Cookie.get(key)
	return kvMap[key]
end

function Cookie.flush()
	local path = cc.FileUtils:getInstance():getWritablePath() .. "game_cookies.txt"
	local str = json.encode(kvMap)

	if str then
		io.writefile(path, str)
	end
end

return Cookie
