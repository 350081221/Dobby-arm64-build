local UI_base = import("..UI_base")
local FRAME_abyss_gift = class("FRAME_abyss_gift", UI_base)

function FRAME_abyss_gift.open(npc)
	local ui = FRAME_abyss_gift.new(npc)

	ui:onOpen()
	PopManager.open(ui, nil, function ()
		ui:onClose()
	end, PopManager.ANIM_TYPE.FADE, 0)
end

function FRAME_abyss_gift:ctor(npc)
	FRAME_abyss_gift.super.ctor(self, "frame_abyss_gift", UIManager.BIG_TYPE.POP)

	self.npc = npc

	self:init()
end

function FRAME_abyss_gift:init()
	self:initUI()
	self:refresh()
	ManagerInfo.onDataChange(self, "abyss_gift", nil, function ()
		self:refresh()
	end)
end

function FRAME_abyss_gift:initUI()
	local mask1 = self:getComponentByTag("mask1")

	mask1:toTouchable()
	mask1:setOpacity(0)
	mask1:setVisible(false)
	mask1:setLocalZOrder(1000)

	local mask = self:getComponentByTag("mask")

	mask:toTouchable()
	mask:setOpacity(0)

	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local function tapListener(ui, csv, index, x, y)
		local worldPos = self.list:convertToWorldSpace(cc.p(x, y))

		if ui:hitTestByComponent("bt_get", worldPos.x, worldPos.y, true) then
			local bt_get = ui:getComponentByTag("bt_get")

			if bt_get and bt_get:isVisible() then
				UIManager.callTapGroup("button_click", bt_get)
			end

			local bt_disabled = ui:getComponentByTag("bt_disabled")

			if bt_disabled and bt_disabled:isVisible() then
				UIManager.callTapGroup("button_click", bt_disabled)
			end

			local progress, max = InfoAbyssGift.getProgress()
			local rewardCount = InfoAbyssGift.getRewardCount()

			if rewardCount > 0 then
				Alert.open(Localization.getSrcText("今日已领取"))

				return
			end

			if progress < max then
				Alert.open(Localization.getSrcText("进度未满"))

				return
			end

			InfoAbyssGift.getReward(csv.id, function (rcvData)
				if rcvData.rewards then
					self:showRewards(csv, rcvData.rewards)
				end
			end)
		elseif ui:hitTestByFlag("flag_slot", worldPos.x, worldPos.y, true) and ui.slot then
			UIManager.callTapGroup("slot_click", ui.slot, function ()
				DropManager.popDetail(DropManager.TYPE.ITEM, {
					num = 1,
					base_id = csv.reward_item
				})
			end)
		end
	end

	local listFlag = self:getFlagByTag("flag_list")
	self.list = self:createListOnFlag("flag_list", LIST_abyss_gift, tapListener, touchListener)

	self:createBarByTag("progress_bar", Style.gold)

	local hint = self:getComponentByTag("hint")

	hint:toTouchable()
	hint:addTap(function ()
		POP_msg.open(Localization.getSrcText("通过通关深渊积累点数\n每日可选取一次奖励"))
	end)
	hint:setTapGroup("button_click")
end

function FRAME_abyss_gift:showRewards(csv, rewards)
	local mask1 = self:getComponentByTag("mask1")

	mask1:setVisible(true)

	local chest = Unit.new()

	chest:load(csv.model)
	chest:display(global.map, self.npc.x, self.npc.y)

	local units = TeamManager.getTeam()

	for i, unit in ipairs(units) do
		local effectGen = unit:getEffectGen()

		if effectGen then
			effectGen:fadeTo(30, 0, "outQuad")
		end
	end

	local function delayClose()
		chest:removeSelf()
		PopManager.closeTo(self)
	end

	local function onJumpComplete()
		MapEffect.quake()
		chest:setAction("open", 1, function ()
			chest:setAction("opened")

			for i, unit in ipairs(units) do
				local effectGen = unit:getEffectGen()

				if effectGen then
					effectGen:fadeTo(30, 255, "outQuad")
				end
			end

			POP_reward.openMixed(rewards, function ()
				if self.performWithDelay then
					self:performWithDelay(delayClose, 0.05)
				end
			end, Localization.getSrcText("深渊奖励"))
		end)
	end

	local mapX, mapY = global.map:tileToMap(self.npc.tile.x + 2, self.npc.tile.y)
	local scale = 0.2

	chest:setScale(0)

	chest.z = 192

	chest:setBmpY()

	local function onJumpUpdate()
		scale = math.min(1, scale + 0.15)

		chest:setScale(scale)
	end

	chest:jump({
		x = mapX,
		y = mapY
	}, 10, -1, onJumpComplete, nil, onJumpUpdate)

	local bg = self:getComponentByTag("bg")
	local centerX = bg.x / 2

	global.map:setPositionOffsetTween("ui_open", 0, 0, 10)
	global.map:tweenFov(mapX - 96, mapY - 96, 10, "outQuad")
	global.map:tweenScrollTo(mapX - 96, mapY - 96, 10, nil, "outQuad")

	local mask = self:getComponentByTag("mask")

	transition.moveTo(self, {
		easing = "sineOut",
		time = 0.2,
		x = mask.width
	})
end

function FRAME_abyss_gift:refresh()
	local rewardList = InfoAbyssGift.getRewardList()

	self.list:setItems(rewardList, true)

	local progress, max = InfoAbyssGift.getProgress()
	local rewardCount = InfoAbyssGift.getRewardCount()

	self:setBarProgressByTag("progress_bar", progress / max)

	local label_ready = self:getComponentByTag("label_ready")
	local label_already = self:getComponentByTag("label_already")

	label_ready:setVisible(rewardCount == 0)
	label_already:setVisible(rewardCount > 0)
	self:replaceLabelOnFlag("label_progress", nil, math.floor(progress / max * 100))
end

function FRAME_abyss_gift:onOpen()
	local units = TeamManager.getUnits()

	for i, unit in ipairs(units) do
		unit:setOpacity(0)
	end

	local bg = self:getComponentByTag("bg")
	local centerX = bg.x / 2

	global.map:setPositionOffset("ui_open", centerX - display.cx, 0)
	MapUtils.focusIn(self.npc, nil, 10, 1.6, {
		y = -96,
		x = -96
	})
end

function FRAME_abyss_gift:onClose()
	self:removeEnterFrame("scrollLoop")

	local units = TeamManager.getUnits()

	for i, unit in ipairs(units) do
		unit:setOpacity(255)
	end

	global.map:setPositionOffset("ui_open", 0, 0)
	global.map:setViewZoom(1.5)
	MapUtils.focusOut(self.npc, nil, 15)
end

return FRAME_abyss_gift
