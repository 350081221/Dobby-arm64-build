local POP_hint = class("POP_hint", UI_base)

function POP_hint.open(worldRect, id, isCenter, isTest, testText)
	local ui = nil
	local isNew = false

	if POP_hint.ui then
		ui = POP_hint.ui
	else
		isNew = true
		ui = POP_hint.new()

		display.getRunningScene():addChild(ui, LayerConfig.hint)

		POP_hint.ui = ui
	end

	ui:show(worldRect, id, isCenter, isNew, isTest, testText)
end

function POP_hint.close()
	if POP_hint.ui then
		POP_hint.ui:destroy()
	end
end

function POP_hint.openOnNode(node, id)
	if tolua.isnull(node) then
		return
	end

	local x, y = node:getPosition()
	local size = node:getContentSize()
	local pt = node:getParent():convertToWorldSpace(cc.p(x, y))
	local anchor = node:getAnchorPoint()
	local rect = cc.rect(pt.x - anchor.x * size.width, pt.y - anchor.y * size.height, size.width, size.height)

	POP_hint.open(rect, id)
end

function POP_hint.openOnRect(parent, _rect, id)
	local pt = parent:convertToWorldSpace(cc.p(_rect.x, _rect.y))
	local rect = cc.rect(pt.x - 0 * _rect.width, pt.y - 0 * _rect.height, _rect.width, _rect.height)

	POP_hint.open(rect, id)
end

function POP_hint.openOnCenter(id)
	local rect = cc.rect(display.cx, display.cy, 0, 0)

	POP_hint.open(rect, id, true)
end

function POP_hint:ctor()
	POP_hint.super.ctor(self, "pop_hint", UIManager.BIG_TYPE.BOTTOM)
	self:init()
end

function POP_hint:init()
end

function POP_hint:destroy()
	if self.data then
		Looper.stopTween(self.data.tweenID)
	end

	self:removeSelf()
end

function POP_hint:getDirection(rect)
	local centerX = rect.x + rect.width / 2
	local centerY = rect.y + rect.height / 2
	local direction = 1

	if centerX < display.cx then
		if centerY < display.cy then
			direction = 1
		else
			direction = 4
		end
	elseif centerY < display.cy then
		direction = 2
	else
		direction = 3
	end

	return direction
end

function POP_hint:show(rect, id, isCenter, isNew, isTest, testText)
	self.id = id
	POP_hint.isOver = nil
	local hintData = CsvParser.getCsvData("hint", id)
	local direction = self:getDirection(rect)
	local textFlag = self:getFlagByTag("flag_text")
	local headFlag = self:getFlagByTag("flag_head")
	textFlag.x = textFlag.originalX
	textFlag.width = textFlag.originalWidth
	headFlag.x = headFlag.originalX

	if direction == 1 or direction == 4 then
		local bg = self:getComponentByTag("bg")
		headFlag.x = bg.width - (headFlag.x + headFlag.width)
		textFlag.x = bg.width - (textFlag.x + textFlag.width)
	end

	local text = hintData.text

	if isTest and testText then
		text = testText
	end

	print("$$$ POP_hint:show", hintData.id)

	local labelWidth, labelHeight, intervalSum = self:setText(text, ifFull, isTest)

	if not isTest then
		self:hideArrow()
		self:performWithDelay(function ()
			POP_hint.isOver = true

			if isCenter then
				self:showArrow()
			end
		end, intervalSum + 0.2)
	end

	local heightOffset = 0

	if labelHeight >= 78 then
		heightOffset = labelHeight - 65
	end

	print("$$$ labelHeight", labelHeight, heightOffset)

	local ifFull = false

	if not empty(hintData.head) then
		if heightOffset > 0 then
			headFlag.height = headFlag.originalHeight + heightOffset
			headFlag.y = headFlag.originalY - heightOffset
		else
			headFlag.height = headFlag.originalHeight
			headFlag.y = headFlag.originalY
		end

		if self.head ~= hintData.head or self.headX ~= headFlag.x or self.headY ~= headFlag.y then
			local pic = IconManager.getHead(hintData.head, hintData.emoji)
			self.icon = self:createIconOnFlag("flag_head", pic, 100, UILayout.SCALE_TYPE.LARGE, nil, , UILayout.ALIGN_TYPE.BOTTOM)
			self.head = hintData.head
			self.headX = headFlag.x
			self.headY = headFlag.y
		end

		if direction == 1 or direction == 4 then
			self.icon:setScaleX(-math.abs(self.icon:getScaleX()))
		else
			self.icon:setScaleX(math.abs(self.icon:getScaleX()))
		end
	else
		ifFull = true
		self.head = nil
		self.headX = nil
		self.headY = nil

		self:removeIconOnFlag("flag_head")
	end

	local bg = self:getComponentByTag("bg")

	if heightOffset > 0 then
		bg:setSize(nil, bg.originalHeight + heightOffset)
		bg:setPos(nil, bg.originalY - heightOffset)
	else
		bg:setSize(nil, bg.originalHeight)
		bg:setPos(nil, bg.originalY)
	end

	local x, y = nil
	local arrowSpace = 30

	if isCenter then
		local anchorX = 0.5
		local anchorY = 0.5

		if not empty(hintData.anchor) then
			local arr = string.split(hintData.anchor, ",")
			anchorX = tonumber(arr[1])
			anchorY = tonumber(arr[2])
		end

		x = rect.x + rect.width / 2 - bg.width / 2 - display.width / 2 + display.width * anchorX
		y = rect.y + rect.height / 2 - bg.height / 2 - display.height / 2 + display.height * anchorY
	else
		if direction == 1 then
			x = rect.x + rect.width + arrowSpace
			y = rect.y + rect.height + arrowSpace
		elseif direction == 2 then
			x = rect.x - bg.width - arrowSpace
			y = rect.y + rect.height + arrowSpace
		elseif direction == 3 then
			x = rect.x - bg.width - arrowSpace
			y = rect.y - arrowSpace - bg.height
		elseif direction == 4 then
			x = rect.x + rect.width + arrowSpace
			y = rect.y - arrowSpace - bg.height
		end

		y = (y + bg.height / 2 - display.cy) / 4 * 3 + display.cy - bg.height / 2
		x = (x + bg.width / 2 - display.cx) / 4 * 3 + display.cx - bg.width / 2
	end

	x = math.max(50, math.min(display.width - 530, x))
	y = math.max(50, math.min(display.height - 150, y)) + heightOffset

	if isNew then
		self:setPosition(x, y)
	else
		transition.moveTo(self, {
			time = 0.3,
			easing = "sineOut",
			x = x,
			y = y
		})
	end

	if not isTest and hintData.emotion == 1 then
		Style.makeShock(self)
	end
end

function POP_hint:setText(text, ifFull, isTest)
	text = StringUtil.replaceTag(text, function (tag, embedded)
		return ManagerInfo.parseTag(tag, not embedded)
	end)

	self:removeLabelGroupOnFlag("flag_text")
	self:removeLabelGroupOnFlag("flag_text_full")

	local textFlag = "flag_text"

	if ifFull then
		textFlag = "flag_text_full"
	end

	local isLight = false

	if Localization.isAlphabet() then
		isLight = true
	end

	local ubbMap, labels, lines, totalWidth, totalHeight = self:createUbbOnFlag(textFlag, text, {
		yspace = 5,
		wrap = true,
		align = Style.left,
		valign = Style.vtop
	}, isLight)
	local fadeTime = 0.02
	local defaultInterval = 0.025
	local defaultLineInterval = 0
	local intervalSum = 0

	if isTest then
		-- Nothing
	elseif Localization.isAlphabet() then
		for i, label in ipairs(labels) do
			label:setOpacity(0)
			transition.fadeIn(label, {
				time = 0.1
			})
		end
	else
		intervalSum = self:animateUbb(ubbMap, labels, fadeTime, defaultInterval, defaultLineInterval)
	end

	if isTest then
		POP_hint.textHeight = totalHeight
	end

	return totalWidth, totalHeight, intervalSum
end

function POP_hint:hideArrow()
end

function POP_hint:showArrow()
end

function POP_hint:onExit()
	POP_hint.super.onExit(self)

	POP_hint.ui = nil
end

return POP_hint
