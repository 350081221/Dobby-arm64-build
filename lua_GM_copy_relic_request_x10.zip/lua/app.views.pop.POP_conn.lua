local SimpleTCP = require("framework.SimpleTCP")
local POP_conn = class("POP_conn", UI_base)
local instance = nil

notify.register("connection", function (event)
	Log.debug("POP_conn register", event, instance)

	if instance then
		Log.debug("instance.onConnected", instance.onConnected)
	end

	if POP_conn.inLogout then
		return
	end

	if event == SimpleTCP.EVENT_CLOSED or event == SimpleTCP.EVENT_FAILED then
		if not instance then
			instance = POP_conn.new()

			display.getRunningScene():addChild(instance, LayerConfig.conn_alert)
		elseif instance.onDisconnect then
			instance:onDisconnect()
		end
	elseif event == SimpleTCP.EVENT_CONNECTING then
		if instance then
			instance:onConnecting()
		end
	elseif event == SimpleTCP.EVENT_CONNECTED and instance and instance.onConnected then
		instance:onConnected()
	end
end)

local autoReconnectCount = 0

function POP_conn.clearCount()
	autoReconnectCount = 0
end

function POP_conn:ctor()
	POP_conn.super.ctor(self, "pop_conn")
	self:init()
end

function POP_conn:init()
	self:initUI()

	self.offset = 0
	self.isQuick = true

	if autoReconnectCount == 0 then
		autoReconnectCount = autoReconnectCount + 1

		self:onConnecting()
		self:reconnect()
		self:delayManual()
	else
		self:onDisconnect()
	end
end

function POP_conn:delayManual(delay)
	self:closeManual()

	delay = delay or 180
	self.manualTimer = Looper.setTimeout(function ()
		self:onDisconnect()
	end, delay)
end

function POP_conn:closeManual()
	if self.manualTimer then
		Looper.clearTimeout(self.manualTimer)

		self.manualTimer = nil
	end

	self:createLabelOnFlag("flag_stat", "连接中")

	local connPB = self:getComponentByTag("conn_pb")

	connPB:setVisible(false)
end

function POP_conn:initUI()
	local mask = self:getComponentByTag("mask")

	mask:toTouchable()

	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local connPB = self:getComponentByTag("conn_pb")

	connPB:toTouchable()
	connPB:setVisible(false)
	connPB:addTap(function ()
		self.isQuick = true

		self:reconnect()
	end)
	connPB:setTapGroup("button_click")
end

function POP_conn:reconnect()
	if InfoUser.isKick then
		self:createLabelOnFlag("flag_stat", "已主动断开连接")

		return
	end

	print("$$$ POP_conn:reconnect", Connection.getStat())
	Connection.reconnect(nil, self.isQuick)
end

function POP_conn:onDisconnect()
	local connPB = self:getComponentByTag("conn_pb")

	connPB:toTouchable()
	connPB:setVisible(true)
	self:removeLabelOnFlag("flag_stat")

	self.isQuick = false
end

function POP_conn:onConnecting()
	self:createLabelOnFlag("flag_stat", "连接中")

	local connPB = self:getComponentByTag("conn_pb")

	connPB:setVisible(false)

	self.isQuick = true

	self:delayManual()
end

function POP_conn:onConnected()
	Log.debug("重新连接")

	local tryCount = 5

	local function onClose(inMap)
		Connection.flush()

		instance = nil

		self:removeSelf()

		if inMap then
			Log.debug("重连补单", global.map)

			if global.map then
				InfoOrder.recover(function (rcvData)
					local rewards = rcvData.rewards

					if #rewards > 0 then
						POP_reward.openMixed(rewards, nil, Localization.getSrcText("充值成功"))
					end

					if rcvData.order_info and #rcvData.order_info > 0 then
						local str = ""

						for i, orderInfo in ipairs(rcvData.order_info) do
							if not empty(orderInfo.goods_id) then
								local csv = CsvParser.getCsvData("rmb_cost", orderInfo.goods_id, nil, true)

								if csv then
									str = str .. "\n" .. csv.name
								end
							end
						end

						if str ~= "" then
							str = "[color=238,199,111]" .. Localization.getSrcText("充值成功") .. "[/color]" .. str

							POP_msg.open(str, {
								align = Style.left
							})
						end
					end
				end)
			end
		end
	end

	local function onTryFailure()
		Connection.disConnect()
	end

	if global.loginLoadOver then
		local function onLoginFailure(err)
			Log.debug("重登失败 " .. err)
			Connection.clearFlush()
			app:enterScene("LoginScene")
		end

		local function onLoginProgress(current, max)
			self:closeManual()
		end

		local function onLoginSuccess()
			Log.debug("重登成功")

			if not DungeonScene.currentMap or not InfoDungeon.inDungeon() or InfoDungeon.inDungeonSafe() then
				onClose(true)
			else
				InfoBag.saveBagItemInfo()

				local function onCheckVersion(rcvData)
					dump(rcvData, "$$$ onCheckVersion")

					if rcvData.is_diff == 1 then
						onClose()
						FRAME_dungeon_result.open(rcvData, FRAME_dungeon_result.OPEN_TYPE.VERSION)
					else
						InfoBag.clearBagItemInfo()

						local type = InfoDungeon.getType()
						local stageType = InfoDungeon.getStage()

						if type == InfoDungeon.TYPE.STAGE and stageType > 100 then
							OnlineCamp.recover()
						else
							InfoDungeon.recoverOnReconnect(function ()
								onClose()
							end, function ()
								tryCount = tryCount - 1

								if tryCount > 0 then
									onLoginSuccess()
								else
									onTryFailure()
								end
							end)
						end
					end
				end

				InfoDungeon.dungeon_check_version(onCheckVersion)
			end

			OnlineChat.tryReconnect()
			notify.dispatch("reconn_succ")
		end

		InfoUser.clearOnReconnect()

		if InfoUser.isLogin then
			if InfoUser.hasAutoLoginData() then
				InfoUser.autoLogin(onLoginSuccess, onLoginFailure, onLoginProgress, true)
			else
				onLoginFailure()
			end
		end

		return
	end

	Log.debug("重连未登录")

	if global.loginUI then
		global.loginUI:onReconnect()
	end

	onClose()
end

function POP_conn:onExit()
	instance = nil

	if self.tweenID then
		Looper.stopTween(self.tweenID)

		self.tweenID = nil
	end

	POP_conn.super.onExit(self)
end

return POP_conn
