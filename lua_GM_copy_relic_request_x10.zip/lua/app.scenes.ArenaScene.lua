local ArenaScene = class("ArenaScene", function ()
	return display.newScene("ArenaScene")
end)
local TYPE = {
	CHAT_REPLAY = 4,
	CHAT = 3,
	ARENA_REPLAY = 2,
	ARENA = 1
}
ArenaScene.TYPE = TYPE

function ArenaScene.enterMap(type, seed, attr_level, teams, skill_record)
	FRAME_wild.close()
	FRAME_union_pve.close()

	local mapName = InfoArena.getArenaMap(seed)

	Log.verbose("ArenaScene.enterMap", seed, mapName)

	ArenaScene.currentMap = mapName
	ArenaScene.type = type
	ArenaScene.seed = seed
	ArenaScene.attr_level = attr_level
	ArenaScene.teams = teams
	ArenaScene.skill_record = skill_record
	local mapObj = Map.getMapData(mapName)

	Transition.setTitle(mapObj.mapData.name)
	app:enterScene("ArenaScene")
end

function ArenaScene:ctor()
	Log.debug("ArenaScene:ctor")
	event_listener.extendMethods(self, true)
end

function ArenaScene:isReplay()
	return ArenaScene.type == TYPE.ARENA_REPLAY or ArenaScene.type == TYPE.CHAT_REPLAY
end

function ArenaScene:isArenaBattle()
	return ArenaScene.type == TYPE.ARENA
end

function ArenaScene:init()
	Log.debug("ArenaScene:init")
	CombatAttr.setAttrLevel(ArenaScene.attr_level)
	CombatUnit.startIndex()
	self:initMap()
	Log.debug("ArenaScene:init initMap over")
	notify.safeRegister(self, "battle_state_change", function (isBattle)
		self.isBattle = isBattle

		if isBattle then
			self.battleUI:ready()
		else
			self.battleUI:out()
		end
	end)
	self:initTeams()

	local team1 = self.teams[1]

	local function onTimeout()
		self:onBattleOver(false, true)
	end

	self.battleUI = FRAME_arena_battle.new(team1, self.petTeamInfo1, ArenaScene.type, onTimeout)

	self:addChild(self.battleUI)

	global.ui = self.battleUI
	global.battleUI = self.battleUI

	self.battleUI:setControllEnabled(not self:isReplay())

	local abyssBaseCSV = CsvParser.getCsvData("abyss_base_num", ArenaScene.attr_level)
	WarMachine.dmg_ratio = abyssBaseCSV.arena_dmg_ratio
	WarMachine.heal_ratio = abyssBaseCSV.arena_heal_ratio
	WarMachine.shield_ratio = abyssBaseCSV.arena_shield_ratio

	print("$$$ ArenaScene.attr_level", ArenaScene.attr_level, WarMachine.dmg_ratio, WarMachine.heal_ratio, WarMachine.shield_ratio)

	if self:isReplay() then
		self:startBattle()
	else
		self.skillRecord = {}
		self.recordLocked = true

		FRAME_arena_prepare.open(team1, function (autoSkillMap)
			self.battleUI:startWithSkill(autoSkillMap)
			self.battleUI:refreshSkillSlots()

			for i, hero in ipairs(team1) do
				if hero:isSwitchSkill() then
					self:recordSwitchSkill(i, {
						index = hero.skillSwitchIndex or 1
					})
				else
					self:recordSetAutoSkill(i, {
						isAuto = hero:isAutoSkill()
					})
				end
			end

			self:startBattle()

			self.recordLocked = nil
		end)
	end
end

function ArenaScene:onBattleOver(isWin, isTimeout)
	local function onUIClose()
		InfoDungeon.enterCamp()
	end

	local function popResult(rcvData)
		if self:isReplay() then
			FRAME_arena_over_s.open(isWin, function ()
				onUIClose(true)
			end)
		elseif ArenaScene.type == TYPE.ARENA then
			FRAME_arena_over.open(isWin, rcvData.rewards, rcvData.points, function ()
				onUIClose(true)
			end)
		elseif ArenaScene.type == TYPE.CHAT then
			FRAME_arena_over_s.open(isWin, function ()
				onUIClose(true)
			end, FRAME_arena_over_s.OPEN_TYPE.CHAT, {
				user_id = OnlineChat.getBattleUserID()
			})
		end
	end

	CombatUnit.clearIndex()

	WarMachine.event_on = false

	WarMachine.logStop()

	local function delayPop(rcvData)
		self:performWithDelay(function ()
			popResult(rcvData)
		end, 2)
	end

	if self:isReplay() then
		delayPop()
	elseif ArenaScene.type == TYPE.ARENA then
		InfoArena.battleOverYD(isWin, self.skillRecord, function (rcvData)
			delayPop(rcvData)
		end)
	elseif ArenaScene.type == TYPE.CHAT then
		OnlineChat.battleOver(isWin, self.skillRecord, function (rcvData)
			delayPop(rcvData)
		end)
	end
end

function ArenaScene:startBattle()
	local battleCenter = MapEventManager.getEventByTagOne("battle-center")
	local centerTile = global.map:getTile(battleCenter.x, battleCenter.y)
	local createParams = {
		isCopy = true,
		seed = ArenaScene.seed,
		onBattleWin = function ()
			self:onBattleOver(true)
		end,
		onBattleLose = function ()
			self:onBattleOver(false)
		end
	}

	if self:isReplay() then
		local skill_record = json.decode(ArenaScene.skill_record) or {}
		local recordIndex = 1

		local function onUpdate(frame)
			local record = skill_record[recordIndex]

			while record and record.frame == frame do
				local hero = CombatUnit.getByIndex(record.hero)

				if record.cmd == "retreat" then
					print("$$$$$$$$ retreat")
					WarMachine.over()
					self:onBattleOver(false)
				elseif record.auto ~= nil then
					hero:setAutoSkill(record.auto == 1)
				elseif record.switch ~= nil then
					hero:switchSkill(record.switch, frame == 0)
				else
					local target = nil

					if record.target.index then
						target = CombatUnit.getByIndex(record.target.index)
					else
						target = {
							x = record.target.x,
							y = record.target.y
						}
					end

					hero:castHandSkill(hero:getActiveSkill(), target)
				end

				recordIndex = recordIndex + 1
				record = skill_record[recordIndex]
			end
		end

		onUpdate(0)
		WarMachine.setBeforeUpdate(function ()
			local frame = WarMachine.getFrame()

			onUpdate(frame)
		end)
	end

	WarMachine.logStart()
	global.map:prepareBattleCopy(centerTile, 0, battleCenter, createParams, self.copyMap, self.petIndexMap)

	for camp = 1, 2 do
		local petReady = self.petReady[camp]
		local prepareData = petReady.prepareData

		WarMachine.preparePet(camp, prepareData.centerTile, prepareData.playerTile, prepareData.playerAngle)

		if petReady.petInfo then
			WarMachine.addPetReady(camp, petReady.petInfo)
		end
	end
end

function ArenaScene:initMap()
	local map = Map.new(display.width, display.height)

	self:addChild(map)
	map:setGamma(Sound.getGamma())
	map:load(ArenaScene.currentMap)

	global.map = map
	local battleCenter = MapEventManager.getEventByTagOne("battle-center")
	local centerX, centerY = map:tileToMap(battleCenter.x, battleCenter.y)

	map:scrollTo(centerX, centerY)
	map:setFov(centerX, centerY)
end

local team_pos = {
	{
		2
	},
	{
		1,
		3
	},
	{
		1,
		2,
		3
	}
}

function ArenaScene:initTeams()
	local random = Random.new(ArenaScene.seed)

	print("$$$ initTeams", ArenaScene.seed)

	self.teams = {}
	self.petReady = {}
	self.petTeamInfo1 = {}
	local teamData = ArenaScene.teams[2]
	local copy = json.decode(teamData.copy) or {}
	copy.hero = copy.hero or {}
	copy.pet = copy.pet or {}
	local levelTotal = 0
	local levelCount = 0

	for j, heroInfo in ipairs(copy.hero) do
		levelTotal = levelTotal + heroInfo.level
		levelCount = levelCount + 1
	end

	if levelCount > 0 then
		CopyAttr.setAttrLevel(math.floor(levelTotal / levelCount))
	else
		CopyAttr.setAttrLevel(1)
	end

	self.copyMap = {}
	self.petIndexMap = {}

	for camp = 1, 2 do
		local teamData = ArenaScene.teams[camp]
		local copy = json.decode(teamData.copy) or {}
		copy.hero = copy.hero or {}
		copy.pet = copy.pet or {}
		local hero_name = nil

		if teamData.hero_name then
			hero_name = json.decode(teamData.hero_name) or {}
		else
			hero_name = {}
		end

		local pet_name = nil

		if teamData.pet_name then
			pet_name = json.decode(teamData.pet_name) or {}
		else
			pet_name = {}
		end

		local fCount = 0
		local bCount = 0

		for j, heroInfo in ipairs(copy.hero) do
			local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)

			if heroCSV.class == 1 then
				fCount = fCount + 1
			else
				bCount = bCount + 1
			end
		end

		local f_pos = team_pos[fCount]
		local b_pos = team_pos[bCount]
		local fCount = 0
		local bCount = 0
		self.teams[camp] = {}
		local petIndex = math.max(1, math.min(#copy.pet, tonumber(copy.petIndex) or 0))

		for j, heroInfo in ipairs(copy.hero) do
			heroInfo.name = hero_name[j] or ""
			heroInfo.id = heroInfo.id or camp * 100 + j
			local hero = HeroCopy.new()
			hero.camp = camp
			hero.seed = random:getInt(1, 65535)
			hero.random = Random.new(hero.seed)

			hero:setInfo(heroInfo, copy)

			local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)
			local posLine, posIndex = nil

			if heroCSV.class == 1 then
				fCount = fCount + 1
				posLine = 1
				posIndex = f_pos[fCount]
			else
				bCount = bCount + 1
				posLine = 2
				posIndex = b_pos[bCount]
			end

			local posX, posY = nil

			if heroInfo.x and heroInfo.y then
				local areaEvent = MapEventManager.getEventByTagOne("area_ready_" .. camp)

				if camp == 1 then
					posX = areaEvent.x + heroInfo.x
					posY = areaEvent.y + heroInfo.y
				else
					posX = areaEvent.x + areaEvent.w - 1 - heroInfo.x
					posY = areaEvent.y + areaEvent.h - 1 - heroInfo.y
				end
			else
				local posEvent = MapEventManager.getEventByTagOne("pos_" .. camp .. "_" .. posLine .. "_" .. posIndex)
				posX = posEvent.x
				posY = posEvent.y
			end

			print("$$$ camp", camp, heroInfo.x, heroInfo.y)

			local mapX, mapY = global.map:tileToMap(posX, posY)

			hero:display(global.map, mapX, mapY)

			if camp == 1 then
				hero.angle = math.pi
			end

			if not self:isReplay() and camp == 1 then
				hero:addEventListener("set_auto_skill", function (event)
					if not self.recordLocked then
						self:recordSetAutoSkill(j, event)
					end
				end)
				hero:addEventListener("switch_skill", function (event)
					if not self.recordLocked then
						self:recordSwitchSkill(j, event)
					end
				end)
				hero:addEventListener("manual_cast", function (event)
					if not self.recordLocked then
						self:recordManualCast(j, event)
					end
				end)
			end

			table.insert(self.teams[camp], hero)
		end

		self.petReady[camp] = {}
		local petReady = self.petReady[camp]
		local battleCenter = MapEventManager.getEventByTagOne("battle-center")
		local centerTile = global.map:getTile(battleCenter.x, battleCenter.y)
		local playerEvent = MapEventManager.getEventByTagOne("player_" .. camp)
		local playerTile = global.map:getTile(playerEvent.x, playerEvent.y)
		local playerAngle = math.atan2(battleCenter.y - playerEvent.y, battleCenter.x - playerEvent.x)
		petReady.prepareData = {
			centerTile = centerTile,
			playerTile = playerTile,
			playerAngle = playerAngle
		}
		local petInfo = copy.pet[petIndex]

		if petInfo then
			petInfo.name = pet_name[petIndex] or ""
			petInfo.id = camp * 100 + petIndex
			petReady.petInfo = petInfo

			if camp == 1 then
				table.insert(self.petTeamInfo1, petInfo)
			end
		end

		self.copyMap[camp] = copy
		self.petIndexMap[camp] = petIndex
	end
end

function ArenaScene:recordSwitchSkill(heroIndex, event)
	local frame = WarMachine.getFrame()
	local info = {
		frame = frame,
		hero = heroIndex,
		switch = event.index
	}

	table.insert(self.skillRecord, info)
end

function ArenaScene:recordManualCast(heroIndex, event)
	local frame = WarMachine.getFrame()
	local info = {
		frame = frame,
		hero = heroIndex
	}

	if event.type == "pos" then
		info.target = {
			x = event.x,
			y = event.y
		}
	elseif event.type == "unit" then
		info.target = {
			index = event.index
		}
	end

	table.insert(self.skillRecord, info)
end

function ArenaScene:recordSetAutoSkill(heroIndex, event)
	local frame = WarMachine.getFrame()
	local info = {
		frame = frame,
		hero = heroIndex,
		auto = event.isAuto and 1 or 0
	}

	table.insert(self.skillRecord, info)
end

function ArenaScene:recordRetreat()
	local frame = WarMachine.getFrame()
	local info = {
		cmd = "retreat",
		frame = frame
	}

	table.insert(self.skillRecord, info)
end

function ArenaScene:onEnter()
	app:onSceneEnter(self, nil, 1)
	self:init()
end

function ArenaScene:onExit()
	global.player = nil
	global.ui = nil
	global.map = nil
	global.battleUI = nil
	global.adventureUI = nil

	app:onSceneExit(self)
end

return ArenaScene
