local InfoBag = {}
local rawData = {}

function InfoBag.init()
	Connection.listen("bag_sync", InfoBag.sync)
	Connection.listen("bag_sync_remove", InfoBag.syncRemove)
end

app:addToAppEnterCall(InfoBag.init)

function InfoBag.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoBag.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("bag_query", callback)
end

function InfoBag.onQuery(rcvData)
	rawData = {}

	for i, data in ipairs(rcvData.list) do
		rawData[data.bag_index] = data
	end
end

function InfoBag.sync(data)
	local quickArr = InfoQuickSlots.getFreePosList()
	local quickIndex = 1
	local preItemMap = {}
	local hasEquip = false

	if #quickArr > 0 then
		for i, syncData in ipairs(data.list) do
			if syncData.type == DropManager.TYPE.ITEM and not InfoQuickSlots.findItem(syncData.item_id) and not preItemMap[syncData.item_id] then
				preItemMap[syncData.item_id] = InfoBag.getItemNum(syncData.item_id)
			end
		end
	end

	for i, syncData in ipairs(data.list) do
		local bag_index = syncData.bag_index

		if rawData[bag_index] and rawData[bag_index].type == DropManager.TYPE.EQUIP then
			hasEquip = true
		end

		rawData[bag_index] = syncData

		if rawData[bag_index] and rawData[bag_index].type == DropManager.TYPE.EQUIP then
			hasEquip = true
		end
	end

	for itemID, preNum in pairs(preItemMap) do
		local itemCSV = CsvParser.getCsvData("item", itemID)

		if itemCSV.is_quickuse == 1 and preNum == 0 then
			local newNum = InfoBag.getItemNum(itemID)

			if newNum > 0 then
				InfoQuickSlots.set(quickArr[quickIndex], itemID)

				quickIndex = quickIndex + 1

				if quickIndex > #quickArr then
					break
				end
			end
		end
	end

	if hasEquip then
		notify.dispatch("equip_up_change")
	end

	ManagerInfo.dataChange("bag")
end

function InfoBag.syncRemove(data)
	dump(data, "$$$ syncRemove")

	local hasEquip = false

	for i, syncData in ipairs(data.list) do
		local bag_index = syncData.bag_index

		if rawData[bag_index] and rawData[bag_index].type == DropManager.TYPE.EQUIP then
			hasEquip = true
		end

		rawData[bag_index] = nil
	end

	if hasEquip then
		notify.dispatch("equip_up_change")
	end
end

function InfoBag.getBagInfo(bag_index)
	return rawData[bag_index]
end

function InfoBag.isAvatar(bag_index)
	local data = rawData[bag_index]

	if data.type == DropManager.TYPE.EQUIP then
		local equipInfo = InfoEquip.getInfo(data.equip_id)
		local equipCSV = CsvParser.getCsvData("equip", equipInfo.base_id)

		if equipCSV.is_avatar == 1 then
			return true
		end
	end

	return false
end

function InfoBag.isLocked(bag_index)
	local data = rawData[bag_index]

	if data.type == DropManager.TYPE.EQUIP then
		local equipInfo = InfoEquip.getInfo(data.equip_id)

		if equipInfo.locked == 1 then
			return true
		end
	elseif data.type == DropManager.TYPE.CARD then
		local cardInfo = InfoCard.getCardInfo(data.card_id)

		if cardInfo.locked == 1 then
			return true
		end
	elseif data.type == DropManager.TYPE.SIGIL then
		local sigilInfo = InfoSigil.getInfo(data.sigil_id)

		if sigilInfo.locked == 1 then
			return true
		end
	elseif data.type == DropManager.TYPE.ARTIFACT then
		local artifactInfo = InfoArtifact.getInfo(data.artifact_id)

		if artifactInfo.locked == 1 then
			return true
		end
	end

	return false
end

function InfoBag.getEquipIndex(equipID)
	for bag_index, data in pairs(rawData) do
		if data.type == DropManager.TYPE.EQUIP and data.equip_id == equipID then
			return bag_index
		end
	end
end

function InfoBag.getItemNum(itemBaseID)
	local num = 0

	for bag_index, data in pairs(rawData) do
		if data.type == DropManager.TYPE.ITEM and data.item_id == itemBaseID then
			num = num + data.item_num
		end
	end

	return num
end

function InfoBag.getItemTypeList(type)
	local arr = {}
	local objMap = {}

	for bag_index, data in pairs(rawData) do
		if data.type == DropManager.TYPE.ITEM and not empty(data.item_id) then
			local itemCSV = CsvParser.getCsvData("item", data.item_id)

			if itemCSV.type == type then
				if not objMap[data.item_id] then
					objMap[data.item_id] = {
						num = 0,
						base_id = data.item_id
					}

					table.insert(arr, objMap[data.item_id])
				end

				objMap[data.item_id].num = objMap[data.item_id].num + data.item_num
			end
		end
	end

	return arr, objMap
end

function InfoBag.getRuneIndexArr(itemUseMap)
	local usedMap = {}

	for k, v in pairs(itemUseMap) do
		if v.used > 0 then
			if not usedMap[v.base_id] then
				usedMap[v.base_id] = v.used
			else
				usedMap[v.base_id] = usedMap[v.base_id] + v.used
			end
		end
	end

	local arr = {}

	for base_id, num in pairs(usedMap) do
		local _arr = InfoBag.getRuneIndexArrOne(base_id, num)

		for i, v in ipairs(_arr) do
			table.insert(arr, v)
		end
	end

	return arr
end

function InfoBag.getRuneIndexArrOne(base_id, num)
	local bagArr = {}

	for bag_index, data in pairs(rawData) do
		if data.type == DropManager.TYPE.ITEM and data.item_id == base_id then
			table.insert(bagArr, {
				index = bag_index,
				num = data.item_num
			})
		end
	end

	table.sort(bagArr, function (a, b)
		if a.num == b.num then
			return a.index < b.index
		else
			return a.num < b.num
		end
	end)

	local arr = {}
	local index = 1

	while index <= #bagArr do
		local bagData = bagArr[index]
		local use_num = math.min(num, bagData.num)

		table.insert(arr, {
			item_id = base_id,
			bag_index = bagData.index,
			num = use_num
		})

		num = num - use_num

		if num <= 0 then
			break
		else
			index = index + 1
		end
	end

	if num ~= 0 then
		-- Nothing
	end

	return arr
end

function InfoBag.getItemUseIndex(itemBaseID)
	local num = 0
	local bestNum, bestIndex = nil

	for bag_index, data in pairs(rawData) do
		if data.type == DropManager.TYPE.ITEM and data.item_id == itemBaseID and (not bestIndex or data.item_num < bestNum) then
			bestNum = data.item_num
			bestIndex = bag_index
		end
	end

	return bestIndex
end

function InfoBag.getRaw()
	return rawData
end

function InfoBag.getAll(filterFunc, sortFunc)
	local bagList = {}

	for bag_index, data in pairs(rawData) do
		local tempData = nil

		if data.type == DropManager.TYPE.EQUIP then
			tempData = {
				type = data.type,
				bagIndex = bag_index,
				info = InfoEquip.getInfo(data.equip_id)
			}
		elseif data.type == DropManager.TYPE.CARD then
			tempData = {
				type = data.type,
				bagIndex = bag_index,
				info = InfoCard.getCardInfo(data.card_id)
			}
		elseif data.type == DropManager.TYPE.SIGIL then
			tempData = {
				type = data.type,
				bagIndex = bag_index,
				info = InfoSigil.getInfo(data.sigil_id)
			}
		elseif data.type == DropManager.TYPE.ARTIFACT then
			tempData = {
				type = data.type,
				bagIndex = bag_index,
				info = InfoArtifact.getInfo(data.artifact_id)
			}
		elseif data.type == DropManager.TYPE.ITEM then
			tempData = {
				type = data.type,
				bagIndex = bag_index,
				info = {
					base_id = data.item_id,
					num = data.item_num
				}
			}
		end

		if tempData and (not filterFunc or filterFunc(tempData)) then
			table.insert(bagList, tempData)
		end
	end

	if sortFunc then
		table.sort(bagList, sortFunc)
	end

	return bagList
end

function InfoBag.getList(showLocked)
	local list = {}
	local amount = InfoBag.getAmount()
	local showNum = nil

	if showLocked then
		showNum = InfoConsume.getBagAmount().show_num
	else
		showNum = amount
	end

	for bag_index = 1, showNum do
		if bag_index <= amount then
			if rawData[bag_index] and rawData[bag_index].type ~= DropManager.TYPE.NONE then
				if rawData[bag_index].type == DropManager.TYPE.EQUIP then
					table.insert(list, {
						type = DropManager.TYPE.EQUIP,
						bagIndex = bag_index,
						info = InfoEquip.getInfo(rawData[bag_index].equip_id)
					})
				elseif rawData[bag_index].type == DropManager.TYPE.CARD then
					table.insert(list, {
						type = DropManager.TYPE.CARD,
						bagIndex = bag_index,
						info = InfoCard.getCardInfo(rawData[bag_index].card_id)
					})
				elseif rawData[bag_index].type == DropManager.TYPE.SIGIL then
					table.insert(list, {
						type = DropManager.TYPE.SIGIL,
						bagIndex = bag_index,
						info = InfoSigil.getInfo(rawData[bag_index].sigil_id)
					})
				elseif rawData[bag_index].type == DropManager.TYPE.ARTIFACT then
					table.insert(list, {
						type = DropManager.TYPE.ARTIFACT,
						bagIndex = bag_index,
						info = InfoArtifact.getInfo(rawData[bag_index].artifact_id)
					})
				elseif rawData[bag_index].type == DropManager.TYPE.ITEM then
					table.insert(list, {
						type = DropManager.TYPE.ITEM,
						bagIndex = bag_index,
						info = {
							base_id = rawData[bag_index].item_id,
							num = rawData[bag_index].item_num
						}
					})
				end
			else
				table.insert(list, {
					type = DropManager.TYPE.NONE,
					bagIndex = bag_index
				})
			end
		else
			table.insert(list, {
				locked = true,
				type = DropManager.TYPE.NONE,
				bagIndex = bag_index
			})
		end
	end

	return list
end

function InfoBag.remove(bagIndex, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ bag_remove")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("bag_remove", {
		index = bagIndex
	}, callback)
end

function InfoBag.sort(bagInfo, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			rawData = {}

			for i, data in ipairs(bagInfo) do
				rawData[data.bag_index] = data
			end

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("bag_sort", {
		list = bagInfo
	}, callback)
end

function InfoBag.autoSort(bagItems)
	local newBagItems = {}
	local amount = InfoBag.getAmount()
	local itemArr = {}
	local equipArr = {}
	local cardArr = {}
	local sigilArr = {}
	local artifactArr = {}

	for k, obj in pairs(bagItems) do
		if obj.type == DropManager.TYPE.EQUIP then
			table.insert(equipArr, obj)
		elseif obj.type == DropManager.TYPE.CARD then
			table.insert(cardArr, obj)
		elseif obj.type == DropManager.TYPE.SIGIL then
			table.insert(sigilArr, obj)
		elseif obj.type == DropManager.TYPE.ARTIFACT then
			table.insert(artifactArr, obj)
		elseif obj.type == DropManager.TYPE.ITEM then
			table.insert(itemArr, obj)
		end
	end

	table.sort(equipArr, function (a, b)
		local infoA = a.info or InfoEquip.getInfo(a.equip_id)
		local infoB = b.info or InfoEquip.getInfo(b.equip_id)
		local qualityA = InfoEquip.getQuality(infoA)
		local qualityB = InfoEquip.getQuality(infoB)

		if qualityA == qualityB then
			local dataA = CsvParser.getCsvData("equip", infoA.base_id)
			local dataB = CsvParser.getCsvData("equip", infoB.base_id)

			if dataA.class == dataB.class then
				if dataA.id == dataB.id then
					if infoA.id and infoB.id then
						return infoA.id < infoB.id
					else
						return tostring(infoB) < tostring(infoA)
					end
				else
					return dataA.id < dataB.id
				end
			else
				return dataA.class < dataB.class
			end
		else
			return qualityB < qualityA
		end
	end)
	table.sort(cardArr, function (a, b)
		local infoA = a.info or InfoCard.getCardInfo(a.card_id)
		local infoB = b.info or InfoCard.getCardInfo(b.card_id)
		local qualityA = InfoCard.getQuality(infoA)
		local qualityB = InfoCard.getQuality(infoB)

		if qualityA == qualityB then
			if infoA.base_id == infoB.base_id then
				if infoA.id and infoB.id then
					return infoA.id < infoB.id
				else
					return tostring(infoB) < tostring(infoA)
				end
			else
				return infoA.base_id < infoB.base_id
			end
		else
			return qualityB < qualityA
		end
	end)
	table.sort(sigilArr, function (a, b)
		local infoA = a.info or InfoSigil.getInfo(a.sigil_id)
		local infoB = b.info or InfoSigil.getInfo(b.sigil_id)
		local qualityA = InfoSigil.getQuality(infoA)
		local qualityB = InfoSigil.getQuality(infoB)

		if qualityA == qualityB then
			if infoA.base_id == infoB.base_id then
				if infoA.id and infoB.id then
					return infoA.id < infoB.id
				else
					return tostring(infoB) < tostring(infoA)
				end
			else
				return infoA.base_id < infoB.base_id
			end
		else
			return qualityB < qualityA
		end
	end)
	table.sort(artifactArr, function (a, b)
		local infoA = a.info or InfoArtifact.getInfo(a.artifact_id)
		local infoB = b.info or InfoArtifact.getInfo(b.artifact_id)
		local qualityA = InfoArtifact.getQuality(infoA)
		local qualityB = InfoArtifact.getQuality(infoB)

		if qualityA == qualityB then
			if infoA.base_id == infoB.base_id then
				if infoA.id and infoB.id then
					return infoA.id < infoB.id
				else
					return tostring(infoB) < tostring(infoA)
				end
			else
				return infoA.base_id < infoB.base_id
			end
		else
			return qualityB < qualityA
		end
	end)
	table.sort(itemArr, function (a, b)
		local dataA = CsvParser.getCsvData("item", a.item_id)
		local dataB = CsvParser.getCsvData("item", b.item_id)

		if dataA.quality == dataB.quality then
			if dataA.id == dataB.id then
				return b.item_num < a.item_num
			else
				return dataA.id < dataB.id
			end
		else
			return dataB.quality < dataA.quality
		end
	end)

	for i, obj in ipairs(equipArr) do
		local succ = false

		for j = 1, amount do
			if not newBagItems[j] then
				newBagItems[j] = obj

				break
			end
		end
	end

	for i, obj in ipairs(cardArr) do
		local succ = false

		for j = 1, amount do
			if not newBagItems[j] then
				newBagItems[j] = obj

				break
			end
		end
	end

	for i, obj in ipairs(sigilArr) do
		local succ = false

		for j = 1, amount do
			if not newBagItems[j] then
				newBagItems[j] = obj

				break
			end
		end
	end

	for i, obj in ipairs(artifactArr) do
		local succ = false

		for j = 1, amount do
			if not newBagItems[j] then
				newBagItems[j] = obj

				break
			end
		end
	end

	for i, obj in ipairs(itemArr) do
		local allClear = false

		for j = 1, amount do
			local bagItem = newBagItems[j]

			if bagItem and bagItem.type == DropManager.TYPE.ITEM and bagItem.item_id == obj.item_id then
				local itemData = CsvParser.getCsvData("item", obj.item_id)

				if bagItem.item_num < math.max(1, itemData.bag_stack) then
					local putNum = math.min(math.max(1, itemData.bag_stack) - bagItem.item_num, obj.item_num)
					bagItem.item_num = bagItem.item_num + putNum
					obj.item_num = obj.item_num - putNum

					if obj.item_num == 0 then
						allClear = true

						break
					end
				end
			end
		end

		if not allClear then
			for j = 1, amount do
				if not newBagItems[j] then
					newBagItems[j] = obj

					break
				end
			end
		end
	end

	local bagInfo = {}

	for bag_index = 1, amount do
		if newBagItems[bag_index] then
			newBagItems[bag_index].bag_index = bag_index

			table.insert(bagInfo, newBagItems[bag_index])
		else
			table.insert(newBagItems, {
				type = DropManager.TYPE.NONE
			})
		end
	end

	if json.encode(bagItems) ~= json.encode(newBagItems) then
		return bagInfo
	end
end

local savedBagItemInfo = nil

function InfoBag.saveBagItemInfo()
	if not savedBagItemInfo then
		savedBagItemInfo = {}
	end

	local newEquip = InfoEquip.getIsnew()

	for i, info in ipairs(newEquip) do
		if not savedBagItemInfo[DropManager.TYPE.EQUIP] then
			savedBagItemInfo[DropManager.TYPE.EQUIP] = {}
		end

		savedBagItemInfo[DropManager.TYPE.EQUIP][info.id] = info
	end

	local newSigil = InfoSigil.getIsnew()

	for i, info in ipairs(newSigil) do
		if not savedBagItemInfo[DropManager.TYPE.SIGIL] then
			savedBagItemInfo[DropManager.TYPE.SIGIL] = {}
		end

		savedBagItemInfo[DropManager.TYPE.SIGIL][info.id] = info
	end

	local unsavedCard = InfoCard.getUnsaved()

	for i, info in ipairs(unsavedCard) do
		if not savedBagItemInfo[DropManager.TYPE.CARD] then
			savedBagItemInfo[DropManager.TYPE.CARD] = {}
		end

		savedBagItemInfo[DropManager.TYPE.CARD][info.id] = info
	end

	local unsavedArtifact = InfoArtifact.getUnsaved()

	for i, info in ipairs(unsavedArtifact) do
		if not savedBagItemInfo[DropManager.TYPE.ARTIFACT] then
			savedBagItemInfo[DropManager.TYPE.ARTIFACT] = {}
		end

		savedBagItemInfo[DropManager.TYPE.ARTIFACT][info.id] = info
	end
end

function InfoBag.getBagItemInfo(type, id)
	if savedBagItemInfo and savedBagItemInfo[type] and savedBagItemInfo[type][id] then
		return savedBagItemInfo[type][id]
	end
end

function InfoBag.clearBagItemInfo()
	savedBagItemInfo = nil
end

function InfoBag.getAmount()
	return InfoConsume.getBagAmount().num
end

function InfoBag.getCarryItemList()
	local list = {}
	local existedMap = {}
	local num = 0

	for bag_index, data in pairs(rawData) do
		if data.type == DropManager.TYPE.ITEM then
			local baseID = data.item_id
			local itemCSV = CsvParser.getCsvData("item", baseID)

			if itemCSV.is_quickuse == 1 then
				if not existedMap[baseID] then
					existedMap[baseID] = {
						base_id = baseID,
						num = data.item_num
					}

					table.insert(list, existedMap[baseID])
				else
					existedMap[baseID].num = existedMap[baseID].num + data.item_num
				end
			end
		end
	end

	table.sort(list, function (a, b)
		return a.base_id < b.base_id
	end)

	return list
end

function InfoBag.getDeliverList()
	local arr = {}
	local amount = InfoBag.getAmount()

	for bag_index = 1, amount do
		if rawData[bag_index] then
			if rawData[bag_index].type == DropManager.TYPE.EQUIP then
				table.insert(arr, {
					type = DropManager.TYPE.EQUIP,
					info = InfoEquip.getInfo(rawData[bag_index].equip_id)
				})
			elseif rawData[bag_index].type == DropManager.TYPE.SIGIL then
				table.insert(arr, {
					type = DropManager.TYPE.SIGIL,
					info = InfoSigil.getInfo(rawData[bag_index].sigil_id)
				})
			elseif rawData[bag_index].type == DropManager.TYPE.ITEM then
				local itemCSV = CsvParser.getCsvData("item", rawData[bag_index].item_id)

				if itemCSV.is_autosell ~= 1 then
					table.insert(arr, {
						type = DropManager.TYPE.ITEM,
						info = {
							base_id = rawData[bag_index].item_id,
							num = rawData[bag_index].item_num
						}
					})
				end
			end
		end
	end

	return arr
end

return InfoBag
