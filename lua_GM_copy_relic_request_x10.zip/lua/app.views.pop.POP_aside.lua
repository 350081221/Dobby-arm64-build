local POP_aside = class("POP_aside", UI_base)
local currentInstance = nil

function POP_aside.open(id, onComplete)
	LayerConfig.setPopLocked("POP_aside", true)

	currentInstance = POP_aside.new()

	display.getRunningScene():addChild(currentInstance, LayerConfig.aside)
	currentInstance:show(id, onComplete)
end

function POP_aside.openText(text, params, onComplete)
	currentInstance = POP_aside.new()

	display.getRunningScene():addChild(currentInstance, LayerConfig.aside)
	currentInstance:showText(text, params, onComplete)
end

function POP_aside.getInstance()
	return currentInstance
end

function POP_aside.isOpening()
	return currentInstance ~= nil
end

function POP_aside.close()
	if currentInstance and not tolua.isnull(currentInstance) then
		currentInstance:removeSelf()
	end

	currentInstance = nil

	LayerConfig.setPopLocked("POP_aside", false)
end

function POP_aside:ctor()
	POP_aside.super.ctor(self, "pop_aside", UIManager.BIG_TYPE.CENTER)
	self:init()
end

function POP_aside:init()
	self:initUI()
	transition.fadeIn(self, {
		time = 0.1,
		easing = "sineOut"
	})
end

function POP_aside:initUI()
	local mask = self:getComponentByTag("mask")

	mask:toTouchable()
	mask:setOpacity(0)
end

function POP_aside:show(asideID, onComplete)
	self.id = asideID
	local data = CsvParser.getCsvData("aside", asideID)

	self:showData(data, onComplete)
end

function POP_aside:showText(text, params, onComplete)
	local data = CsvParser.getCsvData("aside", "sample", true)
	data.text = text

	if params then
		for k, v in pairs(data) do
			if params[k] then
				data[k] = params[k]
			end
		end
	end

	self:showData(data, onComplete)
end

function POP_aside:showData(data, onComplete)
	self.onComplete = onComplete
	self.data = data

	self:hideArrow()

	local dataStr = data.text
	dataStr = StringUtil.replaceTag(dataStr, function (tag, embedded)
		return ManagerInfo.parseTag(tag, not embedded)
	end)

	if data.layout == 2 then
		local arrow = self:getComponentByTag("arrow")

		arrow:setVisible(false)
	else
		local arrow = self:getComponentByTag("arrow_2")

		arrow:setVisible(false)
	end

	local mask = self:getComponentByTag("mask")

	mask:setOpacity(math.floor((data.bg_alpha or 0) * 255))

	if not empty(data.background) then
		local background = display.newSprite(getFinalRes("res/image/pic/misc/background/" .. data.background .. ".png"))

		self:addChild(background, 100)
		background:setPosition(self:getBigWidth() / 2, display.cy + self:getBigY())
		background:setOpacity(0)
		transition.fadeTo(background, {
			opacity = 255,
			time = 0.5,
			easing = "linear"
		})

		if not empty(self.data.bg_start_scale) then
			background:setScale(self.data.bg_start_scale)
		end

		self.background = background
	end

	local asides = string.split(dataStr, ";")
	self.asides = {}

	for i = 1, #asides do
		local text = asides[i]

		if string.sub(text, 1, 1) == "\n" then
			text = string.sub(text, 2)
		end

		if string.sub(text, -1) == "\n" then
			text = string.sub(text, 1, -2)
		end

		if asides[i] ~= "" then
			table.insert(self.asides, text)
		end
	end

	self.asideIndex = 1

	self:next()
end

function POP_aside:next()
	if self.asideIndex <= #self.asides then
		self:setText(self.asides[self.asideIndex])

		self.asideIndex = self.asideIndex + 1
	else
		local fadeTime = (self.data.fadeout_time or 6) / 60

		if self.background and not empty(self.data.bg_out_scale) then
			transition.scaleTo(self.background, {
				time = fadeTime,
				scale = self.data.bg_out_scale
			})
		end

		transition.fadeOut(self, {
			easing = "linear",
			time = fadeTime,
			onComplete = function ()
				if self.onComplete then
					self.onComplete()
				end

				self:removeSelf()
			end
		})
	end
end

function POP_aside:fadeOut(labels)
	local hasNext = self.asideIndex <= #self.asides
	local backFade = self.background and not hasNext
	local fadeTime = (self.data.fadeout_time or 6) / 60
	local stayTime = (self.data.stay_time or 0) / 60
	local mask = self:getComponentByTag("mask")

	mask:removeTap()

	for i = 1, #labels do
		local label = labels[i]

		if i == #labels and not backFade then
			transition.fadeOut(label, {
				easing = "sineOut",
				delay = 0.1,
				time = fadeTime,
				onComplete = function ()
					self:next()
				end
			})
		else
			transition.fadeOut(label, {
				easing = "sineOut",
				delay = 0.1,
				time = fadeTime
			})
		end
	end

	if backFade then
		self:next()
	end
end

function POP_aside:setText(text)
	local arrow, textFlagName, yspace = nil
	local bg2 = self:getComponentByTag("bg_2")

	if self.data.layout == 2 then
		arrow = self:getComponentByTag("arrow_2")
		textFlagName = "flag_text_2"

		bg2:setVisible(true)
		bg2:setOpacity(150)
		bg2:setLocalZOrder(200)

		yspace = 10
	else
		arrow = self:getComponentByTag("arrow")
		textFlagName = "flag_text"

		bg2:setVisible(false)

		yspace = 15
	end

	arrow:setLocalZOrder(200)

	local align = Style.left_in_center

	if self.data.layout == 3 then
		align = Style.center
	end

	local ubbMap, labels, lines, totalWidth, totalHeight = self:createUbbOnFlag(textFlagName, text, {
		align = align,
		valign = Style.vcenter,
		yspace = yspace
	})
	local fadeTime = 0.02
	local defaultInterval = 0.03
	local defaultLineInterval = 0.75

	if Localization.isAlphabet() then
		defaultInterval = defaultInterval / 2
	end

	local intervalSum = self:animateUbb(ubbMap, labels, fadeTime, defaultInterval, defaultLineInterval)
	local lastX, lastY = lines[#lines][1]:getPosition()

	if self.data.layout ~= 2 then
		arrow:setPosition(display.width / 2 / self:getBigScale(), lastY - 75)
	end

	local textOver = false
	local fadeTime = (self.data.fadeout_time or 6) / 60
	local stayTime = (self.data.stay_time or 0) / 60

	if self.overSequence then
		self:stopAction(self.overSequence)

		self.overSequence = nil
	end

	self.overSequence = self:performWithDelay(function ()
		textOver = true

		self:showArrow()
	end, intervalSum + 0.5 + stayTime)
	local mask = self:getComponentByTag("mask")

	local function onMaskTap()
		if textOver then
			self:hideArrow()

			if tostring(self.id) == "1010" then
				TaHelper.taGuideDetail(10200)
			elseif tostring(self.id) == "2004" then
				TaHelper.taGuideDetail(10500)
			end

			self:fadeOut(labels)
		elseif self.data.no_skip ~= 1 then
			for i = 1, #labels do
				local label = labels[i]

				transition.stopTarget(label)
				label:setOpacity(255)
			end

			textOver = true

			self:showArrow()
		end
	end

	mask:addTap(onMaskTap)
end

function POP_aside:hideArrow()
	local arrow = nil

	if self.data.layout == 2 then
		arrow = self:getComponentByTag("arrow_2")
	else
		arrow = self:getComponentByTag("arrow")
	end

	transition.stopTarget(arrow)
	arrow:setOpacity(0)
end

function POP_aside:showArrow()
	if self.overSequence then
		self:stopAction(self.overSequence)

		self.overSequence = nil
	end

	local arrow = nil

	if self.data.layout == 2 then
		arrow = self:getComponentByTag("arrow_2")
	else
		arrow = self:getComponentByTag("arrow")
	end

	transition.stopTarget(arrow)
	Style.makePuyo(arrow)
	transition.fadeIn(arrow, {
		time = 0.3
	})
end

function POP_aside:onExit()
	currentInstance = nil

	POP_aside.super.onExit(self)
end

return POP_aside
