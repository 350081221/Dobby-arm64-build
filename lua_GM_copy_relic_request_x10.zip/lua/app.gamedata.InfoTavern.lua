local InfoTavern = {}
local rawData = nil

function InfoTavern.init()
	Connection.listen("tavern_sync", InfoTavern.sync)
end

app:addToAppEnterCall(InfoTavern.init)

function InfoTavern.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoTavern.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("tavern_query", callback)
end

function InfoTavern.onQuery(rcvData)
	rawData = rcvData
end

function InfoTavern.sync(data)
	for k, v in pairs(data) do
		rawData[k] = v
	end

	ManagerInfo.dataChange("tavern", data)
end

function InfoTavern.needRefresh()
	if rawData and Time.now() < rawData.refresh_time then
		return false
	end

	return true
end

function InfoTavern.getData()
	return rawData
end

function InfoTavern.getHeroData(index)
	return rawData.list[index]
end

function InfoTavern.getNextRefreshTime()
	return RefreshManager.getNextTime(RefreshManager.TYPE.TAVERN, Time.now())
end

function InfoTavern.hire(index, hash, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			rawData.count = rcvData.count
			rawData.list[rcvData.index].hired = 1

			ManagerInfo.dataChange("tavern", rawData)

			if not global.player then
				TeamManager.createUnitsOnMap(DungeonScene.enterInfo)
				DungeonState.clearMap()
			else
				TeamManager.refreshTeam()
				InfoGuide.tryTrigger(1040)
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("tavern_hire", {
		index = index,
		hash = hash
	}, callback)
end

function InfoTavern.refresh(mode, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			if CONFIG.is_ta and mode == 1 then
				TaHelper.taTrack("update_hero")
			end

			ManagerInfo.dataChange("tavern", rawData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("tavern_refresh", {
		mode = mode
	}, callback)
end

function InfoTavern.setTargetQuality(target_quality, onSuccess, onFailure)
	if rawData.target_quality == target_quality then
		return
	end

	rawData.target_quality = target_quality

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("tavern_target_quality", {
		target_quality = target_quality
	}, callback)
end

function InfoTavern.getCount()
	return rawData.count
end

function InfoTavern.getProbs(customLevel)
	local buildingLevel = customLevel or InfoBuilding.getBuildingLevel(InfoBuilding.TAG.TAVERN)
	local levelData = CsvParser.getCsvData("tavern", buildingLevel, "level")
	local probs = SheetUtil.getColumnValueList(levelData, "quality_")
	local powerMax = 0
	local powerArr = {}
	local indexMax = 1

	for i, v in ipairs(probs) do
		local quality = i - 1

		if v > 0 then
			powerMax = powerMax + v

			table.insert(powerArr, v)

			indexMax = math.max(indexMax, i)
		end
	end

	local plusData = InfoBuilding.getPlusData(InfoBuilding.TAG.TAVERN, 201)

	if plusData then
		local offset = math.floor(powerArr[indexMax] * plusData.value1 / 100)
		powerArr[indexMax] = powerArr[indexMax] + offset
		powerArr[1] = powerArr[1] - offset
	end

	local probArr = {}
	local qualityMax = 0

	for i, v in ipairs(powerArr) do
		local quality = i - 1
		qualityMax = math.max(qualityMax, quality)

		table.insert(probArr, 1, {
			quality = quality,
			prob = v / powerMax
		})
	end

	return probArr, qualityMax
end

function InfoTavern.getBestQuality()
	local bestQuality = 0

	for i, data in ipairs(rawData.list) do
		if data.hired == 0 then
			bestQuality = math.max(bestQuality, data.quality)
		end
	end

	return bestQuality
end

function InfoTavern.getTavernQuality()
	local targetQuality = rawData.target_quality

	if empty(targetQuality) then
		targetQuality = 2
	end

	return targetQuality
end

return InfoTavern
