local List = import("...ui.List")
local ServerSelectList = class("ServerSelectList", List)

function ServerSelectList:ctor(rect)
	ServerSelectList.super.ctor(self, rect, List.DIRECTION_VERTICAL)
	self:setSpace(5, 5)
	self:setCellName("cell_server_select")
	self:setCellSize(cc.size(self.touchRect.height, 70))
end

function ServerSelectList:onCellInit(ui, data)
	ui:createLabelOnFlag("flag_name", data.name)
end

return ServerSelectList
