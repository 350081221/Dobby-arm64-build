local List = import("...ui.List")
local LIST_select_line = class("LIST_select_line", List)

function LIST_select_line:ctor(rect, cols)
	LIST_select_line.super.ctor(self, rect)
	self:setCellName("cell_select_line")
	self:setSpace(5, 5)
	self:setCellSize(cc.size(self.touchRect.width, 70))
end

function LIST_select_line:onCellInit(ui, data, index)
	local str = Localization.getSrcText("线路：{1}")
	local style = {}

	if data.line_stat > 0 then
		str = Localization.getSrcText("线路(不可切换)：{1}")
		style.color = Style.disableColor
	end

	local _selected = ui:getComponentByTag("selected")
	local _unselected = ui:getComponentByTag("unselected")

	_selected:addLabel(StringUtil.replace(str, data.line_id), style)
	_unselected:addLabel(StringUtil.replace(str, data.line_id), style)
	self:onCellSelected(ui, data, self.selectedIndex == index)
end

function LIST_select_line:onCellSelected(ui, data, selected)
	local _selected = ui:getComponentByTag("selected")
	local _unselected = ui:getComponentByTag("unselected")

	_selected:setVisible(selected)
	_unselected:setVisible(not selected)
end

return LIST_select_line
