local UI_base = import("..UI_base")
local FRAME_naraka_gate = class("FRAME_naraka_gate", UI_base)

function FRAME_naraka_gate.open(npc, onComplete)
	local ui = FRAME_naraka_gate.new(npc, onComplete)

	ui:onOpen()
	PopManager.open(ui, nil, function ()
		if ui.onClose then
			ui:onClose()
		end
	end, PopManager.ANIM_TYPE.FADE, 100)
end

function FRAME_naraka_gate:ctor(npc, onComplete)
	FRAME_naraka_gate.super.ctor(self, "frame_naraka_gate", UIManager.BIG_TYPE.POP)

	self.npc = npc
	self.onComplete = onComplete
	self.chanceCSV = npc.data
	self.total = self.chanceCSV.value1
	self.eventIndex = npc.eventData.index

	self:init()
end

function FRAME_naraka_gate:init()
	self:initUI()

	local csvList = CsvParser.getCsvList("naraka_mode")

	self.list:setItems(csvList)

	self.starMax = 0

	for i, v in ipairs(csvList) do
		self.starMax = self.starMax + v.reward_score
	end

	self:refreshReward()
end

function FRAME_naraka_gate:initUI()
	local mask = self:getComponentByTag("mask")

	mask:toTouchable()
	mask:setOpacity(0)

	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local bt_enter = self:getComponentByTag("bt_enter")

	bt_enter:toTouchable()
	bt_enter:setTapGroup("button_click")
	bt_enter:addTap(function ()
		if self.requestLock then
			return
		end

		self.requestLock = true
		local params = {}
		local totalpoints = 0
		local selectedIndexArr = self.list:getSelectedMulti()

		for i, index in ipairs(selectedIndexArr) do
			local csv = self.list.items[index]

			table.insert(params, csv.id)

			totalpoints = totalpoints + csv.reward_score
		end

		local function onSuccess(rcvData)
			local result = rcvData.dungeon_result

			if CONFIG.is_ta then
				local stageType, stageID = InfoDungeon.getStage()

				TaHelper.taTrack("dailyboss_challenge", {
					stage_id = stageID,
					hero_info = TaHelper.getHeroInfoAll(),
					diffpoint = totalpoints
				})
			end

			local title, subTitle = InfoDungeon.getTitle(result.type, result.dungeon_id, result.quest_id, result.abyss_seed)

			Transition.setTitle(title, subTitle)
			Transition.leave(function ()
				InfoDungeon.enterStage(result)
				DungeonScene.enterDungeon(DungeonScene.ENTER_TYPE.NEW, result)
			end)
		end

		local function onFailure(err)
			self.requestLock = nil
		end

		InfoDungeon.getChance(self.npc, self.eventIndex, params, onSuccess, onFailure)
	end)

	local function tapListener(ui, csv, index)
		self:refreshReward()
	end

	self.list = self:createListOnFlag("flag_mode", LIST_naraka_mode, tapListener, touchListener)

	self.list:setTapGroup("list_click")
	self.list:setMultiSelectEnabled(true)

	local function tapListener(ui, data, index, x, y)
		local worldPos = self.rewardList:convertToWorldSpace(cc.p(x, y))

		if ui.slots then
			for i, v in ipairs(ui.slots) do
				local slot = ui.slots[i]

				if slot and slot:hitTestByComponent("bg", worldPos.x, worldPos.y, true) then
					DropManager.popDetail(slot.type, slot.info)
				end
			end
		end
	end

	self.rewardList = self:createListOnFlag("flag_reward", LIST_naraka_reward, tapListener, touchListener)

	self.rewardList:setTapGroup("list_click")
end

function FRAME_naraka_gate:refreshReward()
	local starNum = 0
	local selectedIndexArr = self.list:getSelectedMulti()

	for i, index in ipairs(selectedIndexArr) do
		local csv = self.list.items[index]
		starNum = starNum + csv.reward_score
	end

	local style = {
		size = 30,
		color = InfoHero.getHpColor(1 - starNum / self.starMax)
	}

	self:replaceLabelGroupOnFlag("flag_star_num", {
		starNum
	}, {
		style
	})

	local narakaCSV = InfoNaraka.getNarakaCSV()
	local rewardArr = {}

	table.insert(rewardArr, {
		title = 1
	})

	local itemArr = string.split(narakaCSV.item_display, ",")
	local items = {}

	for i, v in ipairs(itemArr) do
		if not empty(v) then
			table.insert(items, {
				base_id = v
			})
		end
	end

	table.insert(rewardArr, {
		items = items
	})
	table.insert(rewardArr, {
		title = 2
	})

	local rewardCSV = CsvParser.getCsvData("naraka_score_reward", starNum)
	local items = SheetUtil.getColumnList(rewardCSV, {
		"reward_item_",
		"reward_num_"
	}, {
		"base_id",
		"num"
	})

	table.insert(rewardArr, {
		items = items
	})
	self.rewardList:setStarNum(starNum, self.starMax)
	self.rewardList:setItems(rewardArr)
end

function FRAME_naraka_gate:onOpen()
	local mask = self:getComponentByTag("mask")
	local centerX = mask.x / 2

	global.map:setPositionOffset("ui_open", centerX - display.cx, 0)
	MapUtils.focusIn(self.npc, nil, 10, 1.4)
end

function FRAME_naraka_gate:onClose()
	global.map:setPositionOffset("ui_open", 0, 0)
	MapUtils.focusOut(self.npc, nil, 15)
end

return FRAME_naraka_gate
