local POP_notice_input = class("POP_notice_input", UI_base)
local BUTTON_STYLE = {
	GREEN = 2,
	BLUE = 1,
	RED = 3
}
POP_notice_input.BUTTON_STYLE = BUTTON_STYLE

function POP_notice_input.open(msg, hintStr, defaultValue, inputCheck, confirmFunc, cancelFunc, confirmDesc, cancelDesc, confirmButtonStyle, cancelButtonStyle)
	local ui = POP_notice_input.new("pop_notice_input", msg, hintStr, defaultValue, inputCheck, confirmFunc, cancelFunc, confirmDesc, cancelDesc, confirmButtonStyle, cancelButtonStyle)

	display.getRunningScene():addChild(ui, LayerConfig.notice)
end

function POP_notice_input.openCost(costItem, costStr, msg, hintStr, defaultValue, inputCheck, confirmFunc, cancelFunc, confirmDesc, cancelDesc, confirmButtonStyle, cancelButtonStyle)
	local ui = POP_notice_input.new("pop_notice_input_cost", msg, hintStr, defaultValue, inputCheck, confirmFunc, cancelFunc, confirmDesc, cancelDesc, confirmButtonStyle, cancelButtonStyle)

	ui:setCost(costItem, costStr)
	display.getRunningScene():addChild(ui, LayerConfig.notice)
end

function POP_notice_input:ctor(uiName, msg, hintStr, defaultValue, inputCheck, confirmFunc, cancelFunc, confirmDesc, cancelDesc, confirmButtonStyle, cancelButtonStyle)
	POP_notice_input.super.ctor(self, uiName, UIManager.BIG_TYPE.POP)

	self.msg = msg
	self.hintStr = hintStr or ""
	self.defaultValue = defaultValue or ""
	self.inputCheck = inputCheck
	self.confirmFunc = confirmFunc
	self.cancelFunc = cancelFunc
	self.confirmDesc = confirmDesc
	self.cancelDesc = cancelDesc
	self.confirmButtonStyle = confirmButtonStyle
	self.cancelButtonStyle = cancelButtonStyle

	self:init()
end

function POP_notice_input:init()
	self:initUI()

	if not self.cancelDesc then
		app:setKeyBackCallback(function ()
			local cancelFunc = self.cancelFunc

			self:removeSelf()

			if cancelFunc ~= nil then
				cancelFunc()
			end
		end)
	end
end

function POP_notice_input:initUI()
	local mask = self:getComponentByTag("mask")

	mask:toTouchable()
	self:createLabelOnFlag("flag_msg", self.msg)
	self:createLabelOnFlag("flag_hint", self.hintStr)

	local inputEB = self:createEditBoxOnComponent("eb_input")

	inputEB:setInputMode(6)
	inputEB:setText(self.defaultValue)

	local confirmPB = self:getComponentByTag("confirm_pb")

	if self.confirmDesc then
		confirmPB:addLabel(self.confirmDesc)
	end

	confirmPB:toTouchable()
	confirmPB:setTapGroup("button_click")

	local function doConfirm(inputStr)
		local confirmFunc = self.confirmFunc

		if confirmFunc ~= nil then
			confirmFunc(inputStr)
		end

		self:removeSelf()
	end

	local function handleConfirm()
		local inputStr = inputEB:getText()

		if self.inputCheck and not self.inputCheck(inputStr) then
			return
		end

		if self.costItem then
			POP_notice.open(self.costStr, function ()
				doConfirm(inputStr)
			end)
		else
			doConfirm(inputStr)
		end
	end

	confirmPB:addTap(handleConfirm)

	local cancelPB = self:getComponentByTag("cancel_pb")

	if self.cancelDesc then
		cancelPB:addLabel(self.cancelDesc)
	end

	cancelPB:toTouchable()
	cancelPB:setTapGroup("button_click")

	local function handleCancel()
		local cancelFunc = self.cancelFunc

		if cancelFunc ~= nil then
			cancelFunc()
		end

		self:removeSelf()
	end

	cancelPB:addTap(handleCancel)

	if self:getFlagByTag("flag_cost") then
		self.costList = self:createListOnFlag("flag_cost", CostListH)

		self.costList:setDetailDisabled()
	end
end

function POP_notice_input:setCost(costItem, costStr)
	self.costItem = costItem
	self.costStr = costStr

	self.costList:setItems({
		costItem
	})
end

function POP_notice_input:onExit()
	app:clearKeyBackCallback()
	POP_notice_input.super.onExit(self)
end

return POP_notice_input
