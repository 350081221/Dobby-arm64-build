local InfoGM = {}
local rawData = {}

function InfoGM.init()
end

InfoGM.init()

local alreadySendErrorMap = {}

function InfoGM.sendError(tag, content)
	if InfoParams.getValue("client_err_log") ~= 1 then
		return
	end

	if alreadySendErrorMap[content] then
		return
	end

	alreadySendErrorMap[content] = true

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("gm_log_error", {
		tag = tag,
		content = content,
		version = version
	}, callback)
end

function InfoGM.sendLog(tag, content)
end

function InfoGM.setBuildingLevel(tag, level, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			notify.dispatch("building_set_level", tag)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("gm_building_level", {
		tag = tag,
		level = level
	}, callback)
end

function InfoGM.setHero(id, base_id, level, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("gm_set_hero", {
		id = id,
		base_id = base_id,
		level = level
	}, callback)
end

function InfoGM.setPet(id, name, base_id, level, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("gm_set_pet", {
		id = id,
		name = name,
		base_id = base_id,
		level = level
	}, callback)
end

function InfoGM.setInitItem(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("gm_init_item", callback)
end

function InfoGM.setItemNum(id, num, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("gm_set_item", {
		id = id,
		num = num
	}, callback)
end

function InfoGM.setItemLimit(id, num, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("gm_set_item_limit", {
		id = id,
		num = num
	}, callback)
end

function InfoGM.dropItemNum(id, num, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("gm_drop_item", {
		id = id,
		num = num
	}, callback)
end

function InfoGM.addBagItem(id, num, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("gm_bag_item", {
		id = id,
		num = num
	}, callback)
end

function InfoGM.addBagCard(id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("gm_bag_card", {
		id = id
	}, callback)
end

function InfoGM.drop(drop_id, level, rare, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("gm_drop", {
		drop_id = drop_id,
		level = level,
		rare = rare
	}, callback)
end

function InfoGM.setCurrentGuide(id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("gm_guide", {
		id = id
	}, callback)
end

function InfoGM.setFreeGuide(id, isFin, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("gm_guide_free", {
		id = id,
		is_fin = isFin
	}, callback)
end

function InfoGM.setMission(id, isFin, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("gm_mission", {
		id = id,
		is_fin = isFin
	}, callback)
end

function InfoGM.setBook(base_id, id, record, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("gm_book", {
		base_id = base_id,
		id = id,
		record = record
	}, callback)
end

function InfoGM.getAttrs(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("gm_attrs", {}, callback)
end

function InfoGM.setMine(mine_index, is_active, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "gm_mine")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("gm_mine", {
		mine_index = mine_index,
		is_active = is_active
	}, callback)
end

function InfoGM.resetTask(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoTaskQuest.snapshotReset()

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("gm_task_reset", callback)
end

function InfoGM.setMirror(type, level, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("gm_mirror_set_level", {
		type = type,
		level = level
	}, callback)
end

function InfoGM.dismissNonposHero(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			local rewards = rcvData.rewards

			if rewards and #rewards > 0 then
				POP_reward.openMixed(rewards, nil, Localization.getSrcText("返还物品"))
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("gm_hero_dismiss_nonpos", callback)
end

function InfoGM.removeUnequipedEquip(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("gm_equip_remove_unequiped", callback)
end

function InfoGM.removeUnequipedCard(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("gm_card_remove_unequiped", callback)
end

function InfoGM.setAbyss(maxLayer, maxLevel, autoPickTime, autoPickCurr, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoDungeon.gmSetAbyss(maxLayer, maxLevel, autoPickTime, autoPickCurr)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("gm_set_abyss", {
		max_layer = maxLayer,
		max_level = maxLevel,
		autopick_time = autoPickTime,
		autopick_curr = autoPickCurr
	}, callback)
end

function InfoGM.setArena(season, points, vs_points, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("gm_set_arena", {
		season = season,
		points = points,
		vs_points = vs_points
	}, callback)
end

function InfoGM.setChecksumFree(value, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("gm_checksum_free", {
		value = value
	}, callback)
end

function InfoGM.refreshChecksumFree()
	print("$$$ refreshChecksumFree", global.super, global.weak, global.attr_debug)

	if global.super or global.weak or global.attr_debug or global.autodown then
		InfoGM.setChecksumFree(1)
	else
		InfoGM.setChecksumFree(0)
	end
end

function InfoGM.clearNonexistItem(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "gm_clear_nonexist_item")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			Console.log("清理", rcvData.count, "个物品")

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("gm_clear_nonexist_item", callback)
end

function InfoGM.gachaInfo(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "gm_gacha_info")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("gm_gacha_info", callback)
end

function InfoGM.test(id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "gm_test")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("gm_test", {
		id = id
	}, callback)
end

function InfoGM:enterDungeon(layer, enter_layer, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ rcvData")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			local title, subTitle = InfoDungeon.getTitle(rcvData.type, rcvData.dungeon_id, rcvData.quest_id, rcvData.abyss_seed)

			Transition.setTitle(title, subTitle)
			Transition.leave(function ()
				InfoDungeon.makeMaps(rcvData)

				if onSuccess then
					onSuccess(rcvData)
				end
			end)
		end
	end

	Connection.request("gm_dungeon_enter", {
		layer = layer,
		enter_layer = enter_layer
	}, callback)
end

function InfoGM.setDropLimit(value, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			global.gmDropLimit = value

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("gm_drop_limit", {
		value = value
	}, callback)
end

function InfoGM.resetOrder(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("gm_order_reset", callback)
end

function InfoGM.dustModify(params, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("gm_dust_modify", params, callback)
end

function InfoGM.rankingAdd(type, points, user_id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "gm_ranking_add")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("gm_ranking_add", {
		type = type,
		points = points,
		user_id = user_id
	}, callback)
end

function InfoGM.dropCheck(dropID, num, onSuccess, onFailure)
	print("$$$ InfoGM.dropCheck", dropID, num)

	local function callback(rcvData)
		dump(rcvData, "gm_drop_check")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("gm_drop_check", {
		drop_id = dropID,
		num = num
	}, callback)
end

function InfoGM.usedrop(itemID, num, onSuccess, onFailure)
	print("$$$ InfoGM.usedrop", itemID, num)

	local function callback(rcvData)
		dump(rcvData, "gm_item_usedrop")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("gm_item_usedrop", {
		item_id = itemID,
		num = num
	}, callback)
end

function InfoGM.usedropUI(itemID, num, onSuccess, onFailure)
	print("$$$ InfoGM.usedrop", itemID, num)

	local function callback(rcvData)
		dump(rcvData, "gm_item_usedrop_ui")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("gm_item_usedrop_ui", {
		item_id = itemID,
		num = num
	}, callback)
end

function InfoGM.unionRes(money, res, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "gm_union_set_money_and_res")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("gm_union_set_money_and_res", {
		money = money,
		res = res
	}, callback)
end

function InfoGM.testVar(name, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "gm_var")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("gm_var", {
		name = name
	}, callback)
end

return InfoGM
