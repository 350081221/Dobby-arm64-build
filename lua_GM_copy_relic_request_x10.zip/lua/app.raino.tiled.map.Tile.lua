local AstarTile = import("..astar.AstarTile")
local Tile = class("Tile", AstarTile)

function Tile.clear()
	Tile.assetsMap = {}
	Tile.assetsTagMap = {}
end

function Tile:ctor(map, x, y, mapTile)
	Tile.super.ctor(self, x, y)

	local mapX, mapY = map:tileToMap(self)
	local drawX, drawY = map:mapToDraw(mapX, mapY)
	self.drawX = drawX
	self.drawY = drawY
	self.tag = self.x .. "_" .. self.y
	self.sortTag = crypto.md5(self.tag)
	self.map = map
	self.mapTile = mapTile

	if mapTile then
		self.walk = mapTile:getWalk()
	else
		self.walk = 0
	end

	self.light = {
		b = 1,
		g = 1,
		base = 0,
		r = 1,
		sum = 0,
		clipLightMap = {}
	}

	if not empty(self.map.config.light.color_rgb) then
		local rgbArr = string.split(self.map.config.light.color_rgb, ",")
		self.light.originalRGB = {
			r = self.light.r,
			g = self.light.g,
			b = self.light.b
		}
		self.light.r = tonumber(rgbArr[1] / 255)
		self.light.g = tonumber(rgbArr[2] / 255)
		self.light.b = tonumber(rgbArr[3] / 255)
	end

	self.filledCount = 0
	self.unitMap = {}
	self.unitIndex = 0
	self.unitIndexMap = {}
	self.otherMap = {}
	self.unitChangeListenerStack = {}
end

function Tile:getUnitArr()
	local arr = {}

	for k, unit in pairs(self.unitMap) do
		table.insert(arr, unit)
	end

	table.sort(arr, function (a, b)
		return a.id < b.id
	end)

	return arr
end

function Tile:addClipLight(clipID, light, rgb)
	self.light.clipLightMap[clipID] = {
		light = light,
		rgb = rgb
	}

	self.map:addTileLightDirty(self)
end

function Tile:removeClipLight(clipID)
	self.light.clipLightMap[clipID] = nil

	self.map:addTileLightDirty(self)
end

function Tile:refreshLightSum()
	self.light.sum = self.light.base
	local rgbArr = {}
	local rgbStr = ""

	for clipID, lightObj in pairs(self.light.clipLightMap) do
		self.light.sum = self.light.sum + lightObj.light

		if lightObj.rgb and lightObj.light > 0 then
			table.insert(rgbArr, lightObj)

			if rgbStr ~= "" then
				rgbStr = rgbStr .. ","
			end

			rgbStr = rgbStr .. math.floor(lightObj.light * 255) .. "." .. lightObj.rgb.r .. "." .. lightObj.rgb.g .. "." .. lightObj.rgb.b
		end
	end

	local r = 255
	local g = 255
	local b = 255
	local lightTotal = self.mapTile:getLightObj() + self.light.sum + self.map.config.light.color_base

	if #rgbArr > 0 and self.light.sum > 0 then
		for i, lightObj in ipairs(rgbArr) do
			r = r - (255 - lightObj.rgb.r) * lightObj.light / lightTotal
			g = g - (255 - lightObj.rgb.g) * lightObj.light / lightTotal
			b = b - (255 - lightObj.rgb.b) * lightObj.light / lightTotal
		end

		r = r - (255 - r) * math.min(255, lightTotal) / 255
		g = g - (255 - g) * math.min(255, lightTotal) / 255
		b = b - (255 - b) * math.min(255, lightTotal) / 255
		r = math.max(0, r)
		g = math.max(0, g)
		b = math.max(0, b)
	end

	if not empty(self.map.config.light.color_rgb) then
		local rgbArr = string.split(self.map.config.light.color_rgb, ",")
		self.light.originalRGB = {
			r = r / 255,
			g = g / 255,
			b = b / 255
		}
		r = math.min(r, 255 - (255 - tonumber(rgbArr[1])) * math.max(0, 1 - self.light.sum))
		g = math.min(g, 255 - (255 - tonumber(rgbArr[2])) * math.max(0, 1 - self.light.sum))
		b = math.min(b, 255 - (255 - tonumber(rgbArr[3])) * math.max(0, 1 - self.light.sum))
	end

	self.light.r = r / 255
	self.light.g = g / 255
	self.light.b = b / 255

	self.mapTile:setLightBase(self.light.sum, rgbStr)
	self:refreshAssetsLight()
	self:refreshUnitLight()
end

function Tile:addOther(clip)
	if self.otherMap[clip.id] == nil then
		self.otherMap[clip.id] = clip

		if not clip.noFillTile then
			self.filledCount = self.filledCount + 1

			if self.filledCount == 1 then
				self:setFilled(true)
			end
		end
	end
end

function Tile:removeOther(clip)
	if self.otherMap[clip.id] ~= nil then
		self.otherMap[clip.id] = nil

		if not clip.noFillTile then
			self.filledCount = self.filledCount - 1

			if self.filledCount <= 0 then
				self:setFilled(false)
			end
		end
	end
end

function Tile:addUnit(unit)
	if self.unitMap[unit.id] == nil then
		self.unitMap[unit.id] = unit
		self.unitIndexMap[unit.id] = self.unitIndex
		self.unitIndex = self.unitIndex + 1

		self:clearOccupied()
		self:refreshOccupied()

		if unit.tile == self then
			for i = 1, #self.unitChangeListenerStack do
				self.unitChangeListenerStack[i].func(self.unitChangeListenerStack[i].obj, unit, true)
			end
		end

		if not unit.noFillTile then
			self.filledCount = self.filledCount + 1

			if self.filledCount == 1 then
				self:setFilled(true)
			end
		end
	end
end

function Tile:removeUnit(unit)
	if self.unitMap[unit.id] ~= nil then
		self.unitMap[unit.id] = nil
		self.unitIndexMap[unit.id] = nil

		self:clearOccupied()
		self:refreshOccupied()

		if unit.tile == self then
			for i = 1, #self.unitChangeListenerStack do
				self.unitChangeListenerStack[i].func(self.unitChangeListenerStack[i].obj, unit, false)
			end
		end

		if not unit.noFillTile then
			self.filledCount = self.filledCount - 1

			if self.filledCount <= 0 then
				self:setFilled(false)
			end
		end
	end
end

function Tile:isMasterUnit(testUnit)
	local testID = self.unitIndexMap[testUnit.id]
	local testSize = testUnit.size or 0

	if Map.NO_UNIT_BLOCK or testUnit.noBlock or testUnit.speed == 0 or testUnit.speed == nil or testUnit.getState and testUnit:getState("no_move") then
		return true
	end

	for unitID, unit in pairs(self.unitMap) do
		local id = self.unitIndexMap[unitID]

		if unit ~= testUnit and unit.isBlock and not unit.noEntity then
			if unit.speed == nil or unit.speed == 0 or unit.getState and unit:getState("no_move") then
				return false
			end

			local unitSize = unit.size or 0

			if testSize < unitSize then
				return false
			end

			if unitSize == testSize and testID < id then
				return false
			end
		end
	end

	return true
end

function Tile:findUnit(_unit)
	for unitID, unit in pairs(self.unitMap) do
		if unit == _unit then
			return true
		end
	end

	return false
end

function Tile:addUnitChangeListener(obj, func, multiply)
	for i = 1, #self.unitChangeListenerStack do
		if self.unitChangeListenerStack[i].obj == obj and self.unitChangeListenerStack[i].func == func then
			return
		end
	end

	for unitID, unit in pairs(self.unitMap) do
		if multiply or unit.tile == self then
			func(obj, unit, true)
		end
	end

	table.insert(self.unitChangeListenerStack, {
		obj = obj,
		func = func
	})
end

function Tile:removeUnitChangeListener(obj, func, multiply)
	for i = 1, #self.unitChangeListenerStack do
		if self.unitChangeListenerStack[i].obj == obj and self.unitChangeListenerStack[i].func == func then
			table.remove(self.unitChangeListenerStack, i)

			break
		end
	end

	for unitID, unit in pairs(self.unitMap) do
		if multiply or unit.tile == self then
			func(obj, unit, false)
		end
	end
end

function Tile:getOccupied(unit)
	return self.occupiedUnit ~= nil and self.occupiedUnit ~= unit
end

function Tile:setOccupied(unit)
	if unit.isBlock then
		self.occupiedUnit = unit

		self:refreshOccupied()
	end
end

function Tile:clearOccupied(unit)
	if unit == nil then
		self.occupiedUnit = nil
	elseif unit == self.occupiedUnit then
		self.occupiedUnit = nil
	end

	self:refreshOccupied()
end

function Tile:refreshOccupied()
end

function Tile:getBorder(way)
	if Map.NO_BORDER then
		return false
	end

	if way == 0 then
		if self.map.borderStack[self.x .. "_" .. self.y] and self.map.borderStack[self.x .. "_" .. self.y][1] then
			return true
		end
	elseif way == 3 then
		if self.map.borderStack[self.x .. "_" .. self.y] and self.map.borderStack[self.x .. "_" .. self.y][0] then
			return true
		end
	elseif way == 2 then
		if self.map.borderStack[self.x + 1 .. "_" .. self.y] and self.map.borderStack[self.x + 1 .. "_" .. self.y][1] then
			return true
		end
	elseif way == 1 and self.map.borderStack[self.x .. "_" .. self.y + 1] and self.map.borderStack[self.x .. "_" .. self.y + 1][0] then
		return true
	end

	return false
end

function Tile:getBorderFull()
	if Map.NO_BORDER then
		return false
	end

	for i = 0, 3 do
		if self:getBorder(i) then
			return true
		end
	end

	return false
end

function Tile:isEmpty()
	return table.nums(self.unitMap) == 0 and table.nums(self.otherMap) == 0
end

function Tile:isEmptyUnit()
	return table.nums(self.unitMap) == 0
end

function Tile:getWalkable(walkLevel, checkUnit, noCheckOccupied)
	if Map.walkOnVislble and not self:getVisible() then
		return false
	end

	if walkLevel < self:getWalk() then
		return false
	elseif not Map.NO_UNIT_BLOCK then
		if type(checkUnit) == "function" then
			return checkUnit(self, self.unitMap)
		elseif not checkUnit or not checkUnit.noBlock then
			for unitID, unit in pairs(self.unitMap) do
				if unit ~= checkUnit and unit.isBlock then
					return false
				end
			end
		end
	end

	if not Map.NO_UNIT_BLOCK and not noCheckOccupied then
		if type(checkUnit) == "function" then
			return checkUnit(self)
		elseif checkUnit and not checkUnit.noBlock then
			return not self:getOccupied(checkUnit)
		end
	end

	return true
end

function Tile:setForceWalk(tag, level)
	if not self.forceWalkStack then
		self.forceWalkStack = {}
	end

	self.forceWalkStack[tag] = level
	self.forceWalk = 0

	for _tag, _level in pairs(self.forceWalkStack) do
		self.forceWalk = math.max(self.forceWalk, _level)
	end
end

function Tile:removeForceWalk(tag)
	if self.forceWalkStack then
		self.forceWalkStack[tag] = nil

		if table.nums(self.forceWalkStack) == 0 then
			self.forceWalkStack = nil
			self.forceWalk = nil
		else
			self.forceWalk = 0

			for _tag, _level in pairs(self.forceWalkStack) do
				self.forceWalk = math.max(self.forceWalk, _level)
			end
		end
	end
end

function Tile:getWalk()
	if not Map.NO_FORCE_WALK and self.forceWalk then
		return self.forceWalk
	end

	return self.walk
end

function Tile:onDraw()
	self:setUnitActive(true)
	self:checkWaking(true)
	MapEventManager.onDrawTile(self)
	MapEffect.onDrawTile(self)
end

function Tile:onErase()
	self:setUnitActive(false)
	self:checkWaking(false)
	MapEventManager.onEraseTile(self)
	MapEffect.onEraseTile(self)
end

function Tile:checkWaking(wake)
	for unitID, unit in pairs(self.unitMap) do
		if unit.tile == self and unit.type == "monster" then
			if wake then
				unit:wake()
			else
				unit:sleep()
			end
		end
	end
end

function Tile:setUnitActive(active)
	for unitID, unit in pairs(self.unitMap) do
		if unit.tile == self then
			unit:setActive(active)
			unit:refreshVisible()
		end
	end

	for unitID, unit in pairs(self.otherMap) do
		if unit.tile == self then
			unit:refreshVisible()
		end
	end
end

function Tile:refreshUnitLight()
	for unitID, unit in pairs(self.unitMap) do
		if unit.tile == self then
			unit:refreshSelfLight()
		end
	end

	for unitID, unit in pairs(self.otherMap) do
		if unit.tile == self then
			unit:refreshSelfLight()
		end
	end
end

function Tile:refreshUnitVisible()
	for unitID, unit in pairs(self.unitMap) do
		if unit.tile == self then
			unit:refreshVisible()
		end
	end

	for unitID, unit in pairs(self.otherMap) do
		if unit.tile == self then
			unit:refreshVisible()
		end
	end

	self:refreshAssetsLight()
end

function Tile:setInview(inview)
	if self.mapTile then
		self.mapTile:setInview(inview)
	end
end

function Tile:getInview()
	if self.mapTile then
		return self.mapTile:getInview()
	else
		return true
	end
end

function Tile:getVisible()
	if self.mapTile then
		return self.mapTile:getVisible()
	else
		return true
	end
end

function Tile:setFilled(filled, tag)
	tag = tag or "default"
	local preFilled = self.filledTags ~= nil

	if filled then
		self.filledTags = self.filledTags or {}
		self.filledTags[tag] = true
	elseif self.filledTags then
		self.filledTags[tag] = nil
	end

	if self.filledTags and table.nums(self.filledTags) == 0 then
		self.filledTags = nil
	end

	local newFilled = self.filledTags ~= nil

	if preFilled ~= newFilled and self.mapTile then
		self.mapTile:setFilled(newFilled)
	end
end

function Tile:setHasEvent(b)
	self.mapTile:setHasEvent(b)
end

Tile.lightColor = {}

function Tile.getLightColor(c, r, g, b)
	local r = math.ceil(c * r)
	local g = math.ceil(c * g)
	local b = math.ceil(c * b)
	local tag = r .. "_" .. g .. "_" .. b

	if Tile.lightColor[tag] == nil then
		Tile.lightColor[tag] = cc.c3b(r, g, b)
	end

	return Tile.lightColor[tag]
end

function Tile:getUnitLight()
	if self.mapTile then
		return self.mapTile:getLightObj() + self.light.sum
	else
		return 1
	end
end

function Tile:getUnitLightRGB()
	if self.mapTile then
		local r = self.light.r
		local g = self.light.g
		local b = self.light.b

		if self.light.originalRGB then
			local originalPercent = 0.75
			r = r * (1 - originalPercent) + self.light.originalRGB.r * originalPercent
			g = g * (1 - originalPercent) + self.light.originalRGB.g * originalPercent
			b = b * (1 - originalPercent) + self.light.originalRGB.b * originalPercent
		end

		return self.mapTile:getLightObj() + self.light.sum, r, g, b
	else
		return 1, 1, 1, 1
	end
end

function Tile:getGroundLight()
	return self.mapTile:getLightGround() + self.light.sum
end

function Tile:setLightForce(groundLight, objLight)
	self.mapTile:setLightForce(groundLight, objLight)
end

function Tile:removeLightForce()
	self.mapTile:removeLightForce()
end

Tile.assetsMap = {}
Tile.assetsTagMap = {}
Tile.assetsZOrders = {
	skill_select = 300,
	skill_range_disable = 200,
	skill_range = 100
}

function Tile:openAsset(assetName, tag)
	tag = tag or "default"

	if not Tile.assetsTagMap[self.tag] then
		Tile.assetsTagMap[self.tag] = {}
	end

	if not Tile.assetsTagMap[self.tag][assetName] then
		Tile.assetsTagMap[self.tag][assetName] = {
			[tag] = true
		}

		if Tile.assetsMap[self.tag] == nil then
			Tile.assetsMap[self.tag] = {}

			self:setFilled(true, "assets")
		end

		local newSprite = nil

		if Tile.assetsMap[self.tag][assetName] == nil then
			local sprite = display.newSprite("#map_assets_" .. assetName)

			sprite:setPosition(self.drawX, -self.drawY)
			self.map.lightLayer:addChild(sprite, Tile.assetsZOrders[assetName] or 100)

			Tile.assetsMap[self.tag][assetName] = sprite
			newSprite = sprite
		end

		return newSprite
	else
		Tile.assetsTagMap[self.tag][assetName][tag] = true
	end
end

function Tile:closeAsset(assetName, tag)
	tag = tag or "default"

	if not Tile.assetsTagMap[self.tag] then
		Tile.assetsTagMap[self.tag] = {}
	end

	if Tile.assetsTagMap[self.tag][assetName] then
		Tile.assetsTagMap[self.tag][assetName][tag] = nil

		if table.nums(Tile.assetsTagMap[self.tag][assetName]) == 0 then
			Tile.assetsTagMap[self.tag][assetName] = nil
		end
	end

	if not Tile.assetsTagMap[self.tag][assetName] and Tile.assetsMap[self.tag] then
		if Tile.assetsMap[self.tag][assetName] then
			local sprite = Tile.assetsMap[self.tag][assetName]

			sprite:removeSelf()

			Tile.assetsMap[self.tag][assetName] = nil
		end

		if table.nums(Tile.assetsMap[self.tag]) == 0 then
			Tile.assetsMap[self.tag] = nil

			self:setFilled(false, "assets")
		end
	end
end

function Tile:fadeoutAssets()
	self.assetOpacityLocked = true

	if Tile.assetsMap[self.tag] then
		for assetName, sprite in pairs(Tile.assetsMap[self.tag]) do
			transition.fadeTo(sprite, {
				time = 0.2,
				opacity = 0
			})
		end
	end
end

function Tile:fadeinAssets()
	if Tile.assetsMap[self.tag] then
		for assetName, sprite in pairs(Tile.assetsMap[self.tag]) do
			transition.fadeTo(sprite, {
				time = 0.2,
				opacity = self.assetOpacity,
				onComplete = function ()
					self.assetOpacityLocked = nil

					self:refreshAssetsLight()
				end
			})
		end
	else
		self.assetOpacityLocked = nil
	end
end

function Tile:refreshAssetsLight()
	if Tile.assetsMap[self.tag] then
		self.assetOpacity = math.floor(math.max(0, math.min(1, self:getUnitLight())) * 255)

		for assetName, sprite in pairs(Tile.assetsMap[self.tag]) do
			if not self.assetOpacityLocked then
				sprite:setOpacity(self.assetOpacity)
			end
		end
	end
end

function Tile.clearAssetsByName(assetName)
	for tileTag, assetsMap in pairs(Tile.assetsMap) do
		if assetsMap[assetName] then
			local sprite = assetsMap[assetName]

			transition.fadeTo(sprite, {
				opacity = 0,
				time = 0.2,
				onComplete = function ()
					sprite:removeSelf()
				end
			})

			assetsMap[assetName] = nil
		end
	end

	for tileTag, assetsMap in pairs(Tile.assetsTagMap) do
		if assetsMap[assetName] then
			assetsMap[assetName] = nil
		end
	end
end

function Tile:getTag()
	return self.tag
end

function Tile:setShockOffset(height)
	self.mapTile:setShockOffset(height)
end

return Tile
