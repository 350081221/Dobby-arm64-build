local ConnBench = class("ConnBench")
local proto = import("..proto.proto")
local sproto = import("..proto.sproto")
local Scheduler = cc.Director:getInstance():getScheduler()
local SimpleTCP = require("framework.SimpleTCP")

function ConnBench:ctor()
	self._host = sproto.new(proto.s2c):host("package")
	self._request = self._host:attach(sproto.new(proto.c2s))
	self._last = ""
	self.session = 0
	self.host = nil
	self.port = nil
	self.socket = nil
	self.response = {}
	self.listener = {}
	self.tosendStack = {}
	self.sendLock = nil
end

require("pack")

function ConnBench:pack_msg(str)
	if _VERSION ~= "Lua 5.3" then
		local len = string.len(str)
		local leninfo = string.pack("bb", math.floor(len / 256), len % 256)

		return string.pack("A", leninfo .. str)
	else
		return string.pack(">s2", str)
	end
end

function ConnBench:unpack_package(text)
	local size = #text

	if size < 2 then
		return nil, text
	end

	local s = text:byte(1) * 256 + text:byte(2)

	if size < s + 2 then
		return nil, text
	end

	return text:sub(3, 2 + s), text:sub(3 + s)
end

function ConnBench:recv_package(r)
	local result, _last = nil
	result, _last = self:unpack_package(self._last)
	self._last = _last

	if result then
		return self._host:dispatch(result)
	end

	result, _last = self:unpack_package(self._last .. r)
	self._last = _last

	if result then
		return self._host:dispatch(result)
	end
end

function ConnBench:pack_request(name, args)
	self.session = self.session + 1
	local str = self._request(name, args, self.session)
	local package = self:pack_msg(str)

	return package, self.session
end

local function print_request(name, args)
	print("REQUEST", name)

	if args then
		for k, v in pairs(args) do
			print(k, v)
		end
	end
end

local function print_response(session, args)
	print("RESPONSE", session)

	if args then
		for k, v in pairs(args) do
			print(k, v)
		end
	end
end

local function print_package(t, ...)
	if t == "REQUEST" then
		print_request(...)
	else
		assert(t == "RESPONSE")
		print_response(...)
	end
end

function ConnBench:init(host, port)
	Log.verbose("[ConnBench.init]", host, port)

	self.host = host
	self.port = port

	self:initSocket()

	local function callback(dt)
		self:sendNext()
	end

	local callbackEntry = Scheduler:scheduleScriptFunc(callback, 0.2, false)
end

function ConnBench:initSocket()
	self.socket = SimpleTCP.new(self.host, self.port, function (event, data)
		if event ~= SimpleTCP.EVENT_DATA and self.waitingForReconnect then
			if self.waitingForReconnect == 2 then
				if event == SimpleTCP.EVENT_CONNECTED then
					self.waitingForReconnect = 1

					self.socket:close()

					return
				end
			elseif self.waitingForReconnect == 1 then
				if event == SimpleTCP.EVENT_CONNECTED then
					self.waitingForReconnect = nil

					if self.reconnectCallback then
						self:reconnectCallback()
					end
				elseif event == SimpleTCP.EVENT_CLOSED or event == SimpleTCP.EVENT_FAILED then
					self.socket:connect()
				end
			end

			return
		end

		self:onSocketEvent(event, data)
	end)

	self.socket:connect()
end

function ConnBench:connect()
	self.socket:connect()
end

function ConnBench:reconnect(onComplete)
	if self.socket.stat == SimpleTCP.STAT_CONNECTING then
		self.waitingForReconnect = 2
		self.reconnectCallback = onComplete
	elseif self.socket.stat == SimpleTCP.STAT_CONNECTED then
		self.waitingForReconnect = 1
		self.reconnectCallback = onComplete

		self.socket:close()
	else
		self.socket:connect()
	end
end

function ConnBench:registerSocket()
end

function ConnBench:onSocketEvent(event, data)
	if event == SimpleTCP.EVENT_DATA then
		local t, session_id, resp, err = self:recv_package(data)

		while t do
			if t == "REQUEST" then
				local pack = self.listener[session_id]

				if pack then
					pack.callback(resp)

					if pack.totalTimes then
						pack.times = pack.times + 1

						if pack.totalTimes <= pack.times then
							self.listener[session_id] = nil
						end
					end
				end
			else
				assert(t == "RESPONSE")

				self.tosendStack[session_id] = nil

				if self.response[session_id] then
					if resp.err then
						print("[err]" .. resp.err)
						ErrCode.onErr(resp.err)
					end

					self.response[session_id].callback(resp)

					self.response[session_id] = nil
				end

				self.sendLock = nil
			end

			t, session_id, resp, err = self:recv_package("")
		end

		self:sendNext()
	elseif event == SimpleTCP.EVENT_CONNECTED then
		-- Nothing
	elseif event == SimpleTCP.EVENT_CONNECTING then
		-- Nothing
	elseif event == SimpleTCP.EVENT_CONNECTED then
		-- Nothing
	elseif event == SimpleTCP.EVENT_CLOSED then
		-- Nothing
	end
end

function ConnBench:flush()
	self:sendNext()
end

function ConnBench:clearFlush()
	self.tosendStack = {}
end

function ConnBench:send(name, args)
	if self.waitingForReconnect then
		return
	end

	local package, session = self:pack_request(name, args)

	if self.socket then
		self.tosendStack[session] = package

		self:sendNext()
	end

	return session
end

function ConnBench:sendNext()
	if self.socket.stat == SimpleTCP.STAT_CONNECTED and (not self.sendLock or self.sendLock < Time.time()) then
		local tosendList = {}

		for session, package in pairs(self.tosendStack) do
			table.insert(tosendList, {
				session = session,
				package = package
			})
		end

		if #tosendList > 0 then
			table.sort(tosendList, function (a, b)
				return a.session < b.session
			end)

			local first = tosendList[1]
			self.tosendStack[first.session] = nil
			local package = first.package
			self.sendLock = Time.time() + GameConfig.request_lock_c

			self.socket:send(package)
		end
	end
end

function ConnBench:request(cmd, args, callback)
	if type(args) == "function" then
		callback = args
		args = {}
	end

	local now = Time.time()

	local function newCallback(resp)
		local lag = Time.time() - now
		resp.lag = lag

		if callback then
			callback(resp)
		end
	end

	self:doRequest(cmd, args, newCallback)
end

function ConnBench:doRequest(cmd, args, callback)
	if type(args) == "function" then
		callback = args
		args = {}
	end

	args.beat = math.floor(Time.lifeTime())
	local session = self:send(cmd, args)
	self.response[session] = {
		callback = callback
	}
end

function ConnBench:listen(cmd, callback, times)
	self.listener[cmd] = {
		times = 0,
		callback = callback,
		totalTimes = times
	}
end

function ConnBench:removeListen(cmd)
	self.listener[cmd] = nil
end

function ConnBench:getStat()
	if self.socket then
		if self.socket.stat == SimpleTCP.STAT_CONNECTING then
			return "connecting"
		elseif self.socket.stat == SimpleTCP.STAT_FAILED then
			return "failed"
		elseif self.socket.stat == SimpleTCP.STAT_CONNECTED then
			return "connected"
		elseif self.socket.stat == SimpleTCP.STAT_CLOSED then
			return "closed"
		end
	end

	return "unknown"
end

function ConnBench:isLocked()
	if self.sendLock and Time.time() <= self.sendLock then
		return true
	end
end

return ConnBench
