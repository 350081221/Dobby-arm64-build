local NAV_base = import(".NAV_base")
local NAV_seat = class("NAV_seat", NAV_base)

function NAV_seat.open(npc)
	local ui = NAV_seat.new(npc)

	return ui
end

function NAV_seat:ctor(npc)
	NAV_seat.super.ctor(self, npc, "nav_seat")
end

function NAV_seat:init()
	NAV_seat.super.init(self)
end

function NAV_seat:onTap(index)
	NAV_seat.super.onTap(self, index)

	if index == 1 then
		FRAME_seat.open(self.npc)
	end
end

return NAV_seat
