local SimpleTCP = require("framework.SimpleTCP")
local POP_doing = class("POP_doing", UI_base)
local instance = nil

function POP_doing.open(msg)
	if not instance then
		instance = POP_doing.new(msg)

		display.getRunningScene():addChild(instance, LayerConfig.conn_alert)
	end
end

function POP_doing.close()
	if instance then
		instance:removeSelf()
	end
end

function POP_doing:ctor(msg)
	POP_doing.super.ctor(self, "pop_doing")

	self.msg = msg

	self:init()
end

function POP_doing:init()
	self:initUI()
	self:createLabelOnFlag("flag_msg", self.msg or "")
end

function POP_doing:initUI()
	local mask = self:getComponentByTag("mask")

	mask:toTouchable()
end

function POP_doing:onExit()
	instance = nil

	POP_doing.super.onExit(self)
end

return POP_doing
