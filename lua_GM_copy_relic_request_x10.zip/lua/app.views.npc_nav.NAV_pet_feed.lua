local NAV_base = import(".NAV_base")
local NAV_pet_feed = class("NAV_pet_feed", NAV_base)

function NAV_pet_feed.open(npc)
	local ui = NAV_pet_feed.new(npc)

	return ui
end

function NAV_pet_feed:ctor(npc)
	NAV_pet_feed.super.ctor(self, npc, "nav_pet_feed")
end

function NAV_pet_feed:init()
	NAV_pet_feed.super.init(self)
end

function NAV_pet_feed:onTap(index)
	NAV_pet_feed.super.onTap(self, index)

	if index == 1 then
		print("$$$ self.npc", self.npc.feedData)

		local data = self.npc.feedData

		if InfoHome.isSelf() then
			FRAME_pet_feed_feed.open(data.feedData.pos)
		else
			FRAME_pet_feed_feed.openVisit(data.feedData.pos, data)
		end
	end
end

return NAV_pet_feed
