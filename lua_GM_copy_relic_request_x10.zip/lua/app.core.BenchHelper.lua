local proto = import("..proto.proto")
local core = require("sproto.core")
local BenchHelper = {}

local function bin2hex(s)
	s = string.gsub(s, "(.)", function (x)
		return string.format("%02X ", string.byte(x))
	end)

	return s
end

local function writeFile(fileName, str)
	local path = cc.FileUtils:getInstance():getWritablePath() .. fileName

	if not io.exists(path) then
		io.writefile(path, str)
	else
		local file, err = io.open(path, "ab")

		if not err then
			file:write(str)
			file:close()
		end
	end
end

local sessionMap = {}

function BenchHelper.setSession(session, cmd, code, args)
	sessionMap[session] = {
		cmd = cmd,
		code = code,
		args = args
	}
end

function BenchHelper.init()
	writeFile("bench_package.txt", "----- bench start ----- " .. Time.showDate(Time.time()) .. "\n")
end

function BenchHelper.onSend(session, package)
	if sessionMap[session] then
		local cmd = sessionMap[session].cmd
		local code = sessionMap[session].code
		local args = sessionMap[session].args
		local hex = bin2hex(package)
		local str = "cmd:" .. cmd .. " msgId:" .. code .. " package:" .. hex .. "\n"

		writeFile("bench_package.txt", str)

		local str = dumpExport(args, "发包 " .. "cmd:" .. cmd .. " msgId:" .. code)

		writeFile("bench_request.txt", str)
	end
end

function BenchHelper.onResponse(session, data)
	if sessionMap[session] then
		local cmd = sessionMap[session].cmd
		local code = sessionMap[session].code
		local args = sessionMap[session].args
		local str = dumpExport(data, "返包 " .. "cmd:" .. cmd .. " msgId:" .. code)

		writeFile("bench_request.txt", str)

		sessionMap[session] = nil
	end
end

return BenchHelper
