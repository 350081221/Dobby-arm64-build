local InfoHero = {}
local STAR_TYPE = {
	PEAK = 1,
	NORMAL = 0
}
InfoHero.STAR_TYPE = STAR_TYPE
local rawData = nil
local heroDropLocked = false
local heroDropLockCache = {}

function InfoHero.init()
	Connection.listen("hero_sync", InfoHero.sync)
	Connection.listen("hero_sync_remove", InfoHero.syncRemove)
	Connection.listen("hero_add_exp", InfoHero.onAddExp)
	Connection.listen("hero_drop_random", InfoHero.onDropRandom)
end

app:addToAppEnterCall(InfoHero.init)

function InfoHero.clear()
	heroDropLocked = false
	heroDropLockCache = {}
end

function InfoHero.setDebugAttr(hero, attrTestID)
	if DEV_MODE then
		local hero_id = hero.info.id

		Cookie.set("debugAttrMap_" .. hero_id, attrTestID, true)
		hero:refreshBattleData()
	end
end

function InfoHero.getDebugAttr(hero_id)
	if DEV_MODE then
		local attrTestID = Cookie.get("debugAttrMap_" .. hero_id)

		if attrTestID then
			return CsvParser.getCsvData("attr_test", attrTestID), attrTestID
		end
	end
end

function InfoHero.clearDebugAttr(hero)
	local hero_id = hero.info.id

	Cookie.set("debugAttrMap_" .. hero_id, nil, true)
	hero:refreshBattleData()
end

function InfoHero.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			rawData = {}

			for i, data in ipairs(rcvData.list) do
				rawData[data.id] = data
			end

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("hero_query", callback)
end

function InfoHero.onAddExp(data)
	notify.dispatch("hero_add_exp", data)

	if data.pre_level < data.level then
		local heroInfo = InfoHero.getHero(data.id)

		TaHelper.taTrack("hero_levelup", {
			hero_id = data.id,
			after_level = data.level
		})
	end
end

function InfoHero.sync(data)
	local teamChanged = false
	local changedIdStack = {}

	for i, syncData in ipairs(data.list) do
		local id = syncData.id

		if not rawData[id] then
			rawData[id] = syncData

			if rawData[id].pos > 0 then
				teamChanged = true
			end
		else
			if rawData[id].pos > 0 then
				teamChanged = true
			end

			for k, v in pairs(syncData) do
				rawData[id][k] = v
			end

			if rawData[id].pos > 0 then
				teamChanged = true
			end
		end

		changedIdStack[id] = rawData[id]
	end

	ManagerInfo.dataChange("hero", changedIdStack)
end

function InfoHero.syncRemove(data)
	local teamChanged = false
	local changedIdStack = {}

	for i, id in ipairs(data.list) do
		if rawData[id] then
			changedIdStack[id] = rawData[id]

			if rawData[id].pos > 0 then
				teamChanged = true
			end

			rawData[id] = nil
		end
	end

	ManagerInfo.dataChange("hero", changedIdStack)
end

function InfoHero.onDropRandom(data)
	local heroInfo = InfoHero.getHero(data.id)

	TaHelper.taTrack("recruit_hero", {
		recruit_type = 2,
		hero_id = heroInfo.id
	})

	if heroDropLocked then
		table.insert(heroDropLockCache, data.id)
	else
		local heroInfo = InfoHero.getHero(data.id)

		FRAME_hero_drop.open(heroInfo)
	end
end

function InfoHero.setHeroDropLocked(locked)
	heroDropLocked = locked

	if not locked then
		local cache = {}

		for i, v in ipairs(heroDropLockCache) do
			table.insert(cache, v)
		end

		heroDropLockCache = {}

		if #cache > 0 then
			local showNext = nil

			function showNext()
				if #cache > 0 then
					local heroID = table.remove(cache, 1)
					local heroInfo = InfoHero.getHero(heroID)

					FRAME_hero_drop.open(heroInfo, nil, showNext)
				end
			end

			showNext()
		end
	end
end

function InfoHero.getMaxLevel()
	local maxLevel = 0

	for id, heroInfo in pairs(rawData) do
		maxLevel = math.max(maxLevel, heroInfo.level)
	end

	return maxLevel
end

function InfoHero.getMaxScore()
	local maxScore = 0

	for id, heroInfo in pairs(rawData) do
		maxScore = math.max(maxScore, InfoHero.getScore(heroInfo))
	end

	return maxScore
end

function InfoHero.getTeam()
	if InfoDungeon.inDungeon() then
		local stageType, stageID, stageParams = InfoDungeon.getStage()

		if stageType == InfoDungeon.STAGE_TYPE.UNION_SOLO then
			local team = {}
			local heroInfo = InfoHero.getHero(stageParams.hero_id)

			table.insert(team, heroInfo)

			return team
		end
	end

	if InfoDungeon.isFixedTeam() then
		local heros = StageUtils.getFixedHero()

		return heros
	end

	local team = {}

	for id, heroInfo in pairs(rawData) do
		if heroInfo.pos ~= 0 then
			table.insert(team, heroInfo)
		end
	end

	table.sort(team, function (a, b)
		return a.pos < b.pos
	end)

	return team
end

function InfoHero.getTeamInPos()
	if InfoDungeon.inDungeon() then
		local stageType, stageID, stageParams = InfoDungeon.getStage()

		if stageType == InfoDungeon.STAGE_TYPE.UNION_SOLO then
			local team = {}
			local heroInfo = InfoHero.getHero(stageParams.hero_id)
			team[1] = heroInfo

			return team
		end
	end

	if InfoDungeon.isFixedTeam() then
		local heros = StageUtils.getFixedHero()

		return heros
	end

	local team = {}

	for id, heroInfo in pairs(rawData) do
		if heroInfo.pos ~= 0 then
			team[heroInfo.pos] = heroInfo
		end
	end

	return team
end

function InfoHero.countTeam()
	local team = InfoHero.getTeam()

	return #team
end

function InfoHero.count()
	local count = 0

	for id, heroInfo in pairs(rawData) do
		count = count + 1
	end

	local buildingCSV = InfoBuilding.getBuildingData(InfoBuilding.TAG.TAVERN)

	return count, buildingCSV.value2
end

function InfoHero.getTeamMainLevel()
	local teamCount = 0
	local teamLevelTotal = 0

	for id, heroInfo in pairs(rawData) do
		if heroInfo.pos > 0 then
			teamCount = teamCount + 1
			teamLevelTotal = teamLevelTotal + heroInfo.level
		end
	end

	local mainLevel = 0

	if teamCount > 0 then
		mainLevel = math.floor(teamLevelTotal / teamCount)
	end

	return mainLevel
end

function InfoHero.transfer(id, enc, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			TeamManager.refreshTeam()

			local heroInfo = InfoHero.getHero(id)
			local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)

			TaHelper.taTrack("hero_starup", {
				hero_id = id,
				after_level = heroCSV.job_level
			})

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("hero_transfer", {
		id = id,
		enc = enc
	}, callback)
end

function InfoHero.reborn(id, enc_list, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			TeamManager.refreshTeam()
			TaHelper.taTrack("hero_reborn", {
				hero_id = id
			})

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("hero_reborn", {
		id = id,
		enc_list = enc_list
	}, callback)
end

function InfoHero.dustSelect(id, enc_list, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ hero_dust_skill")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("hero_dust_skill", {
		id = id,
		enc_list = enc_list
	}, callback)
end

function InfoHero.getTransferList(filterFunc, sortFunc)
	local teamList = {}

	for id, heroInfo in pairs(rawData) do
		if not filterFunc or filterFunc(heroInfo) then
			local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)

			if heroCSV.lv_max <= heroInfo.level and not empty(heroCSV.next_job) then
				table.insert(teamList, heroInfo)
			end
		end
	end

	table.sort(teamList, sortFunc or function (heroInfoA, heroInfoB)
		local posA = heroInfoA.pos
		local posB = heroInfoB.pos

		if posA == 0 and posB == 0 then
			if heroInfoA.level == heroInfoB.level then
				return heroInfoA.id < heroInfoB.id
			else
				return heroInfoB.level < heroInfoA.level
			end
		elseif posA ~= 0 and posB ~= 0 then
			return posA < posB
		else
			return posB < posA
		end
	end)

	return teamList
end

function InfoHero.setAutoSkill(id, isAuto, onSuccess, onFailure)
	local is_auto = isAuto and 1 or 0

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			rawData[id].auto_skill = is_auto

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("hero_auto_skill", {
		id = id,
		is_auto = is_auto
	}, callback)
end

function InfoHero.getAll(filterFunc, sortFunc)
	local teamList = {}

	for id, heroInfo in pairs(rawData) do
		if not filterFunc or filterFunc(heroInfo) then
			table.insert(teamList, heroInfo)
		end
	end

	table.sort(teamList, sortFunc or function (heroInfoA, heroInfoB)
		local posA = heroInfoA.pos
		local posB = heroInfoB.pos

		if posA == 0 and posB == 0 then
			if heroInfoA.level == heroInfoB.level then
				if heroInfoA.quality == heroInfoB.quality then
					return heroInfoA.id < heroInfoB.id
				else
					return heroInfoB.quality < heroInfoA.quality
				end
			else
				return heroInfoB.level < heroInfoA.level
			end
		elseif posA ~= 0 and posB ~= 0 then
			return posA < posB
		else
			return posB < posA
		end
	end)

	return teamList
end

function InfoHero.hasHero()
	return rawData ~= nil and table.nums(rawData) > 0
end

function InfoHero.getHero(id)
	if not id and global.player then
		id = global.player.info.id
	end

	id = id or InfoHero.getTeam()[1]

	return rawData[id]
end

function InfoHero.findGuideHero(class, quality, inTeam)
	for id, heroInfo in pairs(rawData) do
		local heroData = CsvParser.getCsvData("hero", heroInfo.base_id)

		if heroData.class == class and heroInfo.quality == quality then
			if inTeam then
				if heroInfo.pos > 0 then
					return heroInfo
				end
			elseif heroInfo.pos == 0 then
				return heroInfo
			end
		end
	end
end

function InfoHero.getHeroByPos(pos)
	for id, heroInfo in pairs(rawData) do
		if heroInfo.pos == pos then
			return heroInfo
		end
	end
end

function InfoHero.dismiss(id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ hero_dismiss")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("hero_dismiss", {
		id = id
	}, callback)
end

function InfoHero.setName(id, name, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ hero_set_name")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("hero_set_name", {
		id = id,
		name = name
	}, callback)
end

function InfoHero.getName(heroInfo)
	if InfoHero.isTrueSp(heroInfo) then
		local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)

		return Localization.getSpHeroName(heroCSV.sp_id)
	else
		return heroInfo.name
	end
end

function InfoHero.washPreview(id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("hero_wash_preview", {
		id = id
	}, callback)
end

function InfoHero.washConfirm(id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("hero_wash_confirm", {
		id = id
	}, callback)
end

function InfoHero.getCardTotal(heroInfo)
	local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)

	return heroCSV.equip_card
end

function InfoHero.getCardOpenJobLevel(heroInfo, pos)
	local baseID = InfoHero.getBaseJob(heroInfo.base_id)
	local heroCSV = CsvParser.getCsvData("hero", baseID)

	while heroCSV do
		if pos <= heroCSV.equip_card then
			return heroCSV.job_level
		else
			heroCSV = CsvParser.getCsvData("hero", heroCSV.next_job, nil, true)
		end
	end
end

function InfoHero.getFreeCardPos(heroInfo)
	local cardTotal = InfoHero.getCardTotal(heroInfo)

	for pos = 1, cardTotal do
		local cardInfo = InfoCard.getCardOnHero(heroID, i)

		if not cardInfo then
			return pos
		end
	end
end

function InfoHero.getQualityColor(quality)
	local qualityData = CsvParser.getCsvData("hero_quality", quality)

	if qualityData and not empty(qualityData.color) then
		local colorArr = string.split(qualityData.color, ",")

		return cc.c4b(tonumber(colorArr[1]), tonumber(colorArr[2]), tonumber(colorArr[3]), 255)
	end

	return cc.c4b(255, 255, 255, 255)
end

function InfoHero.getQualityColorStr(quality)
	local qualityData = CsvParser.getCsvData("hero_quality", quality)

	return qualityData.color
end

function InfoHero.getQualityName(quality)
	local qualityData = CsvParser.getCsvData("hero_quality", quality)

	return qualityData.name
end

function InfoHero.getHpColor(percent)
	percent = math.max(0, math.min(percent, 1))
	local color = nil

	if percent > 0.5 then
		color = cc.c4b(255 * (1 - (percent - 0.5) / 0.5), 255, 0, 255)
	else
		color = cc.c4b(255, 255 * percent / 0.5, 0, 255)
	end

	return color
end

function InfoHero.getAttrRatio(heroInfo, attr)
	local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)

	return SheetUtil.getLinearNumber(heroCSV[attr .. "_ratio"], heroInfo[attr .. "_seed"] / 65536)
end

function InfoHero.getAttrRank(heroInfo, attr)
	local qualityList = CsvParser.getCsvList("hero_quality")
	local percent = heroInfo[attr .. "_seed"] / 65536
	local attrRank = nil

	for i, v in ipairs(qualityList) do
		if percent <= v.growth_value then
			attrRank = v

			break
		end
	end

	attrRank = attrRank or qualityList[#qualityList]
	local name = attrRank.name

	if not InfoFunction.checkFuncOpen(10200) then
		name = ""
	end

	return name, InfoHero.getQualityColor(attrRank.id)
end

local scoreBuff = nil

function InfoHero.buffScoreStart()
	scoreBuff = {}
end

function InfoHero.buffScoreOver()
	scoreBuff = nil
end

function InfoHero.getScore(heroInfo, customPetAttr, noDust)
	if scoreBuff and scoreBuff[heroInfo.id] then
		return scoreBuff[heroInfo.id]
	end

	local attr = CombatAttr.getHeroAttr(heroInfo, nil, , customPetAttr, nil, noDust)

	CombatAttr.finalize(attr, nil, true)

	local attr_raw = CsvParser.getCsvRaw("attr")
	local addTotal = 0
	local multiTotal = 0

	for k, v in pairs(attr_raw) do
		if attr[k] then
			if v.ability_value1 ~= 0 then
				addTotal = addTotal + attr[k] * v.ability_value1
			end

			if v.ability_value2 ~= 0 then
				multiTotal = multiTotal + attr[k] * v.ability_value2
			end
		end
	end

	local score = math.floor(addTotal * (1 + multiTotal))

	if scoreBuff then
		scoreBuff[heroInfo.id] = score
	end

	return score
end

function InfoHero.getScoreAll()
	if not rawData then
		return 0
	end

	local score = 0

	for pos = 1, GameConfig.hero_team_num do
		local heroInfo = InfoHero.getHeroByPos(pos)

		if heroInfo then
			score = score + InfoHero.getScore(heroInfo)
		end
	end

	return score
end

function InfoHero.getTeamScore()
	if not rawData then
		return 0
	end

	local heroScore = InfoHero.getScoreAll()
	local petScore = InfoPet.getScoreAll()
	local pet_ability_ratio = CsvParser.getCsvData("config", "pet_ability_ratio").value
	local score = heroScore + math.floor(petScore * pet_ability_ratio)

	return score
end

function InfoHero.getTeamMax()
	return 3
end

function InfoHero.getExpTotal(level, exp)
	local startLevel = 1
	local expTotal = exp

	while startLevel < level do
		local baseCSV = CsvParser.getCsvData("hero_base_num", startLevel)

		if not baseCSV then
			break
		end

		local expUpg = baseCSV.exp
		expTotal = expTotal + expUpg
		startLevel = startLevel + 1
	end

	return expTotal
end

function InfoHero.getTotalLevel(exp)
	local level = 1
	local expTotal = exp

	while true do
		local baseCSV = CsvParser.getCsvData("hero_base_num", level)

		if not baseCSV then
			break
		end

		local expUpg = baseCSV.exp

		if expUpg <= expTotal then
			level = level + 1
			expTotal = expTotal - expUpg
		else
			break
		end
	end

	return expTotal, level
end

function InfoHero.getExp(heroInfo)
	local expUpg = CsvParser.getCsvData("hero_base_num", heroInfo.level).exp
	local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)
	local level = heroInfo.level
	local buildingCSV = InfoBuilding.getBuildingData(InfoBuilding.TAG.TAVERN)
	local maxLevel = math.min(heroCSV.lv_max, buildingCSV.value1)
	local jobMaxLevel = heroCSV.lv_max
	local buildingMax = buildingCSV.value1
	local displayLevel = level

	if heroCSV.job_level > 0 then
		local preCSV = CsvParser.getFilteredData("hero", {
			next_job = heroInfo.base_id
		})
		displayLevel = level - (preCSV.lv_max - 1)
		jobMaxLevel = jobMaxLevel + 1 - preCSV.lv_max
		buildingMax = buildingMax + 1 - preCSV.lv_max
	end

	local displayMaxLevel = nil

	if InfoDungeon.isFixedTeam() then
		displayMaxLevel = jobMaxLevel
	else
		displayMaxLevel = math.min(jobMaxLevel, buildingMax)
	end

	if InfoHero.isPeak(heroInfo) then
		local peakCSV, perkMaxLevel = InfoHero.getPeakCSV(heroInfo.level)
		displayLevel = peakCSV.level
		displayMaxLevel = perkMaxLevel
	end

	return heroInfo.exp, expUpg, level, maxLevel, displayLevel, displayMaxLevel, jobMaxLevel
end

function InfoHero.getFinalLevel(heroInfo, level, isUpper)
	local heroCSV = CsvParser.getCsvData("hero", InfoHero.getBaseJob(heroInfo.base_id))
	local jobLevel = heroCSV.job_level
	local displayLevel = level

	while heroCSV do
		if isUpper then
			if level < heroCSV.lv_max then
				break
			end
		elseif level <= heroCSV.lv_max then
			break
		end

		displayLevel = level - heroCSV.lv_max + 1
		jobLevel = heroCSV.job_level
		heroCSV = CsvParser.getCsvData("hero", heroCSV.next_job, nil, true)

		if not heroCSV then
			break
		end
	end

	return displayLevel, jobLevel + 1
end

function InfoHero.getJoblevel(heroInfo, level)
	local heroCSV = CsvParser.getCsvData("hero", InfoHero.getBaseJob(heroInfo.base_id))
	local jobLevel = heroCSV.job_level

	while heroCSV do
		if level < heroCSV.lv_max then
			break
		end

		if not empty(heroCSV.next_job) then
			jobLevel = heroCSV.job_level + 1
			heroCSV = CsvParser.getCsvData("hero", heroCSV.next_job)
		else
			break
		end
	end

	return jobLevel
end

function InfoHero.getExpAdded(startLevel, startExp, exp)
	local expLeft = startExp + exp
	local level = startLevel
	local expUpg = CsvParser.getCsvData("hero_base_num", level).exp
	local max_level = math.min(GameConfig.hero_peak_level, CsvParser.getMaxID("hero_base_num"))

	while expUpg <= expLeft do
		expLeft = expLeft - expUpg
		level = level + 1

		if max_level <= level then
			break
		end

		expUpg = CsvParser.getCsvData("hero_base_num", level).exp
	end

	return level, expLeft, expUpg
end

function InfoHero.getExpDiff(startLevel, startExp, endLevel, endExp)
	local level = startLevel
	local exp = startExp
	local diffExp = 0

	while level < endLevel do
		local expUpg = CsvParser.getCsvData("hero_base_num", level).exp
		diffExp = diffExp + expUpg - exp
		exp = 0
		level = level + 1
	end

	diffExp = diffExp + endExp - exp

	return diffExp
end

function InfoHero.getSkillByPos(heroInfo, pos)
	return InfoHero.getSkill(heroInfo).id
end

function InfoHero.getActiveSkill(heroInfo)
	return InfoHero.getSkill(heroInfo)
end

function InfoHero.getSkill(heroInfo)
	local heroData = CsvParser.getCsvData("hero", heroInfo.base_id)
	local skillID = heroData.skill_id

	for i = 1, heroData.job_level do
		local enc = heroInfo["skill_enc_" .. i]

		if empty(enc) then
			enc = 1
		end

		skillID = skillID + math.pow(10, i - 1) * enc
	end

	return {
		id = skillID
	}
end

function InfoHero.getSwitchSkill(heroInfo, index)
	local heroData = CsvParser.getCsvData("hero", heroInfo.base_id)
	local skillID = heroData["switch_skill_" .. index]

	return {
		id = skillID
	}
end

function InfoHero.autoOff()
	local posMap = {}

	for id, heroInfo in pairs(rawData) do
		if heroInfo.pos > 0 then
			if not posMap[heroInfo.pos] then
				posMap[heroInfo.pos] = {}
			end

			table.insert(posMap[heroInfo.pos], heroInfo)
		end
	end

	local offArr = {}

	for pos, arr in pairs(posMap) do
		if #arr > 1 then
			local _arr = {}

			for i, heroInfo in ipairs(arr) do
				table.insert(_arr, {
					id = heroInfo.id,
					score = InfoHero.getScore(heroInfo)
				})
			end

			table.sort(_arr, function (a, b)
				return b.score < a.score
			end)

			for i = 2, #_arr do
				table.insert(offArr, {
					pos = 0,
					id = _arr[i].id
				})
			end
		end
	end

	if #offArr > 0 then
		dump(offArr, "$$$ InfoHero.autoOff")
		InfoHero.setposQueue(offArr)
	end
end

function InfoHero.setpos(id, pos, onSuccess, onFailure)
	InfoHero.setposQueue({
		{
			id = id,
			pos = pos
		}
	}, onSuccess, onFailure)
end

function InfoHero.setposQueue(queue, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			TeamManager.refreshTeam()

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("hero_setpos", {
		queue = queue
	}, callback)
end

function InfoHero.getIDBybaseID(baseID, isBaseJob)
	local petID = nil

	for id, heroInfo in pairs(rawData) do
		local trueBaseID = heroInfo.base_id

		if isBaseJob then
			trueBaseID = InfoHero.getBaseJob(trueBaseID)
		end

		if trueBaseID == baseID then
			return id
		end
	end
end

function InfoHero.join(baseID, onSuccess, onFailure)
	local petID = InfoHero.getIDBybaseID(baseID)

	if not petID then
		return
	end

	local pos = InfoHero.getFreePos()

	if pos then
		InfoHero.setpos(petID, pos, onSuccess, onFailure)
	end
end

function InfoHero.switchPos(id, pos, onSuccess, onFailure)
	local prePos = rawData[id].pos
	local queue = {
		{
			id = id,
			pos = pos
		}
	}
	local posMap = InfoHero.getPosMap()

	if posMap[pos] then
		table.insert(queue, {
			id = posMap[pos],
			pos = prePos
		})
	end

	InfoHero.setposQueue(queue, onSuccess, onFailure)
end

function InfoHero.solidPos(onSuccess, onFailure)
	local maxPos = 0
	local team = {}

	for id, heroInfo in pairs(rawData) do
		if heroInfo.pos ~= 0 then
			team[heroInfo.pos] = heroInfo
			maxPos = math.max(maxPos, heroInfo.pos)
		end
	end

	local emptyCount = 0
	local queue = {}

	for pos = 1, maxPos do
		if team[pos] then
			if emptyCount > 0 then
				table.insert(queue, {
					id = team[pos].id,
					pos = pos - emptyCount
				})
			end
		else
			emptyCount = emptyCount + 1
		end
	end

	if not empty(queue) then
		InfoHero.setposQueue(queue, onSuccess, onFailure)
	elseif onSuccess then
		onSuccess()
	end
end

function InfoHero.getPosMap()
	local posMap = {}

	for id, heroInfo in pairs(rawData) do
		if heroInfo.pos ~= 0 then
			posMap[heroInfo.pos] = heroInfo.id
		end
	end

	return posMap
end

function InfoHero.getQuality(heroInfo)
	return heroInfo.quality
end

function InfoHero.getJobTree(baseID)
	local preHeroCache = CacheData.get("InfoHero_preHeroCache")

	if not preHeroCache then
		preHeroCache = {}
		local hero_raw = CsvParser.getCsvRaw("hero")

		for k, v in pairs(hero_raw) do
			if not empty(v.next_job) then
				preHeroCache[v.next_job] = v.id
			end
		end

		CacheData.set("InfoHero_preHeroCache", preHeroCache)
	end

	local arr = {
		baseID
	}

	while preHeroCache[baseID] and preHeroCache[baseID] ~= baseID do
		baseID = preHeroCache[baseID]

		table.insert(arr, 1, baseID)
	end

	return arr
end

function InfoHero.getBaseJob(baseID)
	local baseID = InfoHero.getJobTree(baseID)[1]

	return baseID
end

function InfoHero.getRebornCost(heroInfo)
	local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)
	local rebornCSV = CsvParser.getCsvData("hero_reborn", heroCSV.job_level)

	return SheetUtil.getColumnList(rebornCSV, {
		"cost_id_",
		"cost_num_"
	}, {
		"base_id",
		"num"
	})
end

function InfoHero.isSp(heroInfo)
	local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)

	if not empty(heroCSV.sp_id) then
		local spCSV = CsvParser.getCsvData("hero_sp", heroCSV.sp_id)

		return spCSV ~= nil
	end

	return false
end

function InfoHero.isTrueSp(heroInfo)
	local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)

	if not empty(heroCSV.sp_id) then
		local spCSV = CsvParser.getCsvData("hero_sp", heroCSV.sp_id)

		return spCSV.is_normal == 0
	end

	return false
end

function InfoHero.getSpStoryList(heroInfo)
	local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)
	local csvList = CsvParser.getCsvList("hero_story", "id", {
		sp_id = heroCSV.sp_id
	})

	return csvList
end

function InfoHero.getPreJob(base_id)
	local preJobCache = CacheData.get("InfoHero_preJobCache")

	if not preJobCache then
		preJobCache = {}
		local csvRaw = CsvParser.getCsvRaw("hero")

		for k, csv in pairs(csvRaw) do
			if not empty(csv.next_job) then
				preJobCache[csv.next_job] = csv.id
			end
		end

		CacheData.set("InfoHero_preJobCache", preJobCache)
	end

	return preJobCache[base_id]
end

function InfoHero.getJobLevelCSV(base_id, jobLevel)
	local csv = CsvParser.getCsvData("hero", base_id)

	while jobLevel < csv.job_level do
		csv = CsvParser.getCsvData("hero", InfoHero.getPreJob(csv.id))
	end

	while csv.job_level < jobLevel do
		csv = CsvParser.getCsvData("hero", csv.next_job)
	end

	return csv
end

function InfoHero.exchange(id_low, id_high, enc_list, onSuccess, onFailure)
	local is_auto = isAuto and 1 or 0

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("hero_exchange", {
		id_low = id_low,
		id_high = id_high,
		enc_list = enc_list
	}, callback)
end

function InfoHero.getTopLevelSP(sp_id)
	local bestLevel, bestInfo = nil

	for id, heroInfo in pairs(rawData) do
		local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)

		if not empty(heroCSV.sp_id) and heroCSV.sp_id == sp_id and (not bestLevel or bestLevel < heroInfo.level) then
			bestLevel = heroInfo.level
			bestInfo = heroInfo
		end
	end

	return bestInfo
end

function InfoHero.getSkillDescList(skillID, heroInfo)
	local arr = {}
	local job_level = 0

	if heroInfo then
		local heroData = CsvParser.getCsvData("hero", heroInfo.base_id)
		job_level = heroData.job_level
	end

	local skillCSV = CsvParser.getCsvData("skill", skillID)
	local baseID = skillCSV.base_id
	skillCSV = CsvParser.getCsvData("skill", baseID)

	table.insert(arr, {
		enabled = true,
		desc = skillCSV.desc
	})

	local skillLevel = 1

	while true do
		if skillLevel <= job_level then
			local tempID = baseID

			for i = 1, skillLevel do
				local enc = heroInfo["skill_enc_" .. i]

				if empty(enc) then
					enc = 1
				end

				tempID = tempID + math.pow(10, i - 1) * enc
			end

			skillCSV = CsvParser.getCsvData("skill", tempID)

			table.insert(arr, {
				enabled = true,
				desc = skillCSV.desc
			})
		else
			local tempID = baseID

			for i = 1, skillLevel - 1 do
				tempID = tempID + math.pow(10, i - 1)
			end

			local tempID1 = tempID + math.pow(10, skillLevel - 1) * 1
			local skillCSV1 = CsvParser.getCsvData("skill", tempID1, nil, true)

			if not skillCSV1 then
				break
			end

			local tempID2 = tempID + math.pow(10, skillLevel - 1) * 2
			local skillCSV2 = CsvParser.getCsvData("skill", tempID2, nil, true)

			if skillCSV2 then
				local str = Localization.getSrcText("分支{1}：{2}")
				local desc = StringUtil.replace(str, 1, skillCSV1.desc_advance) .. "\n" .. StringUtil.replace(str, 2, skillCSV2.desc_advance)

				table.insert(arr, {
					enabled = false,
					desc = desc
				})
			else
				table.insert(arr, {
					enabled = false,
					desc = skillCSV1.desc
				})
			end
		end

		skillLevel = skillLevel + 1
	end

	return arr
end

function InfoHero.setAffix(id, affix_id, item_id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ hero_set_affix")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("hero_set_affix", {
		id = id,
		affix_id = affix_id,
		item_id = item_id
	}, callback)
end

function InfoHero.getAffixList(heroInfo)
	local base_id = InfoHero.getBaseJob(heroInfo.base_id)
	local heroCSV = CsvParser.getCsvData("hero", base_id)

	if not empty(heroCSV.sp_id) then
		local spCSV = CsvParser.getCsvData("hero_sp", heroCSV.sp_id)

		if not empty(spCSV.random_hero) then
			local random_hero_csv = CsvParser.getCsvData("random_hero", spCSV.random_hero)
			local affixStr = random_hero_csv["affix_" .. heroInfo.gender]

			if not empty(affixStr) then
				local affixArr = SheetUtil.getNumberArr(affixStr)

				return affixArr
			end
		end
	end

	local csvList = CsvParser.getCsvList("hero_affix")
	local arr = {}

	for i, csv in ipairs(csvList) do
		if not empty(csv.rare) then
			local baseIDCheck = false
			local genderCheck = false

			if empty(csv.base_id) then
				baseIDCheck = true
			else
				local baseIdArr = string.split(csv.base_id, ",")

				for i, v in ipairs(baseIdArr) do
					if tonumber(v) == base_id then
						baseIDCheck = true

						break
					end
				end
			end

			if baseIDCheck then
				if empty(csv.gender) then
					genderCheck = true
				else
					local genderArr = string.split(csv.gender, ",")

					for i, v in ipairs(genderArr) do
						if tonumber(v) == heroInfo.gender then
							genderCheck = true

							break
						end
					end
				end
			end

			if baseIDCheck and genderCheck then
				table.insert(arr, csv.id)
			end
		end
	end

	table.sort(arr, function (a, b)
		local csvA = CsvParser.getCsvData("hero_affix", a)
		local csvB = CsvParser.getCsvData("hero_affix", b)
		local scoreA = 0

		if not empty(csvA.base_id) then
			scoreA = scoreA + 1
		end

		local scoreB = 0

		if not empty(csvB.base_id) then
			scoreB = scoreB + 1
		end

		if scoreA == scoreB then
			return a < b
		else
			return scoreB < scoreA
		end
	end)

	return arr
end

function InfoHero.setAvatarHide(id, pos, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if OnlineCamp.inRoom() then
				OnlineCamp.updateAppear(id)
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("hero_avatar_hide", {
		id = id,
		pos = pos
	}, callback)
end

function InfoHero.getAvatarHideMap(heroInfo)
	local avatarHideMap = {}

	if not empty(heroInfo.avatar_hide) then
		local arr = json.decode(heroInfo.avatar_hide)

		if arr then
			for i, v in ipairs(arr) do
				if GameConfig.avatar_hide_pos[v] then
					avatarHideMap[v] = true
				end
			end
		end
	end

	return avatarHideMap
end

function InfoHero.lock(id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("hero_lock", {
		hero_id = id
	}, callback)
end

function InfoHero.checkExpFull(id)
	local heroInfo = rawData[id]

	if heroInfo then
		local level = heroInfo.level
		local baseID = heroInfo.base_id
		local heroCSV = CsvParser.getCsvData("hero", baseID)
		local buildingCSV = InfoBuilding.getBuildingData(InfoBuilding.TAG.TAVERN)
		local max_level = math.min(heroCSV.lv_max, buildingCSV.value1)

		if max_level <= level then
			return true
		end
	end
end

function InfoHero.isPeakReady(heroInfo)
	return GameConfig.hero_peak_level <= heroInfo.level
end

function InfoHero.isPeak(heroInfo)
	return GameConfig.hero_peak_level < heroInfo.level
end

function InfoHero.peakMaxLevel()
	local maxID = CsvParser.getMaxID("hero_peak_level")
	local csv = CsvParser.getCsvData("hero_peak_level", maxID)

	return csv.hero_level
end

local perkLevelCache, perkLevelPointCache, perkIdPointCache, perkPointIdCache = nil

function InfoHero.getPerkLevelCache()
	if not perkLevelCache then
		perkLevelCache = {}
		perkLevelPointCache = {}
		perkIdPointCache = {}
		perkPointIdCache = {}
		local csvList = CsvParser.getCsvList("hero_peak_perk")
		local levelMap = {}
		local points = 0

		for i, csv in ipairs(csvList) do
			if not levelMap[csv.hero_level] then
				levelMap[csv.hero_level] = true
				points = points + 1

				table.insert(perkLevelCache, {
					level = csv.hero_level,
					points = points
				})

				perkLevelPointCache[csv.hero_level] = points
			end

			perkIdPointCache[csv.id] = points
			perkPointIdCache[points] = perkPointIdCache[points] or {}

			table.insert(perkPointIdCache[points], csv.id)
		end
	end

	return perkLevelCache, perkLevelPointCache, perkIdPointCache, perkPointIdCache
end

local peakHeroLevelCache, peakStarMaxLevelCache = nil

function InfoHero.getPeakCSV(heroLevel)
	if not peakHeroLevelCache then
		peakHeroLevelCache = {}
		peakStarMaxLevelCache = {}
		local csvList = CsvParser.getCsvList("hero_peak_level")

		for i, csv in ipairs(csvList) do
			peakHeroLevelCache[csv.hero_level] = csv.id
			peakStarMaxLevelCache[csv.star] = csv.level
		end
	end

	if peakHeroLevelCache[heroLevel] then
		local csv = CsvParser.getCsvData("hero_peak_level", peakHeroLevelCache[heroLevel])

		return csv, peakStarMaxLevelCache[csv.star]
	end
end

function InfoHero.getStar(heroInfo)
	if InfoHero.isPeak(heroInfo) then
		local peakCSV = InfoHero.getPeakCSV(heroInfo.level)

		return STAR_TYPE.PEAK, peakCSV.star
	else
		local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)
		local starNum = heroCSV.job_level + 1

		return STAR_TYPE.NORMAL, starNum
	end
end

function InfoHero.getPerkPoints(heroInfo)
	local perkLevelCache, perkLevelPointCache, perkIdPointCache, perkPointIdCache = InfoHero.getPerkLevelCache()
	local perkMax = 0
	local peakCSV = InfoHero.getPeakCSV(heroInfo.level)

	if peakCSV then
		for i, v in ipairs(perkLevelCache) do
			if v.level <= peakCSV.id then
				perkMax = v.points
			else
				break
			end
		end
	end

	local perkList = InfoHero.getPerkList(heroInfo)
	local perkNum = 0

	for i, v in ipairs(perkList) do
		if not empty(v.id) then
			perkNum = perkNum + 1
		end
	end

	local perkLeft = math.max(0, perkMax - perkNum)

	return perkLeft, perkMax
end

function InfoHero.getPerkList(heroInfo)
	local perkLevelCache, perkLevelPointCache, perkIdPointCache, perkPointIdCache = InfoHero.getPerkLevelCache()
	local perkMap = {}

	if not empty(heroInfo.perks) then
		local arr = string.split(heroInfo.perks, ",")

		for i, v in ipairs(arr) do
			local id = tonumber(v)

			if id then
				local points = perkIdPointCache[id]
				perkMap[points] = id
			end
		end
	end

	local perkArr = {}

	for i, v in ipairs(perkLevelCache) do
		table.insert(perkArr, {
			points = v.points,
			level = v.level,
			id = perkMap[v.points] or 0,
			ids = perkPointIdCache[v.points]
		})
	end

	return perkArr
end

function InfoHero.getSigilSet(heroInfo, isDisplay)
	local heroLevel = heroInfo.level

	if isDisplay and not InfoHero.isPeak(heroInfo) then
		local displayLevel, star = InfoHero.getFinalLevel(heroInfo, heroInfo.level, true)
		local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)

		if heroCSV.job_level < star then
			heroLevel = heroLevel - 1
		end
	end

	local csvList = CsvParser.getCsvList("sigil_set")
	local setCsv = nil

	for i, csv in ipairs(csvList) do
		if csv.hero_level <= heroLevel then
			setCsv = csv
		else
			break
		end
	end

	return setCsv
end

function InfoHero.peakUp(id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("hero_peak_up", {
		hero_id = id
	}, callback)
end

function InfoHero.perkSelect(id, perkID, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("hero_perk_select", {
		hero_id = id,
		perk_id = perkID
	}, callback)
end

function InfoHero.setSigilColor(id, pos, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "hero_sigil_color")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("hero_sigil_color", {
		hero_id = id,
		pos = pos
	}, callback)
end

function InfoHero.isArtifactReady(heroInfo)
	local artifact_open_level = CsvParser.getCsvData("config", "artifact_open_level").value
	local displayLevel, openJobLevel = InfoHero.getFinalLevel(heroInfo, artifact_open_level, true)
	local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)

	return openJobLevel <= heroCSV.job_level, openJobLevel
end

return InfoHero
