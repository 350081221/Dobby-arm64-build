local Log = {}

local function makeLog(isPrint, isWrite, tag, ...)
	if isPrint then
		print(tag, ...)
	end
end

function Log.verbose(...)
	makeLog(true, false, "[verbose]", ...)
end

function Log.debug(...)
	makeLog(true, false, "[* debug]", ...)

	if DEV_MODE or device.platform == "windows" then
		Console.log("[debug]", ...)
	end
end

function Log.warn(...)
	makeLog(true, false, "[*** warn]", ...)
end

function Log.print(...)
	makeLog(true, false, ...)

	if DEV_MODE or device.platform == "windows" then
		Console.log(...)
	end
end

function Log.startMeter(name)
	local now = socket.gettime()
	local obj = {
		meterStartTime = now,
		meterCurrentTime = now
	}

	function obj.markMeter(markName)
		local now = socket.gettime()

		makeLog(true, false, "[meter]" .. name .. "-" .. markName, "step:" .. now - obj.meterCurrentTime .. " total:" .. now - obj.meterStartTime)

		obj.meterCurrentTime = now
	end

	return obj
end

return Log
