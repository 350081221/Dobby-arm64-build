local Style = {
	blue = cc.c4b(28, 127, 192, 255),
	green = cc.c4b(0, 219, 65, 255),
	deepGreen = cc.c4b(27, 100, 40, 255),
	yellow = cc.c4b(248, 228, 0, 255),
	orange = cc.c4b(255, 151, 15, 255),
	gold = cc.c4b(254, 174, 14, 255),
	red = cc.c4b(220, 0, 0, 255),
	purple = cc.c4b(182, 29, 162, 255),
	white = cc.c4b(255, 255, 255, 255),
	black = cc.c4b(0, 0, 0, 255),
	nearBlack = cc.c4b(44, 40, 39, 255),
	pureRed = cc.c4b(255, 0, 0, 255),
	weakRed = cc.c4b(255, 118, 118, 255),
	deepBlue = cc.c4b(37, 66, 119, 255),
	mana = cc.c4b(106, 172, 239, 255),
	manaCost = cc.c4b(71, 140, 210, 255),
	colorDisabled = cc.c4b(192, 192, 192, 255),
	golden = cc.c4b(238, 199, 111, 255),
	goldenStr = "238,199,111",
	gray = cc.c4b(128, 128, 128, 255),
	enableColor = cc.c4b(146, 172, 71, 255),
	disableColor = cc.c4b(185, 57, 57, 255),
	darkColor = cc.c4b(43, 21, 0, 255)
}
Style.darkStyle = {
	color = Style.darkColor,
	outlineColor = cc.c4b(226, 221, 190, 255)
}
Style.lightColor = cc.c4b(230, 223, 207, 255)
Style.lightStyle = {
	color = Style.lightColor,
	outlineColor = cc.c4b(40, 37, 22, 255)
}
Style.redColor = cc.c4b(157, 21, 21, 255)
Style.bar1 = cc.c3b(255, 168, 0)
Style.font1 = cc.c4b(154, 136, 114, 255)
Style.font2 = cc.c4b(255, 199, 132, 255)
Style.font3 = cc.c4b(247, 212, 188, 255)
Style.fontMagic = cc.c4b(42, 180, 193, 255)
Style.fontEnhance = cc.c4b(228, 124, 22, 255)
Style.fontGem = cc.c4b(125, 231, 241, 255)
Style.fontIllusion = cc.c4b(135, 0, 255, 255)
Style.fontSuit = cc.c4b(255, 192, 0, 255)
Style.fontSuitLevel = cc.c4b(0, 192, 0, 255)
Style.fontDust = cc.c4b(254, 0, 127, 255)
Style.fontDustAttr = Style.font2
Style.dustDisabled = cc.c4b(142, 137, 131, 150)
Style.excellentColor = cc.c4b(215, 126, 44, 255)

function Style.init()
	local color_suit = CsvParser.getCsvData("config", "color_suit").value
	local color_dust = CsvParser.getCsvData("config", "color_dust").value
	Style.fontSuit = ColorUtil.getC4B(color_suit, 255)
	Style.fontDust = ColorUtil.getC4B(color_dust, 255)
end

function Style.b2f(bColor)
	return cc.c4f(bColor.r / 255, bColor.g / 255, bColor.b / 255, bColor.a / 255)
end

if device.platform == "ios" then
	Style.defaultFont = "Source Han Sans CN Bold"
else
	Style.defaultFont = "fonts/SourceHanSansCN-Bold.otf"
end

Style.defaultColor = Style.white
Style.left = cc.TEXT_ALIGNMENT_LEFT
Style.center = cc.TEXT_ALIGNMENT_CENTER
Style.right = cc.TEXT_ALIGNMENT_RIGHT
Style.vtop = cc.VERTICAL_TEXT_ALIGNMENT_TOP
Style.vcenter = cc.VERTICAL_TEXT_ALIGNMENT_CENTER
Style.vbottom = cc.VERTICAL_TEXT_ALIGNMENT_BOTTOM
Style.left_in_center = "left_in_center"
Style.right_in_center = "right_in_center"
Style.defaultAlign = Style.center

function Style.getColorBetween(color1, color2, percent)
	local r = (color2.r - color1.r) * percent + color1.r
	local g = (color2.g - color1.g) * percent + color1.g
	local b = (color2.b - color1.b) * percent + color1.b

	return cc.c4b(r, g, b, 255)
end

function Style.getTTFStyle(style)
	style = style or {}
	local font = style.font or Style.defaultFont

	if font == "" then
		font = nil
	else
		font = getFinalRes(font)
	end

	local valign = nil

	if style.wrap then
		valign = Style.vtop
	end

	return {
		__styled = true,
		size = style.size or Style.defaultSize,
		color = style.color or Style.defaultColor,
		outlineDistance = style.outline,
		outlineColor = style.outlineColor,
		shadowDistance = style.shadow,
		shadowColor = style.shadowColor,
		align = style.align or Style.defaultAlign,
		font = font,
		valign = style.valign or valign,
		wrap = style.wrap,
		offsetX = style.offsetX or 0,
		offsetY = style.offsetY or 0,
		opacity = style.opacity or 255
	}
end

local qualityColor = {
	[0] = cc.c4b(248, 247, 244, 255),
	cc.c4b(73, 152, 62, 255),
	cc.c4b(73, 87, 187, 255),
	cc.c4b(137, 79, 191, 255),
	cc.c4b(244, 121, 32, 255),
	cc.c4b(170, 33, 22, 255)
}

function Style.getQualityColor(quality)
	return qualityColor[quality] or qualityColor[0]
end

function Style.makeShining(node, min, max, time, interval, start, upInterval, upEasing, downEasing)
	min = min or 64
	max = max or 255
	time = time or 0.3
	interval = interval or 0
	upInterval = upInterval or 0
	start = start or 0
	local shiningUp, shiningDown = nil

	function shiningUp()
		transition.fadeTo(node, {
			delay = upInterval,
			opacity = max,
			time = time,
			onComplete = shiningDown,
			easing = downEasing
		})
	end

	function shiningDown()
		transition.fadeTo(node, {
			delay = interval,
			opacity = min,
			time = time,
			onComplete = shiningUp,
			easing = upEasing
		})
	end

	transition.fadeTo(node, {
		delay = start,
		opacity = min,
		time = time,
		onComplete = shiningUp,
		easing = upEasing
	})
end

function Style.makePuyo(node, interval, baseScale, isOnce)
	local slotY = node:getPositionY()
	baseScale = baseScale or 1
	local animationStep1, animationStep2, animationStep3, animationStep4, animationStep5 = nil

	function animationStep1()
		transition.moveTo(node, {
			easing = "sineOut",
			time = 0.1,
			y = slotY - 4 * baseScale
		})
		transition.scaleTo(node, {
			easing = "sineOut",
			time = 0.1,
			scaleX = 1.1 * baseScale,
			scaleY = 0.9 * baseScale,
			onComplete = animationStep2
		})
	end

	function animationStep2()
		transition.moveTo(node, {
			easing = "sineInOut",
			time = 0.1,
			y = slotY + 12 * baseScale
		})
		transition.scaleTo(node, {
			easing = "sineInOut",
			time = 0.1,
			scaleX = 0.9 * baseScale,
			scaleY = 1.1 * baseScale,
			onComplete = animationStep3
		})
	end

	function animationStep3()
		transition.scaleTo(node, {
			easing = "sineIn",
			time = 0.1,
			scaleX = 1 * baseScale,
			scaleY = 1 * baseScale
		})

		if isOnce then
			transition.moveTo(node, {
				easing = "sineIn",
				time = 0.1,
				y = slotY
			})
		else
			transition.moveTo(node, {
				easing = "sineIn",
				time = 0.1,
				y = slotY,
				onComplete = animationStep4
			})
		end
	end

	function animationStep4()
		transition.scaleTo(node, {
			easing = "sineOut",
			time = 0.06,
			scaleX = 1.1 * baseScale,
			scaleY = 0.9 * baseScale
		})
		transition.moveTo(node, {
			easing = "sineOut",
			time = 0.06,
			y = slotY - 4 * baseScale,
			onComplete = animationStep5
		})
	end

	function animationStep5()
		transition.scaleTo(node, {
			easing = "sineIn",
			time = 0.06,
			scaleX = 1 * baseScale,
			scaleY = 1 * baseScale
		})
		transition.moveTo(node, {
			easing = "sineIn",
			time = 0.06,
			y = slotY,
			onComplete = function ()
				node:performWithDelay(animationStep1, interval or 1)
			end
		})
	end

	animationStep1()
end

function Style.beat(node, scale, time, onComplete)
	scale = scale or 2
	time = time or 0.05

	local function beatDown()
		transition.scaleTo(node, {
			scale = 1,
			easing = "sineOut",
			time = time,
			onComplete = onComplete
		})
	end

	local function beatUp()
		transition.scaleTo(node, {
			easing = "sineOut",
			scale = scale,
			time = time,
			onComplete = beatDown
		})
	end

	beatUp()
end

function Style.makeBeat(node, scale, time)
	scale = scale or 1.5
	time = time or 0.5
	local beatUp, beatDown = nil

	function beatDown()
		transition.scaleTo(node, {
			scale = 1,
			easing = "sineOut",
			time = time,
			onComplete = beatUp
		})
	end

	function beatUp()
		transition.scaleTo(node, {
			easing = "sineOut",
			scale = scale,
			time = time,
			onComplete = beatDown
		})
	end

	beatUp()
end

function Style.beatup(node, initY, onComplete)
	local function beatDown()
		transition.moveTo(node, {
			easing = "sineOut",
			time = 0.075,
			y = initY
		})
		transition.scaleTo(node, {
			scale = 1,
			time = 0.075,
			easing = "sineOut",
			onComplete = onComplete
		})
	end

	local function beatUp()
		transition.moveTo(node, {
			easing = "backOut",
			time = 0.075,
			y = initY + 5
		})
		transition.scaleTo(node, {
			scale = 1.25,
			time = 0.075,
			easing = "backOut",
			onComplete = beatDown
		})
	end

	beatUp()
end

function Style.turnAround(node, time, isAnti)
	time = time or 1
	local moveUp, moveDown = nil

	function moveDown()
		node:setRotation(isAnti and -180 or 180)
		transition.rotateTo(node, {
			rotate = isAnti and -360 or 360,
			time = time / 2,
			onComplete = moveUp
		})
	end

	function moveUp()
		node:setRotation(0)
		transition.rotateTo(node, {
			rotate = isAnti and -180 or 180,
			time = time / 2,
			onComplete = moveDown
		})
	end

	moveUp()
end

function Style.makeFloat(node, distance, time)
	distance = distance or 5
	time = time or 1
	local initY = node:getPositionY()
	local moveUp, moveDown = nil

	function moveDown()
		transition.moveTo(node, {
			easing = "sineOut",
			y = initY,
			time = time,
			onComplete = moveUp
		})
	end

	function moveUp()
		transition.moveTo(node, {
			easing = "sineOut",
			y = initY + distance,
			time = time,
			onComplete = moveDown
		})
	end

	moveUp()
end

function Style.makeShock(node, scope, time)
	scope = scope or 10
	time = time or 0
	local shockLoop = nil
	local originalX, originalY = node:getPosition()

	local function shockLoop(_node, frame, passed, sharp)
		node:setPosition(originalX + math.random() * scope * 2 - scope, originalY + math.random() * scope * 2 - scope)

		time = time - passed / 60

		if time < 0 then
			scope = scope * 0.8
		end

		if scope < 1 then
			node:setPosition(originalX, originalY)
			Looper.stopLoop(node, shockLoop)
		end
	end

	Looper.startLoop(node, shockLoop)
end

function Style.switchEffect(ui, isShow, onComplete)
	transition.stopTarget(ui)

	if not ui.originalY then
		ui.originalY = ui:getPositionY()
	end

	local time = 0.15
	local yOffset = 10

	if isShow then
		local minOpacity = 200
		local startOpacity = ui:getOpacity()
		local delay = 0

		if minOpacity < startOpacity then
			delay = (startOpacity - minOpacity) / 255 * 0.15

			transition.fadeTo(ui, {
				easing = "sineIn",
				time = delay,
				opacity = minOpacity
			})
			transition.moveTo(ui, {
				easing = "sineOut",
				time = delay,
				y = ui.originalY + yOffset
			})
		end

		transition.fadeTo(ui, {
			opacity = 255,
			easing = "sineOut",
			delay = delay,
			time = time
		})
		ui:setPositionY(ui.originalY - yOffset)
		transition.moveTo(ui, {
			easing = "backOut",
			delay = delay,
			time = time,
			y = ui.originalY,
			onComplete = onComplete
		})
	else
		transition.fadeTo(ui, {
			opacity = 0,
			easing = "sineIn",
			time = time
		})
		transition.moveTo(ui, {
			easing = "sineOut",
			time = time,
			y = ui.originalY + yOffset,
			onComplete = onComplete
		})
	end
end

function Style.getPropColor(preValue, newValue)
	if preValue < newValue then
		return Style.enableColor
	elseif newValue < preValue then
		return Style.disableColor
	else
		return Style.font1
	end
end

function Style.makeFont(ui, uiName, fontColor, blurColor, blurParams, noClearOutline, customText)
	if customText then
		ui:createLabelOnFlag(uiName, customText)
	end

	local style = ui:getStyleByTag(uiName)
	local label = ui:getComponentByTag(uiName)

	if not noClearOutline then
		label:enableOutline(cc.c4b(0, 0, 0, 0), style.outline)
	end

	local size = label:getContentSize()

	if size.width == 0 then
		return
	end

	if fontColor then
		local sprite = ui:createTrueMask(uiName, fontColor)
	end

	local label_border = ui:getComponentByTag(uiName .. "_border")

	if ui:getFlagByTag(uiName .. "_border") and customText then
		label_border = ui:createLabelOnFlag(uiName .. "_border", customText)
	end

	if label_border then
		label_border:setLocalZOrder(label_border:getLocalZOrder() - 1)
	end

	local style = ui:getStyleByTag(uiName .. "_glow")
	local label_glow = ui:getComponentByTag(uiName .. "_glow")

	if customText then
		label_glow = ui:createLabelOnFlag(uiName .. "_glow", customText)
	end

	label_glow:setLocalZOrder(label_glow:getLocalZOrder() - 2)

	local sprite = ui:createTrueMask(uiName .. "_glow", blurColor)
	blurParams = blurParams or {}

	Shader.blur(sprite, false, blurParams.resolution or 150, blurParams.blurRadius or 10, blurParams.sampleNum or 10)

	return sprite
end

function Style.getFontLang(lang)
	local style = {}

	if not empty(lang) then
		style.lang = lang
		style.font = Localization.getFont(lang)
	end

	return style
end

return Style
