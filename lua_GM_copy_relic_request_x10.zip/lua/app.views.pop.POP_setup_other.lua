local POP_setup_other = class("POP_setup_other", UI_base)

function POP_setup_other.open()
	local ui = POP_setup_other.new()

	PopManager.open(ui)
end

function POP_setup_other:ctor()
	POP_setup_other.super.ctor(self, "pop_setup_other", UIManager.BIG_TYPE.POP)
	self:init()
end

function POP_setup_other:init()
	self:initUI()
end

function POP_setup_other:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local button_step = self:getComponentByTag("button_step")

	button_step:toTouchable()
	button_step:setTapGroup("button_click")
	button_step:addTap(function ()
		Sound.setStepSound(not Sound.isStepSound())
		self:refreshStepSound()
	end)
	self:refreshStepSound()

	local button_show_dmg = self:getComponentByTag("button_show_dmg")

	button_show_dmg:toTouchable()
	button_show_dmg:setTapGroup("button_click")
	button_show_dmg:addTap(function ()
		local isShowDmg = Cookie.get("isShowDmg") or 1
		isShowDmg = 1 - isShowDmg

		Cookie.set("isShowDmg", isShowDmg, true)
		self:refreshShowDmg()
	end)
	self:refreshShowDmg()

	local button_top = self:getComponentByTag("button_top")

	button_top:toTouchable()
	button_top:setTapGroup("button_click")
	button_top:addTap(function ()
		local isTopConfirm = Cookie.get("isTopConfirm") or 1
		isTopConfirm = 1 - isTopConfirm

		Cookie.set("isTopConfirm", isTopConfirm, true)
		self:refreshTop()
	end)
	self:refreshTop()

	local button_autolock = self:getComponentByTag("button_autolock")
	local autolock = InfoVars.get("autolock")

	if autolock ~= nil then
		button_autolock:toTouchable()
		button_autolock:setTapGroup("button_click")
		button_autolock:addTap(function ()
			local autolock = InfoVars.get("autolock")

			if autolock == 1 then
				InfoVars.set("autolock", 0, function ()
					self:refreshAutolock()
				end)
			else
				InfoVars.set("autolock", 1, function ()
					self:refreshAutolock()
				end)
			end
		end)
		self:refreshAutolock()
	else
		button_autolock:setVisible(false)

		local hint_autolock = self:getComponentByTag("hint_autolock")
		local label_autolock = self:getComponentByTag("label_autolock")
		local selected_autolock = self:getComponentByTag("selected_autolock")
		local button_autolock = self:getComponentByTag("button_autolock")

		hint_autolock:setVisible(false)
		label_autolock:setVisible(false)
		selected_autolock:setVisible(false)
		button_autolock:setVisible(false)
	end

	local button_screen = self:getComponentByTag("button_screen")

	if CONFIG.screen_lock then
		button_screen:toTouchable()
		button_screen:setTapGroup("button_click")
		button_screen:addTap(function ()
			Sound.setScreenOn(not Sound.isScreenOn())
			self:refreshScreen()
		end)
		self:refreshScreen()
	else
		button_screen:setVisible(false)

		local hint_screen = self:getComponentByTag("hint_screen")
		local label_screen = self:getComponentByTag("label_screen")
		local selected_screen = self:getComponentByTag("selected_screen")

		hint_screen:setVisible(false)
		label_screen:setVisible(false)
		selected_screen:setVisible(false)
	end

	local button_flash = self:getComponentByTag("button_flash")

	button_flash:toTouchable()
	button_flash:setTapGroup("button_click")
	button_flash:addTap(function ()
		local isAllowFlash = Cookie.get("isAllowFlash") or 1
		isAllowFlash = 1 - isAllowFlash

		Cookie.set("isAllowFlash", isAllowFlash, true)
		self:refreshFlash()
	end)
	self:refreshFlash()

	local button_nodrop_saved = self:getComponentByTag("button_nodrop_saved")
	local nodrop_saved = InfoVars.get("nodrop_saved")

	button_nodrop_saved:toTouchable()
	button_nodrop_saved:setTapGroup("button_click")
	button_nodrop_saved:addTap(function ()
		local nodrop_saved = InfoVars.get("nodrop_saved")

		if nodrop_saved == 1 then
			InfoVars.set("nodrop_saved", 0, function ()
				self:refreshNodropSaved()
			end)
		else
			InfoVars.set("nodrop_saved", 1, function ()
				self:refreshNodropSaved()
			end)
		end
	end)
	self:refreshNodropSaved()

	local hintButtons = {
		"hint_step",
		"hint_show_dmg",
		"hint_top",
		"hint_autolock",
		"hint_screen",
		"hint_flash",
		"hint_nodrop_saved"
	}
	local hints = {
		Localization.getSrcText("开启、关闭脚步音效"),
		Localization.getSrcText("战斗中是否显示伤害数字"),
		Localization.getSrcText("地城小地图跳转时是否需要确认"),
		Localization.getSrcText("获得橙色英雄和宠物时是否自动锁定\n否则只会自动锁定红色品质"),
		Localization.getSrcText("是否禁用设备熄屏，保持屏幕常亮"),
		Localization.getSrcText("是否允许闪白特效，否则将用黑色代替"),
		Localization.getSrcText("是否启用地城中不能丢弃绑定装备的保护措施")
	}

	for i, v in ipairs(hintButtons) do
		local button = self:getComponentByTag(v)

		button:setOpacity(0)
		button:toTouchable()
		button:addTap(function ()
			local x, y = button:getPosition()
			local pos = self:convertToWorldSpace(cc.p(x, y))

			TinyHint.open(cc.p(pos.x, pos.y), hints[i])
		end)
	end
end

function POP_setup_other:refreshStepSound()
	local selected_step = self:getComponentByTag("selected_step")

	selected_step:setVisible(Sound.isStepSound())
end

function POP_setup_other:refreshShowDmg()
	local selected_show_dmg = self:getComponentByTag("selected_show_dmg")
	local isShowDmg = Cookie.get("isShowDmg") or 1

	selected_show_dmg:setVisible(isShowDmg == 1)
end

function POP_setup_other:refreshTop()
	local selected_top = self:getComponentByTag("selected_top")
	local isTopConfirm = Cookie.get("isTopConfirm") or 1

	selected_top:setVisible(isTopConfirm == 1)
end

function POP_setup_other:refreshAutolock()
	local selected_autolock = self:getComponentByTag("selected_autolock")

	selected_autolock:setVisible(InfoVars.get("autolock") == 1)
end

function POP_setup_other:refreshScreen()
	if CONFIG.screen_lock then
		local selected_screen = self:getComponentByTag("selected_screen")

		selected_screen:setVisible(Sound.isScreenOn())
	end
end

function POP_setup_other:refreshFlash()
	local selected_flash = self:getComponentByTag("selected_flash")
	local isAllowFlash = Cookie.get("isAllowFlash") or 1

	selected_flash:setVisible(isAllowFlash == 1)
end

function POP_setup_other:refreshNodropSaved()
	local selected_nodrop_saved = self:getComponentByTag("selected_nodrop_saved")

	selected_nodrop_saved:setVisible(InfoVars.get("nodrop_saved") == 1)
end

return POP_setup_other
