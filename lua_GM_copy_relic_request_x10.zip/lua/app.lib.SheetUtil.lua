local SheetUtil = class("SheetUtil")
SheetUtil.CONDITION = {
	EXIT_BUTTON = 1001
}

function SheetUtil.getArray(value)
	local _valueArr = string.split(value, ";")
	local valueArr = {}
	local t = {}

	for i, v in ipairs(_valueArr) do
		if v ~= "" then
			table.insert(valueArr, tonumber(v) or v)
		end
	end

	return valueArr
end

function SheetUtil.getTableArray(value)
	local _valueArr = string.split(value, ";")
	local t = {}

	for i, v in ipairs(_valueArr) do
		if v ~= "" then
			local _vArr = string.split(v, ",")
			local _t = {}

			for j, v1 in ipairs(_vArr) do
				if j == 1 then
					t[v1] = _t
				else
					table.insert(_t, tonumber(v1) or v1)
				end
			end
		end
	end

	return t
end

function SheetUtil.getTableValue(value)
	local _valueArr = string.split(value, ";")
	local t = {}

	for i, v in ipairs(_valueArr) do
		if v ~= "" then
			local _vArr = string.split(v, ",")
			t[_vArr[1]] = tonumber(_vArr[2]) or _vArr[2]
		end
	end

	return t
end

function SheetUtil.getString(value, randomFunc, exceptMap)
	if CONFIG.isBench then
		randomFunc = Random.new()
	end

	local result = ""

	if value == "" then
		result = ""
	end

	if type(value) == "number" then
		result = tostring(value)
	end

	if type(exceptMap) == "number" or type(exceptMap) == "string" then
		local _exceptMap = {
			[tostring(exceptMap)] = true
		}
		exceptMap = _exceptMap
	end

	randomFunc = randomFunc or math.random

	if not string.find(value, ";") then
		if not string.find(value, ":") then
			result = value
		else
			local pairArr = string.split(value, ":")
			result = pairArr[1]
		end
	elseif not string.find(value, ":") then
		local _valueArr = string.split(value, ";")
		local valueArr = {}

		for i, v in ipairs(_valueArr) do
			if v ~= "" and (not exceptMap or not exceptMap[v]) then
				table.insert(valueArr, v)
			end
		end

		if type(randomFunc) == "table" then
			result = valueArr[math.floor(randomFunc:next() * #valueArr) + 1]
		else
			result = valueArr[math.floor(randomFunc() * #valueArr) + 1]
		end
	else
		local _valueArr = string.split(value, ";")
		local vArr = {}
		local pArr = {}

		for i, v in ipairs(_valueArr) do
			if v ~= "" then
				local pairArr = string.split(v, ":")

				if not exceptMap or not exceptMap[pairArr[1]] then
					table.insert(vArr, pairArr[1])
					table.insert(pArr, tonumber(pairArr[2]))
				end
			end
		end

		result = vArr[SheetUtil.getPowerRandomIndex(pArr, randomFunc)]
	end

	result = StringUtil.trim(result)

	if exceptMap and exceptMap[result] then
		result = ""
	end

	return result
end

local function _getNumberRange(value, randomFunc)
	if CONFIG.isBench then
		randomFunc = Random.new()
	end

	if type(value) == "number" then
		return value
	elseif tonumber(value) ~= nil then
		return tonumber(value)
	elseif string.find(value, "~") then
		local valueArr = string.split(value, "~")

		if type(randomFunc) == "table" then
			return tonumber(valueArr[1]) + math.floor(randomFunc:next() * (tonumber(valueArr[2]) - tonumber(valueArr[1]) + 1))
		else
			return tonumber(valueArr[1]) + math.floor(randomFunc() * (tonumber(valueArr[2]) - tonumber(valueArr[1]) + 1))
		end
	end
end

function SheetUtil.getMinMax(value)
	if value == "" then
		return 0, 0
	end

	local min, max = nil

	if type(value) == "number" then
		min = value
		max = min
	elseif tonumber(value) ~= nil then
		min = tonumber(value)
		max = min
	elseif string.find(value, ";") then
		local valueArr = {}

		if not string.find(value, ":") then
			local _valueArr = string.split(value, ";")

			for i, v in ipairs(_valueArr) do
				if v ~= "" then
					table.insert(valueArr, v)
				end
			end
		else
			local _valueArr = string.split(value, ";")

			for i, v in ipairs(_valueArr) do
				if v ~= "" then
					local pairArr = string.split(v, ":")

					table.insert(valueArr, pairArr[1])
				end
			end
		end

		for i, v in ipairs(valueArr) do
			local _min, _max = SheetUtil.getMinMax(v)

			if not min or _min < min then
				min = _min
			end

			if not max or max < _max then
				max = _max
			end
		end
	elseif string.find(value, "~") then
		local valueArr = string.split(value, "~")
		min = tonumber(valueArr[1])
		max = tonumber(valueArr[2])
	end

	return min, max
end

function SheetUtil.getNumber(value, randomFunc)
	if CONFIG.isBench then
		randomFunc = Random.new()
	end

	if value == "" then
		return 0
	end

	randomFunc = randomFunc or math.random

	if type(value) == "number" then
		return value
	elseif tonumber(value) ~= nil then
		return tonumber(value)
	elseif string.find(value, ";") then
		if not string.find(value, ":") then
			local _valueArr = string.split(value, ";")
			local valueArr = {}

			for i, v in ipairs(_valueArr) do
				if v ~= "" then
					table.insert(valueArr, v)
				end
			end

			local vStr = nil

			if type(randomFunc) == "table" then
				vStr = valueArr[math.floor(randomFunc:next() * #valueArr) + 1]
			else
				vStr = valueArr[math.floor(randomFunc() * #valueArr) + 1]
			end

			return _getNumberRange(vStr, randomFunc)
		else
			local _valueArr = string.split(value, ";")
			local vArr = {}
			local pArr = {}

			for i, v in ipairs(_valueArr) do
				if v ~= "" then
					local pairArr = string.split(v, ":")

					table.insert(vArr, pairArr[1])
					table.insert(pArr, tonumber(pairArr[2]))
				end
			end

			local vStr = vArr[SheetUtil.getPowerRandomIndex(pArr, randomFunc)]

			return _getNumberRange(vStr, randomFunc)
		end
	elseif string.find(value, "~") then
		if not string.find(value, ":") then
			return _getNumberRange(value, randomFunc)
		else
			local pairArr = string.split(value, ":")

			return _getNumberRange(pairArr[1], randomFunc)
		end
	end

	return 0
end

function SheetUtil.getNumberArr(value)
	if value == "" then
		return {
			0
		}
	end

	if type(value) == "number" then
		return {
			value
		}
	elseif tonumber(value) ~= nil then
		return {
			tonumber(value)
		}
	elseif string.find(value, ";") then
		if not string.find(value, ":") then
			local _valueArr = string.split(value, ";")
			local valueArr = {}

			for i, v in ipairs(_valueArr) do
				if v ~= "" then
					table.insert(valueArr, tonumber(v))
				end
			end

			return valueArr
		else
			local _valueArr = string.split(value, ";")
			local vArr = {}

			for i, v in ipairs(_valueArr) do
				if v ~= "" then
					local pairArr = string.split(v, ":")

					table.insert(vArr, tonumber(pairArr[1]))
				end
			end

			return vArr
		end
	elseif string.find(value, "~") then
		if not string.find(value, ":") then
			local valueArr = string.split(value, "~")

			return {
				tonumber(valueArr[1]),
				tonumber(valueArr[2])
			}
		else
			local pairArr = string.split(value, ":")
			local valueArr = string.split(pairArr[1], "~")

			return {
				tonumber(valueArr[1]),
				tonumber(valueArr[2])
			}
		end
	end

	return {
		0
	}
end

local function _getNumberRangeLinear(value, ratio)
	if type(value) == "number" then
		return value
	elseif tonumber(value) ~= nil then
		return tonumber(value)
	elseif string.find(value, "~") then
		local valueArr = string.split(value, "~")

		return tonumber(valueArr[1]) + math.floor(ratio * (tonumber(valueArr[2]) - tonumber(valueArr[1]) + 1))
	end
end

local function _getPowerRandomIndexLinear(powerArr, ratio)
	local powerMax = 0

	for i = 1, #powerArr do
		powerMax = powerMax + tonumber(powerArr[i])
	end

	powerMax = ratio * powerMax

	for i = 1, #powerArr do
		if powerMax < tonumber(powerArr[i]) then
			return i
		else
			powerMax = powerMax - tonumber(powerArr[i])
		end
	end

	return #powerArr
end

function SheetUtil.getLinearNumber(value, ratio)
	if value == "" then
		return 0
	end

	if type(value) == "number" then
		return value
	elseif tonumber(value) ~= nil then
		return tonumber(value)
	elseif string.find(value, ";") then
		if not string.find(value, ":") then
			local _valueArr = string.split(value, ";")
			local valueArr = {}

			for i, v in ipairs(_valueArr) do
				if v ~= "" then
					table.insert(valueArr, v)
				end
			end

			local vIndex = math.floor(ratio * #valueArr) + 1
			local vStr = valueArr[vIndex]
			local ranMin = (vIndex - 1) / #valueArr
			local ranMax = vIndex / #valueArr

			return _getNumberRangeLinear(vStr, (ratio - ranMin) / (ranMax - ranMin))
		else
			local _valueArr = string.split(value, ";")
			local vArr = {}
			local pArr = {}
			local ptArr = {}
			local powerTotal = 0

			for i, v in ipairs(_valueArr) do
				if v ~= "" then
					local pairArr = string.split(v, ":")

					table.insert(vArr, pairArr[1])

					local power = tonumber(pairArr[2])

					table.insert(pArr, power)
					table.insert(ptArr, powerTotal)

					powerTotal = powerTotal + power
				end
			end

			table.insert(ptArr, powerTotal)

			local vIndex = _getPowerRandomIndexLinear(pArr, ratio)
			local vStr = vArr[vIndex]
			local ranMin = ptArr[vIndex] / powerTotal
			local ranMax = ptArr[vIndex + 1] / powerTotal

			return _getNumberRangeLinear(vStr, (ratio - ranMin) / (ranMax - ranMin))
		end
	elseif string.find(value, "~") then
		if not string.find(value, ":") then
			return _getNumberRangeLinear(value, ratio)
		else
			local pairArr = string.split(value, ":")

			return _getNumberRangeLinear(pairArr[1], ratio)
		end
	end

	return 0
end

function SheetUtil.getNumberUp(value, randomFunc, upValue)
	if CONFIG.isBench then
		randomFunc = Random.new()
	end

	if value == "" then
		return 0
	end

	randomFunc = randomFunc or math.random

	if type(value) == "number" then
		return value
	elseif tonumber(value) ~= nil then
		return tonumber(value)
	elseif string.find(value, ";") then
		if not string.find(value, ":") then
			local _valueArr = string.split(value, ";")
			local valueArr = {}

			for i, v in ipairs(_valueArr) do
				if v ~= "" then
					table.insert(valueArr, v)
				end
			end

			local vStr = nil

			if type(randomFunc) == "table" then
				vStr = valueArr[math.floor(randomFunc:next() * #valueArr) + 1]
			else
				vStr = valueArr[math.floor(randomFunc() * #valueArr) + 1]
			end

			return _getNumberRange(vStr, randomFunc)
		else
			local _valueArr = string.split(value, ";")
			local vArr = {}
			local pArr = {}

			for i, v in ipairs(_valueArr) do
				if v ~= "" then
					local pairArr = string.split(v, ":")
					local _value = tonumber(pairArr[1])

					table.insert(vArr, _value)

					local _power = tonumber(pairArr[2])

					if _value > 0 then
						_power = _power * (1 + upValue / 100)
					end

					table.insert(pArr, _power)
				end
			end

			local vStr = vArr[SheetUtil.getPowerRandomIndex(pArr, randomFunc)]

			return _getNumberRange(vStr, randomFunc)
		end
	elseif string.find(value, "~") then
		if not string.find(value, ":") then
			return _getNumberRange(value, randomFunc)
		else
			local pairArr = string.split(value, ":")

			return _getNumberRange(pairArr[1], randomFunc)
		end
	end

	return 0
end

function SheetUtil.getPowerRandomIndex(powerArr, randomFunc, keyName)
	if CONFIG.isBench then
		randomFunc = Random.new()
	end

	randomFunc = randomFunc or math.random

	if keyName then
		local powerMax = 0

		for i = 1, #powerArr do
			powerMax = powerMax + tonumber(powerArr[i][keyName])
		end

		if type(randomFunc) == "table" then
			powerMax = randomFunc:next() * powerMax
		else
			powerMax = randomFunc() * powerMax
		end

		for i = 1, #powerArr do
			if powerMax < tonumber(powerArr[i][keyName]) then
				return i
			else
				powerMax = powerMax - tonumber(powerArr[i][keyName])
			end
		end
	else
		local powerMax = 0

		for i = 1, #powerArr do
			powerMax = powerMax + tonumber(powerArr[i])
		end

		if type(randomFunc) == "table" then
			powerMax = randomFunc:next() * powerMax
		else
			powerMax = randomFunc() * powerMax
		end

		for i = 1, #powerArr do
			if powerMax < tonumber(powerArr[i]) then
				return i
			else
				powerMax = powerMax - tonumber(powerArr[i])
			end
		end
	end
end

function SheetUtil.getColumnListFull(data, columns, keys)
	local list = {}
	local index = 1

	while true do
		local isEmpty = false
		local obj = {}

		for i = 1, #columns do
			if data[columns[i] .. index] ~= nil and data[columns[i] .. index] ~= "" then
				if keys then
					obj[keys[i]] = data[columns[i] .. index]
				else
					obj[columns[i]] = data[columns[i] .. index]
				end
			else
				isEmpty = true

				break
			end
		end

		if isEmpty then
			break
		else
			table.insert(list, obj)

			index = index + 1
		end
	end

	return list
end

function SheetUtil.getColumnList(data, columns, keys)
	local list = {}
	local index = 1

	while true do
		local isEmpty = true
		local obj = {}

		for i = 1, #columns do
			if data[columns[i] .. index] ~= nil and data[columns[i] .. index] ~= "" then
				if keys then
					obj[keys[i]] = data[columns[i] .. index]
				else
					obj[columns[i]] = data[columns[i] .. index]
				end

				isEmpty = false
			end
		end

		if isEmpty then
			break
		else
			table.insert(list, obj)

			index = index + 1
		end
	end

	return list
end

function SheetUtil.getColumnValueList(data, column)
	local list = {}
	local index = 1

	while true do
		local isEmpty = true
		local value = nil

		if data[column .. index] ~= nil and data[column .. index] ~= "" then
			value = data[column .. index]
			isEmpty = false
		end

		if isEmpty then
			break
		else
			table.insert(list, value)

			index = index + 1
		end
	end

	return list
end

return SheetUtil
