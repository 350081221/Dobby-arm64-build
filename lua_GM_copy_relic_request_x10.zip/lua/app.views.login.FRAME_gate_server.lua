local UI_base = import("..UI_base")
local FRAME_gate_server = class("FRAME_gate_server", UI_base)

function FRAME_gate_server.open(serverList, sdkResult, onSuccess, onFailure, onProgress)
	local ui = FRAME_gate_server.new(serverList, sdkResult, onSuccess, onFailure, onProgress)

	PopManager.open(ui)
end

function FRAME_gate_server:ctor(serverList, sdkResult, onSuccess, onFailure, onProgress)
	FRAME_gate_server.super.ctor(self, "frame_gate_server")

	self.serverList = serverList
	self.sdkResult = sdkResult
	self.onSuccess = onSuccess
	self.onFailure = onFailure
	self.onProgress = onProgress

	self:init()
end

function FRAME_gate_server:init()
	self.noCloseByKey = true

	self:initUI()

	local items, firstIndex = self:makeServerList()

	self.list:setItems(items)

	if firstIndex then
		self.list:setSelectedIndex(firstIndex)
	end

	self:refresh()
end

function FRAME_gate_server:makeServerList()
	local arr = self.serverList
	local serverArr = {}
	local firstIndex = nil
	local recentArr = {}

	for i, v in ipairs(arr) do
		if v.login_time > 0 then
			table.insert(recentArr, v)
		end
	end

	if #recentArr > 0 then
		table.sort(recentArr, function (a, b)
			return b.login_time < a.login_time
		end)
		table.insert(serverArr, {
			label = Localization.getSrcText("最近登录")
		})

		for i = 1, self.cols - 1 do
			table.insert(serverArr, {
				empty = true,
				label = 1
			})
		end

		for i = 1, math.min(3, #recentArr) do
			table.insert(serverArr, recentArr[i])

			firstIndex = firstIndex or #serverArr
		end

		local moreNum = math.ceil(#recentArr / self.cols) * self.cols - #recentArr

		for i = 1, moreNum do
			table.insert(serverArr, {
				empty = true
			})
		end
	end

	local recommendArr = {}

	for i, v in ipairs(arr) do
		if v.status == 1 then
			table.insert(recommendArr, v)
		end
	end

	if #recommendArr > 0 then
		table.insert(serverArr, {
			label = Localization.getSrcText("推荐")
		})

		for i = 1, self.cols - 1 do
			table.insert(serverArr, {
				empty = true,
				label = 1
			})
		end

		for i, v in ipairs(recommendArr) do
			table.insert(serverArr, v)

			firstIndex = firstIndex or #serverArr
		end

		local moreNum = math.ceil(#recommendArr / self.cols) * self.cols - #recommendArr

		for i = 1, moreNum do
			table.insert(serverArr, {
				empty = true
			})
		end
	end

	table.insert(serverArr, {
		label = Localization.getSrcText("所有服务器")
	})

	for i = 1, self.cols - 1 do
		table.insert(serverArr, {
			empty = true,
			label = 1
		})
	end

	for i, v in ipairs(arr) do
		table.insert(serverArr, v)

		firstIndex = firstIndex or #serverArr
	end

	local moreNum = math.ceil(#arr / self.cols) * self.cols - #arr

	for i = 1, moreNum do
		table.insert(serverArr, {
			empty = true
		})
	end

	return serverArr, firstIndex
end

function FRAME_gate_server:initUI()
	local mask = self:getComponentByTag("mask")

	mask:toTouchable()
	mask:setOpacity(0)

	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local bg1 = self:getComponentByTag("bg1")
	local flag_list = self:getFlagByTag("flag_list")
	local holder = self:getComponentByTag("holder")
	local holder_bg = self:getComponentByTag("holder_bg")
	local bt_enter = self:getComponentByTag("bt_enter")
	local bt_enter_disabled = self:getComponentByTag("bt_enter_disabled")
	local label_new = self:getComponentByTag("label_new")
	local flag_head = self:getFlagByTag("flag_head")
	local flag_status = self:getFlagByTag("flag_status")
	local widthOffset = math.max(self:getBigWidth(), display.width) - 960
	local cellWidth = 250
	local moreCols = math.floor(widthOffset / cellWidth)
	moreCols = math.max(0, math.min(2, moreCols))

	if moreCols > 0 then
		bg:setSize(bg.originalWidth + cellWidth * moreCols)
		bg:setPos(bg.x - cellWidth * moreCols / 2)
		bg1:setSize(bg1.originalWidth + cellWidth * moreCols)
		bg1:setPos(bg1.x - cellWidth * moreCols / 2)
		holder:setPos(holder.x - cellWidth * moreCols / 2)
		holder_bg:setPos(holder_bg.x - cellWidth * moreCols / 2)

		flag_list.width = flag_list.originalWidth + cellWidth * moreCols
		flag_list.x = flag_list.x - cellWidth * moreCols / 2

		bt_enter:setPos(bt_enter.x + cellWidth * moreCols / 2)
		bt_enter_disabled:setPos(bt_enter_disabled.x + cellWidth * moreCols / 2)
		label_new:setPositionX(label_new.x - cellWidth * moreCols / 2)

		flag_head.x = flag_head.x - cellWidth * moreCols / 2
		flag_status.x = flag_status.x - cellWidth * moreCols / 2
	end

	self.cols = 2 + moreCols

	local function tapListener(ui, data, index)
		if not data.empty and not data.label then
			UIManager.callTapGroup("button_click")
			self.list:setSelectedIndex(index)
			self:refresh()
		end
	end

	self.list = self:createListOnFlag("flag_list", function (rect)
		return LIST_gate_server.new(rect, self.cols)
	end, tapListener)
	local holder = self:getComponentByTag("holder")

	self.list:setHolders({
		holder
	}, nil, 5)

	local bt_enter = self:getComponentByTag("bt_enter")

	bt_enter:toTouchable()
	bt_enter:setTapGroup("button_click")
	bt_enter:addTap(function ()
		local item = self.list:getSelectedItem()

		self:login(item.server_id)
	end)

	local bt_enter_disabled = self:getComponentByTag("bt_enter_disabled")

	bt_enter_disabled:toTouchable()
	bt_enter_disabled:setTapGroup("button_click")
	bt_enter_disabled:addTap(function ()
		local item = self.list:getSelectedItem()

		if item then
			Alert.open(Localization.getSrcText("服务器未开放"))
		else
			Alert.open(Localization.getSrcText("未选择服务器"))
		end
	end)
end

function FRAME_gate_server:refresh()
	local item = self.list:getSelectedItem()
	local bt_enter = self:getComponentByTag("bt_enter")
	local bt_enter_disabled = self:getComponentByTag("bt_enter_disabled")

	if item then
		bt_enter:setVisible(true)
		bt_enter_disabled:setVisible(false)
	else
		bt_enter:setVisible(false)
		bt_enter_disabled:setVisible(true)
	end
end

function FRAME_gate_server:login(server_id)
	if self.locked then
		return
	end

	self.locked = true
	local sdkResult = self.sdkResult
	local onSuccess = self.onSuccess
	local onFailure = self.onFailure
	local onProgress = self.onProgress
	local params = {
		sign = CONFIG.gate_sign,
		app_id = CONFIG.gate_app_id,
		sdk_channel_type = CONFIG.qudao_code,
		sdk_uid = sdkResult.user_id,
		server_id = server_id,
		sdk_username = sdkResult.user_name,
		sdk_token = sdkResult.token
	}

	Http.request(CONFIG.gate_host .. "sdk_login", params, function (_data)
		dump(_data, CONFIG.gate_host .. "sdk_login", 10)

		if _data.code ~= 200 or type(_data.data) ~= "table" then
			Log.debug("服务器验证失败：", _data.message, "渠道", CONFIG.qudao_code)
			Alert.open(Localization.getSrcText("服务器验证失败"))

			self.locked = nil

			return
		end

		local data = _data.data

		if data.server_host then
			SERVER_HOST = data.server_host
			SERVER_PORT = data.server_port

			Log.debug("=账号服转游戏服=", SERVER_HOST, SERVER_PORT)
			Connection.init(SERVER_HOST, SERVER_PORT)

			local function _onSuccess()
				PopManager.close()

				if onSuccess then
					onSuccess()
				end
			end

			local function _onProgress(index, total, msg)
				PopManager.close()

				if onProgress then
					onProgress(index, total, msg)
				end
			end

			local function _onFailure(err)
				self.locked = nil
			end

			InfoUser.loginGate(CONFIG.qudao_code, sdkResult.user_id, sdkResult.user_name, data.token, sdkResult.channel_type, _onSuccess, _onFailure, _onProgress)
		end
	end)
end

return FRAME_gate_server
