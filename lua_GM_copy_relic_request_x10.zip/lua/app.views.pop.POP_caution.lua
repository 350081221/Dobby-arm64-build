local POP_caution = class("POP_caution", UI_base)

function POP_caution:ctor()
	POP_caution.super.ctor(self, "pop_caution", UIManager.BIG_TYPE.TOP)
	self:init()
end

function POP_caution:init()
	self.oneStack = {}

	notify.safeRegister(self, "caution_push", function (data)
		self:addOne(data)
	end)
end

local defaultStayTime = 4

function POP_caution:addOne(data)
	local csv = CsvParser.getCsvData("caution", data.base_id)

	if not csv then
		return
	end

	local stayTime = data.time or defaultStayTime
	local one = UIManager.getUI("pop_caution_one")
	local bg = one:getComponentByTag("bg")
	local text = csv.text

	if data.text then
		text = data.text
	elseif data.replace and #data.replace > 0 then
		text = StringUtil.replace(text, unpack(data.replace))
	end

	local flag = one:getFlagByTag("flag_text")
	local newTextArr = {}
	local len = utf8.len(text)

	for j = 1, len do
		table.insert(newTextArr, utf8.sub(text, j, j))
	end

	one:createLabelGroupOnFlag("flag_text", newTextArr, nil, {
		limitWidthText = "…",
		align = Style.left,
		limitWidth = flag.width
	})

	local sub_text = csv.sub_text

	if data.sub_text then
		sub_text = data.sub_text
	elseif data.mini_replace and #data.mini_replace > 0 then
		sub_text = StringUtil.replace(sub_text, unpack(data.mini_replace))
	end

	local subTextArr = {}
	local len = utf8.len(sub_text)

	for j = 1, len do
		table.insert(subTextArr, utf8.sub(sub_text, j, j))
	end

	one:createLabelGroupOnFlag("flag_mini_text", subTextArr, nil, {
		limitWidthText = "…",
		align = Style.left,
		limitWidth = flag.width
	})

	if data.icon then
		one:createIconOnFlag("flag_icon", data.icon, 100, true)
	else
		local slot = DropSlot.new(one:getFlagByTag("flag_icon"), "slot_04")

		one:addChild(slot, 100)
		slot:setDrop(csv.icon_type, {
			level = 1,
			num = 1,
			base_id = data.id
		})
	end

	self:addChild(one)
	table.insert(self.oneStack, one)

	one.createTime = Time.time()
	one.stayTime = stayTime
	one.isNew = true

	one:setOpacity(0)
	self:addEnterFrame("arrange_loop", function ()
		self:arrange()
	end)
end

local spaceX = 240
local spaceY = 100
local lineNum = 3

function POP_caution:arrange()
	local nowTime = Time.time()
	local oneStack = self.oneStack
	local removeArr = {}
	local blockX = 0
	local blockY = 0
	local dWidth = math.max(self:getBigWidth(), display.width)
	local startX = dWidth / 2 - (math.min(#oneStack, lineNum) - 1) / 2 * spaceX
	local startY = 550

	for i, one in ipairs(oneStack) do
		local x = startX + blockX * spaceX
		local y = startY - blockY * spaceY
		blockX = blockX + 1

		if lineNum <= blockX then
			blockX = 0
			blockY = blockY + 1
		end

		if one.isNew then
			one.isNew = nil

			one:setPosition(x, y + 100)
			transition.fadeTo(one, {
				easing = "sineOut",
				opacity = 255,
				time = 0.2
			})
		end

		local currentX = one:getPositionX()
		local currentY = one:getPositionY()

		one:setPosition((x - currentX) / 2 + currentX, (y - currentY) / 2 + currentY)

		if not one.removed and one.stayTime < nowTime - one.createTime then
			one.removed = true

			table.insert(removeArr, one)
		end
	end

	for i, one in ipairs(removeArr) do
		transition.fadeTo(one, {
			easing = "sineOut",
			opacity = 0,
			time = 0.2,
			onComplete = function ()
				for j, v in ipairs(oneStack) do
					if v == one then
						table.remove(oneStack, j)
					end
				end

				one:removeSelf()
			end
		})
	end

	if #oneStack == 0 then
		self:removeEnterFrame("arrange_loop")
	end
end

function POP_caution:onExit()
	self:removeEnterFrame("arrange_loop")
	POP_caution.super.onExit(self)
end

return POP_caution
