local Shader = {}
local UNIFORM_TYPE = {
	FLOAT = 2,
	INT = 1,
	TEXTURE = 6,
	VEC4 = 5,
	VEC3 = 4,
	VEC2 = 3
}

local function setInnerShader(node, name)
	if tolua.isnull(node) then
		return
	end

	if not node.setGLProgramState then
		return
	end

	node:setGLProgramState(cc.GLProgramState:getOrCreateWithGLProgramName(name))
end

local function setCustomShader(node, name, params, vshName)
	if tolua.isnull(node) then
		return
	end

	if not node.setGLProgramState then
		return
	end

	local customName = "custom_" .. name

	if params then
		for k, v in pairs(params) do
			customName = customName .. "_" .. k .. "_" .. v.type

			if type(v.value) == "table" then
				for _k, _v in pairs(v.value) do
					customName = customName .. "_" .. _k .. "_" .. tostring(_v)
				end
			else
				customName = customName .. "_" .. tostring(v.value)
			end
		end
	end

	local glprogram = cc.GLProgramCache:getInstance():getGLProgram(customName)
	local isNew = false

	if not glprogram then
		glprogram = cc.GLProgram:createWithFilenames(getFinalRes("shader/" .. (vshName or name) .. ".vsh"), getFinalRes("shader/" .. name .. ".fsh"))

		cc.GLProgramCache:getInstance():addGLProgram(glprogram, customName)

		isNew = true
	end

	if glprogram then
		local glprogramState = cc.GLProgramState:getOrCreateWithGLProgram(glprogram)

		if isNew and params then
			for k, v in pairs(params) do
				if v.type == UNIFORM_TYPE.INT then
					glprogramState:setUniformInt(k, v.value)
				elseif v.type == UNIFORM_TYPE.FLOAT then
					glprogramState:setUniformFloat(k, v.value)
				elseif v.type == UNIFORM_TYPE.VEC2 then
					glprogramState:setUniformVec2(k, v.value)
				elseif v.type == UNIFORM_TYPE.VEC3 then
					glprogramState:setUniformVec3(k, v.value)
				elseif v.type == UNIFORM_TYPE.VEC4 then
					glprogramState:setUniformVec4(k, v.value)
				elseif v.type == UNIFORM_TYPE.TEXTURE then
					glprogramState:setUniformTexture(k, v.value)
				end
			end
		end

		node:setGLProgramState(glprogramState)
	end
end

function Shader.custom(node, name, isRecursive)
	if tolua.isnull(node) then
		return
	end

	if isRecursive == nil then
		isRecursive = true
	end

	setCustomShader(node, name, nil, "default")

	if isRecursive and node.getChildren then
		local children = node:getChildren()

		for i, child in ipairs(children) do
			if tolua.type(child) ~= "cc.Label" then
				Shader.custom(child, name, isRecursive)
			end
		end
	end
end

function Shader.recover(node, isRecursive)
	if tolua.isnull(node) then
		return
	end

	if isRecursive == nil then
		isRecursive = true
	end

	setInnerShader(node, "ShaderPositionTextureColor_noMVP")

	if isRecursive and node.getChildren then
		local children = node:getChildren()

		for i, child in ipairs(children) do
			if tolua.type(child) ~= "cc.Label" then
				Shader.recover(child, isRecursive)
			end
		end
	end
end

function Shader.gray(node, isRecursive)
	if tolua.isnull(node) then
		return
	end

	if isRecursive == nil then
		isRecursive = true
	end

	setCustomShader(node, "gray", nil, "default")

	if isRecursive and node.getChildren then
		local children = node:getChildren()

		for i, child in ipairs(children) do
			if tolua.type(child) ~= "cc.Label" then
				Shader.gray(child, isRecursive)
			end
		end
	end
end

function Shader.highlight(node, lightness, isRecursive)
	if tolua.isnull(node) then
		return
	end

	if isRecursive == nil then
		isRecursive = true
	end

	setCustomShader(node, "highlight", {
		lightness = {
			type = UNIFORM_TYPE.FLOAT,
			value = lightness
		}
	}, "default")

	if isRecursive and node.getChildren then
		local children = node:getChildren()

		for i, child in ipairs(children) do
			if tolua.type(child) ~= "cc.Label" then
				Shader.highlight(child, lightness, isRecursive)
			end
		end
	end
end

function Shader.subtract(node, lightness, isRecursive)
	if tolua.isnull(node) then
		return
	end

	if isRecursive == nil then
		isRecursive = true
	end

	setCustomShader(node, "subtract", {
		lightness = {
			type = UNIFORM_TYPE.FLOAT,
			value = lightness
		}
	}, "default")

	if isRecursive and node.getChildren then
		local children = node:getChildren()

		for i, child in ipairs(children) do
			if tolua.type(child) ~= "cc.Label" then
				Shader.subtract(child, lightness, isRecursive)
			end
		end
	end
end

function Shader.linearGradient(node, isRecursive)
	if tolua.isnull(node) then
		return
	end

	if isRecursive == nil then
		isRecursive = true
	end

	if tolua.type(node) == "cc.Sprite" then
		setCustomShader(node, "gradient_linear", {
			u_startColor = {
				type = UNIFORM_TYPE.VEC4,
				value = cc.vec4(1, 1, 1, 1)
			},
			u_endColor = {
				type = UNIFORM_TYPE.VEC4,
				value = cc.vec4(0.5, 0.5, 0.5, 1)
			}
		}, "default")
	end

	if isRecursive and node.getChildren then
		local children = node:getChildren()

		for i, child in ipairs(children) do
			if tolua.type(child) ~= "cc.Label" then
				Shader.glow(child, isRecursive)
			end
		end
	end
end

function Shader.gradient(node, isRecursive)
	if tolua.isnull(node) then
		return
	end

	if isRecursive == nil then
		isRecursive = true
	end

	if tolua.type(node) == "cc.Sprite" then
		setCustomShader(node, "gradient", {
			u_startColor = {
				type = UNIFORM_TYPE.VEC4,
				value = cc.vec4(1, 1, 1, 1)
			},
			u_endColor = {
				type = UNIFORM_TYPE.VEC4,
				value = cc.vec4(0.5, 0.5, 0.5, 1)
			},
			u_center = {
				type = UNIFORM_TYPE.VEC2,
				value = cc.p(0.5, 0.5)
			},
			u_radius = {
				value = 0.5,
				type = UNIFORM_TYPE.FLOAT
			},
			u_expand = {
				value = 0.1,
				type = UNIFORM_TYPE.FLOAT
			}
		}, "default")
	end

	if isRecursive and node.getChildren then
		local children = node:getChildren()

		for i, child in ipairs(children) do
			if tolua.type(child) ~= "cc.Label" then
				Shader.glow(child, isRecursive)
			end
		end
	end
end

function Shader.blur(node, isRecursive, resolution, blurRadius, sampleNum)
	if tolua.isnull(node) then
		return
	end

	if isRecursive == nil then
		isRecursive = true
	end

	if tolua.type(node) == "cc.Sprite" then
		setCustomShader(node, "blur", {
			resolution = {
				type = UNIFORM_TYPE.VEC2,
				value = cc.p(resolution or 100, resolution or 100)
			},
			blurRadius = {
				type = UNIFORM_TYPE.FLOAT,
				value = blurRadius or 10
			},
			sampleNum = {
				type = UNIFORM_TYPE.FLOAT,
				value = sampleNum or 5
			}
		}, "default")
	end

	if isRecursive and node.getChildren then
		local children = node:getChildren()

		for i, child in ipairs(children) do
			if tolua.type(child) ~= "cc.Label" then
				Shader.blur(child, isRecursive, step, strength)
			end
		end
	end
end

function Shader.glow(node, isRecursive, c4b, radius, ctime, threshold)
	if tolua.isnull(node) then
		return
	end

	if isRecursive == nil then
		isRecursive = true
	end

	ctime = ctime or 1
	threshold = threshold or 1
	radius = radius or 5
	local color = nil
	color = (not c4b or cc.vec4(c4b.r / 255, c4b.g / 255, c4b.b / 255, (c4b.a or 255) / 255)) and cc.vec4(0.5, 0.5, 0.5, 1)

	dump(color, "$$$ color")

	if tolua.type(node) == "cc.Sprite" then
		setCustomShader(node, "glow", {
			u_ctime = {
				type = UNIFORM_TYPE.FLOAT,
				value = ctime
			},
			u_threshold = {
				type = UNIFORM_TYPE.FLOAT,
				value = threshold
			},
			u_radius = {
				type = UNIFORM_TYPE.FLOAT,
				value = radius
			},
			u_outlineColor = {
				type = UNIFORM_TYPE.VEC4,
				value = color
			}
		}, "default")
	end

	if isRecursive and node.getChildren then
		local children = node:getChildren()

		for i, child in ipairs(children) do
			if tolua.type(child) ~= "cc.Label" then
				Shader.glow(child, isRecursive, c4b, radius, ctime, threshold)
			end
		end
	end
end

function Shader.innerGlow(node, isRecursive)
	if tolua.isnull(node) then
		return
	end

	if isRecursive == nil then
		isRecursive = true
	end

	if tolua.type(node) == "cc.Sprite" then
		setCustomShader(node, "inner_glow", {
			u_sampler = {
				type = UNIFORM_TYPE.TEXTURE,
				value = node:getTexture():getName()
			},
			u_ctime = {
				value = 1,
				type = UNIFORM_TYPE.FLOAT
			},
			u_threshold = {
				value = 1,
				type = UNIFORM_TYPE.FLOAT
			},
			u_radius = {
				value = 1,
				type = UNIFORM_TYPE.FLOAT
			},
			u_outlineColor = {
				type = UNIFORM_TYPE.VEC4,
				value = cc.vec4(0, 0, 0, 1)
			}
		}, "default")
	end

	if isRecursive and node.getChildren then
		local children = node:getChildren()

		for i, child in ipairs(children) do
			if tolua.type(child) ~= "cc.Label" then
				Shader.innerGlow(child, isRecursive)
			end
		end
	end
end

return Shader
