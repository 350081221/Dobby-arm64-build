local UI_base = import(".UI_base")
local FRAME_main_bard = class("FRAME_main_bard", UI_base)

function FRAME_main_bard:ctor(onPopChat)
	FRAME_main_bard.super.ctor(self, "frame_main_bard", UIManager.BIG_TYPE.BOTTOM)

	self.onPopChat = onPopChat

	self:init()
end

function FRAME_main_bard:init()
	self:initUI()

	if InfoDungeon.isCamp() then
		notify.safeRegister(self, "bard_listen", function (rcvData)
			self:onBardListen(rcvData)
		end)

		self.nextType = SheetUtil.getNumber("1:50;2:50000")
		self.changeTypePower = 0
		self.changeThrehold = {
			60,
			40
		}
		self.waitTime = math.random(300, 600)

		self:addEnterFrame("bardWait", function ()
			self:bardWaitLoop()
		end)
	end

	notify.safeRegister(self, "chat_add", function (arr, is_new)
		local data = arr[1]

		if data and is_new then
			pcall(self.addChat, self, data)
		end
	end)
	notify.safeRegister(self, "main_bard_refresh", function ()
		self:refreshChatSetup()
	end)
	self:refreshPosition()
	self:refreshChatSetup()
end

function FRAME_main_bard:setInitChat()
	if self.chatBar then
		return
	end

	local chatStack = OnlineChat.getStack()

	if #chatStack > 0 then
		local data = chatStack[#chatStack]

		if data then
			pcall(self.addChat, self, data)
		end
	end
end

function FRAME_main_bard:refreshChatSetup()
	local isOnlineChat = OnlineChat.isOnlineChat()
	local chatIcon = self:getComponentByTag("chat_icon")
	local bg = self:getComponentByTag("bg")

	chatIcon:setVisible(isOnlineChat == 1)

	if isOnlineChat == 1 then
		self:clearBard()
		bg:setVisible(true)
		transition.stopTarget(bg)
		transition.fadeTo(bg, {
			opacity = 255,
			time = 0.2,
			easing = "sineOut"
		})
		self:setInitChat()
	else
		self:removeChatBar()
		transition.stopTarget(bg)
		transition.fadeTo(bg, {
			opacity = 0,
			time = 0.2,
			easing = "sineOut",
			onComplete = function ()
				bg:setVisible(false)
			end
		})
	end
end

function FRAME_main_bard:getX(bottomX)
	if self.getBigWidth then
		local offsetX = bottomX - self:getBigWidth() / 2
		local bg = self:getComponentByTag("bg")

		return math.min(0, (offsetX - 210) * self:getBigScale()), bg.width
	else
		return bottomX
	end
end

function FRAME_main_bard:refreshPosition(bottomX, y)
	y = y or 0

	if bottomX then
		local x = self:getX(bottomX)

		self:setPosition(x, y)
	else
		self:setPosition(0, y)
	end
end

function FRAME_main_bard:addChat(data)
	local textArr = {}
	local styleArr = {}
	local style = {
		color = Style.font2
	}

	if not empty(data.user_info.nicklang) then
		style.lang = data.user_info.nicklang
		style.font = Localization.getFont(data.user_info.nicklang)
	end

	table.insert(textArr, data.user_info.nickname)
	table.insert(styleArr, style)
	table.insert(textArr, ":")
	table.insert(styleArr, {})

	if data.type == OnlineChat.TYPE.MSG then
		local style = {}

		if not empty(data.lang) then
			style.lang = data.lang
			style.font = Localization.getFont(data.lang)
		end

		table.insert(textArr, data.msg)
		table.insert(styleArr, style)
	elseif data.type == OnlineChat.TYPE.EMOJI then
		local emojiCSV = CsvParser.getCsvData("emoji", data.id, nil, true)

		if emojiCSV then
			local style = {
				color = Style.mana
			}

			table.insert(textArr, emojiCSV.name)
			table.insert(styleArr, style)
		end
	elseif data.type == OnlineChat.TYPE.BATTLE then
		local style = {
			color = Style.mana
		}

		table.insert(textArr, Localization.getSrcText("发起挑战邀请"))
		table.insert(styleArr, style)
	elseif data.type == OnlineChat.TYPE.BATTLE_REPLAY then
		local pack = json.decode(data.pack)
		local style = {}

		table.insert(textArr, Localization.getSrcText("挑战"))
		table.insert(styleArr, style)

		local style = {
			color = Style.mana
		}

		if not empty(data.lang) then
			style.lang = data.lang
			style.font = Localization.getFont(data.lang)
		end

		table.insert(textArr, pack.name2)
		table.insert(styleArr, style)
	elseif data.type == OnlineChat.TYPE.SONG then
		local itemCSV = CsvParser.getCsvData("item", data.id)
		local style = {
			color = Style.mana
		}

		table.insert(textArr, itemCSV.short_desc)
		table.insert(styleArr, style)
	elseif data.type == OnlineChat.TYPE.TOWER_ROOM then
		local towerCSV = CsvParser.getCsvData("tower", data.room_id)

		if towerCSV then
			local style = {
				color = Style.golden
			}

			table.insert(textArr, towerCSV.name)
			table.insert(styleArr, style)
		else
			return
		end
	elseif data.type == OnlineChat.TYPE.EQUIP then
		local pack = json.decode(data.pack)
		local qualityColor = InfoEquip.getQualityColor({
			base_id = pack.info[1],
			quality = pack.info[2],
			dust_id = pack.info[5]
		})
		local style = {
			color = qualityColor
		}

		if not empty(data.lang) then
			style.lang = data.lang
			style.font = Localization.getFont(data.lang)
		end

		table.insert(textArr, pack.name)
		table.insert(styleArr, style)
	elseif data.type == OnlineChat.TYPE.CARD then
		local pack = json.decode(data.pack)
		local cardCSV = CsvParser.getCsvData("card", pack.info[1])
		local qualityColor = InfoHero.getQualityColor(cardCSV.quality)
		local style = {
			color = qualityColor
		}

		if not empty(data.lang) then
			style.lang = data.lang
			style.font = Localization.getFont(data.lang)
		end

		table.insert(textArr, pack.name)
		table.insert(styleArr, style)
	elseif data.type == OnlineChat.TYPE.PET then
		local pack = json.decode(data.pack)
		local name, isDefault = InfoPet.getNameDefault({
			base_id = pack.info[1],
			name = pack.name
		})
		local qualityColor = InfoHero.getQualityColor(pack.info[2])
		local style = {
			color = qualityColor
		}

		if not isDefault and not empty(data.lang) then
			style.lang = data.lang
			style.font = Localization.getFont(data.lang)
		end

		table.insert(textArr, name)
		table.insert(styleArr, style)
	else
		local pack = json.decode(data.pack)
		local qualityColor = InfoHero.getQualityColor(pack.info[2])
		local style = {
			color = qualityColor
		}

		if not empty(data.lang) then
			style.lang = data.lang
			style.font = Localization.getFont(data.lang)
		end

		local name = pack.name

		if data.type == OnlineChat.TYPE.HERO then
			local pack = data.pack
			local _data = json.decode(pack)
			local _info = _data.info
			local heroInfo = {
				base_id = _info[1],
				quality = _info[2],
				level = _info[3],
				gender = _info[4],
				body = _info[5],
				hair = _info[6],
				equips = _info[7],
				name = _data.name
			}
			name = InfoHero.getName(heroInfo)
		end

		table.insert(textArr, name)
		table.insert(styleArr, style)
	end

	self:createChatBar(textArr, styleArr)
end

function FRAME_main_bard:removeChatBar()
	if self.chatBar then
		local bar = self.chatBar

		transition.fadeTo(bar, {
			opacity = 0,
			time = 0.2,
			easing = "sineOut",
			onComplete = function ()
				bar:removeSelf()
			end
		})

		self.chatBar = nil
	end
end

function FRAME_main_bard:createChatBar(textArr, styleArr)
	self:removeChatBar()

	local bar = UIManager.getUI("com_chat_bar")
	local flag = bar:getFlagByTag("flag_text")
	local newTextArr = {}
	local newStyleArr = {}

	table.insert(newTextArr, textArr[1])
	table.insert(newStyleArr, styleArr[1])
	table.insert(newTextArr, textArr[2])
	table.insert(newStyleArr, styleArr[2])

	local maxLen = flag.width / (flag.labelStyle.size or 20) * 2
	maxLen = maxLen - utf8.len(textArr[1])

	for i = 3, #textArr do
		local text = textArr[i]
		local style = styleArr[i]
		local len = utf8.len(text)

		for j = 1, len do
			table.insert(newTextArr, utf8.sub(text, j, j))
			table.insert(newStyleArr, style)

			if maxLen < #newTextArr then
				break
			end
		end
	end

	local labels, lines, totalWidth, totalHeight = bar:createLabelGroupOnFlag("flag_text", newTextArr, newStyleArr, {
		limitWidthText = "…",
		align = Style.left,
		limitWidth = flag.width
	})
	local flag = self:getFlagByTag("flag_bard")
	local x = flag.x + flag.width / 2
	local y = flag.y + flag.height / 2

	bar:setPosition(x, y - 30)
	bar:setOpacity(0)
	bar:setScale(0.8)
	transition.moveTo(bar, {
		time = 0.2,
		easing = "sineOut",
		y = y
	})
	transition.scaleTo(bar, {
		time = 0.2,
		easing = "sineOut",
		scale = 1
	})
	transition.fadeTo(bar, {
		opacity = 255,
		time = 0.2,
		easing = "sineOut"
	})
	self:addChild(bar, 100)

	self.chatBar = bar
end

function FRAME_main_bard:waitNext()
	self.waitTime = math.random(3600, 5400)
	self.changeTypePower = self.changeTypePower + math.random(30, 70)

	if self.changeThrehold[self.nextType] < self.changeTypePower then
		self.nextType = 3 - self.nextType
		self.changeTypePower = 0
	end
end

function FRAME_main_bard:bardWaitLoop()
	if Connection.getStat() ~= "connected" then
		return
	end

	if self.requestLocked then
		return
	end

	if self.waitTime <= 0 then
		self.rcvData = nil

		if self.nextType == 1 then
			self.requestLocked = true

			local function onRequestComplete()
				self.requestLocked = nil
			end

			InfoBard.listen(onRequestComplete, onRequestComplete)
		elseif self.nextType == 2 then
			local bardCSV = LinesManager.getBard(0, math.random(1, 65535))

			self:startText(bardCSV.text_2)
			self:waitNext()
		end
	else
		self.waitTime = self.waitTime - 1
	end
end

function FRAME_main_bard:initUI()
	local bg = self:getComponentByTag("bg")

	bg:setVisible(false)
	bg:setOpacity(0)
	bg:toTouchable()
	bg:addTap(function ()
		self:popDetail()
	end)
end

function FRAME_main_bard:popDetail(isBard)
	local isOnlineChat = OnlineChat.isOnlineChat()

	if isBard or isOnlineChat == 0 then
		if global.player then
			if not self.text then
				local bardCSV = LinesManager.getBard(0, math.random(1, 65535))

				if bardCSV then
					self.text = bardCSV.text_2
				end
			end

			if not self.text then
				print("没有吟游故事", self.text, self.rcvData)
			else
				FRAME_bard_detail.open(self.text, self.rcvData)
			end
		end
	else
		if not InfoGuide.isFin() then
			Alert.open(Localization.getSrcText("引导期间该功能无法使用"))

			return
		end

		local onPopChat = self.onPopChat

		if onPopChat then
			onPopChat(true)
		end

		FRAME_chat.open(function ()
			if onPopChat then
				onPopChat(false)
			end
		end)
	end
end

function FRAME_main_bard:onBardListen(rcvData)
	if empty(rcvData) then
		local bardCSV = LinesManager.getBard(0, math.random(1, 65535))

		self:startText(bardCSV.text_2)
		self:waitNext()

		return
	end

	local text = InfoBard.parseLong(rcvData)

	if text then
		self.rcvData = rcvData

		self:startText(text)
	end

	self:waitNext()
end

function FRAME_main_bard:playLines(id)
	local bardCSV = CsvParser.getCsvData("lines_bard", id)

	self:startText(bardCSV.text_2)
	self:waitNext()
end

function FRAME_main_bard:startText(text)
	self.text = text
	local texts = string.split(text, "\n")

	self:openTexts(texts)
end

local ySpace = 35
local maxLines = 1
local easingTime = 0.3
local intervalTime = 3
local outTime = 2

function FRAME_main_bard:openTexts(texts)
	self.texts = texts

	self:clearBard()

	local isOnlineChat = OnlineChat.isOnlineChat()

	if isOnlineChat == 0 then
		local bg = self:getComponentByTag("bg")

		bg:setVisible(true)
		transition.stopTarget(bg)
		transition.fadeTo(bg, {
			opacity = 255,
			time = 0.5,
			easing = "sineOut"
		})
	end

	self.textIndex = 1
	self.bars = {}
	self.stat = 0
	self.maxLoop = maxHeight

	self:addEnterFrame("textLoop", function ()
		self:textLoop()
	end)

	local npc = Npc.getInstance(MiscConfig.bard_npc)

	if npc then
		npc:setAction("talk")
	end
end

function FRAME_main_bard:closeTexts()
	local delay = outTime
	local bg = self:getComponentByTag("bg")

	transition.stopTarget(bg)
	bg:performWithDelay(function ()
		local npc = Npc.getInstance(MiscConfig.bard_npc)

		if npc then
			npc:setAction("idle")
			npc:removeSay()
		end

		local isOnlineChat = OnlineChat.isOnlineChat()

		if isOnlineChat == 0 then
			transition.fadeTo(bg, {
				opacity = 0,
				easing = "sineOut",
				time = easingTime,
				onComplete = function ()
					bg:setVisible(false)
				end
			})
		end
	end, delay)

	for i, bar in ipairs(self.bars) do
		transition.stopTarget(bar)
		transition.fadeTo(bar, {
			opacity = 0,
			easing = "sineOut",
			delay = delay,
			time = easingTime
		})
	end
end

function FRAME_main_bard:textLoop()
	if self.stat == 0 then
		local flag = self:getFlagByTag("flag_bard")
		local text = self.texts[self.textIndex]

		if text then
			local npc = Npc.getInstance(MiscConfig.bard_npc)

			if npc then
				npc:say(text)
			end

			local isOnlineChat = OnlineChat.isOnlineChat()

			if isOnlineChat == 0 then
				local bar = nil
				bar = self:createBardBar(text, function (intervalSum)
				end)

				bar:setPosition(flag.x + flag.width / 2, flag.y - ySpace / 2)
				bar:setOpacity(0)
				bar:setScale(0.8)
				self:addChild(bar, 100)
				table.insert(self.bars, bar)
			end
		end

		for i, bar in ipairs(self.bars) do
			local line = self.textIndex - i
			local percent = (maxLines - line) / maxLines
			local barY = flag.y + ySpace * math.pow(1 - percent, 0.7)
			local opacity = 255 * math.pow(percent, 3)
			local scale = 1 * math.pow(percent, 0.4)
			local time = easingTime

			if i == #self.bars then
				transition.moveTo(bar, {
					easing = "sineIn",
					time = time,
					y = barY
				})
				transition.scaleTo(bar, {
					easing = "sineOut",
					time = time,
					scale = scale
				})
			else
				transition.moveTo(bar, {
					easing = "sineOut",
					time = time,
					y = barY
				})
				transition.scaleTo(bar, {
					easing = "sineIn",
					time = time,
					scale = scale
				})
			end

			if opacity <= 0 then
				transition.fadeTo(bar, {
					easing = "sineOut",
					time = time,
					opacity = opacity,
					onComplete = function ()
						bar:setVisible(false)
					end
				})
			else
				transition.fadeTo(bar, {
					easing = "sineOut",
					time = time,
					opacity = opacity
				})
			end
		end

		self.textIndex = self.textIndex + 1
		self.statTime = Time.time() + intervalTime
		self.stat = 1
	elseif self.stat == 1 then
		if self.statTime < Time.time() then
			if self.textIndex > #self.texts then
				self:removeEnterFrame("textLoop")
				self:closeTexts()
			else
				self.stat = 0
			end
		end
	elseif self.stat == 2 then
		-- Nothing
	end
end

function FRAME_main_bard:removeBardBar()
end

function FRAME_main_bard:createBardBar(text, onComplete)
	local bar = UIManager.getUI("com_bard_bar")
	local flag = bar:getFlagByTag("flag_text")
	local ubbMap, labels, lines, totalWidth, totalHeight = bar:createUbbOnFlag("flag_text", text, {
		yspace = 15,
		align = Style.left_in_center,
		valign = Style.vtop
	})
	local fadeTime = 0.02
	local defaultInterval = 0.03
	local defaultLineInterval = 0.75

	if Localization.isAlphabet() then
		defaultInterval = defaultInterval / 2
	end

	bar:animateUbb(ubbMap, labels, fadeTime, defaultInterval, defaultLineInterval, onComplete)

	local bg = bar:getComponentByTag("bg")
	local bgWidth = totalWidth + (flag.originalX - bg.originalX) * 2

	bg:setSize(bgWidth)
	bg:setPos(-bgWidth / 2)

	return bar
end

function FRAME_main_bard:clearBard()
	self:removeEnterFrame("textLoop")
	self:removeEnterFrame("bardWait")

	if self.bars then
		for i, bar in ipairs(self.bars) do
			bar:removeSelf()
		end
	end

	self.bars = {}
end

function FRAME_main_bard:delayRemove()
	self:performWithDelay(function ()
		self:removeSelf()
	end, 0.1)
end

return FRAME_main_bard
