local MapUtils = class("MapUtils")

function MapUtils.getLos(map, la, lb)
	local dx = lb.x - la.x
	local dy = lb.y - la.y
	local x = la.x
	local y = la.y
	local ray = {}

	if dx == 0 then
		if dy > 0 then
			for y = la.y, lb.y do
				table.insert(ray, map:getTile(x, y))
			end
		else
			for y = la.y, lb.y, -1 do
				table.insert(ray, map:getTile(x, y))
			end
		end

		return ray
	end

	if dy == 0 then
		if dx > 0 then
			for x = la.x, lb.x do
				table.insert(ray, map:getTile(x, y))
			end
		else
			for x = la.x, lb.x, -1 do
				table.insert(ray, map:getTile(x, y))
			end
		end

		return ray
	end

	local k = dy / dx
	local e = -0.5

	if math.abs(k) < 1 then
		if dx > 0 and dy > 0 then
			table.insert(ray, map:getTile(x, y))

			for i = 0, dx - 1 do
				x = x + 1
				e = e + math.abs(k)

				table.insert(ray, map:getTile(x, y))

				if e >= 0 then
					y = y + 1
					e = e - 1

					table.insert(ray, map:getTile(x, y))
				end
			end

			return ray
		elseif dx > 0 and dy < 0 then
			table.insert(ray, map:getTile(x, y))

			for i = 0, dx - 1 do
				x = x + 1
				e = e + math.abs(k)

				table.insert(ray, map:getTile(x, y))

				if e >= 0 then
					y = y - 1
					e = e - 1

					table.insert(ray, map:getTile(x, y))
				end
			end

			return ray
		elseif dx < 0 and dy < 0 then
			table.insert(ray, map:getTile(x, y))

			for i = 0, -dx - 1 do
				x = x - 1
				e = e + math.abs(k)

				table.insert(ray, map:getTile(x, y))

				if e >= 0 then
					y = y - 1
					e = e - 1

					table.insert(ray, map:getTile(x, y))
				end
			end

			return ray
		elseif dx < 0 and dy > 0 then
			table.insert(ray, map:getTile(x, y))

			for i = 0, -dx - 1 do
				x = x - 1
				e = e + math.abs(k)

				table.insert(ray, map:getTile(x, y))

				if e >= 0 then
					y = y + 1
					e = e - 1

					table.insert(ray, map:getTile(x, y))
				end
			end

			return ray
		end

		return
	elseif dx > 0 and dy > 0 then
		table.insert(ray, map:getTile(x, y))

		for i = 0, dy - 1 do
			y = y + 1
			e = e + 1 / math.abs(k)

			table.insert(ray, map:getTile(x, y))

			if e >= 0 then
				x = x + 1
				e = e - 1

				table.insert(ray, map:getTile(x, y))
			end
		end

		return ray
	elseif dx < 0 and dy < 0 then
		table.insert(ray, map:getTile(x, y))

		for i = 0, -dy - 1 do
			y = y - 1
			e = e + 1 / math.abs(k)

			table.insert(ray, map:getTile(x, y))

			if e >= 0 then
				x = x - 1
				e = e - 1

				table.insert(ray, map:getTile(x, y))
			end
		end

		return ray
	elseif dx > 0 and dy < 0 then
		table.insert(ray, map:getTile(x, y))

		for i = 0, -dy - 1 do
			y = y - 1
			e = e + 1 / math.abs(k)

			table.insert(ray, map:getTile(x, y))

			if e >= 0 then
				x = x + 1
				e = e - 1

				table.insert(ray, map:getTile(x, y))
			end
		end

		return ray
	elseif dx < 0 and dy > 0 then
		table.insert(ray, map:getTile(x, y))

		for i = 0, dy - 1 do
			y = y + 1
			e = e + 1 / math.abs(k)

			table.insert(ray, map:getTile(x, y))

			if e >= 0 then
				x = x - 1
				e = e - 1

				table.insert(ray, map:getTile(x, y))
			end
		end

		return ray
	end
end

function MapUtils.findCampfireSeat(unit, centerTile, exceptMap)
	local neibourOffsets = {
		{
			y = 0,
			x = -1
		},
		{
			y = 0,
			x = 1
		},
		{
			y = -1,
			x = 0
		},
		{
			y = 1,
			x = 0
		}
	}

	local function checkNeibour(_tile)
		if exceptMap[_tile.tag] then
			return false
		end

		for i, offset in ipairs(neibourOffsets) do
			if _tile.x + offset.x == centerTile.x and _tile.y + offset.y == centerTile.y then
				return true
			end
		end

		return false
	end

	if checkNeibour(unit.tile) then
		return true
	else
		local path, pathFound = unit.map:findPath(unit.tile, centerTile, unit.walkLevel, unit.size, function (tile)
			return checkNeibour(tile)
		end, unit)

		return path
	end
end

function MapUtils.spreadAreaForCampfire(map, centerTile, emptyRange, range, mhdRange)
	local openMap = {}
	local heap = {}
	local areaTiles = {}
	local borderTiles = {}

	table.insert(heap, centerTile)
	table.insert(areaTiles, centerTile)

	openMap[centerTile.tag] = true
	mhdRange = mhdRange or 65535
	range = range or 65535
	local walkLevel = 0
	local neibourOffsets = {
		{
			y = 0,
			x = -1
		},
		{
			y = 0,
			x = 1
		},
		{
			y = -1,
			x = 0
		},
		{
			y = 1,
			x = 0
		}
	}
	local borderOffsets = {
		2,
		0,
		1,
		3
	}

	local function addHeap(tile, out)
		for i = 1, #neibourOffsets do
			local neibour = map:getTile(tile.x + neibourOffsets[i].x, tile.y + neibourOffsets[i].y)

			if neibour ~= nil and openMap[neibour.tag] == nil and neibour:getVisible() then
				if not out and neibour:getWalk() <= walkLevel and math.abs(neibour.x - centerTile.x) <= range and math.abs(neibour.y - centerTile.y) <= range and math.abs(neibour.x - centerTile.x) + math.abs(neibour.y - centerTile.y) <= mhdRange then
					if walkLevel > 0 or not neibour:getBorder(borderOffsets[i]) then
						local isClear = true

						for m = -emptyRange, emptyRange do
							for n = -emptyRange, emptyRange do
								local x = neibour.x + m
								local y = neibour.y + n
								local _tile = map:getTile(x, y)

								if not _tile or walkLevel < _tile:getWalk() then
									isClear = false

									break
								end
							end
						end

						table.insert(heap, neibour)

						openMap[neibour.tag] = true

						if isClear then
							table.insert(areaTiles, neibour)
						end
					end
				else
					table.insert(borderTiles, neibour)

					openMap[neibour.tag] = true
				end
			end
		end
	end

	while #heap > 0 do
		local current = table.remove(heap, 1)

		addHeap(current)
	end

	return areaTiles, borderTiles
end

function MapUtils.spreadArea(map, centerTile, range, mhdRange, walkLevel, noNeedVisible)
	local openMap = {}
	local heap = {}
	local areaTiles = {}
	local borderTiles = {}
	local areaTileMap = {}

	table.insert(heap, centerTile)
	table.insert(areaTiles, centerTile)

	openMap[centerTile.tag] = true
	mhdRange = mhdRange or 65535
	range = range or 65535
	walkLevel = walkLevel or 0
	local neibourOffsets = {
		{
			y = 0,
			x = -1
		},
		{
			y = 0,
			x = 1
		},
		{
			y = -1,
			x = 0
		},
		{
			y = 1,
			x = 0
		}
	}
	local borderOffsets = {
		2,
		0,
		1,
		3
	}

	local function addHeap(tile, out)
		for i = 1, #neibourOffsets do
			local neibour = map:getTile(tile.x + neibourOffsets[i].x, tile.y + neibourOffsets[i].y)

			if neibour ~= nil and openMap[neibour.tag] == nil and (noNeedVisible or neibour:getVisible()) then
				if not out and neibour:getWalk() <= walkLevel and math.abs(neibour.x - centerTile.x) <= range and math.abs(neibour.y - centerTile.y) <= range and math.abs(neibour.x - centerTile.x) + math.abs(neibour.y - centerTile.y) <= mhdRange then
					if walkLevel > 0 or not neibour:getBorder(borderOffsets[i]) then
						table.insert(heap, neibour)
						table.insert(areaTiles, neibour)

						areaTileMap[neibour.tag] = true
						openMap[neibour.tag] = true
					end
				else
					table.insert(borderTiles, neibour)

					openMap[neibour.tag] = true
				end
			end
		end
	end

	while #heap > 0 do
		local current = table.remove(heap, 1)

		addHeap(current)
	end

	local openMap = {}
	local heap = {}
	local outTiles = {}

	table.insert(heap, centerTile)

	openMap[centerTile.tag] = true

	local function addOutheap(tile, out)
		for i = 1, #neibourOffsets do
			local neibour = map:getTile(tile.x + neibourOffsets[i].x, tile.y + neibourOffsets[i].y)

			if neibour ~= nil and openMap[neibour.tag] == nil then
				openMap[neibour.tag] = true

				if noNeedVisible or neibour:getVisible() then
					table.insert(heap, neibour)
				end

				if not areaTileMap[neibour.tag] then
					table.insert(outTiles, neibour)
				end
			end
		end
	end

	while #heap > 0 do
		local current = table.remove(heap, 1)

		addOutheap(current)
	end

	return areaTiles, outTiles, borderTiles
end

function MapUtils.rectArea(map, centerTile, xRange, yRange)
	local areaX, areaY = nil

	if map.topType == Map.TOP_90 then
		areaX = centerTile.x
		areaY = centerTile.y
	else
		areaX = centerTile.x - centerTile.y + map.areaWidth / 2
		areaY = centerTile.x + centerTile.y
	end

	local tiles = {}

	for x = areaX - xRange, areaX + xRange do
		for y = areaY - yRange, areaY + yRange do
			if y % 2 == 0 then
				local drawX = math.floor(y / 2 + (x - map.areaWidth / 2) / 2)
				local drawY = math.floor(y / 2 - (x - map.areaWidth / 2) / 2)
				tile = map:getTile(drawX, drawY)

				if tile then
					table.insert(tiles, tile)
				end
			end
		end
	end

	local borderTiles = {}

	for x = areaX - xRange - 1, areaX + xRange + 1, xRange * 2 + 2 do
		for y = areaY - yRange, areaY + yRange do
			local drawX = math.floor(y / 2 + (x - map.areaWidth / 2) / 2)
			local drawY = math.floor(y / 2 - (x - map.areaWidth / 2) / 2)
			tile = map:getTile(drawX, drawY)

			if tile then
				table.insert(borderTiles, tile)
			end
		end
	end

	for x = areaX - xRange, areaX + xRange do
		for y = areaY - yRange - 1, areaY + yRange + 1, yRange * 2 + 2 do
			local drawX = math.floor(y / 2 + (x - map.areaWidth / 2) / 2)
			local drawY = math.floor(y / 2 - (x - map.areaWidth / 2) / 2)
			tile = map:getTile(drawX, drawY)

			if tile then
				table.insert(borderTiles, tile)
			end
		end
	end

	return tiles, borderTiles
end

function MapUtils.dirtyRect(dirtyX, dirtyY, minX, maxX, minY, maxY, func, refresh, yEven)
	local limit = nil

	if refresh or dirtyX > 0 then
		if refresh then
			limit = minX
		else
			limit = math.max(minX, maxX - dirtyX + 1)
		end

		for i = maxX, limit, -1 do
			if yEven then
				for j = math.ceil(minY / 2) * 2, maxY, 2 do
					func(i, j)
				end
			else
				for j = minY, maxY do
					func(i, j)
				end
			end
		end

		maxX = limit - 1
	elseif dirtyX < 0 then
		limit = math.min(maxX, minX - dirtyX - 1)

		for i = minX, limit do
			if yEven then
				for j = math.ceil(minY / 2) * 2, maxY, 2 do
					func(i, j)
				end
			else
				for j = minY, maxY do
					func(i, j)
				end
			end
		end

		minX = limit + 1
	end

	if refresh or dirtyY > 0 then
		if refresh then
			limit = minY
		else
			limit = math.max(minY, maxY - dirtyY + 1)
		end

		for i = minX, maxX do
			if yEven then
				for j = math.floor(maxY / 2) * 2, limit, -2 do
					func(i, j)
				end
			else
				for j = maxY, limit, -1 do
					func(i, j)
				end
			end
		end
	elseif dirtyY < 0 then
		limit = math.min(maxY, minY - dirtyY - 1)

		for i = minX, maxX do
			if yEven then
				for j = math.ceil(minY / 2) * 2, limit, 2 do
					func(i, j)
				end
			else
				for j = minY, limit do
					func(i, j)
				end
			end
		end
	end
end

function MapUtils.compareRect(newRect, oldRect)
	local oldRectMap = {}

	if oldRect then
		for i = oldRect.x, oldRect.x + oldRect.width - 1 do
			for j = oldRect.y, oldRect.y + oldRect.height - 1 do
				oldRectMap[i .. "_" .. j] = {
					x = i,
					y = j
				}
			end
		end
	end

	local oldRectRetainMap = {}
	local newArr = {}
	local oldArr = {}

	if newRect then
		for i = newRect.x, newRect.x + newRect.width - 1 do
			for j = newRect.y, newRect.y + newRect.height - 1 do
				local tag = i .. "_" .. j

				if not oldRectMap[tag] then
					table.insert(newArr, {
						x = i,
						y = j
					})
				else
					oldRectRetainMap[tag] = true
				end
			end
		end
	end

	for tag, p in pairs(oldRectMap) do
		if not oldRectRetainMap[tag] then
			table.insert(oldArr, p)
		end
	end

	return newArr, oldArr
end

function MapUtils.setRelicDisable(map, centerTile, radius)
	for x = centerTile.x - radius, centerTile.x + radius do
		for y = centerTile.y - radius, centerTile.y + radius do
			local tile = map:getTile(x, y)
			tile.relicDisabled = true
		end
	end
end

function MapUtils.getRelicPositions(eventRect, seed, relics)
	local map = global.map
	local posArr = {}
	local centerX, centerY = map:tileToMap(eventRect.x, eventRect.y)
	centerX = centerX + map.ptPerTile * (eventRect.width - 1) / 2
	centerY = centerY + map.ptPerTile * (eventRect.height - 1) / 2
	local centerTileX = eventRect.x + math.floor((eventRect.width - 1) / 2)
	local centerTileY = eventRect.y + math.floor((eventRect.height - 1) / 2)
	local centerTile = map:getTile(centerTileX, centerTileY)

	if not centerTile then
		return {}
	end

	local range = 2
	local minX = centerTileX - range
	local minY = centerTileY - range
	local maxX = centerTileX + range
	local maxY = centerTileY + range

	if eventRect.width % 2 == 0 then
		maxX = maxX + 1
	end

	if eventRect.height % 2 == 0 then
		maxY = maxY + 1
	end

	local preNoUnitBlock = Map.NO_UNIT_BLOCK
	Map.NO_UNIT_BLOCK = true
	local preWalkOnVislble = Map.walkOnVislble
	Map.walkOnVislble = false
	local readyTiles = {}

	for tileX = minX, maxX do
		for tileY = minY, maxY do
			local tile = map:getTile(tileX, tileY)

			if tile and not tile.relicDisabled and tile:getWalkable(0) and not MapEventManager.checkTileHasTrigger(tile) then
				local path, pathFound = global.map:findPath(tile, centerTile, 0)

				if pathFound then
					local mapX, mapY = map:tileToMap(tileX, tileY)
					local distance = math.sqrt(math.pow(mapX - centerX, 2) + math.pow(mapY - centerY, 2))

					table.insert(readyTiles, {
						tile = tile,
						distance = distance
					})
				end
			end
		end
	end

	Map.NO_UNIT_BLOCK = preNoUnitBlock
	Map.walkOnVislble = preWalkOnVislble

	table.sort(readyTiles, function (a, b)
		return a.distance < b.distance
	end)

	local random = Random.new(seed)

	for i = 1, #relics do
		local ran = random:nextGauss()
		local index = math.floor(ran * #readyTiles) + 1
		local obj = table.remove(readyTiles, index)

		if not obj then
			break
		end

		local tile = obj.tile
		local mapX, mapY = map:tileToMap(tile)

		table.insert(posArr, {
			x = mapX,
			y = mapY
		})
	end

	return posArr
end

function MapUtils.tileMapToArr(tileMap)
	local tileArr = {}

	for k, tile in pairs(tileMap) do
		table.insert(tileArr, tile)
	end

	table.sort(tileArr, function (a, b)
		return a.sortTag < b.sortTag
	end)

	return tileArr
end

function MapUtils.preparePetBattle(areaTileMap, centerTile, playerTile, playerAngle)
	local axisAngle = GeomPlane.angle(centerTile.x, centerTile.y, playerTile.x, playerTile.y)
	local insectAngle = axisAngle + math.pi / 2
	local tiles = {}
	local maxScore = 0.1
	local _tiles = MapUtils.tileMapToArr(areaTileMap)

	for i, tile in ipairs(_tiles) do
		if tile:getWalkable(0) then
			local x, y = GeomPlane.intersect(centerTile.x, centerTile.y, axisAngle, tile.x, tile.y, insectAngle)
			local insectPt = cc.p(x, y)
			local insectDistance = GeomPlane.distance(insectPt.x, insectPt.y, tile.x, tile.y)
			local scoreAngle = GeomPlane.angle(centerTile.x, centerTile.y, insectPt.x, insectPt.y)
			local scoreDistance = GeomPlane.distance(centerTile.x, centerTile.y, insectPt.x, insectPt.y)
			local angleOffset = math.abs(scoreAngle - axisAngle)

			if math.pi < angleOffset then
				angleOffset = angleOffset - math.pi * 2
			end

			angleOffset = math.abs(angleOffset)

			if angleOffset > math.pi / 2 then
				scoreDistance = -scoreDistance
			end

			local score = scoreDistance
			local offsetScale = 1 + insectDistance

			table.insert(tiles, {
				score = score,
				tile = tile,
				offsetScale = offsetScale
			})

			maxScore = math.max(maxScore, score)
		end
	end

	for i, v in ipairs(tiles) do
		v.percent = v.score / maxScore
	end

	return tiles
end

function MapUtils.getPetBattle(tiles, percent)
	local bestTile, bestOffset = nil

	for i, v in ipairs(tiles) do
		if v.tile:isEmpty() then
			local percentOffset = math.abs(percent - v.percent) * v.offsetScale

			if not bestOffset or percentOffset < bestOffset then
				bestOffset = percentOffset
				bestTile = v.tile
			end
		end
	end

	return bestTile
end

local normalLight = nil

function MapUtils.getNormalLight()
	return normalLight
end

function MapUtils.focusIn(unit, onComplete, time, zoom, offset, isMoveFov, noHideUI, noLight)
	normalLight = nil

	if unit then
		if unit.action then
			if unit.type == "npc" and unit.npcType == Npc.TYPE.NPC then
				local lines = LinesManager.getNpcOpen(unit.data.id)

				if lines then
					unit:say(lines, 120)
				end
			end

			local centerX, centerY = unit:getCenter(obj)

			if offset then
				centerX = centerX + (offset.x or 0)
				centerY = centerY + (offset.y or 0)
			end

			global.map:scrollTo(centerX, centerY)

			if isMoveFov then
				global.map:setFov(centerX, centerY)
			end

			unit:setCustomLight(0.7, 1.75)
			unit:draw()

			if global.player then
				global.player:faceTo(unit)
			end

			if not noLight then
				normalLight = {
					min = global.map.config.light.min,
					radius = global.map.config.light.radius
				}

				global.map:setConfig({
					light = {
						radius = 0.7,
						min = 0.2
					}
				})
			end
		else
			global.map:scrollTo(unit.x, unit.y)
		end
	end

	if not noHideUI then
		global.ui:setVisible(false)
	end

	if global.player then
		global.player:setGoDirectionLocked("map_focus_inout", true)
	end

	global.map:tweenViewZoom(zoom or 1.4, time or 20, onComplete, true)
	Unit.setFocusUnit(nil)
end

function MapUtils.focusOut(unit, onComplete, time, zoom, noFocusPlayer, fixZoom)
	if global.player then
		if not noFocusPlayer then
			global.map:scrollTo(global.player.x, global.player.y)
		end

		Unit.setFocusUnit(global.player, noFocusPlayer)
	end

	if unit and unit.clearCustomLight then
		unit:clearCustomLight()
	end

	if normalLight then
		global.map:setConfig({
			light = normalLight
		})
	end

	global.ui:setVisible(true)

	local function _onComplete()
		if onComplete then
			onComplete()
		end

		if global.player then
			global.player:setGoDirectionLocked("map_focus_inout", false)
		end
	end

	global.map:tweenViewZoom(zoom or 1, time or 20, _onComplete, not fixZoom)
end

local dropOccupiedItemMap = {}

function MapUtils.getDropTile(centerTile)
	if not dropOccupiedItemMap[centerTile:getTag()] then
		dropOccupiedItemMap[centerTile:getTag()] = true

		return centerTile
	end

	local range = 1

	local function sortMethod(a, b)
		return a.r < b.r
	end

	while range < 5 do
		local offsets = {
			{
				xb = 0,
				yb = 0,
				x = 1,
				y = range * 2
			},
			{
				xb = 1,
				y = 1,
				yb = 0,
				x = math.max(range * 2 - 2, 1)
			}
		}
		local tileArray = {}

		for l = 1, #offsets do
			local offset = offsets[l]

			for i = centerTile.x - range + offset.xb, centerTile.x + range - offset.xb, offset.x do
				for j = centerTile.y - range + offset.yb, centerTile.y + range - offset.yb, offset.y do
					local tile = global.map:getTile(i, j)

					if tile and tile:getWalk() == 0 and not dropOccupiedItemMap[tile:getTag()] then
						local minR = math.min(math.abs(i - centerTile.x), math.abs(j - centerTile.y))

						table.insert(tileArray, {
							r = minR,
							tile = tile
						})
					end
				end
			end
		end

		if #tileArray > 0 then
			table.sort(tileArray, sortMethod)

			local tile = tileArray[1].tile
			dropOccupiedItemMap[tile:getTag()] = true

			return tile
		end

		range = range + 1
	end
end

function MapUtils.startDropTile(tiles)
	dropOccupiedItemMap = {}

	if tiles then
		for i, tile in ipairs(tiles) do
			dropOccupiedItemMap[tile.tag] = true
		end
	end
end

function MapUtils.getBattleCenter(tile1, tile2)
	local los = MapUtils.getLos(global.map, tile1, tile2)

	if #los > 0 then
		local lineWalkable = true

		for i = 1, #los do
			local tile = los[i]

			if tile:getWalk() > 0 or tile:getBorderFull() then
				lineWalkable = false

				break
			end
		end

		if lineWalkable then
			return los[math.ceil(#los / 2)]
		end
	end

	return tile1
end

function MapUtils.getScreenOutTile(tileCenter, tileNear, border)
	local map = global.map
	border = border or 0

	local function checkBorder(tile)
		local mapX, mapY = map:tileToMap(tile)
		local screenX, screenY = map:mapToScreen(mapX, mapY)

		if screenX < -border or screenX > map.width + border or screenY < -border or screenY > map.height + border then
			return true
		end
	end

	local areaTiles = MapUtils.spreadArea(map, tileCenter)
	local bestTile, bestDistance = nil

	for i, tile in ipairs(areaTiles) do
		if checkBorder(tile) then
			local distanceCenter = math.sqrt(math.pow(tile.x - tileCenter.x, 2) + math.pow(tile.y - tileCenter.y, 2))
			local distanceNear = math.sqrt(math.pow(tile.x - tileNear.x, 2) + math.pow(tile.y - tileNear.y, 2))

			if distanceNear <= distanceCenter and (not bestDistance or distanceNear < bestDistance) then
				bestDistance = distanceNear
				bestTile = tile
			end
		end
	end

	return bestTile
end

function MapUtils.getPathTo(x, y)
	Map.walkOnVislble = false
	local resultPath = nil
	local unit = global.player
	local targetNpc, targetTile = nil
	targetTile = unit.map:mapToTile(x, y)
	local path, pathFound = unit.map:findPath(unit.tile, targetTile)

	if pathFound then
		resultPath = path
	end

	if not resultPath then
		local trainUnits = unit.train.units

		if #trainUnits > 0 then
			local preBlocks = {}

			for i = 1, #trainUnits do
				preBlocks[i] = trainUnits[i].isBlock
				trainUnits[i].isBlock = false
			end

			local path, pathFound = unit.map:findPath(unit.tile, targetTile)

			if pathFound then
				resultPath = path
			end

			for i = 1, #trainUnits do
				trainUnits[i].isBlock = preBlocks[i]
			end
		end
	end

	Map.walkOnVislble = true

	return resultPath
end

function MapUtils.getPathClose(x, y)
	Map.walkOnVislble = false
	local resultPath = nil
	local unit = global.player
	local targetNpc, targetTile = nil
	targetTile = unit.map:mapToTile(x, y)

	local function checkClose(tile)
		if math.abs(tile.x - targetTile.x) == 1 and tile.y == targetTile.y then
			return true
		elseif math.abs(tile.y - targetTile.y) == 1 and tile.x == targetTile.x then
			return true
		end
	end

	local path, pathFound = unit.map:findPath(unit.tile, targetTile, unit.walkLevel, unit.size, function (tile)
		return checkClose(tile)
	end, unit)

	if pathFound then
		resultPath = path
	end

	if not resultPath then
		local trainUnits = unit.train.units

		if #trainUnits > 0 then
			local preBlocks = {}

			for i = 1, #trainUnits do
				preBlocks[i] = trainUnits[i].isBlock
				trainUnits[i].isBlock = false
			end

			local path, pathFound = unit.map:findPath(unit.tile, targetTile, unit.walkLevel, unit.size, function (tile)
				return checkClose(tile)
			end, unit)

			if pathFound then
				resultPath = path
			end

			for i = 1, #trainUnits do
				trainUnits[i].isBlock = preBlocks[i]
			end
		end
	end

	Map.walkOnVislble = true

	return resultPath
end

function MapUtils.spreadAreaForDevice(map, centerTile, size, emptyRange, range, mhdRange)
	local function checkUnit(tile, unitMap)
		for k, unit in pairs(unitMap) do
			if unit.type == "npc" then
				return false
			end
		end

		return true
	end

	local openMap = {}
	local closeMap = {}
	local heap = {}
	local areaTiles = {}
	local borderTiles = {}

	table.insert(heap, centerTile)

	size = size or 0
	emptyRange = emptyRange or 0
	mhdRange = mhdRange or 65535
	range = range or 65535
	local walkLevel = 0
	local neibourOffsets = {
		{
			y = 0,
			x = -1
		},
		{
			y = 0,
			x = 1
		},
		{
			y = -1,
			x = 0
		},
		{
			y = 1,
			x = 0
		}
	}
	local borderOffsets = {
		2,
		0,
		1,
		3
	}

	local function addHeap(tile)
		if math.abs(tile.x - centerTile.x) <= range and math.abs(tile.y - centerTile.y) <= range and math.abs(tile.x - centerTile.x) + math.abs(tile.y - centerTile.y) <= mhdRange then
			if walkLevel > 0 or not tile:getBorder(borderOffsets[i]) then
				local isClear = true

				for m = -emptyRange, emptyRange + size - 1 do
					for n = -emptyRange, emptyRange + size - 1 do
						local x = tile.x + m
						local y = tile.y + n
						local _tile = map:getTile(x, y)

						if not _tile or not _tile:getWalkable(walkLevel, checkUnit) then
							isClear = false

							break
						end
					end
				end

				if isClear then
					table.insert(areaTiles, tile)
				end
			end
		else
			table.insert(borderTiles, tile)
		end

		closeMap[tile.tag] = true

		for i, neibourOffset in ipairs(neibourOffsets) do
			local neibour = map:getTile(tile.x + neibourOffset.x, tile.y + neibourOffset.y)

			if neibour and neibour:getVisible() and not openMap[neibour.tag] then
				openMap[neibour.tag] = true

				table.insert(heap, neibour)
			end
		end
	end

	while #heap > 0 do
		local current = table.remove(heap, 1)

		if not closeMap[current.tag] then
			addHeap(current)
		end
	end

	return areaTiles, borderTiles
end

function MapUtils.spreadFind(map, centerTile, checkFunc)
	local result = {}
	local openMap = {}
	local closeMap = {}
	local heap = {}

	table.insert(heap, centerTile)

	local mhdRange = 65535
	local range = 65535
	local walkLevel = 0
	local neibourOffsets = {
		{
			y = 0,
			x = -1
		},
		{
			y = 0,
			x = 1
		},
		{
			y = -1,
			x = 0
		},
		{
			y = 1,
			x = 0
		}
	}
	local borderOffsets = {
		2,
		0,
		1,
		3
	}

	local function addHeap(tile)
		if math.abs(tile.x - centerTile.x) <= range and math.abs(tile.y - centerTile.y) <= range and math.abs(tile.x - centerTile.x) + math.abs(tile.y - centerTile.y) <= mhdRange and checkFunc(tile) then
			table.insert(result, tile)
		end

		closeMap[tile.tag] = true

		for i, neibourOffset in ipairs(neibourOffsets) do
			local neibour = map:getTile(tile.x + neibourOffset.x, tile.y + neibourOffset.y)

			if neibour and neibour:getWalk() == 0 and not openMap[neibour.tag] then
				openMap[neibour.tag] = true

				table.insert(heap, neibour)
			end
		end
	end

	while #heap > 0 do
		local current = table.remove(heap, 1)

		if not closeMap[current.tag] then
			addHeap(current)
		end
	end

	return result
end

function MapUtils.findFrontTile(unit)
	local x = unit.tile.x
	local y = unit.tile.y
	local angle = unit.angle + math.pi / 4
	local td = 4
	local perA = math.pi * 2 / td
	local d = math.floor(angle / perA) + 3
	d = d % td

	if d == 0 then
		y = y + 1
	elseif d == 1 then
		x = x - 1
	elseif d == 2 then
		y = y - 1
	elseif d == 3 then
		x = x + 1
	end

	local tile = unit.map:getTile(x, y)

	if tile:getWalk() == 0 and tile:isEmpty() then
		return tile
	end
end

function MapUtils.spreadAreaForSafe(map, centerTile, checkUnit)
	local openMap = {}
	local heap = {}
	local areaTiles = {}

	table.insert(heap, centerTile)
	table.insert(areaTiles, centerTile)

	openMap[centerTile.tag] = true
	local preWalkOnVislble = Map.walkOnVislble
	Map.walkOnVislble = false
	local neibourOffsets = {
		{
			y = 0,
			x = -1
		},
		{
			y = 0,
			x = 1
		},
		{
			y = -1,
			x = 0
		},
		{
			y = 1,
			x = 0
		}
	}
	local borderOffsets = {
		2,
		0,
		1,
		3
	}

	local function checkNeibour(neibour, offsetIndex)
		if openMap[neibour.tag] == nil then
			if neibour:getWalkable(0, checkUnit, true) then
				if not offsetIndex or not neibour:getBorder(borderOffsets[offsetIndex]) then
					table.insert(heap, neibour)
					table.insert(areaTiles, neibour)

					openMap[neibour.tag] = true
				end
			else
				openMap[neibour.tag] = true
			end
		end
	end

	local function addHeap(tile)
		for i = 1, #neibourOffsets do
			local neibour = map:getTile(tile.x + neibourOffsets[i].x, tile.y + neibourOffsets[i].y)

			if neibour ~= nil then
				checkNeibour(neibour, i)
			end
		end

		local eventData = MapEventManager.getEventByTile(tile.x, tile.y, "teleport")

		if eventData then
			local finData = MapEventManager.findLinkOne(eventData, "teleport")

			if finData then
				local finTile = map:getTile(finData.x, finData.y)

				if finTile then
					checkNeibour(finTile)
				end
			end
		end
	end

	while #heap > 0 do
		local current = table.remove(heap, 1)

		addHeap(current)
	end

	Map.walkOnVislble = preWalkOnVislble

	return areaTiles
end

local safeAreaMap, safePreTile, safeEnterTile = nil

function MapUtils.markSafe(enterEvent)
	local map = global.map
	safeEnterTile = map:getTile(enterEvent.x, enterEvent.y)

	if safeEnterTile then
		local areaTiles = MapUtils.spreadAreaForSafe(map, safeEnterTile, global.player)

		print("MapUtils.markSafe", #areaTiles)

		safeAreaMap = {}

		for index, _tile in ipairs(areaTiles) do
			safeAreaMap[_tile.tag] = true
		end
	end
end

function MapUtils.checkSafe(tile)
	if tile and safeAreaMap then
		local isSafe = safeAreaMap[tile.tag]

		if isSafe then
			safePreTile = tile
		end

		return isSafe
	end

	return true
end

function MapUtils.recoverSafe()
	local tile = safePreTile or safeEnterTile

	if tile then
		local mapX, mapY = global.map:tileToMap(tile)

		global.player:draw(mapX, mapY, true)
		global.player:setGoDirectionLocked("enterDest", true)
		global.player:fillTrain()
		global.player:checkTrain()

		local units = global.player:getTrainUnits()

		for i, unit in ipairs(units) do
			local effectGen = unit:getEffectGen()

			if effectGen then
				effectGen:zmove(0, 500)
			end

			local function fall()
				local effectGen = unit:getEffectGen()

				if effectGen then
					if i == #units then
						effectGen:zmove(30, 0, nil, function ()
							MapEffect.quake()
							global.player:clearGoDirectionLocked()
						end)
					else
						effectGen:zmove(30, 0, nil, function ()
							MapEffect.quake()
						end)
					end
				end
			end

			MapFrameManager.setTimeout(fall, 10 * (i - 1))
		end
	end
end

function MapUtils.clearOnScene()
	safeAreaMap = nil
	safePreTile = nil
	safeEnterTile = nil
end

function MapUtils.findFreeTile(x, y, width, height)
	local map = global.map
	local arr = {}
	local tileMap = {}

	for i = x, x + width do
		for j = y, y + height do
			local tile = map:getTile(i, j)

			if tile and tile:getWalkable(0) then
				table.insert(arr, tile)

				tileMap[tile.tag] = true
			end
		end
	end

	return arr, tileMap
end

return MapUtils
