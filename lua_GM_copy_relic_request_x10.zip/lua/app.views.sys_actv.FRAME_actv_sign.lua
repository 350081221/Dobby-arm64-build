local UI_base = import("..UI_base")
local FRAME_actv_sign = class("FRAME_actv_sign", UI_base)

function FRAME_actv_sign.open(uiName, data, onClose)
	local ui = FRAME_actv_sign.new(uiName, data)

	PopManager.open(ui, nil, onClose)
end

function FRAME_actv_sign:ctor(uiName, data)
	self.data = data
	self.actv_id = data and data.actv_id
	local bigType = nil

	if not uiName then
		bigType = UIManager.BIG_TYPE.POP
	end

	FRAME_actv_sign.super.ctor(self, uiName or "frame_sign_week", bigType)
	self:init()
end

function FRAME_actv_sign:resetData(data)
	if data then
		self.actv_id = data.actv_id

		self:refresh()
	end
end

function FRAME_actv_sign:init()
	self:initUI()

	local data = InfoActvRecord.getData(self.actv_id)
	local pic_mask = self:getComponentByTag("pic_mask")

	pic_mask:setVisible(false)

	if data and not empty(data.pic) then
		local picURL = Localization.getTextByLang(data.pic)

		PicLoader.load(picURL, function (path)
			if pic_mask.setVisible then
				pic_mask:setVisible(true)
				self:createPicOnFlag("pic_mask", path, nil, UILayout.SCALE_TYPE.LARGE)
			end
		end)
	end

	local preTime = math.floor(Time.time())

	self:addEnterFrame("trySignLoop", function ()
		local nowTime = math.floor(Time.time())

		if preTime < nowTime then
			preTime = nowTime

			InfoActvRecord.trySign()
		end
	end)
	InfoActvRecord.trySign()
	self:refresh()
	ManagerInfo.onDataChange(self, "actv_record", nil, function ()
		self:refresh()
	end)
end

function FRAME_actv_sign:refresh()
	if self:getFlagByTag("flag_title") then
		local name = InfoActv.getName(self.actv_id)

		self:createLabelOnFlag("flag_title", name)
	end

	local dayArr = InfoActvRecord.getAwardList(self.actv_id)

	self.list:setItems(dayArr, true)
end

function FRAME_actv_sign:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local function tapListener(ui, data, index, x, y)
		local configData = data.config
		local actv_id = configData.actv_id
		local currentDay = InfoActvRecord.getCurrentDay(actv_id)

		if InfoActvRecord.checkRewarded(actv_id, index) or currentDay < index then
			DropManager.popDetail(DropManager.TYPE.ITEM, {
				base_id = data.id,
				num = data.num
			})
		elseif InfoActvRecord.checkSign(actv_id, index) then
			InfoActvRecord.getReward(index, configData.actv_id, false, function (rcvData)
				local rewards = rcvData.rewards

				if rewards and #rewards > 0 then
					POP_reward.openMixed(rewards, nil, Localization.getSrcText("签到奖励"))
				end
			end)
		elseif configData.is_recover == 1 then
			local cost = configData.cost[index]

			FRAME_actv_sign_detail.open({
				base_id = data.id,
				num = data.num
			}, {
				base_id = cost.id,
				num = cost.num
			}, index, actv_id)
		else
			DropManager.popDetail(DropManager.TYPE.ITEM, {
				base_id = data.id,
				num = data.num
			})
		end
	end

	self.list = self:createListOnFlag("flag_list", LIST_sign_week, tapListener)

	self.list:setTapGroup("list_click")

	local flag = self:getFlagByTag("flag_list")

	self.list:setCellSize(cc.size(math.floor(flag.width / 7), flag.height))
end

return FRAME_actv_sign
