local NAV_base = import(".NAV_base")
local NAV_union_center = class("NAV_union_center", NAV_base)

function NAV_union_center.open(npc)
	local ui = NAV_union_center.new(npc)

	return ui
end

function NAV_union_center:ctor(npc)
	NAV_union_center.super.ctor(self, npc, "nav_union_center")
end

function NAV_union_center:init()
	NAV_union_center.super.init(self)
	self:refresh()
	ManagerInfo.onDataChange(self, "union", nil, function ()
		self:refresh()
	end)
end

function NAV_union_center:refresh()
	local index = 2

	if InfoUnion.checkPower("lvup_building") then
		self:setButtonVisible(index, true)
		self:setBuildingLvupIndex(index, true)
	else
		self:setButtonVisible(index, false)
	end
end

function NAV_union_center:onTap(index)
	NAV_union_center.super.onTap(self, index)

	if index == 1 then
		local unionID = InfoUnion.getUnionID()

		FRAME_union_info.open(unionID, true, FRAME_union_info.TYPE.MY)
	elseif index == 3 then
		POP_msg.open(Localization.getLoneText("NAV_union_center"), {
			size = 20,
			align = Style.left
		}, true)
	end
end

return NAV_union_center
