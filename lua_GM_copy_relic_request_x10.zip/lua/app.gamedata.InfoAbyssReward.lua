local InfoAbyssReward = {}
local rawData = nil

function InfoAbyssReward.init()
	Connection.listen("abyss_reward_sync", InfoAbyssReward.sync)
end

app:addToAppEnterCall(InfoAbyssReward.init)

function InfoAbyssReward.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoAbyssReward.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("abyss_reward_query", callback)
end

function InfoAbyssReward.onQuery(rcvData)
	rawData = rcvData
end

function InfoAbyssReward.sync(syncData)
	for k, v in pairs(syncData) do
		rawData[k] = v
	end

	ManagerInfo.dataChange("abyss_reward")
end

function InfoAbyssReward.getReward(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "abyss_reward_get_reward")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("abyss_reward_get_reward", callback)
end

function InfoAbyssReward.hasReward()
	local abyssLevel = InfoDungeon.getAbyssMaxLevel()
	local csvRaw = CsvParser.getCsvRaw("abyss_reward")

	for k, v in pairs(csvRaw) do
		if rawData.already_id < v.id and v.id <= abyssLevel then
			return true
		end
	end

	return false
end

function InfoAbyssReward.getAreaOpened()
	local currentID = rawData.area_id
	local csvList = CsvParser.getCsvList("abyss_area")
	local maxOpenedID = 0

	for i, csv in ipairs(csvList) do
		if currentID < csv.id and not empty(csv.open_item) then
			break
		end

		maxOpenedID = csv.id
	end

	return maxOpenedID
end

function InfoAbyssReward.openArea(areaID, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "abyss_reward_open_area")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("abyss_reward_open_area", {
		area_id = areaID
	}, callback)
end

function InfoAbyssReward.getBuildingMax()
	local currentID = math.max(1, rawData.area_id)
	local worldID = InfoWorld.getAbyssArea()
	local csv = CsvParser.getCsvData("abyss_area", math.min(currentID, worldID))

	print("$$$ getBuildingMax", currentID, worldID, csv.building_max, CONFIG.isNeo)

	if CONFIG.isNeo then
		return csv.building_max_neo
	else
		return csv.building_max
	end
end

function InfoAbyssReward.getPeakMax()
	local worldID = InfoWorld.getAbyssArea()
	local csv = CsvParser.getCsvData("abyss_area", worldID)

	if not empty(csv.hero_peak_level_max) then
		return csv.hero_peak_level_max
	end
end

function InfoAbyssReward.getPeakMaxOpen()
	local csvList = CsvParser.getCsvList("abyss_area")

	for i, csv in ipairs(csvList) do
		if not empty(csv.hero_peak_level_max) then
			return csv
		end
	end
end

function InfoAbyssReward.getPeakMaxPet()
	local worldID = InfoWorld.getAbyssArea()
	local csv = CsvParser.getCsvData("abyss_area", worldID)

	if not empty(csv.pet_peak_level_max) then
		return csv.pet_peak_level_max
	end
end

function InfoAbyssReward.getPeakMaxOpenPet()
	local csvList = CsvParser.getCsvList("abyss_area")

	for i, csv in ipairs(csvList) do
		if not empty(csv.pet_peak_level_max) then
			return csv
		end
	end
end

function InfoAbyssReward.getArtifactMax()
	local worldID = InfoWorld.getAbyssArea()
	local csv = CsvParser.getCsvData("abyss_area", worldID)
	local levelMax = 0
	local starMax = 0

	if not empty(csv.artifact_level_max) then
		levelMax = csv.artifact_level_max
	end

	if not empty(csv.artifact_star_max) then
		starMax = csv.artifact_star_max
	end

	return levelMax, starMax
end

return InfoAbyssReward
