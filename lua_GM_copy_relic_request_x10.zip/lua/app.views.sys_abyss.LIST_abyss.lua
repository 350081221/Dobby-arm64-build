local List = import("...ui.List")
local LIST_abyss = class("LIST_abyss", List)

function LIST_abyss:ctor(rect, isWide)
	LIST_abyss.super.ctor(self, rect)

	self.isWide = isWide
	self.noEmptyText = true
	local uiName = self.isWide and "cell_abyss_l" or "cell_abyss"

	self:setCellName(uiName)
	self:setSpace(5, 5)
	self:setCellSize(cc.size(self.touchRect.width, 110))
end

function LIST_abyss:getCellName(index)
	local data = self.items[index]

	if data.isSkip then
		return self.isWide and "cell_abyss_skip_l" or "cell_abyss_skip"
	elseif data.isBoss then
		return self.isWide and "cell_abyss_boss_l" or "cell_abyss_boss"
	elseif data.isAkasa then
		return self.isWide and "cell_abyss_akasa_l" or "cell_abyss_akasa"
	else
		return self.isWide and "cell_abyss_l" or "cell_abyss"
	end
end

function LIST_abyss:getCellSize(index)
	local data = self.items[index]

	if data.isSkip then
		return cc.size(self.touchRect.width, 60)
	elseif data.isBoss then
		return cc.size(self.touchRect.width, 130)
	else
		return cc.size(self.touchRect.width, 110)
	end
end

function LIST_abyss:onCellInit(ui, data, index)
	if data.isSkip then
		local icon = ui:getComponentByTag("icon")

		icon:setColor(Style.font1)

		return
	end

	local csv = data.csv
	local _selected = ui:getComponentByTag("selected")

	if not InfoGuide.isFin() and index == 1 then
		_selected:setVisible(true)
		Style.makeShining(_selected, nil, , 0.6)
	else
		_selected:setVisible(false)
		transition.stopTarget(_selected)
	end

	local areaCSV = CsvParser.getCsvData("abyss_area", data.areaID)

	ui:removeLabelOnFlag("flag_name")
	ui:removeLabelOnFlag("label_mine")

	if data.isBoss then
		ui:createLabelOnFlag("flag_name", csv.name)
		ui:createLabelOnFlag("flag_boss_name", areaCSV.boss_name)
		ui:createIconOnFlag("flag_icon", IconManager.getAbyssAreaIcon(areaCSV.id), 100, true)
	elseif data.isAkasa then
		ui:createLabelOnFlag("flag_name", csv.name)

		local group = InfoDungeon.getAbyssGroup(csv)

		ui:replaceLabelOnFlag("flag_layers", nil, #group - 1)
	else
		ui:createLabelOnFlag("flag_name", csv.name)

		if areaCSV then
			ui:replaceLabelOnFlag("flag_area", nil, areaCSV.name, data.areaIndex)
		else
			ui:removeLabelOnFlag("flag_area")
		end

		local group = InfoDungeon.getAbyssGroup(csv)
		local mineCount = 0
		local mineAlready = 0

		for i, abyssData in ipairs(group) do
			if abyssData and not empty(abyssData.mine_index) then
				if InfoFurnace.getMineRecord(abyssData.mine_index) > 0 then
					mineAlready = mineAlready + 1
				end

				mineCount = mineCount + 1
			end
		end

		local mine_icon = ui:getComponentByTag("mine_icon")

		mine_icon:setVisible(mineCount > 0)

		if mineCount > 0 then
			local text = ui:getFlagByTag("label_mine").text

			if mineCount <= mineAlready then
				Shader.recover(mine_icon)
				mine_icon:setOpacity(255)
				Style.makeShining(mine_icon, 1000, 255, 60, 60)

				if text then
					ui:createLabelOnFlag("label_mine", text, {
						color = Style.enableColor
					})
				end
			else
				Shader.gray(mine_icon)
				transition.stopTarget(mine_icon)
				mine_icon:setOpacity(150)

				if text then
					ui:createLabelOnFlag("label_mine", text, {
						color = Style.disableColor
					})
				end
			end
		end
	end
end

return LIST_abyss
