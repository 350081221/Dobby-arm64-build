local PortraitManager = {}
local TYPE = {
	MUGSHOT = 1,
	CENTER = 3,
	STANDING = 2
}
local infoCache = {}

local function getAvatarKeyFromInfo(info, dataName, type)
	local data = CsvParser.getCsvData(dataName, info.base_id)
	local avatarList = SheetUtil.getColumnListFull(data, {
		"avatar_index_",
		"avatar_id_"
	}, {
		"avatar",
		"value"
	})

	for i, v in ipairs(avatarList) do
		data[v.avatar] = v.value
	end

	local str = info.body or data.model

	for i = 1, #Unit.AVATAR_LAYERS do
		local avatarName = info["avatar_" .. i] or data["avatar_" .. i]

		if i == 1 then
			avatarName = info.hair or avatarName
		end

		if avatarName then
			str = str .. "_" .. i .. "-" .. avatarName
		end
	end

	if type == "gwar" then
		for i, pos in ipairs(GameConfig.display_equip_arr) do
			local equip = info["equip_" .. pos]

			if equip then
				str = str .. "_" .. equip
			end
		end
	end

	return str
end

local function getIcon(textureKey)
	local texture = cc.Director:getInstance():getTextureCache():getTextureForKey(textureKey)

	if texture then
		local finalScale = infoCache[textureKey]
		local sprite = display.newSprite(texture)

		sprite:setScale(finalScale)

		local node = display.newNode()

		node:setCascadeColorEnabled(true)
		node:setCascadeOpacityEnabled(true)
		node:addChild(sprite)
		node:setContentSize(sprite:getContentSize())

		return node
	end
end

local animationInfoCache = {}

local function getAnimationInfo(textureKey)
	if animationInfoCache[textureKey] then
		return animationInfoCache[textureKey].maxFrame, animationInfoCache[textureKey].frameSkip
	end
end

local function setAnimationInfo(textureKey, maxFrame, frameSkip)
	animationInfoCache[textureKey] = {
		maxFrame = maxFrame,
		frameSkip = frameSkip
	}
end

local function getIconByUnit(type, unit, size, realScale, angle, offset, force, textureKey, frame)
	frame = frame or 1
	angle = angle or 0
	offset = offset or {
		y = 0,
		x = 0
	}
	local width = size.width
	local height = size.height
	angle = angle * math.pi / 180
	local direction = unit:getDirection(angle)
	local directionZero = unit:getDirection(0)
	local portraitInfo = unit.portraitInfo
	realScale = realScale or portraitInfo.scale * width / 64
	local scale = math.min(6, math.max(1, math.round(realScale)))
	local finalScale = realScale / scale
	textureKey = textureKey or "Portrait#" .. type .. "_" .. unit:getAvatarKey() .. "_" .. width .. "_" .. height .. "_" .. scale .. "_" .. offset.x .. "_" .. offset.y .. "_" .. direction.d .. "_" .. direction.scale .. "_" .. frame
	infoCache[textureKey] = finalScale
	local texture = cc.Director:getInstance():getTextureCache():getTextureForKey(textureKey)

	if not texture or force then
		if texture then
			cc.Director:getInstance():getTextureCache():removeTextureForKey(textureKey)
		end

		local preX, preY = unit:getPosition()
		local preAngle = unit.angle
		local preColor = unit:getColor()
		local preVisible = unit:isVisible()
		local preOpacity = unit:getOpacity()

		unit:setColor(cc.c4b(255, 255, 255, 255))

		unit.angle = angle

		unit:setVisible(true)
		unit:setOpacity(255)

		local preAction = unit.action
		local preFrame = unit.frame
		local preScaleX = unit:getScaleX()
		local preScaleY = unit:getScaleY()
		local preExScale = unit.exScale

		unit:setExScale(1)
		unit:setScaleX(1 / (unit.mapScale or 1))
		unit:setScaleY(1 / (unit.mapScale or 1))

		if portraitInfo then
			if type == TYPE.MUGSHOT then
				unit:setPosition(math.floor(width / scale / finalScale / 2) + offset.x - portraitInfo.x * direction.scale * directionZero.scale, math.floor(height / scale / finalScale / 2) + offset.y + portraitInfo.y)
			elseif type == TYPE.STANDING then
				unit:setPosition(math.floor(width / scale / finalScale / 2) + offset.x, math.floor(height / scale / finalScale / 2) + offset.y)
			elseif type == TYPE.CENTER then
				unit:setPosition(math.floor((width / scale / finalScale - portraitInfo.x * direction.scale * directionZero.scale) / 2) + offset.x, math.floor((height / scale / finalScale + portraitInfo.y) / 2) + offset.y)
			end
		elseif type == TYPE.MUGSHOT then
			unit:setPosition(math.floor(width / scale / finalScale / 2) + offset.x, math.floor(height / scale / finalScale / 2 - unit.height + 8) + offset.y)
		elseif type == TYPE.STANDING then
			unit:setPosition(math.floor(width / scale / finalScale / 2) + offset.x, math.floor(height / scale / finalScale / 2) + offset.y)
		elseif type == TYPE.CENTER then
			unit:setPosition(math.floor(width / scale / finalScale / 2) + offset.x, math.floor(height / scale / finalScale - unit.height + 4) + offset.y)
		end

		unit:setFrame("idle", unit:getDirection(), frame)

		local preZ = unit.z
		unit.z = 0

		unit:setBmpY()

		if unit.setAvatarZ then
			unit:setAvatarZ(frame)
		end

		if unit.exShadow then
			unit.exShadow:setVisible(false)
		end

		if unit.exRotation3D then
			unit:setRotation3D(cc.Vertex3F(0, 0, 0))
		end

		local renderTexture = cc.RenderTexture:create(math.ceil(width / scale / finalScale), math.ceil(height / scale / finalScale))

		renderTexture:beginWithClear(1, 1, 1, 0)
		unit:visit()
		renderTexture:endToLua()

		local renderImage = renderTexture:newImage()
		local scaleImage = nil

		if scale > 1 then
			scaleImage = renderImage:xbrzScale(scale)
		else
			scaleImage = renderImage
		end

		texture = cc.Director:getInstance():getTextureCache():addImage(scaleImage, textureKey)

		texture:setAliasTexParameters()
		unit:setExScale(preExScale)
		unit:setPosition(preX, preY)
		unit:setColor(preColor)

		unit.angle = preAngle

		unit:setVisible(preVisible)
		unit:setOpacity(preOpacity)
		unit:setScaleX(preScaleX)
		unit:setScaleY(preScaleY)
		unit:setFrame(preAction, unit:getDirection(), preFrame)

		unit.z = preZ

		unit:setBmpY()

		if unit.setAvatarZ then
			unit:setAvatarZ()
		end

		if unit.exShadow then
			unit.exShadow:setVisible(true)
		end

		if unit.exRotation3D then
			unit:setRotation3D(cc.Vertex3F(unit.exRotation3D, 0, 0))
		end
	end

	local sprite = display.newSprite(texture)

	sprite:setScale(finalScale)

	local node = display.newNode()

	node:setCascadeColorEnabled(true)
	node:setCascadeOpacityEnabled(true)
	node:addChild(sprite)
	node:setContentSize(sprite:getContentSize())

	return node
end

function PortraitManager.getUnitMugshot(unit, size, scale, angle, offset, force)
	return getIconByUnit(TYPE.MUGSHOT, unit, size, scale, angle, offset, force)
end

function PortraitManager.getUnitStanding(unit, size, scale, angle, offset, force)
	return getIconByUnit(TYPE.STANDING, unit, size, scale, angle, offset, force)
end

function PortraitManager.getUnitMugshotAnimation(unit, size, scale, angle, offset, force, frame)
	return getIconByUnit(TYPE.MUGSHOT, unit, size, scale, angle, offset, force, nil, frame)
end

function PortraitManager.getUnitStandingAnimation(unit, size, scale, angle, offset, force, frame)
	return getIconByUnit(TYPE.STANDING, unit, size, scale, angle, offset, force, nil, frame)
end

function PortraitManager.getMixedMugshot(type, id, size, scale, angle, offset, isAnimation, customFrameSkip)
	if type == "npc" then
		return PortraitManager.getNpcMugshot(id, size, scale, angle, offset, isAnimation, customFrameSkip)
	elseif type == "pet" then
		return PortraitManager.getPetMugshot(id, size, scale, angle, offset, isAnimation, customFrameSkip)
	elseif type == "chance" then
		return PortraitManager.getChanceMugshot(id, size, scale, angle, offset, isAnimation, customFrameSkip)
	elseif type == "monster" then
		return PortraitManager.getMonsterMugshot(id, size, scale, angle, offset, isAnimation, customFrameSkip)
	end
end

function PortraitManager.getHeroGwarMugshot(heroInfo, size, scale, angle, offset, isAnimation, customFrameSkip)
	scale = scale or 3
	angle = angle or 0
	offset = offset or {
		y = 0,
		x = 0
	}
	local width = size.width
	local height = size.height

	if isAnimation then
		local maxFrame, frameSkip = getAnimationInfo()
		local unit = nil

		if not maxFrame then
			unit = HeroGwar.new()

			unit:setInfo(heroInfo)

			maxFrame = #unit.frameStack.idle[1]
			frameSkip = unit.playSkip

			setAnimationInfo(maxFrame, frameSkip)
		end

		customFrameSkip = customFrameSkip or frameSkip
		local node = display.newNode()

		node:setCascadeOpacityEnabled(true)

		local frames = {}

		for frame = 1, maxFrame do
			local textureKey = "Portrait#" .. getAvatarKeyFromInfo(heroInfo, "hero", "gwar") .. "_" .. width .. "_" .. height .. "_" .. scale .. "_" .. offset.x .. "_" .. offset.y .. "_" .. angle .. "_" .. frame
			local icon = getIcon(textureKey)

			if not icon then
				if not unit then
					unit = Hero.new()

					unit:setInfo(heroInfo)
				end

				icon = getIconByUnit(TYPE.MUGSHOT, unit, size, scale, angle, offset, false, textureKey, frame)
			end

			node:addChild(icon)
			table.insert(frames, icon)
			icon:setVisible(false)
		end

		if unit then
			display.getRunningScene():addChild(unit)
			unit:removeSelf()
		end

		local playCount = 0
		local frame = math.random(0, maxFrame - 1)
		local _frames = 0

		local function animationLoop(dt)
			local _preFrames = _frames
			local passed = dt * 60
			_frames = _frames + passed
			local sharp = math.floor(_frames) - math.floor(_preFrames)

			for i = 1, sharp do
				if playCount <= 0 then
					if frames[frame] then
						frames[frame]:setVisible(false)
					end

					frame = frame + 1

					if maxFrame < frame then
						frame = 1
					end

					frames[frame]:setVisible(true)

					playCount = customFrameSkip
				else
					playCount = playCount - 1
				end
			end
		end

		node:addNodeEventListener(cc.NODE_ENTER_FRAME_EVENT, animationLoop)
		node:scheduleUpdate()
		animationLoop(0)

		return node
	else
		local frame = 1
		local textureKey = "Portrait#" .. getAvatarKeyFromInfo(heroInfo, "hero", "gwar") .. "_" .. width .. "_" .. height .. "_" .. scale .. "_" .. offset.x .. "_" .. offset.y .. "_" .. angle .. "_" .. frame
		local icon = getIcon(textureKey)

		if not icon then
			local unit = HeroGwar.new()

			unit:setInfo(heroInfo)

			icon = getIconByUnit(TYPE.MUGSHOT, unit, size, scale, angle, offset, false, textureKey, frame)

			display.getRunningScene():addChild(unit)
			unit:removeSelf()
		end

		return icon
	end
end

function PortraitManager.getHeroMugshot(heroInfo, size, scale, angle, offset, isAnimation, customFrameSkip, customKey)
	scale = scale or 3
	angle = angle or 0
	offset = offset or {
		y = 0,
		x = 0
	}
	local width = size.width
	local height = size.height

	if isAnimation then
		local maxFrame, frameSkip = getAnimationInfo()
		local unit = nil

		if not maxFrame then
			unit = Hero.new()

			unit:setInfo(heroInfo)

			maxFrame = #unit.frameStack.idle[1]
			frameSkip = unit.playSkip

			setAnimationInfo(maxFrame, frameSkip)
		end

		customFrameSkip = customFrameSkip or frameSkip
		local node = display.newNode()

		node:setCascadeOpacityEnabled(true)

		local frames = {}

		for frame = 1, maxFrame do
			local textureKey = "Portrait#" .. getAvatarKeyFromInfo(heroInfo, "hero") .. "_" .. width .. "_" .. height .. "_" .. scale .. "_" .. offset.x .. "_" .. offset.y .. "_" .. angle .. "_" .. frame .. (customKey or "")
			local icon = getIcon(textureKey)

			if not icon then
				if not unit then
					unit = Hero.new()

					unit:setInfo(heroInfo)
				end

				icon = getIconByUnit(TYPE.MUGSHOT, unit, size, scale, angle, offset, false, textureKey, frame)
			end

			node:addChild(icon)
			table.insert(frames, icon)
			icon:setVisible(false)
		end

		if unit then
			display.getRunningScene():addChild(unit)
			unit:removeSelf()
		end

		local playCount = 0
		local frame = math.random(0, maxFrame - 1)
		local _frames = 0

		local function animationLoop(dt)
			local _preFrames = _frames
			local passed = dt * 60
			_frames = _frames + passed
			local sharp = math.floor(_frames) - math.floor(_preFrames)

			for i = 1, sharp do
				if playCount <= 0 then
					if frames[frame] then
						frames[frame]:setVisible(false)
					end

					frame = frame + 1

					if maxFrame < frame then
						frame = 1
					end

					frames[frame]:setVisible(true)

					playCount = customFrameSkip
				else
					playCount = playCount - 1
				end
			end
		end

		node:addNodeEventListener(cc.NODE_ENTER_FRAME_EVENT, animationLoop)
		node:scheduleUpdate()
		animationLoop(0)

		return node
	else
		local frame = 1
		local textureKey = "Portrait#" .. getAvatarKeyFromInfo(heroInfo, "hero") .. "_" .. width .. "_" .. height .. "_" .. scale .. "_" .. offset.x .. "_" .. offset.y .. "_" .. angle .. "_" .. frame .. (customKey or "")
		local icon = getIcon(textureKey)

		if not icon then
			local unit = Hero.new()

			unit:setInfo(heroInfo)

			icon = getIconByUnit(TYPE.MUGSHOT, unit, size, scale, angle, offset, false, textureKey, frame)

			display.getRunningScene():addChild(unit)
			unit:removeSelf()
		end

		return icon
	end
end

function PortraitManager.getNpcMugshot(npcID, size, scale, angle, offset, isAnimation, customFrameSkip)
	scale = scale or 3
	angle = angle or 0
	offset = offset or {
		y = 0,
		x = 0
	}
	local width = size.width
	local height = size.height

	if isAnimation then
		local maxFrame, frameSkip = getAnimationInfo()
		local unit = nil

		if not maxFrame then
			unit = Npc.new()

			unit:setID(npcID, nil, true)

			maxFrame = #unit.frameStack.idle[1]
			frameSkip = unit.playSkip

			setAnimationInfo(maxFrame, frameSkip)
		end

		customFrameSkip = customFrameSkip or frameSkip
		local node = display.newNode()
		local frames = {}

		for frame = 1, maxFrame do
			local textureKey = "Portrait#npcMugshot:" .. tostring(npcID) .. "_" .. width .. "_" .. height .. "_" .. scale .. "_" .. offset.x .. "_" .. offset.y .. "_" .. angle .. "_" .. frame
			local icon = getIcon(textureKey)

			if not icon then
				if not unit then
					unit = Npc.new()

					unit:setID(npcID, nil, true)
				end

				icon = getIconByUnit(TYPE.MUGSHOT, unit, size, scale, angle, offset, false, textureKey, frame)
			end

			node:addChild(icon)
			table.insert(frames, icon)
			icon:setVisible(false)
		end

		if unit then
			display.getRunningScene():addChild(unit)
			unit:removeSelf()
		end

		local playCount = customFrameSkip
		local frame = 0

		local function animationLoop(dt)
			if playCount <= 0 then
				if frames[frame] then
					frames[frame]:setVisible(false)
				end

				frame = frame + 1

				if maxFrame < frame then
					frame = 1
				end

				frames[frame]:setVisible(true)

				playCount = customFrameSkip
			else
				playCount = playCount - 1
			end
		end

		node:addNodeEventListener(cc.NODE_ENTER_FRAME_EVENT, animationLoop)
		node:scheduleUpdate()

		return node
	else
		local frame = 1
		local textureKey = "Portrait#npcMugshot:" .. tostring(npcID) .. "_" .. width .. "_" .. height .. "_" .. scale .. "_" .. offset.x .. "_" .. offset.y .. "_" .. angle .. "_" .. frame
		local icon = getIcon(textureKey)

		if not icon then
			local unit = Npc.new()

			unit:setID(npcID, nil, true)

			icon = getIconByUnit(TYPE.MUGSHOT, unit, size, scale, angle, offset, false, textureKey, frame)

			display.getRunningScene():addChild(unit)
			unit:removeSelf()
		end

		return icon
	end
end

function PortraitManager.getChanceMugshot(npcID, size, scale, angle, offset, isAnimation, customFrameSkip)
	scale = scale or 3
	angle = angle or 0
	offset = offset or {
		y = 0,
		x = 0
	}
	local width = size.width
	local height = size.height

	if isAnimation then
		local maxFrame, frameSkip = getAnimationInfo()
		local unit = nil

		if not maxFrame then
			unit = Npc.new()

			unit:setChanceID(npcID)

			maxFrame = #unit.frameStack.idle[1]
			frameSkip = unit.playSkip

			setAnimationInfo(maxFrame, frameSkip)
		end

		customFrameSkip = customFrameSkip or frameSkip
		local node = display.newNode()
		local frames = {}

		for frame = 1, maxFrame do
			local textureKey = "Portrait#chanceMugshot:" .. tostring(npcID) .. "_" .. width .. "_" .. height .. "_" .. scale .. "_" .. offset.x .. "_" .. offset.y .. "_" .. angle .. "_" .. frame
			local icon = getIcon(textureKey)

			if not icon then
				if not unit then
					unit = Npc.new()

					unit:setChanceID(npcID)
				end

				icon = getIconByUnit(TYPE.MUGSHOT, unit, size, scale, angle, offset, false, textureKey, frame)
			end

			node:addChild(icon)
			table.insert(frames, icon)
			icon:setVisible(false)
		end

		if unit then
			display.getRunningScene():addChild(unit)
			unit:removeSelf()
		end

		local playCount = customFrameSkip
		local frame = 0

		local function animationLoop(dt)
			if playCount <= 0 then
				if frames[frame] then
					frames[frame]:setVisible(false)
				end

				frame = frame + 1

				if maxFrame < frame then
					frame = 1
				end

				frames[frame]:setVisible(true)

				playCount = customFrameSkip
			else
				playCount = playCount - 1
			end
		end

		node:addNodeEventListener(cc.NODE_ENTER_FRAME_EVENT, animationLoop)
		node:scheduleUpdate()

		return node
	else
		local frame = 1
		local textureKey = "Portrait#npcMugshot:" .. tostring(npcID) .. "_" .. width .. "_" .. height .. "_" .. scale .. "_" .. offset.x .. "_" .. offset.y .. "_" .. angle .. "_" .. frame
		local icon = getIcon(textureKey)

		if not icon then
			local unit = Npc.new()

			unit:setChanceID(npcID)

			if unit.spineData then
				unit:refreshSpine()
			end

			icon = getIconByUnit(TYPE.MUGSHOT, unit, size, scale, angle, offset, false, textureKey, frame)

			display.getRunningScene():addChild(unit)
			unit:removeSelf()
		end

		return icon
	end
end

function PortraitManager.getPetMugshot(petID, size, scale, angle, offset, isAnimation, customFrameSkip)
	return PortraitManager.getPetType(TYPE.MUGSHOT, petID, size, scale, angle, offset, isAnimation, customFrameSkip)
end

function PortraitManager.getPetStanding(petID, size, scale, angle, offset, isAnimation, customFrameSkip)
	return PortraitManager.getPetType(TYPE.STANDING, petID, size, scale, angle, offset, isAnimation, customFrameSkip)
end

function PortraitManager.getPetCenter(petID, size, scale, angle, offset, isAnimation, customFrameSkip)
	return PortraitManager.getPetType(TYPE.CENTER, petID, size, scale, angle, offset, isAnimation, customFrameSkip)
end

function PortraitManager.getMonsterMugshot(monsterID, size, scale, angle, offset, isAnimation, customFrameSkip)
	return PortraitManager.getMonsterType(TYPE.MUGSHOT, monsterID, size, scale, angle, offset, isAnimation, customFrameSkip)
end

function PortraitManager.getMonsterStanding(monsterID, size, scale, angle, offset, isAnimation, customFrameSkip)
	return PortraitManager.getMonsterType(TYPE.STANDING, monsterID, size, scale, angle, offset, isAnimation, customFrameSkip)
end

function PortraitManager.getMonsterCenter(monsterID, size, scale, angle, offset, isAnimation, customFrameSkip)
	return PortraitManager.getMonsterType(TYPE.CENTER, monsterID, size, scale, angle, offset, isAnimation, customFrameSkip)
end

function PortraitManager.getPetType(type, petID, size, scale, angle, offset, isAnimation, customFrameSkip)
	scale = scale or 3
	angle = angle or 0
	offset = offset or {
		y = 0,
		x = 0
	}
	local width = size.width
	local height = size.height
	local petData = CsvParser.getCsvData("pet", petID)

	if isAnimation then
		local maxFrame, frameSkip = getAnimationInfo()
		local unit = nil

		if not maxFrame then
			unit = Clip.new()

			unit:load(petData.model)

			maxFrame = #unit.frameStack.idle[1]
			frameSkip = unit.playSkip

			setAnimationInfo(maxFrame, frameSkip)
		end

		customFrameSkip = customFrameSkip or frameSkip
		local node = display.newNode()
		local frames = {}

		for frame = 1, maxFrame do
			local textureKey = "Portrait#petMugshot:" .. tostring(petID) .. "_" .. width .. "_" .. height .. "_" .. scale .. "_" .. offset.x .. "_" .. offset.y .. "_" .. angle .. "_" .. frame
			local icon = getIcon(textureKey)

			if not icon then
				if not unit then
					unit = Clip.new()

					unit:load(petData.model)
				end

				icon = getIconByUnit(type, unit, size, scale, angle, offset, false, textureKey, frame)
			end

			node:addChild(icon)
			table.insert(frames, icon)
			icon:setVisible(false)
		end

		if unit then
			display.getRunningScene():addChild(unit)
			unit:removeSelf()
		end

		local playCount = customFrameSkip
		local frame = 0

		local function animationLoop(dt)
			if playCount <= 0 then
				if frames[frame] then
					frames[frame]:setVisible(false)
				end

				frame = frame + 1

				if maxFrame < frame then
					frame = 1
				end

				frames[frame]:setVisible(true)

				playCount = customFrameSkip
			else
				playCount = playCount - 1
			end
		end

		node:addNodeEventListener(cc.NODE_ENTER_FRAME_EVENT, animationLoop)
		node:scheduleUpdate()

		return node
	else
		local frame = 1
		local textureKey = "Portrait#petMugshot:" .. tostring(petID) .. "_" .. width .. "_" .. height .. "_" .. scale .. "_" .. offset.x .. "_" .. offset.y .. "_" .. angle .. "_" .. frame
		local icon = getIcon(textureKey)

		if not icon then
			local unit = Clip.new()

			unit:load(petData.model)

			icon = getIconByUnit(type, unit, size, scale, angle, offset, false, textureKey, frame)

			display.getRunningScene():addChild(unit)
			unit:removeSelf()
		end

		return icon
	end
end

function PortraitManager.getMonsterType(type, monsterID, size, scale, angle, offset, isAnimation, customFrameSkip)
	scale = scale or 3
	angle = angle or 0
	offset = offset or {
		y = 0,
		x = 0
	}
	local width = size.width
	local height = size.height
	local monsterData = CsvParser.getCsvData("monster", monsterID)

	if isAnimation then
		local maxFrame, frameSkip = getAnimationInfo()
		local unit = nil

		if not maxFrame then
			unit = Monster.new()

			unit:setInfo({
				level = 1,
				base_id = monsterID
			})
			unit:setScale(1)

			maxFrame = #unit.frameStack.idle[1]
			frameSkip = unit.playSkip

			setAnimationInfo(maxFrame, frameSkip)
		end

		customFrameSkip = customFrameSkip or frameSkip
		local node = display.newNode()
		local frames = {}

		for frame = 1, maxFrame do
			local textureKey = "Portrait#monsterMugshot:" .. tostring(monsterID) .. "_" .. width .. "_" .. height .. "_" .. scale .. "_" .. offset.x .. "_" .. offset.y .. "_" .. angle .. "_" .. frame
			local icon = getIcon(textureKey)

			if not icon then
				if not unit then
					unit = Monster.new()

					unit:setInfo({
						level = 1,
						base_id = monsterID
					})
					unit:setScale(1)
				end

				icon = getIconByUnit(type, unit, size, scale, angle, offset, false, textureKey, frame)
			end

			node:addChild(icon)
			table.insert(frames, icon)
			icon:setVisible(false)
		end

		if unit then
			display.getRunningScene():addChild(unit)
			unit:removeSelf()
		end

		local playCount = customFrameSkip
		local frame = 0

		local function animationLoop(dt)
			if playCount <= 0 then
				if frames[frame] then
					frames[frame]:setVisible(false)
				end

				frame = frame + 1

				if maxFrame < frame then
					frame = 1
				end

				frames[frame]:setVisible(true)

				playCount = customFrameSkip
			else
				playCount = playCount - 1
			end
		end

		node:addNodeEventListener(cc.NODE_ENTER_FRAME_EVENT, animationLoop)
		node:scheduleUpdate()

		return node
	else
		local frame = 1
		local textureKey = "Portrait#monsterMugshot:" .. tostring(monsterID) .. "_" .. width .. "_" .. height .. "_" .. scale .. "_" .. offset.x .. "_" .. offset.y .. "_" .. angle .. "_" .. frame
		local icon = getIcon(textureKey)

		if not icon then
			local unit = Monster.new()

			unit:setInfo({
				level = 1,
				base_id = monsterID
			})
			unit:setScale(1)

			icon = getIconByUnit(type, unit, size, scale, angle, offset, false, textureKey, frame)

			display.getRunningScene():addChild(unit)
			unit:removeSelf()
		end

		return icon
	end
end

function PortraitManager.clearOnScene()
	infoCache = {}
	animationInfoCache = {}
end

return PortraitManager
