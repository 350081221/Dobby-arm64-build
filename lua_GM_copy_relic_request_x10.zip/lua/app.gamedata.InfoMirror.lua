local InfoMirror = {}
local rawData = {}

function InfoMirror.init()
	Connection.listen("mirror_sync", InfoMirror.sync)
end

app:addToAppEnterCall(InfoMirror.init)

function InfoMirror.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoMirror.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("mirror_query", callback)
end

function InfoMirror.onQuery(rcvData)
	rawData = {}

	for i = 1, #rcvData.list do
		local data = rcvData.list[i]
		rawData[data.type] = data
	end
end

function InfoMirror.sync(data)
	local changedIdStack = {}

	for i, syncData in ipairs(data.list) do
		local type = syncData.type

		if not rawData[type] then
			rawData[type] = syncData
		else
			for k, v in pairs(syncData) do
				rawData[type][k] = v
			end
		end

		changedIdStack[type] = rawData[type]
	end

	ManagerInfo.dataChange("mirror", changedIdStack, "type")
end

function InfoMirror.lvup(next_id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("mirror_lvup", {
		next_id = next_id
	}, callback)
end

function InfoMirror.getTypeMap()
	local typeCSVMap = CacheData.get("InfoMirror_typeCSVMap")
	local typeList = CacheData.get("InfoMirror_typeList")

	if not typeCSVMap then
		typeCSVMap = {}
		typeList = {}
		local arr = CsvParser.getCsvList("mirror_skill")

		for i, data in ipairs(arr) do
			if not typeCSVMap[data.type] then
				typeCSVMap[data.type] = {}

				table.insert(typeList, data.type)
			end

			typeCSVMap[data.type][data.level] = data
		end

		CacheData.set("InfoMirror_typeCSVMap", typeCSVMap)
		CacheData.set("InfoMirror_typeList", typeList)
	end

	table.sort(typeList, function (a, b)
		return a < b
	end)

	return typeCSVMap, typeList
end

function InfoMirror.checkLvupResource(checkItemID)
	local csvRaw = CsvParser.getCsvRaw("mirror_skill")

	for k, v in pairs(csvRaw) do
		if v.mat_id1 ~= checkItemID then
			return false
		end
	end

	return true
end

function InfoMirror.countLvup()
	local arr = InfoMirror.getList()
	local count = 0

	for i, data in ipairs(arr) do
		local isMax = InfoMirror.isMax(data.type, data.level)
		local isBuildingLimit = InfoMirror.isBuildingLimit(data.type, data.level)

		if not isMax then
			if isBuildingLimit then
				-- Nothing
			else
				local nextInfo = InfoMirror.getInfo(data.type, data.level + 1)
				local costArr = SheetUtil.getColumnList(nextInfo.data, {
					"mat_id",
					"mat_num"
				}, {
					"base_id",
					"num"
				})
				local costInfo = costArr[1]
				local itemNum = InfoItem.getNum(costInfo.base_id)

				if costInfo.num <= itemNum then
					count = count + 1
				end
			end
		end
	end

	return count
end

function InfoMirror.getList()
	local arr = CsvParser.getCsvList("mirror_skill")
	local typeCSVMap, typeList = InfoMirror.getTypeMap()
	local items = {}

	for i, type in ipairs(typeList) do
		local level = InfoMirror.getLevel(type)
		local data = typeCSVMap[type][math.max(level, 1)]

		table.insert(items, {
			type = type,
			level = level,
			data = data
		})
	end

	return items
end

function InfoMirror.getInfo(type, level)
	local typeCSVMap = InfoMirror.getTypeMap()
	level = level or InfoMirror.getLevel(type)
	local data = typeCSVMap[type][math.max(level, 1)]

	if data then
		return {
			type = type,
			level = level,
			data = data
		}
	end
end

function InfoMirror.getLevel(type)
	local row = rawData[type]

	if row then
		return math.min(InfoMirror.getMaxLevel(type), row.level)
	else
		return 0
	end
end

function InfoMirror.getCurrent(type)
	local row = rawData[type]
	local level = InfoMirror.getLevel(type)

	if level > 0 then
		local info = InfoMirror.getInfo(type, level)

		return info.data
	end
end

local maxLevelCache = nil

function InfoMirror.getMaxLevel(type)
	if not maxLevelCache then
		maxLevelCache = {}
		local mirrorRaw = CsvParser.getCsvRaw("mirror_skill")

		for k, v in pairs(mirrorRaw) do
			if not maxLevelCache[v.type] or maxLevelCache[v.type] < v.level then
				maxLevelCache[v.type] = v.level
			end
		end
	end

	return maxLevelCache[type]
end

function InfoMirror.isMax(type, level)
	local info = InfoMirror.getInfo(type, level + 1)

	return info == nil
end

function InfoMirror.isBuildingLimit(type, level)
	local info = InfoMirror.getInfo(type, level + 1)

	if info and InfoBuilding.getBuildingFin(info.data.need_building_id) then
		return false
	end

	return true
end

return InfoMirror
