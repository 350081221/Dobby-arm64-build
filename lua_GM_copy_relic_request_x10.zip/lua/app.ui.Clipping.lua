local Clipping = class("Clipping", function (clippingName, picName)
	local path = getFinalRes("res/clipping/" .. clippingName .. ".json")
	local clippingData = JsonParser.parse(path)
	local rect = cc.rect(0, 0, clippingData.width, clippingData.height)
	local node = display.newClippingRectangleNode(rect)

	node:setNodeEventEnabled(true)

	return node
end)

function Clipping:ctor(clippingName, picName)
	event_listener.extendMethods(self)

	local clippingData = JsonParser.parse("res/clipping/" .. clippingName .. ".json")
	local picData = clippingData.clipping[picName]
	local picPath = getFinalRes("res/image/" .. clippingData.path .. "/" .. picName)
	local bmp = display.newSprite(picPath)

	bmp:setScale(picData.scale / 100)
	bmp:setPosition(math.floor(clippingData.width / 2) + picData.xoffset, math.floor(clippingData.height / 2) - picData.yoffset)
	self:addChild(bmp)
end

return Clipping
