local UI_base = import("..UI_base")
local FRAME_relic_get = class("FRAME_relic_get", UI_base)
local TYPE = {
	GATHER = 2,
	RELIC = 1
}
FRAME_relic_get.TYPE = TYPE

function FRAME_relic_get.open(type, npc, eventIndex, params, equipDropList, itemDropList, cardDropList, sigilDropList, onComplete, onClose)
	local ui = FRAME_relic_get.new(type, npc, eventIndex, params, equipDropList, itemDropList, cardDropList, sigilDropList, onComplete, onClose)

	ui:onOpen()
	PopManager.open(ui, nil, function ()
		if onClose then
			onClose()
		end

		ui:onClose()
	end, PopManager.ANIM_TYPE.FADE, 0)
end

function FRAME_relic_get:ctor(type, npc, eventIndex, params, equipDropList, itemDropList, cardDropList, sigilDropList, onComplete)
	FRAME_relic_get.super.ctor(self, "frame_relic_get", UIManager.BIG_TYPE.POP)

	self.type = type
	self.npc = npc
	self.eventIndex = eventIndex
	self.params = params
	self.equipDropList = equipDropList
	self.cardDropList = cardDropList
	self.itemDropList = itemDropList
	self.sigilDropList = sigilDropList
	self.onComplete = onComplete

	self:init()
end

function FRAME_relic_get:init()
	self:initUI()
	self:initBagList()
	self:initReadyList()
end

function FRAME_relic_get:initUI()
	local mask1 = self:getComponentByTag("mask1")

	mask1:toTouchable()
	mask1:setOpacity(0)

	local mask2 = self:getComponentByTag("mask2")

	mask2:toTouchable()
	mask2:setOpacity(0)

	local bg1 = self:getComponentByTag("bg1")

	bg1:toTouchable()

	local bg2 = self:getComponentByTag("bg2")

	bg2:toTouchable()

	local rightBG = self:getComponentByTag("right_bg")
	local confirmButton = self:getComponentByTag("bt_confirm")
	local confirmButtonDisable = self:getComponentByTag("bt_confirm_disable")
	local allButton = self:getComponentByTag("bt_all")
	local sortButton = self:getComponentByTag("bt_sort")
	local readyListCols = 2
	local widthOffset = math.max(self:getBigWidth(), display.width) - 960

	if widthOffset >= 120 then
		mask2:setSize(mask2.originalWidth + 120)
		mask2:setPos(mask2.x - 120)
		bg2:setSize(bg2.originalWidth + 120)
		bg2:setPos(bg2.x - 120)
		rightBG:setSize(rightBG.originalWidth + 120)
		rightBG:setPos(rightBG.x - 120)

		local readyListFlag = self:getFlagByTag("flag_ready_list")
		readyListFlag.width = readyListFlag.originalWidth + 120
		readyListFlag.x = readyListFlag.x - 120
		readyListCols = 3

		confirmButton:setPos(confirmButton.x - 30)
		confirmButtonDisable:setPos(confirmButtonDisable.x - 30)
		allButton:setPos(allButton.x - 90)
	end

	local function tapListener(ui, data, index, x, y)
		local function onPick(_ui)
			self:pickToBag(data)
			PopManager.closeTo(_ui)
		end

		if data.type == DropManager.TYPE.EQUIP then
			FRAME_equip_detail.open(data.info, FRAME_equip_detail.OPEN_TYPE.PICK, onPick)
		elseif data.type == DropManager.TYPE.SIGIL then
			FRAME_sigil_detail.open(data.info, FRAME_equip_detail.OPEN_TYPE.PICK, onPick)
		elseif data.type == DropManager.TYPE.CARD then
			FRAME_card.open(data.info, FRAME_card.OPEN_TYPE.PICK, onPick)
		elseif data.type == DropManager.TYPE.ITEM then
			FRAME_item_detail.open(data.info, FRAME_item_detail.OPEN_TYPE.PICK, onPick)
		end
	end

	self.readyList = self:createListOnFlag("flag_ready_list", function (rect)
		return LIST_relic_get.new(rect, readyListCols)
	end, tapListener)

	self.readyList:setPickable(true, nil, , true)
	self.readyList:addEventListener("pickBegan", function (event)
		self:onPickMovedReady(event)
	end)
	self.readyList:addEventListener("pickMoved", function (event)
		self:onPickMovedReady(event)
	end)
	self.readyList:addEventListener("pickEnded", function (event)
		self:onPickEndedReady(event)
	end)

	local function tapListener(ui, data, index)
		local function onRemove(_ui)
			self:removeFromBag(data)
			PopManager.closeTo(_ui)
		end

		if data.type == DropManager.TYPE.EQUIP then
			if self:canDrop(data, true) then
				FRAME_equip_detail.open(data.info, FRAME_equip_detail.OPEN_TYPE.REMOVE, onRemove)
			else
				FRAME_equip_detail.open(data.info, FRAME_equip_detail.OPEN_TYPE.NONE)
			end
		elseif data.type == DropManager.TYPE.SIGIL then
			if self:canDrop(data, true) then
				FRAME_sigil_detail.open(data.info, FRAME_sigil_detail.OPEN_TYPE.REMOVE, onRemove)
			else
				FRAME_sigil_detail.open(data.info, FRAME_sigil_detail.OPEN_TYPE.NONE)
			end
		elseif data.type == DropManager.TYPE.CARD then
			FRAME_card.open(data.info, FRAME_card.OPEN_TYPE.NONE)
		elseif data.type == DropManager.TYPE.ARTIFACT then
			FRAME_artifact.open(data.info, FRAME_card.OPEN_TYPE.NONE)
		elseif data.type == DropManager.TYPE.ITEM then
			FRAME_item_detail.open(data.info, FRAME_item_detail.OPEN_TYPE.REMOVE, onRemove)
		end
	end

	self.bagList = self:createListOnFlag("flag_bag_list", function (rect)
		return LIST_bag.new(rect, 4)
	end, tapListener)

	self.bagList:setPickable(true, nil, , true)
	self.bagList:addEventListener("pickBegan", function (event)
		self:onPickMovedBag(event)
	end)
	self.bagList:addEventListener("pickMoved", function (event)
		self:onPickMovedBag(event)
	end)
	self.bagList:addEventListener("pickEnded", function (event)
		self:onPickEndedBag(event)
	end)

	if InfoGuide.isFin() then
		confirmButtonDisable:setVisible(false)
		confirmButton:toTouchable()
		confirmButton:setTapGroup("button_click")
		confirmButton:addTap(function ()
			if self:isReadyItemsClear() then
				self:openRelic()
			else
				POP_notice.open(Localization.getSrcText("是否丢弃未拾取物品？"), function ()
					self:openRelic()
				end)
			end
		end)
	else
		confirmButton:setVisible(false)
		confirmButtonDisable:toTouchable()
		confirmButtonDisable:setTapGroup("button_click")
		confirmButtonDisable:addTap(function ()
			Alert.open(Localization.getSrcText("引导期间该功能无法使用"))
		end)
	end

	allButton:toTouchable()
	allButton:setTapGroup("button_click")
	allButton:addTap(function ()
		self:getAll()
	end)
	sortButton:toTouchable()
	sortButton:setTapGroup("button_click")
	sortButton:addTap(function ()
		self:autoSort()
	end)
end

function FRAME_relic_get:autoSort()
	local amount = InfoBag.getAmount()
	local bagInfo = {}

	for i = 1, amount do
		local obj = self.bagItems[i]

		if obj.info then
			if obj.type == DropManager.TYPE.ITEM then
				table.insert(bagInfo, {
					bag_index = i,
					type = obj.type,
					item_id = tonumber(obj.info.base_id),
					item_num = obj.info.num
				})
			elseif obj.type == DropManager.TYPE.EQUIP then
				if obj.info.id then
					table.insert(bagInfo, {
						bag_index = i,
						type = obj.type,
						equip_id = tonumber(obj.info.id)
					})
				else
					table.insert(bagInfo, {
						bag_index = i,
						type = obj.type,
						info = obj.info
					})
				end
			elseif obj.type == DropManager.TYPE.CARD then
				if obj.info.id then
					table.insert(bagInfo, {
						bag_index = i,
						type = obj.type,
						card_id = tonumber(obj.info.id)
					})
				else
					table.insert(bagInfo, {
						bag_index = i,
						type = obj.type,
						info = obj.info
					})
				end
			elseif obj.type == DropManager.TYPE.SIGIL then
				if obj.info.id then
					table.insert(bagInfo, {
						bag_index = i,
						type = obj.type,
						sigil_id = tonumber(obj.info.id)
					})
				else
					table.insert(bagInfo, {
						bag_index = i,
						type = obj.type,
						info = obj.info
					})
				end
			elseif obj.type == DropManager.TYPE.ARTIFACT then
				if obj.info.id then
					table.insert(bagInfo, {
						bag_index = i,
						type = obj.type,
						artifact_id = tonumber(obj.info.id)
					})
				else
					table.insert(bagInfo, {
						bag_index = i,
						type = obj.type,
						info = obj.info
					})
				end
			end
		end
	end

	local newBagInfo = InfoBag.autoSort(bagInfo)

	if newBagInfo then
		self.bagItems = {}

		for bag_index = 1, amount do
			if newBagInfo[bag_index] and newBagInfo[bag_index].type ~= DropManager.TYPE.NONE then
				if newBagInfo[bag_index].type == DropManager.TYPE.EQUIP then
					if newBagInfo[bag_index].equip_id then
						table.insert(self.bagItems, {
							type = DropManager.TYPE.EQUIP,
							info = InfoEquip.getInfo(newBagInfo[bag_index].equip_id)
						})
					else
						table.insert(self.bagItems, {
							type = DropManager.TYPE.EQUIP,
							info = newBagInfo[bag_index].info
						})
					end
				elseif newBagInfo[bag_index].type == DropManager.TYPE.CARD then
					if newBagInfo[bag_index].card_id then
						table.insert(self.bagItems, {
							type = DropManager.TYPE.CARD,
							info = InfoCard.getCardInfo(newBagInfo[bag_index].card_id)
						})
					else
						table.insert(self.bagItems, {
							type = DropManager.TYPE.CARD,
							info = newBagInfo[bag_index].info
						})
					end
				elseif newBagInfo[bag_index].type == DropManager.TYPE.SIGIL then
					if newBagInfo[bag_index].sigil_id then
						table.insert(self.bagItems, {
							type = DropManager.TYPE.SIGIL,
							info = InfoSigil.getInfo(newBagInfo[bag_index].sigil_id)
						})
					else
						table.insert(self.bagItems, {
							type = DropManager.TYPE.SIGIL,
							info = newBagInfo[bag_index].info
						})
					end
				elseif newBagInfo[bag_index].type == DropManager.TYPE.ARTIFACT then
					if newBagInfo[bag_index].artifact_id then
						table.insert(self.bagItems, {
							type = DropManager.TYPE.ARTIFACT,
							info = InfoArtifact.getInfo(newBagInfo[bag_index].artifact_id)
						})
					else
						table.insert(self.bagItems, {
							type = DropManager.TYPE.ARTIFACT,
							info = newBagInfo[bag_index].info
						})
					end
				elseif newBagInfo[bag_index].type == DropManager.TYPE.ITEM then
					table.insert(self.bagItems, {
						type = DropManager.TYPE.ITEM,
						info = {
							base_id = newBagInfo[bag_index].item_id,
							num = newBagInfo[bag_index].item_num
						}
					})
				end
			else
				table.insert(self.bagItems, {
					type = DropManager.TYPE.NONE
				})
			end
		end

		self:refreshBagList()
	end
end

function FRAME_relic_get:pickToBag(data)
	self.bagList:setUnselected()

	local bagIndex = self:getBagListFreeIndex()

	if bagIndex then
		local succ = self:addBagTo(bagIndex, data)

		if succ then
			self:onBagListChanged()
		end
	else
		Alert.open(Localization.getSrcText("背包已满"))
	end
end

function FRAME_relic_get:removeFromBag(data)
	self.bagList:setUnselected()

	local bagIndex = self:getBagIndex(data)

	if bagIndex then
		self:removeBagAt(bagIndex)
		self:onBagListChanged()
	end
end

function FRAME_relic_get:isReadyItemsClear()
	return #self.readyItems == 0
end

function FRAME_relic_get:initReadyList()
	self.readyItems = {}
	local index = 1

	for i, v in ipairs(self.equipDropList) do
		table.insert(self.readyItems, {
			tag = "relic_" .. index,
			type = DropManager.TYPE.EQUIP,
			info = v
		})

		index = index + 1
	end

	for i, v in ipairs(self.cardDropList) do
		table.insert(self.readyItems, {
			tag = "relic_" .. index,
			type = DropManager.TYPE.CARD,
			info = v
		})

		index = index + 1
	end

	for i, v in ipairs(self.sigilDropList) do
		table.insert(self.readyItems, {
			tag = "relic_" .. index,
			type = DropManager.TYPE.SIGIL,
			info = v
		})

		index = index + 1
	end

	for i, v in ipairs(self.itemDropList) do
		table.insert(self.readyItems, {
			tag = "relic_" .. index,
			type = DropManager.TYPE.ITEM,
			info = v
		})

		index = index + 1
	end

	self:refreshReadyList()
end

function FRAME_relic_get:refreshReadyList()
	self.readyList:setItems(self.readyItems, true)
end

function FRAME_relic_get:removeReadyList(tag)
	for i, v in ipairs(self.readyItems) do
		if v.tag == tag then
			table.remove(self.readyItems, i)

			return
		end
	end
end

function FRAME_relic_get:addReadyList(type, info)
	if type == DropManager.TYPE.NONE then
		return
	end

	if type == DropManager.TYPE.ITEM then
		for i, v in ipairs(self.readyItems) do
			if v.type == type and v.info.base_id == info.base_id then
				v.info.num = v.info.num + info.num

				return
			end
		end
	end

	table.insert(self.readyItems, {
		type = type,
		info = info
	})

	local function sortMethod(a, b)
		return a.info.base_id < b.info.base_id
	end

	table.sort(self.readyItems, sortMethod)

	for i, v in ipairs(self.readyItems) do
		v.tag = "ready_" .. i
	end
end

function FRAME_relic_get:initBagList()
	self.bagItems = InfoBag.getList()

	self:refreshBagList()
end

function FRAME_relic_get:refreshBagList()
	self.bagList:setItems(self.bagItems, true)
end

function FRAME_relic_get:addBagTo(index, readyObj)
	local carryNum = InfoBag.getAmount()
	local succ = false
	local clear = false
	local obj = self.bagItems[index]

	if obj and not self:canDrop(obj) then
		return succ, clear
	end

	if readyObj.type == DropManager.TYPE.ITEM then
		local itemData = CsvParser.getCsvData("item", readyObj.info.base_id)

		if obj.type == readyObj.type and obj.info.base_id == readyObj.info.base_id then
			if obj.info.num < math.max(1, itemData.bag_stack) then
				local changeNum = math.min(math.max(1, itemData.bag_stack) - obj.info.num, readyObj.info.num)
				obj.info.num = obj.info.num + changeNum
				readyObj.info.num = readyObj.info.num - changeNum

				if readyObj.info.num <= 0 then
					self:removeReadyList(readyObj.tag)

					clear = true
				end

				succ = true
			end
		else
			local num = math.min(math.max(1, itemData.bag_stack), readyObj.info.num)

			if obj.type then
				self:addReadyList(obj.type, obj.info)
			end

			obj.type = readyObj.type
			obj.info = {
				base_id = readyObj.info.base_id,
				num = num
			}
			readyObj.info.num = readyObj.info.num - num

			if readyObj.info.num <= 0 then
				self:removeReadyList(readyObj.tag)

				clear = true
			end

			succ = true
		end
	elseif readyObj.type == DropManager.TYPE.EQUIP or readyObj.type == DropManager.TYPE.CARD or readyObj.type == DropManager.TYPE.SIGIL then
		if obj.type then
			self:addReadyList(obj.type, obj.info)
		end

		obj.type = readyObj.type
		obj.info = readyObj.info

		self:removeReadyList(readyObj.tag)

		clear = true
		succ = true
	end

	return succ, clear
end

function FRAME_relic_get:removeBagAt(index)
	if self.bagItems[index].type then
		self:addReadyList(self.bagItems[index].type, self.bagItems[index].info)

		self.bagItems[index].type = nil
		self.bagItems[index].info = nil
	end
end

function FRAME_relic_get:putBagTo(fromIndex, toIndex)
	local fromObj = self.bagItems[fromIndex]
	local toObj = self.bagItems[toIndex]

	if fromObj.type == DropManager.TYPE.ITEM and toObj.type == DropManager.TYPE.ITEM and fromObj.info.base_id == toObj.info.base_id then
		local itemData = CsvParser.getCsvData("item", toObj.info.base_id)

		if toObj.info.num < math.max(1, itemData.bag_stack) then
			local putNum = math.min(math.max(1, itemData.bag_stack) - toObj.info.num, fromObj.info.num)
			toObj.info.num = toObj.info.num + putNum
			fromObj.info.num = fromObj.info.num - putNum

			if fromObj.info.num <= 0 then
				fromObj.type = nil
				fromObj.info = nil
			end
		end
	else
		self.bagItems[fromIndex] = toObj
		self.bagItems[toIndex] = fromObj
		self.bagItems[fromIndex].index = fromIndex
		self.bagItems[toIndex].index = toIndex
	end
end

function FRAME_relic_get:onPickMovedReady(event)
	local hitIndex = self:getBagListHitIndex(event.x, event.y)

	if hitIndex then
		self.bagList:setSelectedIndex(hitIndex)
	else
		self.bagList:setUnselected()
	end
end

function FRAME_relic_get:onPickEndedReady(event)
	self.bagList:setUnselected()
	self.readyList:stopPickAnimation()

	local hitIndex = self:getBagListHitIndex(event.x, event.y)

	if hitIndex then
		local readyObj = event.cell.data
		local succ = self:addBagTo(hitIndex, readyObj)

		if succ then
			self:onBagListChanged()
		end
	end
end

function FRAME_relic_get:onPickMovedBag(event)
	local hitIndex = self:getBagListHitIndex(event.x, event.y)

	if hitIndex then
		self.bagList:setSelectedIndex(hitIndex)
	else
		self.bagList:setUnselected()
	end
end

function FRAME_relic_get:canDrop(itemInfo, noAlert)
	if itemInfo.type == DropManager.TYPE.CARD then
		if not noAlert then
			Alert.open(Localization.getSrcText("无法丢弃卡片"))
		end

		return false
	elseif itemInfo.type == DropManager.TYPE.ARTIFACT then
		if not noAlert then
			Alert.open(Localization.getSrcText("无法丢弃饰物"))
		end

		return false
	elseif itemInfo.type == DropManager.TYPE.EQUIP then
		local equipInfo = itemInfo.info

		if equipInfo and equipInfo.locked == 1 then
			if not noAlert then
				Alert.open(Localization.getSrcText("物品已锁定，无法丢弃"))
			end

			return false
		end

		if InfoVars.get("nodrop_saved") == 1 and equipInfo and equipInfo.saved == 1 then
			if not noAlert then
				Alert.open(Localization.getSrcText("无法丢弃已绑定装备"))
			end

			return false
		end
	elseif itemInfo.type == DropManager.TYPE.SIGIL then
		local sigilInfo = itemInfo.info

		if sigilInfo and sigilInfo.locked == 1 then
			if not noAlert then
				Alert.open(Localization.getSrcText("物品已锁定，无法丢弃"))
			end

			return false
		end

		if InfoVars.get("nodrop_saved") == 1 and sigilInfo and sigilInfo.saved == 1 then
			if not noAlert then
				Alert.open(Localization.getSrcText("无法丢弃已绑定魔纹"))
			end

			return false
		end
	end

	return true
end

function FRAME_relic_get:onPickEndedBag(event)
	self.bagList:setUnselected()

	local hitIndex = self:getBagListHitIndex(event.x, event.y)
	local itemInfo = event.cell.data
	local itemIndex = self:getBagIndex(itemInfo)

	if hitIndex ~= itemIndex then
		if hitIndex then
			self:putBagTo(itemIndex, hitIndex)
		else
			if not self:canDrop(itemInfo) then
				return
			end

			self:removeBagAt(itemIndex)
		end

		self:onBagListChanged()
	end
end

function FRAME_relic_get:getBagIndex(itemInfo)
	for i, v in ipairs(self.bagItems) do
		if v == itemInfo then
			return i
		end
	end
end

function FRAME_relic_get:getBagListHitIndex(x, y)
	local hitIndex = self.bagList:hitTestCell(x, y)

	if hitIndex then
		local carryNum = InfoBag.getAmount()

		if hitIndex <= carryNum then
			return hitIndex
		end
	end
end

function FRAME_relic_get:getBagListFreeIndex()
	local amount = InfoBag.getAmount()

	for i = 1, amount do
		if not self.bagItems[i] or not self.bagItems[i].type or self.bagItems[i].type == DropManager.TYPE.NONE then
			return i
		end
	end
end

function FRAME_relic_get:onBagListChanged()
	self:refreshReadyList()
	self:refreshBagList()
end

function FRAME_relic_get:openRelic()
	local amount = InfoBag.getAmount()
	local bagInfo = {}

	for i = 1, amount do
		local obj = self.bagItems[i]

		if obj.info then
			if obj.type == DropManager.TYPE.ITEM then
				table.insert(bagInfo, {
					bag_index = i,
					type = obj.type,
					item_id = tonumber(obj.info.base_id),
					item_num = obj.info.num
				})
			elseif obj.type == DropManager.TYPE.EQUIP then
				if obj.info.id then
					table.insert(bagInfo, {
						bag_index = i,
						type = obj.type,
						equip_id = tonumber(obj.info.id)
					})
				else
					table.insert(bagInfo, {
						bag_index = i,
						type = obj.type,
						new_equip_index = tonumber(obj.info.index)
					})
				end
			elseif obj.type == DropManager.TYPE.SIGIL then
				if obj.info.id then
					table.insert(bagInfo, {
						bag_index = i,
						type = obj.type,
						sigil_id = tonumber(obj.info.id)
					})
				else
					table.insert(bagInfo, {
						bag_index = i,
						type = obj.type,
						new_sigil_index = tonumber(obj.info.index)
					})
				end
			elseif obj.type == DropManager.TYPE.CARD then
				if obj.info.id then
					table.insert(bagInfo, {
						bag_index = i,
						type = obj.type,
						card_id = tonumber(obj.info.id)
					})
				else
					table.insert(bagInfo, {
						bag_index = i,
						type = obj.type,
						new_card_index = tonumber(obj.info.index)
					})
				end
			elseif obj.type == DropManager.TYPE.ARTIFACT and obj.info.id then
				table.insert(bagInfo, {
					bag_index = i,
					type = obj.type,
					artifact_id = tonumber(obj.info.id)
				})
			end
		end
	end

	local npc = self.npc
	local onComplete = self.onComplete

	local function _onComplete(rcvData)
		local pickEffect = npc.data.pick_effect

		if not empty(pickEffect) then
			local effectGen = npc:getEffectGen()

			if effectGen then
				effectGen:castEffect(pickEffect, npc)
			end
		end

		if onComplete then
			onComplete(rcvData)
		end

		PopManager.close()
		GuideManager.free20()
	end

	if self.type == TYPE.RELIC then
		InfoDungeon.getRelic(self.eventIndex, self.params.relicIndex, bagInfo, _onComplete)
	elseif self.type == TYPE.GATHER then
		local eventsetIndex = nil

		if self.params then
			eventsetIndex = self.params.eventsetIndex
		end

		InfoDungeon.getGather(self.eventIndex, bagInfo, eventsetIndex, _onComplete)
	elseif self.type == TYPE.CHANCE and (npc.data.type == 13 or npc.data.type == 14) then
		InfoDungeon.getChance(npc, self.eventIndex, {
			type = 2,
			bag = bagInfo
		}, _onComplete)
	end
end

function FRAME_relic_get:getAll()
	local itemArr = {}
	local equipArr = {}
	local cardArr = {}
	local sigilArr = {}
	local artifactArr = {}

	for k, obj in pairs(self.readyItems) do
		if obj.type == DropManager.TYPE.EQUIP then
			table.insert(equipArr, obj)
		elseif obj.type == DropManager.TYPE.CARD then
			table.insert(cardArr, obj)
		elseif obj.type == DropManager.TYPE.SIGIL then
			table.insert(sigilArr, obj)
		elseif obj.type == DropManager.TYPE.ARTIFACT then
			table.insert(artifactArr, obj)
		elseif obj.type == DropManager.TYPE.ITEM then
			table.insert(itemArr, obj)
		end
	end

	local needRefresh = false
	local carryNum = InfoBag.getAmount()

	table.sort(equipArr, function (a, b)
		local qualityA = InfoEquip.getQuality(a.info)
		local qualityB = InfoEquip.getQuality(b.info)

		return qualityB < qualityA
	end)
	table.sort(cardArr, function (a, b)
		local qualityA = InfoCard.getQuality(a.info)
		local qualityB = InfoCard.getQuality(b.info)

		return qualityB < qualityA
	end)
	table.sort(sigilArr, function (a, b)
		return b.info.quality < a.info.quality
	end)

	for i, obj in ipairs(equipArr) do
		local succ = false

		for i = 1, carryNum do
			if self.bagItems[i].type == nil or self.bagItems[i].type == DropManager.TYPE.NONE then
				self:addBagTo(i, obj)

				succ = true
				needRefresh = true

				break
			end
		end

		if not succ then
			break
		end
	end

	for i, obj in ipairs(cardArr) do
		local succ = false

		for i = 1, carryNum do
			if self.bagItems[i].type == nil or self.bagItems[i].type == DropManager.TYPE.NONE then
				self:addBagTo(i, obj)

				succ = true
				needRefresh = true

				break
			end
		end

		if not succ then
			break
		end
	end

	for i, obj in ipairs(sigilArr) do
		local succ = false

		for i = 1, carryNum do
			if self.bagItems[i].type == nil or self.bagItems[i].type == DropManager.TYPE.NONE then
				self:addBagTo(i, obj)

				succ = true
				needRefresh = true

				break
			end
		end

		if not succ then
			break
		end
	end

	for i, obj in ipairs(artifactArr) do
		local succ = false

		for i = 1, carryNum do
			if self.bagItems[i].type == nil or self.bagItems[i].type == DropManager.TYPE.NONE then
				self:addBagTo(i, obj)

				succ = true
				needRefresh = true

				break
			end
		end

		if not succ then
			break
		end
	end

	for i, obj in ipairs(itemArr) do
		local allClear = false

		for i = 1, carryNum do
			if self.bagItems[i].type == DropManager.TYPE.ITEM and self.bagItems[i].info.base_id == obj.info.base_id then
				local succ, clear = self:addBagTo(i, obj)

				if succ then
					needRefresh = true
				end

				if clear then
					allClear = true

					break
				end
			end
		end

		if not allClear then
			for i = 1, carryNum do
				if self.bagItems[i].type == nil or self.bagItems[i].type == DropManager.TYPE.NONE then
					local succ, clear = self:addBagTo(i, obj)

					if succ then
						needRefresh = true
					end

					if clear then
						allClear = true

						break
					end
				end
			end
		end
	end

	if needRefresh then
		self:onBagListChanged()
	end

	if #self.readyItems > 0 then
		Alert.open(Localization.getSrcText("无法拾取所有战利品"))
	else
		self:openRelic()
	end
end

function FRAME_relic_get:onOpen()
	local bg1 = self:getComponentByTag("bg1")
	local bg2 = self:getComponentByTag("bg2")
	local centerX = (bg1.x + bg1.width + bg2.x) / 2

	global.map:setPositionOffset("ui_open", centerX - display.cx, 0)
	MapUtils.focusIn(self.npc, nil, 10, 1.4)
end

function FRAME_relic_get:onClose()
	global.map:setPositionOffset("ui_open", 0, 0)
	MapUtils.focusOut(self.npc, nil, 15)
end

return FRAME_relic_get
