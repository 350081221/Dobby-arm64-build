local InfoIllusion = {}
local rawData = nil

function InfoIllusion.init()
	Connection.listen("illusion_sync", InfoIllusion.sync)
end

app:addToAppEnterCall(InfoIllusion.init)

function InfoIllusion.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoIllusion.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("illusion_query", callback)
end

function InfoIllusion.onQuery(rcvData)
	rawData = {}

	for i, equip_id in ipairs(rcvData.list) do
		rawData[equip_id] = true
	end
end

function InfoIllusion.sync(data)
	for i, equip_id in ipairs(data.list) do
		rawData[equip_id] = true
	end

	ManagerInfo.dataChange("illusion")
end

function InfoIllusion.doIllusion(equip_id, illusion_id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("illusion_do", {
		equip_id = equip_id,
		illusion_id = illusion_id
	}, callback)
end

function InfoIllusion.getIllusionList(equipInfo)
	local equipCSV = CsvParser.getCsvData("equip", equipInfo.base_id)
	local csvList = CsvParser.getCsvList("illusion")
	local arr = {}

	for i, csv in ipairs(csvList) do
		if csv.is_close ~= 1 then
			local _equipCSV = CsvParser.getCsvData("equip", csv.equip_id)

			if _equipCSV.class == equipCSV.class and rawData[csv.equip_id] then
				table.insert(arr, csv)
			end
		end
	end

	return arr
end

return InfoIllusion
