local Test = class("Test", function ()
	return display.newScene("Test")
end)

function Test:ctor()
end

function Test:init()
	local map = Map.new(display.width, display.height)

	self:addChild(map)
	map:load("#plug")
	map:selfTouchDrag()
end

function Test:onEnter()
	app:onSceneEnter(self)
	self:init()
end

function Test:onExit()
	app:onSceneExit(self)
end

return Test
