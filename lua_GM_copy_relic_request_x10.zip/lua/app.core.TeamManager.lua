local TeamManager = {
	TYPE = {
		HERO = 1,
		PET = 2
	}
}

function TeamManager.clear()
	TeamManager.heroHPLocked = nil
end

function TeamManager.lockHeroHP()
	TeamManager.heroHPLocked = true
end

function TeamManager.unlockHeroHP()
	TeamManager.heroHPLocked = nil
end

function TeamManager.refreshBattleData()
	local units = global.player:getTrainUnits()

	for i, unit in ipairs(units) do
		unit:refreshBattleData()
	end
end

function TeamManager.refreshTeamSneak(inBattle)
	if not global.player then
		return
	end

	local units = global.player:getTrainUnits()

	if InfoDungeon.getSneakPoint() > 0 and not inBattle then
		for i, unit in ipairs(units) do
			unit:addLastingEffect(MiscConfig.sneak_effect, nil, true)
			unit:performWithDelay(function ()
				unit:setOpacity(150)
			end, 0.1)
		end
	else
		for i, unit in ipairs(units) do
			unit:removeLastingEffect(MiscConfig.sneak_effect, true)
			unit:performWithDelay(function ()
				unit:setOpacity(255)
			end, 0.1)
		end
	end
end

local unitChangeListener = nil

function TeamManager.setUnitChangeListener(func)
	unitChangeListener = func
end

function TeamManager.clearUnitChangeListener()
	unitChangeListener = nil
end

function TeamManager.createUnitByTemplete(heroInfo, isPlayer)
	local unit = nil

	if isPlayer then
		unit = Player.new()
		global.player = unit
	else
		unit = Hero.new()
	end

	unit.seed = math.random(1, 65535)
	unit.random = Random.new(unit.seed)

	unit:setHeroTempleteID(heroInfo.templeteID, heroInfo, true)

	return unit
end

function TeamManager.createUnitByData(heroInfo, isPlayer)
	local unit = nil

	if isPlayer then
		unit = Player.new()
		global.player = unit
	else
		unit = Hero.new()
	end

	unit.seed = math.random(1, 65535)
	unit.random = Random.new(unit.seed)

	unit:setInfo(heroInfo)

	return unit
end

function TeamManager.recoverTrain(trainInfo)
	if global.player then
		global.player.angle = trainInfo.angle

		global.player:draw(trainInfo.x, trainInfo.y, true)
		global.player:setTrain(trainInfo.train)
		global.player:resetTrain()
	end
end

function TeamManager.createUnitsOnRecover(trainInfo)
	TeamManager.ready = nil
	local teamData = {}
	local heros = InfoHero.getTeam()

	for i, v in ipairs(heros) do
		table.insert(teamData, v)
	end

	local first = true
	local isFixedTeam, fixed_team = InfoDungeon.isFixedTeam()

	if isFixedTeam then
		local heroes = StageUtils.getFixedHero()

		for i, heroInfo in ipairs(heroes) do
			local unit = TeamManager.createUnitByTemplete(heroInfo, first)
			local tile = global.map:mapToTile(trainInfo.x, trainInfo.y)

			if not tile then
				local enterEvent = MapEventManager.getMapEnter()

				if enterEvent and enterEvent.x and enterEvent.y then
					local x, y = global.map:tileToMap(enterEvent.x, enterEvent.y)
					trainInfo.x = x
					trainInfo.y = y
				end
			end

			unit:display(global.map, trainInfo.x, trainInfo.y)

			if not first then
				global.player:addToTrain(unit)
			end

			first = false
		end
	else
		if not InfoHero.hasHero() then
			return
		end

		for i = 1, #teamData do
			local heroInfo = teamData[i]

			if heroInfo then
				local heroHp = InfoDungeon.getHeroHP(heroInfo.id)

				if not heroHp or heroHp > 0 then
					local unit = TeamManager.createUnitByData(heroInfo, first)
					local tile = global.map:mapToTile(trainInfo.x, trainInfo.y)

					if not tile then
						local enterEvent = MapEventManager.getMapEnter()

						if enterEvent and enterEvent.x and enterEvent.y then
							local x, y = global.map:tileToMap(enterEvent.x, enterEvent.y)
							trainInfo.x = x
							trainInfo.y = y
						end
					end

					unit:display(global.map, trainInfo.x, trainInfo.y)

					if heroHp then
						unit.battleData.hp = heroHp
					end

					if not first then
						global.player:addToTrain(unit)
					elseif trainInfo.d then
						unit:setDir(trainInfo.d)
					else
						unit.angle = trainInfo.angle or 0
					end

					first = false
				else
					local corpseInfo = DungeonState.getCorpse(heroInfo.id)

					if corpseInfo and corpseInfo.map_index == InfoDungeon.getMapIndex() then
						local unit = TeamManager.createUnitByData(heroInfo, false)

						unit:display(global.map, corpseInfo.x, corpseInfo.y)

						if corpseInfo.d then
							unit:setDir(corpseInfo.d)
						else
							unit.angle = corpseInfo.angle or 0
						end

						unit:recoverDead()
					end
				end
			end
		end
	end

	if global.player then
		global.player:fillTrain()
		global.player:resetTrain()
	end

	TeamManager.refreshTeamLeader()
	TeamManager.refreshTeamShrineBuff()

	if unitChangeListener then
		unitChangeListener()
	end

	TeamManager.ready = true
end

function TeamManager.createUnitsOnMap(enterInfo, noEnterAction, fixedEnter, fixedIndex)
	TeamManager.ready = nil
	enterInfo = enterInfo or {}
	local enterEvent, destData, sitData, faceData = MapEventManager.getMapEnter(enterInfo.tag, fixedEnter, fixedIndex)
	enterEvent = enterEvent or {}
	local mode = enterEvent.mode or 0
	local enterX = enterInfo.x or enterEvent and enterEvent.x or 48
	local enterY = enterInfo.y or enterEvent and enterEvent.y or 48
	local first = true
	local count = 0
	local isFixedTeam, fixed_team = InfoDungeon.isFixedTeam()

	if isFixedTeam then
		local heroes = StageUtils.getFixedHero()

		for i, heroInfo in ipairs(heroes) do
			local unit = TeamManager.createUnitByTemplete(heroInfo, first)
			local x, y = global.map:tileToMap(enterX, enterY)

			unit:display(global.map, x, y)

			if not first then
				global.player:addToTrain(unit)
			end

			first = false
			count = count + 1
		end
	else
		if not InfoHero.hasHero() then
			return
		end

		local teamData = {}
		local heros = InfoHero.getTeam()

		for i, v in ipairs(heros) do
			table.insert(teamData, v)
		end

		for i = 1, #teamData do
			local heroInfo = teamData[i]

			if heroInfo then
				local heroHp = InfoDungeon.getHeroHP(heroInfo.id)

				if not heroHp or heroHp > 0 then
					local unit = TeamManager.createUnitByData(heroInfo, first)
					local x, y = global.map:tileToMap(enterX, enterY)

					unit:display(global.map, x, y)

					if heroHp then
						unit.battleData.hp = heroHp
					end

					if not first then
						global.player:addToTrain(unit)
					end

					first = false
					count = count + 1
				elseif not InfoDungeon.inGap() then
					local corpseInfo = DungeonState.getCorpse(heroInfo.id)

					if corpseInfo and corpseInfo.map_index == InfoDungeon.getMapIndex() then
						local tile = global.map:mapToTile(corpseInfo.x, corpseInfo.y)

						if tile then
							local unit = TeamManager.createUnitByData(heroInfo, false)

							unit:display(global.map, corpseInfo.x, corpseInfo.y)

							unit.angle = corpseInfo.angle

							unit:recoverDead()
						end
					end
				end
			end
		end
	end

	TeamManager.refreshTeamLeader()
	TeamManager.refreshTeamShrineBuff()

	local destX = enterInfo.dest_x
	local destY = enterInfo.dest_y

	if (empty(destX) or not empty(destY)) and destData then
		destX = destData.x
		destY = destData.y
	end

	if destX and destY then
		local mapX, mapY = global.map:tileToMap(destX, destY)

		if not noEnterAction then
			if mode == 1 then
				global.player:setGoDirectionLocked("enterDest", true)
				global.player:draw(mapX, mapY, true)
				global.player:checkTrain()

				local angle = math.atan2(destY - enterY, destX - enterX)
				local units = global.player:getTrainUnits()

				for i, unit in ipairs(units) do
					unit.angle = angle
					local effectGen = unit:getEffectGen()

					if effectGen then
						effectGen:zmove(0, 1000)
					end

					local function fall()
						local effectGen = unit:getEffectGen()

						if i == #units then
							if effectGen then
								effectGen:zmove(60, 0, nil, function ()
									DungeonState.flush()
									MapEffect.quake()
									global.player:setGoDirectionLocked("enterDest", false)
								end)
							end
						elseif effectGen then
							effectGen:zmove(60, 0, nil, function ()
								MapEffect.quake()
							end)
						end
					end

					MapFrameManager.setTimeout(fall, 10 * (i - 1))
				end
			else
				global.player:setGoDirectionLocked("enterDest", true)
				global.player:go(mapX, mapY)
				global.player:setPathFinishedCallback(function ()
					DungeonState.flush()
					global.player:setGoDirectionLocked("enterDest", false)
				end)
			end
		else
			global.player:draw(mapX, mapY, true)
			global.player:checkTrain()
			DungeonState.flush()
		end
	elseif sitData then
		local trainPosArray = {}
		local faceX, faceY = nil

		if faceData then
			faceX, faceY = global.map:tileToMap(faceData.x, faceData.y)
		end

		local units = global.player:getTrainUnits()

		for i = 1, #sitData do
			local startX, startY = global.map:tileToMap(enterX, enterY)

			if i > 1 then
				startX, startY = global.map:tileToMap(sitData[i - 1].x, sitData[i - 1].y)
			end

			local info = ConfParser.parse(sitData[i].info)
			local endX, endY = global.map:tileToMap(sitData[i].x, sitData[i].y)
			local trainSteps = math.ceil(global.map.ptPerTile / Player.normalSpeed)

			if units[i + 1] then
				units[i + 1].x = endX
				units[i + 1].y = endY

				units[i + 1]:draw()

				if faceData then
					units[i + 1].angle = math.atan2(faceY - endY, faceX - endX)
				end

				if info.sit == 1 then
					units[i + 1]:setAction("sit")
					units[i + 1]:randomizeFrame()
				end
			end

			local angle = math.atan2(startY - endY, startX - endX)

			for j = 1, trainSteps do
				local x = startX + (endX - startX) * j / trainSteps
				local y = startY + (endY - startY) * j / trainSteps

				table.insert(trainPosArray, {
					x = x,
					y = y,
					d = global.player:getDir(angle)
				})
			end
		end

		global.player:setTrain(trainPosArray)

		global.player.angle = math.atan2(faceY - global.player.y, faceX - global.player.x)

		DungeonState.flush()
	else
		DungeonState.flush()
	end

	if unitChangeListener then
		unitChangeListener()
	end

	TeamManager.ready = true
end

function TeamManager.refillAll()
	if not global.player then
		return
	end

	local team = TeamManager.getTeam()
	local teamInfos = InfoHero.getTeam()

	for i = 1, math.max(#team, #teamInfos) do
		if team[i] and teamInfos[i] then
			team[i]:setInfo(teamInfos[i])
			team[i]:refill()
		elseif team[i] then
			global.player:removeFromTrain(team[i])
		else
			local unit = TeamManager.createUnitByData(teamInfos[i])

			unit:display(global.map, global.player.x, global.player.y)
			global.player:addToTrain(unit)
			unit:refill()
		end
	end

	dump(TeamManager.deadUnitArr, "$$$ TeamManager.deadUnitArr")

	if TeamManager.deadUnitArr then
		for i, unit in ipairs(TeamManager.deadUnitArr) do
			if not tolua.isnull(unit) then
				unit:removeSelf()
			end
		end

		TeamManager.deadUnitArr = nil
	end
end

function TeamManager.getTeam()
	if global.player then
		local units = global.player:getTrainUnits()

		return units
	end

	return {}
end

function TeamManager.getDieHero()
	local units = ClipOnMap.getUnitList("hero")

	for i, unit in ipairs(units) do
		if unit.battleData and unit.battleData.die then
			return unit
		end
	end
end

function TeamManager.refreshTeam(inDungeon)
	if not global.player then
		return
	end

	local team = TeamManager.getTeam()
	local teamInfos = InfoHero.getTeam()

	if inDungeon then
		local newTeamInfos = {}

		for i, heroInfo in ipairs(teamInfos) do
			if InfoDungeon.getHeroHP(heroInfo.id) > 0 then
				table.insert(newTeamInfos, heroInfo)
			end
		end

		teamInfos = newTeamInfos
	end

	for i = 1, math.max(#team, #teamInfos) do
		if team[i] and teamInfos[i] then
			team[i]:setInfo(teamInfos[i])
		elseif team[i] then
			global.player:removeFromTrain(team[i])
		else
			local unit = TeamManager.createUnitByData(teamInfos[i])

			unit:display(global.map, global.player.x, global.player.y)
			global.player:addToTrain(unit)
		end
	end

	TeamManager.refreshTeamLeader()
	TeamManager.refreshTeamShrineBuff()

	if unitChangeListener then
		unitChangeListener()
	end

	notify.dispatch("team_refresh_team")
end

function TeamManager.refreshTeamHp()
	if not global.player then
		return
	end

	local heros = TeamManager.getTeam()

	for i, hero in ipairs(heros) do
		hero:refreshHp()
	end

	notify.dispatch("team_refresh_team")
end

function TeamManager.refreshTeamShrineBuff()
	if not global.player then
		return
	end

	local allBuffs = {}
	local shrineData = InfoDungeon.getShrineData()

	for index, shrineInfo in pairs(shrineData) do
		local buffs = {
			shrineInfo.id
		}
		local random = Random.new(shrineInfo.seed)

		for i, v in ipairs(buffs) do
			table.insert(allBuffs, {
				id = v,
				seed = random:getInt(1, 65535)
			})
		end
	end

	local unionBuff = InfoDungeon.getUnionBuff()

	dump(unionBuff, "$$$ unionBuff")

	for i, v in ipairs(unionBuff) do
		local csv = CsvParser.getCsvData("union_buff", v)
		local buffArr = SheetUtil.getColumnValueList(csv, "buff_id_")

		for i, v in ipairs(buffArr) do
			table.insert(allBuffs, {
				seed = 1,
				id = v
			})
		end
	end

	local heros = TeamManager.getTeam()

	for i, hero in ipairs(heros) do
		hero:clearShrineBuff()

		for j, v in ipairs(allBuffs) do
			hero:addShrineBuff(v.id, v.seed)
		end
	end

	notify.dispatch("team_refresh_team")
end

function TeamManager.getHeroByID(id)
	if global.player then
		local units = global.player:getTrainUnits()

		for i, unit in ipairs(units) do
			if unit.info.id == id then
				return unit
			end
		end
	end
end

function TeamManager.getHeroByPos(pos)
	local isFixedTeam, fixed_team = InfoDungeon.isFixedTeam()

	if isFixedTeam then
		if global.player then
			local units = global.player:getTrainUnits()

			return units[pos]
		end
	else
		local teamInPos = InfoHero.getTeamInPos()
		local heroInfo = teamInPos[pos]

		if not heroInfo then
			return
		end

		if global.player then
			local units = global.player:getTrainUnits()

			for i, unit in ipairs(units) do
				if unit.info.id == heroInfo.id then
					return unit
				end
			end
		end
	end
end

function TeamManager.getHeroByIndex(index)
	if global.player then
		local units = global.player:getTrainUnits()

		return units[index]
	end
end

function TeamManager.getTeamNum()
	if global.player then
		return #global.player:getTrainUnits()
	end

	return 0
end

function TeamManager.getUnits()
	if global.player then
		return global.player:getTrainUnits()
	end

	return {}
end

function TeamManager.getUnit(index)
	if global.player then
		return global.player:getTrainUnits()[index]
	end
end

function TeamManager.getRandomUnit(random)
	random = random or Random.new(math.random(1, 65535))
	local units = TeamManager.getUnits()
	units = random:order(units)

	return units[1]
end

function TeamManager.refreshPets()
end

function TeamManager.refreshTeamLeader()
	local heros = TeamManager.getTeam()

	for i, hero in ipairs(heros) do
		hero:refreshSkillHud()
	end
end

function TeamManager.getPlayerUnit()
	if not InfoHero.hasHero() then
		return
	end

	local team = InfoHero.getTeam()

	for i, heroInfo in ipairs(team) do
		local unit = TeamManager.createUnitByData(heroInfo, true)

		return unit
	end
end

function TeamManager.regroup(onRegroupOver)
	if not global.player then
		return
	end

	local deadUnitArr = nil

	if global.player.battleData.die then
		local units = global.player:getTrainUnits()
		local newTeamInfos = {}
		local deathInfos = {}

		for i, unit in ipairs(units) do
			local infoPack = {
				info = unit.info,
				x = unit.x,
				y = unit.y,
				angle = unit.angle
			}

			if unit.battleData.die then
				table.insert(deathInfos, infoPack)
			else
				table.insert(newTeamInfos, infoPack)
			end
		end

		deadUnitArr = {}

		for i, unit in ipairs(units) do
			local pack = nil

			if i <= #newTeamInfos then
				pack = newTeamInfos[i]

				unit:refill()
				print("$$$ ??? unit:refill()")
			else
				pack = deathInfos[i - #newTeamInfos]

				unit:die()
				table.insert(deadUnitArr, unit)
			end

			unit:setInfo(pack.info)

			unit.angle = pack.angle

			unit:draw(pack.x, pack.y, true)

			unit.speed = Player.normalSpeed
		end

		global.player:cutTrain(#newTeamInfos - 1)
		global.player:fillTrain()
	else
		deadUnitArr = global.player:removeDead()
	end

	global.player:regroupTrain(onRegroupOver)

	if #deadUnitArr > 0 then
		notify.dispatch("team_refresh_team")
	end

	TeamManager.deadUnitArr = deadUnitArr
end

function TeamManager.stopAllRevive()
	if not global.player then
		return
	end

	local units = global.player:getTrainUnits()

	for i, unit in ipairs(units) do
		unit:stopRevive()
	end
end

return TeamManager
