local NAV_base = import(".NAV_base")
local NAV_merchant = class("NAV_merchant", NAV_base)

function NAV_merchant.open(npc, shopType)
	print("$$$ NAV_merchant.open", shopType)

	local ui = NAV_merchant.new(npc, shopType)

	return ui
end

function NAV_merchant:ctor(npc, shopType)
	NAV_merchant.super.ctor(self, npc, "nav_merchant")

	self.shopType = shopType
end

function NAV_merchant:onTap(index)
	NAV_merchant.super.onTap(self, index)
	print("NAV_merchant:onTap", index, self.npc)

	if index == 1 then
		FRAME_merchant.open(self.npc, self.shopType)
	end
end

return NAV_merchant
