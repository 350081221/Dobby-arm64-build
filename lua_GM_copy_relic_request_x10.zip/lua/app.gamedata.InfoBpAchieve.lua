local InfoBpAchieve = {}
local TYPE = {
	LIFE = 3,
	WEEK = 2,
	DAY = 1
}
InfoBpAchieve.TYPE = TYPE
local rawData = {}
local bp_id, day_refresh, week_refresh = nil

function InfoBpAchieve.init()
	Connection.listen("bp_achieve_sync", InfoBpAchieve.sync)
	Connection.listen("bp_achieve_sync_remove", InfoBpAchieve.syncRemove)
end

app:addToAppEnterCall(InfoBpAchieve.init)

function InfoBpAchieve.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoBpAchieve.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("bp_achieve_query", callback)
end

function InfoBpAchieve.onQuery(rcvData)
	dump(rcvData, "bp_achieve_query")

	rawData = {}

	for i, data in ipairs(rcvData.list) do
		rawData[data.base_id] = data
	end

	bp_id = rcvData.bp_id
	day_refresh = rcvData.day_refresh
	week_refresh = rcvData.week_refresh
end

function InfoBpAchieve.sync(data)
	dump(data, "$$$ InfoBpAchieve.sync")

	if data.list then
		for i, syncData in ipairs(data.list) do
			local base_id = syncData.base_id

			if rawData[base_id] then
				for k, v in pairs(syncData) do
					rawData[base_id][k] = v
				end
			else
				rawData[base_id] = syncData
			end
		end
	end

	if data.bp_id then
		bp_id = data.bp_id
	end

	if data.day_refresh then
		day_refresh = data.day_refresh
	end

	if data.week_refresh then
		week_refresh = data.week_refresh
	end

	notify.dispatch("campaign_changed")
	ManagerInfo.dataChange("bp_achieve")
end

function InfoBpAchieve.syncRemove(data)
	dump(data, "$$$ InfoBpAchieve.syncRemove")

	if data.list then
		for i, base_id in ipairs(data.list) do
			rawData[base_id] = nil
		end
	end
end

function InfoBpAchieve.getList()
	local arr = {}

	for base_id, data in pairs(rawData) do
		table.insert(arr, data)
	end

	table.sort(arr, function (a, b)
		if a.type == b.type then
			return a.type < b.type
		else
			return a.base_id < b.base_id
		end
	end)

	return arr
end

function InfoBpAchieve.countRedot()
	local redotCount = 0
	local arr = InfoBpAchieve.getList()

	for i, v in ipairs(arr) do
		local count, countMax, rewarded = InfoBpAchieve.checkExp(v)

		if rewarded == 0 and countMax <= count then
			redotCount = redotCount + 1
		end
	end

	return redotCount
end

function InfoBpAchieve.checkExp(data)
	local csv = CsvParser.getCsvData("bp_achieve", data.base_id)
	local nowTime = Time.now()
	local count = data.count

	if csv.type == TYPE.DAY then
		if RefreshManager.checkTimePassed(RefreshManager.TYPE.BP_ACHIEVE_DAY, nowTime, data.count_time) then
			count = 0
		end
	elseif csv.type == TYPE.WEEK and RefreshManager.checkTimePassed(RefreshManager.TYPE.BP_ACHIEVE_WEEK, nowTime, data.count_time) then
		count = 0
	end

	local countMax = csv.num
	local rewarded = data.rewarded
	count = math.min(count, countMax)

	return count, countMax, rewarded
end

function InfoBpAchieve.getExp(base_id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("bp_achieve_get_exp", {
		base_id = base_id
	}, callback)
end

function InfoBpAchieve.refresh(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("bp_achieve_refresh", callback)
end

function InfoBpAchieve.checkRefresh(onSuccess, onFailure)
	local typeArr = {
		TYPE.DAY,
		TYPE.WEEK
	}
	local nowTime = Time.now()
	local needRefresh = false

	for i, type in ipairs(typeArr) do
		if type == TYPE.DAY then
			if RefreshManager.checkTimePassed(RefreshManager.TYPE.BP_ACHIEVE_DAY, nowTime, day_refresh) then
				needRefresh = true
			end
		elseif type == TYPE.WEEK and RefreshManager.checkTimePassed(RefreshManager.TYPE.BP_ACHIEVE_WEEK, nowTime, week_refresh) then
			needRefresh = true
		end
	end

	if not needRefresh then
		local bpData = InfoBp.getCurrent()

		if bpData and bpData.id ~= bp_id then
			needRefresh = true
		end
	end

	if needRefresh then
		InfoBpAchieve.refresh(onSuccess, onFailure)
	end
end

return InfoBpAchieve
