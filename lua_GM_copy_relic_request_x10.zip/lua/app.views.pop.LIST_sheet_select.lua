local List = import("...ui.List")
local LIST_sheet_select = class("LIST_sheet_select", List)

function LIST_sheet_select:ctor(rect)
	LIST_sheet_select.super.ctor(self, rect)
	self:setSpace(5, 5)
	self:setCellName("cell_sheet_select")
	self:setCellSize(cc.size(self.touchRect.width, 40))
end

function LIST_sheet_select:onCellInit(ui, data)
	ui:createLabelOnFlag("flag_id", data.id or "")
	ui:createLabelOnFlag("flag_name", data.name or "")
	ui:createLabelOnFlag("flag_key", data.key or "")
end

return LIST_sheet_select
