local UI_base = import("..UI_base")
local FRAME_actv_preview = class("FRAME_actv_preview", UI_base)

function FRAME_actv_preview.open(data)
	local ui = FRAME_actv_preview.new(data)

	PopManager.open(ui)
end

function FRAME_actv_preview:ctor(data)
	FRAME_actv_preview.super.ctor(self, "frame_actv_preview", UIManager.BIG_TYPE.POP)

	self.data = data

	self:init()
end

function FRAME_actv_preview:init()
	self:initUI()
end

function FRAME_actv_preview:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local title = Localization.getTextByLang(self.data.title)
	local info = Localization.getTextByLang(self.data.info)

	self:createLabelOnFlag("flag_title", title)

	local textArea = self:createTextAreaOnFlag("flag_content")

	textArea:setUbbEnabled(true)
	textArea:setSpace(3, 3)
	textArea:setText(info)
end

return FRAME_actv_preview
