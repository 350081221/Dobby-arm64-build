local ArcParam = class("ArcParam")
ArcParam.MOTION_MOVE = 0
ArcParam.MOTION_DUPLICATE = 1
ArcParam.LAYER_LOW = 0
ArcParam.LAYER_BASE = 1
ArcParam.LAYER_HIGH = 2
ArcParam.PARTICLE_ASH = 0
ArcParam.PARTICLE_CLIP = 1
ArcParam.PARTICLE_SPINE = 2
ArcParam.START_FIXED = 0
ArcParam.START_RANDOM_RADIUS = 1
ArcParam.START_RANDOM = 2
ArcParam.LIFE_BOX = 0
ArcParam.LIFE_TIME = 1
ArcParam.props = {
	"amount",
	"angle",
	"motion",
	"duplicateInterval",
	"axialMotion.speed",
	"axialMotion.acc",
	"axialMotion.decay",
	"axialMotion.chaosValue",
	"axialMotion.chaosContinuous",
	"radialMotion.speed",
	"radialMotion.acc",
	"radialMotion.decay",
	"radialMotion.chaosValue",
	"radialMotion.chaosContinuous",
	"whirlMotion.speed",
	"whirlMotion.acc",
	"whirlMotion.decay",
	"whirlMotion.chaosValue",
	"whirlMotion.chaosContinuous",
	"layer",
	"particleType",
	"clipURL",
	"clipHue",
	"clipHueRandom",
	"startType",
	"startX",
	"startY",
	"startRadius",
	"startZ",
	"lifeType",
	"lifeCount",
	"boxMinRadius",
	"boxMaxRadius",
	"boxMinZ",
	"boxMaxZ",
	"startInterval",
	"lightRadius",
	"lightAlpha"
}

function ArcParam:ctor(arcEffect, paramStr)
	self.container = arcEffect

	self:deserialize(paramStr)
end

function ArcParam:deserialize(paramStr)
	paramStr = string.gsub(paramStr, "~", "&0")
	local paramArr = string.split(paramStr, "&")
	local speedArr = {}

	for i = 1, #ArcParam.props do
		if string.find(ArcParam.props[i], "Motion") then
			table.insert(speedArr, tonumber(paramArr[i]))

			if #speedArr == 5 then
				local propNameArr = string.split(ArcParam.props[i], ".")
				self[propNameArr[1]] = ArcSpeed.new(self.container, speedArr)
				speedArr = {}
			end
		else
			local value = tonumber(paramArr[i])

			if value == nil then
				value = paramArr[i]
			end

			self[ArcParam.props[i]] = value
		end
	end

	if Sound.getDislayLevel() >= 1 then
		self.amount = math.ceil(self.amount / 2)
		self.startInterval = self.startInterval * 2

		if self.motion == ArcParam.MOTION_DUPLICATE then
			self.duplicateInterval = self.duplicateInterval * 2
		end
	end
end

return ArcParam
