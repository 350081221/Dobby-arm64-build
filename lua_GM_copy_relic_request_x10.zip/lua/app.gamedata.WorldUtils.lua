local WorldUtils = {}
local statusLabelMap = {
	{
		name = Localization.getSrcText("正常"),
		style = {
			color = Style.green
		}
	},
	{
		name = Localization.getSrcText("爆满"),
		style = {
			color = Style.red
		}
	},
	{
		name = Localization.getSrcText("维护"),
		style = {
			color = Style.gray
		}
	}
}

function WorldUtils.getStatusLabel(status)
	return statusLabelMap[status]
end

function WorldUtils.getStatus(data)
	local status = nil
	local isClosing = false

	if empty(data.addr) then
		status = 3
	elseif data.server_open_state ~= 1 then
		isClosing = true
		status = 3
	elseif data.server_register_state ~= 1 then
		status = 2
	else
		status = 1
	end

	return status, statusLabelMap[status], isClosing
end

return WorldUtils
