local List = import("...ui.List")
local LIST_dungeon_prepare_carry = class("LIST_dungeon_prepare_carry", List)

function LIST_dungeon_prepare_carry:ctor(rect)
	LIST_dungeon_prepare_carry.super.ctor(self, rect)

	self.isBounc = false

	self:setCols(4, 70, 10)
	self:setCellName("cell_bag")
	self:setSpace(5, 5)
	self:setCellSize(cc.size(self.touchRect.width, 110))
end

function LIST_dungeon_prepare_carry:onCellInit(ui, data)
	if not ui.slot then
		ui.slot = DropSlot.new(ui:getFlagByTag("flag_slot"), "slot_01")

		ui:addChild(ui.slot, 100)
	end

	ui.slot:setAlwaysShowNumber(data.type == DropManager.TYPE.ITEM)
	ui:getComponentByTag("bg"):setVisible(data.enabled)
	ui:getComponentByTag("bg_disabled"):setVisible(not data.enabled)

	if data.type == DropManager.TYPE.EQUIP then
		local names, styles = InfoEquip.getNameDisplay(data.info)

		ui:createLabelGroupOnFlag("flag_name", names, styles, {
			align = Style.center
		})
	elseif data.type == DropManager.TYPE.ITEM then
		local name, style = InfoItem.getNameDisplay(data.info)

		ui:createLabelOnFlag("flag_name", name, style)
	end

	ui.slot:setDrop(data.type, data.info)
	ui.slot:setVisible(not empty(data.type))
	self:onCellSelected(ui, data, false)
end

function LIST_dungeon_prepare_carry:onCellSelected(ui, data, selected)
	ui.slot:setSelected(selected)
	ui:getComponentByTag("selected"):setVisible(selected)
end

function LIST_dungeon_prepare_carry:checkPickable(ui, data, x, y)
	return data.type ~= nil and ui:hitTest(cc.p(x, y))
end

function LIST_dungeon_prepare_carry:getPickNode(cell)
	if cell then
		return cell.slot
	end
end

return LIST_dungeon_prepare_carry
