local NAV_base = import(".NAV_base")
local NAV_gather = class("NAV_gather", NAV_base)

function NAV_gather.open(npc)
	local ui = NAV_gather.new(npc)

	return ui
end

function NAV_gather:ctor(npc)
	NAV_gather.super.ctor(self, npc, "nav_gather")
end

function NAV_gather:init()
	NAV_gather.super.init(self)

	local index = 1
	local ui = self.buttons[index].ui
	local button = self.buttons[index].button

	self:setButtonName(ui, self.npc.data.nav_text)
end

function NAV_gather:onTap(index)
	NAV_gather.super.onTap(self, index)
	print("NAV_gather:onTap", index, self.npc)

	if index == 1 then
		self.npc:openGather()
	end
end

return NAV_gather
