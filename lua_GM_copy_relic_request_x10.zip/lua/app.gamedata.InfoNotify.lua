local InfoNotify = {}
local rawData = nil
local towerStack = {}

function InfoNotify.init()
	Connection.listen("notify_push", InfoNotify.onPushNotify)
	Connection.listen("marquee_push", InfoNotify.onPushMarquee)
	Connection.listen("marquee_fixed_push", InfoNotify.onPushMarqueeFixed)
	Connection.listen("marquee_instant_push", InfoNotify.onPushMarqueeInstant)
end

app:addToAppEnterCall(InfoNotify.init)

function InfoNotify.onPushNotify(data)
	local csv = CsvParser.getCsvData("notify", data.notice_id)

	dump(csv, "$$$ onPushNotify")

	if csv.type == 1 then
		table.insert(towerStack, {
			time = Time.now(),
			data = data
		})
	end

	if csv.id == 500001 then
		InfoArena.replayAdd()
	end

	if csv.id == 700001 then
		InfoPetFeed.onVisitFeed()
	end

	notify.dispatch("notify_push", data)
end

function InfoNotify.onPushMarqueeInstant(data)
	if data and data.msg then
		notify.dispatch("marquee_push", {
			msg = data.msg
		})
	end
end

function InfoNotify.onPushMarquee(data)
	notify.dispatch("marquee_push", data)
end

function InfoNotify.onPushMarqueeFixed(data)
	if global.loginFrameOver then
		local isShowMarquee = Cookie.get("isShowMarquee") or 1
		local csv = CsvParser.getCsvData("marquee", data.id)

		if isShowMarquee == 1 or csv.is_festival ~= 1 then
			local text = csv.text

			if data.replace and #data.replace > 0 then
				text = StringUtil.replace(text, unpack(data.replace))
			end

			notify.dispatch("marquee_push", {
				msg = text
			})
		end
	end
end

function InfoNotify.getTowerStack()
	local newTowerStack = {}
	local now = Time.now()

	for i, v in ipairs(towerStack) do
		local data = v.data

		if now < v.time + data.time then
			table.insert(newTowerStack, v)
		end
	end

	towerStack = newTowerStack

	return towerStack
end

return InfoNotify
