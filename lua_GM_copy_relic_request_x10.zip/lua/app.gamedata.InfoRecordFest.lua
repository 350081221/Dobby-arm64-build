local InfoRecordFest = {}
local TYPE = {
	WEEK = 2,
	FIRST = 1
}
InfoRecordFest.TYPE = TYPE
local rawData = nil

function InfoRecordFest.init()
	Connection.listen("record_fest_sync", InfoRecordFest.sync)
end

app:addToAppEnterCall(InfoRecordFest.init)

function InfoRecordFest.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoRecordFest.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("record_fest_query", callback)
end

function InfoRecordFest.onQuery(rcvData)
	rawData = {}

	for i = 1, #rcvData.list do
		local data = rcvData.list[i]
		rawData[data.type] = data
	end
end

function InfoRecordFest.sync(data)
	for i, syncData in ipairs(data.list) do
		local type = syncData.type

		if not rawData[type] then
			rawData[type] = syncData
		else
			for k, v in pairs(syncData) do
				rawData[type][k] = v
			end
		end
	end

	notify.dispatch("campaign_changed")
	ManagerInfo.dataChange("record_fest")
end

function InfoRecordFest.getReward(type, day, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("record_fest_get_reward", {
		type = type,
		day = day
	}, callback)
end

function InfoRecordFest.getRecord(type, day)
	local data = rawData[type]

	if data then
		local recordNum = rawData[type].reward_record

		return BitUtil.getBitByIndex(recordNum, day)
	else
		return 0
	end
end

function InfoRecordFest.getDays(type)
	local nowTime = Time.now()
	local data = rawData[type]

	if data then
		local login_time = data.login_time
		local login_days = data.login_days
		local dayPassed = RefreshManager.checkTimePassedDays(RefreshManager.TYPE.SIGN_IN, nowTime, login_time)

		return login_days + dayPassed
	else
		return 0
	end
end

function InfoRecordFest.getTypeMap()
	local record_fest_typeMap = CacheData.get("InfoRecordFest_record_fest_typeMap")

	if not record_fest_typeMap then
		record_fest_typeMap = {}
		local csvRaw = CsvParser.getCsvRaw("record_fest")

		for k, v in pairs(csvRaw) do
			if not record_fest_typeMap[v.type] then
				local typeCsv = CsvParser.getCsvData("record_fest_type", v.type)
				record_fest_typeMap[v.type] = {
					dayTotal = 0,
					csv = typeCsv,
					days = {}
				}
			end

			record_fest_typeMap[v.type].days[v.day] = v
			record_fest_typeMap[v.type].dayTotal = record_fest_typeMap[v.type].dayTotal + 1
		end

		CacheData.set("InfoRecordFest_record_fest_typeMap", record_fest_typeMap)
	end

	return record_fest_typeMap
end

function InfoRecordFest.getList(type)
	local typeMap = InfoRecordFest.getTypeMap()
	local v = typeMap[type]
	local days = v.days
	local arr = {}

	for k, v in pairs(days) do
		table.insert(arr, v)
	end

	table.sort(arr, function (a, b)
		return a.day < b.day
	end)

	return arr
end

function InfoRecordFest.countRedot(type)
	local nowTime = Time.now()
	local typeMap = InfoRecordFest.getTypeMap()
	local redotCount = 0
	local v = typeMap[type]
	local csv = v.csv
	local days = v.days

	if empty(csv.festival_id) or InfoFestival.checkOpening(csv.festival_id) then
		for k, v in pairs(days) do
			if v.day <= InfoRecordFest.getDays(v.type) and InfoRecordFest.getRecord(type, v.day) == 0 then
				redotCount = redotCount + 1
			end
		end
	end

	print("$$$ InfoRecordFest.countRedot", type, redotCount)

	return redotCount
end

function InfoRecordFest.isOpen(type)
	local nowTime = Time.now()
	local typeMap = InfoRecordFest.getTypeMap()
	local v = typeMap[type]
	local csv = v.csv
	local days = v.days

	if empty(csv.festival_id) or InfoFestival.checkOpening(csv.festival_id) then
		for k, v in pairs(days) do
			if InfoRecordFest.getRecord(type, v.day) == 0 then
				return true
			end
		end
	end

	return false
end

function InfoRecordFest.checkOpening(type)
	local data = rawData[type]

	if not data then
		return false
	end

	local nowTime = Time.now()
	local typeMap = InfoRecordFest.getTypeMap()
	local redotCount = 0
	local v = typeMap[type]
	local csv = v.csv

	if empty(csv.festival_id) or InfoFestival.checkOpening(csv.festival_id) then
		return true
	else
		return false
	end
end

function InfoRecordFest.isActived(type)
	local data = rawData[type]

	return data ~= nil
end

return InfoRecordFest
