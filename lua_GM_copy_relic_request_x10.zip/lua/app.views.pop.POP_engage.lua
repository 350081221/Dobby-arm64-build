local POP_engage = class("POP_engage", UI_base)

function POP_engage.open(onComplete)
	local ui = POP_engage.new(onComplete)

	display.getRunningScene():addChild(ui, LayerConfig.pop)
end

function POP_engage:ctor(onComplete)
	POP_engage.super.ctor(self, "pop_engage")

	self.onComplete = onComplete

	self:init()
end

function POP_engage:init()
	self:initUI()

	local showTime = 0.7

	self:setOpacity(0)
	transition.fadeTo(self, {
		easing = "sineOut",
		opacity = 255,
		time = 0.2
	})
	self:performWithDelay(function ()
		if self.onComplete then
			self.onComplete()
		end
	end, showTime)
	transition.fadeTo(self, {
		easing = "sineOut",
		opacity = 0,
		time = 0.2,
		delay = showTime,
		onComplete = function ()
			self:removeSelf()
		end
	})
end

function POP_engage:initUI()
	local mask = self:getComponentByTag("mask")

	mask:toTouchable()

	local text = Localization.getSrcText("战 斗 开 始")
	local len = utf8.len(text)
	local textArray = {}

	for i = 1, len do
		table.insert(textArray, utf8.sub(text, i, i))
	end

	local labelArray = self:createLabelGroupOnFlag("flag_msg", textArray)

	for i = 1, #labelArray do
		local label = labelArray[i]
		local y = label:getPositionY()

		label:setPositionY(y - 50)
		label:setOpacity(0)
		transition.fadeTo(label, {
			easing = "sineOut",
			opacity = 255,
			time = 0.2,
			delay = 0.02 * i
		})
		transition.moveTo(label, {
			easing = "backOut",
			time = 0.2,
			delay = 0.02 * i,
			y = y
		})
	end
end

return POP_engage
