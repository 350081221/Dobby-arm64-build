local InfoArmory = {}
local rawData = {}

function InfoArmory.init()
	Connection.listen("armory_sync", InfoArmory.sync)
end

app:addToAppEnterCall(InfoArmory.init)

function InfoArmory.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoArmory.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("armory_query", callback)
end

function InfoArmory.onQuery(rcvData)
	dump(rcvData, "armory_query")

	rawData = {}

	for i, data in ipairs(rcvData.list) do
		rawData[data.id] = data
	end
end

function InfoArmory.sync(data)
	dump(data, "$$$ InfoArmory.sync")

	for i, syncData in ipairs(data.list) do
		local id = syncData.id

		if rawData[id] then
			for k, v in pairs(syncData) do
				rawData[id][k] = v
			end
		else
			rawData[id] = syncData
		end
	end

	ManagerInfo.dataChange("armory")
end

function InfoArmory.setName(index, heroInfo, name, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ armory_set_name")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)

	Connection.request("armory_set_name", {
		index = index,
		hero_class = heroCSV.class,
		name = name
	}, callback)
end

function InfoArmory.save(index, heroInfo, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ armory_save")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)
	local data = {
		index = index,
		hero_class = heroCSV.class
	}

	for i = 1, 4 do
		local equipInfo = InfoEquip.getEquipOnHero(heroInfo.id, i)

		if equipInfo then
			data["equip_" .. i] = equipInfo.id
		else
			data["equip_" .. i] = 0
		end
	end

	local cardInfo = InfoCard.getCardOnHero(heroInfo.id, 1)

	if cardInfo then
		data.card = cardInfo.id
	else
		data.card = 0
	end

	dump(data, "$$$ InfoArmory.save")
	Connection.request("armory_save", data, callback)
end

function InfoArmory.getArmoryInfo(heroInfo, armory_index)
	local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)

	for id, data in pairs(rawData) do
		if data.armory_index == armory_index and data.hero_class == heroCSV.class then
			return data
		end
	end
end

function InfoArmory.getList(heroInfo)
	local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)
	local hero_class = heroCSV.class
	local amountData = InfoConsume.getArmoryAmount()
	local num = amountData.num
	local show_num = amountData.show_num
	local indexMap = {}

	for id, data in pairs(rawData) do
		if data.hero_class == heroCSV.class then
			indexMap[data.armory_index] = data
		end
	end

	local arr = {}

	for i = 1, show_num do
		if i <= num then
			table.insert(arr, {
				info = indexMap[i]
			})
		else
			table.insert(arr, {
				closed = true
			})
		end
	end

	return arr
end

return InfoArmory
