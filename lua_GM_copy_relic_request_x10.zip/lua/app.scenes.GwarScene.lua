local GwarScene = class("GwarScene", function ()
	return display.newScene("GwarScene")
end)

function GwarScene.pve(rawData, zoneData, round)
	FRAME_wild.close()
	FRAME_union_pve.close()

	local mapName = "gwar_1"
	local csv = CsvParser.getCsvData("gwar_monster_create", rawData.stage_id)

	if csv then
		mapName = csv.map
	end

	Log.verbose("GwarScene.enterMap", mapName)

	GwarScene.mapName = mapName
	GwarScene.data = {
		type = GwarCore.TYPE.PVE,
		battle_id = rawData.stage_id,
		team1 = rawData.heros,
		buff1 = rawData.buffs,
		seed = rawData.battle_seed,
		hash = rawData.battle_hash,
		score = rawData.score,
		isReplay = rawData.isReplay,
		isEmu = rawData.isEmu,
		isTest = rawData.isTest
	}

	dump(GwarScene.data, "$$$ GwarScene.data")
	GwarScene.open()
end

function GwarScene.unionWar(rawData, zoneData, round)
	FRAME_wild.close()
	FRAME_union_pve.close()

	local mapName = "gwar_1"

	Log.verbose("GwarScene.enterMap", mapName)

	GwarScene.mapName = mapName

	dump(rawData, "$$$ rawData")

	GwarScene.data = {
		type = GwarCore.TYPE.PVP,
		team1 = rawData.battle_side_a.heros,
		team2 = rawData.battle_side_b.heros,
		buff1 = rawData.battle_side_a.support,
		buff2 = rawData.battle_side_b.support,
		union1 = rawData.battle_side_a.union_info,
		union2 = rawData.battle_side_b.union_info,
		win = rawData.who_is_win == rawData.battle_side_a.union_info.union_id and 1 or 2,
		seed = rawData.battle_seed,
		zone_id = zoneData.zone_id,
		round = round,
		hash = rawData.battle_hash,
		isTest = rawData.isTest
	}

	dump(GwarScene.data, "$$$ GwarScene.data")
	GwarScene.open()
end

function GwarScene.open()
	local type = GwarScene.data.type
	local name = Localization.getSrcText("会战")

	if type == GwarCore.TYPE.PVP then
		name = Localization.getSrcText("联盟会战")
	elseif type == GwarCore.TYPE.PVE then
		name = Localization.getSrcText("PVE")
	end

	Transition.setTitle(name)
	app:enterScene("GwarScene")
end

function GwarScene:ctor()
	Log.debug("GwarScene:ctor")
	event_listener.extendMethods(self, true)
end

function GwarScene:init()
	self:initMap()
	self:initUnits()

	self.ui = FRAME_gwar.new()

	self:addChild(self.ui)

	global.ui = self.ui
	local type = GwarScene.data.type

	if type == GwarCore.TYPE.PVE then
		self.gplay:setBossCallback(function (bossData)
			if bossData and self.ui and self.ui.onBossChange then
				self.ui:onBossChange(bossData)
			end
		end)
		self.gplay:onRoundBoss()
	end

	self.gplay:setChangeCallback(function (teamCount)
		self:onTeamChange(teamCount)
	end)
	self.gplay:setNewRoundCallback(function ()
		self:onNewRound()
	end)
end

function GwarScene:getTeamMap()
	local maxTeam = 2
	local type = GwarScene.data.type

	if type == GwarCore.TYPE.PVP then
		maxTeam = 2
	elseif type == GwarCore.TYPE.PVE then
		maxTeam = 1
	end

	local rawTeamMap = {
		GwarScene.data.team1,
		GwarScene.data.team2
	}
	local teamMap = {}
	local unitID = 1

	for camp = 1, maxTeam do
		teamMap[camp] = {}
		local rawTeam = rawTeamMap[camp]

		for i, heroInfo in ipairs(rawTeam) do
			table.insert(teamMap[camp], {
				heroInfo = heroInfo
			})
		end

		for i, teamOne in ipairs(teamMap[camp]) do
			local heroCSV = CsvParser.getCsvData("hero", teamOne.heroInfo.base_id)
			teamOne.job = heroCSV.class
			teamOne.camp = camp
			teamOne.attrs = {}

			for _, attrKey in ipairs(CombatAttr.attrs) do
				local value = teamOne.heroInfo["attr_" .. attrKey]
				local key = "gwar_" .. attrKey .. "_" .. GwarCore.UNIT_KEY[heroCSV.class]
				value = value * InfoUnion.getConfig(key)
				teamOne.attrs[attrKey] = math.floor(value)
			end

			teamOne.battleData = {
				hp = teamOne.attrs.hp
			}
			teamOne.id = unitID
			unitID = unitID + 1
		end
	end

	return teamMap
end

function GwarScene:initUnits()
	local teamMap = self:getTeamMap()
	local seed = GwarScene.data.seed
	self.gcore = GwarCore.new()
	local type = GwarScene.data.type

	if type == GwarCore.TYPE.PVP then
		self.gcore:pvp(teamMap[1], teamMap[2], seed, GwarScene.data.buff1, GwarScene.data.buff2)

		self.gplay = GwarPlay.new(self.gcore, function (winCamp)
			local hash = self.gcore:getHash()
			local hash2 = ""

			if DEV_MODE then
				local teamMap2 = self:getTeamMap()
				local gcore2 = GwarCore.new()

				gcore2:pvp(teamMap2[1], teamMap2[2], seed, GwarScene.data.buff1, GwarScene.data.buff2)
				gcore2:start()

				hash2 = gcore2:getHash()
			end

			print("阵营" .. winCamp .. "胜利", GwarScene.data.seed, GwarScene.data.hash == hash, GwarScene.data.hash, hash, hash2)
			FRAME_gwar_result.open(self.gcore)
		end)
	elseif type == GwarCore.TYPE.PVE then
		self.gcore:pve(teamMap[1], GwarScene.data.battle_id, seed, GwarScene.data.buff1)

		self.gplay = GwarPlay.new(self.gcore, function (winCamp)
			local hash = self.gcore:getHash()
			local hashArr = {}

			if DEV_MODE then
				for i = 1, 1 do
					local teamMap2 = self:getTeamMap()
					local gcore2 = GwarCore.new()

					gcore2:pve(teamMap2[1], GwarScene.data.battle_id, seed, GwarScene.data.buff1)
					gcore2:start()

					local hash2 = gcore2:getHash()

					table.insert(hashArr, hash2)
				end
			end

			local score = self.gcore.pveScore

			print("PVE结束", GwarScene.data.seed, GwarScene.data.hash == hash, score == GwarScene.data.score, score, GwarScene.data.score, GwarScene.data.hash, hash)

			if DEV_MODE then
				for i, hash2 in ipairs(hashArr) do
					print("$$$ hash2", i, hash2)
				end
			end

			FRAME_gwar_result.open(self.gcore)
		end)
	end

	self.gplay:start()
end

function GwarScene:onTeamChange(teamCount)
	self.ui:onTeamChange(teamCount)
end

function GwarScene:onNewRound()
	self.ui:onNewRound()
end

function GwarScene:exit()
	local main_map = UserCookie.get("main_map")

	if main_map == "union" and InfoUnion.hasUnion() then
		InfoUnion.enterMap()

		return
	end

	InfoDungeon.enterCamp()
end

function GwarScene:initMap()
	local map = Map.new(display.width, display.height)

	self:addChild(map)
	map:setGamma(Sound.getGamma())
	map:load(GwarScene.mapName)

	global.map = map
	local battleCenter = MapEventManager.getEventByTagOne("battle-center")
	local centerX, centerY = map:tileToMap(battleCenter.x, battleCenter.y)
	centerX = centerX + 48
	centerY = centerY + 48

	map:scrollTo(centerX, centerY)
	map:setFov(centerX, centerY)
end

function GwarScene:onEnter()
	app:onSceneEnter(self, nil, 1)
	self:init()
end

function GwarScene:onExit()
	global.player = nil
	global.ui = nil
	global.map = nil
	global.battleUI = nil
	global.adventureUI = nil

	app:onSceneExit(self)
end

return GwarScene
