local DisplayUtil = {}

function DisplayUtil.changeParent(node, newParent, newZOrder)
	node._originalParent = node:getParent()
	node._originalZOrder = node:getLocalZOrder()

	node:retain()
	node:removeFromParent(false)
	newParent:addChild(node, newZOrder)
	node:release()
end

function DisplayUtil.recoverParent(node)
	if node._originalParent then
		node:retain()
		node:removeFromParent(false)
		node._originalParent:addChild(node, node._originalZOrder)
		node:release()
	end
end

return DisplayUtil
