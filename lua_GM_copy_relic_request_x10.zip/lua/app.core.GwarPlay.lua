local GwarPlay = class("GwarPlay")
GwarPlay.multiple_interval = 10

function GwarPlay:ctor(gcore, onOver)
	self.gcore = gcore
	self.onOver = onOver
	self.round = 1

	self:init()

	self.random = Random.new(gcore.seed)
end

function GwarPlay:init()
	self.unitMap = {}
	self.teamCount = {}

	for camp = 1, 2 do
		local teamArr = self.gcore:getTeamArr(camp)

		for i, teamOne in ipairs(teamArr) do
			self:createOne(camp, teamOne, true)
		end

		self.teamCount[camp] = {
			max = self.gcore.teamCountMap[camp],
			num = self.gcore.teamCountMap[camp]
		}
	end
end

function GwarPlay:createOne(camp, teamOne, isInit)
	local map = global.map
	local tile = GwarPlay.getTile(camp, teamOne.x, teamOne.y + (isInit and 2 or 0))
	local unit = HeroGwar.new()
	unit.gwarCamp = camp
	unit.campAngle = camp == 1 and math.pi or 0
	unit.angle = unit.campAngle

	if teamOne.type == GwarCore.TEAM_TYPE.MONSTER then
		unit:setMonster(teamOne.base_id)
	else
		unit:setInfo(teamOne.heroInfo)
	end

	local mapX, MapY = map:tileToMap(tile)

	unit:display(map, mapX, MapY)
	unit:init(teamOne)
	unit:onBattleStart()
	unit:addEventListener("die", function ()
		self:onDie(unit)
	end)

	self.unitMap[teamOne.id] = unit

	return unit
end

function GwarPlay:getRound()
	return self.round
end

function GwarPlay:onDie(unit)
	self.teamCount[unit.gwarCamp].num = self.teamCount[unit.gwarCamp].num - 1

	if self.changeCallback then
		self.changeCallback(self.teamCount)
	end
end

function GwarPlay:setNewRoundCallback(changeCallback)
	self.newRoundCallback = changeCallback

	if self.newRoundCallback then
		self.newRoundCallback()
	end
end

function GwarPlay:setBossCallback(bossCallback)
	self.bossCallback = bossCallback

	if self.bossCallback then
		self.bossCallback(self.bossData)
	end
end

function GwarPlay:setChangeCallback(changeCallback)
	self.changeCallback = changeCallback

	if self.changeCallback then
		self.changeCallback(self.teamCount)
	end
end

function GwarPlay.getMonsterCenter(attacker, action_type)
	local tile = attacker.tile
	local areaEvent = MapEventManager.getEventByTagOne("area_1")
	local tileX = tile.x
	local tileY = tile.y

	if action_type == 2 then
		tileX = areaEvent.x - attacker.size
	elseif action_type == 3 then
		tileX = areaEvent.x - attacker.size
		tileY = math.floor(areaEvent.y + (areaEvent.h - 1) / 2 - (attacker.size - 1) / 2)
	end

	return tileX, tileY
end

function GwarPlay.getUnitPos(camp, tileX, tileY)
	local RAW_ARR = GwarCore.RAW_ARR
	local campF = 3 - camp * 2
	local areaEvent = MapEventManager.getEventByTagOne("area_" .. camp)

	if areaEvent.x <= tileX and tileX <= areaEvent.x + areaEvent.w - 1 then
		local startX = nil

		if camp == 1 then
			startX = areaEvent.x
		else
			startX = areaEvent.x + areaEvent.w - 1
		end

		local startY = areaEvent.y
		local xOffset = tileX - areaEvent.x
		local yOffset = tileY - areaEvent.y
		local unitX = nil

		if camp == 1 then
			unitX = tileY - startY + 1
		else
			unitX = startY + #RAW_ARR - tileY
		end

		local unitY = (tileX - startX) * campF + 1

		return unitX, unitY
	end
end

function GwarPlay.getTile(camp, unitX, unitY)
	local map = global.map
	local RAW_ARR = GwarCore.RAW_ARR
	local campF = 3 - camp * 2
	local areaEvent = MapEventManager.getEventByTagOne("area_" .. camp)
	local startX = nil

	if camp == 1 then
		startX = areaEvent.x
	else
		startX = areaEvent.x + areaEvent.w - 1
	end

	local startY = areaEvent.y
	local x = startX + (unitY - 1) * campF
	local y = nil

	if camp == 1 then
		y = startY + unitX - 1
	else
		y = startY + #RAW_ARR - unitX
	end

	return map:getTile(x, y)
end

function GwarPlay:stop()
	if self.nextTimer then
		MapFrameManager.clearTimeout(self.nextTimer)

		self.nextTimer = nil
	end
end

function GwarPlay:start()
	self.hpResetded = nil
	self.nextTimer = MapFrameManager.setTimeout(function ()
		self:next()
	end, 60)
end

function GwarPlay:makeBossAttrs(teamOne, level)
	level = math.min(CsvParser.getMaxID("gwar_base_num"), level)
	local monCSV = CsvParser.getCsvData("gwar_monster", teamOne.base_id)
	local baseCSV = CsvParser.getCsvData("gwar_base_num", level)
	local attrs = {}

	for _, attrKey in ipairs(CombatAttr.attrs) do
		local value = baseCSV["class" .. monCSV.class .. "_" .. attrKey] * monCSV[attrKey .. "_ratio"]
		attrs[attrKey] = value
	end

	return attrs
end

function GwarPlay:onCastBoss(dmg)
	local teamOne = self.unitMap[self.gcore.bossID].teamOne
	local preHp = self.bossHp
	self.bossHp = self.bossHp - dmg
	local pveScore = 0

	for level = 1, self.bossLevel - 1 do
		local baseCSV = CsvParser.getCsvData("gwar_base_num", level)
		pveScore = pveScore + baseCSV.class3_score
	end

	local baseCSV = CsvParser.getCsvData("gwar_base_num", self.bossLevel)
	local score = (teamOne.attrs.hp - math.max(self.bossHp, 0)) / teamOne.attrs.hp * baseCSV.class3_score
	pveScore = pveScore + math.floor(score)
	self.bossPveScore = pveScore

	if self.bossHp <= 0 then
		local maxLevel = CsvParser.getMaxID("gwar_base_num")

		if self.bossLevel < maxLevel then
			self.bossLevel = self.bossLevel + 1
		end

		local attrs = self:makeBossAttrs(teamOne, self.bossLevel)
		self.bossHp = attrs.hp
		self.bossHpMax = attrs.hp
	end

	self.bossData = {
		level = self.bossLevel,
		score = self.bossPveScore,
		hp = self.bossHp,
		hpMax = self.bossHpMax
	}

	if self.bossCallback then
		self.bossCallback(self.bossData)
	end
end

function GwarPlay:onRoundBoss()
	local teamOne = self.unitMap[self.gcore.bossID].teamOne
	self.bossData = {
		level = self.gcore.level,
		score = self.gcore.pveScore,
		hp = teamOne.battleData.hp,
		hpMax = teamOne.battleData.hpMax
	}

	if self.bossCallback then
		self.bossCallback(self.bossData)
	end
end

function GwarPlay:next()
	local isOver, winCamp = self.gcore:isOver()

	if self.gcore.type == GwarCore.TYPE.PVE then
		self:onRoundBoss()

		local teamOne = self.unitMap[self.gcore.bossID].teamOne
		teamOne.battleData.roundHp = teamOne.battleData.hp
		self.bossHp = teamOne.battleData.hp
		self.bossHpMax = teamOne.battleData.hpMax
		self.bossLevel = self.gcore.level
		self.bossPveScore = self.gcore.pveScore
	end

	if self.turnType == GwarCore.TURN_TYPE.ATTACK then
		self.round = self.gcore.round

		if self.newRoundCallback then
			self.newRoundCallback()
		end
	end

	if isOver and self.turnType == GwarCore.TURN_TYPE.ATTACK then
		if self.onOver then
			self.onOver(winCamp)
		else
			Alert.open("阵营" .. winCamp .. "胜利")
		end
	else
		local playData, newTeam = self.gcore:next(true)

		if newTeam then
			for i, teamOne in ipairs(newTeam) do
				local unit = self:createOne(teamOne.camp, teamOne)
				local monCSV = CsvParser.getCsvData("gwar_monster", teamOne.base_id)

				if not empty(monCSV.born_effect) then
					local effectGen = unit:getEffectGen()

					if effectGen then
						effectGen:castEffect(monCSV.born_effect, unit)
					end
				end
			end
		end

		if not self.hpResetded then
			self.hpResetded = true

			for key, unit in pairs(self.unitMap) do
				unit:resetHp()
			end
		end

		self:playTurn(playData)
	end
end

function GwarPlay:turnStart()
	self.turnLock = 0
end

function GwarPlay:turnCoundCheck(delay)
	delay = delay or 0

	if self.nextTimer then
		MapFrameManager.clearTimeout(self.nextTimer)

		self.nextTimer = nil
	end

	if self.turnLock == 0 then
		if delay <= 0 then
			self:next()
		else
			self.nextTimer = MapFrameManager.setTimeout(function ()
				self:next()
			end, delay)
		end
	end
end

function GwarPlay:turnCoundAdd()
	self.turnLock = self.turnLock + 1
end

function GwarPlay:turnCoundOver(delay)
	self.turnLock = self.turnLock - 1

	self:turnCoundCheck(delay or 60)

	if self.gcore.type == GwarCore.TYPE.PVE then
		self:onRoundBoss()
	end
end

function GwarPlay:playTurn(playData)
	self:turnStart()

	local turnData = playData.turnData
	local roundData = playData.roundData
	local attackData = playData.attackData
	local dieArr = playData.dieArr
	self.turnType = turnData.type

	if turnData.type == GwarCore.TURN_TYPE.FORWARD then
		for index, id in ipairs(dieArr) do
			local unit = self.unitMap[id]

			if unit then
				self.unitMap[id] = nil
			end
		end

		if roundData then
			for unitID, v in pairs(roundData) do
				local unit = self.unitMap[unitID]

				if v.hp then
					unit.battleData.hp = v.hp
				end

				if v.heal > 0 then
					unit:jumpDmg(v.heal, "font_heal_", 0)

					local effectGen = unit:getEffectGen()

					if effectGen then
						effectGen:castEffect(MiscConfig.gwar_effect_heal, unit)
					end
				end
			end
		end

		for camp = 1, 2 do
			local teamArr = self.gcore:getTeamArr(camp)

			if teamArr then
				for index, teamOne in ipairs(teamArr) do
					local unit = self.unitMap[teamOne.id]

					if teamOne.battleData.shield and teamOne.battleData.shield > 0 then
						unit:removeLastingEffect(MiscConfig.shield_effect, true)
						unit:addLastingEffect(MiscConfig.shield_effect)
					else
						unit:removeLastingEffect(MiscConfig.shield_effect, true)
					end

					local destTile = GwarPlay.getTile(camp, teamOne.x, teamOne.y)
					local mapX, mapY = global.map:tileToMap(destTile)

					if unit.tile ~= destTile or math.abs(unit.x - mapX) > 1 or math.abs(unit.y - mapY) > 1 then
						unit:stop()
						unit:stopJump()

						local result = unit:goTile(destTile, function ()
							unit.angle = unit.campAngle

							self:turnCoundOver(10)
						end)

						if result then
							self:turnCoundAdd()
						end
					end
				end
			end
		end
	elseif turnData.turn then
		for i, actionObj in ipairs(attackData) do
			for unitID, attackArr in pairs(actionObj) do
				local attacker = self.unitMap[unitID]

				self:attackMonster(attacker, attackArr)
			end
		end
	elseif turnData.job == GwarCore.JOB.M or turnData.job == GwarCore.JOB.A then
		for unitID, attackArr in pairs(attackData) do
			local attacker = self.unitMap[unitID]

			self:attackRange(attacker, attackArr)
		end
	elseif turnData.job == GwarCore.JOB.W and #attackData > 0 then
		self:turnCoundAdd()

		local attackIndex = 1
		local nextBatch = nil

		function nextBatch(isAllOver)
			if isAllOver or not attackData[attackIndex] then
				self:turnCoundOver(20)

				return
			end

			self:attackMelee(attackData[attackIndex], attackData[attackIndex + 1] == nil, nextBatch)

			attackIndex = attackIndex + 1
		end

		nextBatch()
	end

	self:turnCoundCheck(10)
end

function GwarPlay:attackMonster(attacker, attackArr)
	local castArr = {}

	for index, obj in ipairs(attackArr) do
		local target = self.unitMap[obj.target]

		table.insert(castArr, {
			target = target,
			dmgPack = obj.dmgPack
		})
	end

	if #castArr > 0 then
		self:turnCoundAdd()

		local function doCast()
			attacker:lockDie(true)
			attacker:castMonster(castArr, function ()
				attacker:lockDie(false)
				self:turnCoundOver(20)
			end)
		end

		MapFrameManager.setTimeout(doCast, self.random:getInt(1, 20), attacker)
	end
end

function GwarPlay:attackRange(attacker, attackArr)
	local castArr = {}

	for index, obj in ipairs(attackArr) do
		local target = self.unitMap[obj.target]

		table.insert(castArr, {
			target = target,
			dmgPack = obj.dmgPack
		})
	end

	if #castArr > 0 then
		self:turnCoundAdd()

		local function doCast()
			attacker:lockDie(true)
			attacker:castRange(castArr, function ()
				attacker:lockDie(false)
				self:turnCoundOver(20)
			end)
		end

		MapFrameManager.setTimeout(doCast, self.random:getInt(1, 20), attacker)
	end
end

function GwarPlay:attackMelee(attackArr, isFinal, onComplete)
	local count = 0
	local total = #attackArr

	for index, obj in ipairs(attackArr) do
		count = count + 1
		local attacker = self.unitMap[obj.attacker]
		local target = self.unitMap[obj.target]

		local function doCast()
			attacker:lockDie(true)
			attacker:castMelee({
				target = target,
				dmgPack = obj.dmgPack
			}, isFinal, function ()
				attacker:lockDie(false)

				count = count - 1

				if count == 0 then
					onComplete()
				end
			end)
		end

		MapFrameManager.setTimeout(doCast, self.random:getInt(1, math.min(total, 20)), attacker)
	end

	if count == 0 then
		onComplete(true)
	end
end

return GwarPlay
