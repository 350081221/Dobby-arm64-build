local Modao = class("Modao")

function Modao:ctor()
	self.map = global.map

	event_listener.extendMethods(self)

	self.skills = {}
	self.skillIndexMap = {}
end

function Modao:initBattle(seed)
	self.warSeed = seed
	self.skills = {}
	self.skillIndexMap = {}
	local plusArr = InfoBuilding.getPlusDataList(InfoBuilding.TAG.MONO, 402)
	local enhanceMap = {}

	for i, plusData in ipairs(plusArr) do
		enhanceMap[plusData.value1] = plusData.value2
	end

	for pos = 1, GameConfig.modao_skill_num do
		local info = InfoModao.getSkillByPos(pos)

		if info then
			local baseID = info.base_id
			local modaoCSV = CsvParser.getCsvData("modao_skill", baseID)
			local enhance = 0

			if enhanceMap[modaoCSV.skill_id] then
				enhance = enhanceMap[modaoCSV.skill_id]
			end

			local skillCSV = CsvParser.getFilteredData("skill", {
				category = modaoCSV.skill_id,
				level = info.level,
				enhance = enhance
			})
			local skillPack = self:addSkill(skillCSV.id)
			skillPack.caster = self:getBattleData(info.level, baseID)
			self.skillIndexMap[pos] = skillCSV.id
		end
	end
end

function Modao:addMana(value)
	local manaMax = InfoModao.getMpMax()
	self.mana = math.min(manaMax, self.mana + value)

	notify.dispatch("modao_mana")
end

function Modao:dispatchManualSkillsCD()
end

function Modao:addSkill(id, trigger)
	if trigger == nil then
		trigger = true
	end

	local skillData = CsvParser.getCsvData("skill", id)

	if skillData then
		local skillPack = {
			power = 0,
			cdPenal = 0,
			cdMax = 0,
			cd = 0,
			data = skillData,
			trigger = trigger,
			already = {}
		}

		if not skillData.power_value then
			skillPack.powerValue = SheetUtil.getNumber(skillData.power_value)
		end

		local buffArr = SheetUtil.getColumnList(skillData, {
			"buff_"
		}, {
			"buffID"
		})

		for i, v in ipairs(buffArr) do
			local buffData = CsvParser.getCsvData("buff", v.buffID)

			if not empty(buffData.trigger_skill) then
				self:addSkill(buffData.trigger_skill, false)
			end
		end

		self.skills[id] = skillPack

		return skillPack
	else
		Log.warn("add skill not found id", id)
	end
end

function Modao:getItemSkillPack(itemID)
	local itemCSV = CsvParser.getCsvData("item", itemID)
	local skillID = itemCSV.use_skill
	local skillPack = self:getSkillPack(skillID)

	if not skillPack then
		skillPack = self:addSkill(skillID)
		skillPack.caster = self:getItemBattleData(InfoDungeon.getLevel())
	end

	return skillPack
end

function Modao:getSkills()
	return self.skills
end

function Modao:getSkillPack(skillID)
	return self.skills[skillID]
end

function Modao:getActiveSkill(index)
	local skillID = self.skillIndexMap[index]

	if skillID then
		return self:getSkillPack(skillID)
	end
end

function Modao:getBattleData(level, baseID)
	local caster = {
		battleData = {
			camp = 1
		},
		attrs = {},
		info = {
			level = level,
			id = baseID
		},
		type = "modao",
		id = "modao_" .. baseID,
		isModao = true
	}
	local combatAttr = CombatAttr.getModaoAttr(level)

	for k, v in pairs(combatAttr) do
		caster.attrs[k] = v
	end

	caster.map = self.map
	caster.effectGen = UnitEffect.new(caster)

	function caster.getEffectGen()
		return caster.effectGen
	end

	CombatAttr.finalize(caster.attrs)

	return caster
end

function Modao:getItemBattleData(level)
	local caster = {
		battleData = {
			camp = 1
		},
		attrs = {},
		info = {
			level = level
		},
		type = "modao"
	}
	local combatAttr = CombatAttr.getItemAttr(level)

	for k, v in pairs(combatAttr) do
		caster.attrs[k] = v
	end

	caster.map = self.map
	caster.effectGen = UnitEffect.new(caster)

	function caster.getEffectGen()
		return caster.effectGen
	end

	CombatAttr.finalize(caster.attrs)

	return caster
end

function Modao:castSkill(skillPack, target, isItem)
	local caster = skillPack.caster
	caster.x = target.x
	caster.y = target.y
	caster.tile = self.map:mapToTile(caster.x, caster.y)
	caster.random = Random.new(self.warSeed)
	caster.warRandom = Random.new(self.warSeed)
	local skillData = skillPack.data

	if not isItem and not InfoModao.checkMp(skillData.mp) then
		return false
	end

	caster.effectGen:castEffect(skillData.focus_effect, caster, nil, , caster)

	local fullFrameTime = WarMachine.getFrame()
	skillPack.cdMax = SheetUtil.getNumber(skillData.cd)
	skillPack.cd = fullFrameTime + skillPack.cdMax

	self:dispatchEvent({
		name = "skill_cd",
		cd = skillPack.cd,
		cdMax = skillPack.cdMax,
		id = skillData.id
	})
	self:dispatchEvent({
		name = "skill_cd_" .. skillData.id,
		cd = skillPack.cd,
		cdMax = skillPack.cdMax
	})

	if not empty(skillData.shared_cd) then
		self:dispatchEvent({
			name = "shared_cd",
			cd = fullFrameTime + skillData.shared_cd,
			cdMax = skillData.shared_cd,
			id = skillData.id
		})
	end

	if not isItem then
		InfoModao.useMp(skillPack.data.mp)
	end

	skillPack.already = {}

	local function castDo()
		if caster.isModao then
			WarMachine.checkAttr(caster)
		end

		self:castDo(skillPack, target)
	end

	if skillData.pre_time > 0 then
		MapFrameManager.setTimeout(castDo, skillData.pre_time)
	else
		castDo()
	end
end

function Modao:castDo(skillPack, target, _t_Caster)
	local caster = skillPack.caster
	local skillData = skillPack.data

	caster.effectGen:castEffect(skillData.cast_effect, caster, nil, , caster)
	SkillManager.cast(skillData, skillPack, caster.attrs, target, _t_Caster or caster, {
		x = target.x,
		y = target.y
	})

	local combineList = SheetUtil.getColumnValueList(skillData, "combine_")

	for i, skillID in ipairs(combineList) do
		local skillPack = self:getSkillPack(skillID)
		skillPack = skillPack or self:addSkill(skillID)
		skillPack.caster = caster

		self:castDo(skillPack, target, _t_Caster)
	end

	local units = WarMachine.getUnits()

	for j, unit in ipairs(units) do
		if unit.castBuffTrigger then
			unit:castBuffTrigger(CombatUnit.BUFF_TIMING.CAST_MODAO)
		end
	end

	local trueTarget = target

	if skillData.select_type == 1 and skillPack and trueTarget.id then
		skillPack.already[trueTarget.id] = true
	end

	if not empty(skillData.trigger_skill) then
		local _skillPack = self:getSkillPack(skillData.trigger_skill)
		_skillPack = _skillPack or self:addSkill(skillData.trigger_skill, false)

		if _skillPack then
			_skillPack.caster = caster

			if skillPack and skillData.trigger_other == 1 then
				_skillPack.already = skillPack.already
			else
				_skillPack.already = {}

				if trueTarget.id then
					_skillPack.already[trueTarget.id] = true
				end
			end

			local currentCaster = trueTarget
			local _caster = {
				type = caster.type,
				data = caster.data,
				info = caster.info,
				id = caster.id,
				level = caster.info.level,
				battleData = caster.battleData,
				attrs = caster.attrs,
				x = currentCaster.x,
				y = currentCaster.y,
				z = currentCaster.z,
				width = currentCaster.width,
				height = currentCaster.height,
				tile = currentCaster.tile,
				map = currentCaster.map,
				random = caster.random,
				warRandom = caster.warRandom,
				checkPathLimited = function (self, tag)
					return currentCaster:checkPathLimited(tag)
				end,
				checkMeleeAndRangedTile = function (self, skillRange, unit, isJump)
					return currentCaster:checkMeleeAndRangedTile(skillRange, unit, isJump)
				end,
				getEffectGen = function (self)
					if currentCaster.getEffectGen then
						return currentCaster:getEffectGen()
					end
				end,
				getCenter = function (self, obj)
					return currentCaster:getCenter(obj)
				end
			}
			local multipleTimes = 1
			local multipleInterval = 1

			if not empty(skillData.multiple) then
				local multipleArr = string.split(skillData.multiple, ",")
				multipleTimes = SheetUtil.getNumber(multipleArr[1], caster.warRandom)

				if multipleArr[2] then
					multipleInterval = SheetUtil.getNumber(multipleArr[2], caster.warRandom) or 0
				end
			end

			for i = 1, multipleTimes do
				local isReady, newTarget = SkillManager.findAutoSkillTarget(_caster, _skillPack.data, trueTarget, _skillPack.already)

				if newTarget then
					if newTarget.id then
						_skillPack.already[newTarget.id] = true
					end

					local function castTrigger()
						if WarMachine.on then
							self:castDo(_skillPack, newTarget, _caster)
						end
					end

					local trigger_delay = skillData.trigger_delay

					if skillData.is_fly == 1 and not empty(skillData.fly_effect) then
						trigger_delay = trigger_delay + UnitEffect.getMissleTime(skillData.fly_effect, _t_Caster or caster, trueTarget)
					end

					trigger_delay = trigger_delay + multipleInterval * (i - 1)

					if trigger_delay > 0 then
						local units = WarMachine.getUnitsByCamp(1)

						if units[1] then
							MapFrameManager.setTimeout(castTrigger, trigger_delay, units[1])
						end
					else
						castTrigger()
					end
				end
			end
		end
	end
end

function Modao:onPause(modaoID)
	notify.dispatch("modao_pause")
	global.map:tweenViewZoomLooper(global.map.battleZoom * 0.9, 20)
end

function Modao:onResume(modaoID)
	notify.dispatch("modao_resume")
	global.map:tweenViewZoomLooper(global.map.battleZoom, 10)
end

return Modao
