local CombatUnit = import(".CombatUnit")
local Pet = class("Pet", CombatUnit)

function Pet:ctor(isArena)
	Pet.super.ctor(self, "pet")

	self.activeSkill = nil
	self.alwaysVisible = true
	self.alwaysActive = true
	self.fixedLight = 255
	self.isBlock = true
	self.isArena = isArena
	self.noEntity = true

	notify.safeRegister(self, "pet_add_exp", function (data)
		if data.id == self.info.id then
			self:onAddExp(data)
		end
	end)
	ManagerInfo.onDataChange(self, "pet", nil, function (idStack, idMap)
		if idMap[self.info.id] then
			local petInfo = InfoPet.getPet(self.info.id)

			if petInfo then
				self:setInfo(petInfo)
			end

			return
		end
	end)
end

function Pet:onBattleStart(warSeed)
	print("$$$ Pet:onBattleStart", warSeed)
	Pet.super.onBattleStart(self, warSeed)
end

function Pet:onAddExp(data)
	if data.pre_level < data.level then
		local effectGen = self:getEffectGen()

		if effectGen then
			effectGen:castEffect(MiscConfig.effect_levelup, self)
		end

		self:dispatchEvent({
			name = "level_changed"
		})
	end

	if not empty(data.max_type) then
		local str = nil

		if data.max_type == 1 then
			str = Localization.getSrcText("到达职业上限")
		elseif data.max_type == 2 then
			str = Localization.getSrcText("到达围栏上限")
		end

		if str then
			self:flyWord(str, {
				color = Style.red
			}, 90)
		end
	elseif data.exp_add > 0 then
		local str = Localization.getSrcText("经验+{1}")

		self:flyWord(StringUtil.replace(str, data.exp_add), {
			color = Style.golden
		}, 90)
		self:dispatchEvent({
			name = "exp_changed"
		})
	end
end

function Pet:setInfo(petInfo, noBattle)
	self.info = petInfo
	local petData = CsvParser.getCsvData("pet", petInfo.base_id)

	self:setData(petData)
	self:refreshBattleData()
end

function Pet:refreshBattleData()
	Pet.super.refreshBattleData(self)

	local data = nil

	if self.isArena then
		self.customAttrLevel = CopyAttr.getAttrLevel()
		data = CopyAttr.getPetAttr(self.info)
	else
		self.customAttrLevel = nil
		data = CombatAttr.getPetAttr(self.info)
	end

	self:setBattleData(data)
end

function Pet:setData(data)
	Pet.super.setData(self, data)

	if not empty(data.attack_id) then
		self:addSkill(data.attack_id)
	end

	self:clearCardBuff()

	if data.skill_ran == 1 then
		self.ranSkill = {
			stack = {}
		}
	end

	local index = 1

	while not empty(data["skill_id" .. index]) do
		local skillID = data["skill_id" .. index]
		local skillPack = self:addSkill(skillID)
		index = index + 1

		if skillPack and skillPack.data.type == 2 and self.ranSkill then
			local weight = data["ran_weight_" .. index]

			if empty(weight) then
				weight = 100
			end

			table.insert(self.ranSkill.stack, {
				skillPack = skillPack,
				weight = weight
			})
		end
	end

	if self.ranSkill and #self.ranSkill.stack == 0 then
		self.ranSkill = nil
	end

	if self.ranSkill then
		for i, obj in ipairs(self.ranSkill.stack) do
			local skillPack = obj.skillPack

			print("宠物随机技能", i, skillPack.data.name, "权重", obj.weight)
		end
	end

	local random = Random.new(self.seed)
	local index = 1

	while not empty(data["buff_id" .. index]) do
		local buffID = data["buff_id" .. index]

		self:addCardBuff(buffID, random:getInt(1, 65535))

		index = index + 1
	end
end

function Pet:setBattleData(data)
	Pet.super.setBattleData(self, data)

	if not self.battleData.hp then
		self.battleData.hp = self.attrs.hp
	end
end

function Pet:die(isBattleOver)
	if not self.battleData.die then
		local effectGen = self:getEffectGen()

		if effectGen then
			if isBattleOver then
				effectGen:castEffect(self.data.over_effect, self)
			else
				effectGen:castEffect(self.data.die_effect, self)
			end
		end

		self:clearEffect()
		self:setAction("idle")
		self:stopPlay()

		if self.shadow then
			self.shadow:removeSelf()

			self.shadow = nil
		end

		WarMachine.removePet(self)
		transition.fadeTo(self, {
			opacity = 0,
			time = 0.5,
			onComplete = function ()
				MapFrameManager.setTimeout(function ()
					self:removeSelf()
				end, MiscConfig.unit_delay_remove)
			end
		})
		self:removeFromMap()
	end

	Pet.super.die(self)
end

function Pet:setHudVisible(visible)
	local color, style = nil

	if self.battleData.camp == 1 then
		color = cc.c3b(35, 180, 28)
	else
		color = cc.c3b(248, 184, 16)
	end

	Summoned.super.setHudVisible(self, visible, color, style)
end

function Pet:getBattleName()
	return InfoPet.getName(self.info)
end

return Pet
