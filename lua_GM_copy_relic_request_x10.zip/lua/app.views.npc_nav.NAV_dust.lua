local NAV_base = import(".NAV_base")
local NAV_dust = class("NAV_dust", NAV_base)

function NAV_dust.open(npc)
	local ui = NAV_dust.new(npc)

	return ui
end

function NAV_dust:ctor(npc)
	NAV_dust.super.ctor(self, npc, "nav_dust")
end

function NAV_dust:init()
	NAV_dust.super.init(self)
	self:refresh()
	ManagerInfo.onDataChange(self, {
		"dust",
		"dust_achieve",
		"dust_pass",
		"dust_attr_manual"
	}, nil, function ()
		self:refresh()
	end)
end

function NAV_dust:refresh()
	local index = 3
	local ui = self.buttons[index].ui
	local dustState, dustID = InfoDust.getState()
	local redot = ui:getComponentByTag("redot")

	redot:setVisible(FRAME_dust_pass.countRedot(dustID) > 0)
end

function NAV_dust:onTap(index)
	NAV_dust.super.onTap(self, index)

	if index == 1 then
		FRAME_dust_main.open()
	elseif index == 2 then
		FRAME_dust_ranking.open()
	elseif index == 3 then
		local dustState, dustID, dustNextTime = InfoDust.getState()

		if dustID and dustState ~= InfoDust.STATE.NONE then
			FRAME_dust_pass.open()
		else
			Alert.open(Localization.getSrcText("赛季已关闭"))
		end
	end
end

return NAV_dust
