local FRAME_battle_setup = class("FRAME_battle_setup", UI_base)

function FRAME_battle_setup.open()
	local ui = FRAME_battle_setup.new()

	PopManager.open(ui)
end

function FRAME_battle_setup:ctor()
	FRAME_battle_setup.super.ctor(self, "frame_battle_setup", UIManager.BIG_TYPE.POP)
	self:init()
end

function FRAME_battle_setup:init()
	self:initUI()
	self:refreshSkills()
	self:refreshSpeedup()
end

function FRAME_battle_setup:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local heros = InfoHero.getTeamInPos()
	local label_auto = self:getComponentByTag("label_auto")
	local label_auto_disabled = self:getComponentByTag("label_auto_disabled")
	local label_auto_hint = self:getComponentByTag("label_auto_hint")

	label_auto_disabled:setVisible(not SkillManager.autoEnabled())
	label_auto_hint:setVisible(SkillManager.autoEnabled())
	label_auto_disabled:setPositionX(label_auto:getPositionX() + (label_auto:getContentSize().width + label_auto_disabled:getContentSize().width) / 2 + 10)
	label_auto_hint:setPositionX(label_auto:getPositionX() + (label_auto:getContentSize().width + label_auto_hint:getContentSize().width) / 2 + 10)

	for i = 1, GameConfig.hero_team_num do
		local heroInfo = heros[i]
		local auto_bg = self:getComponentByTag("auto_bg_" .. i)
		local skill_mask = self:getComponentByTag("skill_mask_" .. i)
		local auto_selected = self:getComponentByTag("auto_selected_" .. i)

		if heroInfo then
			local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)
			local quality = InfoHero.getQuality(heroInfo)
			local qualityColor = InfoHero.getQualityColor(quality)
			local isSwitchSkill = heroCSV.is_switch_skill == 1

			self:createLabelOnFlag("flag_hero_name_" .. i, InfoHero.getName(heroInfo), {
				color = qualityColor
			})

			if isSwitchSkill then
				self:createLabelOnFlag("flag_type_" .. i, Localization.getSrcText("切换形态"))
			else
				self:createLabelOnFlag("flag_type_" .. i, Localization.getSrcText("切换自动"))
			end

			if InfoDungeon.isFixedTeam() then
				local hero = TeamManager.getHeroByPos(i)

				if hero then
					auto_bg:toTouchable()
					auto_bg:setTapGroup("button_click")
					auto_bg:addTap(function ()
						if isSwitchSkill then
							hero.info.auto_skill = 1 - hero.info.auto_skill

							print("$$$ heroInfo.auto_skill", hero.info.auto_skill)
						else
							hero:setAutoSkill(not hero:isAutoSkill())

							hero.info.auto_skill = hero:isAutoSkill() and 1 or 0
						end

						self:refreshSkills()
					end)
				end
			elseif SkillManager.autoEnabled() then
				auto_bg:toTouchable()
				auto_bg:setTapGroup("button_click")
				auto_bg:addTap(function ()
					local info = InfoHero.getHero(heroInfo.id)

					InfoHero.setAutoSkill(heroInfo.id, info.auto_skill ~= 1, function ()
						self:refreshSkills()
					end)
				end)
			end

			skill_mask:setLocalZOrder(1000)
			auto_selected:setLocalZOrder(1100)
		else
			auto_bg:setVisible(false)
			skill_mask:setVisible(false)
		end
	end

	local bt_manual_monster = self:getComponentByTag("bt_manual_monster")

	bt_manual_monster:toTouchable()
	bt_manual_monster:setTapGroup("button_click")
	bt_manual_monster:addTap(function ()
		PopManager.close()
		FRAME_manual_monster.open()
	end)

	local bt_speedup_no = self:getComponentByTag("bt_speedup_no")
	local bt_speedup_yes = self:getComponentByTag("bt_speedup_yes")
	local no_speedup = self:getComponentByTag("no_speedup")

	if InfoDungeon.isSpeedup() then
		bt_speedup_no:toTouchable()
		bt_speedup_no:setTapGroup("button_click")
		bt_speedup_no:addTap(function ()
			Cookie.set("speedup_ban", nil, true)
			global.map:refreshSpeedup()
			self:refreshSpeedup()
		end)
		bt_speedup_yes:toTouchable()
		bt_speedup_yes:setTapGroup("button_click")
		bt_speedup_yes:addTap(function ()
			Cookie.set("speedup_ban", true, true)
			global.map:refreshSpeedup()
			self:refreshSpeedup()
		end)
		no_speedup:setVisible(false)
	else
		bt_speedup_no:setVisible(false)
		bt_speedup_yes:setVisible(false)
	end

	local hintStr = Localization.getLoneText("FRAME_battle_setup")
	local hint = self:getComponentByTag("hint")

	if empty(hintStr) then
		hint:setVisible(false)
	else
		hint:toTouchable()
		hint:setTapGroup("button_click")
		hint:addTap(function ()
			POP_msg.open(hintStr, {
				size = 20,
				align = Style.left
			})
		end)
	end

	local autopick_item = CsvParser.getCsvData("config", "autopick_item").value

	self:createIconOnFlag("flag_autopick_slot", IconManager.getItemIcon(autopick_item), nil, true)

	if InfoDungeon.isAutoPick() then
		self:removeLabelOnFlag("label_autopick_no")
	else
		self:removeLabelOnFlag("label_autopick_yes")
	end
end

function FRAME_battle_setup:refreshSkills()
	local heros = InfoHero.getTeamInPos()

	for i = 1, GameConfig.hero_team_num do
		local heroInfo = heros[i]
		local auto_selected = self:getComponentByTag("auto_selected_" .. i)

		if heroInfo then
			local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)
			local quality = InfoHero.getQuality(heroInfo)
			local qualityColor = InfoHero.getQualityColor(quality)
			local isSwitchSkill = heroCSV.is_switch_skill == 1
			local skillID = nil

			if isSwitchSkill then
				if InfoDungeon.isFixedTeam() then
					local hero = TeamManager.getHeroByPos(i)

					if hero then
						skillID = InfoHero.getSwitchSkill(heroInfo, hero.info.auto_skill + 1).id
					end
				else
					skillID = InfoHero.getSwitchSkill(heroInfo, heroInfo.auto_skill + 1).id
				end

				auto_selected:setVisible(false)
			else
				skillID = InfoHero.getSkill(heroInfo).id

				if InfoDungeon.isFixedTeam() then
					local hero = TeamManager.getHeroByPos(i)

					if hero then
						auto_selected:setVisible(hero:isAutoSkill())
					end
				elseif SkillManager.autoEnabled() then
					auto_selected:setVisible(heroInfo.auto_skill == 1)
				else
					auto_selected:setVisible(false)
				end
			end

			local skillCSV = CsvParser.getCsvData("skill", skillID)

			self:createLabelOnFlag("flag_skll_name_" .. i, skillCSV.name)
			self:createIconOnFlag("auto_slot_" .. i, IconManager.getSkillIcon(skillID), 100, true)
		else
			auto_selected:setVisible(false)
		end
	end
end

function FRAME_battle_setup:refreshSpeedup()
	if InfoDungeon.isSpeedup() then
		local bt_speedup_no = self:getComponentByTag("bt_speedup_no")
		local bt_speedup_yes = self:getComponentByTag("bt_speedup_yes")

		bt_speedup_no:setVisible(Cookie.get("speedup_ban"))
		bt_speedup_yes:setVisible(not Cookie.get("speedup_ban"))
	end
end

return FRAME_battle_setup
