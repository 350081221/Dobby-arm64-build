local NAV_base = import(".NAV_base")
local NAV_gladiator = class("NAV_gladiator", NAV_base)

function NAV_gladiator.open(npc)
	local ui = NAV_gladiator.new(npc)

	return ui
end

function NAV_gladiator:ctor(npc)
	NAV_gladiator.super.ctor(self, npc, "nav_gladiator")
end

function NAV_gladiator:init()
	NAV_gladiator.super.init(self)

	local eventData = self.npc.eventData
	local eventInfo = InfoDungeon.getEventInfo(eventData.index)
	local gladiatorCSV = CacheData.chance_getGladiator(self.npc.baseID, eventInfo.fin)

	self.npc:say(gladiatorCSV.text)

	local ui = self.buttons[1].ui

	if eventInfo.fin == 0 then
		local str = Localization.getSrcText("接受挑战")
		str = string.gsub(str, "\\n", "\n")

		self:setButtonName(ui, str)
		self:setButtonVisible(2, false)
	elseif eventInfo.fin == GameConfig.gladiator_max then
		self:setButtonVisible(1, false)
		self:setButtonVisible(2, true)
	else
		local str = Localization.getSrcText("继续挑战")
		str = string.gsub(str, "\\n", "\n")

		self:setButtonName(ui, str)
		self:setButtonVisible(2, true)
	end

	if not empty(self.npc.data.read_time) and self.npc.data.read_time > 0 then
		self:openTouch()
	end
end

function NAV_gladiator:onTap(index)
	NAV_gladiator.super.onTap(self, index)

	local eventData = self.npc.eventData
	local eventIndex = eventData.index
	local eventInfo = InfoDungeon.getEventInfo(eventData.index)

	if index == 1 then
		-- Nothing
	elseif index == 2 then
		InfoDungeon.getChance(self.npc, eventIndex, {
			type = 2
		}, function (rcvData)
			local finalRelic = InfoDungeon.getFinalRelic(eventIndex)

			if finalRelic then
				self.npc:openRelic(eventIndex, finalRelic.index)
			end

			if global.player then
				global.player:checkNearNpc()
			end
		end)
	end
end

function NAV_gladiator:onTouch(event, index)
	NAV_gladiator.super.onTouch(self, event, index)

	local eventData = self.npc.eventData
	local eventIndex = eventData.index
	local eventInfo = InfoDungeon.getEventInfo(eventData.index)

	if index == 1 and not empty(self.npc.data.read_time) and self.npc.data.read_time > 0 then
		self:onRead(event, self.npc.data.read_msg, self.npc.data.read_sfx, self.npc.data.read_over_sfx, function ()
			if self.npc and eventInfo.fin < GameConfig.gladiator_max then
				self.npc:removeSay()
				InfoDungeon.removeBlood(eventIndex)
				ChanceUtils.gladiatorBattle(self.npc, function ()
					if global.player then
						global.player:checkNearNpc()
					end
				end)
			end
		end)
	end
end

function NAV_gladiator:close(immediately)
	self.npc:removeSay()
	NAV_gladiator.super.close(self, immediately)
end

return NAV_gladiator
