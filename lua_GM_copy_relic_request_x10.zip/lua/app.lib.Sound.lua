local Sound = {}
local currentMusicName = ""
local savedMusicName = ""
local musicEnabled = true
local musicFadeTime = 30
local musicVolumeSet = 1
local musicVolume = 0
local musicVolumeTweenID, onceMusicName = nil

function Sound.playMusicOnceLoop()
	local source = audio._sources[1]

	if not source then
		Looper.stopLoop(Sound, Sound.playMusicOnceLoop)

		return
	end

	local stat = source:getStat()

	if stat == 4 then
		local npc = Npc.getInstance(MiscConfig.bard_npc)

		if npc then
			npc:removeMappedAction("idle")
			npc:setAction("idle")
		end

		Sound.stopMusicOnce()
	end
end

function Sound.stopMusicOnce()
	Looper.stopLoop(Sound, Sound.playMusicOnceLoop)

	onceMusicName = nil

	if not empty(currentMusicName) then
		Sound.playMusic(currentMusicName, true)
	end
end

function Sound.playMusicOnce(fileName, force)
	if musicEnabled and (force or not onceMusicName) then
		Looper.stopLoop(Sound, Sound.playMusicOnceLoop)

		onceMusicName = fileName

		audio.playBGMSync(getFinalRes("res/sound/bgm/" .. fileName .. ".ogg"), false)
		Looper.startLoop(Sound, Sound.playMusicOnceLoop)

		local npc = Npc.getInstance(MiscConfig.bard_npc)

		if npc then
			npc:setMappedAction("idle", "talk")
			npc:setAction("talk")
		end

		return true
	end
end

local musicList, musicListIndex, musicListNextLocked = nil

function Sound.playMusicListLoop()
	local source = audio._sources[1]

	if not source then
		Looper.stopLoop(Sound, Sound.playMusicListLoop)

		return
	end

	local stat = source:getStat()
	local nowTime = Time.time()

	if stat == 4 and (not musicListNextLocked or musicListNextLocked < nowTime) then
		musicListNextLocked = nowTime + 3
		musicListIndex = musicListIndex + 1

		if musicListIndex > #musicList then
			musicListIndex = 1
		end

		Sound.playMusicListNext()
	end
end

function Sound.playMusicList(fileNameArr)
	if musicEnabled and #fileNameArr > 0 then
		musicList = fileNameArr
		musicListIndex = 1

		Sound.playMusicListNext()

		return
	end
end

function Sound.playMusicListNext()
	if musicEnabled then
		Looper.stopLoop(Sound, Sound.playMusicListLoop)
		audio.playBGMSync(getFinalRes("res/sound/bgm/" .. musicList[musicListIndex] .. ".ogg"), false)
		Looper.startLoop(Sound, Sound.playMusicListLoop)

		local npc = Npc.getInstance(MiscConfig.bard_npc)

		if npc then
			npc:setMappedAction("idle", "talk")
			npc:setAction("talk")
		end
	end
end

function Sound.playMusic(fileName, force)
	if type(fileName) == "table" then
		fileName = fileName[1]
	end

	if musicEnabled and (force or currentMusicName ~= fileName) then
		local function startMusic()
			if fileName ~= "" then
				audio.playBGMSync(getFinalRes("res/sound/bgm/" .. fileName .. ".ogg"), true)

				local fadeTime = (musicVolumeSet - musicVolume) * musicFadeTime

				if fadeTime <= 0 then
					musicVolume = musicVolumeSet

					audio.setBGMVolume(musicVolumeSet)
				else
					local obj = {
						volume = musicVolume
					}

					local function onUpdate()
						musicVolume = obj.volume

						audio.setBGMVolume(obj.volume)
					end

					if musicVolumeTweenID then
						Looper.stopTween(musicVolumeTweenID)
					end

					musicVolumeTweenID = Looper.tween(fadeTime, obj, {
						volume = musicVolumeSet
					}, "linear", nil, onUpdate)
				end
			end
		end

		if currentMusicName == "" then
			startMusic()
		else
			local fadeTime = musicVolume * musicFadeTime

			if fadeTime <= 0 then
				musicVolume = 0

				audio.setBGMVolume(0)
				startMusic()
			else
				local obj = {
					volume = musicVolume
				}

				local function onUpdate()
					musicVolume = obj.volume

					audio.setBGMVolume(obj.volume)
				end

				if musicVolumeTweenID then
					Looper.stopTween(musicVolumeTweenID)
				end

				musicVolumeTweenID = Looper.tween(fadeTime, obj, {
					volume = 0
				}, "linear", startMusic, onUpdate)
			end
		end

		currentMusicName = fileName
	end

	savedMusicName = fileName
end

function Sound.stopMusic()
	audio.stopBGM()

	currentMusicName = ""
end

function Sound.recoverMusic()
	currentMusicName = ""

	Sound.playMusic(savedMusicName)
end

function Sound.musicOn()
	if not musicEnabled then
		musicEnabled = true

		Sound.recoverMusic()
	end
end

function Sound.musicOff()
	if musicEnabled then
		musicEnabled = false

		Sound.stopMusic()
	end
end

function Sound.setMusicOn(isOn)
	if isOn then
		Sound.musicOn()
	else
		Sound.musicOff()
	end
end

function Sound.isMusicOn()
	return musicEnabled
end

function Sound.setMusicVolume(vol, isFlush)
	Cookie.set("musicVolumeSet", vol, isFlush)

	musicVolumeSet = vol
	local fadeTime = math.abs(musicVolumeSet - musicVolume) * musicFadeTime

	if fadeTime <= 0 then
		musicVolume = musicVolumeSet

		audio.setBGMVolume(musicVolumeSet)
	else
		local obj = {
			volume = musicVolume
		}

		local function onUpdate()
			musicVolume = obj.volume

			audio.setBGMVolume(obj.volume)
		end

		if musicVolumeTweenID then
			Looper.stopTween(musicVolumeTweenID)
		end

		musicVolumeTweenID = Looper.tween(fadeTime, obj, {
			volume = musicVolumeSet
		}, "linear", nil, onUpdate)
	end
end

function Sound.getMusicVolume()
	return musicVolumeSet
end

local soundTimeMap = {}
local soundEnabled = true
local soundPreloaded = {}
local soundVolumeSet = 1
local loopSoundMap = {}

function Sound.playSound(fileName, asMusicEnable, onLoadSource, isLoop, noCheckTime)
	if asMusicEnable ~= true and soundEnabled and soundVolumeSet > 0 or asMusicEnable and musicEnabled and musicVolumeSet > 0 then
		local path = getFinalRes("res/sound/sfx/" .. fileName .. ".ogg")

		if not soundPreloaded[fileName] then
			audio.loadFile(path, function ()
				soundPreloaded[fileName] = true
				local now = socket.gettime()

				if noCheckTime or soundTimeMap[fileName] == nil or now - soundTimeMap[fileName] > 0.1 then
					local source = audio.playEffect(path, isLoop)

					if isLoop then
						loopSoundMap[fileName] = source
					end

					if onLoadSource then
						onLoadSource(source)
					end

					soundTimeMap[fileName] = now
				end
			end)
		else
			local now = socket.gettime()

			if noCheckTime or soundTimeMap[fileName] == nil or now - soundTimeMap[fileName] > 0.1 then
				local source = audio.playEffect(path, isLoop)

				if isLoop then
					loopSoundMap[fileName] = source
				end

				if onLoadSource then
					onLoadSource(source)
				end

				soundTimeMap[fileName] = now
			end
		end
	end
end

function Sound.stopSound(fileName)
	if loopSoundMap[fileName] then
		loopSoundMap[fileName]:stop()

		loopSoundMap[fileName] = nil
	end
end

function Sound.clearSound()
	for fileName, v in pairs(soundPreloaded) do
		local path = getFinalRes("res/sound/sfx/" .. fileName .. ".ogg")

		audio.unloadFile(path)
	end

	soundPreloaded = {}
	loopSoundMap = {}
end

function Sound.soundOn()
	if not soundEnabled then
		soundEnabled = true

		Cookie.set("soundEnabled", soundEnabled)
		Cookie.flush()
	end
end

function Sound.soundOff()
	if soundEnabled then
		soundEnabled = false

		Cookie.set("soundEnabled", soundEnabled)
		Cookie.flush()
	end
end

function Sound.setSoundOn(isOn)
	if isOn then
		Sound.soundOn()
	else
		Sound.soundOff()
	end
end

function Sound.isSoundOn()
	return soundEnabled
end

function Sound.setSoundVolume(vol, isFlush)
	Cookie.set("soundVolumeSet", vol, isFlush)

	soundVolumeSet = vol

	audio.setEffectVolume(soundVolumeSet, true)
end

function Sound.getSoundVolume()
	return soundVolumeSet
end

local displayLevelSet = 0

function Sound.setDislayLevel(vol, isFlush)
	displayLevelSet = 2 - math.min(2, math.max(0, math.floor(vol * 3)))

	Cookie.set("displayLevelSet", displayLevelSet, isFlush)
end

function Sound.getDislayLevel()
	local level = tonumber(displayLevelSet) or 0

	return math.min(2, math.max(0, level))
end

function Sound.getDislayVolume()
	local level = tonumber(displayLevelSet) or 0

	return (2 - level) / 2
end

local atomsDisplaySet = 0

function Sound.setAtomsLevel(vol, isFlush)
	atomsDisplaySet = 2 - math.min(2, math.max(0, math.floor(vol * 3)))

	Cookie.set("atomsDisplaySet", atomsDisplaySet, isFlush)
end

function Sound.getAtomsLevel()
	local level = tonumber(atomsDisplaySet) or 0

	return math.min(2, math.max(0, level))
end

function Sound.getAtomsVolume()
	local level = tonumber(atomsDisplaySet) or 0

	return (2 - level) / 2
end

local gammaSet = 0

function Sound.setGamma(vol, isFlush)
	gammaSet = vol

	Cookie.set("gammaSet", gammaSet, isFlush)
end

function Sound.getGamma()
	return gammaSet
end

local screenOnSet = nil

function Sound.isScreenOn()
	return screenOnSet == 1
end

function Sound.setScreenOn(enabled)
	screenOnSet = enabled and 1 or 0

	Cookie.set("isScreenOn", screenOnSet, true)
	LuaBridge.call("luaScreenOn", {
		enabled = screenOnSet
	}, function (result)
	end)
end

local stepSoundSet = nil

function Sound.isStepSound()
	return stepSoundSet == 1
end

function Sound.setStepSound(enabled)
	stepSoundSet = enabled and 1 or 0

	Cookie.set("stepSoundSet", stepSoundSet, true)
end

local nextBattleMusic = nil

function Sound.setBattleMusic(fileName)
	nextBattleMusic = fileName
end

function Sound.getBattleMusic()
	return nextBattleMusic
end

function Sound.clearBattleMusic()
	nextBattleMusic = nil
end

function Sound.init()
	musicVolumeSet = Cookie.get("musicVolumeSet") or 1
	soundVolumeSet = Cookie.get("soundVolumeSet") or 1

	Sound.setSoundVolume(soundVolumeSet)

	stepSoundSet = Cookie.get("stepSoundSet") or 1
	displayLevelSet = Cookie.get("displayLevelSet") or 0
	atomsDisplaySet = Cookie.get("atomsDisplaySet") or 0
	gammaSet = Cookie.get("gammaSet") or 0
end

function Sound.clear()
	for fileName, sound in pairs(loopSoundMap) do
		sound:stop()
	end

	loopSoundMap = {}

	Looper.stopLoop(Sound, Sound.playMusicOnceLoop)

	onceMusicName = nil

	Looper.stopLoop(Sound, Sound.playMusicListLoop)

	musicListNextLocked = nil

	Sound.clearBattleMusic()
end

return Sound
