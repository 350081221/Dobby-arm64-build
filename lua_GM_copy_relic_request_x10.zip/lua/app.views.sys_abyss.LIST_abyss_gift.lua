local List = import("...ui.List")
local LIST_abyss_gift = class("LIST_abyss_gift", List)

function LIST_abyss_gift:ctor(rect, cellName)
	LIST_abyss_gift.super.ctor(self, rect)
	self:setSpace(3, 2)
	self:setCellName(cellName or "cell_abyss_gift")
	self:setCellSize(cc.size(self.touchRect.width, 130))
end

function LIST_abyss_gift:onCellInit(ui, csv)
	if not ui.slot then
		ui.slot = DropSlot.new(ui:getFlagByTag("flag_slot"), "slot_01")

		ui:addChild(ui.slot, 100)
	end

	local itemCSV = CsvParser.getCsvData("item", csv.reward_item)

	ui:createLabelOnFlag("flag_name", itemCSV.name)
	ui.slot:setDrop(DropManager.TYPE.ITEM, {
		num = 1,
		base_id = csv.reward_item
	})

	local disableButton = ui:getComponentByTag("bt_disabled")
	local getButton = ui:getComponentByTag("bt_get")
	local progress, max = InfoAbyssGift.getProgress()
	local canGet = max <= progress and InfoAbyssGift.getRewardCount() == 0

	disableButton:setVisible(not canGet)
	getButton:setVisible(canGet)
end

return LIST_abyss_gift
