local List = import("...ui.List")
local LIST_naraka = class("LIST_naraka", List)

function LIST_naraka:ctor(rect)
	LIST_naraka.super.ctor(self, rect)
	self:setCellName("cell_naraka")
	self:setSpace(5, 5)
	self:setCellSize(cc.size(self.touchRect.width, 110))
end

function LIST_naraka:onCellInit(ui, csv, index)
	ui:removeLabelOnFlag("flag_name")
	ui:removeLabelOnFlag("flag_reward")
	ui:removeLabelGroupOnFlag("flag_reward")

	if ui.icon then
		ui.icon:removeSelf()

		ui.icon = nil
	end

	local bg_disable = ui:getComponentByTag("bg_disable")

	if InfoNaraka.isOpen(csv.id) then
		bg_disable:setVisible(false)
		ui:createLabelOnFlag("flag_name", csv.name)

		local mugshotRect = ui:getRectByFlag("flag_icon")
		local portrait = PortraitManager.getMonsterMugshot(csv.monster_display, mugshotRect, 3, 0, cc.p(0, 0))

		portrait:setPosition(mugshotRect.x + mugshotRect.width / 2, mugshotRect.y + mugshotRect.height / 2)
		ui:addChild(portrait, 100)

		ui.icon = portrait
		local itemArr = string.split(csv.item_display, ",")
		local labelArr = {}
		local styleArr = {}

		for i, v in ipairs(itemArr) do
			if not empty(v) then
				local itemCSV = CsvParser.getCsvData("item", v)

				if #labelArr > 0 then
					table.insert(labelArr, ",")
					table.insert(styleArr, {})
				end

				table.insert(labelArr, itemCSV.name)
				table.insert(styleArr, {
					color = Style.font3
				})
			end
		end

		ui:replaceLabelGroupOnFlag("flag_reward", labelArr, styleArr)
	else
		bg_disable:setVisible(true)
		bg_disable:setLocalZOrder(2000)

		local areaCSV = CsvParser.getCsvData("abyss_area", csv.abyss_area)
		local str = Localization.getSrcText("通关「{1}」")

		bg_disable:addLabel(StringUtil.replace(str, areaCSV.name))
	end

	local _selected = ui:getComponentByTag("selected")

	_selected:setLocalZOrder(200)
	self:onCellSelected(ui, data, self.selectedIndex == index, true)
end

function LIST_naraka:onCellSelected(ui, csv, selected, isInit)
	local _selected = ui:getComponentByTag("selected")

	_selected:setVisible(selected)

	if isInit then
		if selected then
			ui:setOpacity(255)
		else
			ui:setOpacity(150)
		end
	elseif selected then
		transition.stopTarget(ui)
		transition.fadeTo(ui, {
			opacity = 255,
			time = 0.2
		})
	else
		transition.stopTarget(ui)
		transition.fadeTo(ui, {
			opacity = 150,
			time = 0.2
		})
	end
end

return LIST_naraka
