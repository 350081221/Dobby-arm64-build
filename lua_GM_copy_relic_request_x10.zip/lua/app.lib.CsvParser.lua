local zlib = require("zlib")
local CsvParser = {}
local cachedDataMap = {}
local cachedMaxID = {}
local filteredDataCache = {}
local columnMap = {}
local checkFunc = nil

function CsvParser.setCheckFunc(obj)
	checkFunc = obj
end

function CsvParser.clearCheckFunc()
	checkFunc = nil
end

local function getFileStr(filePath)
	local content = getFileData(filePath)

	if not CsvParser.noCompress then
		local uncompress = zlib.inflate()
		content = uncompress(content)
	end

	return content
end

function CsvParser.clearCache()
	cachedDataMap = {}
	cachedMaxID = {}
	filteredDataCache = {}
end

function CsvParser.getMaxID(name)
	local maxID = cachedMaxID[name]

	if not maxID then
		local rawData = CsvParser.getCsvRaw(name)

		for k, v in pairs(rawData) do
			if not maxID or maxID < v.id then
				maxID = v.id
			end
		end

		cachedMaxID[name] = maxID
	end

	return maxID
end

function CsvParser.getCsvRaw(name)
	cachedDataMap[name] = cachedDataMap[name] or CsvParser.loadFile(name, true)

	return cachedDataMap[name]
end

function CsvParser.getCsvList(name, sortKey, filters, sortFunc)
	sortKey = sortKey or "id"
	cachedDataMap[name] = cachedDataMap[name] or CsvParser.loadFile(name, true)
	local arr = {}

	for id, data in pairs(cachedDataMap[name]) do
		local filterOK = true

		if filters then
			for k, v in pairs(filters) do
				if data[k] ~= v then
					filterOK = false

					break
				end
			end
		end

		if filterOK then
			table.insert(arr, data)
		end
	end

	sortFunc = sortFunc or function (a, b)
		return a[sortKey] < b[sortKey]
	end

	table.sort(arr, sortFunc)

	return arr
end

function CsvParser.getFilteredData(name, filters)
	local valueKey = ""
	local dataTag = name .. "#"
	local filterKeyArr = {}

	for k, v in pairs(filters) do
		table.insert(filterKeyArr, k)
	end

	table.sort(filterKeyArr, function (a, b)
		return a < b
	end)

	for i, key in ipairs(filterKeyArr) do
		dataTag = dataTag .. "_" .. key
		valueKey = valueKey .. "_" .. filters[key]
	end

	if not filteredDataCache[dataTag] then
		filteredDataCache[dataTag] = {}
		local dataArr = CsvParser.getCsvList(name)

		for i, v in ipairs(dataArr) do
			local valueTag = ""

			for j, key in ipairs(filterKeyArr) do
				valueTag = valueTag .. "_" .. v[key]
			end

			filteredDataCache[dataTag][valueTag] = v
		end
	end

	return filteredDataCache[dataTag][valueKey]
end

function CsvParser.getCsvData(name, id, returnNewObject, ignoreMiss)
	cachedDataMap[name] = cachedDataMap[name] or CsvParser.loadFile(name, true)

	if not ignoreMiss and (not cachedDataMap[name] or not cachedDataMap[name][tostring(id)]) then
		Log.debug("CsvParser.getCsvData miss ", name, id, debug.traceback())
	end

	if checkFunc then
		checkFunc(cachedDataMap[name][tostring(id)])
	end

	if returnNewObject then
		local newObj = {}

		for k, v in pairs(cachedDataMap[name][tostring(id)]) do
			newObj[k] = v
		end

		return newObj
	else
		return cachedDataMap[name][tostring(id)]
	end
end

function CsvParser.getHash(csvData)
	local fileName = csvData.__file
	local columns = columnMap[fileName]
	local hashArr = {}

	for i, v in ipairs(columns) do
		table.insert(hashArr, tostring(csvData[v]))
	end

	local hashStr = table.concat(hashArr, "_")

	return crypto.md5(hashStr), hashStr
end

function CsvParser.loadFile(fileName, castToNumber)
	castToNumber = castToNumber or false
	local file_in = "res/data/" .. fileName .. ".csv"
	local str = ""
	local lang = Localization.getLang()

	if fileName ~= "err_code" and lang ~= GameConfig.default_lang then
		local file_in = "res/data_" .. lang .. "/" .. fileName .. ".csv"

		if isFileExist(file_in) then
			str = getFileStr(file_in)
		end
	end

	if str == "" then
		local file_in = "res/data/" .. fileName .. ".csv"
		str = getFileStr(file_in)
	end

	local data = {}
	local lines = str:split("\n")
	local columns = lines[1]:split(",")
	columns[#columns] = string.trim(columns[#columns])
	columnMap[fileName] = columns

	for i = 2, #lines do
		local values = lines[i]:split(",")
		values[#values] = string.trim(values[#values])
		local id = tostring(values[1])

		if id == nil then
			break
		end

		data[id] = {
			__line = i,
			__file = fileName
		}
		local hashArr = {}

		for j = 1, #values do
			local value = values[j]
			local langValue = Localization.getSheetText(fileName, id, columns[j])

			if langValue then
				value = langValue
			end

			if castToNumber then
				local numberValue = tonumber(value)

				if numberValue == nil then
					data[id][columns[j]] = CsvParser.escapeMiscellaneous(value)
				else
					data[id][columns[j]] = numberValue
				end
			else
				data[id][columns[j]] = CsvParser.escapeMiscellaneous(value)
			end

			table.insert(hashArr, tostring(data[id][columns[j]]))
		end

		local hashStr = table.concat(hashArr, "_")
		data[id].__hash = crypto.md5(hashStr)
	end

	return data
end

function CsvParser.loadArr(fileName, castToNumber)
	castToNumber = castToNumber or false
	local file_in = "res/data/" .. fileName .. ".csv"
	local arr = {}
	local str = getFileStr(file_in)
	local lines = str:split("\n")
	local columns = lines[1]:split(",")
	columns[#columns] = string.trim(columns[#columns])
	columnMap[fileName] = columns

	for i = 2, #lines do
		local values = lines[i]:split(",")
		values[#values] = string.trim(values[#values])
		local data = {
			__line = i,
			__file = fileName
		}
		local hashArr = {}

		for j = 1, #values do
			if castToNumber then
				local numberValue = tonumber(values[j])

				if numberValue == nil then
					data[columns[j]] = CsvParser.escapeMiscellaneous(values[j])
				else
					data[columns[j]] = numberValue
				end
			else
				data[columns[j]] = CsvParser.escapeMiscellaneous(values[j])
			end

			table.insert(hashArr, tostring(data[columns[j]]))
		end

		local hashStr = table.concat(hashArr, "_")
		data.__hash = crypto.md5(hashStr)

		table.insert(arr, data)
	end

	return arr
end

function CsvParser.escapeMiscellaneous(str)
	str = string.gsub(str, "&comma;", ",")
	str = string.gsub(str, "&linefeed;", "\n")
	str = string.gsub(str, "&quot;", "\"")
	str = string.gsub(str, "_x000D_", "")

	return str
end

return CsvParser
