local ChanceUtils = {}

function ChanceUtils.furnaceBattle(npc, onComplete)
	local eventIndex = npc.eventData.index
	local eventData = npc.eventData
	local monsterGroupID = npc.data.value1
	local pack = MapEventManager.makeMonsterSet(npc.eventData, MapEventManager.monsterSetIndex, nil, {
		id = monsterGroupID
	})
	MapEventManager.monsterSetIndex = MapEventManager.monsterSetIndex + 1
	local random = Random.new(npc.eventData.seed)
	local createParams = {
		id = monsterGroupID,
		random = random,
		pack = pack,
		onBattleWin = function (onSent)
			local enemys = WarMachine.getEventEnemy(eventData)

			for i, unit in ipairs(enemys) do
				unit.negative = true
			end

			InfoDungeon.getChance(npc, eventIndex, nil, function (rcvData)
				if onComplete then
					onComplete()
				end

				global.player:setGoDirectionLocked("chance_battle_win", true)

				local function aoeKillMonsters()
					for i, unit in ipairs(enemys) do
						if unit.x and unit.y then
							local distance = math.sqrt(math.pow(npc.x - unit.x, 2) + math.pow(npc.y - unit.y, 2))

							Looper.setTimeout(function ()
								unit:die()
							end, distance * 0.05, unit)
						elseif unit.die then
							unit:die()
						end
					end
				end

				local function onZoomRecover()
					MapEffect.quake(5, 1.5, 15)
					npc:refreshOpened(true)
					npc.map:tweenViewZoom(1, 15, nil, , "linear")
					npc.map:recoverConfig(15, "outQuad")
					MapEffect.bulletTime("WarMachine_over", 0.5)
					aoeKillMonsters()
					Looper.setTimeout(function ()
						global.player:setGoDirectionLocked("chance_battle_win", false)

						if onSent then
							onSent()
						end
					end, 60, npc)
				end

				local function showUnits()
					local units = ClipOnMap.getUnitList("summoned", "monster", "hero", "pet")

					for i, unit in ipairs(units) do
						local effectGen = unit:getEffectGen()

						if effectGen then
							effectGen:fadeTo(5, 255, "outQuad")
						end
					end
				end

				local function onZoomClose()
					MapEffect.quake(3, 1.2, 60)
					Looper.setTimeout(showUnits, 55, npc)
					Looper.setTimeout(onZoomRecover, 60, npc)
				end

				local units = ClipOnMap.getUnitList("summoned", "monster", "hero", "pet")

				for i, unit in ipairs(units) do
					local effectGen = unit:getEffectGen()

					if effectGen then
						effectGen:fadeTo(10, 0, "outQuad")
					end
				end

				npc.map:cancelBattleLight()
				npc.map:tweenViewZoom(1.25, 30, onZoomClose, nil, "outQuad")
				npc.map:setConfig({
					light = {
						min = 0.1,
						radius = 0.3
					}
				}, 15, "outQuad")
			end, function (err)
			end)
		end
	}

	npc:setAction("battle")
	global.map:prepareBattle(npc.tile, nil, npc.eventData, nil, createParams)
end

function ChanceUtils.gladiatorBattle(npc, onComplete)
	local eventData = npc.eventData
	local eventIndex = eventData.index
	local eventInfo = InfoDungeon.getEventInfo(eventData.index)
	local info = ConfParser.parse(eventData.info)
	local chanceID = nil

	if info.id then
		chanceID = info.id
	else
		local random = Random.new(eventData.seed)
		local drop_rare = 0
		chanceID = DropManager.dropLibChance(info.drop_id, InfoDungeon.getLevel(), drop_rare, random)
	end

	local chanceCSV = CsvParser.getCsvData("chance", chanceID)
	local gladiatorCSV = CacheData.chance_getGladiator(chanceID, eventInfo.fin)
	Monster.noCheckBattle = true
	local monsterGroupID = gladiatorCSV.battle

	print("$$$ monsterGroupID", monsterGroupID)

	if empty(monsterGroupID) then
		return
	end

	local pack = MapEventManager.makeMonsterSet(npc.eventData, MapEventManager.monsterSetIndex, nil, {
		id = monsterGroupID
	})
	MapEventManager.monsterSetIndex = MapEventManager.monsterSetIndex + 1
	local random = Random.new(npc.eventData.seed)
	local createParams = {
		id = monsterGroupID,
		random = random,
		pack = pack
	}

	if global.player then
		global.player:setNpcNavDisabled(true)
	end

	function createParams.onBattleWin(onSent)
		if WarMachine.winType == 1 then
			local enemys = WarMachine.getEventEnemy(eventData)

			for jj, unit in ipairs(enemys) do
				unit:die()
			end
		end

		Monster.noCheckBattle = nil

		InfoDungeon.getChance(npc, eventIndex, {
			type = 1
		}, function (rcvData)
			if onComplete then
				onComplete()
			end

			global.player:setGoDirectionLocked("chance_battle_win", true)

			local function onZoomRecover()
				npc:refreshGladiator(animated)
				npc.map:tweenViewZoom(1, 15, nil, , "linear")
				Looper.setTimeout(function ()
					global.player:setGoDirectionLocked("chance_battle_win", false)

					if global.player then
						global.player:setNpcNavDisabled(false)
					end
				end, 60, npc)
			end

			local function onZoomClose()
				if onSent then
					onSent()
				end

				Looper.setTimeout(onZoomRecover, 60, npc)
			end

			npc.map:cancelBattleLight()
			npc.map:tweenViewZoom(1.25, 30, onZoomClose, nil, "outQuad")
		end, function (err)
		end)
	end

	npc:setAction("open")
	global.map:prepareBattle(npc.tile, nil, npc.eventData, nil, createParams)
end

function ChanceUtils.openEquipShop(npc, eventIndex)
	local eventInfo = InfoDungeon.getEventInfo(eventIndex)

	if eventInfo and eventInfo.fin > 0 then
		npc:say(LinesManager.getAction("equip_shop_empty"), 120)

		return
	end

	InfoDungeon.getEquipShopInfo(eventIndex, function (rcvData)
		local shopCount = 0

		for i, v in ipairs(rcvData.list) do
			if v.fin ~= 1 then
				shopCount = shopCount + 1
			end
		end

		if shopCount > 0 then
			FRAME_equip_shop.open(npc, eventIndex, rcvData.list, rcvData.best_id)
		else
			npc:say(LinesManager.getAction("equip_shop_empty"), 120)
		end
	end)
end

return ChanceUtils
