local InfoBard = {}
local TYPE = {
	ELITE = 2,
	BOSS = 1,
	TREASURE = 3
}
InfoBard.TYPE = TYPE

function InfoBard.init()
end

function InfoBard.listen(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if rcvData.like_names ~= "" then
				rcvData.like_names = json.decode(rcvData.like_names)
			else
				rcvData.like_names = {}
			end

			notify.dispatch("bard_listen", rcvData)

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("bard_listen", callback)
end

function InfoBard.like(id, hash, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("bard_like", {
		id = id,
		hash = hash
	}, callback)
end

function InfoBard.parseShort(rcvData)
	return InfoBard.parse(rcvData, 1)
end

function InfoBard.parseLong(rcvData)
	return InfoBard.parse(rcvData, 2)
end

function InfoBard.parse(rcvData, kind)
	if rcvData.type == InfoBard.TYPE.BOSS or rcvData.type == InfoBard.TYPE.ELITE then
		local data = json.decode(rcvData.pack)
		local abyssCSV = CsvParser.getCsvData("abyss", data.dunID, nil, true)

		if abyssCSV then
			local monsterCSV = CsvParser.getCsvData("monster", data.monID)
			local terrainCSV = CsvParser.getCsvData("abyss_terrain", abyssCSV.map_type)
			local bardCSV = LinesManager.getBard(1, rcvData.seed, {
				map_type = abyssCSV.map_type
			})

			if bardCSV then
				local text = bardCSV["text_" .. kind]
				local newStr = StringUtil.replaceTag(text, function (tag)
					if tag == "name" then
						return data.name
					elseif tag == "abyss" then
						return terrainCSV.name
					elseif tag == "monster" then
						return monsterCSV.name
					end
				end)

				return newStr
			end
		end

		return
	end

	if rcvData.type == InfoBard.TYPE.TREASURE then
		-- Nothing
	end
end

return InfoBard
