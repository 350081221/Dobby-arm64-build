local UI_base = import("..UI_base")
local FRAME_abyss = class("FRAME_abyss", UI_base)

function FRAME_abyss.open(npc)
	local ui = FRAME_abyss.new(npc)
	local container = display.newNode()
	container.ui_title = "container"

	container:setCascadeOpacityEnabled(true)
	container:addChild(ui)
	ui:onOpen()
	PopManager.open(container, nil, function ()
		ui:onClose()
	end, PopManager.ANIM_TYPE.FADE, 50)
end

function FRAME_abyss:ctor(npc, onClose)
	FRAME_abyss.super.ctor(self, "frame_abyss", UIManager.BIG_TYPE.POP)

	self.npc = npc

	self:init()
end

function FRAME_abyss:init()
	self:initUI()
	self:refreshArea()

	local areaSelectedIndex = 1

	for i, areaCSV in ipairs(self.areaList.items) do
		if InfoWorld.getAbyssArea() < areaCSV.id then
			areaSelectedIndex = i + 1
		else
			break
		end
	end

	self.areaList:setSelectedIndex(areaSelectedIndex)

	local flag_probup = self:getFlagByTag("flag_probup")
	local probupUI = FRAME_probup.new(Localization.getSrcText("深渊"), {
		4,
		5
	}, flag_probup)

	self:addChild(probupUI, 1000)

	local seasonGuideUI = FRAME_season_guide.new(GameConfig.moonID, 6)

	self:addChild(seasonGuideUI, 1000)

	self.seasonGuideUI = seasonGuideUI
	local dropGuideUI = FRAME_season_guide.new(GameConfig.seasonID, 9)

	self:addChild(dropGuideUI, 1000)
	dropGuideUI:setPositionY(-180)

	self.dropGuideUI = dropGuideUI
	local giftUI = FRAME_area_gift.new()

	self:addChild(giftUI, 1000)

	self.giftUI = giftUI

	self:refreshAreaHide()
	self:refreshList()
	InfoAbyssArea.checkGift(function ()
		self:refreshAreaGift()
	end)
	ManagerInfo.onDataChange(self, "order", nil, function ()
		self:refreshAreaGift()
	end)
end

function FRAME_abyss:refreshAreaHide()
	local areaArr, maxIndex, areaOpenMax = InfoDungeon.getAreaList()

	print("$$$ maxIndex, areaOpenMax", maxIndex, areaOpenMax)

	local spaceX = 170 * self:getBigScale()
	local bg1 = self:getComponentByTag("bg1")
	local giftX = 0

	if areaOpenMax <= 1 then
		self:setPositionX(spaceX)
		self.seasonGuideUI:setPositionX(-spaceX)
		self.dropGuideUI:setPositionX(-spaceX)
		bg1:setVisible(false)
		self.areaList:setVisible(false)

		if self.openUI then
			self.openUI:setPositionX(self.openUI.oriX - spaceX / 2)
		end
	else
		self:setPositionX(0)
		self.seasonGuideUI:setPositionX(0)
		self.dropGuideUI:setPositionX(0)
		bg1:setVisible(true)
		self.areaList:setVisible(true)

		if self.openUI then
			self.openUI:setPositionX(self.openUI.oriX)
		end

		giftX = 160
	end

	self.giftUI:setPositionX(giftX)
end

function FRAME_abyss:initUI()
	local mask1 = self:getComponentByTag("mask1")

	mask1:toTouchable()
	mask1:setOpacity(0)
	mask1:setVisible(false)
	mask1:setLocalZOrder(10000)

	local mask = self:getComponentByTag("mask")

	mask:toTouchable()
	mask:setOpacity(0)

	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local bg1 = self:getComponentByTag("bg1")

	bg1:toTouchable()
	bg1:setLocalZOrder(90)

	local listFlag = self:getFlagByTag("flag_list")
	local listFlagBoss = self:getFlagByTag("flag_list_boss")
	local areaListFlag = self:getFlagByTag("flag_list_area")
	local flag_probup = self:getFlagByTag("flag_probup")
	local flag_boss = self:getFlagByTag("flag_boss")
	local flag_boss_neo = self:getFlagByTag("flag_boss_neo")
	local holder = self:getComponentByTag("holder")
	local holder_bg = self:getComponentByTag("holder_bg")
	local holder_bg_boss = self:getComponentByTag("holder_bg_boss")
	local stand_mask = self:getComponentByTag("stand_mask")
	local bg_closed = self:getComponentByTag("bg_closed")
	local lWidth = display.width - 960 >= 100
	self.lWidth = lWidth

	if lWidth then
		mask:setPos(mask.x - 100)
		mask:setSize(mask.width + 100)
		bg:setPos(bg.x - 100)
		bg:setSize(bg.width + 100)
		holder:setPos(holder.x - 100)
		holder_bg:setPos(holder_bg.x - 100)
		holder_bg_boss:setPos(holder_bg_boss.x - 100)

		listFlag.x = listFlag.x - 100
		listFlag.width = listFlag.width + 100
		listFlagBoss.x = listFlagBoss.x - 100
		listFlagBoss.width = listFlagBoss.width + 100
		flag_probup.width = flag_probup.width - 100
		flag_boss.x = flag_boss.x - 100
		flag_boss.width = flag_boss.width - 100
		flag_boss_neo.x = flag_boss_neo.x - 100
		flag_boss_neo.width = flag_boss_neo.width - 100

		stand_mask:setPos(stand_mask.x - 100)
		stand_mask:setSize(stand_mask.width + 100)
		bg_closed:setPos(bg_closed.x - 100)
		bg_closed:setSize(bg_closed.width + 100)
		bg_closed:resetLabel()
	end

	local function tapListener(ui, data, index)
		self:refreshList()
	end

	self.areaList = self:createListOnFlag("flag_list_area", LIST_abyss_area, tapListener, touchListener)

	self.areaList:setTapGroup("list_click")

	local function tapListener(ui, data, index)
		if data.isSkip then
			return
		end

		if not InfoGuide.isFin() and index > 1 then
			Alert.open(Localization.getSrcText("请先完成引导"))

			return
		end

		if InfoDungeon.isBossLayer(data.csv) and not InfoDungeon.isBossOpen(data.csv) then
			Alert.open(Localization.getSrcText("未达到boss层级"))

			return
		end

		FRAME_abyss_prepare.open(data.csv)
	end

	self.list = self:createListOnFlag("flag_list", function (rect)
		return LIST_abyss.new(rect, lWidth)
	end, tapListener, touchListener)

	self.list:setTapGroup("list_click")

	local holder = self:getComponentByTag("holder")

	self.list:setHolders({
		holder
	}, nil, 5)

	local flag = self:getFlagByTag("flag_target")
	local flag = self:getFlagByTag("flag_boss")
	local bossUIName = "frame_abyss_boss"

	if lWidth then
		bossUIName = "frame_abyss_boss_l"
	end

	local bossUI = UIManager.getUI(bossUIName)

	bossUI:setPosition(flag.x, flag.y)
	self:addChild(bossUI, 80)

	self.bossUI = bossUI
	local boss_bg = bossUI:getComponentByTag("boss_bg")

	boss_bg:setOpacity(120)

	local bt_boss = bossUI:getComponentByTag("bt_boss")

	bt_boss:toTouchable()
	bt_boss:setTapGroup("button_click")
	bt_boss:setOpacity(0)
	bt_boss:addTap(function ()
		if self.bossInfo and self.bossInfo.boss then
			local bossCSV = self.bossInfo.boss
			local akasaCSV = self.bossInfo.akasa
			local areaCSV = self.bossInfo.area

			if InfoDungeon.isBossLayer(bossCSV) and not InfoDungeon.isBossOpen(bossCSV) then
				Alert.open(Localization.getSrcText("未达到boss层级"))

				return
			end

			FRAME_abyss_prepare_boss.open(areaCSV, bossCSV, akasaCSV)
		end
	end)

	local unit = Monster.new()
	unit.angle = 0

	unit:randomizeFrame()
	bossUI:addChild(unit, 1000)

	local unitFlag = bossUI:getFlagByTag("flag_unit")

	unit:setPosition(unitFlag.x + unitFlag.width / 2, unitFlag.y)

	self.bossUnit = unit
	local flag = self:getFlagByTag("flag_boss_neo")
	local neoUIName = "frame_boss_neo"

	if lWidth then
		neoUIName = "frame_boss_neo_l"
	end

	local neoUI = UIManager.getUI(neoUIName)

	neoUI:setPosition(flag.x, flag.y)
	self:addChild(neoUI, 80)

	self.neoUI = neoUI
	local boss_bg = neoUI:getComponentByTag("boss_bg")

	boss_bg:setOpacity(120)
	boss_bg:toTouchable()
	boss_bg:setTapGroup("bg_click")
	boss_bg:addTap(function ()
		if self.bossInfo and self.bossInfo.boss then
			local bossCSV = self.bossInfo.boss
			local akasaCSV = self.bossInfo.akasa
			local areaCSV = self.bossInfo.area

			FRAME_abyss_boss_neo.open(areaCSV, bossCSV, akasaCSV)
		end
	end)

	local bg_akasa_name = neoUI:getComponentByTag("bg_akasa_name")

	bg_akasa_name:setOpacity(200)

	local akasa_bg = neoUI:getComponentByTag("akasa_bg")

	akasa_bg:toTouchable()
	akasa_bg:setTapGroup("bg_click")
	akasa_bg:addTap(function ()
		if self.bossInfo and self.bossInfo.boss then
			local bossCSV = self.bossInfo.boss
			local akasaCSV = self.bossInfo.akasa
			local areaCSV = self.bossInfo.area

			FRAME_abyss_akasa.open(areaCSV, bossCSV, akasaCSV)
		end
	end)

	local function tapListener(ui, data, index)
		DropManager.popDetail(data.type, data.info)
	end

	neoUI.rewardList = neoUI:createListOnFlag("flag_reward", LIST_abyss_prepare, tapListener)

	neoUI.rewardList:setCols(self.lWidth and 6 or 5)
	neoUI.rewardList:setCellSize(cc.size(neoUI.rewardList.cols * 85, 85))
	neoUI.rewardList:setSpace(5, 5)
	neoUI.rewardList:setTouchDelegate()
	neoUI.rewardList:setTouchEnabled(false)
	neoUI.rewardList:setOpacity(80)
	neoUI.rewardList:setLocalZOrder(akasa_bg:getLocalZOrder())
end

function FRAME_abyss:refreshAreaGift()
	local areaCSV = self.areaList:getSelectedItem()
	local giftCSV, onceCSV, dayLeft = InfoAbyssArea.getGift(areaCSV.id)

	if giftCSV and InfoOrder.getOnce(onceCSV.id) == 0 then
		self.giftUI:setGift(areaCSV.id)
	else
		self.giftUI:clearGift()
	end
end

function FRAME_abyss:refreshList()
	local areaCSV = self.areaList:getSelectedItem()
	local holder_bg = self:getComponentByTag("holder_bg")
	local holder_bg_boss = self:getComponentByTag("holder_bg_boss")
	local bg_closed = self:getComponentByTag("bg_closed")

	self:refreshAreaGift()

	if areaCSV.id <= InfoWorld.getAbyssArea() then
		local entranceList, bossCSV, akasaCSV = InfoDungeon.getEntranceList(areaCSV.id)
		local isBoss = areaCSV.is_boss > 0

		if areaCSV.is_boss == 2 then
			self.list:setVisible(false)
			holder_bg:setVisible(false)
			holder_bg_boss:setVisible(false)
		else
			self.list:setVisible(true)

			if isBoss then
				self.list:setRect(self:getRectByFlag("flag_list_boss"))
			else
				self.list:setRect(self:getRectByFlag("flag_list"))
			end

			holder_bg:setVisible(not isBoss)
			holder_bg_boss:setVisible(isBoss)
			self.list:setItems(entranceList)
		end

		if isBoss then
			self.bossInfo = {
				area = areaCSV,
				boss = bossCSV,
				akasa = akasaCSV
			}
		end

		self.bossUI:setVisible(areaCSV.is_boss == 1)

		if areaCSV.is_boss == 1 then
			self:refreshBossUI(areaCSV, bossCSV, akasaCSV)
		end

		self.neoUI:setVisible(areaCSV.is_boss == 2)

		if areaCSV.is_boss == 2 then
			self:refreshNeoUI(areaCSV, bossCSV, akasaCSV)
		end

		self:removeClippingOnFlag("stand_mask")

		local stand_mask = self:getComponentByTag("stand_mask")

		stand_mask:setVisible(false)
		bg_closed:setVisible(false)
	else
		self.bossUI:setVisible(false)
		self.list:setVisible(false)
		holder_bg:setVisible(false)
		holder_bg_boss:setVisible(false)
		bg_closed:setVisible(true)

		local stand_mask = self:getComponentByTag("stand_mask")

		stand_mask:setVisible(true)

		local pic = self:createClippingOnFlag("stand_mask", "area_closed", areaCSV.stand)

		if pic then
			Shader.gray(pic)
			pic:setOpacity(100)
			transition.fadeTo(pic, {
				time = 0.2,
				opacity = 150
			})
		end
	end
end

function FRAME_abyss:refreshNeoUI(areaCSV, bossCSV, akasaCSV)
	local ui = self.neoUI
	local label, labelWidth = ui:createLabelOnFlag("flag_boss_name", areaCSV.boss_name)
	local bg_boss_name = ui:getComponentByTag("bg_boss_name")

	bg_boss_name:setSize(labelWidth + 20)
	bg_boss_name:setPos(bg_boss_name.originalX - (bg_boss_name.width - bg_boss_name.originalWidth) / 2)

	local maxLayer = InfoDungeon.getAbyssMaxLayer()
	local neoList = InfoAbyssArea.getBossNeoList(areaCSV.id)
	local neoCSV, index = InfoAbyssArea.getBossNeoCurrent(areaCSV.id)

	if ui.standPicArr then
		for i, pic in ipairs(ui.standPicArr) do
			pic:removeSelf()
		end
	end

	ui.standPicArr = {}
	local rect = ui:getComponentByTag("stand_mask")
	local pic_mask = rect

	pic_mask:setOpacity(5)

	local zorder = pic_mask:getLocalZOrder()
	local clippingName = "boss_neo_s"

	if self.lWidth then
		clippingName = "boss_neo_sl"
	end

	local container = display.newNode()

	for i, csv in ipairs(neoList) do
		if index <= i then
			local clippingData = JsonParser.parse("res/clipping/" .. clippingName .. ".json")
			local picPath = getFinalRes("res/image/" .. clippingData.path .. "/" .. csv.pic .. ".png")
			local pic = display.newSprite(picPath)
			local picData = clippingData.clipping[csv.pic .. ".png"]

			pic:setScale(picData.scale / 100)
			pic:setPosition(rect.x + math.floor(clippingData.width / 2) + picData.xoffset, rect.y + math.floor(clippingData.height / 2) - picData.yoffset)
			container:addChild(pic, -i)

			pic.x = rect.x
			pic.y = rect.y
			pic.width = rect.width
			pic.height = rect.height

			if index < i then
				pic:setVisible(true)
				Shader.gray(pic)
				pic:setOpacity(50)
			else
				pic:setVisible(true)
			end

			table.insert(ui.standPicArr, pic)
		end
	end

	local clipNode = cc.ClippingNode:create()

	clipNode:setStencil(pic_mask)
	clipNode:setAlphaThreshold(0.0001)
	clipNode:addChild(container)
	clipNode:setCascadeOpacityEnabled(true)
	ui:addChild(clipNode, zorder)

	if akasaCSV then
		ui:createLabelOnFlag("flag_akasa_name", akasaCSV.name)
	else
		ui:removeLabelOnFlag("flag_akasa_name")
	end

	local info = InfoDungeon.getAbyssInfo(akasaCSV.layer)

	if info then
		local itemArr = {}
		local arr = string.split(info.reward_item, ";")

		for i, v in ipairs(arr) do
			if not empty(v) then
				local itemID = tonumber(v)

				if InfoItem.getNum(itemID) == 0 then
					table.insert(itemArr, {
						type = DropManager.TYPE.ITEM,
						info = {
							num = 1,
							base_id = itemID
						}
					})
				end
			end
		end

		local arr = string.split(info.item_display, ";")

		for i, v in ipairs(arr) do
			if not empty(v) then
				local itemID = tonumber(v)
				local itemCSV = CsvParser.getCsvData("item", itemID)

				if itemCSV.drop_level_min <= info.level + 3 and info.level <= itemCSV.drop_level_max then
					table.insert(itemArr, {
						type = DropManager.TYPE.ITEM,
						info = {
							num = 1,
							base_id = itemID
						}
					})
				end
			end
		end

		ui.rewardList:setAbyssLevel(akasaCSV.level)
		ui.rewardList:setItems(itemArr)
	end
end

function FRAME_abyss:refreshBossUI(areaCSV, bossCSV, akasaCSV)
	local ui = self.bossUI

	if areaCSV then
		ui:createLabelOnFlag("flag_boss_name", areaCSV.boss_name)

		local unitFlag = ui:getFlagByTag("flag_unit")
		local unit = self.bossUnit
		local monsterInfo = {
			level = 1,
			base_id = areaCSV.model_show
		}

		unit:setInfo(monsterInfo)
		unit:rawSetScale(math.min(1.5, unitFlag.height / unit.height))
		unit:forceAction("idle")

		if unit.shadow then
			unit.shadow:removeSelf()
		end

		local shadow = display.newSprite("#map_assets_shadow")

		shadow:setScale(math.sqrt(unit.width / 64))

		unit.shadow = shadow

		unit:addChild(shadow, -100)
	else
		ui:removeLabelOnFlag("flag_boss_name")
	end

	local titleArr = {
		Localization.getSrcText("领域首领"),
		""
	}

	if InfoDungeon.isBossLayer(bossCSV) and not InfoDungeon.isBossOpen(bossCSV) then
		titleArr[2] = Localization.getSrcText("(未开启)")
	end

	ui:replaceLabelGroupOnFlag("flag_title", titleArr, {
		{},
		{
			color = Style.disableColor
		}
	})

	if akasaCSV then
		ui:createLabelOnFlag("flag_akasa_name", akasaCSV.name)
	else
		ui:removeLabelOnFlag("flag_akasa_name")
	end

	ui:clearDuplicated("bar")

	if areaCSV then
		local mapCount, mapAlready, mineCount, mineAlready = InfoDungeon.getAreaInfo(areaCSV.id)
		local flag = ui:getFlagByTag("flag_bar")
		local space = 3
		local perWidth = (flag.width - space * (mapCount - 1)) / mapCount
		local bar = ui:getComponentByTag("bar")
		local barArr = ui:duplicateComponent("bar", mapCount - 1, perWidth + space, 0, Style.left)

		for i, bar in ipairs(barArr) do
			bar:setSize(perWidth, nil, true)
			bar:setPos(flag.x + (i - 1) * (perWidth + space))

			if i <= mapAlready then
				bar:setFrame(1)
			else
				bar:setFrame(2)
			end
		end
	end
end

function FRAME_abyss:refreshArea()
	local areaArr, maxIndex, areaOpenMax = InfoDungeon.getAreaList()

	print("$$$ areaOpenMax", areaOpenMax, maxIndex)
	self.areaList:setItems(areaArr)

	local openID = nil

	if areaOpenMax < maxIndex then
		local csv = CsvParser.getCsvData("abyss_area", areaOpenMax + 1)

		if csv and InfoItem.getNum(csv.open_item) > 0 then
			openID = csv.id
		end
	end

	if self.openUI then
		self.openUI:removeSelf()

		self.openUI = nil
	end

	if openID then
		local flag = self:getFlagByTag("flag_target")
		local openUI = self:createUIOnFlag("flag_target", "frame_abyss_area_open", -100)
		openUI.oriX = flag.x + (flag.width - (lWidth and 100 or 0)) / 2 - 195

		openUI:setPositionX(openUI.oriX)

		self.openUI = openUI
		local csv = CsvParser.getCsvData("abyss_area", openID)
		local slot = DropSlot.new(openUI:getFlagByTag("flag_slot"), "slot_01")

		openUI:addChild(slot, 100)
		slot:setDrop(DropManager.TYPE.ITEM, {
			base_id = csv.open_item
		})
		slot:setDetailEnabled(true)

		local bt_open = openUI:getComponentByTag("bt_open")

		bt_open:toTouchable()
		bt_open:setTapGroup("button_click")
		bt_open:addTap(function ()
			InfoAbyssReward.openArea(openID, function ()
				self:showAreaOpen(openID, function ()
					self:refreshAreaHide()
					self:refreshArea()
					self.areaList:setSelectedIndex(1)
					self:refreshList()
					self:refreshAreaGift()
					Sound.stopMusicOnce()
				end)
			end)
		end)
	end
end

function FRAME_abyss:showAreaOpen(areaID, onOver)
	Sound.playMusicOnce(MiscConfig.area_open_bgm, true)

	local csv = CsvParser.getCsvData("abyss_area", areaID)
	local mask1 = self:getComponentByTag("mask1")

	mask1:setVisible(true)

	if self.seasonGuideUI then
		transition.fadeTo(self.seasonGuideUI, {
			time = 0.2,
			easing = "sineOut",
			opacity = 0,
			onComplete = function ()
				self.seasonGuideUI:setVisible(false)
			end
		})
	end

	if self.dropGuideUI then
		transition.fadeTo(self.dropGuideUI, {
			time = 0.2,
			easing = "sineOut",
			opacity = 0,
			onComplete = function ()
				self.dropGuideUI:setVisible(false)
			end
		})
	end

	if self.giftUI then
		transition.fadeTo(self.giftUI, {
			time = 0.2,
			easing = "sineOut",
			opacity = 0,
			onComplete = function ()
			end
		})
	end

	local units = TeamManager.getTeam()

	for i, unit in ipairs(units) do
		local effectGen = unit:getEffectGen()

		if effectGen then
			effectGen:fadeTo(30, 0, "outQuad")
		end
	end

	local mapX, mapY = global.map:tileToMap(self.npc.tile.x + 2, self.npc.tile.y)
	local areaCSV = CsvParser.getCsvData("abyss_area", areaID)

	local function closeStep()
		global.map:scrollTo(self.npc.x, self.npc.y)
		mask1:setVisible(false)

		if self.seasonGuideUI then
			self.seasonGuideUI:setVisible(true)
			transition.fadeTo(self.seasonGuideUI, {
				time = 0.2,
				easing = "sineOut",
				opacity = 255
			})
		end

		if self.dropGuideUI then
			self.dropGuideUI:setVisible(true)
			transition.fadeTo(self.dropGuideUI, {
				time = 0.2,
				easing = "sineOut",
				opacity = 255
			})
		end

		if self.giftUI then
			transition.fadeTo(self.giftUI, {
				time = 0.2,
				easing = "sineOut",
				opacity = 255
			})
		end

		for i, unit in ipairs(units) do
			local effectGen = unit:getEffectGen()

			if effectGen then
				effectGen:fadeTo(30, 255, "outQuad")
			end
		end

		local bg = self:getComponentByTag("bg")
		local centerX = bg.x / 2

		global.map:tweenViewZoom(1.4, 60, nil, true)
		global.map:setPositionOffsetTween("ui_open", centerX - display.cx, -96, 60)

		if onOver then
			onOver()
		end
	end

	local function delayClose()
		MapEffect.quake(16)
		POP_mask.openFlash(self, nil, 10, 120)
		Looper.setTimeout(closeStep, 60, self)
	end

	local stone = nil
	local stoneZ = 100
	local npcX, npcY = global.map:tileToMap(self.npc.tile)
	local distance, angle, angleOffset, loopFunc3 = nil
	local shiningTime = 1

	local function refreshStonePos()
		local x = math.cos(angle + angleOffset) * distance + npcX
		local y = math.sin(angle + angleOffset) * distance + npcY

		stone:draw(x, y, true)
	end

	local function makeShining(node, start)
		local min = 0
		local max = 200
		local interval = 0
		local upInterval = 0
		start = start or 0
		local shiningUp, shiningDown = nil

		function shiningUp()
			transition.fadeTo(node, {
				delay = upInterval,
				opacity = max,
				time = shiningTime,
				onComplete = shiningDown
			})
		end

		function shiningDown()
			transition.fadeTo(node, {
				delay = interval,
				opacity = min,
				time = shiningTime,
				onComplete = shiningUp
			})
		end

		transition.fadeTo(node, {
			delay = start,
			opacity = min,
			time = shiningTime,
			onComplete = shiningUp
		})
	end

	local function step4()
		self:performWithDelay(function ()
			Sound.playSound(MiscConfig.sfx_area_open)
		end, 0.3)

		local startObj = {
			percent = 1
		}
		local endObj = {
			percent = 0
		}
		local startDistance = distance
		local startShineTime = shiningTime

		local function onUpdate()
			shiningTime = math.max(startShineTime * startObj.percent, 0.05)
			distance = startDistance * startObj.percent

			refreshStonePos()
		end

		local function onComplete()
			Looper.stopLoop(stone, loopFunc3)
			stone:removeSelf()
			delayClose()
		end

		Looper.tween(45, startObj, endObj, "inCubic", onComplete, onUpdate)
	end

	local function step3()
		Sound.playSound(MiscConfig.sfx_shrine_read)

		local time = 200
		distance = math.sqrt(math.pow(stone.y - npcY, 2) + math.pow(stone.x - npcX, 2))
		angle = math.atan2(stone.y - npcY, stone.x - npcX)
		angleOffset = 0
		local effectGen = stone:getEffectGen()

		if effectGen then
			effectGen:zmove(time, stoneZ)
		end

		global.map:tweenViewZoom(1.2, time, nil, true)
		global.map:setPositionOffsetTween("ui_open", 0, -stoneZ * 1.2, time)

		local alreadyStep3 = nil
		local speed = 0
		local maxSpeed = 0.05
		local maxAngle = math.pi * 4
		local overAngle = maxAngle - 1

		function loopFunc3(obj, frame, passed, sharp)
			if alreadyStep3 then
				speed = math.max((0 - speed) * math.pow(0.3, passed) + speed, 0.005)
			else
				speed = (maxSpeed - speed) * math.pow(0.2, passed) + speed
			end

			angleOffset = angleOffset + speed * passed
			angleOffset = math.min(angleOffset, maxAngle)

			refreshStonePos()

			if not alreadyStep3 and overAngle <= angleOffset then
				alreadyStep3 = true

				self:performWithDelay(step4, 1)
			end
		end

		Looper.startLoop(stone, loopFunc3)
	end

	local function step2()
		stone.highlight = display.newSprite(stone.modelName):align(display.LEFT_BOTTOM)

		stone.bmp:addChild(stone.highlight)
		Shader.custom(stone.highlight, "add_1")
		makeShining(stone.highlight, 0.1)

		local startObj = {
			percent = 1
		}
		local endObj = {
			percent = 0.2
		}
		local startShineTime = shiningTime

		local function onUpdate()
			shiningTime = startShineTime * startObj.percent
		end

		Looper.tween(30, startObj, endObj, "outCubic", nil, onUpdate)
		self:performWithDelay(step3, 0.5)
	end

	local function step1()
		local flag = self.openUI:getFlagByTag("flag_slot")
		local pos = self.openUI:convertToWorldSpace(cc.p(flag.x + flag.width / 2, flag.y + flag.height / 2))
		local startX, startY = global.map:screenToMap(pos.x, pos.y)
		stone = DropItem.new()

		stone:setDrop({
			type = DropManager.TYPE.ITEM,
			info = {
				num = 1,
				base_id = areaCSV.open_item
			}
		})
		stone:display(global.map, startX, startY)

		stone.fixedLight = 255

		local function onJumpComplete()
			step2()
		end

		local scale = 0.3

		stone:rawSetScale(scale)
		stone:setBmpY()

		local function onJumpUpdate()
			scale = math.min(0.5, scale + 0.05)

			stone:rawSetScale(scale)
		end

		stone:jump({
			x = mapX,
			y = mapY
		}, 10, 50, onJumpComplete, nil, onJumpUpdate)
	end

	global.map:setPositionOffsetTween("ui_open", 0, 0, 10)
	global.map:tweenFov(mapX, mapY, 10, "outQuad")
	global.map:tweenScrollTo(mapX, mapY, 10, nil, "outQuad")

	local mask = self:getComponentByTag("mask")

	transition.moveTo(self, {
		time = 0.2,
		easing = "sineOut",
		x = mask.width
	})
	transition.moveTo(self.openUI, {
		time = 0.2,
		easing = "sineOut",
		x = self:getPositionX() + self.openUI:getPositionX() - mask.width
	})
	transition.fadeTo(self.openUI, {
		time = 0.2,
		easing = "sineOut",
		opacity = 0,
		onComplete = function ()
			self.openUI:removeSelf()

			self.openUI = nil
		end
	})
	step1()
end

function FRAME_abyss:onOpen()
	local bg = self:getComponentByTag("bg")
	local centerX = bg.x / 2

	global.map:tweenViewZoom(1.4, 10, nil, true)
	global.map:setPositionOffset("ui_open", centerX - display.cx, -96)
	global.player:setGoDirectionLocked("ui_open", true)

	self.normalLight = {
		min = global.map.config.light.min,
		radius = global.map.config.light.radius
	}

	global.map:setConfig({
		light = {
			min = 0.2,
			radius = 0.5
		}
	})
	global.ui:setVisible(false)
	global.map:scrollTo(self.npc.x, self.npc.y)
	self.npc:setCustomLight(0.6, 2)
	self.npc:draw()
end

function FRAME_abyss:onClose()
	global.map:scrollTo(global.player.x, global.player.y)
	global.map:tweenViewZoom(1, 15)
	global.map:setPositionOffset("ui_open", 0, 0)
	global.player:setGoDirectionLocked("ui_open", false)
	global.map:setConfig({
		light = self.normalLight
	})
	global.ui:setVisible(true)
	self.npc:clearCustomLight()
end

return FRAME_abyss
