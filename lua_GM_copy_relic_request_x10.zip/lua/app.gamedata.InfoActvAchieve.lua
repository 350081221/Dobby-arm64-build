local InfoActvAchieve = {}
local day_data = {}
local full_data = {}
local day_config = {}
local full_config = {}

function InfoActvAchieve.init()
	Connection.listen("actv_achieve_sync", InfoActvAchieve.sync)
end

app:addToAppEnterCall(InfoActvAchieve.init)

function InfoActvAchieve.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoActvAchieve.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("actv_achieve_query", callback)
end

function InfoActvAchieve.onQuery(rcvData)
	dump(rcvData, "actv_achieve_query", 10)

	day_data = {}
	full_data = {}
	day_config = {}
	full_config = {}

	for i, v in ipairs(rcvData.list) do
		if v.type == 1 then
			day_data[v.actv_id] = day_data[v.actv_id] or {}
			day_data[v.actv_id][v.base_id] = v
		elseif v.type == 2 then
			full_data[v.actv_id] = full_data[v.actv_id] or {}
			full_data[v.actv_id][v.base_id] = v
		end
	end

	for i, v in ipairs(rcvData.config_day) do
		day_config[v.actv_id] = v
	end

	for i, v in ipairs(rcvData.config_full) do
		full_config[v.actv_id] = v
	end
end

function InfoActvAchieve.sync(data)
	dump(data, "$$$ InfoActvAchieve.sync")

	if data.list then
		for i, syncData in ipairs(data.list) do
			if syncData.type == 1 then
				day_data[syncData.actv_id] = day_data[syncData.actv_id] or {}

				if not day_data[syncData.actv_id][syncData.base_id] then
					day_data[syncData.actv_id][syncData.base_id] = syncData
				else
					for k, v in pairs(syncData) do
						day_data[syncData.actv_id][syncData.base_id][k] = v
					end
				end
			elseif syncData.type == 2 then
				full_data[syncData.actv_id] = full_data[syncData.actv_id] or {}

				if not full_data[syncData.actv_id][syncData.base_id] then
					full_data[syncData.actv_id][syncData.base_id] = syncData
				else
					for k, v in pairs(syncData) do
						full_data[syncData.actv_id][syncData.base_id][k] = v
					end
				end
			end
		end
	end

	if data.config_day then
		for i, syncData in ipairs(data.config_day) do
			if not day_config[syncData.actv_id] then
				day_config[syncData.actv_id] = syncData
			else
				for k, v in pairs(syncData) do
					day_config[syncData.actv_id][k] = v
				end
			end
		end
	end

	if data.config_full then
		for i, syncData in ipairs(data.config_full) do
			if not full_config[syncData.actv_id] then
				full_config[syncData.actv_id] = syncData
			else
				for k, v in pairs(syncData) do
					full_config[syncData.actv_id][k] = v
				end
			end
		end
	end

	ManagerInfo.dataChange("actv_achieve")
	notify.dispatch("actv_redot")

	if data.list then
		for i, syncData in ipairs(data.list) do
			local base_id = syncData.base_id

			if base_id > 0 then
				local csv = CsvParser.getCsvData("actv_achieve", base_id)

				notify.dispatch("caution_push", {
					base_id = 200001,
					icon = IconManager.getActvAchieveIcon(base_id),
					sub_text = csv.name
				})
			end
		end
	end
end

function InfoActvAchieve.getReward(actv_id, actv_type, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "actv_achieve_get_reward")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("actv_achieve_get_reward", {
		actv_id = actv_id,
		actv_type = actv_type
	}, callback)
end

function InfoActvAchieve.countRedot(actv_id, actv_type)
	local redotCount = 0

	if InfoActvAchieve.rewardReady(actv_id, actv_type) then
		redotCount = redotCount + 1
	end

	return redotCount
end

function InfoActvAchieve.rewardAlready(actv_id, actv_type)
	local opening = InfoActvAchieve.checkOpening(actv_id, actv_type)

	if opening then
		local rewardData = InfoActvAchieve.getData(actv_id, actv_type, -1)

		if rewardData then
			local count = rewardData.count

			if actv_type == GameConfig.ACTV_TYPE.achieve and Time.checkDayPassed(rewardData.day_time) then
				count = 0
			end

			return count > 0
		end
	end

	return false
end

function InfoActvAchieve.rewardReady(actv_id, actv_type)
	local opening = InfoActvAchieve.checkOpening(actv_id, actv_type)

	if opening then
		local configOne = InfoActvAchieve.getConfig(actv_id, actv_type)
		local allFin = true
		local _target = configOne.target or {}

		for i, v in ipairs(_target) do
			local count = InfoActvAchieve.getCount(actv_id, actv_type, v.id)

			if count < v.num then
				allFin = false

				break
			end
		end

		if allFin and not InfoActvAchieve.rewardAlready(actv_id, actv_type) then
			return true
		end
	end

	return false
end

function InfoActvAchieve.checkOpening(actv_id, actv_type)
	local opening = InfoActv.checkBindOpening(actv_id, actv_type)

	return opening
end

function InfoActvAchieve.checkShopOpening(actv_id, actv_type)
	local opening = InfoActv.checkBindShopOpening(actv_id, actv_type)

	return opening
end

function InfoActvAchieve.getConfig(actv_id, actv_type)
	if actv_type == GameConfig.ACTV_TYPE.achieve_full then
		return full_config[actv_id] or {}
	else
		return day_config[actv_id] or {}
	end
end

function InfoActvAchieve.getTargetList(actv_id, actv_type)
	local opening = InfoActvAchieve.checkOpening(actv_id, actv_type)

	if opening then
		local configOne = InfoActvAchieve.getConfig(actv_id, actv_type)
		local arr = {}
		local _target = configOne.target or {}

		for i, v in ipairs(_target) do
			table.insert(arr, v)
		end

		table.sort(arr, function (a, b)
			return a.id < b.id
		end)

		return arr
	else
		return {}
	end
end

function InfoActvAchieve.getAwardList(actv_id, actv_type)
	local opening = InfoActvAchieve.checkOpening(actv_id, actv_type)

	if opening then
		local configOne = InfoActvAchieve.getConfig(actv_id, actv_type)

		return configOne.award or {}
	else
		return {}
	end
end

function InfoActvAchieve.getData(actv_id, actv_type, base_id)
	local dataMap = nil

	if actv_type == GameConfig.ACTV_TYPE.achieve_full then
		dataMap = full_data
	else
		dataMap = day_data
	end

	if dataMap and dataMap[actv_id] and dataMap[actv_id][base_id] then
		return dataMap[actv_id][base_id]
	end
end

function InfoActvAchieve.getCount(actv_id, actv_type, base_id)
	local opening = InfoActvAchieve.checkOpening(actv_id, actv_type)

	if opening then
		local data = InfoActvAchieve.getData(actv_id, actv_type, base_id)

		if data then
			local count = data.count

			if actv_type == GameConfig.ACTV_TYPE.achieve and Time.checkDayPassed(data.day_time) then
				count = 0
			end

			return count
		end
	end

	return 0
end

return InfoActvAchieve
