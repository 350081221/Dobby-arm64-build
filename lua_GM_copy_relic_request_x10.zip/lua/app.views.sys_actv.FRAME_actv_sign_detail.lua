local UI_base = import("..UI_base")
local FRAME_actv_sign_detail = class("FRAME_actv_sign_detail", UI_base)

function FRAME_actv_sign_detail.open(itemInfo, costItem, day, actv_id)
	local ui = FRAME_actv_sign_detail.new(itemInfo, costItem, day, actv_id)

	PopManager.open(ui)
end

function FRAME_actv_sign_detail:ctor(itemInfo, costItem, day, actv_id)
	self.itemInfo = itemInfo
	self.costItem = costItem
	self.day = day
	self.actv_id = actv_id

	FRAME_actv_sign_detail.super.ctor(self, "frame_sign_detail", UIManager.BIG_TYPE.POP)
	self:init()
end

function FRAME_actv_sign_detail:init()
	self:initUI()
end

function FRAME_actv_sign_detail:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	self.costList = self:createListOnFlag("flag_cost", CostListH)

	self.costList:setItems({
		self.costItem
	})

	local itemInfo = self.itemInfo
	local name, style = InfoItem.getNameDisplay(itemInfo)
	local label = self:createLabelOnFlag("flag_name", name, style)
	local descFlag = self:getFlagByTag("flag_desc")
	local flag_unique = self:getFlagByTag("flag_unique")
	local unique_bg = self:getComponentByTag("unique_bg")
	local uniqueBGY = 0
	local listSpace = 0
	local itemData = CsvParser.getCsvData("item", itemInfo.base_id)

	if not empty(itemData.unique_desc) then
		unique_bg:setVisible(true)

		local label, labelWidth, labelHeight = self:createLabelOnFlag("flag_unique", itemData.unique_desc, {
			wrap = true,
			valign = Style.vbottom
		})

		unique_bg:setPos(nil, unique_bg.originalY + uniqueBGY)
		unique_bg:setSize(nil, unique_bg.originalHeight + labelHeight - 20)

		listSpace = listSpace + labelHeight + 20
	else
		unique_bg:setVisible(false)
	end

	descFlag.height = descFlag.height - listSpace
	descFlag.y = descFlag.originalY + listSpace
	self.slot = DropSlot.new(self:getFlagByTag("flag_icon"), "slot_01")

	self:addChild(self.slot, 100)

	local function tapListener(ui, data, index, x, y)
		if ui.slots then
			local worldPos = self.textArea:convertToWorldSpace(cc.p(x, y))

			for i, slot in ipairs(ui.slots) do
				if slot:hitTestByComponent("bg", worldPos.x, worldPos.y, true) then
					if slot.type == DropManager.TYPE.CARD then
						FRAME_card.openPreview(slot.info)

						break
					end

					if slot.type == DropManager.TYPE.ITEM then
						local x, y = slot:getPosition()
						local pos = ui:convertToWorldSpace(cc.p(x, y))

						FRAME_item_mini.open(cc.rect(pos.x, pos.y, slot.width, slot.height), slot.info)

						break
					end

					DropManager.popDetail(slot.type, slot.info)

					break
				end
			end
		end
	end

	local textArea = self:createListOnFlag("flag_desc", function (rect)
		return LIST_item_detail.new(rect, self:getStyleByTag("flag_desc"))
	end, tapListener)

	textArea:setSpace(10, 10)

	self.textArea = textArea

	self.slot:setDrop(DropManager.TYPE.ITEM, itemInfo)

	local items, hasDrop = FRAME_item_detail.getDesc(itemData, self.textArea)

	self.textArea:setItems(items, true)

	local bt_get = self:getComponentByTag("bt_get")

	bt_get:toTouchable()
	bt_get:addTap(function ()
		local costArr = self.costList.items

		if not InfoItem.checkCost(costArr) then
			Alert.open(Localization.getSrcText("消耗物品不足"))

			return
		end

		InfoActvRecord.getReward(self.day, self.actv_id, true, function (rcvData)
			local rewards = rcvData.rewards

			if rewards and #rewards > 0 then
				POP_reward.openMixed(rewards, function ()
					PopManager.closeTo(self)
				end, Localization.getSrcText("签到奖励"))
			end
		end)
	end)
	bt_get:setTapGroup("button_click")
end

return FRAME_actv_sign_detail
