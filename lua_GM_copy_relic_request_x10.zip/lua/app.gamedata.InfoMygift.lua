local InfoMygift = {}
local rawData = {}

function InfoMygift.init()
	Connection.listen("mygift_sync", InfoMygift.sync)
end

app:addToAppEnterCall(InfoMygift.init)

function InfoMygift.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoMygift.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("mygift_query", callback)
end

function InfoMygift.onQuery(rcvData)
	dump(rcvData, "mygift_query")

	rawData = {}

	for i, v in ipairs(rcvData.list) do
		rawData[v.id] = v
	end
end

function InfoMygift.sync(data)
	dump(data, "$$$ InfoMygift.sync")

	if data.is_all == 1 then
		rawData = {}

		for i, data in ipairs(data.list) do
			rawData[data.id] = data
		end
	else
		for i, data in ipairs(data.list) do
			if not rawData[data.id] then
				rawData[data.id] = data
			else
				for k, v in pairs(data) do
					rawData[data.id][k] = v
				end
			end
		end
	end

	ManagerInfo.dataChange("mygift")
end

function InfoMygift.checkIgnore(id)
	local data = rawData[id]

	if data and data.ignore_time then
		local day = Time.getDay(data.ignore_time or 0)
		local nowDay = Time.getDay()

		print("$$$ checkIgnore", day, nowDay)

		return nowDay < day + 7
	end
end

function InfoMygift.setIgnore(id)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("mygift_set_ignore", {
		id = id
	}, callback)
end

function InfoMygift.get(id)
	return rawData[id]
end

function InfoMygift.getTabList()
	local arr = {}
	local nowTime = Time.now()

	for k, v in pairs(rawData) do
		if v.close ~= 1 and v.stime <= nowTime and nowTime < v.etime then
			table.insert(arr, v)
		end
	end

	local abyssLevel = InfoDungeon.getAbyssMaxLevel()

	table.sort(arr, function (a, b)
		local limitA = (empty(a.limit_level) or a.limit_level <= abyssLevel) and 1 or 0
		local limitB = (empty(b.limit_level) or b.limit_level <= abyssLevel) and 1 or 0

		if limitA == limitB then
			return a.id < b.id
		else
			return limitB < limitA
		end
	end)

	return arr
end

function InfoMygift.getJumpList()
	local arr = {}
	local nowTime = Time.now()
	local abyssLevel = InfoDungeon.getAbyssMaxLevel()

	for k, v in pairs(rawData) do
		if v.close ~= 1 and v.limit_level <= abyssLevel and v.jump == 1 and v.stime <= nowTime and nowTime < v.etime and (v.buy_limit == 0 or v.buy_count < v.buy_limit) then
			table.insert(arr, v)
		end
	end

	table.sort(arr, function (a, b)
		return b.id < a.id
	end)

	return arr
end

return InfoMygift
