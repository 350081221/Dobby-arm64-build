local Npc = class("Npc", Unit)
Npc.instanceMap = {}
Npc.petInstanceMap = {}
Npc.gatherInstanceMap = {}
Npc.shrineInstanceMap = {}
Npc.chanceInstanceMap = {}
Npc.doorInstanceMap = {}
Npc.deviceInstanceMap = {}
Npc.heroTempleteInstanceMap = {}
local TYPE = {
	HERO_TEMPLETE = 10,
	DEVICE = 8,
	CHANCE = 7,
	DOOR = 6,
	SHRINE = 5,
	RELIC = 4,
	GATHER = 3,
	PET = 2,
	NPC = 1,
	MOONCARD_CHEST = 11
}
Npc.TYPE = TYPE
local RELIC_TYPE = {
	GAP = 2,
	BLOOD = 1,
	TROPHY = 9
}
Npc.RELIC_TYPE = RELIC_TYPE

local gmRelicCopyRequestMap = {}

local function requestGMCopyTrophyRelic(eventIndex, relicIndex)
	if not GM then
		return
	end

	local mapIndex = InfoDungeon.getMapIndex()
	local key = tostring(mapIndex) .. "_" .. tostring(eventIndex) .. "_" .. tostring(relicIndex)

	if gmRelicCopyRequestMap[key] then
		return
	end

	local itemID = nil
	local bagIndex = nil	
	local rawBag = InfoBag.getRaw()

	for _bagIndex, bagData in pairs(rawBag) do
		if bagData.type == DropManager.TYPE.ITEM and not empty(bagData.item_id) then
			local itemData = CsvParser.getCsvData("item", bagData.item_id)

			if itemData and itemData.use_type == 26 then
				itemID = bagData.item_id
				bagIndex = _bagIndex

				break
			end
		end
	end

	if not itemID or not bagIndex then
		return
	end

	gmRelicCopyRequestMap[key] = true

	local params = {
		mIdx = mapIndex,
		eIdx = eventIndex,
		rIdx = relicIndex
	}

	for i = 1, 10 do
		Looper.setTimeout(function ()
			InfoItem.use(itemID, 1, bagIndex, nil, function ()
			end, nil, params)
		end, i * 2, global.map)
	end
end

function Npc.getByEvent(eventIndex)
	local unitList = ClipOnMap.getUnitList("npc")

	for _, unit in ipairs(unitList) do
		if unit.eventData and unit.eventData.index == eventIndex then
			return unit
		end
	end
end

function Npc.addToInstanceMap(baseID, unit)
	Npc.instanceMap[tostring(baseID)] = unit
end

function Npc.removeFromInstanceMap(baseID)
	Npc.instanceMap[tostring(baseID)] = nil
end

function Npc.getInstance(baseID)
	return Npc.instanceMap[tostring(baseID)]
end

function Npc.addToPetMap(baseID, unit)
	Npc.petInstanceMap[tostring(baseID)] = unit
end

function Npc.removeFromPetMap(baseID)
	Npc.petInstanceMap[tostring(baseID)] = nil
end

function Npc.getPet(baseID)
	return Npc.petInstanceMap[tostring(baseID)]
end

function Npc.addToGatherMap(baseID, unit)
	Npc.gatherInstanceMap[tostring(baseID)] = unit
end

function Npc.removeFromGatherMap(baseID)
	Npc.gatherInstanceMap[tostring(baseID)] = nil
end

function Npc.getGather(baseID)
	return Npc.gatherInstanceMap[tostring(baseID)]
end

function Npc.addToShrineMap(baseID, unit)
	Npc.shrineInstanceMap[tostring(baseID)] = unit
end

function Npc.removeFromShrineMap(baseID)
	Npc.shrineInstanceMap[tostring(baseID)] = nil
end

function Npc.getShrine(baseID)
	return Npc.shrineInstanceMap[tostring(baseID)]
end

function Npc.addToChanceMap(baseID, unit)
	Npc.chanceInstanceMap[tostring(baseID)] = unit
end

function Npc.removeFromChanceMap(baseID)
	Npc.chanceInstanceMap[tostring(baseID)] = nil
end

function Npc.getChance(baseID)
	return Npc.chanceInstanceMap[tostring(baseID)]
end

function Npc.addToDoorMap(baseID, unit)
	Npc.doorInstanceMap[tostring(baseID)] = unit
end

function Npc.removeFromDoorMap(baseID)
	Npc.doorInstanceMap[tostring(baseID)] = nil
end

function Npc.getDoor(baseID)
	return Npc.doorInstanceMap[tostring(baseID)]
end

function Npc.addToDeviceMap(baseID, unit)
	Npc.deviceInstanceMap[tostring(baseID)] = unit
end

function Npc.removeFromDeviceMap(baseID)
	Npc.deviceInstanceMap[tostring(baseID)] = nil
end

function Npc.getDevice(baseID)
	return Npc.deviceInstanceMap[tostring(baseID)]
end

function Npc.addToHeroTempleteMap(baseID, unit)
	Npc.petInstanceMap[tostring(baseID)] = unit
end

function Npc.removeFromHeroTempleteMap(baseID)
	Npc.petInstanceMap[tostring(baseID)] = nil
end

function Npc.getHeroTemplete(baseID)
	return Npc.petInstanceMap[tostring(baseID)]
end

function Npc:ctor()
	Npc.super.ctor(self, "npc")

	self.alwaysVisible = true
	self.priority = 0
end

function Npc:refreshEventset()
	if self.eventsetArr then
		for i, v in ipairs(self.eventsetArr) do
			if v ~= self then
				v:refreshOpened()
			end
		end
	end
end

function Npc:setShrineID(id, eventData)
	self.npcType = TYPE.SHRINE
	self.baseID = id
	self.eventData = eventData

	Npc.addToShrineMap(self.baseID, self)

	local shrineData = CsvParser.getCsvData("shrine", id)

	assert(shrineData, "shrine miss id:" .. id)
	self:setData(shrineData)

	if shrineData.class == 1 then
		if InfoGuide.getFreeRecord(4) == 0 then
			self.checkGuideFree = InfoGuide.guideFree(4, self, function ()
				self.checkGuideFree = nil
			end, self)
		end
	elseif shrineData.class == 2 and InfoGuide.getFreeRecord(21) == 0 then
		self.checkGuideFree = InfoGuide.guideFree(21, self, function ()
			self.checkGuideFree = nil
		end, self)
	end
end

function Npc:openShrine(eventsetIndex)
	local eventIndex = self.eventData.index

	local function onGatherGet(rcvData)
		global.player:onNpcDisable(self)
		self:refreshOpened(true)
		self:refreshEventset()
		self:shrineEffect()
	end

	InfoDungeon.getShrine(eventIndex, eventsetIndex, onGatherGet)
end

function Npc:stopShrine()
	self:stopRead()
end

function Npc:shrineEffect()
	if self.data.type == 101 then
		GuideManager.setModaoHidden(false)
		GuideManager.startGuideModao()
	end
end

function Npc:setChanceID(id, eventData)
	self.npcType = TYPE.CHANCE
	self.baseID = id
	self.eventData = eventData

	Npc.addToChanceMap(self.baseID, self)

	local chanceData = CsvParser.getCsvData("chance", id)

	assert(chanceData, "chance miss id:" .. id)
	self:setData(chanceData)

	if not empty(chanceData.action) then
		self:setFixedAction(chanceData.action)
	end

	if chanceData.no_turn == 1 then
		self:setFixedAngle(math.random(1, 360))
	end

	if self.data.type == 7 then
		if InfoGuide.getFreeRecord(15) == 0 then
			self.checkGuideFree = InfoGuide.guideFree(15, self, function ()
				self.checkGuideFree = nil
			end, self)
		end
	elseif self.data.type == 11 then
		-- Nothing
	elseif self.data.type ~= 13 then
		if self.data.type == 14 then
			-- Nothing
		elseif self.data.type == 1 then
			if InfoGuide.getFreeRecord(16) == 0 then
				self.checkGuideFree = InfoGuide.guideFree(16, self, function ()
					self.checkGuideFree = nil
				end, self)
			end
		elseif self.data.id == 10007 and InfoGuide.getFreeRecord(17) == 0 then
			self.checkGuideFree = InfoGuide.guideFree(17, self, function ()
				self.checkGuideFree = nil
			end, self)
		end
	end
end

function Npc:isGladiator()
	if self.npcType == TYPE.CHANCE and self.data.type == 11 then
		return true
	end
end

function Npc:refreshGladiator(animated)
	local eventData = self.eventData
	local eventIndex = eventData.index
	local eventInfo = InfoDungeon.getEventInfo(eventData.index)
	local gladiatorCSV = CacheData.chance_getGladiator(self.baseID, eventInfo.fin)

	self:clearEffect()

	local isBlock = true

	if GameConfig.gladiator_max < eventInfo.fin then
		local finalRelic = InfoDungeon.getFinalRelic(eventIndex)

		if not finalRelic or finalRelic.fin ~= 0 then
			self:setAction("idle")

			isBlock = false
		else
			self:setAction("opened")
		end
	elseif eventInfo.fin == 0 then
		self:setAction("idle")

		if empty(gladiatorCSV.model) then
			isBlock = false
		end
	else
		self:setAction("open")
	end

	self.isBlock = isBlock

	if isBlock and not empty(gladiatorCSV.model) then
		self:addLastingEffect(gladiatorCSV.model)
	end
end

function Npc:checkChance()
	return NavUtil.checkChance(self)
end

function Npc:openChance()
	NavUtil.openChance(self)
end

local stageDialogGroups = nil

function Npc:getStageDialog(group, stageIndex)
	if not stageDialogGroups then
		stageDialogGroups = {}
		local csvRaw = CsvParser.getCsvRaw("stage_dialog")

		for k, v in pairs(csvRaw) do
			if not stageDialogGroups[v.group] then
				stageDialogGroups[v.group] = {}
			end

			stageDialogGroups[v.group][v.stage_index] = v.dialog
		end
	end

	return stageDialogGroups[group][stageIndex]
end

function Npc:setDoorID(id, eventData)
	self.npcType = TYPE.DOOR
	self.baseID = id
	self.eventData = eventData
	self.noFillTile = true

	Npc.addToDoorMap(self.baseID, self)

	local doorData = CsvParser.getCsvData("door", id)

	assert(doorData, "door miss id:" .. id)
	self:setData(doorData)
	self:refreshOpened()
end

function Npc:setDeviceID(id, eventData)
	self.npcType = TYPE.DEVICE
	self.baseID = id
	self.eventData = eventData

	Npc.addToDeviceMap(self.baseID, self)

	local deviceData = CsvParser.getCsvData("device", id)
	self.noFocusToPlayer = true

	self:setData(deviceData)
end

function Npc:setPetID(id)
	self.npcType = TYPE.PET
	self.baseID = id

	Npc.addToPetMap(self.baseID, self)

	local petData = CsvParser.getCsvData("pet", id)

	assert(petData, "pet miss id:" .. id)
	self:setData(petData)
end

function Npc:setHeroTempleteID(id, eventData)
	local eventInfo = ConfParser.parse(eventData.info)
	self.npcType = TYPE.HERO_TEMPLETE
	self.baseID = id
	self.eventData = eventData

	Npc.addToHeroTempleteMap(self.baseID, self)

	local random = Random.new(eventData.seed)
	local templeteData = CsvParser.getCsvData("hero_templete", id)
	local heroInfo = {
		quality = SheetUtil.getNumber(templeteData.quality, random),
		base_id = SheetUtil.getString(templeteData.base_id, random),
		gender = SheetUtil.getString(templeteData.gender, random),
		body = SheetUtil.getString(templeteData.body, random),
		hair = SheetUtil.getString(templeteData.hair, random),
		affix = SheetUtil.getString(templeteData.affix, random)
	}
	local heroData = CsvParser.getCsvData("hero", heroInfo.base_id, true)

	assert(heroData, "hero miss id:" .. id)

	local genderCode = {
		"male",
		"female"
	}

	for i = 1, 5 do
		heroData["avatar_" .. i] = StringUtil.replaceTag(heroData["avatar_" .. i], {
			gender = genderCode[tonumber(heroInfo.gender) + 1]
		})
	end

	heroData.model = heroInfo.body
	heroData.avatar_1 = heroInfo.hair
	heroData.name = eventInfo.name
	heroData.dialog = eventInfo.dialog

	self:setData(heroData)
	self:refreshHeroTemplete()
end

function Npc:setID(id, eventData, noAddInstance)
	self.npcType = TYPE.NPC
	self.baseID = id
	self.noAddInstance = noAddInstance
	self.eventData = eventData

	if not self.noAddInstance then
		Npc.addToInstanceMap(self.baseID, self)
	end

	local npcData = CsvParser.getCsvData("npc", id)

	assert(npcData, "npc miss id:" .. id)
	self:setData(npcData)

	if not empty(npcData.building) or not empty(npcData.building0) or not empty(npcData.building_hide_0) or not empty(npcData.building_hide_1) then
		if not empty(npcData.building) then
			self.buildingTag = npcData.building
		elseif not empty(npcData.building0) then
			self.buildingTag = npcData.building0
		elseif not empty(npcData.building_hide_0) then
			self.buildingTag = npcData.building_hide_0
		elseif not empty(npcData.building_hide_1) then
			self.buildingTag = npcData.building_hide_1
		end

		self:refreshBuilding()
		notify.safeRegister(self, "building_set_level", function (tag)
			if tag == npcData.building or tag == npcData.building0 or tag == npcData.building_hide_0 or tag == npcData.building_hide_1 then
				self:refreshBuilding()
			end
		end)
		notify.safeRegister(self, "building_levelup", function (tag)
			if tag == npcData.building or tag == npcData.building0 or tag == npcData.building_hide_0 or tag == npcData.building_hide_1 then
				self:refreshBuilding(true)
			end
		end)
	end

	if self.data.building == InfoBuilding.TAG.MERCHANT and InfoGuide.getFreeRecord(11) == 0 then
		self.checkGuideFree = InfoGuide.guideFree(11, self, function ()
			self.checkGuideFree = nil
		end, self, 10)
	end
end

function Npc:refreshTaskAndFestival()
	local taskData = InfoTaskQuest.getDataForNPC(self.baseID)

	if taskData then
		local taskCSV = CsvParser.getCsvData("task", taskData.base_id)
		local effectType = 1

		if taskCSV.type == 4 then
			effectType = 3
		elseif taskCSV.type == 3 then
			effectType = 2
		end

		local effectName = nil

		if taskData.fin == 0 then
			effectName = "quest_" .. effectType .. "_2"
		elseif taskData.fin == 1 then
			effectName = "quest_" .. effectType .. "_1"
		end

		if effectName then
			self:addLastingEffect(effectName)
		end
	end

	local festivalData = InfoFestival.getDataForNPC(self.baseID)

	if self.data.hidden == 1 then
		self:setHidden("no_TaskAndFestival", taskData == nil and festivalData == nil)
	end
end

function Npc:removeTask()
	self:removeLastingEffect("quest_1_1")
	self:removeLastingEffect("quest_1_2")
	self:removeLastingEffect("quest_2_1")
	self:removeLastingEffect("quest_2_2")
	self:removeLastingEffect("quest_3_1")
	self:removeLastingEffect("quest_3_2")
end

function Npc:refreshFarmTile(animated)
	self.blockLocked = true
	self.isBlock = false
	self.farmInfo = nil
	local needLoop = self:refreshFarmTileLoop(animated)

	if needLoop then
		MapFrameManager.startLoop(self, self.refreshFarmTileLoop)
	end
end

function Npc:refreshFarmTileLoop(animated)
	if type(animated) == "number" then
		local total = InfoFarm.countTiles()
		total = math.max(total, 1)
		local frame = animated

		if not self.nextLoopFrame or self.nextLoopFrame < frame then
			local interval = 1
			self.nextLoopFrame = (math.ceil(frame / interval / total) + self.farmPos) * total * interval
		else
			return
		end
	end

	local farmInfo, farmSeed, index, tileSeed = InfoFarm.getTileInfo(self.farmPos)

	if farmInfo == nil then
		return
	end

	if farmInfo.ready then
		self:setAction("ready")
	else
		self:setAction("idle")

		return
	end

	local needLoop = false

	if self.farmInfo then
		if not farmInfo.ready or farmInfo.isHarvest then
			MapFrameManager.stopLoop(self, self.refreshFarmTileLoop)
		end

		if ObjUtil.compare(self.farmInfo, farmInfo) then
			return
		end
	else
		if farmSeed == 0 then
			return
		end

		if farmInfo.ready and not farmInfo.isHarvest then
			needLoop = true
		end
	end

	local farm_seed_csv = CsvParser.getCsvData("farm_seed", farmSeed)
	local farmRanID = SheetUtil.getString(farm_seed_csv.ran, Random.new(tileSeed))
	local farmCsv = CsvParser.getCsvData("farm_seed", farmRanID)
	local farmModel = farmCsv.seed_pic
	local isNew = not self.isHarvest

	if self.isHarvest and not farmInfo.isHarvest and animated == true then
		local effect = self:addEffect(MiscConfig.farm_model, true)
		local skeleton = effect.skeletons[1]

		skeleton:setAttachment("shuidao", farmModel)
		effect:setAction("idle2")

		local time, harvestNum = InfoFarm.getHarvestResult(self.farmPos)
		local timeDelay = time - Time.time()

		local function harvestAnim()
			Sound.playSound(MiscConfig.sfx_harvest)
			effect:setAction("shouge", 1, function ()
				self:removeEffect(MiscConfig.farm_model)
			end)

			if harvestNum and global.ui and global.ui.flyCoins then
				local customPic = IconManager.getMiscFarm(farmModel)
				local items = {
					{
						type = DropManager.TYPE.ITEM,
						customPic = customPic,
						info = {
							base_id = GameConfig.farm_item,
							num = harvestNum
						}
					}
				}

				if not empty(farmCsv.food_item) then
					table.insert(items, {
						type = DropManager.TYPE.ITEM,
						info = {
							num = 1,
							base_id = farmCsv.food_item
						}
					})
				end

				global.ui:flyCoins(cc.p(self.x, self.y), items)
			end
		end

		if timeDelay > 0 then
			effect:performWithDelay(harvestAnim, timeDelay)
		else
			harvestAnim()
		end
	end

	self.isHarvest = farmInfo.isHarvest

	self:removeLastingEffect(MiscConfig.farm_model)

	if not empty(farmModel) then
		local effect = self:addLastingEffect(MiscConfig.farm_model)
		local skeleton = effect.skeletons[1]

		skeleton:setAttachment("shuidao", farmModel)

		if farmInfo.isHarvest then
			if isNew then
				if animated ~= false then
					effect:setAction("zhangcheng", 1, function ()
						effect:setAction("idle2")
					end)
				else
					effect:setAction("idle2")
				end
			else
				effect:setAction("idle2")
			end
		else
			effect:setAction("idle")
		end
	end

	self.farmInfo = farmInfo

	return needLoop
end

function Npc:refreshHatch(animated)
	local hatchData = InfoPetHatch.getByPos(self.hatchPos)

	self:clearEffect()
	self:setGatherHudVisible(false)
	MapFrameManager.stopLoop(self, self.refreshHatchProgress)

	if not hatchData then
		self:setAction("lock")

		self.hatchState = 0
	elseif empty(hatchData.base_id) then
		if animated then
			if self.hatchState == 2 then
				local function startAnimation()
					self:setAction("open", 1, function ()
						self:setAction("empty")
					end)
					Looper.setTimeout(function ()
						POP_mask.openFlash(self)
					end, 30, self)
				end

				MapUtils.focusIn(self, startAnimation, 20, 1.4)
				Looper.setTimeout(function ()
					local petInfo = InfoPet.getPet(global.perHatchID)

					POP_pet_born.open(petInfo, onClose)
				end, 120, self)
				Looper.setTimeout(function ()
					MapUtils.focusOut(self, nil, 120)
				end, 90, self)
			else
				local effect = self:addEffect("@building")

				effect:setScale(0.6)
				Looper.setTimeout(function ()
					self:setAction("empty")
				end, 60, self)
			end
		else
			self:setAction("empty")
		end

		self.hatchState = 1
	else
		local function showEggQuality()
			local petCSV = CsvParser.getCsvData("pet", hatchData.base_id)

			if self.skeletons then
				local skeleton = self.skeletons[1]

				skeleton:setAttachment("egg1", petCSV.egg_model)
			end
		end

		if animated then
			if self.hatchState == 1 then
				self:setAction("start", 1, function ()
					self:setAction("idle")
					showEggQuality()
				end)
				showEggQuality()
			elseif self.hatchState == 2 then
				self:setAction("jiasu", 1, function ()
					self:setAction("idle")
				end)
			end
		else
			self:setAction("idle")
			showEggQuality()
		end

		self:setGatherHudVisible(true)
		self:refreshHatchProgress()
		MapFrameManager.startLoop(self, self.refreshHatchProgress)

		self.hatchState = 2
	end
end

function Npc:refreshHatchProgress()
	local per = InfoPetHatch.getHatchTime(self.hatchPos)

	self:hudSetGather(per)
end

function Npc:setData(data)
	Npc.super.setData(self, data)
	self:updateAvatar()

	self.warn = data.warn

	if data.no_block == 1 then
		self.blockLocked = true
		self.isBlock = false
	end

	if self.data.warn_fadein == 1 then
		local effectGen = self:getEffectGen()

		if effectGen then
			effectGen:fadeTo(0, 0)
		end
	end
end

function Npc:wake()
	if self.waking ~= true then
		self.waking = true

		self:waitForPatrol(true)
	end
end

function Npc:sleep()
	if self.waking then
		self.waking = false

		self:stopPatrolWaiting()
	end
end

function Npc:setHidden(tag, hidden)
	Npc.super.setHidden(self, tag, hidden)
	self:refreshBlock()
end

function Npc:refreshBlock()
	if self.blockLocked then
		return
	end

	local isBlock = true

	if self:isHidden() then
		isBlock = false
	end

	if self.npcType == TYPE.RELIC then
		if self.data.auto_pick == 1 then
			isBlock = false
		end
	elseif self.npcType == TYPE.DOOR then
		isBlock = false
	end

	self.isBlock = isBlock
end

function Npc:stop(code)
	Npc.super.stop(self, code)

	if self.map.isBattle then
		return
	end

	self:waitForPatrol()
end

function Npc:removeFromMap()
	if self.tile and self.warn then
		local listenRange = self.warn

		if self.tile then
			for i = self.tile.x - listenRange, self.tile.x + listenRange do
				for j = self.tile.y - listenRange, self.tile.y + listenRange do
					self:unlistenTile(i, j)
				end
			end
		end
	end

	Npc.super.removeFromMap(self)
end

function Npc:retile()
	local preTile = self.tile

	Npc.super.retile(self)

	local tile = self.tile

	if tile == preTile then
		return
	end

	if not empty(self.warn) then
		local listenRange = self.warn
		local refresh = true

		if preTile ~= nil then
			refresh = false
			local dirtyX = preTile.x - tile.x
			local dirtyY = preTile.y - tile.y
			local minX = preTile.x - listenRange
			local maxX = preTile.x + listenRange
			local minY = preTile.y - listenRange
			local maxY = preTile.y + listenRange

			MapUtils.dirtyRect(dirtyX, dirtyY, minX, maxX, minY, maxY, handler(self, self.unlistenTile), refresh)
		end

		local dirtyX, dirtyY = nil

		if not refresh then
			dirtyX = tile.x - preTile.x
			dirtyY = tile.y - preTile.y
		end

		local minX = tile.x - listenRange
		local maxX = tile.x + listenRange
		local minY = tile.y - listenRange
		local maxY = tile.y + listenRange

		MapUtils.dirtyRect(dirtyX, dirtyY, minX, maxX, minY, maxY, handler(self, self.listenTile), refresh)
	end

	if self.tile:getVisible() then
		self:wake()
	else
		self:sleep()
	end
end

function Npc:listenTile(x, y)
	local tile = self.map:getTile(x, y)

	if tile then
		tile:addUnitChangeListener(self, self.onTileUnitChanged)
	end
end

function Npc:unlistenTile(x, y)
	local tile = self.map:getTile(x, y)

	if tile then
		tile:removeUnitChangeListener(self, self.onTileUnitChanged)
	end
end

function Npc:onTileUnitChanged(unit, addOrRemove)
	if self.map.isBattle then
		return
	end

	if unit.type == "hero" then
		if addOrRemove then
			if self.data.warn_fadein == 1 then
				local effectGen = self:getEffectGen()

				if effectGen then
					effectGen:fadeTo(15, 255)
				end
			end

			if not empty(self.data.warn_action) then
				self:setAction(self.data.warn_action, 1, function ()
					self:setAction("idle")
				end)
			end

			if not empty(self.data.warn_flee) then
				self:patrol(self.data.warn_flee, {
					unit
				})
			end

			if not self:isSaying() and not empty(self.data.whisper) then
				local whisperStr = SheetUtil.getString(self.data.whisper)

				if not empty(whisperStr) then
					self:say(whisperStr, 60)
				end
			end
		elseif self.data.warn_fadein == 1 then
			local effectGen = self:getEffectGen()

			if effectGen then
				effectGen:fadeTo(15, 0)
			end
		end
	end
end

function Npc:display(map, x, y)
	Npc.super.display(self, map, x, y)

	if self.npcType == TYPE.NPC then
		self:refreshBuilding()

		if self.data.building == InfoBuilding.TAG.PET_HATCH then
			local info = ConfParser.parse(self.eventData.info)
			self.hatchPos = info.pos

			self:refreshHatch()
			ManagerInfo.onDataChange(self, "pet_hatch", nil, function (idStack, posMap)
				if posMap[self.hatchPos] then
					self:refreshHatch(true)
				end
			end)
		elseif self.data.building == InfoBuilding.TAG.FARM_TILE then
			local info = ConfParser.parse(self.eventData.info)
			self.farmPos = info.pos

			self:refreshFarmTile(false)
			ManagerInfo.onDataChange(self, "farm", nil, function (idStack, posMap)
				self:refreshFarmTile(true)
			end)
		end

		self:refreshTaskAndFestival()
	end

	if self.npcType == TYPE.SHRINE and self.skeletons then
		local skeleton = self.skeletons[1]

		if self.spineName == "shenkan" then
			local qualityAffix = {
				"_g",
				"_b",
				"_p",
				"_o",
				""
			}
			local lightSlots = {
				{
					"light7",
					"light1"
				},
				{
					"light6",
					"light1"
				},
				{
					"light1",
					"light1"
				},
				{
					"light8",
					"light1"
				},
				{
					"light4",
					"light1"
				},
				{
					"light5",
					"light1"
				},
				{
					"light3",
					"light3"
				},
				{
					"light9",
					"light5"
				},
				{
					"light13",
					"light5"
				},
				{
					"light10",
					"light5"
				},
				{
					"light12",
					"light5"
				},
				{
					"light11",
					"light5"
				}
			}
			local affix = qualityAffix[self.data.quality]

			if not empty(self.data.buff_icon) then
				skeleton:setAttachment("gongji", self.data.buff_icon .. affix)
			end

			for i, arr in ipairs(lightSlots) do
				skeleton:setAttachment(arr[1], arr[2] .. affix)
			end
		elseif self.spineName == "shenkan2" then
			local qualityAffix = {
				"_g",
				"_b",
				"_p",
				"_o",
				""
			}
			local lightSlots = {
				{
					"light7",
					"light1"
				},
				{
					"light6",
					"light1"
				},
				{
					"light1",
					"light1"
				},
				{
					"light8",
					"light1"
				},
				{
					"light4",
					"light1"
				},
				{
					"light5",
					"light1"
				},
				{
					"light3",
					"light3"
				},
				{
					"light9",
					"light5"
				},
				{
					"light13",
					"light5"
				},
				{
					"light10",
					"light5"
				},
				{
					"light12",
					"light5"
				},
				{
					"light11",
					"light5"
				}
			}
			local affix = qualityAffix[self.data.quality]

			if not empty(self.data.buff_icon) then
				skeleton:setAttachment("gongji", self.data.buff_icon .. affix)
			end

			for i, arr in ipairs(lightSlots) do
				skeleton:setAttachment(arr[1], arr[2] .. affix)
			end
		end
	end

	if self.npcType == TYPE.CHANCE then
		if self.data.type == 11 then
			MapUtils.setRelicDisable(map, self.tile, 1)
		elseif self.data.type == 17 and self:isInteractive() and not self.runeItem then
			local scale = self.data.scale * 0.8
			local height = 100 + 25 * scale
			local dropItem = DropItem.new()

			dropItem:setDrop({
				type = DropManager.TYPE.ITEM,
				info = {
					num = 1,
					base_id = self.data.value1
				}
			})
			dropItem:setScale(scale)

			dropItem.zorderOffset = 1
			dropItem.getLocked = true

			dropItem:display(map, self.x, self.y)

			local effectGen = dropItem:getEffectGen()

			if effectGen then
				effectGen:float(3, 120, 5, height)
			end

			self.runeItem = dropItem
		end
	end

	if self.eventData then
		self:refreshOpened()
	end

	if self.checkGuideFree then
		self.checkGuideFree()
	end
end

function Npc:focusTo(player, fromDrama)
	if self.npcType == TYPE.GATHER or self.npcType == TYPE.RELIC then
		return
	end

	if self.noFocusToPlayer then
		return
	end

	self:stop(26)
	self:stopPatrolWaiting()

	local function faceToLoop()
		if not self.fixedAngle then
			if self.faceToTile then
				self:faceToTile(player.tile)
			end
		else
			self.angle = self.fixedAngle
		end
	end

	self.focusUnit = player
	self.focusHandler = player:addEventListener("retile", faceToLoop)

	faceToLoop()
end

function Npc:setNoFocusToPlayer(b)
	self.noFocusToPlayer = b
end

function Npc:setFreeAngle(angle)
	self.freeAngle = angle * math.pi / 180
	self.angle = self.freeAngle

	self:refreshSpineScale()
end

function Npc:setFixedAngle(angle)
	self.fixedAngle = angle * math.pi / 180
	self.angle = self.fixedAngle

	self:refreshSpineScale()
end

function Npc:focusRelease()
	if self.npcType == TYPE.GATHER then
		return
	end

	if self.patrolData and self.patrolData.area then
		self:waitForPatrol(true)
	elseif self.freeAngle then
		self.angle = self.freeAngle
	end

	if self.focusUnit then
		self.focusUnit:removeEventListener("retile", self.focusHandler)
	end
end

function Npc:onNear()
	if not self.nearEffect_already then
		self.nearEffect_already = true
		local nearEffect = self.data.near_effect

		if not empty(nearEffect) then
			local effectGen = self:getEffectGen()

			if effectGen then
				effectGen:castEffect(nearEffect, self)
			end
		end
	end

	if self.costIcon then
		transition.stopTarget(self.costIcon)

		local costIcon = self.costIcon

		costIcon:setScale(0.5)
		Style.beatup(costIcon, costIcon.initY, function ()
			costIcon:setPositionY(costIcon.initY)
			Style.makeFloat(costIcon)
		end)
	end
end

function Npc:refreshCost()
	local costList = SheetUtil.getColumnList(self.data, {
		"cost_id_",
		"cost_num_"
	}, {
		"base_id",
		"num"
	})

	if #costList > 0 then
		self:showCost(costList)
	end
end

function Npc:showCost(costList)
	if not self:isInteractive() then
		return
	end

	if self.costIcon then
		self.costIcon:removeSelf()
	end

	local item = costList[1]
	local bg = display.newSprite("#map_assets_cost_bg")
	local bgSize = bg:getContentSize()

	bg:setPositionY(self.height + 30)
	self:addChild(bg)

	local iconPath = IconManager.getItemIcon(item.base_id)
	local icon = display.newSprite(iconPath)

	icon:setPosition(bgSize.width / 2, bgSize.height / 2 + 2)
	bg:addChild(icon)

	local color = nil

	if not InfoItem.checkCost({
		item
	}) then
		color = Style.red
	end

	local numLabel = UIManager.createLabel(bgSize.width / 2, 8, 0, 0, item.num, {
		outline = 1,
		size = 16,
		color = color
	})

	bg:addChild(numLabel)

	bg.initY = bg:getPositionY()

	Style.makeFloat(bg)

	self.costIcon = bg

	event_listener.extendMethods(bg, true)
	ManagerInfo.onDataChange(bg, "item", item.base_id, function ()
		self:refreshCost()
	end)
end

function Npc:closeCost()
	if self.costIcon then
		local costIcon = self.costIcon

		transition.scaleTo(costIcon, {
			scale = 0,
			easing = "sineOut",
			time = 0.2,
			onComplete = function ()
				costIcon:removeSelf()
			end
		})

		self.costIcon = nil
	end
end

function Npc:addHeadIcon(model, priority)
	if not self.headIconQueue then
		self.headIconQueue = {}
	end

	for i, v in ipairs(self.headIconQueue) do
		if v.model == model then
			return
		end
	end

	table.insert(self.headIconQueue, {
		model = model,
		priority = priority
	})
	table.sort(self.headIconQueue, function (a, b)
		return b.priority < a.priority
	end)
	self:refreshHeadIcon()
end

function Npc:removeHeadIcon(model)
	if self.headIconQueue then
		local existed = false

		for i, v in ipairs(self.headIconQueue) do
			if v.model == model then
				table.remove(self.headIconQueue, i)

				existed = true

				break
			end
		end

		if existed then
			self:refreshHeadIcon()
		end
	end
end

function Npc:refreshHeadIcon()
	if self.headIconQueue and #self.headIconQueue > 0 then
		local obj = self.headIconQueue[1]

		if self.headIcon ~= obj.model then
			self:removeLastingEffect(self.headIcon)

			self.headIcon = obj.model

			self:addLastingEffect(self.headIcon)
		end
	elseif self.headIcon then
		self:removeLastingEffect(self.headIcon)

		self.headIcon = nil
	end
end

function Npc:refreshBuilding(animated)
	local buildingCSV = nil
	local _buildingLevel = InfoBuilding.getBuildingLevel(self.buildingTag)

	if _buildingLevel then
		buildingCSV = InfoBuilding.getBuildingData(self.buildingTag, _buildingLevel - 1)
	end

	local function change()
		if not empty(self.data.building_hide_0) then
			local buildingLevel = InfoBuilding.getBuildingLevel(self.data.building_hide_0)

			self:setHidden("npc-buidling", buildingLevel == 0)

			if animated and buildingLevel == 1 then
				self:setOpacity(0)

				local obj = {
					opacity = 0
				}

				local function onUpdate()
					self:setOpacity(obj.opacity)
				end

				Looper.tween(30, obj, {
					opacity = 255
				}, "linear", nil, onUpdate)
			end
		elseif not empty(self.data.building_hide_1) then
			self:setHidden("npc-buidling", InfoBuilding.getBuildingLevel(self.data.building_hide_1) > 0)
		end

		local buildingLevel = InfoBuilding.getBuildingLevel(self.buildingTag)

		if buildingLevel == 0 and self:hasAction("ready") then
			self:setAction("ready")
		end

		if animated then
			local buildingLevel = InfoBuilding.getBuildingLevel(self.buildingTag)

			if buildingLevel == 1 and global.player then
				global.player:checkNearNpc()
			end

			if buildingCSV and not empty(buildingCSV.build_over_hint) then
				HintManager.open(buildingCSV.build_over_hint, function ()
					if global.player then
						global.player:setGoDirectionLocked("build_over_hint", false)
					end
				end)
			end
		end
	end

	if animated then
		if self.buildingTag == InfoBuilding.TAG.MONO and InfoGuide.getFreeRecord(14) == 0 then
			DramaManager.presetUnit(self)
			InfoGuide.triggerFree(14)
		end

		if self.buildingTag == InfoBuilding.TAG.MONO then
			local buildingLevel = InfoBuilding.getBuildingLevel(self.buildingTag)

			if buildingLevel == 0 then
				self:setAction("open", 1, change)
			else
				self:setAction("open2", 1, change)
			end
		else
			if buildingCSV and not empty(buildingCSV.build_over_hint) and global.player then
				global.player:setGoDirectionLocked("build_over_hint", true)
			end

			if empty(self.data.building_hide_0) then
				local effect = self:addEffect("@building")

				effect:setScale(0.8)
			end

			Looper.setTimeout(change, 60, self)
		end
	else
		change()
	end

	if InfoParams.getValue("union_gwar") == 1 and self.buildingTag == InfoBuilding.TAG.UNION_GWAR and InfoParams.getValue("union_gwar") == 1 and InfoUnion.inWarSeason() then
		self:setAction("opened")
	end
end

function Npc:startRead(time, onComplete, onUpdate)
	if self.gathering then
		return
	end

	local timeLeft = time
	local gatherLoop = nil

	local function stopLoop()
		self.gathering = nil

		MapFrameManager.stopLoop(self, gatherLoop)
	end

	function gatherLoop(_, frame, passed, sharp)
		if not self.gathering then
			stopLoop()

			return
		end

		timeLeft = timeLeft - passed

		if onUpdate then
			onUpdate(math.min(1, math.max(0, 1 - timeLeft / time)))
		end

		if timeLeft <= 0 then
			stopLoop()
			onComplete()
		end
	end

	self.gathering = true

	MapFrameManager.startLoop(self, gatherLoop)
end

function Npc:stopRead()
	if self.gathering then
		self.gathering = nil

		return true
	end
end

function Npc:setMooncardChest(eventData)
	self.npcType = TYPE.MOONCARD_CHEST
	self.baseID = MiscConfig.moonDailyGather
	self.eventData = eventData
	self.priority = 10
	Npc.mooncardChest = self
	local gatherData = CsvParser.getCsvData("gather", MiscConfig.moonDailyGather)

	assert(gatherData, "gather miss id:" .. MiscConfig.moonDailyGather)
	self:setData(gatherData)
	self:refreshMooncardChest(true)
end

function Npc:refreshMooncardChest(animated)
	self:setHidden("npc-mooncard", not InfoOrder.inMoon())
	self:refreshOpened()

	if InfoOrder.moonToday() and animated and not global.mooncardChestShow then
		global.mooncardChestShow = true
		local effectGen = self:getEffectGen()

		if effectGen then
			effectGen:castEffect(MiscConfig.moonDailyEffect)
		end
	end
end

function Npc:setGatherID(id, eventData)
	self.npcType = TYPE.GATHER
	self.baseID = id
	self.eventData = eventData

	Npc.addToGatherMap(self.baseID, self)

	local gatherData = CsvParser.getCsvData("gather", id)

	assert(gatherData, "gather miss id:" .. id)
	self:setData(gatherData)
	self:refreshCost()

	if InfoGuide.getFreeRecord(19) == 0 then
		if self.data.is_bag == 1 and empty(self.data.is_global) and not DramaManager.opening then
			self.checkGuideFree = InfoGuide.guideFree(19, self, function ()
				self.checkGuideFree = nil
			end, self)
		end
	elseif InfoGuide.getFreeRecord(28) == 0 and self.data.is_bag == 1 and self.data.id == 900003 and not DramaManager.opening then
		self.checkGuideFree = InfoGuide.guideFree(27, self, function ()
			self.checkGuideFree = nil
		end, self, nil, true)
	end
end

function Npc:openGather(eventsetIndex)
	if self.npcType ~= TYPE.GATHER then
		return
	end

	if self.getGatherLock then
		return
	end

	if global.player then
		global.player:stop(27)
		global.player:faceToTile(self.tile)
		global.player:stopMoveDirection()
	end

	local eventIndex = self.eventData.index
	local mapID = self.eventData.mapName
	local costList = SheetUtil.getColumnList(self.data, {
		"cost_id_",
		"cost_num_"
	}, {
		"id",
		"num"
	})
	local costCheck, lackList, lackStr = InfoItem.checkCost(costList)

	if not costCheck then
		local msg = Localization.getSrcText("缺少 {1}")

		Alert.open(StringUtil.replace(msg, lackStr))

		return
	end

	if self.data.is_bag ~= 1 and self.data.drop_ground ~= 1 then
		global.resource:lockAll()
	end

	self.getGatherLock = true
	local isClosed = false

	local function onGetInfo(info)
		local function onGatherGet(rcvData)
			global.player:onNpcDisable(self)
			self:refreshEventset()
			self:refreshOpened(false)

			isClosed = true

			self:closeCost()

			if self.data.is_bag ~= 1 then
				if rcvData.items and #rcvData.items > 0 then
					self:popItems(rcvData.items)
				elseif self.data.drop_ground ~= 1 then
					global.resource:unlockAll()
				end
			end
		end

		if self.data.is_bag == 1 then
			FRAME_relic_get.open(FRAME_relic_get.TYPE.GATHER, self, eventIndex, {
				eventsetIndex = eventsetIndex
			}, info.drop_equips, info.drop_items, info.drop_cards, info.drop_sigils, function (_rcvData)
				onGatherGet(_rcvData)
			end, function ()
				self.getGatherLock = nil

				self:refreshOpened(false)

				isClosed = true
			end)
		else
			InfoDungeon.getGather(eventIndex, nil, , onGatherGet, function ()
				self.getGatherLock = nil
			end)
		end

		local openEffect = self.data.open_effect

		if not empty(openEffect) then
			local effectGen = self:getEffectGen()

			if effectGen then
				effectGen:castEffect(openEffect, self)
			end
		end
	end

	local gatherEffect = self.data.gather_effect

	if not empty(gatherEffect) then
		local effectGen = self:getEffectGen()

		if effectGen then
			effectGen:castEffect(gatherEffect, self)
		end
	end

	if self.data.is_bag == 1 then
		InfoDungeon.getGatherInfo(eventIndex, eventsetIndex, function (rcvData)
			self:refreshEventset()

			if self:hasAction("open") then
				self:setAction("open", 1, function ()
					if not isClosed then
						self:setAction("opened", 1)
					end
				end)
				Looper.setTimeout(function ()
					onGetInfo(rcvData)
				end, 25, self)
			else
				self:setAction("opened", 1)
				onGetInfo(rcvData)
			end
		end, function ()
			self.getGatherLock = nil
		end)
	else
		onGetInfo()
	end
end

function Npc:popItems(_items, forceGround)
	_items = Random.randomOrder(_items, math.random)
	local items = {}

	for i, v in ipairs(_items) do
		table.insert(items, {
			type = DropManager.TYPE.ITEM,
			info = v
		})
	end

	self:setCustomLight(0.8, 1.75)
	self:refreshLight()

	local centerX, centerY = self:getCenter()

	if forceGround or self.data.drop_ground == 1 then
		MapUtils.startDropTile({
			self.tile
		})

		local popNext = nil
		local step = 0

		function popNext()
			if step == 0 then
				Shader.highlight(self, 0.1)

				local dropInfo = table.remove(items, 1)
				dropInfo.eventIndex = self.eventData.index
				local dropItem = DropItem.new()

				dropItem:setDrop(dropInfo)
				dropItem:setScale(MiscConfig.drop_item_scale)
				dropItem:display(self.map, centerX, centerY)

				local tile = self.map:mapToTile(centerX, centerY)
				local destTile = MapUtils.getDropTile(tile)

				if destTile then
					local x, y = self.map:tileToMap(destTile)

					dropItem:jump({
						x = x,
						y = y
					}, math.random() * 5 + 10, math.random() * 32 + 64)
				end

				if #items > 0 then
					MapFrameManager.setTimeout(popNext, 1, self)
				else
					Shader.recover(self)
					self:clearCustomLight()
				end

				step = 1
			else
				Shader.recover(self)
				MapFrameManager.setTimeout(popNext, 2, self)

				step = 0
			end
		end

		popNext()

		return
	end

	for i, dropInfo in ipairs(items) do
		dropInfo.info.num = 0
	end

	global.ui:popItems(cc.p(centerX, centerY), items, function ()
		global.resource:unlockAll()
	end)
	Shader.highlight(self, 0.1)
	MapFrameManager.setTimeout(function ()
		Shader.recover(self)
		self:refreshLight()
	end, 5, self)
end

function Npc:popMultiDrop(dropList, onComplete)
	local index = 1
	local showNext = nil

	function showNext()
		self:popDrop(dropList[index])

		index = index + 1

		if index <= #dropList then
			MapFrameManager.setTimeout(showNext, 15, self)
		else
			LayerConfig.setPopLocked("Npc_gather", true)
			MapFrameManager.setTimeout(function ()
				POP_reward.open(dropList, onComplete)
				LayerConfig.setPopLocked("Npc_gather", false)
			end, 20, self)
		end
	end

	showNext()
end

function Npc:popDrop(dropInfo)
	local dropItem = DropItem.new()

	dropItem:setDrop(dropInfo)
	dropItem:setScale(0.7)
	dropItem:setShadowEnabled(false)
	dropItem:display(self.map, self.x, self.y)
	dropItem:fadeUp(nil, 15, nil, 100)
end

function Npc:flyToResource(dropInfo, onComplete)
	local dropItem = DropItem.new()

	dropItem:setDrop(dropInfo)
	dropItem:setScale(0.7)
	dropItem:setShadowEnabled(false)
	dropItem:display(self.map, self.x, self.y)
	dropItem:flyToResource(onComplete)
end

function Npc:refreshOpened(animated)
	local eventIndex = self.eventData.index
	local mapID = self.eventData.mapName
	local visible = self:isVisible()

	self:setHidden("npc-visible", not visible)

	if visible then
		if self.npcType == TYPE.GATHER or self.npcType == TYPE.SHRINE then
			if not self:isInteractive() or not self:checkEventsetIndex() then
				if animated then
					local openEffect = self.data.open_effect

					if not empty(openEffect) then
						local effectGen = self:getEffectGen()

						if effectGen then
							effectGen:castEffect(openEffect, self)
						end
					end
				end

				if animated and self:hasAction("open") then
					self:setAction("open", 1, function ()
						self:setAction("opened")
					end)
				else
					self:setAction("opened")
				end
			else
				self:setAction("idle")
			end
		elseif self.npcType == TYPE.MOONCARD_CHEST then
			if not InfoOrder.moonToday() then
				if animated then
					local openEffect = self.data.open_effect

					if not empty(openEffect) then
						local effectGen = self:getEffectGen()

						if effectGen then
							effectGen:castEffect(openEffect, self)
						end
					end
				end

				if animated and self:hasAction("open") then
					self:setAction("open", 1, function ()
						self:setAction("opened")
					end)
				else
					self:setAction("opened")
				end
			else
				self:setAction("idle")
			end
		elseif self.npcType == TYPE.CHANCE then
			local alreadyFin = false

			if self:checkEventsetIndex() then
				if self.data.type == 11 then
					self:refreshGladiator()
				elseif self.data.type == 7 then
					local dungeon_csv = InfoDungeon.getDungeonCSV()
					local mine_index = dungeon_csv.mine_index
					local already = false

					if not empty(mine_index) then
						alreadyFin = InfoFurnace.getMineRecord(mine_index) > 0
					end
				elseif self.data.type == 13 or self.data.type == 14 then
					alreadyFin = InfoDungeon.getEventInfo(eventIndex).fin == 2
				else
					alreadyFin = InfoDungeon.getEventInfo(eventIndex).fin == 1
				end
			else
				alreadyFin = true
			end

			if alreadyFin then
				if self.runeItem then
					self.runeItem:removeSelf()

					self.runeItem = nil
				end

				if animated and self:hasAction("open") then
					self:setAction("open", 1, function ()
						self:setAction("opened")
					end)
				else
					self:setAction("opened")
				end
			else
				self:setAction("idle")
			end
		elseif self.npcType == TYPE.DOOR then
			local fin = InfoDungeon.getEventInfo(eventIndex).fin
			local links = MapEventManager.findLinkAll(self.eventData)
			local info = ConfParser.parse(self.eventData.info)
			local linkCount = 0

			for i, linkData in ipairs(links) do
				if linkData.tag ~= "selector" then
					linkCount = linkCount + 1
				end
			end

			linkCount = math.max(linkCount, 1)
			local isOpen = nil

			if info.open_type == 1 then
				isOpen = fin < linkCount
			else
				isOpen = linkCount <= fin
			end

			if self.doorOpening ~= isOpen then
				self.doorOpening = isOpen

				if isOpen then
					if animated and self:hasAction("open") then
						self:setAction("open", 1, function ()
							self:setAction("opened")
						end)
					else
						self:setAction("opened")
					end
				elseif animated and self:hasAction("close") then
					self:setAction("close", 1, function ()
						self:setAction("idle")
					end)
				else
					self:setAction("idle")
				end
			end

			if self.tile then
				for x = self.tile.x, self.tile.x + self.size - 1 do
					for y = self.tile.y, self.tile.y + self.size - 1 do
						local tile = self.map:getTile(x, y)

						if tile then
							tile:setForceWalk("door", isOpen and 0 or 2)
						end
					end
				end
			end
		end
	end
end

function Npc:setRelicID(id, eventIndex, relicIndex, overTime)
	self.npcType = TYPE.RELIC
	self.baseID = id
	self.eventIndex = eventIndex
	self.relicIndex = relicIndex
	self.angle = math.random() * math.pi / 2
	local relicData = CsvParser.getCsvData("relic", id)

	assert(relicData, "relic miss id:" .. id)
	self:setData(relicData)
	self:refreshBlock()
	MapFrameManager.stopLoop(self, self.relicTimeCountdown)

	if not empty(overTime) then
		self.relicOverTime = overTime

		MapFrameManager.startLoop(self, self.relicTimeCountdown)
	end

	if InfoGuide.getFreeRecord(3) == 0 and self.data.type == 1 and not DramaManager.opening then
		self.checkGuideFree = InfoGuide.guideFree(3, self, function ()
			self.checkGuideFree = nil
		end, self)

		return
	end

	if InfoGuide.getFreeRecord(2) == 0 and self.data.type == 9 then
		if not DramaManager.opening then
			self.checkGuideFree = InfoGuide.guideFree(2, self, function ()
				self.checkGuideFree = nil
			end, self)
		else
			local notify_id = nil
			notify_id = notify.safeRegister(self, "drama_over", function ()
				notify.unregister("drama_over", notify_id)

				local checkGuideFree = InfoGuide.guideFree(2, self, nil, self)

				checkGuideFree()
			end)
		end
	end
end

function Npc:relicTimeCountdown()
	local timeLeft = self.relicOverTime - Time.now()

	if timeLeft <= 0 then
		MapFrameManager.stopLoop(self, self.relicTimeCountdown)
		self:relicDestroy()
	elseif timeLeft <= 10 then
		local opacity = (0.6 + math.cos(timeLeft * 5 * math.pi) * 0.4) * 255

		self:setOpacity(opacity)
	elseif timeLeft <= 30 then
		local opacity = (0.7 + math.cos(timeLeft * 2 * math.pi) * 0.3) * 255

		self:setOpacity(opacity)
	end
end

function Npc:openRelic(_eventIndex, _relicIndex)
	if self.getRelicLock then
		return
	end

	if self.data.auto_pick ~= 1 and global.player then
		global.player:stop(27)
		global.player:faceToTile(self.tile)
		global.player:stopMoveDirection()
	end

	local eventIndex = _eventIndex or self.eventIndex
	local relicIndex = _relicIndex or self.relicIndex
	local mapID = global.map.mapName
	local relicID = InfoDungeon.getRelicID(eventIndex, relicIndex)
	local relicCSV = CsvParser.getCsvData("relic", relicID)

	if relicCSV.type ~= RELIC_TYPE.TROPHY then
		global.player:onNpcDisable(self)
	end

	self.getRelicLock = true
	local isClosed = false

	local function doRequest()
		if relicCSV.type == RELIC_TYPE.TROPHY then
			requestGMCopyTrophyRelic(eventIndex, relicIndex)

			local function onGetInfo(info)
				FRAME_relic_get.open(FRAME_relic_get.TYPE.RELIC, self, eventIndex, {
					relicIndex = relicIndex
				}, info.drop_equips, info.drop_items, info.drop_cards, info.drop_sigils, function (_rcvData)
					global.player:onNpcDisable(self)

					if self.npcType == TYPE.RELIC then
						self:relicDestroy(true)
					elseif self.npcType == TYPE.CHANCE and self.data.type == 11 then
						self:clearEffect()
						notify.dispatch("top_map_refresh")
					end
				end, function ()
					self.getRelicLock = nil

					self:setAction("idle")

					isClosed = true
				end)
			end

			InfoDungeon.getRelicInfo(eventIndex, relicIndex, function (rcvData)
				if self:hasAction("open") then
					self:setAction("open", 1, function ()
						if not isClosed then
							self:setAction("opened", 1)
						end
					end)
					Looper.setTimeout(function ()
						onGetInfo(rcvData)
					end, 18, self)
				else
					self:setAction("opened", 1)
					onGetInfo(rcvData)
				end
			end, function ()
				self.getRelicLock = nil
			end)

			return
		end

		InfoDungeon.getRelic(eventIndex, relicIndex, nil, function (rcvData)
			if relicCSV.type == RELIC_TYPE.GAP then
				print("$$$ rcvData.gap_id", rcvData.gap_id)

				if not empty(rcvData.gap_id) then
					DungeonScene.enterDungeon(DungeonScene.ENTER_TYPE.NEW, rcvData)

					return
				end
			end

			if rcvData.ex_data and #rcvData.ex_data.drop_list > 0 then
				local dropList = rcvData.ex_data.drop_list

				if relicCSV.type == RELIC_TYPE.GAP then
					-- Nothing
				else
					local function onPopClose()
						GuideManager.guidePopDrop(dropList)
						self:relicDestroy(true)
					end

					self:popMultiDrop(dropList, onPopClose)

					if self:hasAction("open") then
						self:setAction("open", 1, function ()
							self:setAction("opened")
						end)
					else
						self:setAction("opened")
					end
				end
			else
				self:relicDestroy(true)
			end

			self:removeFromMap()
		end, function ()
			self.getRelicLock = nil

			global.player:addNearNpc(self)
		end)
	end

	local openEffect = self.data.open_effect

	if not empty(openEffect) then
		local effectGen = self:getEffectGen()

		if effectGen then
			effectGen:castEffect(openEffect, self)
		end
	end

	doRequest()
end

function Npc:relicDestroy(animated)
	MapFrameManager.stopLoop(self, self.relicTimeCountdown)

	local function doDestroy()
		global.player:onNpcDisable(self)
		self:setHidden("npc-destroy", true)
		self:clearLight()
	end

	if animated then
		local relicID = InfoDungeon.getRelicID(self.eventIndex, self.relicIndex)
		local relicData = CsvParser.getCsvData("relic", relicID)

		if relicData.type == 1 then
			local effectGen = self:getEffectGen()

			if effectGen then
				effectGen:zmove(30, 48)
				effectGen:fadeTo(30, 0, "outQuad")
			end

			MapFrameManager.setTimeout(doDestroy, 30, self)
		elseif relicData.type == 2 then
			doDestroy()
		else
			local effectGen = self:getEffectGen()

			if effectGen then
				effectGen:fadeTo(30, 0, "outQuad")
			end

			MapFrameManager.setTimeout(doDestroy, 30, self)
		end
	else
		doDestroy()
	end
end

function Npc:hireHero()
	local function askForJoin()
		POP_notice.open(Localization.getSrcText("招募这名佣兵吗?"), function ()
			global.player:setGoDirectionLocked("hire_hero", true)

			local function onSuccess(rcvData)
				local function onNoneUnit()
					global.player:setGoDirectionLocked("hire_hero", false)
					self:refreshHeroTemplete()
					global.player:onNpcDisable(self)
				end

				if rcvData.ex_data then
					local heroID = rcvData.ex_data.hero_id
					local unit = TeamManager.getHeroByID(heroID)

					if unit then
						self:refreshHeroTemplete()
						global.player:onNpcDisable(self)
						unit:draw(self.x, self.y, true)
						global.player:regroupTrain(function ()
							global.player:setGoDirectionLocked("hire_hero", false)
						end)
					else
						onNoneUnit()
					end
				else
					onNoneUnit()
				end
			end

			local eventIndex = self.eventData.index
			local mapID = self.eventData.mapName

			InfoDungeon.getHeroTemp(eventIndex, onSuccess, function ()
				global.player:setGoDirectionLocked("hire_hero", false)
			end)
		end)
	end

	if not empty(self.data.dialog) then
		POP_dialog.open(self.data.dialog, askForJoin)
	else
		askForJoin()
	end
end

function Npc:refreshHeroTemplete()
	local visible = self:isVisible()

	self:setHidden("npc-hero-templete", not visible)
end

function Npc:refreshLight(x, y)
	local visible = self:isVisible()

	if not visible then
		return
	end

	Npc.super.refreshLight(self, x, y)
end

function Npc:isVisible()
	if self.npcType == TYPE.GATHER then
		local gatherData = CsvParser.getCsvData("gather", self.baseID)

		if gatherData.disappear == 1 and not self:isInteractive() then
			return false
		end
	elseif self.npcType == TYPE.CHANCE then
		local chanceData = CsvParser.getCsvData("chance", self.baseID)

		if chanceData.disappear == 1 and not self:isInteractive() then
			return false
		end
	elseif self.npcType == TYPE.SHRINE then
		local shrineData = CsvParser.getCsvData("shrine", self.baseID)

		if shrineData.disappear == 1 and not self:isInteractive() then
			return false
		end
	elseif self.npcType == TYPE.HERO_TEMPLETE then
		local eventIndex = self.eventData.index

		if InfoDungeon.getEventInfo(eventIndex).fin == 1 then
			return false
		end
	elseif self.npcType == TYPE.NPC then
		if not empty(self.data.func_open) then
			local funcCSV = InfoFunction.checkFuncOpen(self.data.func_open)

			if not funcCSV then
				return false
			end
		end

		if InfoParams.getValue("sigil") ~= 1 and self.buildingTag == InfoBuilding.TAG.SIGIL then
			return false
		end

		if self.buildingTag == InfoBuilding.TAG.ARTIFACT then
			local showArtifact = false

			if InfoParams.getValue("artifact") == 1 then
				local funcCSV = InfoFunction.checkFuncOpen(10700)

				if funcCSV then
					showArtifact = true
				end
			end

			return showArtifact
		end
	end

	return true
end

function Npc:checkEventsetIndex()
	if self.eventsetIndex then
		local eventIndex = self.eventData.index
		local eventInfo = InfoDungeon.getEventInfo(eventIndex)

		if eventInfo.set_index and eventInfo.set_index ~= self.eventsetIndex then
			return false
		end
	end

	return true
end

function Npc:isInteractive()
	if WarMachine.on then
		return false
	end

	if self.eventsetIndex then
		local eventIndex = self.eventData.index
		local eventInfo = InfoDungeon.getEventInfo(eventIndex)

		if eventInfo.set_index then
			for i, setNpc in ipairs(self.eventsetArr) do
				if setNpc ~= self and setNpc.eventsetIndex == eventInfo.set_index then
					return setNpc:isInteractive()
				end
			end
		end
	end

	if self.npcType == TYPE.GATHER then
		if not self.eventData then
			return false
		end

		local eventIndex = self.eventData.index

		if InfoDungeon.getEventInfo(eventIndex).fin == 1 then
			return false
		end

		if self.data.is_global == 1 and InfoGather.isMarked(self.data.id) then
			return false
		end
	elseif self.npcType == TYPE.SHRINE then
		if not self.eventData then
			return false
		end

		local eventIndex = self.eventData.index

		if InfoDungeon.getEventInfo(eventIndex).fin == 1 then
			return false
		end
	elseif self.npcType == TYPE.RELIC then
		if self.getRelicLock then
			return false
		end

		if self.data.auto_pick == 1 then
			return false
		end
	elseif self.npcType == TYPE.NPC then
		local buildingData0 = InfoBuilding.getBuildingData(self.data.building, 0)

		if not empty(self.data.building) and not buildingData0 then
			return true
		elseif not empty(self.data.building) and InfoBuilding.getBuildingLevel(self.data.building) > 0 then
			return true
		elseif not empty(self.data.building0) and InfoBuilding.getBuildingLevel(self.data.building0) == 0 then
			return true
		end

		local data = InfoTaskQuest.getDataForNPC(self.baseID)

		if data then
			return true
		end

		local data = InfoFestival.getDataForNPC(self.baseID)

		if data then
			return true
		end

		return false
	elseif self.npcType == TYPE.CHANCE then
		if not self.eventData then
			return false
		end

		local eventIndex = self.eventData.index

		if self.data.type == 10 then
			return true
		end

		local finLevel = 1

		if self.data.type == 11 then
			finLevel = GameConfig.gladiator_max * 2 + 1
		elseif self.data.type == 13 or self.data.type == 14 then
			finLevel = 2
		end

		if finLevel <= InfoDungeon.getEventInfo(eventIndex).fin then
			return false
		end

		if self.data.type == 7 then
			local dungeon_csv = InfoDungeon.getDungeonCSV()
			local mine_index = dungeon_csv.mine_index

			if empty(mine_index) or InfoFurnace.getMineRecord(mine_index) > 0 then
				return false
			end
		end

		if self.data.type == 16 and InfoGuide.getGuidePetState() ~= 0 then
			return false
		end
	elseif self.npcType == TYPE.MOONCARD_CHEST then
		return InfoOrder.moonToday()
	elseif self.npcType == TYPE.DEVICE then
		return not empty(self.data.building)
	end

	return true
end

function Npc:getRumor()
	if not empty(self.data.rumor) then
		if not self.rumorData then
			local rumorList = string.split(self.data.rumor, ";")
			self.rumorData = {
				index = 1,
				list = rumorList
			}
		end

		local str = self.rumorData.list[self.rumorData.index]
		self.rumorData.index = self.rumorData.index + 1

		if self.rumorData.index > #self.rumorData.list then
			self.rumorData.index = 1
		end

		return str
	end
end

function Npc:setGatherHudVisible(visible, color)
	if self.gatherHudVisible ~= visible then
		self.gatherHudVisible = visible

		if self.gatherHudVisible then
			local hudUI = display.newNode():align(display.LEFT_BOTTOM)
			local barBG = display.newSprite("#map_assets_hudbar_bg"):align(display.LEFT_BOTTOM)
			local bar = display.newSprite("#map_assets_hudbar"):align(display.LEFT_BOTTOM, 1, 1)

			bar:setColor(cc.c3b(82, 134, 231))
			hudUI:addChild(barBG)
			hudUI:addChild(bar)
			hudUI:setCascadeOpacityEnabled(true)
			transition.fadeIn(hudUI, {
				time = 0.4
			})

			self.gatherHud = {
				ui = hudUI,
				bar = bar,
				barbg = barBG
			}

			self.map.highLayer:addChild(hudUI)
			self:refreshShadow()
			self:draw()
			self:hudSetGather(1)
		elseif self.gatherHud then
			local hudUI = self.gatherHud.ui

			transition.fadeOut(hudUI, {
				time = 0.2,
				onComplete = function ()
					hudUI:removeSelf()
				end
			})

			self.gatherHud = nil
		end
	end
end

function Npc:hudSetGather(percent)
	if self.gatherHud == nil then
		return
	end

	percent = math.max(0, math.min(percent, 1))

	self.gatherHud.bar:setScaleX((self.gatherHud.width - 2) / 64 * percent)
end

function Npc:refreshShadow(isNew)
	Npc.super.refreshShadow(self, isNew)

	if self.gatherHud then
		local barWidth = math.floor(self:getFootWidth() * self.map.config.scale.unit)
		barWidth = math.sqrt(barWidth * self.size * self.map.ptPerTile / 2) * 0.7

		self.gatherHud.bar:setScaleX((barWidth - 2) / 64)
		self.gatherHud.barbg:setScaleX(barWidth / 64)

		self.gatherHud.width = barWidth
	end
end

function Npc:setBmpY()
	Npc.super.setBmpY(self)

	if self.gatherHud and self.drawX then
		local hudY = -self.drawY + self.height + self.z + 20

		self.gatherHud.ui:setPosition(self.drawX - self.gatherHud.width / 2, hudY)
	end
end

function Npc:go(x, y)
	self:focusRelease()

	return Npc.super.go(self, x, y)
end

function Npc:onExit()
	if self.npcType == TYPE.NPC then
		if not self.noAddInstance then
			Npc.removeFromInstanceMap(self.baseID)
		end
	elseif self.npcType == TYPE.PET then
		Npc.removeFromPetMap(self.baseID)
	elseif self.npcType == TYPE.GATHER then
		Npc.removeFromGatherMap(self.baseID)
	elseif self.npcType == TYPE.SHRINE then
		Npc.removeFromShrineMap(self.baseID)
	elseif self.npcType == TYPE.CHANCE then
		Npc.removeFromChanceMap(self.baseID)
	elseif self.npcType == TYPE.DOOR then
		Npc.removeFromDoorMap(self.baseID)
	elseif self.npcType == TYPE.DEVICE then
		Npc.removeFromDeviceMap(self.baseID)
	elseif self.npcType == TYPE.HERO_TEMPLETE then
		Npc.removeFromHeroTempleteMap(self.baseID)
	elseif self.npcType == TYPE.MOONCARD_CHEST then
		Npc.mooncardChest = nil
	elseif self.npcType == TYPE.RELIC then
		MapFrameManager.stopLoop(self, self.relicTimeCountdown)
	end

	if not app.sceneChanging and self.runeItem then
		self.runeItem:delayRemove()

		self.runeItem = nil
	end

	Npc.super.onExit(self)
end

return Npc
