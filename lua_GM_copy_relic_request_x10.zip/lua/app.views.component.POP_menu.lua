local UI_base = import("..UI_base")
local POP_menu = class("POP_menu", UI_base)
local BUTTON_TYPE = {
	BLUE = 3,
	RED = 2,
	GREEN = 1
}
POP_menu.BUTTON_TYPE = BUTTON_TYPE

function POP_menu.open(title, style, pos, data, buttonArr)
	local ui = POP_menu.new(title, style, pos, data, buttonArr)
	local x = math.max(50, math.min(display.width - 50 - ui.width, pos.x - ui.width / 2))
	local y = nil

	if pos.y < display.height / 2 then
		y = pos.y + ui.height + 50
	else
		y = pos.y - 50
	end

	y = math.max(ui.height, math.min(display.height, y))

	ui:setPosition(x, y)

	local container = display.newNode()

	container:addChild(ui)
	container:setCascadeOpacityEnabled(true)
	PopManager.open(container)
end

function POP_menu:ctor(title, style, pos, data, buttonArr)
	POP_menu.super.ctor(self, "pop_menu", UIManager.BIG_TYPE.POP)

	self.title = title
	self.style = style
	self.pos = pos
	self.data = data
	self.buttonArr = buttonArr

	self:init()
end

function POP_menu:init()
	self:initUI()
	self:createLabelOnFlag("flag_title", self.title, self.style)
end

function POP_menu:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local flag = self:getFlagByTag("flag_list")
	local buttonX = flag.x
	local buttonY = flag.y + flag.height
	local spaceY = flag.height

	for i, obj in ipairs(self.buttonArr) do
		local ui = UIManager.getUI("pop_menu_button_" .. obj.buttonType)

		ui:setPosition(buttonX, buttonY)
		self:addChild(ui, 100)

		local callback = obj.callback
		local button = ui:getComponentByTag("button")

		button:toTouchable()
		button:setTapGroup("button_click")
		button:addTap(callback)
		button:addLabel(obj.label)

		buttonY = buttonY - spaceY
	end

	local height = #self.buttonArr * spaceY
	local yOffset = height - flag.originalHeight
	local bg = self:getComponentByTag("bg")
	local bg1 = self:getComponentByTag("bg1")

	bg:setSize(nil, bg.originalHeight + yOffset)
	bg1:setSize(nil, bg1.originalHeight + yOffset)
	bg:setPos(nil, bg.originalY - yOffset)
	bg1:setPos(nil, bg1.originalY - yOffset)

	self.height = bg.height
end

return POP_menu
