local NAV_base = import(".NAV_base")
local NAV_sigil = class("NAV_sigil", NAV_base)

function NAV_sigil.open(npc)
	local ui = NAV_sigil.new(npc)

	return ui
end

function NAV_sigil:ctor(npc)
	NAV_sigil.super.ctor(self, npc, "nav_sigil")
end

function NAV_sigil:init()
	NAV_sigil.super.init(self)
end

function NAV_sigil:onTap(index)
	NAV_sigil.super.onTap(self, index)

	if index == 1 then
		FRAME_sigil.open(self.npc)
	elseif index == 2 then
		FRAME_sigil_color.open(self.npc)
	elseif index == 3 then
		FRAME_sigil_fusion.open(self.npc)
	elseif index == 4 then
		FRAME_single_shop.open(InfoSigil, self.npc)
	end
end

return NAV_sigil
