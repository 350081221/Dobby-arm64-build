local AbyssHint = class("AbyssHint", UI_base)

function AbyssHint.open(isEnter, container, seed)
	local csv = LinesManager.getAbyssHint(isEnter, InfoDungeon.getAbyssMaxLevel(), seed)

	print("$$$ AbyssHint.open", csv)

	if csv then
		local ui = AbyssHint.new(csv)

		container:addChild(ui, 100)
	end
end

function AbyssHint:ctor(csv)
	AbyssHint.super.ctor(self, "pop_abyss_hint")

	self.csv = csv

	self:init()
end

function AbyssHint:init()
	self:initUI()
end

function AbyssHint:initUI()
	local hintData = self.csv
	local head = nil

	if hintData.head ~= "" then
		local pic = IconManager.getHead(hintData.head, hintData.emoji)
		head = self:createIconOnFlag("flag_head", pic, 100, UILayout.SCALE_TYPE.LARGE, nil, , UILayout.ALIGN_TYPE.BOTTOM)
	end

	local text = hintData.text
	text = StringUtil.replaceTag(text, function (tag, embedded)
		return ManagerInfo.parseTag(tag, not embedded)
	end)

	if self.createUbbOnFlag then
		local bg = self:getComponentByTag("bg")
		local bg_head = self:getComponentByTag("bg_head")
		local flagName = "flag_text"

		if head then
			flagName = "flag_text_head"

			bg_head:setVisible(true)
			bg:setVisible(false)
		else
			bg_head:setVisible(false)
			bg:setVisible(true)
		end

		local ubbMap, labels, lines, totalWidth, totalHeight = self:createUbbOnFlag(flagName, text, {
			wrap = true,
			yspace = 5,
			align = Style.left,
			valign = Style.vbottom
		}, true)
	end
end

return AbyssHint
