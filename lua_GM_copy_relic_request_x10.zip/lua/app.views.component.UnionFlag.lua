local UI_base = import("..UI_base")
local UnionFlag = class("UnionFlag", UI_base)

function UnionFlag:ctor(rect, uiName)
	UnionFlag.super.ctor(self, uiName or "union_flag")

	self.size = rect

	self:init()

	if rect then
		self:setPosition(rect.x, rect.y)
	end
end

function UnionFlag:init()
	self:initUI()
end

function UnionFlag:initUI()
	local originalWidth = self.width
	local originalHeight = self.height
	local rect = self:getFlagByTag("rect")

	if rect then
		originalWidth = rect.width
		originalHeight = rect.height
	end

	self.width = self.size.width
	self.height = self.size.height
	local widthOffset = 0
	local heightOffset = 0

	if self.width ~= originalWidth or self.height ~= originalHeight then
		widthOffset = self.width - originalWidth
		heightOffset = self.height - originalHeight
		local bgFlag = self:getFlagByTag("flag_bg0")

		if bgFlag then
			bgFlag.width = bgFlag.width + widthOffset
			bgFlag.height = bgFlag.height + heightOffset
		end

		local bgFlag = self:getFlagByTag("flag_bg")

		if bgFlag then
			bgFlag.width = bgFlag.width + widthOffset
			bgFlag.height = bgFlag.height + heightOffset
		end

		local iconWidth = math.floor(bgFlag.width * 71 / 85 / 2) * 2
		local iconHeight = math.ceil(bgFlag.height * 85 / 116 / 2) * 2
		local iconOffsetY = math.ceil(3 * bgFlag.height / 116 / 2) * 2
		local iconFlag = self:getFlagByTag("flag_icon")
		iconFlag.width = iconWidth
		iconFlag.height = iconHeight
		iconFlag.x = bgFlag.x + (bgFlag.width - iconFlag.width) / 2
		iconFlag.y = bgFlag.y + (bgFlag.height - iconFlag.height) / 2 + iconOffsetY
		local frameWidth = math.ceil(bgFlag.width * 115 / 85 / 2) * 2
		local frameHeight = math.ceil(bgFlag.height * 145 / 116 / 2) * 2
		local frameFlag = self:getFlagByTag("flag_frame")
		frameFlag.width = frameWidth
		frameFlag.height = frameHeight
		frameFlag.x = bgFlag.x + (bgFlag.width - frameFlag.width) / 2
		frameFlag.y = bgFlag.y + (bgFlag.height - frameFlag.height) / 2
	end
end

function UnionFlag:clear()
	self:removeIconOnFlag("flag_icon")
	self:removeIconOnFlag("flag_bg")
	self:removeIconOnFlag("flag_bg0")
	self:removeIconOnFlag("flag_frame")
end

function UnionFlag:setNoFrame(noFrame)
	self.noFrame = noFrame
end

function UnionFlag:setFlag(obj)
	local bgPath, iconPath, colorBg1, colorBg2, colorIcon = IconManager.getUnionFlag(obj)
	local bg0Path = IconManager.getUnionFlagRaw("bg")
	local framePath = IconManager.getUnionFlagRaw("frame_000")
	local icon = self:createIconOnFlag("flag_bg0", bg0Path, 100, UILayout.SCALE_TYPE.SMALL)

	icon:setColor(colorBg1)

	if not empty(bgPath) then
		local icon = self:createIconOnFlag("flag_bg", bgPath, 110, UILayout.SCALE_TYPE.SMALL)

		icon:setColor(colorBg2)
	else
		self:removeIconOnFlag("flag_bg")
	end

	local icon = self:createIconOnFlag("flag_icon", iconPath, 120, UILayout.SCALE_TYPE.SMALL)

	icon:setColor(colorIcon)

	local icon = self.noFrame or self:createIconOnFlag("flag_frame", framePath, 130, UILayout.SCALE_TYPE.SMALL)
end

return UnionFlag
