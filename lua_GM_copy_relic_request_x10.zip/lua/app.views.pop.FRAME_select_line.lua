local FRAME_select_line = class("FRAME_select_line", UI_base)

function FRAME_select_line.open()
	InfoUser.getLineList(function (rcvData)
		local ui = FRAME_select_line.new(rcvData)

		PopManager.open(ui)
	end)
end

function FRAME_select_line:ctor(lineData)
	FRAME_select_line.super.ctor(self, "frame_select_line", UIManager.BIG_TYPE.POP)

	self.lineData = lineData
	self.lineID = lineData.current_line_id

	self:init()
end

function FRAME_select_line:init()
	self:initUI()
	self:refresh()
end

function FRAME_select_line:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local function tapListener(ui, data, index, x, y)
		if data.line_stat > 0 then
			return
		end

		self.lineID = data.line_id

		self:refresh()
	end

	self.list = self:createListOnFlag("flag_list", LIST_select_line, tapListener)

	self.list:setTapGroup("list_click")

	local holder = self:getComponentByTag("holder")

	self.list:setHolders({
		holder
	}, nil, 5)

	local function onConfirm()
		if self.locked then
			return
		end

		local lineData = self.list:getSelectedItem()

		if lineData then
			local line_id = lineData.line_id

			if line_id ~= InfoUser.gateLine then
				if InfoDungeon.inNoSafe() then
					Alert.open(Localization.getSrcText("仅可在营地切换"))

					return
				end

				self.locked = true

				InfoUser.selectLine(line_id, function (rcvData)
					POP_conn.inLogout = true

					POP_doing.open(Localization.getSrcText("切换中"))

					local serverArr = string.split(rcvData.line_addr, ":")
					SERVER_HOST = serverArr[1]
					SERVER_PORT = tonumber(serverArr[2])

					OnlineChat.clearOnlineStat()
					OnlineCamp.tryExit()
					OnlineChat.exit()
					print("切线 line_id:", line_id, " 地址：", SERVER_HOST, SERVER_PORT, "token：", rcvData.token)
					Connection.clearFlush()
					Connection.disConnect()
					Connection.init(SERVER_HOST, SERVER_PORT, function ()
						InfoUser.clearOnReconnect()
						InfoUser.reloginGate(rcvData.token, function ()
							POP_conn.inLogout = nil

							OnlineCamp.tryEnter()
							OnlineChat.tryReconnect()
							POP_doing.close()
							PopManager.closeAll()
						end)
					end)
				end)
			else
				PopManager.closeTo(self)
			end
		end
	end

	local confirmPB = self:getComponentByTag("bt_confirm")

	confirmPB:toTouchable()
	confirmPB:setTapGroup("button_click")
	confirmPB:addTap(onConfirm)

	local bt_change = self:getComponentByTag("bt_change")

	bt_change:toTouchable()
	bt_change:setTapGroup("button_click")
	bt_change:addTap(onConfirm)
end

function FRAME_select_line:refresh()
	local lineData = self.lineData
	local confirmPB = self:getComponentByTag("bt_confirm")
	local bt_change = self:getComponentByTag("bt_change")

	confirmPB:setVisible(self.lineID == InfoUser.gateLine)
	bt_change:setVisible(self.lineID ~= InfoUser.gateLine)

	local arr = {}

	for i, v in ipairs(lineData.all_line_info) do
		table.insert(arr, v)
	end

	table.sort(arr, function (a, b)
		local statA = math.min(1, a.line_stat)
		local statB = math.min(1, b.line_stat)

		if statA == statB then
			return a.line_id < b.line_id
		else
			return statA < statB
		end
	end)

	local selectedIndex = 1

	for i, v in ipairs(arr) do
		if self.lineID == v.line_id then
			selectedIndex = i

			break
		end
	end

	self.list:setItems(arr)
	self.list:setSelectedIndex(selectedIndex)
end

return FRAME_select_line
