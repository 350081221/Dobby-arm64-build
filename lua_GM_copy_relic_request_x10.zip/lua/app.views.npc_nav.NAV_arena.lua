local NAV_base = import(".NAV_base")
local NAV_arena = class("NAV_arena", NAV_base)

function NAV_arena.open(npc)
	local ui = NAV_arena.new(npc)

	return ui
end

function NAV_arena:ctor(npc)
	NAV_arena.super.ctor(self, npc, "nav_arena")
end

function NAV_arena:init()
	NAV_arena.super.init(self)

	local actived = InfoArena.isActived()

	self:setButtonVisible(2, actived)
	self:setButtonVisible(3, actived)

	local myArea = InfoArena.getMyArea()

	self:setButtonVisible(4, actived and myArea == 3)
	self:refresh()
	ManagerInfo.onDataChange(self, "arena", nil, function ()
		self:refresh()
	end)
	self:refreshReplay()
	notify.safeRegister(self, "notify_push", function (tag)
		self:refreshReplay()
	end)
end

function NAV_arena:refresh()
	local index = 1
	local ui = self.buttons[index].ui
	local redotCount = InfoArena.countRedot()
	local redot = ui:getComponentByTag("redot")

	redot:setVisible(redotCount > 0)
end

function NAV_arena:refreshReplay()
	local index = 2
	local ui = self.buttons[index].ui
	local redotCount = InfoArena.countRedot()
	local redot = ui:getComponentByTag("redot")

	redot:setVisible(InfoArena.replayCount() > 0)
end

function NAV_arena:onTap(index)
	NAV_arena.super.onTap(self, index)

	if index == 1 then
		FRAME_arena.open(self.npc)
	elseif index == 2 then
		InfoArena.replayClear()
		self:refreshReplay()
		FRAME_arena_replay.open(self.npc)
	elseif index == 3 then
		FRAME_any_shop.open(InfoArena, self.npc)
	elseif index == 4 then
		FRAME_arena_ready.open(FRAME_arena_ready.SIDE.DEFENCE, self)
	end
end

return NAV_arena
