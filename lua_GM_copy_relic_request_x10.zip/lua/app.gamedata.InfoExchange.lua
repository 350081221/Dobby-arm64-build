local Scheduler = cc.Director:getInstance():getScheduler()
local InfoExchange = {}
local rawData = {}
local apprData = {}
local stallName = ""
local stallStar = 0
local catalogData = nil

function InfoExchange.init()
	Connection.listen("exchange_sync", InfoExchange.sync)

	local function callback(dt)
		InfoExchange.checkSys()
	end

	local callbackEntry = Scheduler:scheduleScriptFunc(callback, 443, false)
end

app:addToAppEnterCall(InfoExchange.init)

function InfoExchange.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoExchange.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("exchange_query", callback)
end

function InfoExchange.onQuery(rcvData)
	rawData = {}

	for i, data in ipairs(rcvData.list) do
		rawData[data.sell_index] = data
	end

	apprData = {}

	if not empty(rcvData.appr) then
		apprData = json.decode(rcvData.appr)
	end

	stallName = rcvData.stall_name
	stallStar = rcvData.score
	catalogData = nil

	if not empty(rcvData.catalog_select) then
		catalogData = json.decode(rcvData.catalog_select)
	end
end

function InfoExchange.sync(data)
	dump(data, "$$$ InfoExchange.sync")

	for i, syncData in ipairs(data.list) do
		local sell_index = syncData.sell_index

		if rawData[sell_index] then
			for k, v in pairs(syncData) do
				rawData[sell_index][k] = v
			end
		else
			rawData[sell_index] = syncData
		end
	end

	ManagerInfo.dataChange("exchange")
end

local closedIDMap = {}

function InfoExchange.clear()
	InfoExchange.clearClosedID()
end

function InfoExchange.clearClosedID()
	closedIDMap = {}
end

function InfoExchange.addClosedID(id)
	closedIDMap[id] = true
end

local stalledIDMap = {}

function InfoExchange.clearStalledID()
	stalledIDMap = {}
end

function InfoExchange.addStalledID(id)
	stalledIDMap[id] = true
end

function InfoExchange.sell(sell_index, item_id, num, price, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if rcvData.err == "exchange_sell_err_price" then
				InfoExchange.getPrice()
			end

			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("exchange_sell", {
		sell_index = sell_index,
		item_id = item_id,
		num = num,
		price = price
	}, callback)
end

function InfoExchange.setAppr(_apprData, stall_name, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			apprData = _apprData
			stallName = stall_name

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("exchange_set_appr", {
		appr = json.encode(_apprData),
		stall_name = stall_name
	}, callback)
end

function InfoExchange.setCatalog(_catalogData, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			catalogData = _catalogData

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("exchange_select_catalog", {
		catalog_select = json.encode(_catalogData)
	}, callback)
end

function InfoExchange.getStalls(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("exchange_get_stalls", callback)
end

local priceMap, priceMapTime = nil
local priceMapTimeout = 0

function InfoExchange.getPrice(onSuccess, onFailure)
	local now = Time.time()

	if priceMap and priceMapTime and now < priceMapTime then
		if onSuccess then
			onSuccess()
		end

		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			priceMap = {}
			priceMapTime = now + priceMapTimeout
			local exchange_items_list = CsvParser.getCsvList("exchange_items")

			for i, v in ipairs(exchange_items_list) do
				priceMap[v.id] = 100
			end

			for i, v in ipairs(rcvData.price_arr) do
				priceMap[v.item_id] = v.price
			end

			notify.dispatch("exchange_price_changed")

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("exchange_get_price", callback)
end

function InfoExchange.getPricePercent(item_id)
	return priceMap[item_id] or 100
end

function InfoExchange.getFreeSellIndex()
	for sell_index = 1, GameConfig.exchange_sell_max do
		if not rawData[sell_index] or rawData[sell_index].open == 0 then
			return sell_index
		end
	end
end

function InfoExchange.getBlanketByItem(itemID)
	local csv = nil

	if not empty(itemID) then
		csv = CsvParser.getCsvData("exchange_blanket", itemID)
	end

	csv = csv or CsvParser.getCsvData("exchange_blanket", MiscConfig.DEFAULT_BLANKET)

	return csv.model
end

function InfoExchange.getBlanketList()
	local blanket_csv_list = CsvParser.getCsvList("exchange_blanket")
	local arr = {}

	for i, v in ipairs(blanket_csv_list) do
		if InfoItem.getNum(v.id) > 0 then
			table.insert(arr, {
				type = DropManager.TYPE.ITEM,
				info = {
					num = 1,
					base_id = v.id
				}
			})
		end
	end

	return arr
end

function InfoExchange.isApprEmpty()
	return empty(apprData) or empty(stallName)
end

function InfoExchange.getApprData()
	return apprData
end

function InfoExchange.getStallName()
	return stallName
end

function InfoExchange.getStallScore()
	return stallStar
end

function InfoExchange.getStallStar(score)
	local csvList = CsvParser.getCsvList("exchange_score")
	local csv = nil

	for i, v in ipairs(csvList) do
		if v.id <= score then
			csv = v
		else
			break
		end
	end

	return csv
end

function InfoExchange.getSellInfo(sell_index)
	return rawData[sell_index]
end

function InfoExchange.getCatalogMap()
	local catalogMap = {}

	if catalogData == nil then
		local exchange_catalog_list = {
			1,
			2,
			3,
			4
		}

		for i, v in ipairs(exchange_catalog_list) do
			catalogMap[tostring(v)] = 1
		end
	else
		for i, v in ipairs(catalogData) do
			catalogMap[tostring(v)] = 1
		end
	end

	return catalogMap
end

function InfoExchange.getBuyCatalog()
	local catalogMap = InfoExchange.getCatalogMap()
	local exchange_catalog_list = CsvParser.getCsvList("exchange_catalog")
	local arr = {}

	for i, v in ipairs(exchange_catalog_list) do
		if catalogMap[tostring(v.id)] then
			table.insert(arr, v)
		end
	end

	return arr
end

local requesting, requested_map = nil

function InfoExchange.includeCatalog(item_id, catalog)
	local exchangeCSV = CsvParser.getCsvData("exchange_items", item_id)
	local catalogs = SheetUtil.getColumnValueList(exchangeCSV, "catalog_")

	for i, v in ipairs(catalogs) do
		if v == catalog then
			return true
		end
	end
end

function InfoExchange.getBuyItems(catalog, stallData)
	print("$$$ getBuyItems", catalog, stallData)

	local arr = {}

	if stallData then
		table.insert(arr, {
			line = stallData.name,
			score = stallData.score
		})

		if stallData.goods then
			for i, v in ipairs(stallData.goods) do
				if v.open ~= 0 and not closedIDMap[v.id] and InfoExchange.includeCatalog(v.item_id, catalog) then
					InfoExchange.addStalledID(v.id)

					if not empty(v.item_id) then
						local exchangeCSV = CsvParser.getCsvData("exchange_items", v.item_id, nil, true)

						if exchangeCSV then
							table.insert(arr, {
								type = 1,
								data = v
							})
						end
					end
				end
			end
		end
	end

	table.insert(arr, {
		line = Localization.getSrcText("推荐的商品")
	})

	local goods = InfoExchange.getCachedGoods(catalog)

	for i, v in ipairs(goods) do
		table.insert(arr, v)
	end

	requesting = nil
	requested_map = {}

	return arr
end

local goodsCacheTimeout = 60
local goodsCacheTimeMap = {}
local goodsCacheMap = {}

function InfoExchange.onBuyOpen()
	InfoExchange.clearClosedID()
	InfoExchange.clearStalledID()

	local now = Time.time()
	local exchange_catalog_list = CsvParser.getCsvList("exchange_catalog")

	for i, v in ipairs(exchange_catalog_list) do
		local catalog = v.id
		local preTime = goodsCacheTimeMap[catalog]

		if not preTime or now > preTime + goodsCacheTimeout then
			goodsCacheMap[catalog] = {
				index = 1,
				arr = {}
			}
		end
	end
end

function InfoExchange.getCachedGoods(catalog)
	local cache = goodsCacheMap[catalog]
	local arr = {}

	for i, v in ipairs(cache.arr) do
		if v.open ~= 0 and not closedIDMap[v.id] and not stalledIDMap[v.id] then
			table.insert(arr, {
				type = 2,
				data = v
			})
		end
	end

	if cache.fin ~= 1 then
		table.insert(arr, {
			waiting_index = cache.index
		})
	end

	return arr
end

function InfoExchange.getMoreGoods(catalog, index)
	local cache = goodsCacheMap[catalog]

	if not requested_map[index] then
		if not requesting then
			InfoExchange.getGoodsList(catalog, index)
		end
	else
		local startIndex = requested_map[index]
		local arr = {}

		for i = startIndex, #cache.arr do
			local v = cache.arr[i]

			if v.open ~= 0 and not closedIDMap[v.id] and not stalledIDMap[v.id] and not empty(v.item_id) then
				local exchangeCSV = CsvParser.getCsvData("exchange_items", v.item_id, nil, true)

				if exchangeCSV then
					table.insert(arr, {
						type = 2,
						data = v
					})
				end
			end
		end

		if cache.fin ~= 1 then
			table.insert(arr, {
				waiting_index = cache.index
			})
		end

		return arr, cache.fin == 1
	end
end

function InfoExchange.getGoodsList(catalog, start_index, onSuccess, onFailure)
	local cache = goodsCacheMap[catalog]

	local function callback(rcvData)
		requesting = nil

		dump(rcvData, "exchange_get_list", 10)

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			requested_map[start_index] = #cache.arr + 1
			local list = rcvData.list

			for i, v in ipairs(list) do
				table.insert(cache.arr, v)
			end

			cache.fin = rcvData.fin
			cache.index = rcvData.end_index + 1
			local now = Time.time()
			goodsCacheTimeMap[catalog] = now

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	requesting = true

	Connection.request("exchange_get_list", {
		catalog = catalog,
		start_index = start_index
	}, callback)
end

function InfoExchange.buy(type, id, info, onSuccess, onFailure)
	print("$$$ InfoExchange.buy", type, id)

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("exchange_buy", {
		type = type,
		id = id,
		item_id = info.data.item_id,
		item_num = info.data.item_num,
		price = info.data.price
	}, callback)
end

function InfoExchange.takeback(id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("exchange_takeback", {
		id = id
	}, callback)
end

function InfoExchange.checkSys(onSuccess, onFailure)
	if not rawData then
		return
	end

	local id_list = {}
	local now = Time.now()

	for sell_index, data in pairs(rawData) do
		if data.open ~= 0 and data.sys_time < now then
			table.insert(id_list, data.id)
		end
	end

	dump(id_list, "$$$ checkSys")

	if #id_list == 0 then
		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("exchange_check_sys", {
		list = id_list
	}, callback)
end

function InfoExchange.testFake(onSuccess, onFailure)
	if not rawData then
		return
	end

	local id_list = {}
	local now = Time.now()

	for sell_index, data in pairs(rawData) do
		if data.open ~= 0 then
			table.insert(id_list, data.id)
		end
	end

	if #id_list == 0 then
		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("exchange_test_fake", {
		list = id_list
	}, callback)
end

function InfoExchange.need(catalogMap, onSuccess, onFailure)
	if catalogData == nil then
		return
	end

	local arr = {}

	for catalog, v in pairs(catalogMap) do
		table.insert(arr, catalog)
	end

	if #arr == 0 then
		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("exchange_need", {
		list = arr
	}, callback)
end

return InfoExchange
