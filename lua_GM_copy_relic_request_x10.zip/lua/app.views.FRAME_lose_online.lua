local FRAME_lose_online = class("FRAME_lose_online", UI_base)

function FRAME_lose_online.open(onComplete)
	local ui = FRAME_lose_online.new(onComplete)

	PopManager.open(ui, nil, , PopManager.ANIM_TYPE.JUMP, 100)
end

function FRAME_lose_online:ctor(onComplete)
	FRAME_lose_online.super.ctor(self, "frame_lose_online")

	self.onComplete = onComplete

	self:init()
end

function FRAME_lose_online:init()
	self.noCloseByKey = true

	self:initUI()
end

function FRAME_lose_online:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local mask = self:getComponentByTag("mask")

	mask:toTouchable()
	mask:setOpacity(0)

	local str = Localization.getSrcText("进入观察模式等待其他玩家完成任务，或者返回营地")
	str = string.gsub(str, "\\n", "\n")

	self:createLabelOnFlag("flag_desc", str, {
		wrap = true
	})

	local function onOpenOp()
		local scene = display.getRunningScene()

		scene:openOpMode()
		PopManager.close()

		if self.onComplete then
			self.onComplete()
		end
	end

	local opButton = self:getComponentByTag("bt_op")

	opButton:toTouchable()
	opButton:addTap(onOpenOp)
	opButton:setTapGroup("button_click")
end

return FRAME_lose_online
