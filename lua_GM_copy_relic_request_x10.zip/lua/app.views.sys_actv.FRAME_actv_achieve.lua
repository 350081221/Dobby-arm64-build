local UI_base = import("..UI_base")
local FRAME_actv_achieve = class("FRAME_actv_achieve", UI_base)

function FRAME_actv_achieve.open()
	local ui = FRAME_actv_achieve.new()

	PopManager.open(ui)
end

function FRAME_actv_achieve:ctor(uiName, data)
	FRAME_actv_achieve.super.ctor(self, "iframe_actv_achieve")

	self.actv_type = data and data.actv_type
	self.actv_id = data and data.actv_id

	self:init()
end

function FRAME_actv_achieve:init()
	self:initUI()
	self:refresh()
	ManagerInfo.onDataChange(self, "actv_achieve", nil, function ()
		self:refresh()
	end)
end

function FRAME_actv_achieve:resetData(data)
	if data then
		self.actv_type = data and data.actv_type
		self.actv_id = data and data.actv_id

		self:refresh()
	end
end

function FRAME_actv_achieve:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local function tapListener(ui, data, index, x, y)
		local worldPos = self.list:convertToWorldSpace(cc.p(x, y))

		if ui:hitTestByComponent("bt_get", worldPos.x, worldPos.y, true) then
			if InfoActvAchieve.rewardAlready(self.actv_id, self.actv_type) then
				-- Nothing
			else
				local function onClick()
					local ok = InfoActvAchieve.rewardReady(self.actv_id, self.actv_type)

					if ok then
						InfoActvAchieve.getReward(self.actv_id, self.actv_type, function (rcvData)
							local rewards = rcvData.rewards

							if rewards and #rewards > 0 then
								POP_reward.openMixed(rewards, nil, Localization.getSrcText("获得奖励"))
							end
						end)
					else
						Alert.open(Localization.getSrcText("尚未完成所有目标"))
					end
				end

				local getButton = ui:getComponentByTag("bt_get")
				local getButtonDisabled = ui:getComponentByTag("bt_get_disabled")

				if getButton and getButton:isVisible() then
					UIManager.callTapGroup("button_click", getButton, onClick)
				elseif getButtonDisabled and getButtonDisabled:isVisible() then
					UIManager.callTapGroup("button_click", getButtonDisabled, onClick)
				end
			end
		elseif ui.rewardSlots then
			for k, slot in pairs(ui.rewardSlots) do
				if slot:hitTestByComponent("bg", worldPos.x, worldPos.y, true) then
					UIManager.callTapGroup("slot_click", slot, function ()
						DropManager.popDetail(slot.type, slot.info)
					end)
				end
			end
		end
	end

	self.list = self:createListOnFlag("flag_list", LIST_actv_achieve, tapListener)
	local holder = self:getComponentByTag("holder")

	self.list:setHolders({
		holder
	}, nil, 5)
end

function FRAME_actv_achieve:refresh()
	local items = {}

	table.insert(items, {
		award = InfoActvAchieve.getAwardList(self.actv_id, self.actv_type)
	})

	local arr = InfoActvAchieve.getTargetList(self.actv_id, self.actv_type)

	for i, v in ipairs(arr) do
		table.insert(items, v)
	end

	self.list:setActv(self.actv_id, self.actv_type)
	self.list:setItems(items, true)
end

return FRAME_actv_achieve
