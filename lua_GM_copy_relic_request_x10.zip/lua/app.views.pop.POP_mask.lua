local POP_mask = class("POP_mask", UI_base)

function POP_mask.open(time, opacity, fromOpacity, color, onComplete, onClick, maskName, easing)
	local ui = nil

	if POP_mask.ui then
		ui = POP_mask.ui
	else
		ui = POP_mask.new()

		display.getRunningScene():addChild(ui, LayerConfig.mask)

		POP_mask.ui = ui
	end

	ui:show(time, opacity, fromOpacity, color, onComplete, onClick, maskName, easing)

	return ui
end

function POP_mask.close()
	POP_mask.open(30, 0)
end

function POP_mask.openFlash(existingNode, onUp, upTime, downTime, intervalTime)
	upTime = upTime or 15
	intervalTime = intervalTime or upTime + 10
	downTime = downTime or 60
	local color = "243,240,233"
	local isAllowFlash = Cookie.get("isAllowFlash") or 1

	if isAllowFlash ~= 1 then
		color = "0,0,0"
	end

	local opacity = 255

	POP_mask.open(upTime, opacity, 0, color, function ()
		if onUp then
			onUp()
		end

		Looper.setTimeout(function ()
			POP_mask.open(downTime, 0, opacity, color, nil, , , "inQuad")
		end, intervalTime, existingNode)
	end, nil, , "outQuad")
end

function POP_mask:ctor()
	POP_mask.super.ctor(self, "pop_mask")
	self:init()
end

function POP_mask:init()
	self:initUI()
end

function POP_mask:initUI()
end

local maskNames = {
	"mask",
	"mask_1"
}

function POP_mask:show(time, opacity, fromOpacity, color, onComplete, onClick, maskName, easing)
	if color == nil or color == "" then
		color = "0,0,0"
	end

	if self.data then
		Looper.stopTween(self.data.tweenID)
	end

	maskName = maskName or "mask"
	local block = self:getComponentByTag(maskName)

	for i, v in ipairs(maskNames) do
		local com = self:getComponentByTag(v)

		com:setVisible(v == maskName)
	end

	if not self.data or self.data.color ~= color then
		if maskName == "mask" then
			block:setPos(0, 0)
			block:setSize(display.width, display.height)
		else
			block:setScale(4)
		end

		block:setCascadeOpacityEnabled(true)
		block:setOpacity(0)

		self.data = {
			opacity = fromOpacity or 0,
			color = color
		}
	end

	local colorArr = string.split(color, ",")

	block:setColor(cc.c3b(tonumber(colorArr[1]), tonumber(colorArr[2]), tonumber(colorArr[3])))

	if time == 0 then
		if opacity > 0 then
			block:setOpacity(opacity)

			self.data.opacity = opacity
		else
			self:removeSelf()
		end

		if onComplete then
			onComplete()
		end
	else
		local function onTweenUpdate()
			block:setOpacity(self.data.opacity)
		end

		local function onTweenComplete()
			if opacity <= 0 then
				self:removeSelf()
			end

			if onComplete then
				onComplete()
			end
		end

		onTweenUpdate()

		self.data.tweenID = Looper.tween(time, self.data, {
			opacity = opacity
		}, easing or "outQuad", onTweenComplete, onTweenUpdate)
	end

	if onClick then
		local mask = self:getComponentByTag("mask")

		if maskName ~= "mask" then
			mask:setOpacity(0)
		end

		mask:setVisible(true)
		mask:toTouchable()
		mask:addTap(function ()
			onClick()
		end)
	end
end

function POP_mask:onExit()
	POP_mask.super.onExit(self)

	POP_mask.ui = nil
end

return POP_mask
