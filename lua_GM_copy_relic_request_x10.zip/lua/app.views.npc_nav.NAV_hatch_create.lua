local NAV_base = import(".NAV_base")
local NAV_hatch_create = class("NAV_hatch_create", NAV_base)

function NAV_hatch_create.open(npc, pos)
	local ui = NAV_hatch_create.new(npc, pos)

	return ui
end

function NAV_hatch_create:ctor(npc, pos)
	NAV_hatch_create.super.ctor(self, npc, "nav_hatch_create")

	self.pos = pos
end

function NAV_hatch_create:init()
	NAV_hatch_create.super.init(self)

	local ui = self.buttons[1].ui
	local hatchNum = InfoPetHatch.getHatchNum()

	if hatchNum > 0 then
		local needItem = CsvParser.getCsvData("config", "extra_hatch_need").value
		local itemNumNeed = CsvParser.getCsvData("config", "extra_hatch_price" .. hatchNum).value
		local itemNum = InfoItem.getNum(needItem)
		local itemIcon = IconManager.getItemIcon(needItem)

		ui:createIconOnFlag("flag_icon", itemIcon, 100, true)

		local shadow = ui:createIconOnFlag("flag_icon_shadow", itemIcon, 99, true)

		shadow:setColor(cc.c3b(0, 0, 0))
		shadow:setOpacity(64)

		local color = nil

		if itemNum < itemNumNeed then
			color = Style.red
		end

		ui:createLabelOnFlag("flag_num", itemNumNeed, {
			color = color
		})
		ui:getComponentByTag("first"):setVisible(false)
	else
		ui:removeLabelOnFlag("flag_name")
		ui:removeLabelOnFlag("flag_num")
	end
end

function NAV_hatch_create:onTap(index)
	NAV_hatch_create.super.onTap(self, index)

	if index == 1 then
		if global.player then
			global.player:faceTo(self.npc)
		end

		local function doCreate()
			InfoPetHatch.create(self.pos, function ()
				if global.player then
					global.player:npcChanged(true)
				end
			end)
		end

		local hatchNum = InfoPetHatch.getHatchNum()
		local itemNumNeed = 0
		local itemNum = 0
		local needItem = nil

		if hatchNum > 0 then
			needItem = CsvParser.getCsvData("config", "extra_hatch_need").value
			itemNumNeed = CsvParser.getCsvData("config", "extra_hatch_price" .. hatchNum).value
			itemNum = InfoItem.getNum(needItem)
		end

		if itemNumNeed > 0 then
			if itemNumNeed <= itemNum then
				local costItemCSV = CsvParser.getCsvData("item", needItem)
				local str = Localization.getSrcText("要花费[color={1}][{2}x{3}][/color]开启吗？")

				POP_notice.open(StringUtil.replace(str, Style.goldenStr, costItemCSV.name, itemNumNeed), doCreate)
			else
				Alert.open(Localization.getSrcText("开启材料不够"))
			end
		else
			doCreate()
		end
	end
end

return NAV_hatch_create
