local WebView = {
	open = function (path, x, y, width, height)
		print("$$$ WebView.open", ccexp.WebView)

		local webviewInstance = ccexp.WebView:create()

		print("$$$ webviewInstance", webviewInstance)
		webviewInstance:setContentSize(cc.size(width, height))
		webviewInstance:setScalesPageToFit(true)
		webviewInstance:setPosition(cc.p(x, y))
		webviewInstance:setAnchorPoint(cc.p(0, 0))
		webviewInstance:loadURL(path)

		return webviewInstance
	end
}

return WebView
