local List = import("...ui.List")
local LIST_hint_option = class("LIST_hint_option", List)

function LIST_hint_option:ctor(rect, cols)
	LIST_hint_option.super.ctor(self, rect)
	self:setCellName("cell_hint_option")

	self.isBounc = false

	self:setCellSize(cc.size(self.touchRect.width, 90))
end

function LIST_hint_option:onCellInit(ui, data, index)
	local bg = ui:getComponentByTag("bg")

	bg:addLabel(data.name)
end

return LIST_hint_option
