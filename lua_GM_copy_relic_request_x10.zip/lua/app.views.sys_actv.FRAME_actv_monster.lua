local UI_base = import("..UI_base")
local FRAME_actv_monster = class("FRAME_actv_monster", UI_base)

function FRAME_actv_monster.open()
	local ui = FRAME_actv_monster.new()

	PopManager.open(ui)
end

function FRAME_actv_monster:ctor(uiName, data)
	FRAME_actv_monster.super.ctor(self, "iframe_actv_monster")

	self.actv_id = data and data.actv_id

	self:init()
end

function FRAME_actv_monster:init()
	self:initUI()
	self:refresh()
	ManagerInfo.onDataChange(self, "actv_monster", nil, function ()
		self:refresh()
	end)
end

function FRAME_actv_monster:resetData(data)
	if data then
		self.actv_id = data and data.actv_id

		self:refresh()
	end
end

function FRAME_actv_monster:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local function tapListener(ui, data, index, x, y)
	end

	self.list = self:createListOnFlag("flag_list", LIST_actv_monster, tapListener)
	local holder = self:getComponentByTag("holder")

	self.list:setHolders({
		holder
	}, nil, 5)
end

function FRAME_actv_monster:refresh()
	local items = {}

	table.insert(items, {})

	local arr = InfoActvMonster.getMonsterList(self.actv_id)

	for i, v in ipairs(arr) do
		table.insert(items, v)
	end

	self.list:setActv(self.actv_id)
	self.list:setItems(items, true)
end

return FRAME_actv_monster
