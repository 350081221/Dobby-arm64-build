local NAV_base = import(".NAV_base")
local NAV_reclaim = class("NAV_reclaim", NAV_base)

function NAV_reclaim.open(npc)
	local ui = NAV_reclaim.new(npc)

	return ui
end

function NAV_reclaim:ctor(npc)
	NAV_reclaim.super.ctor(self, npc, "nav_reclaim")
end

function NAV_reclaim:init()
	NAV_reclaim.super.init(self)
end

function NAV_reclaim:onTap(index)
	NAV_reclaim.super.onTap(self, index)

	if index == 1 then
		InfoReclaim.getList(function (rcvData)
			if not self.npc then
				return
			end

			local arr = {}

			for i, v in ipairs(rcvData.equips) do
				table.insert(arr, {
					type = DropManager.TYPE.EQUIP,
					info = v
				})
			end

			for i, v in ipairs(rcvData.cards) do
				table.insert(arr, {
					type = DropManager.TYPE.CARD,
					info = v
				})
			end

			for i, v in ipairs(rcvData.sigils) do
				table.insert(arr, {
					type = DropManager.TYPE.SIGIL,
					info = v
				})
			end

			table.sort(arr, function (a, b)
				return b.info.index < a.info.index
			end)

			if #arr > 0 then
				FRAME_reclaim.open(self.npc, arr)
			else
				self.npc:say(Localization.getSrcText("没有找到遗失物品哟~"))
			end
		end)
	elseif index == 2 then
		FRAME_any_shop.open(InfoAbyssGift, self.npc)
	elseif index == 3 then
		FRAME_any_shop.open(InfoNaraka, self.npc)
	end
end

return NAV_reclaim
