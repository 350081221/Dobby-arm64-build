local LIST_benchmark = class("LIST_benchmark", List)

function LIST_benchmark:ctor(rect)
	LIST_benchmark.super.ctor(self, rect)
	self:setCellName("cell_benchmark")
	self:setSpace(0, 5)
	self:setCellSize(cc.size(self.touchRect.width, 50))
end

function LIST_benchmark:setOnModify(onModify)
	self.onModify = onModify
end

function LIST_benchmark:onCellInit(ui, data)
	ui:createLabelOnFlag("flag_name", data.name)

	local cookieValue = Cookie.get("benchmark_interval_" .. data.id)
	local value = cookieValue or data.defaultInterval
	local style = {}

	if cookieValue ~= data.defaultInterval then
		style.color = Style.blue
	end

	ui:createLabelOnFlag("flag_value", value, style)

	if ui.inputEB then
		ui.inputEB:removeSelf()
	end

	local onModify = self.onModify
	local inputEB = ui:createEditBoxOnComponent("bt_modify", function (event, editbox)
		if event == "began" then
			editbox:setText(data.debugValue or "")
		elseif event == "ended" then
			local text = editbox:getText()

			onModify(data, text)
		end
	end)

	inputEB:setOpacity(200)
	inputEB:setText(data.debugValue or "")

	ui.inputEB = inputEB
	local cookieOpen = Cookie.get("benchmark_open_" .. data.id)
	local isOpen = nil

	if cookieOpen == nil then
		isOpen = true
	else
		isOpen = cookieOpen
	end

	local open = ui:getComponentByTag("open")

	open:setVisible(isOpen)

	local bg = ui:getComponentByTag("bg")

	bg:setOpacity(100)
end

return LIST_benchmark
