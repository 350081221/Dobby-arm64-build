local NAV_base = import(".NAV_base")
local NAV_bard = class("NAV_bard", NAV_base)

function NAV_bard.open(npc)
	local ui = NAV_bard.new(npc)

	return ui
end

function NAV_bard:ctor(npc)
	NAV_bard.super.ctor(self, npc, "nav_bard")
end

function NAV_bard:init()
	NAV_bard.super.init(self)
	self:setButtonVisible(2, false)

	local index = 3
	local opening = InfoParams.getValue("bard_ranking")

	self:setButtonVisible(index, opening == 1)
	self:refresh()
	ManagerInfo.onDataChange(self, {
		"book",
		"manual"
	}, nil, function ()
		self:refresh()
	end)
end

function NAV_bard:refresh()
	local index = 4
	local ui = self.buttons[index].ui
	local new = ui:getComponentByTag("new")

	new:setVisible(FRAME_manual.countRedot() > 0 or InfoManual.checkNewAll())
	new:setFrame(Localization.getNewFrame())
end

function NAV_bard:onTap(index)
	NAV_bard.super.onTap(self, index)
	global.player:faceTo(self.npc)

	if index == 1 then
		InfoBard.listen(function ()
			if global.main_bard then
				global.main_bard:popDetail(true)
			end
		end)
	elseif index == 2 then
		FRAME_book.open(self.npc)
	elseif index == 3 then
		FRAME_ranking.open(self.npc)
	elseif index == 4 then
		FRAME_manual.open()
	end
end

return NAV_bard
