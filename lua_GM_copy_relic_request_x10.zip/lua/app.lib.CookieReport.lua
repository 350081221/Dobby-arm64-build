local CookieReport = {}
local kvMap = {}

function CookieReport.init()
	local path = cc.FileUtils:getInstance():getWritablePath() .. "game_CookieReports.txt"

	if io.exists(path) then
		local contents = getFileString(path)
		local obj = json.decode(contents)

		if obj ~= nil then
			kvMap = obj
		end
	end
end

CookieReport.init()

function CookieReport.set(key, value, doFlush)
	kvMap[key] = value

	if doFlush then
		CookieReport.flush()
	end
end

function CookieReport.get(key)
	return kvMap[key]
end

function CookieReport.flush()
	local path = cc.FileUtils:getInstance():getWritablePath() .. "game_CookieReports.txt"
	local str = json.encode(kvMap)

	if str then
		io.writefile(path, str)
	end
end

return CookieReport
