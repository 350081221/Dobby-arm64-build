local UI_base = import("..UI_base")
local FRAME_top = class("FRAME_top", UI_base)
local TEAM_MAX = 3
local ptPerTile = 140
local heroIso = {
	{
		x = 2,
		y = 2
	},
	{
		x = 2,
		y = 1
	},
	{
		x = 2,
		y = 0
	}
}
local petIsoMap = {}
local isoDragThreshold = 10

function FRAME_top.open()
	local ui = FRAME_top.new()

	PopManager.open(ui)
end

function FRAME_top:ctor()
	FRAME_top.super.ctor(self, "frame_top", UIManager.BIG_TYPE.POP)
	self:init()
end

function FRAME_top:init()
	self:initUI()
	self:createTopUI()
end

function FRAME_top:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local center = self:getComponentByTag("center")
	local already = self:getComponentByTag("already")
	local die = self:getComponentByTag("die")

	center:setColor(MiscConfig.top_center)
	already:setColor(MiscConfig.top_already)
	die:setColor(MiscConfig.top_die)
end

function FRAME_top:isEnter(obj, exTopType)
	local mapType = obj.type

	if not mapType and exTopType[index] then
		mapType = exTopType[index].type
	end

	return mapType == "enter"
end

function FRAME_top:createTopUI()
	local topInfo = DungeonState.getMapTop(global.map.mapName)
	local alreadyMap = topInfo.already
	local viewMap = topInfo.view
	local corpseMap = DungeonState.getCorpseTop()
	local rect = self:getRectByFlag("flag_container")
	local panel = display.newClippingRectangleNode(rect)

	self:addChild(panel, 100)
	panel:setCascadeOpacityEnabled(true)

	local canvas = display.newNode()

	canvas:setPosition(rect.x + rect.width / 2, rect.y + rect.height / 2)
	panel:addChild(canvas)
	canvas:setCascadeOpacityEnabled(true)

	self.topCanvas = canvas
	local size = 50
	local minX = 10000
	local maxX = -10000
	local minY = 10000
	local maxY = -10000

	if global.map.top then
		local topMap = global.map.top.map
		local exTopType = global.map.top.exTopType
		local tileMap = global.map.top.tile
		local centerCode = tileMap[global.player.tile.tag]
		local topPosMap = {}
		self.topIconMap = {}

		for code, obj in pairs(topMap) do
			local link = obj.link
			local x = obj.x * size
			local y = -obj.y * size
			topPosMap[obj.x .. "_" .. obj.y] = code

			if viewMap[code] or self:isEnter(obj, exTopType) then
				local topNode = display.newNode()

				canvas:addChild(topNode, 100)
				topNode:setCascadeOpacityEnabled(true)
				topNode:setPosition(x, y)

				self.topIconMap[code] = topNode
				minX = math.min(minX, x - size)
				maxX = math.max(maxX, x + size)
				minY = math.min(minY, y - size)
				maxY = math.max(maxY, y + size)
				local topIcon = display.newSprite("#map_assets_top_" .. link)

				topIcon:setOpacity(200)
				topNode:addChild(topIcon, 100)

				if alreadyMap[code] == 1 or self:isEnter(obj, exTopType) then
					local icon = display.newSprite("#map_assets_top_block")

					icon:setOpacity(150)
					icon:setScale(0.9)
					topNode:addChild(icon)

					if centerCode == code then
						icon:setColor(MiscConfig.top_center)
					elseif corpseMap[code] then
						icon:setColor(MiscConfig.top_die)
					else
						icon:setColor(MiscConfig.top_already)
					end
				end

				local mapType = obj.type
				local mapType = obj.type
				local eventIndex = nil

				if not mapType and exTopType[tostring(code)] then
					mapType = exTopType[tostring(code)].type
					eventIndex = exTopType[tostring(code)].eventIndex
				end

				if mapType then
					local icon = display.newSprite("#map_assets_top_" .. mapType)
					local scale = 0.7

					icon:setScaleX(scale)
					icon:setScaleY(scale)
					topNode:addChild(icon)

					topNode.eventIcon = icon

					if eventIndex then
						local eventFin = 0
						local eventInfo = InfoDungeon.getEventInfo(eventIndex)

						if eventInfo then
							eventFin = eventInfo.fin
						end

						local finished = false

						if mapType == Rantile.MAP_TYPE.GLADIATOR then
							if GameConfig.gladiator_max < eventInfo.fin then
								local finalRelic = InfoDungeon.getFinalRelic(eventIndex)

								if not finalRelic or finalRelic.fin ~= 0 then
									finished = true
								end
							end
						elseif mapType == Rantile.MAP_TYPE.MINE then
							local dungeon_csv = InfoDungeon.getDungeonCSV()
							local mine_index = dungeon_csv.mine_index
							local already = InfoFurnace.getMineRecord(mine_index) > 0

							if eventFin <= 0 then
								finished = already

								if already then
									finished = false

									if false then
										finished = true
									end
								end
							end
						elseif topType == Rantile.MAP_TYPE.CHEST and eventInfo.data.tag == "chance" then
							finished = eventFin > 1
						else
							finished = eventFin > 0
						end

						if finished then
							icon:setColor(Style.gray)
							icon:setOpacity(200)
						else
							icon:setColor(Style.white)
							icon:setOpacity(255)
						end
					end
				end
			end
		end

		local scale = math.min(rect.width / (maxX - minX), rect.height / (maxY - minY))
		scale = math.min(1.5, scale)

		canvas:setScale(scale)

		local canvasX = rect.x + rect.width / 2 - (maxX + minX) * scale / 2
		local canvasY = rect.y + rect.height / 2 - (maxY + minY) * scale / 2

		canvas:setPosition(canvasX, canvasY)

		local bg = self:getComponentByTag("bg")

		bg:addTap(function (x, y)
			x = x / self:getBigScale()
			y = y / self:getBigScale()
			local topX = math.floor((x - canvasX) / scale / size + 0.5)
			local topY = math.floor((-y + canvasY) / scale / size + 0.5)
			local code = topPosMap[topX .. "_" .. topY]

			if code and (alreadyMap[code] == 1 or topMap[code] and self:isEnter(topMap[code], exTopType)) then
				local topObj = topMap[code]

				if topObj then
					local isTopConfirm = Cookie.get("isTopConfirm") or 1

					if isTopConfirm == 1 then
						POP_notice.open(Localization.getSrcText("确定要移动到所选位置吗？"), function ()
							if self.jumpToTop then
								self:jumpToTop(topObj)
							end

							PopManager.closeTo(self)
						end)
					else
						if self.jumpToTop then
							self:jumpToTop(topObj)
						end

						PopManager.closeTo(self)
					end
				end
			end
		end)

		return
	end

	local topNode = display.newNode()

	canvas:addChild(topNode, 100)

	local topX = 0
	local topY = 0
	local x = topX * size
	local y = topY * size

	topNode:setCascadeOpacityEnabled(true)
	topNode:setPosition(x, y)

	local minX = math.min(minX, x - size)
	local maxX = math.max(maxX, x + size)
	local minY = math.min(minY, y - size)
	local maxY = math.max(maxY, y + size)
	local topIcon = display.newSprite("#map_assets_top_0000")

	topIcon:setOpacity(200)
	topNode:addChild(topIcon, 100)

	local icon = display.newSprite("#map_assets_top_block")

	icon:setColor(MiscConfig.top_center)
	icon:setOpacity(150)
	icon:setScale(0.9)
	topNode:addChild(icon)

	local scale = 1.5

	canvas:setScale(scale)

	local canvasX = rect.x + rect.width / 2 - (maxX + minX) * scale / 2
	local canvasY = rect.y + rect.height / 2 - (maxY + minY) * scale / 2

	canvas:setPosition(canvasX, canvasY)

	local bg = self:getComponentByTag("bg")

	bg:addTap(function (x, y)
		local topX = math.floor((x - canvasX) / scale / size + 0.5)
		local topY = math.floor((-y + canvasY) / scale / size + 0.5)

		if topX == 0 and topY == 0 then
			POP_notice.open(Localization.getSrcText("确定要返回地城入口吗？"), function ()
				InfoDungeon.jumpToEnter()
				PopManager.close()
			end)
		end
	end)
end

function FRAME_top:jumpToTop(topObj)
	if not global.player then
		return
	end

	if WarMachine.on then
		return
	end

	if topObj.entrance then
		local plugEvent = MapEventManager.getEventByTile(topObj.entrance.x + topObj.xOffset, topObj.entrance.y + topObj.yOffset, "plug")

		if plugEvent then
			local plugCenter = MapEventManager.getEventCenterTile(plugEvent)
			local teleportEvent = MapEventManager.findLinkOne(plugEvent, "teleport")
			local teamCount = math.max(2, #TeamManager.getUnits())
			local pathArr = {}

			if teleportEvent then
				local x1, y1 = MapEventManager.getEventCenter(plugEvent)
				local x2, y2 = MapEventManager.getEventCenter(teleportEvent)
				local angle = math.atan2(y2 - y1, x2 - x1) * 180 / math.pi

				if angle < 0 then
					angle = angle + 360
				end

				if angle >= 45 and angle < 135 then
					table.insert(pathArr, global.map:getTile(teleportEvent.x, teleportEvent.y - 1))
					table.insert(pathArr, global.map:getTile(teleportEvent.x, teleportEvent.y - 1 + teamCount))
				elseif angle >= 135 and angle < 225 then
					table.insert(pathArr, global.map:getTile(teleportEvent.x + 1, teleportEvent.y))
					table.insert(pathArr, global.map:getTile(teleportEvent.x + 1 - teamCount, teleportEvent.y))
				elseif angle >= 225 and angle < 315 then
					table.insert(pathArr, global.map:getTile(teleportEvent.x, teleportEvent.y + 1))
					table.insert(pathArr, global.map:getTile(teleportEvent.x, teleportEvent.y + 1 - teamCount))
				else
					table.insert(pathArr, global.map:getTile(teleportEvent.x - 1, teleportEvent.y))
					table.insert(pathArr, global.map:getTile(teleportEvent.x - 1 + teamCount, teleportEvent.y))
				end

				global.player:setMapTouchEnabled(false)
				global.player:setGoDirectionLocked("teleport", true)

				Monster.noCheckBattle = true
				local mapX, mapY = global.map:tileToMap(pathArr[1])

				global.player:draw(mapX, mapY, true)
				global.player:goPath({
					pathArr[2]
				}, true)

				local function releaseFromTeleport()
					DungeonState.flush()
					Log.verbose("teleport releaseFromTeleport")
					global.player:setMapTouchEnabled(true)
					global.player:setGoDirectionLocked("teleport", false)

					Monster.noCheckBattle = false
					local monsters = Monster.getAllMonster()

					for i = 1, #monsters do
						monsters[i]:checkBattle()
					end
				end

				global.player:setPathFinishedCallback(releaseFromTeleport)
			else
				local plugCenter = MapEventManager.getEventCenterTile(plugEvent)
				local enterX = plugCenter.x
				local enterY = plugCenter.y
				local destTile = plugCenter
				local direction = topObj.entrance.direction
				local angle = 0

				if direction == 0 then
					angle = math.pi / 2 * 3
					destTile = global.map:getTile(plugCenter.x, plugCenter.y + 1 - teamCount)
				elseif direction == 1 then
					angle = 0
					destTile = global.map:getTile(plugCenter.x - 1 + teamCount, plugCenter.y)
				elseif direction == 2 then
					angle = math.pi / 2
					destTile = global.map:getTile(plugCenter.x, plugCenter.y - 1 + teamCount)
				elseif direction == 3 then
					angle = math.pi
					destTile = global.map:getTile(plugCenter.x + 1 - teamCount, plugCenter.y)
				end

				Monster.noCheckBattle = true
				local mapX, mapY = global.map:tileToMap(destTile)

				global.player:draw(mapX, mapY, true)
				global.player:setGoDirectionLocked("enterDest", true)

				global.player.angle = angle

				global.player:fillTrain()
				global.player:checkTrain()

				local units = global.player:getTrainUnits()

				for i, unit in ipairs(units) do
					unit.angle = angle
					local effectGen = unit:getEffectGen()

					if effectGen then
						effectGen:zmove(0, 1000)
					end

					local function fall()
						local effectGen = unit:getEffectGen()

						if effectGen then
							if i == #units then
								effectGen:zmove(60, 0, nil, function ()
									DungeonState.flush()
									MapEffect.quake()
									global.player:clearGoDirectionLocked()

									Monster.noCheckBattle = nil
								end)
							else
								effectGen:zmove(60, 0, nil, function ()
									MapEffect.quake()
								end)
							end
						end
					end

					MapFrameManager.setTimeout(fall, 10 * (i - 1))
				end
			end
		end
	else
		InfoDungeon.jumpToEnter()
	end
end

function FRAME_top:getJumpEvent(code)
	if not self.eventCodeMap then
		self.eventCodeMap = {}
		local tileMap = global.map.top.tile
		local eventDataArray = MapEventManager.getEventByTagArray("top_jump")

		if eventDataArray then
			for i, eventData in ipairs(eventDataArray) do
				local tileCode = tileMap[eventData.x .. "_" .. eventData.y]
				self.eventCodeMap[tileCode] = eventData
			end
		end
	end

	if self.eventCodeMap[code] then
		local wayEvent = MapEventManager.findLinkOne(self.eventCodeMap[code], "top_jump_way")

		return self.eventCodeMap[code], wayEvent
	end
end

return FRAME_top
