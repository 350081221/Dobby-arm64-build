local List = import("...ui.List")
local LIST_achieve = class("LIST_achieve", List)

function LIST_achieve:ctor(rect)
	LIST_achieve.super.ctor(self, rect)
	self:setCellName("cell_achieve")
	self:setSpace(0, 0)
	self:setCellSize(cc.size(self.touchRect.width, 110))
end

function LIST_achieve:onCellInit(ui, data)
	if not ui.slot then
		ui.slot = DropSlot.new(ui:getFlagByTag("flag_reward_icon"), "slot_04")

		ui:addChild(ui.slot, 100)
		ui:createBarByTag("count_bar")
	end

	local csv = data.csv
	local count = data.count

	ui:createIconOnFlag("flag_icon", IconManager.getAchieveIcon(csv.id), 100, true)
	ui:createLabelOnFlag("flag_name", csv.name)
	ui:createLabelOnFlag("flag_desc", csv.desc)
	ui:setBarProgressByTag("count_bar", math.min(1, count / csv.value))

	local style = {
		color = Style.font3
	}

	ui:replaceLabelGroupOnFlag("flag_count", {
		StringUtil.simplifyNumber(math.min(count, csv.value)),
		StringUtil.simplifyNumber(csv.value)
	}, {
		style,
		style
	})

	local rewards = SheetUtil.getColumnList(csv, {
		"reward_id_",
		"reward_num_"
	}, {
		"base_id",
		"num"
	})

	ui.slot:setDrop(DropManager.TYPE.ITEM, rewards[1])

	if csv.value <= count then
		ui.slot:setBorderColor(Style.gold)
	else
		ui.slot:setBorderColor(Style.white)
	end
end

return LIST_achieve
