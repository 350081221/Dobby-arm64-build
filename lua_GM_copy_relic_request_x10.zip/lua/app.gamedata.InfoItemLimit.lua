local InfoItemLimit = {}
local rawData = {}

function InfoItemLimit.init()
	Connection.listen("item_limit_sync", InfoItemLimit.sync)
end

app:addToAppEnterCall(InfoItemLimit.init)

function InfoItemLimit.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoItemLimit.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("item_limit_query", callback)
end

function InfoItemLimit.onQuery(rcvData)
	rawData = {}

	for i = 1, #rcvData.list do
		local data = rcvData.list[i]
		rawData[data.base_id] = data
	end
end

function InfoItemLimit.sync(data)
	for i, syncData in ipairs(data.list) do
		local base_id = syncData.base_id

		if not rawData[base_id] then
			rawData[base_id] = syncData
		else
			for k, v in pairs(syncData) do
				rawData[base_id][k] = v
			end
		end
	end

	ManagerInfo.dataChange("item_limit")
end

function InfoItemLimit.getCount(base_id)
	local item_csv = CsvParser.getCsvData("item", base_id)

	if not empty(item_csv.abyss_drop_limit) and not empty(item_csv.limit_refresh_type) and rawData[base_id] then
		local abyss_drop_count = rawData[base_id].abyss_drop_count
		local nowTime = Time.now()

		if RefreshManager.checkTimePassed(item_csv.limit_refresh_type, nowTime, rawData[base_id].abyss_drop_time) then
			abyss_drop_count = 0
		end

		return abyss_drop_count
	end

	return 0
end

function InfoItemLimit.getLimitToday(nowTime, item_csv)
	local limit_refresh_type = item_csv.limit_refresh_type
	local abyss_drop_limit = item_csv.abyss_drop_limit
	local sharp = RefreshManager.getSharp(limit_refresh_type, nowTime)
	local random = Random.new(InfoUser.getID() + sharp + item_csv.id)
	local limitToday = SheetUtil.getNumber(abyss_drop_limit, random)

	return limitToday
end

function InfoItemLimit.getAbyssLimit(base_id)
	local item_csv = CsvParser.getCsvData("item", base_id)
	local prob = nil

	if not empty(item_csv.abyss_drop_limit) and not empty(item_csv.limit_refresh_type) and rawData[base_id] then
		local abyss_drop_count = rawData[base_id].abyss_drop_count
		local nowTime = Time.now()

		if RefreshManager.checkTimePassed(item_csv.limit_refresh_type, nowTime, rawData[base_id].abyss_drop_time) then
			abyss_drop_count = 0
		end

		local todayLimit = InfoItemLimit.getLimitToday(nowTime, item_csv)
		prob = math.sqrt(math.max(0, todayLimit - abyss_drop_count) / todayLimit)
	end

	if (not prob or prob > 0) and not empty(item_csv.convert_item) then
		base_id = item_csv.convert_item
		item_csv = CsvParser.getCsvData("item", base_id)

		if not empty(item_csv.abyss_drop_limit) and not empty(item_csv.limit_refresh_type) and rawData[base_id] then
			local abyss_drop_count = rawData[base_id].abyss_drop_count
			local nowTime = Time.now()

			if RefreshManager.checkTimePassed(item_csv.limit_refresh_type, nowTime, rawData[base_id].abyss_drop_time) then
				abyss_drop_count = 0
			end

			local todayLimit = InfoItemLimit.getLimitToday(nowTime, item_csv)
			prob = math.sqrt(math.max(0, todayLimit - abyss_drop_count) / todayLimit)
		end
	end

	if prob and prob > 0 then
		local min_drop_prob = CsvParser.getCsvData("config", "min_drop_prob").value
		prob = math.max(prob, min_drop_prob)
	end

	return prob
end

return InfoItemLimit
