local LIST_dungeon_result = import("...ui.List")
local LIST_dungeon_result = class("LIST_dungeon_result", LIST_dungeon_result)

function LIST_dungeon_result:ctor(rect, lineNum)
	LIST_dungeon_result.super.ctor(self, rect)
	self:setCellName("cell_dungeon_result")

	self.lineNum = lineNum

	self:setCellSize(cc.size(90, self.touchRect.height))
end

function LIST_dungeon_result:getCellName(index)
	local data = self.items[index]

	if data.label then
		return "cell_dungeon_result_label"
	else
		return self.cellName
	end
end

function LIST_dungeon_result:getCellSize(index)
	local data = self.items[index]

	if data.label then
		return cc.size(self.touchRect.width, 50)
	else
		local h = nil

		if data.type == FRAME_dungeon_result.LIST_TYPE.reward_sell then
			h = math.ceil(#data.arr / self.lineNum) * 120 + 10
		else
			h = math.ceil(#data.arr / self.lineNum) * 90 + 10
		end

		return cc.size(self.touchRect.width, h)
	end
end

function LIST_dungeon_result:onCellInit(ui, data, index)
	if data.label then
		local label, labelWidth = ui:createLabelOnFlag("flag_label", data.label, data.style)
		local line = ui:getComponentByTag("line")
		local lineX = label:getPositionX() + labelWidth / 2 + 15
		local lineWidth = self.touchRect.width - lineX - 5

		if lineWidth > 0 then
			line:setVisible(true)
			line:setPos(lineX)
			line:setSize(lineWidth)
		else
			line:setVisible(false)
		end

		if not data.inited then
			data.inited = true

			ui:setOpacity(0)
			transition.fadeTo(ui, {
				opacity = 255,
				time = 0.1,
				easing = "sineOut"
			})
		else
			ui:setOpacity(255)
		end
	else
		if ui.coms then
			for i, com in ipairs(ui.coms) do
				com:removeSelf()
			end

			ui.coms = nil
		end

		local h = nil

		if data.type == FRAME_dungeon_result.LIST_TYPE.reward_sell then
			h = 120
		else
			h = 90
		end

		ui.coms = {}
		local startX = 5
		local startY = math.ceil(#data.arr / self.lineNum) * h + 10 - h
		local blockX = 0
		local blockY = 0

		for i, v in ipairs(data.arr) do
			local comName = "com_dungeon_result"

			if data.type == FRAME_dungeon_result.LIST_TYPE.reward_sell then
				comName = "com_dungeon_result_sell"
			end

			local com = UIManager.getUI(comName)

			com:setPosition(startX + blockX * 90, startY - blockY * h)
			ui:addChild(com, 100)
			table.insert(ui.coms, com)

			blockX = blockX + 1

			if self.lineNum <= blockX then
				blockX = 0
				blockY = blockY + 1
			end

			local slot = DropSlot.new(com:getFlagByTag("flag_slot"), "slot_01")

			com:addChild(slot, 100)

			com.slot = slot

			slot:setDrop(v.type, v.info)

			if data.type == FRAME_dungeon_result.LIST_TYPE.reward_sell then
				local itemCSV = CsvParser.getCsvData("item", v.info.base_id)

				com:createIconOnFlag("flag_coin_icon", IconManager.getItemIcon(itemCSV.sell_item), 100, true)
				com:createLabelOnFlag("flag_coin", itemCSV.sell_num * v.info.num)
			end

			if not data.inited then
				com:setOpacity(0)

				local delay = math.pow(i, 0.8) / 12

				transition.fadeTo(com, {
					opacity = 255,
					easing = "sineOut",
					time = 0.1,
					delay = delay
				})
			else
				com:setOpacity(255)
			end
		end

		data.inited = true
	end
end

function LIST_dungeon_result:onCellRemove(ui, data, index)
	if ui.coms then
		for i, com in ipairs(ui.coms) do
			com:removeSelf()
		end

		ui.coms = nil
	end
end

return LIST_dungeon_result
