local AstarTile = import(".AstarTile")
local BinaryHeap = import(".BinaryHeap")
local Astar = class("Astar")

function Astar:ctor(map)
	self.map = map
	self.walkLevel = 0
	self.heap = BinaryHeap(function (tileA, tileB)
		local fa = tileA:getF()
		local fb = tileB:getF()

		if fa == fb then
			return tileA.sortTag < tileB.sortTag
		else
			return fa < fb
		end
	end)
end

function Astar:digPath(startTile, walkLevel, size, maxStep, area, occupiedCheckUnit, smoothLevel, clippingMode, bestFunc, random)
	self.startTile = startTile
	self.endTile = endTile
	self.walkLevel = walkLevel
	self.clippingMode = clippingMode or 1
	self.size = size or 1
	self.occupiedCheckUnit = occupiedCheckUnit
	local map = self.map
	AstarTile.resetIndex = AstarTile.resetIndex + 1

	if AstarTile.resetIndex > 65535 then
		AstarTile.resetIndex = 0

		for x = 0, map.tileW - 1 do
			for y = 0, map.tileH - 1 do
				if map:isLegalTile(x, y) then
					map:getTile(x, y):reset()
				end
			end
		end
	end

	local current = startTile
	local path = {}
	local step = 0

	while maxStep > step and current ~= nil do
		table.insert(path, current)
		current:setClosed()

		local neibours = self:getNeibours(current)
		local neiboursInArea = {}

		for i = 1, #neibours do
			if area.x then
				if area.x <= neibours[i].x and area.y <= neibours[i].y and neibours[i].x <= area.x + area.width - self.size and neibours[i].y <= area.y + area.height - self.size then
					table.insert(neiboursInArea, neibours[i])
				end
			elseif area[neibours[i]:getTag()] then
				table.insert(neiboursInArea, neibours[i])
			end
		end

		current = nil

		if #neiboursInArea > 0 then
			if bestFunc then
				current = bestFunc(neiboursInArea)
			elseif random then
				current = neiboursInArea[random:getInt(1, #neiboursInArea)]
			else
				current = neiboursInArea[math.random(1, #neiboursInArea)]
			end

			step = step + 1
		else
			break
		end
	end

	local newPath = {}
	local cX, cY, oX, oY = nil

	if #path > 0 then
		if smoothLevel == 2 then
			currNode = path[1]

			table.insert(newPath, currNode)

			for i = 3, #path do
				if not self:getPoint(currNode, path[i], 0) then
					currNode = path[i - 1]

					table.insert(newPath, currNode)
				end
			end

			table.insert(newPath, path[#path - 1])

			path = newPath
		elseif smoothLevel == 1 then
			table.insert(newPath, path[1])

			for i = 2, #path do
				cX = path[i].x - path[i - 1].x
				cY = path[i].y - path[i - 1].y

				if cX ~= oX or cY ~= oY then
					if i ~= 2 then
						table.insert(newPath, path[i - 1])
					end

					oX = cX
					oY = cY
				end
			end

			table.insert(newPath, path[#path])

			path = newPath
		end
	end

	return path
end

function Astar:findPath(startTile, endTile, walkLevel, size, endTileMapCheck, occupiedCheckUnit, smoothLevel, clippingMode)
	self.startTile = startTile
	self.endTile = endTile
	self.walkLevel = walkLevel
	self.clippingMode = clippingMode or 0
	self.size = size or 1
	self.occupiedCheckUnit = occupiedCheckUnit
	local map = self.map
	AstarTile.resetIndex = AstarTile.resetIndex + 1

	if AstarTile.resetIndex > 65535 then
		AstarTile.resetIndex = 0

		for x = 0, map.tileW - 1 do
			for y = 0, map.tileH - 1 do
				if map:isLegalTile(x, y) then
					map:getTile(x, y):reset()
				end
			end
		end
	end

	local pathFound = false
	local current, endPoint = nil

	self.heap:clear()
	startTile:setOpen()
	startTile:setG(0)
	startTile:setH(endTile.x, endTile.y)
	startTile:setParent(startTile)
	self.heap:insert(startTile, startTile)

	while self.heap:getSize() > 0 and not pathFound do
		local value, data = self.heap:pop()
		current = data

		if endTileMapCheck == nil then
			if current == endTile then
				pathFound = true

				break
			end
		elseif endTileMapCheck(current) then
			endPoint = current
			pathFound = true

			break
		end

		current:setClosed()

		local neibours = self:getNeibours(current)

		for i = 1, #neibours do
			local neibour = neibours[i]

			if not neibour:getOpen() then
				neibour:setOpen()
				neibour:setH(endTile.x, endTile.y)
				neibour:setG(current:getG())
				neibour:setParent(current)
				self.heap:insert(neibour, neibour)
			else
				local tempF = neibour:getH() + current:getG() + neibour:getCost()

				if tempF < neibour:getF() then
					neibour:setG(current:getG())
					neibour:setParent(current)
				end
			end
		end
	end

	local path = {}

	if pathFound then
		local tempPath = {}

		while current ~= startTile do
			table.insert(tempPath, current)

			current = current:getParent()
		end

		table.insert(tempPath, startTile)

		for i = #tempPath, 1, -1 do
			table.insert(path, tempPath[i])
		end
	end

	local newPath = {}
	local cX, cY, oX, oY = nil

	if #path > 0 then
		if smoothLevel == 2 then
			local currNode = path[1]

			table.insert(newPath, currNode)

			for i = 3, #path do
				if not self:getPoint(currNode, path[i], 0) then
					currNode = path[i - 1]

					table.insert(newPath, currNode)
				end
			end

			table.insert(newPath, path[#path - 1])

			path = newPath
		elseif smoothLevel == 1 then
			table.insert(newPath, path[1])

			for i = 2, #path do
				cX = path[i].x - path[i - 1].x
				cY = path[i].y - path[i - 1].y

				if cX ~= oX or cY ~= oY then
					if i ~= 2 then
						table.insert(newPath, path[i - 1])
					end

					oX = cX
					oY = cY
				end
			end

			table.insert(newPath, path[#path])

			path = newPath
		end
	end

	return path, pathFound
end

function Astar:setPathLimited(tileMap)
	self.limitedTileMap = tileMap
end

function Astar:clearPathLimited()
	self.limitedTileMap = nil
end

function Astar:isWalkable(tile, walkLevel)
	if self.limitedTileMap and not self.limitedTileMap[tile.tag] then
		return false
	end

	if Map.walkOnVislble and (self.map.areaWidth < math.abs(tile.x - self.startTile.x) or self.map.areaWidth < math.abs(tile.y - self.startTile.y)) then
		return false
	end

	walkLevel = walkLevel or self.walkLevel

	if self.size == 1 then
		return tile:getWalkable(walkLevel, self.occupiedCheckUnit)
	else
		for i = 0, self.size - 1 do
			for j = 0, self.size - 1 do
				local tempTile = self.map:getTile(tile.x + i, tile.y + j)

				if tempTile ~= nil and not tempTile:getWalkable(walkLevel, self.occupiedCheckUnit) then
					return false
				end
			end
		end

		return true
	end
end

function Astar:getNeibours(tile)
	local returnArray = {}
	local x = tile.x
	local y = tile.y
	local yxd = self.map:getTile(x - 1, y)

	if yxd ~= nil and self:isWalkable(yxd) and not yxd:getClosed() and not tile:getBorder(0) then
		table.insert(returnArray, yxd)
		yxd:costDown()
	end

	local yxu = self.map:getTile(x + 1, y)

	if yxu ~= nil and self:isWalkable(yxu) and not yxu:getClosed() and not tile:getBorder(2) then
		table.insert(returnArray, yxu)
		yxu:costDown()
	end

	local yux = self.map:getTile(x, y + 1)

	if yux ~= nil and self:isWalkable(yux) and not yux:getClosed() and not tile:getBorder(1) then
		table.insert(returnArray, yux)
		yux:costDown()
	end

	local ydx = self.map:getTile(x, y - 1)

	if ydx ~= nil and self:isWalkable(ydx) and not ydx:getClosed() and not tile:getBorder(3) then
		table.insert(returnArray, ydx)
		ydx:costDown()
	end

	local ydxd, ydxu, yuxu, yuxd = nil

	if self.clippingMode == 1 then
		ydxd = self.map:getTile(x - 1, y - 1)

		if ydxd ~= null and self:isWalkable(ydxd) and not ydxd:getClosed() and ydx ~= null and yxd ~= null and self:isWalkable(ydx) and self:isWalkable(yxd) and not tile:getBorder(3) and not tile:getBorder(0) and not ydxd:getBorder(1) and not ydxd:getBorder(2) then
			table.insert(returnArray, ydxd)
			ydxd:costUp()
		end

		yuxd = self.map:getTile(x - 1, y + 1)

		if yuxd ~= null and self:isWalkable(yuxd) and not yuxd:getClosed() and yux ~= null and yxd ~= null and self:isWalkable(yux) and self:isWalkable(yxd) and not tile:getBorder(1) and not tile:getBorder(0) and not yuxd:getBorder(2) and not yuxd:getBorder(3) then
			table.insert(returnArray, yuxd)
			yuxd:costUp()
		end

		ydxu = self.map:getTile(x + 1, y - 1)

		if ydxu ~= null and self:isWalkable(ydxu) and not ydxu:getClosed() and ydx ~= null and yxu ~= null and self:isWalkable(ydx) and self:isWalkable(yxu) and not tile:getBorder(3) and not tile:getBorder(2) and not ydxu:getBorder(0) and not ydxu:getBorder(1) then
			table.insert(returnArray, ydxu)
			ydxu:costUp()
		end

		yuxu = self.map:getTile(x + 1, y + 1)

		if yuxu ~= null and self:isWalkable(yuxu) and not yuxu:getClosed() and yux ~= null and yxu ~= null and self:isWalkable(yux) and self:isWalkable(yxu) and not tile:getBorder(1) and not tile:getBorder(2) and not yuxu:getBorder(0) and not yuxu:getBorder(3) then
			table.insert(returnArray, yuxu)
			yuxu:costUp()
		end
	elseif self.clippingMode == 2 then
		ydxd = self.map:getTile(x - 1, y - 1)

		if ydxd ~= null and self:isWalkable(ydxd) and not ydxd:getClosed() then
			table.insert(returnArray, ydxd)
			ydxd:costUp()
		end

		yuxd = self.map:getTile(x - 1, y + 1)

		if yuxd ~= null and self:isWalkable(yuxd) and not yuxd:getClosed() then
			table.insert(returnArray, yuxd)
			yuxd:costUp()
		end

		ydxu = self.map:getTile(x + 1, y - 1)

		if ydxu ~= null and self:isWalkable(ydxu) and not ydxu:getClosed() then
			table.insert(returnArray, ydxu)
			ydxu:costUp()
		end

		yuxu = self.map:getTile(x + 1, y + 1)

		if yuxu ~= null and self:isWalkable(yuxu) and not yuxu:getClosed() then
			table.insert(returnArray, yuxu)
			yuxu:costUp()
		end
	end

	return returnArray
end

function Astar:getPointBlock(x, y, walkLevel)
	local tile = self.map:getTile(x, y)

	if tile == nil or not self:isWalkable(tile, walkLevel) or tile:getBorderFull() then
		return true
	end

	return false
end

function Astar:getPoint(la, lb, walkLevel)
	local dx = lb.x - la.x
	local dy = lb.y - la.y
	local x = la.x
	local y = la.y

	if self:getPointBlock(x, y, walkLevel) then
		return false
	end

	if dx == 0 then
		if dy > 0 then
			for y = la.y + 1, lb.y - 1 do
				if self:getPointBlock(x, y, walkLevel) then
					return false
				end
			end

			return true
		elseif dy < 0 then
			for y = lb.y + 1, la.y - 1 do
				if self:getPointBlock(x, y, walkLevel) then
					return false
				end
			end

			return true
		else
			return true
		end
	end

	if dy == 0 then
		if dx > 0 then
			for x = la.x + 1, lb.x - 1 do
				if self:getPointBlock(x, y, walkLevel) then
					return false
				end
			end

			return true
		else
			for x = lb.x + 1, la.x - 1 do
				if self:getPointBlock(x, y, walkLevel) then
					return false
				end
			end

			return true
		end
	end

	local k = dy / dx
	local e = -0.5

	if math.abs(k) < 1 then
		if dx > 0 and dy > 0 then
			for i = 0, dx - 1 do
				x = x + 1
				e = e + math.abs(k)

				if self:getPointBlock(x, y, walkLevel) then
					return false
				end

				if e >= 0 then
					y = y + 1
					e = e - 1

					if self:getPointBlock(x, y, walkLevel) then
						return false
					end

					if self:getPointBlock(x - 1, y, walkLevel) then
						return false
					end
				end
			end

			return true
		elseif dx > 0 and dy < 0 then
			for i = 0, dx - 1 do
				x = x + 1
				e = e + math.abs(k)

				if self:getPointBlock(x, y, walkLevel) then
					return false
				end

				if e >= 0 then
					y = y - 1
					e = e - 1

					if self:getPointBlock(x, y, walkLevel) then
						return false
					end

					if self:getPointBlock(x - 1, y, walkLevel) then
						return false
					end
				end
			end

			return true
		elseif dx < 0 and dy < 0 then
			for i = 0, -dx - 1 do
				x = x - 1
				e = e + math.abs(k)

				if self:getPointBlock(x, y, walkLevel) then
					return false
				end

				if e >= 0 then
					y = y - 1
					e = e - 1

					if self:getPointBlock(x, y, walkLevel) then
						return false
					end

					if self:getPointBlock(x + 1, y, walkLevel) then
						return false
					end
				end
			end

			return true
		elseif dx < 0 and dy > 0 then
			for i = 0, -dx - 1 do
				x = x - 1
				e = e + math.abs(k)

				if self:getPointBlock(x, y, walkLevel) then
					return false
				end

				if e >= 0 then
					y = y + 1
					e = e - 1

					if self:getPointBlock(x, y, walkLevel) then
						return false
					end

					if self:getPointBlock(x + 1, y, walkLevel) then
						return false
					end
				end
			end

			return true
		end

		return false
	else
		if dx > 0 and dy > 0 then
			for i = 0, dy - 1 do
				y = y + 1
				e = e + 1 / math.abs(k)

				if self:getPointBlock(x, y, walkLevel) then
					return false
				end

				if e >= 0 then
					x = x + 1
					e = e - 1

					if self:getPointBlock(x, y, walkLevel) then
						return false
					end

					if self:getPointBlock(x, y - 1, walkLevel) then
						return false
					end
				end
			end

			return true
		elseif dx < 0 and dy < 0 then
			for i = 0, -dy - 1 do
				y = y - 1
				e = e + 1 / math.abs(k)

				if self:getPointBlock(x, y, walkLevel) then
					return false
				end

				if e >= 0 then
					x = x - 1
					e = e - 1

					if self:getPointBlock(x, y, walkLevel) then
						return false
					end

					if self:getPointBlock(x, y + 1, walkLevel) then
						return false
					end
				end
			end

			return true
		elseif dx > 0 and dy < 0 then
			for i = 0, -dy - 1 do
				y = y - 1
				e = e + 1 / math.abs(k)

				if self:getPointBlock(x, y, walkLevel) then
					return false
				end

				if e >= 0 then
					x = x + 1
					e = e - 1

					if self:getPointBlock(x, y, walkLevel) then
						return false
					end

					if self:getPointBlock(x, y + 1, walkLevel) then
						return false
					end
				end
			end

			return true
		elseif dx < 0 and dy > 0 then
			for i = 0, dy - 1 do
				y = y + 1
				e = e + 1 / math.abs(k)

				if self:getPointBlock(x, y, walkLevel) then
					return false
				end

				if e >= 0 then
					x = x - 1
					e = e - 1

					if self:getPointBlock(x, y, walkLevel) then
						return false
					end

					if self:getPointBlock(x, y - 1, walkLevel) then
						return false
					end
				end
			end

			return true
		end

		return false
	end
end

return Astar
