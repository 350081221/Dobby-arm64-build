local ManagerInfo = {}
local dataChangeLocked, dataChangeLockedCache = nil

function ManagerInfo.clear()
	dataChangeLocked = nil
	dataChangeLockedCache = nil
end

function ManagerInfo.lockDataChange()
	dataChangeLockedCache = {}
	dataChangeLocked = true
end

function ManagerInfo.unlockDataChange()
	if dataChangeLockedCache then
		for key, v in pairs(dataChangeLockedCache) do
			notify.dispatch(key, v.keyStack, v.data)
		end
	end

	dataChangeLockedCache = nil
	dataChangeLocked = nil
end

function ManagerInfo.onDataChange(view, dataNameArray, dataID, func)
	if type(dataNameArray) ~= "table" then
		dataNameArray = {
			dataNameArray
		}
	end

	for i = 1, #dataNameArray do
		local dataName = dataNameArray[i]
		local key = dataName .. "_change"

		if dataID then
			key = key .. ":" .. dataID
		end

		if view then
			notify.safeRegister(view, key, func)
		else
			notify.register(key, func)
		end
	end
end

function ManagerInfo.dataChange(dataName, data, customKey)
	local keyStack = {}

	if data then
		for id, v in pairs(data) do
			local key = nil

			if v == 1 then
				key = dataName .. "_change:" .. id

				table.insert(keyStack, id)
			elseif customKey then
				key = dataName .. "_change:" .. v[customKey]

				table.insert(keyStack, v[customKey])
			else
				key = dataName .. "_change:" .. id

				table.insert(keyStack, id)
			end

			if dataChangeLocked then
				if not dataChangeLockedCache[key] then
					dataChangeLockedCache[key] = {}
				end
			else
				notify.dispatch(key)
			end
		end
	end

	local key = dataName .. "_change"

	if dataChangeLocked then
		if not dataChangeLockedCache[key] then
			dataChangeLockedCache[key] = {
				keyStack = keyStack,
				data = data
			}
		end
	else
		notify.dispatch(key, keyStack, data)
	end
end

function ManagerInfo.parse(text, isUbb)
	return StringUtil.replaceTag(text, function (tag)
		return ManagerInfo.parseTag(tag, isUbb)
	end)
end

function ManagerInfo.parseTag(tag, isUbb)
	local arr = string.split(tag, ".")
	local key = arr[1]
	local subKey = arr[2] or "name"
	local str = nil

	if key == "nickname" then
		return InfoUser.getNickName()
	elseif key == "player" then
		local heroInfo = InfoHero.getHero()

		if heroInfo[subKey] then
			str = heroInfo[subKey]
		else
			local heroData = CsvParser.getCsvData("hero", heroInfo.base_id, nil, true)

			if not heroData then
				return
			end

			str = heroData[subKey]
		end

		str = Localization.getText(str)

		if isUbb then
			return "[color=238,199,111]" .. str .. "[/color]"
		else
			return str
		end
	elseif string.sub(key, 1, 4) == "item" then
		local arr1 = string.split(key, ":")
		local itemData = CsvParser.getCsvData("item", arr1[2], nil, true)

		if not itemData then
			return
		end

		str = itemData[subKey]
		str = Localization.getText(str)

		if isUbb then
			return "[color=238,199,111]" .. str .. "[/color]"
		else
			return str
		end
	elseif string.sub(key, 1, 5) == "equip" then
		local arr1 = string.split(key, ":")
		local equipData = CsvParser.getCsvData("equip", arr1[2], nil, true)

		if not equipData then
			return
		end

		str = equipData[subKey]
		str = Localization.getText(str)

		if isUbb then
			return "[color=238,199,111]" .. str .. "[/color]"
		else
			return str
		end
	elseif string.sub(key, 1, 3) == "pet" then
		local arr1 = string.split(key, ":")
		local petData = CsvParser.getCsvData("pet", arr1[2], nil, true)

		if not petData then
			return
		end

		str = petData[subKey]
		str = Localization.getText(str)

		if isUbb then
			return "[color=238,199,111]" .. str .. "[/color]"
		else
			return str
		end
	elseif string.sub(key, 1, 3) == "npc" then
		local arr1 = string.split(key, ":")
		local npcData = CsvParser.getCsvData("npc", arr1[2], nil, true)

		if not npcData then
			return
		end

		str = npcData[subKey]
		str = Localization.getText(str)

		if isUbb then
			return "[color=238,199,111]" .. str .. "[/color]"
		else
			return str
		end
	elseif string.sub(key, 1, 3) == "mon" then
		local arr1 = string.split(key, ":")
		local monsterData = CsvParser.getCsvData("monster", arr1[2], nil, true)

		if not monsterData then
			return
		end

		str = monsterData[subKey]
		str = Localization.getText(str)

		if isUbb then
			return "[color=238,199,111]" .. str .. "[/color]"
		else
			return str
		end
	elseif string.sub(key, 1, 5) == "quest" then
		local arr1 = string.split(key, ":")
		local questData = CsvParser.getCsvData("quest", arr1[2], nil, true)

		if not questData then
			return
		end

		str = questData[subKey]
		str = Localization.getText(str)

		if isUbb then
			return "[color=238,199,111]" .. str .. "[/color]"
		else
			return str
		end
	elseif string.sub(key, 1, 7) == "dungeon" then
		local arr1 = string.split(key, ":")
		local dungeonID = arr1[2] or InfoDungeon.getID()
		local dungeonData = CsvParser.getCsvData("dungeon", dungeonID, nil, true)

		if not dungeonData then
			return
		end

		str = dungeonData[subKey]
		str = Localization.getText(str)

		if isUbb then
			return "[color=238,199,111]" .. str .. "[/color]"
		else
			return str
		end
	elseif string.sub(key, 1, 4) == "word" then
		local arr1 = string.split(key, ":")
		local wordData = CsvParser.getCsvData("word", arr1[2], nil, true)

		if not wordData then
			return
		end

		str = wordData.desc
		str = Localization.getText(str)

		if isUbb then
			return "[color=238,199,111]" .. str .. "[/color]"
		else
			return str
		end
	elseif string.sub(key, 1, 10) == "hero_equip" then
		local arr1 = string.split(key, ":")
		local equipData = InfoEquip.getEquipForPlayer(arr1[2])
		str = equipData[subKey]
		str = Localization.getText(str)

		if isUbb then
			return "[color=238,199,111]" .. str .. "[/color]"
		else
			return str
		end
	end
end

return ManagerInfo
