local List = import("...ui.List")
local LIST_dungeon_result_sell_reward = class("LIST_dungeon_result_sell_reward", List)

function LIST_dungeon_result_sell_reward:ctor(rect, cellName, cellWidth)
	LIST_dungeon_result_sell_reward.super.ctor(self, rect, List.DIRECTION_HORIZONTAL)

	self.isBounc = false

	self:setCellName(cellName or "cell_dungeon_result_sell_reward")
	self:setCellSize(cc.size(cellWidth or 150, self.touchRect.height))
	self:addEventListener("onTapListIcon", function (event)
		DropManager.popDetail(DropManager.TYPE.ITEM, event.data)
	end)
end

function LIST_dungeon_result_sell_reward:onCellInit(ui, data)
	local id = data.id or data.base_id
	local costData = CsvParser.getCsvData("item", id)
	local costPic = IconManager.getItemIcon(costData.id)

	ui:createLabelOnFlag("flag_num", data.num)

	local icon = ui:createIconOnFlag("flag_icon", costPic, 100, true)
	local shadow = ui:createIconOnFlag("flag_shadow", costPic, 90, true)

	shadow:setColor(cc.c3b(0, 0, 0))
	shadow:setOpacity(100)
end

return LIST_dungeon_result_sell_reward
