local InfoArtifact = {}
local rawData = {}
local artifactStarMap, artifactMaxStarMap = nil

function InfoArtifact.init()
	artifactStarMap = {}
	artifactMaxStarMap = {}
	local csvList = CsvParser.getCsvList("artifact_star")

	for i, csv in ipairs(csvList) do
		artifactMaxStarMap[csv.artifact_id] = math.max(csv.star, artifactMaxStarMap[csv.artifact_id] or 0)
		artifactStarMap[csv.artifact_id] = artifactStarMap[csv.artifact_id] or {}
		artifactStarMap[csv.artifact_id][csv.star] = csv
	end

	Connection.listen("artifact_sync", InfoArtifact.sync)
	Connection.listen("artifact_sync_remove", InfoArtifact.syncRemove)
end

app:addToAppEnterCall(InfoArtifact.init)

function InfoArtifact.sync(data)
	local changedIdStack = {}

	for i, syncData in ipairs(data.list) do
		if syncData.base_id ~= 0 then
			local id = syncData.id

			if not rawData[id] then
				rawData[id] = syncData
			else
				for k, v in pairs(syncData) do
					rawData[id][k] = v
				end
			end

			changedIdStack[id] = rawData[id]
		end
	end

	ManagerInfo.dataChange("artifact", changedIdStack)
end

function InfoArtifact.syncRemove(data)
	local changedIdStack = {}

	for i, id in ipairs(data.list) do
		if rawData[id] then
			changedIdStack[id] = rawData[id]
			rawData[id] = nil
		end
	end

	ManagerInfo.dataChange("artifact", changedIdStack)
end

function InfoArtifact.query(onSuccess, onFailure)
	rawData = {}
	local nextIndex, queryNext = nil

	function queryNext()
		local function callback(rcvData)
			if rcvData.err then
				if onFailure then
					onFailure()
				end
			else
				for i, data in ipairs(rcvData.list) do
					if data.base_id ~= 0 then
						rawData[data.id] = data
					end
				end

				if rcvData.next_index then
					nextIndex = rcvData.next_index

					queryNext()
				elseif onSuccess then
					onSuccess()
				end
			end
		end

		Connection.request("artifact_query", {
			start_index = nextIndex
		}, callback)
	end

	queryNext()
end

function InfoArtifact.on(artifactID, heroID, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("artifact_on", {
		hero_id = heroID,
		artifact_id = artifactID
	}, callback)
end

function InfoArtifact.off(artifactID, bag_index, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("artifact_off", {
		artifact_id = artifactID,
		bag_index = bag_index
	}, callback)
end

function InfoArtifact.lvup(artifactID, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("artifact_lvup", {
		artifact_id = artifactID
	}, callback)
end

function InfoArtifact.starup(artifactID, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("artifact_starup", {
		artifact_id = artifactID
	}, callback)
end

function InfoArtifact.changeAttr(artifactID, index, attr, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("artifact_change_attr", {
		artifact_id = artifactID,
		index = index,
		attr = attr
	}, callback)
end

function InfoArtifact.lock(artifactID, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("artifact_lock", {
		artifact_id = artifactID
	}, callback)
end

function InfoArtifact.dismiss(artifactID, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("artifact_dismiss", {
		artifact_id = artifactID
	}, callback)
end

function InfoArtifact.getDismissItems(artifactInfo)
	local artifactCSV = CsvParser.getCsvData("artifact", artifactInfo.base_id)
	local levelCSV = CsvParser.getCsvData("artifact_exp", artifactInfo.level)
	local starCostCSV = CsvParser.getCsvData("artifact_star_cost", artifactInfo.star)
	local itemMap = {}
	local itemArr = SheetUtil.getColumnList(artifactCSV, {
		"sell_item_",
		"sell_item_num_"
	}, {
		"base_id",
		"num"
	})

	for i, v in ipairs(itemArr) do
		itemMap[v.base_id] = (itemMap[v.base_id] or 0) + v.num
	end

	local itemArr = SheetUtil.getColumnList(levelCSV, {
		"sell_item_",
		"sell_item_num_"
	}, {
		"base_id",
		"num"
	})

	for i, v in ipairs(itemArr) do
		itemMap[v.base_id] = (itemMap[v.base_id] or 0) + v.num
	end

	local itemArr = SheetUtil.getColumnList(starCostCSV, {
		"sell_item_",
		"sell_item_num_"
	}, {
		"base_id",
		"num"
	})

	for i, v in ipairs(itemArr) do
		itemMap[v.base_id] = (itemMap[v.base_id] or 0) + v.num
	end

	local arr = {}

	for base_id, num in pairs(itemMap) do
		table.insert(arr, {
			base_id = base_id,
			num = num
		})
	end

	table.sort(arr, function (a, b)
		return a.base_id < b.base_id
	end)

	return arr
end

function InfoArtifact.getIDBybaseID(baseID)
	for id, artifactInfo in pairs(rawData) do
		if artifactInfo.base_id == baseID then
			return artifactInfo.id
		end
	end
end

function InfoArtifact.getInfo(id)
	return rawData[id]
end

function InfoArtifact.getEquipedHero(artifactInfo)
	if not empty(artifactInfo.hero_id) then
		return InfoHero.getHero(artifactInfo.hero_id)
	end
end

function InfoArtifact.getArtifactOnHero(heroID)
	if type(heroID) == "table" and heroID.artifact then
		return heroID.artifact
	else
		if type(heroID) == "table" then
			heroID = heroID.id
		end

		for id, artifactInfo in pairs(rawData) do
			if artifactInfo.hero_id == heroID then
				return artifactInfo
			end
		end
	end
end

function InfoArtifact.checkHeroSkill(artifactInfo)
	local heroInfo = nil

	if artifactInfo.isCopy then
		heroInfo = artifactInfo.heroInfo
	else
		heroInfo = InfoArtifact.getEquipedHero(artifactInfo)
	end

	if heroInfo then
		local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)
		local skillCSV = CsvParser.getCsvData("skill", heroCSV.skill_id)
		local starCSV = InfoArtifact.getStarCSV(artifactInfo)

		return starCSV.skill_filter == skillCSV.base_id
	end

	return false
end

function InfoArtifact.getSample(baseID)
	local artifactInfo = {
		star = 1,
		level = 1,
		ran = 0,
		base_id = baseID
	}

	return artifactInfo
end

function InfoArtifact.getWareList(filterFunc, sortFunc)
	local arr = {}

	for id, artifactInfo in pairs(rawData) do
		if not InfoCard.getEquipedHero(artifactInfo) then
			local tempData = {
				type = DropManager.TYPE.ARTIFACT,
				info = artifactInfo
			}

			if not filterFunc or filterFunc(tempData) then
				table.insert(arr, tempData)
			end
		end
	end

	local sortMethod = sortFunc or function (a, b)
		if a.info.star == b.info.star then
			if a.info.level == b.info.level then
				if a.info.base_id == b.info.base_id then
					return a.info.id < b.info.id
				else
					return a.info.base_id < b.info.base_id
				end
			else
				return b.info.level < a.info.level
			end
		else
			return b.info.star < a.info.star
		end
	end

	table.sort(arr, sortMethod)

	return arr
end

function InfoArtifact.getStar(artifactInfo)
	local starMax = artifactMaxStarMap[artifactInfo.base_id] or 0
	local starType = 1
	local starNum = 0

	if artifactInfo.star > 0 then
		starNum = (artifactInfo.star - 1) % 5 + 1
		starType = math.floor((artifactInfo.star - 1) / 5) + 1
	end

	return starType, starNum, starMax
end

function InfoArtifact.getAttrs(artifactInfo)
	local artifactCSV = CsvParser.getCsvData("artifact", artifactInfo.base_id)
	local arr = {}

	for i = 1, 3 do
		local attr = artifactInfo["attr_" .. i]

		if empty(attr) then
			attr = artifactCSV["attr_" .. i]
		end

		local attrCSV = CsvParser.getCsvData("artifact_attr", attr)
		local value = attrCSV.base + artifactInfo.level * attrCSV.add

		table.insert(arr, {
			attr = attr,
			value = value
		})
	end

	return arr
end

function InfoArtifact.getAllAttrs(artifactInfo)
	local attrList = CsvParser.getCsvList("artifact_attr")
	local arr = {}

	for i, attrCSV in ipairs(attrList) do
		local value = attrCSV.base + artifactInfo.level * attrCSV.add

		table.insert(arr, {
			attr = attrCSV.id,
			value = value
		})
	end

	return arr
end

function InfoArtifact.getStarCSV(artifactInfo, customStar)
	local starCSV = artifactStarMap[artifactInfo.base_id][customStar or artifactInfo.star]

	return starCSV
end

local scoreBuff = nil

function InfoArtifact.buffScoreStart()
	scoreBuff = {}
end

function InfoArtifact.buffScoreOver()
	scoreBuff = nil
end

function InfoArtifact.getScore(artifactInfo)
	if scoreBuff and scoreBuff[artifactInfo.id] then
		return scoreBuff[artifactInfo.id]
	end

	local attr = CombatAttr.getArtifactAttr(artifactInfo)
	local attr_raw = CsvParser.getCsvRaw("attr")
	local addTotal = 0

	for k, v in pairs(attr_raw) do
		if attr[k] and v.ability_value1 ~= 0 then
			addTotal = addTotal + attr[k] * v.ability_value1
		end
	end

	local score = math.floor(addTotal)

	if scoreBuff then
		scoreBuff[artifactInfo.id] = score
	end

	return score
end

local shopList = nil
local shopRefreshIndex = 0

function InfoArtifact.getShopLabels()
	local shopCSVList = CsvParser.getCsvList("artifact_shop_label")

	return shopCSVList
end

function InfoArtifact.clearOnReconnect()
	shopList = nil
end

function InfoArtifact.getShopList(_callback)
	local needQuery = shopList == nil

	if needQuery then
		local function callback(rcvData)
			dump(rcvData, "artifact_shop_list")

			if rcvData.err then
				-- Nothing
			else
				shopRefreshIndex = shopRefreshIndex + 1
				shopList = rcvData.items

				if _callback then
					_callback(shopList)
				end
			end
		end

		Connection.request("artifact_shop_list", callback)
	else
		_callback(shopList)
	end
end

function InfoArtifact.getShopItems()
	local abyssLevel = InfoDungeon.getAbyssMaxLevel()
	local arr = {}
	local multiLabel = nil
	local shopCSVList = CsvParser.getCsvList("artifact_shop_label")

	if #shopCSVList > 1 then
		local labelMap = {}

		for i, v in ipairs(shopList) do
			local shopCSV = CsvParser.getCsvData("artifact_shop", v.shop_id, nil, true)

			if shopCSV and shopCSV.abyss_level_min <= abyssLevel and abyssLevel <= shopCSV.abyss_level_max and (shopCSV.no_supply ~= 1 or v.soldout < shopCSV.times) then
				if not labelMap[shopCSV.label] then
					labelMap[shopCSV.label] = {}
				end

				table.insert(labelMap[shopCSV.label], v)
			end
		end

		for i, v in ipairs(shopCSVList) do
			local itemArr = labelMap[v.id]

			if itemArr then
				table.sort(itemArr, function (a, b)
					return a.shop_id < b.shop_id
				end)

				local obj = {
					label = v,
					items = itemArr
				}

				table.insert(arr, obj)
			end
		end

		multiLabel = true
	else
		for i, v in ipairs(shopList) do
			local shopCSV = CsvParser.getCsvData("artifact_shop", v.shop_id, nil, true)

			if shopCSV and shopCSV.abyss_level_min <= abyssLevel and abyssLevel <= shopCSV.abyss_level_max and (shopCSV.no_supply ~= 1 or v.soldout < shopCSV.times) then
				table.insert(arr, v)
			end
		end

		table.sort(arr, function (a, b)
			return a.shop_id < b.shop_id
		end)

		multiLabel = false
	end

	return arr, multiLabel
end

function InfoArtifact.buy(shop_id, num, onSuccess, onFailure)
	local preIndex = shopRefreshIndex

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if rcvData.item then
				local item = rcvData.item

				if preIndex == shopRefreshIndex then
					for i, v in ipairs(shopList) do
						if v.shop_id == item.shop_id then
							for k1, v1 in pairs(item) do
								v[k1] = v1
							end
						end
					end
				end
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("artifact_shop_buy", {
		shop_id = shop_id,
		num = num
	}, callback)
end

function InfoArtifact.getShopCSV()
	return "artifact_shop"
end

function InfoArtifact.getCostNeed()
	return nil
end

function InfoArtifact.getShopName()
	return "artifact"
end

function InfoArtifact.getShopTime()
	return nil
end

function InfoArtifact.getRefreshType()
	return nil
end

function InfoArtifact.getRefreshDesc()
	return nil
end

function InfoArtifact.getSupplyLabel(csv)
	if not empty(csv.refresh_type) then
		return RefreshManager.getDesc(csv.refresh_type)
	end

	return ""
end

function InfoArtifact.getUnsaved()
	local arr = {}

	for id, artifactInfo in pairs(rawData) do
		if artifactInfo.saved ~= 1 then
			table.insert(arr, artifactInfo)
		end
	end

	return arr
end

function InfoArtifact.count(notEquiped)
	local count = 0

	for id, artifactInfo in pairs(rawData) do
		if not notEquiped or not InfoArtifact.getEquipedHero(artifactInfo) then
			count = count + 1
		end
	end

	local artifact_count_max = CsvParser.getCsvData("config", "artifact_count_max").value

	return count, artifact_count_max
end

return InfoArtifact
