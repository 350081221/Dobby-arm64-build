local InfoUser = {}
local REPORT_CODE = {
	CHEAT_ACCELERATE = 1,
	CHEAT_ACCELERATE_C = 2
}
InfoUser.REPORT_CODE = REPORT_CODE
local AUTH_TYPE = {
	GATE = 3,
	QUDAO = 2,
	DIRECT = 1
}
InfoUser.AUTH_TYPE = AUTH_TYPE
local LOGIN_TYPE = {
	REGISTER = 3,
	QUDAO = 1,
	LOGIN = 2
}
local gateName, gateScode = nil
local rawData = {}

local function mergeRawData(data)
	for k, v in pairs(data) do
		rawData[k] = v
	end
end

local function getMagi(params)
	local index = 0
	local indexMax = 5
	local token = tostring(params.token)
	local len = string.len(token)

	for i = 1, len do
		local char = string.byte(token, i)
		index = (index + char) % indexMax
	end

	index = (index + math.floor(params.ran)) % indexMax
	local magi = ""

	if index == 0 then
		magi = crypto.md5(tostring(params.pack_s) .. tostring(params.local_time) .. tostring(params.user_name or params.username) .. tostring(params.ran))
	elseif index == 1 then
		magi = crypto.md5(tostring(params.user_name or params.username) .. tostring(params.pack_s) .. tostring(params.local_time) .. tostring(params.ran))
	elseif index == 2 then
		magi = crypto.md5(tostring(params.user_name or params.username) .. tostring(params.local_time) .. tostring(params.pack_s) .. tostring(params.ran))
	elseif index == 3 then
		magi = crypto.md5(tostring(params.local_time) .. tostring(params.user_name or params.username) .. tostring(params.pack_s) .. tostring(params.ran))
	else
		magi = crypto.md5(tostring(params.local_time) .. tostring(params.pack_s) .. tostring(params.user_name or params.username) .. tostring(params.ran))
	end

	return magi
end

function InfoUser.init()
	if device.platform == "windows" then
		local markData = ConfParser.getLocalData("../deploy/_mark")
		mark = markData.mark or mark
	end

	Connection.listen("user_sync", InfoUser.sync)
	Connection.listen("user_kick", InfoUser.onKick)
	Connection.listen("user_credit", InfoUser.onCredit)
	LuaBridge.register("logout_callback", function (result)
		if result.rs == "success" then
			InfoUser.doReconnect()
		else
			Alert.open(Localization.getSrcText("退出账号失败"))
		end
	end)
	LuaBridge.register("login_cancel_callback", function (result)
		print("$$$ login_cancel_callback ", global.loginUI)

		if global.loginUI then
			global.loginUI:reLogin()
		end
	end)
	LuaBridge.register("kick_callback", function (result)
		InfoUser.onKick(result)
	end)
end

app:addToAppEnterCall(InfoUser.init)

function InfoUser.doReconnect()
	OnlineChat.clearOnlineStat()

	POP_conn.inLogout = true

	Connection.clearFlush()
	Connection.disConnect()
	Connection.reconnect(function ()
		POP_conn.inLogout = nil

		InfoUser.clearOnReconnect()
		Transition.setTitle("")
		app:enterScene("LoginScene")
	end)
end

function InfoUser.sync(data)
	dump(data, "$$$ InfoUser.sync")
	mergeRawData(data)
	ManagerInfo.dataChange("user", data)
end

function InfoUser.onKick(data)
	dump(data, "$$$ onKick")
	Connection.clearFlush()

	InfoUser.isLogin = nil
	InfoUser.isKick = true

	InfoUser.clearOnReconnect()

	local msg = data.msg

	if not msg then
		msg = Localization.getSrcText("已从游戏断开")
		local reason = data.reason

		if reason then
			local csv = CsvParser.getCsvData("word_kick_reason", reason, nil, true)

			if csv then
				msg = csv.desc
			end
		end

		local ban_type = data.ban_type

		if ban_type then
			local csv = CsvParser.getCsvData("ban_type", ban_type, nil, true)

			if csv and csv.type == 2 then
				msg = InfoUser.getBanReason(csv.id)
			end
		end
	end

	app:addToSceneEnterCall(function ()
		POP_confirm.open(msg, function ()
			Connection.reconnect(function ()
				InfoUser.clearOnReconnect()
			end)
		end)
	end)
	Transition.setTitle("")
	app:enterScene("LoginScene")
end

function InfoUser.onCredit(data)
	if data.amount_100 and data.amount_100 > 0 then
		local str = "[color=254,174,14]{1}[/color][color=238,199,111]" .. Localization.getSrcText("代金券到账") .. "[/color]"

		POP_msg.open(StringUtil.replace(str, data.amount_100 / 100), {
			align = Style.center
		})
	end
end

function InfoUser.clear()
	rawData.id = nil
end

function InfoUser.clearOnReconnect()
	InfoUser.clear()
	InfoKanban.clear()
	InfoPaygift.clear()
	OnlineChat.clear()
	TaHelper.clearOnReconnect()
	InfoShop.clear()
	InfoFarm.clear(true)
	InfoHome.clearOnReconnect()
	InfoArena.clearOnReconnect()
	InfoFestival.clearOnReconnect()
	InfoAbyssGift.clearOnReconnect()
	InfoFishing.clearOnReconnect()
	InfoGacha.clearOnReconnect()
	InfoHomeAlchemy.clearOnReconnect()
	InfoHomeCraft.clearOnReconnect()
	InfoNaraka.clearOnReconnect()
	InfoUnion.clearOnReconnect()
	InfoDust.clearOnReconnect()
	InfoSigil.clearOnReconnect()
	InfoArtifact.clearOnReconnect()

	global.bpExpAlready = {}
end

function InfoUser.checkVersion(_version)
	return true
end

local QUDAO_RETRY_TIME = 180
local qudaoLoginSession = nil

function InfoUser.clearQudaoSession()
	if qudaoLoginSession then
		Connection.requestCancel(qudaoLoginSession)

		qudaoLoginSession = nil
	end
end

local savedAutoLoginData = nil

function InfoUser.saveAutoLoginData(data)
	savedAutoLoginData = data
end

function InfoUser.hasAutoLoginData()
	if savedAutoLoginData then
		return true
	end

	return false
end

function InfoUser.hasAutoLogin()
	local username = Cookie.get("savedUsername")
	local password = Cookie.get("savedPassword")

	if username and password then
		return true
	end

	return false
end

function InfoUser.getID()
	return rawData.id
end

function InfoUser.getOriginalID()
	return rawData.original_id
end

function InfoUser.getServerID()
	return rawData.server_id
end

function InfoUser.getNickName()
	return rawData.nickname or ""
end

function InfoUser.getNickAndLang()
	return rawData.nickname or "", rawData.nicklang or ""
end

function InfoUser.getCredit()
	return rawData.credit_100 / 100
end

function InfoUser.isCredit()
	if rawData.ban_credit == 1 then
		return false
	end

	if device.platform == "ios" then
		local iosCheckVersion = InfoParams.getValue("ios_version")
		local isIosCheck = false

		if not empty(iosCheckVersion) and iosCheckVersion == CONFIG.appVersion then
			isIosCheck = true
		end

		if InfoParams.getValue("credit_ios") == 1 and not isIosCheck then
			return true
		end
	elseif InfoParams.getValue("credit_android") == 1 then
		return true
	end

	return false
end

function InfoUser.creditRecover(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "user_credit_recover")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("user_credit_recover", callback)
end

function InfoUser.getHead()
	return {
		icon = rawData.head,
		frame = rawData.head_frame
	}
end

function InfoUser.getCreateTime()
	return rawData.create_time or 0
end

function InfoUser.getTotalTime()
	return rawData.total_time + Time.now() - rawData.login_time
end

function InfoUser.getUserInfo()
	return {
		user_id = InfoUser.getID(),
		nickname = InfoUser.getNickName(),
		head = rawData.head,
		head_frame = rawData.head_frame
	}
end

function InfoUser.getMuteTime()
	return rawData.mute_time or 0
end

function InfoUser.getMuteTimeleft()
	return math.floor((rawData.mute_time or 0) - Time.now())
end

function InfoUser.isMute()
	print("$$$ rawData.mute_time", rawData.mute_time)

	if rawData.mute_time then
		return Time.now() < rawData.mute_time
	end

	return false
end

function InfoUser.setUserInfo(isCreate)
	local params = {
		friendlist = "无",
		profession = "无",
		professionId = "0",
		partyRoleName = "无",
		partyRoleId = "0",
		gameRoleGender = "无",
		partyId = "0",
		partyName = "无",
		vipLevel = "0",
		isCreate = isCreate,
		serverID = tostring(global.server_id),
		serverName = "server" .. tostring(global.server_id),
		gameRoleName = tostring(InfoUser.getNickName()),
		gameRoleID = tostring(InfoUser.getID()),
		gameBalance = tostring(InfoItem.getNum(GameConfig.zuan_item)),
		coinBalance = tostring(InfoItem.getNum(GameConfig.coin_item)),
		gameUserLevel = tostring(InfoDungeon.getAbyssMaxLevel()),
		roleCreateTime = tostring(InfoUser.getCreateTime()),
		gameRolePower = tostring(InfoHero.getMaxScore()),
		totalPay = tostring(InfoOrder.getTotalPay()),
		totalPay100 = tostring(InfoOrder.getTotalPay100()),
		qudaoUserId = tostring(global.qudao_user_id or ""),
		version = tostring(version),
		inpackVersion = tostring(inpackVersion),
		appVersion = tostring(CONFIG.appVersion or ""),
		appBuild = tostring(CONFIG.appBuild or "")
	}

	LuaBridge.call("luaSetUserInfo", params, function (result)
	end)
end

function InfoUser.reloginGate(token, onSuccess, onFailure)
	InfoUser.loginGate(token, gateScode, onSuccess, onFailure)
end

function InfoUser.loginGate(token, scode, onSuccess, onFailure, onProgress)
	gateScode = scode
	local params = {
		type = AUTH_TYPE.GATE,
		token = tostring(token),
		sys_lang = CONFIG.lang_sys,
		sys_country = CONFIG.country_sys,
		ta_device_id = CONFIG.ta_device_id,
		ta_distinct_id = CONFIG.ta_distinct_id,
		appsflyer_id = CONFIG.appsflyer_id,
		client_os = CONFIG.os,
		platform = device.platform,
		lang = Localization.getLang(),
		local_time = math.floor(Time.time()),
		time_zone = Time.getLocalTimezone(),
		pack_tag = PACK_TAG,
		scode = scode
	}

	InfoUser.doLoginGate(params, onSuccess, onFailure, onProgress)
end

function InfoUser.doLoginGate(params, onSuccess, onFailure, onProgress, isReconn)
	local function callback(rcvData)
		if timeoutID then
			Looper.clearTimeout(timeoutID)

			timeoutID = nil
		end

		dump(rcvData, "$$$ auth_login_gate")

		if rcvData.err then
			if rcvData.err == "user_need_active" then
				InfoUser.authActive(rcvData.user_id)
			elseif rcvData.err == "auth_login_err_ban" then
				InfoUser.onLoginBan(rcvData)
			end

			if onFailure then
				onFailure(rcvData.err)
			end
		else
			gateName = rcvData.gateName

			if not InfoUser.checkVersion(rcvData.version) then
				return
			end

			mergeRawData(rcvData)
			InfoUser.saveAutoLoginData(params)
			InfoUser.onLogin(rcvData, function ()
				InfoUser.setUserInfo(rcvData.is_create == 1)
				WingHelper.ghw_user_import()

				if onSuccess then
					onSuccess(rcvData)
				end
			end, onFailure, onProgress, isReconn, rcvData.is_create == 1)
		end
	end

	Connection.request("auth_login_gate", params, callback)
end

function InfoUser.getHttpHead()
	if CONFIG.is_https then
		return "https://"
	end

	return "http://"
end

local loginType, loginParams = nil

function InfoUser.dafuRelogin(onSuccess, onFailure, onProgress)
	local params = ObjUtil.copy(loginParams)
	params.local_time = math.floor(Time.time())
	params.magi = getMagi(params)

	if loginType == LOGIN_TYPE.QUDAO then
		Http.request(InfoUser.getHttpHead() .. CONFIG.center_addr .. "/?cmd=auth_login_qudao", params, function (rcvData)
			InfoUser.onDafuLogin(rcvData, onSuccess, onFailure, onProgress)
		end)
	elseif loginType == LOGIN_TYPE.LOGIN then
		Http.request(InfoUser.getHttpHead() .. CONFIG.center_addr .. "/?cmd=auth_login", params, function (rcvData)
			InfoUser.onDafuLogin(rcvData, onSuccess, onFailure, onProgress)
		end)
	elseif loginType == LOGIN_TYPE.REGISTER then
		Http.request(InfoUser.getHttpHead() .. CONFIG.center_addr .. "/?cmd=auth_register", params, function (rcvData)
			InfoUser.onDafuLogin(rcvData, onSuccess, onFailure, onProgress)
		end)
	end
end

function InfoUser.reinstall()
	if A_reinstall then
		A_reinstall()
	else
		POP_notice.open(Localization.getSrcText("当前版本过低，请重新下载安装"), function ()
			LuaBridge.call("luaReinstall", {}, function (obj)
			end)
		end, function ()
			app.exit()
		end, Localization.getSrcText("前往下载"), Localization.getSrcText("退出游戏"))
	end
end

function InfoUser.getBanReason(ban_type)
	local csv = CsvParser.getCsvData("ban_type", ban_type, nil, true)
	local lang = Localization.getLang()
	local reason = csv.reason

	if csv[lang] then
		reason = csv[lang]
	end

	return reason
end

function InfoUser.onLoginBan(rcvData)
	dump(rcvData, "$$$ onLoginBan")

	local ban_type = rcvData.ban_type or 0
	local csv = CsvParser.getCsvData("ban_type", ban_type, nil, true)
	csv = csv or CsvParser.getCsvData("ban_type", 0)
	local msg = nil

	if csv.type == 1 then
		msg = Localization.getSrcText("账号封禁中，如有疑问请联系客服\n结束时间：{1}\n封禁理由：{2}")
	else
		msg = Localization.getSrcText("客户服务中，暂时无法登录，如有疑问请联系客服\n结束时间：{1}\n服务项目：{2}")
	end

	msg = StringUtil.replace(msg, Time.ymdtFormat(rcvData.time, true), InfoUser.getBanReason(csv.id))

	POP_confirm.openBig(msg, nil, , , {
		align = Style.left
	})
end

function InfoUser.onDafuLogin(rcvData, onSuccess, onFailure, onProgress)
	dump(rcvData, "$$$ onDafuLogin")

	if rcvData.wait_key then
		local function onWaitSuccess(_rcvData)
			InfoUser.onDafuLogin(_rcvData, onSuccess, onFailure, onProgress)
		end

		local function onWaitReset()
			InfoUser.dafuRelogin(onSuccess, onFailure, onProgress)
		end

		FRAME_login_wait.open(rcvData.wait_key, rcvData.wait_time, onWaitSuccess, onWaitReset)

		return
	end

	if rcvData.err then
		if rcvData.err == "user_need_active" then
			InfoUser.authActive(rcvData.user_id)
		elseif rcvData.err == "auth_register_closed" then
			FRAME_register_closed.open()
		elseif rcvData.err == "auth_min_build" then
			InfoUser.reinstall()
		elseif rcvData.err == "auth_login_err_ban" then
			InfoUser.onLoginBan(rcvData)
		end

		onFailure(rcvData.err)
	else
		local serverArr = string.split(rcvData.gateAddr, ":")

		if not CONFIG.neiwang or serverArr[1] ~= "127.0.0.1" then
			SERVER_HOST = serverArr[1]
		end

		SERVER_PORT = tonumber(serverArr[2])

		Log.debug("SERVER_HOST", SERVER_HOST, "SERVER_PORT", SERVER_PORT, "token", rcvData.token)
		Connection.init(SERVER_HOST, SERVER_PORT)
		InfoUser.loginGate(rcvData.token, rcvData.scode, onSuccess, onFailure, onProgress)
	end
end

function InfoUser.loginQudao(code, user_id, user_name, token, channel_type, onSuccess, onFailure, onProgress, s, onHttpSuccess)
	global.channel_type = channel_type
	local params = {
		type = AUTH_TYPE.QUDAO,
		code = code,
		user_id = user_id,
		user_name = user_name,
		token = token,
		channel_type = channel_type,
		mark = mark,
		active_code = activeCode,
		active_is_create = active_is_create,
		sys_lang = CONFIG.lang_sys,
		sys_country = CONFIG.country_sys,
		ta_device_id = CONFIG.ta_device_id,
		ta_distinct_id = CONFIG.ta_distinct_id,
		appsflyer_id = CONFIG.appsflyer_id,
		client_os = CONFIG.os,
		platform = device.platform,
		lang = Localization.getLang(),
		time_zone = Time.getLocalTimezone(),
		pack_tag = PACK_TAG,
		pack_s = s,
		appVersion = CONFIG.appVersion,
		appBuild = CONFIG.appBuild,
		ran = math.random(1, 65535)
	}
	loginType = LOGIN_TYPE.QUDAO
	loginParams = ObjUtil.copy(params)
	params.local_time = math.floor(Time.time())
	params.magi = getMagi(params)

	if CONFIG.dafu then
		Http.request(InfoUser.getHttpHead() .. CONFIG.center_addr .. "/?cmd=auth_login_qudao", params, function (rcvData)
			if onHttpSuccess then
				onHttpSuccess()
			end

			InfoUser.onDafuLogin(rcvData, onSuccess, onFailure, onProgress)
		end)
	else
		InfoUser.doLoginQudao(params, onSuccess, onFailure, onProgress)
	end
end

function InfoUser.doLoginQudao(params, onSuccess, onFailure, onProgress, isReconn)
	local timeoutID, doLoginQudao = nil

	function doLoginQudao()
		if Connection.getStat() == "connected" then
			local function callback(rcvData)
				if timeoutID then
					Looper.clearTimeout(timeoutID)

					timeoutID = nil
				end

				dump(rcvData, "$$$ auth_login_qudao")

				if rcvData.err then
					if rcvData.err == "user_need_active" then
						InfoUser.authActive(rcvData.user_id)
					elseif rcvData.err == "auth_login_err_ban" then
						InfoUser.onLoginBan(rcvData)
					end

					if onFailure then
						onFailure(rcvData.err)
					end
				else
					if not InfoUser.checkVersion(rcvData.version) then
						return
					end

					mergeRawData(rcvData)
					InfoUser.saveAutoLoginData(params)
					InfoUser.onLogin(rcvData, function ()
						InfoUser.setUserInfo(rcvData.is_create == 1)
						WingHelper.ghw_user_import()

						if onSuccess then
							onSuccess(rcvData)
						end
					end, onFailure, onProgress, isReconn, rcvData.is_create == 1)
				end
			end

			InfoUser.clearQudaoSession()

			qudaoLoginSession = Connection.request("auth_login_qudao", params, callback)
		end

		timeoutID = Looper.setTimeout(doLoginQudao, QUDAO_RETRY_TIME)
	end

	doLoginQudao()
end

function InfoUser.login(username, password, onSuccess, onFailure, onProgress, onHttpSuccess)
	local params = {
		token = "local_token_login",
		type = AUTH_TYPE.DIRECT,
		username = username,
		password = password,
		appsflyer_id = CONFIG.appsflyer_id,
		client_os = CONFIG.os,
		platform = device.platform,
		lang = Localization.getLang(),
		pack_tag = PACK_TAG,
		time_zone = Time.getLocalTimezone(),
		mark = mark,
		beat = math.floor(Time.lifeTime()),
		pack_s = CONFIG.local_s or "local",
		appVersion = CONFIG.appVersion,
		appBuild = CONFIG.appBuild,
		ran = math.random(1, 65535)
	}
	loginType = LOGIN_TYPE.LOGIN
	loginParams = ObjUtil.copy(params)
	params.local_time = math.floor(Time.time())
	params.magi = getMagi(params)

	if CONFIG.dafu then
		Http.request(InfoUser.getHttpHead() .. CONFIG.center_addr .. "/?cmd=auth_login", params, function (rcvData)
			if onHttpSuccess then
				onHttpSuccess()
			end

			InfoUser.saveAutoLoginUserPass(username, password)
			InfoUser.onDafuLogin(rcvData, onSuccess, onFailure, onProgress)
		end)
	else
		InfoUser.doLogin(params, onSuccess, onFailure, onProgress)
	end
end

function InfoUser.doLogin(params, onSuccess, onFailure, onProgress, isReconn)
	local function callback(rcvData)
		if rcvData.err then
			if rcvData.err == "user_need_active" then
				InfoUser.authActive(rcvData.user_id)
			elseif rcvData.err == "auth_login_err_ban" then
				InfoUser.onLoginBan(rcvData)
			end

			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if not InfoUser.checkVersion(rcvData.version) then
				return
			end

			mergeRawData(rcvData)
			InfoUser.saveAutoLoginData(params)
			InfoUser.saveAutoLoginUserPass(params.username, params.password)
			InfoUser.onLogin(rcvData, function ()
				onSuccess(rcvData)
			end, onFailure, onProgress, isReconn)
		end
	end

	Connection.request("auth_login", params, callback)
end

function InfoUser.register(username, password, onSuccess, onFailure, onProgress)
	local params = {
		token = "local_token_register",
		type = AUTH_TYPE.DIRECT,
		username = username,
		password = password,
		mark = mark,
		sys_lang = CONFIG.lang_sys,
		sys_country = CONFIG.country_sys,
		ta_device_id = CONFIG.ta_device_id,
		ta_distinct_id = CONFIG.ta_distinct_id,
		appsflyer_id = CONFIG.appsflyer_id,
		client_os = CONFIG.os,
		platform = device.platform,
		lang = Localization.getLang(),
		pack_tag = PACK_TAG,
		time_zone = Time.getLocalTimezone(),
		pack_s = CONFIG.local_s or "local",
		appVersion = CONFIG.appVersion,
		appBuild = CONFIG.appBuild,
		ran = math.random(1, 65535)
	}
	loginType = LOGIN_TYPE.REGISTER
	loginParams = ObjUtil.copy(params)
	params.local_time = math.floor(Time.time())
	params.magi = getMagi(params)

	if CONFIG.dafu then
		Http.request(InfoUser.getHttpHead() .. CONFIG.center_addr .. "/?cmd=auth_register", params, function (rcvData)
			InfoUser.saveAutoLoginUserPass(username, password)
			InfoUser.onDafuLogin(rcvData, onSuccess, onFailure, onProgress)
		end)
	else
		InfoUser.doRegister(params, onSuccess, onFailure, onProgress)
	end
end

function InfoUser.doRegister(params, onSuccess, onFailure, onProgress)
	LuaBridge.call("luaAfEvent", {
		eventName = "registration_start"
	})

	local function callback(rcvData)
		dump(rcvData, "$$$ auth_register")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if not InfoUser.checkVersion(rcvData.version) then
				return
			end

			mergeRawData(rcvData)
			InfoUser.saveAutoLoginData(params)
			InfoUser.saveAutoLoginUserPass(params.username, params.password)
			InfoUser.onLogin(rcvData, function ()
				onSuccess(rcvData)
			end, onFailure, onProgress, nil, true)
		end
	end

	Connection.request("auth_register", params, callback)
end

function InfoUser.autoLogin(onSuccess, onFailure, onProgress, isReconn)
	if not savedAutoLoginData then
		if onFailure then
			onFailure()
		end

		return
	end

	local params = savedAutoLoginData

	if params.type == AUTH_TYPE.DIRECT then
		InfoUser.doLogin(params, onSuccess, onFailure, onProgress, isReconn)
	elseif params.type == AUTH_TYPE.QUDAO then
		InfoUser.doLoginQudao(params, onSuccess, onFailure, onProgress, isReconn)
	elseif savedAutoLoginData.type == AUTH_TYPE.GATE then
		InfoUser.doLoginGate(params, onSuccess, onFailure, onProgress, isReconn)
	end
end

function InfoUser.authActive(user_id)
	FRAME_user_active.open(function (activeCode, closeFunc)
		local function callback(rcvData)
			dump(rcvData, "$$$ auth_active")

			if not rcvData.err then
				if closeFunc then
					closeFunc()
				end

				Alert.open(Localization.getSrcText("完成激活"))
			end
		end

		local params = {
			user_id = user_id,
			active_code = activeCode
		}

		if CONFIG.dafu then
			Http.request(InfoUser.getHttpHead() .. CONFIG.center_addr .. "/?cmd=auth_active", params, callback)
		else
			Connection.request("auth_active", params, callback)
		end
	end)
end

local onLoginData = nil

function InfoUser.onLogin(rcvData, onSuccess, onFailure, onProgress, isReconn, isCreate)
	TaHelper.taTrack("loginsuccess")
	dump(rcvData, "$$$ InfoUser.onLogin")

	if isCreate then
		LuaBridge.call("luaAfEvent", {
			eventName = "registration_complete",
			user_id = tostring(rcvData.id)
		})

		if device.platform == "ios" then
			LuaBridge.call("luaSkadPost", {
				id = 1
			})
		end
	elseif device.platform == "ios" then
		LuaBridge.call("luaSkadPost", {
			id = 2
		})
	end

	if CONFIG.is_solar then
		if isCreate then
			print("$$$ luaSolarAppRegister")
			LuaBridge.call("luaSolarAppRegister", {})
		else
			print("$$$ luaSolarAppLogin")
			LuaBridge.call("luaSolarAppLogin", {})
		end
	end

	UserCookie.init(rcvData.id)
	Time.setServerTime(rcvData.time, rcvData.timezone_offset)

	CONFIG.isNeo = rcvData.is_neo == 1
	CONFIG.isBench = rcvData.is_bench == 1

	print("$$$ is_neo is_bench", rcvData.is_neo, rcvData.is_bench)

	InfoUser.isLogin = true
	InfoUser.isKick = nil
	InfoUser.gateLine = rcvData.line_id or 1
	onLoginData = {
		onSuccess = onSuccess,
		onFailure = onFailure,
		onProgress = onProgress,
		isReconn = isReconn,
		isCreate = isCreate
	}
end

function InfoUser.getLineList(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ game_line_list")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("game_line_list", callback)
end

function InfoUser.selectLine(line_id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ user_request_change_line")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("user_request_change_line", {
		line_id = line_id
	}, callback)
end

function InfoUser.resetLogin(onSuccess, onFailure, onProgress)
	if onLoginData then
		onLoginData.onSuccess = onSuccess
		onLoginData.onFailure = onFailure
		onLoginData.onProgress = onProgress

		InfoUser.afterLogin()
	end
end

function InfoUser.afterLogin()
	print("$$$ afterLogin", onLoginData)

	if onLoginData then
		InfoUser.doAfterLogin()
	else
		Looper.setTimeout(InfoUser.doAfterLogin, 30)
	end
end

function InfoUser.doAfterLogin()
	local onSuccess = onLoginData.onSuccess
	local onFailure = onLoginData.onFailure
	local onProgress = onLoginData.onProgress
	local isReconn = onLoginData.isReconn
	local isCreate = onLoginData.isCreate

	if CONFIG.is_ta then
		local taID = TaHelper.getTaID()

		Log.debug("$$$ taID", taID)
		TaHelper.taLogin(taID)
	end

	if CONFIG.is_yd then
		YdHelper.check(2)
	end

	InfoUser.loadInitData(onSuccess, onFailure, onProgress, isReconn)
end

function InfoUser.saveAutoLoginUserPass(username, password)
	Log.verbose("saveAutoLoginUserPass", username, password)
	Cookie.set("savedUsername", username)
	Cookie.set("savedPassword", password)
	Cookie.flush()
end

function InfoUser.clearAutoLoginUserPass()
	Log.verbose("clearAutoLoginUserPass")
	Cookie.set("savedUsername", nil)
	Cookie.set("savedPassword", nil)
	Cookie.flush()
end

function InfoUser.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			mergeRawData(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("user_query", callback)
end

function InfoUser.setNickname(nickname, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			print("$$$ 更新昵称", InfoUser.getNickName())
			InfoUser.setUserInfo(false)
			WingHelper.ghw_user_create()

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("user_nickname", {
		nickname = nickname,
		lang = Localization.getLang()
	}, callback)
end

function InfoUser.setName(name, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			WingHelper.ghw_user_info_update()

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("user_set_name", {
		name = name,
		lang = Localization.getLang()
	}, callback)
end

function InfoUser.refreshHeadFrameArena()
	local head_frame = rawData.head_frame

	if not empty(head_frame) and head_frame ~= GameConfig.default_head_frame and InfoItem.getNum(head_frame) == 0 and InfoArena.isArenaFrame(head_frame) then
		local divisionCSV = InfoArena.getDivision(nil, InfoArena.getMyArea())

		if divisionCSV and not empty(divisionCSV.frame_id) and divisionCSV.frame_id ~= head_frame then
			InfoUser.setHead(nil, divisionCSV.frame_id, true)

			return true
		end
	end
end

function InfoUser.setHead(head, head_frame, is_arena_frame, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("user_head", {
		head = head,
		head_frame = head_frame,
		is_arena_frame = is_arena_frame and 1 or 0
	}, callback)
end

function InfoUser.checkHead(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ user_head_check")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("user_head_check", callback)
end

function InfoUser.report(code, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("user_report", {
		code = code
	}, callback)
end

function InfoUser.redeem(code, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ user_redeem")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("user_redeem", {
		code = code
	}, callback)
end

function InfoUser.gateList(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ user_gate_list")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("user_gate_list", callback)
end

function InfoUser.checkRealname(name, sfz, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ user_realname")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("user_realname", {
		name = name,
		sfz = sfz
	}, callback)
end

local initLoader = nil

function InfoUser.stopLoadInitData()
	if initLoader then
		initLoader:stop()

		initLoader = nil
	end
end

function InfoUser.loadInitData(onSuccess, onFailure, onProgress, isReconn)
	if isReconn then
		print("$$$ loadInitData isReconn")
	end

	if CONFIG.ping then
		local delayTry = nil

		function delayTry()
			local time = Time.time()

			InfoWorld.query(function ()
				print(Time.time() - time)
				Looper.setTimeout(delayTry, 30)
			end, error_callback)
		end

		delayTry()

		return
	end

	local loader = AsyncLoader.new()
	initLoader = loader

	loader:add(function (complete_callback, error_callback)
		Log.debug("InfoUser.query")
		InfoUser.query(complete_callback, error_callback)
	end, Localization.getSrcText("加载玩家信息"))
	loader:add(function (complete_callback, error_callback)
		Log.debug("InfoChapter.query")
		InfoChapter.query(complete_callback, error_callback)
	end, Localization.getSrcText("加载章节"))
	loader:add(function (complete_callback, error_callback)
		Log.debug("InfoPet.query")
		InfoPet.query(complete_callback, error_callback)
	end, Localization.getSrcText("加载宠物"))
	loader:add(function (complete_callback, error_callback)
		Log.debug("InfoPetHatch.query")
		InfoPetHatch.query(complete_callback, error_callback)
	end, Localization.getSrcText("加载宠物"))
	loader:add(function (complete_callback, error_callback)
		Log.debug("InfoDungeon.query")
		InfoDungeon.query(complete_callback, error_callback)
	end, Localization.getSrcText("加载地城"))
	loader:add(function (complete_callback, error_callback)
		Log.debug("InfoItem.query")
		InfoItem.query(complete_callback, error_callback)
	end, Localization.getSrcText("加载物品"))
	loader:add(function (complete_callback, error_callback)
		Log.debug("InfoEquip.query")
		InfoEquip.query(complete_callback, error_callback)
	end, Localization.getSrcText("加载装备"))
	loader:add(function (complete_callback, error_callback)
		Log.debug("InfoCard.query")
		InfoCard.query(complete_callback, error_callback)
	end, Localization.getSrcText("加载怪物卡片"))
	loader:add(function (complete_callback, error_callback)
		Log.debug("InfoSigil.query")
		InfoSigil.query(complete_callback, error_callback)
	end, Localization.getSrcText("加载魔纹"))
	loader:add(function (complete_callback, error_callback)
		Log.debug("InfoArtifact.query")
		InfoArtifact.query(complete_callback, error_callback)
	end, Localization.getSrcText("加载饰物"))
	loader:add(function (complete_callback, error_callback)
		Log.debug("InfoHero.query")
		InfoHero.query(complete_callback, error_callback)
	end, Localization.getSrcText("加载佣兵"))
	loader:add(function (complete_callback, error_callback)
		Log.debug("InfoMail.query")
		InfoMail.query(complete_callback, error_callback)
	end, Localization.getSrcText("加载邮件"))
	loader:add(function (complete_callback, error_callback)
		Log.debug("InfoMailPerson.query")
		InfoMailPerson.query(complete_callback, error_callback)
	end, Localization.getSrcText("加载个人邮件"))
	loader:add(function (complete_callback, error_callback)
		Log.debug("OnlineChat.query")
		OnlineChat.query(complete_callback, error_callback)
	end, Localization.getSrcText("加载聊天信息"))
	loader:add(function (complete_callback, error_callback)
		Log.debug("InfoUser.initQueryDust")
		InfoUser.initQueryDust(complete_callback, error_callback)
	end, Localization.getSrcText("加载尘封"))
	loader:add(function (complete_callback, error_callback)
		Log.debug("InfoActv.query")
		InfoActv.query(complete_callback, error_callback)
	end, Localization.getSrcText("加载活动"))
	loader:add(function (complete_callback, error_callback)
		Log.debug("InfoUser.initQueryActv")
		InfoUser.initQueryActv(complete_callback, error_callback)
	end, Localization.getSrcText("加载活动"))
	loader:add(function (complete_callback, error_callback)
		Log.debug("InfoUser.initQuery")
		InfoUser.initQuery(complete_callback, error_callback)
	end, Localization.getSrcText("初始化"))
	loader:start(function ()
		Log.debug("InfoUser.loadInitData 1")

		Connection.ingame = true

		if CONFIG.is_ta then
			TaHelper.taUserSet()
		end

		if onSuccess then
			onSuccess()
		end
	end, function ()
		Log.debug("InfoUser.loadInitData 2")

		if onFailure then
			onFailure()
		end
	end, function (index, total, msg)
		Log.debug("InfoUser.loadInitData 3")

		if onProgress then
			onProgress(index, total, msg)
		end
	end)
end

function InfoUser.initQuery(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			local query_arr = {
				{
					InfoItemLimit,
					"item_limit_query"
				},
				{
					InfoGuide,
					"guide_query"
				},
				{
					InfoBuilding,
					"building_query"
				},
				{
					InfoKanban,
					"kanban_query"
				},
				{
					InfoQuest,
					"quest_query"
				},
				{
					InfoMission,
					"mission_query"
				},
				{
					InfoGather,
					"gather_query"
				},
				{
					InfoFurnace,
					"furnace_query"
				},
				{
					InfoTavern,
					"tavern_query"
				},
				{
					InfoShop,
					"shop_query"
				},
				{
					InfoModao,
					"modao_query"
				},
				{
					InfoBag,
					"bag_query"
				},
				{
					InfoQuickSlots,
					"quick_slots_query"
				},
				{
					InfoOrder,
					"order_query"
				},
				{
					InfoTaskQuest,
					"task_quest_query"
				},
				{
					InfoMirror,
					"mirror_query"
				},
				{
					InfoFunction,
					"function_query"
				},
				{
					InfoTravel,
					"travel_query"
				},
				{
					InfoArena,
					"arena_query"
				},
				{
					InfoAchieve,
					"achieve_query"
				},
				{
					InfoRecordFest,
					"record_fest_query"
				},
				{
					InfoRecordMonth,
					"record_month_query"
				},
				{
					InfoPaygift,
					"paygift_query"
				},
				{
					InfoLikes,
					"likes_query"
				},
				{
					InfoFarm,
					"farm_query"
				},
				{
					InfoExchange,
					"exchange_query"
				},
				{
					InfoWild,
					"wild_query"
				},
				{
					InfoGacha,
					"gacha_query"
				},
				{
					InfoManualMonster,
					"manual_monster_query"
				},
				{
					InfoFishing,
					"fishing_query"
				},
				{
					InfoAbyssGift,
					"abyss_gift_query"
				},
				{
					InfoRanking,
					"ranking_query"
				},
				{
					InfoIllusion,
					"illusion_query"
				},
				{
					InfoConsume,
					"consume_query"
				},
				{
					InfoVars,
					"vars_query"
				},
				{
					InfoProbup,
					"probup_query"
				},
				{
					InfoCampfire,
					"campfire_query"
				},
				{
					InfoTower,
					"tower_query"
				},
				{
					InfoAbyssPass,
					"abyss_pass_query"
				},
				{
					InfoAbyssReward,
					"abyss_reward_query"
				},
				{
					InfoHeroSp,
					"hero_sp_query"
				},
				{
					InfoBook,
					"book_query"
				},
				{
					InfoItemShop,
					"item_shop_query"
				},
				{
					InfoNaraka,
					"naraka_query"
				},
				{
					InfoMaruka,
					"maruka_query"
				},
				{
					InfoUserShow,
					"user_show_query"
				},
				{
					InfoManualReward,
					"manual_reward_query"
				},
				{
					InfoHome,
					"home_query"
				},
				{
					InfoDelayItem,
					"delay_item_query"
				},
				{
					InfoAbyssArea,
					"abyss_area_query"
				},
				{
					InfoService,
					"service_query"
				},
				{
					InfoArmory,
					"armory_query"
				},
				{
					InfoRebate,
					"rebate_query"
				},
				{
					InfoWorld,
					"world_query"
				},
				{
					InfoParams,
					"params_query"
				},
				{
					InfoManual,
					"manual_query"
				},
				{
					InfoLang,
					"lang_query"
				},
				{
					InfoFirstAchieve,
					"first_achieve_query"
				},
				{
					InfoUnion,
					"union_query"
				}
			}

			for i, v in ipairs(query_arr) do
				local model = v[1]
				local dataName = v[2]

				assert(rcvData[dataName], dataName)
				model.onQuery(rcvData[dataName])
			end

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("user_init_query", callback)
end

function InfoUser.initQueryDust(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			local query_arr = {
				{
					InfoDust,
					"dust_query"
				},
				{
					InfoDustAchieve,
					"dust_achieve_query"
				},
				{
					InfoDustPass,
					"dust_pass_query"
				},
				{
					InfoDustAttrManual,
					"dust_attr_manual_query"
				}
			}

			for i, v in ipairs(query_arr) do
				local model = v[1]
				local dataName = v[2]

				assert(rcvData[dataName], dataName)
				model.onQuery(rcvData[dataName])
			end

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("user_init_query_dust", callback)
end

function InfoUser.initQueryActv(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			local query_arr = {
				{
					InfoCharge,
					"charge_query"
				},
				{
					InfoFestival,
					"festival_query"
				},
				{
					InfoMygift,
					"mygift_query"
				},
				{
					InfoActvAchieve,
					"actv_achieve_query"
				},
				{
					InfoActvMonster,
					"actv_monster_query"
				},
				{
					InfoActvStage,
					"actv_stage_query"
				},
				{
					InfoActvRecord,
					"actv_record_query"
				},
				{
					InfoBpOverall,
					"bp_overall_query"
				},
				{
					InfoBp,
					"bp_query"
				},
				{
					InfoBpAchieve,
					"bp_achieve_query"
				},
				{
					InfoActvTurntable,
					"actv_turntable_query"
				},
				{
					InfoBack,
					"back_query"
				},
				{
					InfoBackRecord,
					"back_record_query"
				},
				{
					InfoBackAchieve,
					"back_achieve_query"
				},
				{
					InfoPetFeed,
					"pet_feed_query"
				},
				{
					InfoCore,
					"core_query"
				}
			}

			for i, v in ipairs(query_arr) do
				local model = v[1]
				local dataName = v[2]

				assert(rcvData[dataName], dataName)
				model.onQuery(rcvData[dataName])
			end

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("user_init_query_actv", callback)
end

local idEncodeOffset = 10000
local CHAR_ARR = {
	49,
	50,
	51,
	52,
	53,
	54,
	55,
	56,
	57,
	65,
	66,
	67,
	68,
	69,
	70,
	71,
	72,
	74,
	75,
	76,
	77,
	78,
	80,
	81,
	82,
	83,
	84,
	85,
	86,
	87,
	88,
	89,
	90
}
local CHAR_SEED = 54437
local CHAR_RAN, CHAR_MAP = nil

function initEncode()
	if not CHAR_RAN then
		local random = Random.new(CHAR_SEED)
		CHAR_RAN = random:order(CHAR_ARR)

		if not CHAR_MAP then
			CHAR_MAP = {}

			for i, v in ipairs(CHAR_RAN) do
				CHAR_MAP[v] = i
			end
		end
	end
end

function InfoUser.encodeID(value)
	initEncode()

	value = value + idEncodeOffset
	local code = ""
	local charMax = #CHAR_RAN

	while value % charMax ~= value do
		code = code .. string.char(CHAR_RAN[value % charMax + 1])
		value = math.floor(value / charMax)
	end

	code = code .. string.char(CHAR_RAN[value + 1])

	return code
end

function InfoUser.decodeID(code)
	code = string.upper(code)

	initEncode()

	local charMax = #CHAR_RAN
	local value = 0
	code = code:reverse()

	for i = 1, #code do
		local c = code:sub(i, i)
		local char = CHAR_MAP[c:byte()]

		if not char then
			return nil
		end

		value = value * charMax + char - 1
	end

	return value - idEncodeOffset
end

function InfoUser.ydCheck(type, token, deviceId, onSuccess, onFailure)
	local function callback(rcvData)
		if DEV_MODE then
			dump(rcvData, "$$$ user_yd_check")

			if DEV_MODE then
				Log.debug("InfoUser.ydCheck result", rcvData.result)
			end
		end

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	local params = {
		platform = device.platform,
		type = type,
		token = token,
		deviceId = deviceId,
		version = tostring(version),
		appVersion = tostring(CONFIG.appVersion or "")
	}

	if DEV_MODE then
		Log.debug("InfoUser.ydCheck type", type)
	end

	Connection.request("user_yd_check", params, callback)
end

function InfoUser.loginErr(msg, onSuccess)
	local params = {
		version = tostring(version),
		appBuild = tostring(CONFIG.appBuild or ""),
		qudao_code = CONFIG.qudao_code or 0,
		msg = msg or ""
	}

	Http.request(InfoUser.getHttpHead() .. CONFIG.center_addr .. "/?cmd=auth_login_err", params, function (rcvData)
		if onSuccess then
			onSuccess()
		end
	end)
end

return InfoUser
