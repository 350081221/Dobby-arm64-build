local POP_attr_test = class("POP_attr_test", UI_base)

function POP_attr_test.open()
	POP_attr_test.opening = true
	local ui = POP_attr_test.new()

	display.getRunningScene():addChild(ui, LayerConfig.notice)
end

function POP_attr_test:ctor()
	POP_attr_test.super.ctor(self, "pop_attr_test")
	self:init()
end

function POP_attr_test:init()
	self:initUI()
end

function POP_attr_test:initUI()
	local closePB = self:getComponentByTag("close_pb")

	closePB:toTouchable()
	closePB:addTap(function ()
		self:removeSelf()
	end)

	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	self.loopEB = self:createEditBoxOnComponent("eb_loop")

	self.loopEB:setText("100000")

	local test1PB = self:getComponentByTag("bt_test1")

	test1PB:toTouchable()
	test1PB:addTap(function ()
		self:goTest(1)
	end)

	local test2PB = self:getComponentByTag("bt_test2")

	test2PB:toTouchable()
	test2PB:addTap(function ()
		self:goTest(2)
	end)

	local clearPB = self:getComponentByTag("bt_clear")

	clearPB:toTouchable()
	clearPB:addTap(function ()
		self:clearChart()
	end)

	self.resultStack = {}
end

local sectionSize = 10

function POP_attr_test:refreshChart()
	if self.canvasStack then
		for i, v in ipairs(self.canvasStack) do
			v:removeSelf()
		end
	end

	if self.textStack then
		for i, v in ipairs(self.textStack) do
			v:removeSelf()
		end
	end

	self.canvasStack = {}
	self.textStack = {}
	local minAll, maxAll, maxCount = nil

	for i, result in ipairs(self.resultStack) do
		if not minAll or result.min < minAll then
			minAll = result.min
		end

		if not maxAll or maxAll < result.max then
			maxAll = result.max
		end

		for k, v in pairs(result.countMap) do
			if not maxCount or maxCount < v then
				maxCount = v
			end
		end
	end

	if #self.resultStack > 0 then
		maxAll = maxAll + 1
		local chartFlag = self:getFlagByTag("flag_chart")
		local perWidth = chartFlag.width / (maxAll - minAll)

		for j = minAll, maxAll - 1 do
			local x = (j - minAll + 0.5) * perWidth
			local label = UIManager.createLabel(chartFlag.x + x, chartFlag.y - 10, 0, 0, j * sectionSize, {
				size = 16,
				color = Style.black
			})

			self:addChild(label, 100)
			table.insert(self.textStack, label)
		end

		for i, result in ipairs(self.resultStack) do
			local prePt = nil
			local canvas = display.newNode()

			for j = minAll, maxAll do
				local count = result.countMap[j]
				local x = (j - minAll + 0.5) * perWidth

				if count then
					local y = count / maxCount * chartFlag.height * 2 / 3
					local circle = display.newSolidCircle(5, {
						x = x,
						y = y
					})

					canvas:addChild(circle)

					local pt = {
						x,
						y
					}

					if prePt then
						local line = display.newLine({
							prePt,
							pt
						}, {
							radius = 5
						})

						canvas:addChild(line)
					end

					prePt = pt
				end
			end

			self:addChild(canvas, 100 + i)
			canvas:setPosition(chartFlag.x, chartFlag.y)
			table.insert(self.canvasStack, canvas)
		end
	end
end

function POP_attr_test:clearChart()
	self.resultStack = {}

	self:refreshChart()
end

function POP_attr_test:goTest(type)
	local loop = tonumber(self.loopEB:getText())
	local minSection, maxSection = nil
	local sectionCountMap = {}

	for i = 1, loop do
		local value = nil

		if type == 1 then
			value = self:unitTest1()
		elseif type == 2 then
			value = self:unitTest2()
		end

		local section = math.floor(value / sectionSize)

		if not minSection or section < minSection then
			minSection = section
		end

		if not maxSection or maxSection < section then
			maxSection = section
		end

		if not sectionCountMap[section] then
			sectionCountMap[section] = 0
		end

		sectionCountMap[section] = sectionCountMap[section] + 1
	end

	table.insert(self.resultStack, {
		min = minSection,
		max = maxSection,
		countMap = sectionCountMap
	})
	self:refreshChart()
end

function POP_attr_test:unitTest1()
	local random = Random.new(math.random(1, 65535))
	local attrAll = 0

	for i = 1, 6 do
		local attr = math.random() * 40 + 80
		attrAll = attrAll + attr
	end

	return attrAll
end

function POP_attr_test:unitTest2()
	return math.random() * 240 + 480
end

return POP_attr_test
