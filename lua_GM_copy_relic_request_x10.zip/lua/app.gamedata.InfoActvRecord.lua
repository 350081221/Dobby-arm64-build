local InfoActvRecord = {}
local dataMap = {}
local DAYS = 7

function InfoActvRecord.init()
	Connection.listen("actv_record_sync", InfoActvRecord.sync)
end

app:addToAppEnterCall(InfoActvRecord.init)

function InfoActvRecord.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoActvRecord.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("actv_record_query", callback)
end

function InfoActvRecord.onQuery(rcvData)
	dump(rcvData, "actv_record_query", 10)

	dataMap = {}

	for i, v in ipairs(rcvData.list) do
		dataMap[v.actv_id] = v
	end

	dump(dataMap, "$$$ dataMap")
end

function InfoActvRecord.sync(data)
	dump(data, "InfoActvRecord.sync", 10)

	if data.list then
		for i, syncData in ipairs(data.list) do
			if dataMap[syncData.actv_id] then
				for k, v in pairs(syncData) do
					dataMap[syncData.actv_id][k] = v
				end
			else
				dataMap[syncData.actv_id] = syncData
			end
		end
	end

	notify.dispatch("actv_redot")
	ManagerInfo.dataChange("actv_record")
end

function InfoActvRecord.checkOpening(actv_id)
	local opening = InfoActv.checkBindOpening(actv_id, GameConfig.ACTV_TYPE.record)

	return opening, actv_id
end

function InfoActvRecord.checkShopOpening(actv_id)
	local opening = InfoActv.checkBindShopOpening(actv_id, GameConfig.ACTV_TYPE.record)

	return opening, actv_id
end

function InfoActvRecord.getRecord(record, day)
	return BitUtil.getBitByIndex(record, day)
end

function InfoActvRecord.checkSign(actv_id, day)
	local data = dataMap[actv_id]

	if data then
		return InfoActvRecord.getRecord(data.sign_record, day) > 0
	end

	return false
end

function InfoActvRecord.checkRewarded(actv_id, day)
	local data = dataMap[actv_id]

	if data then
		return InfoActvRecord.getRecord(data.reward_record, day) > 0
	end

	return false
end

function InfoActvRecord.getCurrentDay(actv_id, noMinDays)
	local nowTime = Time.now()
	local stime = InfoActv.getTime(actv_id)
	local currentDay = RefreshManager.checkTimePassedDays(RefreshManager.TYPE.SIGN_IN, nowTime, stime)
	currentDay = currentDay + 1

	if noMinDays then
		return currentDay
	else
		return math.min(DAYS, currentDay)
	end
end

function InfoActvRecord.checkRedot(actv_id, day)
	local currentDay = InfoActvRecord.getCurrentDay(actv_id)

	if day <= currentDay then
		return InfoActvRecord.checkSign(actv_id, day) and not InfoActvRecord.checkRewarded(actv_id, day)
	end

	return false
end

function InfoActvRecord.getAwardList(actv_id)
	local arr = {}
	local config = dataMap[actv_id]

	if config then
		for i, v in ipairs(config.award) do
			v.config = config

			table.insert(arr, v)
		end
	end

	return arr
end

function InfoActvRecord.getJumpList()
	local arr = {}

	for k, v in pairs(dataMap) do
		if InfoActvRecord.countRedot(v.actv_id) > 0 then
			table.insert(arr, v)
		end
	end

	table.sort(arr, function (a, b)
		return b.actv_id < a.actv_id
	end)

	return arr
end

function InfoActvRecord.countRedot(actv_id)
	local redotCount = 0
	local opening = InfoActvRecord.checkOpening(actv_id)

	if opening then
		local config = dataMap[actv_id]
		local currentDay = InfoActvRecord.getCurrentDay(actv_id)

		for day = 1, currentDay do
			if InfoActvRecord.checkRedot(actv_id, day) then
				redotCount = redotCount + 1
			end
		end
	end

	return redotCount
end

function InfoActvRecord.getData(actv_id)
	return dataMap[actv_id]
end

function InfoActvRecord.getReward(day, actv_id, isRecover, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "actv_record_get_reward")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("actv_record_get_reward", {
		day = day,
		actv_id = actv_id,
		is_recover = isRecover and 1 or 0
	}, callback)
end

function InfoActvRecord.trySign(onSuccess, onFailure)
	local needTry = false

	for actv_id, data in pairs(dataMap) do
		local opening = InfoActvRecord.checkOpening(actv_id)

		if opening then
			local currentDay = InfoActvRecord.getCurrentDay(actv_id, true)

			if currentDay <= DAYS and not InfoActvRecord.checkSign(actv_id, currentDay) then
				needTry = true

				break
			end
		end
	end

	if not needTry then
		return
	end

	local function callback(rcvData)
		dump(rcvData, "actv_record_sign")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("actv_record_sign", callback)
end

return InfoActvRecord
