local UI_base = import("..UI_base")
local FRAME_abyss_prepare = class("FRAME_abyss_prepare", UI_base)
local TEAM_MAX = 3
local ptPerTile = 140
local heroIso = {
	{
		y = 2,
		x = 2
	},
	{
		y = 1,
		x = 2
	},
	{
		y = 0,
		x = 2
	}
}
local petIsoMap = {}
local isoDragThreshold = 10

function FRAME_abyss_prepare.open(abyssInfo)
	local ui = FRAME_abyss_prepare.new(abyssInfo)

	PopManager.open(ui, nil, , , 200)
end

function FRAME_abyss_prepare:ctor(abyssInfo)
	self.abyssInfo = abyssInfo
	local uiName = "frame_abyss_prepare"
	local funcCSV = InfoFunction.checkFuncOpen(10160)

	if funcCSV then
		uiName = "frame_abyss_prepare_speedup"
	end

	FRAME_abyss_prepare.super.ctor(self, uiName, UIManager.BIG_TYPE.POP)
	self:init()
end

function FRAME_abyss_prepare:init()
	self:initUI()

	local funcCSV = InfoFunction.checkFuncOpen(10160)

	if funcCSV then
		self:refreshAutopick()
		ManagerInfo.onDataChange(self, "dungeon", nil, function ()
			self:refreshAutopick()
		end)
	end

	self:createLabelOnFlag("flag_name", self.abyssInfo.name)
	self:replaceLabelGroupOnFlag("flag_depth", {
		self.abyssInfo.level
	}, {
		{
			color = Style.font3
		}
	})

	local dungeon_id, dungeon_num = InfoDungeon.getLayerRandomAbyss(self.abyssInfo.layer)

	print("$$$ dungeon_id", self.abyssInfo.layer, dungeon_id, InfoDungeon.getSeed())

	local abyssCSV = CsvParser.getCsvData("abyss", dungeon_id)
	local terrainCSV = CsvParser.getCsvData("abyss_terrain", abyssCSV.map_type)
	local multiStr = ""

	if dungeon_num > 1 then
		multiStr = Localization.getSrcText("（不稳定）")
	end

	local labelArray, lineArray, totalWidth, totalHeight, widthArray, heightArray = self:replaceLabelGroupOnFlag("flag_terrain", {
		terrainCSV.name,
		multiStr
	}, {
		{
			color = Style.font3
		}
	})
	local hintButton = self:getComponentByTag("hint")

	if dungeon_num > 1 then
		hintButton:setPositionX(labelArray[#labelArray]:getPositionX() + widthArray[#widthArray] / 2 + 15)
		hintButton:setVisible(true)
		hintButton:toTouchable()
		hintButton:addTap(function ()
			local x, y = hintButton:getPosition()
			local pos = self:convertToWorldSpace(cc.p(x, y))

			TinyHint.open(cc.p(pos.x, pos.y), Localization.getSrcText("标注为（不稳定）的深渊每次进入都会随机改变地形"))
		end)
	else
		hintButton:setVisible(false)
	end

	local info = InfoDungeon.getAbyssInfo(self.abyssInfo.layer)

	if info then
		local monster_border = self:getComponentByTag("monster_border")

		monster_border:setLocalZOrder(200)
		monster_border:setOpacity(175)

		local monsterDesc = nil
		local abyssMaxLayer = InfoDungeon.getAbyssMaxLayer()

		if abyssMaxLayer == 1 then
			abyssMaxLayer = 0
		end

		if not empty(info.monster) and abyssMaxLayer <= info.layer then
			local mugshotRect = self:getRectByFlag("flag_monster_icon")
			local portrait = PortraitManager.getMonsterMugshot(info.monster, mugshotRect, 3, 0, cc.p(0, 0))

			portrait:setPosition(mugshotRect.x + mugshotRect.width / 2, mugshotRect.y + mugshotRect.height / 2)
			self:addChild(portrait, 100)
			self:setComponentToTag("flag_monster_icon", portrait)

			local monsterCSV = CsvParser.getCsvData("monster", info.monster)
			monsterDesc = monsterCSV.desc

			if StringUtil.utf8len(monsterDesc) > 30 then
				monsterDesc = StringUtil.utf8sub(monsterDesc, 1, 28) .. "…"
			end

			monster_border:toTouchable()
			monster_border:setTapGroup("button_click")
			monster_border:addTap(function ()
				FRAME_monster_detail.open({
					base_id = info.monster
				})
			end)
		else
			self:createIconOnFlag("flag_monster_icon", IconManager.getHeadPic("wenhao"), 100, true)

			monsterDesc = Localization.getSrcText("未知魔物")
		end

		self:createLabelOnFlag("flag_monster_desc", monsterDesc, {
			wrap = true,
			valign = Style.vtop
		})

		local itemArr = {}
		local arr = string.split(info.reward_item, ";")

		for i, v in ipairs(arr) do
			if not empty(v) then
				local itemID = tonumber(v)

				if InfoItem.getNum(itemID) == 0 then
					table.insert(itemArr, {
						type = DropManager.TYPE.ITEM,
						info = {
							num = 1,
							base_id = itemID
						}
					})
				end
			end
		end

		local arr = string.split(info.item_display, ";")

		for i, v in ipairs(arr) do
			if not empty(v) then
				local itemID = tonumber(v)
				local itemCSV = CsvParser.getCsvData("item", itemID)

				if itemCSV.drop_level_min <= info.level + 3 and info.level <= itemCSV.drop_level_max then
					table.insert(itemArr, {
						type = DropManager.TYPE.ITEM,
						info = {
							num = 1,
							base_id = itemID
						}
					})
				end
			end
		end

		self.list:setAbyssLevel(self.abyssInfo.level)
		self.list:setItems(itemArr)

		local teamScore = InfoHero.getTeamScore()

		self:replaceLabelGroupOnFlag("flag_score", {
			teamScore
		}, {
			{
				color = Style.font3
			}
		})

		local style = {
			color = Style.font3
		}

		if teamScore < info.standard_score then
			style.color = Style.disableColor
		end

		self:replaceLabelGroupOnFlag("flag_score_standard", {
			info.standard_score
		}, {
			style
		})
	end
end

function FRAME_abyss_prepare:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local function tapListener(ui, data, index)
		DropManager.popDetail(data.type, data.info)
	end

	self.list = self:createListOnFlag("flag_reward", LIST_abyss_prepare, tapListener)

	self.list:setSpace(5, 5)
	self.list:setTapGroup("list_click")

	local enterBt = self:getComponentByTag("bt_enter")

	enterBt:toTouchable()
	enterBt:setTapGroup("button_click")
	enterBt:addTap(function ()
		if InfoHero.countTeam() < GameConfig.hero_team_num then
			Alert.open(StringUtil.replace(Localization.getSrcText("队伍不满{1}人"), GameConfig.hero_team_num))

			return
		end

		TaHelper.taGuideDetail(13900)
		TaHelper.taGuideDetail(14800)

		local function onSuccess(rcvData)
			DungeonScene.enterDungeon(DungeonScene.ENTER_TYPE.NEW, rcvData)
		end

		local speedup = self.speedup and 1 or 0

		print("$$$ speedup", speedup)
		InfoDungeon.enter(InfoDungeon.TYPE.ABYSS, {
			layer = self.abyssInfo.layer,
			dungeon_id = self.abyssInfo.id,
			speedup = speedup
		}, onSuccess)
	end)

	local funcCSV = InfoFunction.checkFuncOpen(10160)

	if funcCSV then
		local speedup_item = CsvParser.getCsvData("config", "speedup_item").value
		local item_csv = CsvParser.getCsvData("item", speedup_item)
		local slot = DropSlot.new(self:getFlagByTag("flag_speedup_slot"), "slot_04")

		slot:setDetailEnabled(true)
		slot:setAlwaysShowNumber(true)
		self:addChild(slot, 100)
		slot:setDrop(DropManager.TYPE.ITEM, {
			base_id = speedup_item,
			num = InfoItem.getNum(speedup_item)
		})

		local label_yes = self:getComponentByTag("label_speedup_yes")
		local label_no = self:getComponentByTag("label_speedup_no")
		local selected_speedup = self:getComponentByTag("selected_speedup")

		local function refreshOpen()
			selected_speedup:setVisible(self.speedup)
			label_yes:setVisible(self.speedup)
			label_no:setVisible(not self.speedup)
		end

		refreshOpen()

		local bg = self:getComponentByTag("speedup_bg")

		bg:toTouchable()
		bg:setOpacity(0)
		bg:setTapGroup("bg_click")
		bg:addTap(function ()
			if self.speedup then
				self.speedup = nil
			else
				if InfoItem.getNum(speedup_item) <= 0 then
					Alert.open(item_csv.name .. Localization.getSrcText("不足"))

					return
				end

				self.speedup = true
			end

			refreshOpen()
		end)

		local slot = DropSlot.new(self:getFlagByTag("flag_autopick_slot"), "slot_04")

		slot:setDetailEnabled(true)
		slot:setAlwaysShowNumber(true)
		self:addChild(slot, 100)

		self.autopickSlot = slot
		local autopick_bg = self:getComponentByTag("autopick_bg")

		autopick_bg:toTouchable()
		autopick_bg:setOpacity(0)
		autopick_bg:setTapGroup("bg_click")
		autopick_bg:addTap(function ()
			FRAME_autopick.open()
		end)
	end
end

function FRAME_abyss_prepare:refreshAutopick()
	local funcCSV = InfoFunction.checkFuncOpen(10160)

	if funcCSV then
		local autopick_item = CsvParser.getCsvData("config", "autopick_item").value

		self.autopickSlot:setDrop(DropManager.TYPE.ITEM, {
			base_id = autopick_item,
			num = InfoItem.getNum(autopick_item)
		})

		local label_yes = self:getComponentByTag("label_autopick_yes")
		local label_no = self:getComponentByTag("label_autopick_no")

		local function refreshTime()
			local nowTime = math.floor(Time.now())
			local time = InfoDungeon.autoPickTime()

			if time <= nowTime then
				label_no:setVisible(true)
				label_yes:setVisible(false)
				self:removeEnterFrame("refreshTime_autopick")

				self.autopickTimeStr = nil
			else
				label_no:setVisible(false)

				local timeLeft = time - nowTime
				local timeStr = Time.showMin(timeLeft)

				if self.autopickTimeStr ~= timeStr then
					self.autopickTimeStr = timeStr

					self:replaceLabelOnFlag("label_autopick_yes", nil, timeStr)
				end
			end
		end

		self:addEnterFrame("refreshTime_autopick", refreshTime)
		refreshTime()
	end
end

return FRAME_abyss_prepare
