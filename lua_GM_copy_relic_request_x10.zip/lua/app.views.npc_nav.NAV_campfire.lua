local NAV_base = import(".NAV_base")
local NAV_campfire = class("NAV_campfire", NAV_base)

function NAV_campfire.open(npc)
	local ui = NAV_campfire.new(npc)

	return ui
end

function NAV_campfire:ctor(npc)
	NAV_campfire.super.ctor(self, npc, "nav_campfire")
end

function NAV_campfire:init()
	NAV_campfire.super.init(self)
end

function NAV_campfire:onTap(index)
	NAV_campfire.super.onTap(self, index)

	if index == 1 then
		FRAME_campfire.open(self.npc)
	end
end

return NAV_campfire
