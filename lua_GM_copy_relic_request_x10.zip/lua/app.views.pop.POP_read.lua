local POP_read = class("POP_read", UI_base)

function POP_read.open(title, percent)
	local ui = POP_read.new(title, percent)
	POP_read.instance = ui

	ui:setOpacity(0)
	transition.fadeTo(ui, {
		easing = "sineOut",
		time = 0.2,
		opacity = 255
	})
	display.getRunningScene():addChild(ui, LayerConfig.read)

	return ui
end

function POP_read.setPercent(percent)
	if POP_read.instance then
		POP_read.instance:_setPercent(percent)
	end
end

function POP_read.close()
	if POP_read.instance then
		local ui = POP_read.instance

		transition.fadeTo(ui, {
			easing = "sineOut",
			time = 0.2,
			opacity = 0,
			onComplete = function ()
				ui:removeSelf()
			end
		})

		POP_read.instance = nil
	end
end

function POP_read:ctor(title, percent)
	POP_read.super.ctor(self, "pop_read", UIManager.BIG_TYPE.POP)

	self.title = title

	self:init()
	self:_setPercent(percent or 0)
end

function POP_read:init()
	self:initUI()
end

function POP_read:initUI()
	self:createLabelOnFlag("flag_title", self.title)

	self.progressBar = self:createBarByTag("bar")
	local right_arrow = self:getComponentByTag("right_arrow")

	right_arrow:setScaleX(-1)
end

function POP_read:_setPercent(percent)
	self:setBarProgressByTag("bar", percent)

	local head = self:getComponentByTag("head")
	local bar = self:getComponentByTag("bar")

	head:setPos(bar.x + bar.width * percent - 28)
end

return POP_read
