local CombatUnit = import(".CombatUnit")
local Tile = import("..map.Tile")
local HeroGwar = class("HeroGwar", CombatUnit)

function HeroGwar:ctor()
	HeroGwar.super.ctor(self, "hero_gwar")

	self.activeSkill = nil
	self.alwaysVisible = true
	self.alwaysActive = true
	self.fixedLight = 255
	self.isBlock = false
	self.noBlock = true
	self.jumpNoRetile = true
	self.attackAction = "attack"
end

function HeroGwar.combineData(heroInfo)
	local jobData = CsvParser.getCsvData("hero", heroInfo.base_id, true)
	local avatarList = SheetUtil.getColumnListFull(jobData, {
		"avatar_index_",
		"avatar_id_"
	}, {
		"avatar",
		"value"
	})

	for i, v in ipairs(avatarList) do
		jobData[v.avatar] = v.value
	end

	jobData.gender = "male"

	if string.find(heroInfo.body, "female", 1, true) then
		jobData.gender = "female"
	end

	jobData.model = heroInfo.body
	jobData.avatar_1 = heroInfo.hair
	jobData.name = heroInfo.name

	return jobData
end

function HeroGwar:setMonster(base_id)
	local monCSV = CsvParser.getCsvData("gwar_monster", base_id, true)
	local monData = ObjUtil.clone(monCSV)
	local avatarList = SheetUtil.getColumnListFull(monCSV, {
		"avatar_index_",
		"avatar_id_"
	}, {
		"avatar",
		"value"
	})

	for i, v in ipairs(avatarList) do
		monData[v.avatar] = v.value
	end

	self.base_id = base_id
	self.size = monData.size

	self:setScale(monData.scale)
	self:setData(monData)
end

function HeroGwar:setInfo(heroInfo, copy)
	self.info = heroInfo
	self.copy = copy
	local heroData = HeroGwar.combineData(heroInfo)

	for equip_pos in pairs(GameConfig.display_equip_pos) do
		local equipBaseID = heroInfo["equip_" .. equip_pos]

		if not empty(equipBaseID) then
			local equipData = CsvParser.getCsvData("equip", equipBaseID)

			if not empty(equipData.avatar) then
				heroData[equipData.avatar] = equipData.avatar_id
			end
		end
	end

	self:setData(heroData)
end

function HeroGwar:init(teamOne)
	self.teamOne = teamOne
	self.battleData = {
		hp = self.teamOne.battleData.hp
	}
end

function HeroGwar:setHp(hp)
	self.battleData.hp = hp
end

function HeroGwar:resetHp()
	self.battleData.hp = self.teamOne.battleData.hp
end

function HeroGwar:damageHp(dmg)
	self.battleData.hp = math.max(0, self.battleData.hp - dmg)

	self:dispatchEvent({
		name = "hp_changed"
	})
	self:hudSetHP(self.battleData.hp / self.teamOne.battleData.hpMax)
	self:checkDie()
end

function HeroGwar:lockDie(isLocked)
	self.dieLocked = isLocked

	if not isLocked then
		self:checkDie()
	end
end

function HeroGwar:checkDie()
	if self.teamOne.isBoss then
		return
	end

	if not self.dieLocked and self.battleData.hp <= 0 then
		self:die()
	end
end

function HeroGwar:setAction(action, loop, overFunc, startFrame)
	if action == "idle" then
		action = self.battleIdleAction
	end

	HeroGwar.super.setAction(self, action, loop, overFunc, startFrame)
end

function HeroGwar:rawSetAction(action, loop, overFunc, startFrame)
	HeroGwar.super.setAction(self, action, loop, overFunc, startFrame)
end

function HeroGwar:setData(data)
	HeroGwar.super.setData(self, data)
	self:updateAvatar()
	self:setAction(self.action)

	if data.class == 1 then
		if self:hasAction("atk_w") then
			self:setMappedAction("attack", "atk_w")
		end

		self.battleIdleAction = "idle_w"
	end

	if data.class == 2 then
		if self:hasAction("atk_a") then
			self:setMappedAction("attack", "atk_a")
		end

		self.battleIdleAction = "idle_a"
	end

	if data.class == 3 then
		if self:hasAction("atk_m") then
			self:setMappedAction("attack", "atk_m")
		end

		self.battleIdleAction = "idle_m"
	end

	self.data.speed = 8
	self.speed = self.data.speed
end

function HeroGwar:updateAvatar()
	if self.noAvatar then
		return
	end

	for i = 1, #Unit.AVATAR_LAYERS do
		if not empty(self.data["avatar_" .. i]) then
			local avatarStr = self.data["avatar_" .. i]
			avatarStr = StringUtil.replaceTag(avatarStr, self.data)

			self:setAvatar(avatarStr, i)
		else
			self:removeAvatar(i)
		end
	end

	self:dispatchEvent({
		name = "update_avatar"
	})
end

function HeroGwar:setDieout(isDieout)
	self.isDieout = isDieout
end

function HeroGwar:die()
	if not self.battleData.die then
		HeroGwar.super.die(self)
		MapFrameManager.stopLoop(self, self.updateFunc)

		self.bladeDisabled = true

		if self.shadow then
			self.shadow:removeSelf()

			self.shadow = nil
		end

		transition.fadeTo(self, {
			opacity = 0,
			time = 0.5,
			onComplete = function ()
				MapFrameManager.setTimeout(function ()
					self:removeSelf()
				end, MiscConfig.unit_delay_remove)
			end
		})
		self:backJump(math.random(200, 250), 60)
		self:removeFromMap()
	end
end

function HeroGwar:castHandSkill(skillPack, target)
	if self.casting.step == 2 or self.casting.step == 5 then
		local castingSkillData = SkillManager.getSkillData(self, self.casting.skillPack)

		if castingSkillData.type == 2 then
			self.readyHandSkill = {
				skillPack = skillPack,
				target = target
			}

			return
		end
	end

	self:castManualSkill(skillPack, target)

	if target.battleData and not target.battleData.die then
		self.battleData.target = target
	end
end

function HeroGwar:onCastOver()
	HeroGwar.super.onCastOver(self)

	if self.readyHandSkill then
		local fullFrameTime = WarMachine.getFrame()
		local skillPack = self.readyHandSkill.skillPack

		if skillPack.cd <= fullFrameTime and SkillManager.checkPower(skillPack, fullFrameTime) then
			self:castHandSkill(skillPack, self.readyHandSkill.target)

			self.readyHandSkill = nil
		end
	end
end

function HeroGwar:interruptSkill()
	HeroGwar.super.interruptSkill(self)

	self.readyHandSkill = nil
end

function HeroGwar:onBattleStart()
end

function HeroGwar:onBattleOver()
	HeroGwar.super.onBattleOver(self)
	self:setHudVisible(false)
end

function HeroGwar:goTile(tile, onComplete)
	local path = self.map:findPath(self.tile, tile, self.walkLevel, self.size, nil, function ()
		return true
	end)

	if path and #path > 0 then
		local result = self:goPath(path, true)

		self:setPathFinishedCallback(onComplete)

		return result
	end

	return false
end

function HeroGwar:updateCastSkill()
	local fullFrameTime = MapFrameManager.getFrame()

	if self.casting.time <= fullFrameTime and self.casting.step > 0 then
		if self.casting.step == 1 or self.casting.step == 5 then
			if self.casting.isMonster then
				self:attackAnimation()
			else
				local targetObj = nil

				if self.casting.isRange then
					targetObj = table.remove(self.casting.castArr, 1)
				elseif self.casting.isMelee then
					targetObj = self.casting.castObj
				end

				self.casting.target = targetObj.target
				self.casting.dmgPack = targetObj.dmgPack

				if self.casting.step == 5 then
					self.casting.time = fullFrameTime + GwarPlay.multiple_interval

					self:attackAnimation(self.casting.target, GwarPlay.multiple_interval)
				else
					local actionTime = 0
					local spineAttackTime = nil

					if self.clipType == CLIP_TYPE.SPINE then
						spineAttackTime = self:getSpineEventTime(self.attackAction, "attack")
					end

					actionTime = spineAttackTime or math.floor(self:getActionTotalFrameTime(self.attackAction) * 3 / 4)
					self.casting.time = fullFrameTime + actionTime

					self:attackAnimation(self.casting.target)
				end
			end

			self.casting.step = 2
		elseif self.casting.step == 2 then
			if self.casting.isMonster then
				self:castDoMonster()
			else
				self:castDo()
			end

			if self.casting.isRange and #self.casting.castArr > 0 then
				self.casting.step = 5
			else
				self.casting.step = 3
				local animTime = self:getActionTotalFrameTime(self.attackAction)
				animTime = animTime / 4

				if self.casting.isMeleeFinal then
					self.casting.time = fullFrameTime + math.floor(animTime)
				else
					self.casting.time = fullFrameTime
				end
			end

			if self.casting.step == 3 then
				self:onCastOver()
			end
		elseif self.casting.step == 3 then
			self.casting.step = 0

			MapFrameManager.stopLoop(self, self.updateFunc)
		elseif self.casting.step == 6 then
			if self.casting.target and self.casting.target.tile then
				self:battleFollow(self.casting.target)
			else
				self.casting.step = 0

				MapFrameManager.stopLoop(self, self.updateFunc)

				local onComplete = self.casting.onComplete

				if onComplete then
					onComplete()
				end
			end
		end
	end
end

function HeroGwar:attackAnimation(unit, limitedActionTime)
	if unit then
		self:faceTo(unit)
	end

	local startFrame = 1

	if limitedActionTime then
		startFrame = math.floor(self:getFrameCount(self.attackAction) - self:getFrameByFrameTime(self.attackAction, limitedActionTime))
		startFrame = math.max(startFrame, 1)
	end

	self:setAction(self.attackAction, 1, function ()
		self:setAction("idle")
	end, startFrame)
end

function HeroGwar:hurtAnimation()
	local function doHurtAnimation()
		if self:hasAction("hurt") and self.action == "idle" and (self.casting.step == 0 or self.casting.step == 4) then
			self:setAction("hurt")
		end

		self.hurtAnimationData = {}

		self:setColor(cc.c3b(128, 0, 0))

		self.hurtAnimationData.timeoutID = MapFrameManager.setTimeout(function ()
			self.hurtAnimationData = nil

			self:refreshVisible()

			if self.action == "hurt" then
				self:setAction("idle")
			end
		end, 10, self)
	end

	if self.hurtAnimationData ~= nil then
		MapFrameManager.clearTimeout(self.hurtAnimationData.timeoutID)
		self:refreshVisible()
		MapFrameManager.setTimeout(doHurtAnimation, 2, self)
	else
		doHurtAnimation()
	end

	self:backJump()
end

function HeroGwar:backJump(dis, height, speed)
	if not self.tile then
		return
	end

	local knockDis = dis or 32
	local knockHeight = height or 20
	local knockSpeed = speed or 30
	local angle = self.campAngle + math.pi
	local mapX, mapY = self.map:tileToMap(self.tile)
	local x2 = math.cos(angle) * knockDis + mapX
	local y2 = math.sin(angle) * knockDis + mapY

	self:stop(14)
	self:draw(mapX, mapY)
	self:jump({
		x = x2,
		y = y2
	}, knockSpeed, knockHeight)

	self.angle = self.campAngle
end

function HeroGwar:findMeleeTile(unit)
	local path, pathFound = nil

	if self:checkMeleeTile(unit) then
		path = true
		pathFound = true
	elseif self:getState("no_move") then
		path = {}
		pathFound = false
	else
		path, pathFound = self.map:findPath(self.tile, unit.tile, self.walkLevel, self.size, function (tile)
			return self:checkMeleeTile(unit, tile)
		end, self)

		if not pathFound and self:isFriendCross() then
			path, pathFound = self.map:findPath(self.tile, unit.tile, self.walkLevel, self.size, function (tile)
				return self:checkMeleeTile(unit, tile, true)
			end, function (tile, unitMap)
				return self:checkUnitBlockCamp(tile, unitMap)
			end)
		end
	end

	return path, pathFound
end

function HeroGwar:battleFollow(unit)
	local fullFrameTime = MapFrameManager.getFrame()
	local path, pathFound = self:findMeleeTile(unit)

	if path == true then
		self:stop()

		self.casting.step = 1
	elseif #path > 0 then
		self:goPath(path)
	end
end

function HeroGwar:castDoTarget(target, dmgPack)
	target:hurtAnimation()
	target:damageHp(dmgPack.dmg)

	local fontFamily = "font_dmg_"
	local fontZ = 0

	if dmgPack.isCritical then
		fontFamily = "font_dmg_s_"
		fontZ = 100
	end

	target:jumpDmg(dmgPack.dmg, fontFamily, fontZ)

	if target.teamOne and target.teamOne.isBoss then
		local gcore = display.getRunningScene().gcore
		local gplay = display.getRunningScene().gplay

		gplay:onCastBoss(dmgPack.dmg)
	end

	if dmgPack.isBlock then
		local effect = target:addEffect(MiscConfig.block_effect)
		local caster = self

		if caster and caster.x and caster.y and caster.z then
			effect:setRotateByPosition(self.map.topType == Map.TOP_90, caster.x, caster.y, caster.z, target.x, target.y, target.z)
		end
	end

	if dmgPack.isDodge then
		target:jumpWord("m", "font_misc_", 0)
	end

	if dmgPack.isShield then
		target:removeLastingEffect(MiscConfig.shield_effect, true)

		local effectGen = target:getEffectGen()

		if effectGen then
			effectGen:castEffect(MiscConfig.shield_hit_effect, target)
		end
	end

	if not empty(self.data.gwar_hurt_effect) then
		local effectGen = target:getEffectGen()

		if effectGen then
			effectGen:castEffect(self.data.gwar_hurt_effect, target)
		end
	end
end

function HeroGwar:castDoMonster()
	local csv = CsvParser.getCsvData("gwar_monster", self.base_id)
	local checkCount = 0

	local function checkComplete()
		if checkCount == 0 then
			local onComplete = self.casting.onComplete

			if csv.action_type ~= 1 and self.originalTile then
				local mapX, mapY = self.map:tileToMap(self.originalTile)

				self:draw(mapX, mapY, true)
			end

			if onComplete then
				onComplete()
			end
		end
	end

	for i, targetObj in ipairs(self.casting.castArr) do
		local target = targetObj.target
		local dmgPack = targetObj.dmgPack
		local distance = math.max(0, target.tile.x - (self.tile.x + self.size)) * self.map.ptPerTile
		local delayTime = 0

		if not empty(csv.affect_speed) and csv.affect_speed > 0 then
			delayTime = math.floor(distance / csv.affect_speed)
		end

		if delayTime > 0 then
			checkCount = checkCount + 1

			MapFrameManager.setTimeout(function ()
				self:castDoTarget(target, dmgPack)

				checkCount = checkCount - 1

				checkComplete()
			end, delayTime, self)
		else
			self:castDoTarget(target, dmgPack)
		end
	end

	checkComplete()
end

function HeroGwar:castDo()
	local target = self.casting.target
	local dmgPack = self.casting.dmgPack
	local jumpWordTime = 45

	if not empty(self.data.gwar_cast_effect) then
		local effectGen = self:getEffectGen()

		if effectGen then
			effectGen:castEffect(self.data.gwar_cast_effect, self)
		end
	end

	local function onHurt()
		if not dmgPack then
			return
		end

		self:castDoTarget(target, dmgPack)

		if self.casting.hurtLeft > 1 then
			self.casting.hurtLeft = self.casting.hurtLeft - 1
		else
			local onComplete = self.casting.onComplete

			if onComplete then
				onComplete()
			end
		end
	end

	if self.casting.isRange then
		local effect = "effect_enegyball"

		if not empty(self.data.gwar_fly_effect) then
			local effectGen = self:getEffectGen()

			if effectGen then
				effectGen:castEffect(self.data.gwar_fly_effect, target, onHurt)
			end
		else
			local effectGen = self:getEffectGen()

			if effectGen then
				local effect = "effect_enegyball"

				effectGen:missle(onHurt, self, target, effect, 30, 30)
			end
		end
	else
		onHurt()
	end
end

function HeroGwar:castMonster(attackArr, onComplete)
	self.casting = {
		isMonster = true,
		step = 1,
		time = MapFrameManager.getFrame(),
		castArr = attackArr,
		onComplete = onComplete
	}

	local function startCast()
		if not empty(self.data.gwar_cast_effect) then
			local effectGen = self:getEffectGen()

			if effectGen then
				effectGen:castEffect(self.data.gwar_cast_effect, self)
			end
		end

		function self.updateFunc()
			self:updateCastSkill()
		end

		MapFrameManager.startLoop(self, self.updateFunc)
	end

	local csv = CsvParser.getCsvData("gwar_monster", self.base_id)

	if csv.action_type == 1 then
		startCast()
	else
		self.originalTile = self.tile
		local tileX, tileY = GwarPlay.getMonsterCenter(self, csv.action_type)
		local mapX, mapY = self.map:tileToMap(tileX, tileY)

		self:jump({
			x = mapX,
			y = mapY
		}, 10, 30, startCast)
	end
end

function HeroGwar:castRange(attackArr, onComplete)
	self.casting = {
		isRange = true,
		hurtLeft = #attackArr,
		step = 1,
		time = MapFrameManager.getFrame(),
		castArr = attackArr,
		onComplete = onComplete
	}

	function self.updateFunc()
		self:updateCastSkill()
	end

	MapFrameManager.startLoop(self, self.updateFunc)
end

function HeroGwar:castMelee(castObj, isFinal, onComplete)
	self.casting = {
		isMelee = true,
		isMeleeFinal = isFinal,
		hurtLeft = 1,
		step = 6,
		time = MapFrameManager.getFrame(),
		castObj = castObj,
		target = castObj.target,
		dmgPack = castObj.dmgPack,
		onComplete = onComplete
	}

	function self.updateFunc()
		self:updateCastSkill()
	end

	MapFrameManager.startLoop(self, self.updateFunc)
end

function HeroGwar:setHudVisible(visible, color, style)
	local color = nil

	if self.camp == 1 then
		color = cc.c3b(35, 180, 28)
	else
		color = cc.c3b(248, 184, 16)
	end

	HeroGwar.super.setHudVisible(self, visible, color, style)
end

return HeroGwar
