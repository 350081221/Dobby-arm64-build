local List = import("...ui.List")
local LIST_emu_myteam = class("LIST_emu_myteam", List)

function LIST_emu_myteam:ctor(rect)
	LIST_emu_myteam.super.ctor(self, rect)
	self:setCellName("cell_emu_myteam")
	self:setSpace(0, 5)
	self:setCellSize(cc.size(self.touchRect.width, 40))
end

function LIST_emu_myteam:onCellInit(ui, data, index)
	ui:createLabelOnFlag("flag_level", data.level)
	ui:createLabelOnFlag("flag_battle", data.winCount .. "/" .. data.battleCount)
	ui:createLabelOnFlag("flag_time", data.time)
	ui:createLabelOnFlag("flag_hp", data.hp)
	ui:createLabelOnFlag("flag_die", data.die)
	self:onCellSelected(ui, data, self.selectedIndex == index)
end

function LIST_emu_myteam:onCellSelected(ui, data, selected)
	local bg = ui:getComponentByTag("bg")

	bg:setOpacity(150)
	bg:setVisible(selected)
end

return LIST_emu_myteam
