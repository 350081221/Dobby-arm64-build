local NAV_base = import(".NAV_base")
local NAV_hatch_put = class("NAV_hatch_put", NAV_base)

function NAV_hatch_put.open(npc, pos)
	local ui = NAV_hatch_put.new(npc, pos)

	return ui
end

function NAV_hatch_put:ctor(npc, pos)
	NAV_hatch_put.super.ctor(self, npc, "nav_hatch_put")

	self.pos = pos
end

function NAV_hatch_put:init()
	NAV_hatch_put.super.init(self)
end

function NAV_hatch_put:onTap(index)
	NAV_hatch_put.super.onTap(self, index)

	if index == 1 then
		FRAME_pet_hatch.open(self.npc, self.pos)
	end
end

return NAV_hatch_put
