local CombatAttr = {
	attrs = {
		"hp",
		"atk",
		"def"
	}
}
local attrs = CombatAttr.attrs
CombatAttr.elements = {
	"fire",
	"ice",
	"lightning",
	"poison"
}
local elements = CombatAttr.elements
local summon_add = {
	"hp",
	"atk",
	"critical",
	"critical_value",
	"critical",
	"dmgadd",
	"dmgresis",
	"attack_speed"
}
CombatAttr.summon_add = summon_add
local element_effects = {
	"@hit_fire_01",
	"@hit_ice_01",
	"@hit_lightning_01",
	"@hit_poison_01"
}
local elementEffectMap = nil

function CombatAttr.getElementEffect(element)
	if not elementEffectMap then
		elementEffectMap = {}

		for i, v in ipairs(CombatAttr.elements) do
			if element_effects[i] then
				elementEffectMap[v] = element_effects[i]
			end
		end
	end

	return elementEffectMap[element]
end

local attrPercentMap = nil

local function init()
	attrPercentMap = {}
	local attrCSV = CsvParser.getCsvRaw("attr")

	for k, v in pairs(attrCSV) do
		if not empty(v.percent) then
			attrPercentMap[v.percent] = true
		end
	end
end

app:addToAppEnterCall(init)

function CombatAttr.isPercentAttr(attr)
	return attrPercentMap[attr]
end

function CombatAttr.clearCache()
	CombatAttr.descCache = nil
	CombatAttr.nameCache = nil
end

function CombatAttr.setAttrLevel(level)
	print("$$$ CombatAttr.setAttrLevel", level)

	CombatAttr.attrLevel = level
end

function CombatAttr.getAttrLevel()
	local attrLevel = CombatAttr.attrLevel or InfoDungeon.getAbyssMaxLevel()
	attrLevel = math.max(1, attrLevel)

	return CsvParser.getCsvData("attr_level", attrLevel)
end

local TYPE = {
	MODAO = 2,
	UNIT = 1,
	ITEM = 4,
	GLOBAL = 3
}
CombatAttr.TYPE = TYPE
local BUFF_TYPE = {
	NORMAL = 1,
	CARD = 3,
	SHRINE = 2
}
CombatAttr.BUFF_TYPE = BUFF_TYPE
local attrIndexList = nil

function CombatAttr.getAttrIndexList()
	if not attrIndexList then
		local csvList = CsvParser.getCsvList("attr", "__line")
		attrIndexList = {}

		for i, v in ipairs(csvList) do
			if v.type == 1 then
				table.insert(attrIndexList, v.id)
			end
		end
	end

	return attrIndexList
end

function CombatAttr.getModaoData()
	return CombatAttr.getModaoAndGlobalData(TYPE.MODAO)
end

function CombatAttr.getGlobalData()
	return CombatAttr.getModaoAndGlobalData(TYPE.GLOBAL)
end

function CombatAttr.testModaoAndGlobalData()
	local modaoAttrs, heroAttrsMap, petAttrsMap = CombatAttr.getModaoAndGlobalData(TYPE.MODAO)
	local globalAttrs = CombatAttr.getModaoAndGlobalData(TYPE.GLOBAL)

	return modaoAttrs, globalAttrs, heroAttrsMap, petAttrsMap
end

function CombatAttr.getModaoAndGlobalData(type)
	local modaoAttrs = {}
	local modaoAttrsDefault = {}
	local attrCSV = CsvParser.getCsvRaw("attr")

	for k, v in pairs(attrCSV) do
		if v.type == type then
			modaoAttrs[k] = v.default
			modaoAttrsDefault[k] = v.default
		end
	end

	local exBuffs = {}
	local manualAttr = InfoManual.getAttr()
	local petAttrData = CombatAttr.getPetTohero()
	local shrineData = InfoDungeon.getShrineData()

	for index, shrineInfo in pairs(shrineData) do
		local buffID = shrineInfo.id

		if not SkillManager.isNoneAttrBuff(buffID) then
			local buffData = CsvParser.getCsvData("buff", buffID)
			local attrList = SheetUtil.getColumnList(buffData, {
				"attr_",
				"mul_value_",
				"add_value_",
				"attr_index",
				"attr_multi"
			}, {
				"attr",
				"mul",
				"add",
				"attr_index",
				"attr_multi"
			})
			local buffSeed = shrineInfo.seed

			if #attrList == 0 then
				SkillManager.markNoneAttrBuff(buffID)
			else
				table.insert(exBuffs, {
					id = buffID,
					seed = buffSeed,
					attrList = attrList
				})
				CombatAttr.attrAddupModaoAndGlobal(type, attrList, modaoAttrs, modaoAttrsDefault, buffSeed)
			end
		end
	end

	local unionBuff = InfoDungeon.getUnionBuff()
	local unionBuffData = {}

	for i, v in ipairs(unionBuff) do
		local csv = CsvParser.getCsvData("union_buff", v)
		local buffArr = SheetUtil.getColumnValueList(csv, "buff_id_")

		for i, v in ipairs(buffArr) do
			table.insert(unionBuffData, v)
		end
	end

	for index, buffID in pairs(unionBuffData) do
		if not SkillManager.isNoneAttrBuff(buffID) then
			local buffData = CsvParser.getCsvData("buff", buffID)
			local attrList = SheetUtil.getColumnList(buffData, {
				"attr_",
				"mul_value_",
				"add_value_",
				"attr_index",
				"attr_multi"
			}, {
				"attr",
				"mul",
				"add",
				"attr_index",
				"attr_multi"
			})
			local buffSeed = 1

			if #attrList == 0 then
				SkillManager.markNoneAttrBuff(buffID)
			else
				table.insert(exBuffs, {
					id = buffID,
					seed = buffSeed,
					attrList = attrList
				})
				CombatAttr.attrAddupModaoAndGlobal(type, attrList, modaoAttrs, modaoAttrsDefault, buffSeed)
			end
		end
	end

	if type == TYPE.MODAO and WarMachine.on then
		local units = WarMachine.getUnits()

		for j, unit in ipairs(units) do
			if unit.battleData and unit.battleData.camp == 1 and not unit.battleData.die then
				for _type, buffTypeArr in pairs(unit.buffStackMap) do
					for i, obj in ipairs(buffTypeArr) do
						if not SkillManager.isNoneAttrBuff(obj.id) then
							local buffData = CsvParser.getCsvData("buff", obj.id)
							local attrList = SheetUtil.getColumnList(buffData, {
								"attr_",
								"mul_value_",
								"add_value_",
								"attr_index",
								"attr_multi"
							}, {
								"attr",
								"mul",
								"add",
								"attr_index",
								"attr_multi"
							})

							if #attrList == 0 then
								SkillManager.markNoneAttrBuff(obj.id)
							else
								CombatAttr.attrAddupModaoAndGlobal(type, attrList, modaoAttrs, modaoAttrsDefault, 0)
							end
						end
					end
				end
			end
		end
	end

	local petTeam = InfoPet.getTeam()
	local petAttrsMap = {}

	for i, petInfo in ipairs(petTeam) do
		local petAttrs = CombatAttr.getPetAttr(petInfo)

		CombatAttr.finalize(petAttrs)

		for k, v in pairs(petAttrs) do
			local attrCSV = CsvParser.getCsvData("attr", k)

			if attrCSV.type == type then
				modaoAttrs[k] = modaoAttrs[k] + v
			end
		end

		petAttrsMap[petInfo.id] = petAttrs
	end

	local heroTeam = InfoHero.getTeam()
	local heroAttrsMap = {}

	for i, heroInfo in ipairs(heroTeam) do
		if InfoDungeon.inDust() then
			heroInfo = InfoDust.cloneSample(heroInfo) or heroInfo
		end

		local heroAttrs = CombatAttr.getHeroAttr(heroInfo, nil, , petAttrData, manualAttr)
		local originalData = {}

		for k, v in pairs(heroAttrs) do
			originalData[k] = v
		end

		for j, buffObj in ipairs(exBuffs) do
			CombatAttr.attrAddup(buffObj.attrList, heroAttrs, originalData, BUFF_TYPE.SHRINE, buffObj.seed)
		end

		CombatAttr.finalize(heroAttrs)

		for k, v in pairs(heroAttrs) do
			local attrCSV = CsvParser.getCsvData("attr", k)

			if attrCSV.type == type then
				modaoAttrs[k] = modaoAttrs[k] + v
			end
		end

		heroAttrsMap[heroInfo.id] = heroAttrs
	end

	local plusArr = InfoBuilding.getPlusDataList(InfoBuilding.TAG.MONO, 401)
	local plusAddMap = {}

	for i, plusData in ipairs(plusArr) do
		plusAddMap[plusData.value1] = plusData.value2
	end

	local attrLevel = CombatAttr.getAttrLevel()

	for k, v in pairs(modaoAttrs) do
		local attrCSV = CsvParser.getCsvData("attr", k)

		if not empty(modaoAttrs[attrCSV.attr_add]) then
			modaoAttrs[k] = modaoAttrs[k] + modaoAttrs[attrCSV.attr_add] * attrLevel[attrCSV.attr_add] * attrCSV.attr_add_ratio
		end

		if not empty(modaoAttrs[attrCSV.percent]) then
			modaoAttrs[k] = modaoAttrs[k] * (1 + modaoAttrs[attrCSV.percent] / 100)
		end

		if plusAddMap[k] then
			modaoAttrs[k] = modaoAttrs[k] + plusAddMap[k]
		end

		modaoAttrs[k] = math.floor(math.min(math.max(modaoAttrs[k], attrCSV.min), attrCSV.max))
	end

	return modaoAttrs, heroAttrsMap, petAttrsMap
end

function CombatAttr.attrAddup(attrList, attrs, originalData, type, seed)
	local random = Random.new(seed)

	for _, obj in ipairs(attrList) do
		local attr = obj.attr
		local mul = obj.mul
		local add = obj.add
		local attr_index = obj.attr_index
		local attr_multi = obj.attr_multi
		local attrCSV = CsvParser.getCsvData("attr", attr)

		if (type ~= BUFF_TYPE.SHRINE or attrCSV.type == 1) and attrs[attr] then
			if not empty(mul) then
				attrs[attr] = attrs[attr] + originalData[attr] * SheetUtil.getNumber(mul, random) / 100
			end

			if not empty(add) then
				attrs[attr] = attrs[attr] + SheetUtil.getNumber(add, random)
			end

			if not empty(attr_index) and not empty(attr_multi) then
				attrs[attr] = attrs[attr] + originalData[attr_index] * SheetUtil.getNumber(attr_multi, random) / 100
			end
		end
	end
end

function CombatAttr.attrAddupModaoAndGlobal(type, attrList, attrs, originalData, seed)
	local random = Random.new(seed)

	for _, obj in ipairs(attrList) do
		local attr = obj.attr
		local mul = obj.mul
		local add = obj.add
		local attr_index = obj.attr_index
		local attr_multi = obj.attr_multi
		local attrCSV = CsvParser.getCsvData("attr", attr)

		if attrCSV.type == type and attrs[attr] then
			if not empty(mul) then
				attrs[attr] = attrs[attr] + originalData[attr] * SheetUtil.getNumber(mul, random) / 100
			end

			if not empty(add) then
				attrs[attr] = attrs[attr] + SheetUtil.getNumber(add, random)
			end

			if not empty(attr_index) and not empty(attr_multi) then
				attrs[attr] = attrs[attr] + originalData[attr_index] * SheetUtil.getNumber(attr_multi, random) / 100
			end
		end
	end
end

function CombatAttr.getSigilValue(attr, value)
	local attrCSV = CsvParser.getCsvData("attr", attr)
	local floatNum = attrCSV.sigil_decimal_len

	if not empty(floatNum) then
		local floatBase = math.pow(10, floatNum)

		return math.round(value * floatBase) / floatBase
	else
		return math.floor(value)
	end
end

function CombatAttr.getAttrDesc(attr, value)
	if not CombatAttr.descCache then
		CombatAttr.descCache = {}
		local attrCSV = CsvParser.getCsvRaw("attr")

		for k, v in pairs(attrCSV) do
			CombatAttr.descCache[v.id] = v.attr_desc
		end
	end

	local desc = CombatAttr.descCache[attr]

	if desc then
		return StringUtil.replace(desc, value)
	else
		return Localization.getSrcText("未知属性")
	end
end

function CombatAttr.getEnhanceDesc(attr, value)
	local attrCSV = CsvParser.getCsvData("attr", attr)
	local desc = attrCSV.name .. "+" .. value

	return desc
end

function CombatAttr.getAttrName(attr)
	if not CombatAttr.nameCache then
		CombatAttr.nameCache = {}
		local attrCSV = CsvParser.getCsvRaw("attr")

		for k, v in pairs(attrCSV) do
			CombatAttr.nameCache[v.id] = v.name
		end
	end

	local name = CombatAttr.nameCache[attr]

	if name then
		return name
	else
		return Localization.getSrcText("未知属性")
	end
end

function CombatAttr.defaultData(baseData, isNoneUnitDefault0)
	local attrCSV = CsvParser.getCsvRaw("attr")
	local data = {}

	for k, v in pairs(attrCSV) do
		if baseData and baseData[k] then
			data[k] = baseData[k]
		elseif v.type ~= 1 and isNoneUnitDefault0 then
			data[k] = 0
		else
			data[k] = v.default
		end
	end

	return data
end

function CombatAttr.finalize(data, attrLevel, noAttrAdd)
	if not noAttrAdd then
		attrLevel = attrLevel or CombatAttr.getAttrLevel()
	end

	local attrCSV = CsvParser.getCsvRaw("attr")

	for k, v in pairs(attrCSV) do
		if not noAttrAdd and not empty(data[v.attr_add]) then
			if not attrLevel[v.attr_add] then
				print("$$$ attrLevel没有", v.attr_add)
			end

			data[k] = data[k] + data[v.attr_add] * attrLevel[v.attr_add] * v.attr_add_ratio
		end

		if not empty(data[v.percent]) then
			data[k] = data[k] * (1 + data[v.percent] / 100)
		end
	end

	for k, v in pairs(attrCSV) do
		data[k] = math.floor(math.min(math.max(data[k], v.min), v.max))
	end
end

function CombatAttr.getModaoAttr(level)
	local data = CombatAttr.calculateAttr(TYPE.MODAO, "modao_base_num", level)

	return data
end

function CombatAttr.getItemAttr(level)
	local data = CombatAttr.calculateAttr(TYPE.ITEM, "item_base_num", level)

	return data
end

function CombatAttr.getBaseHeroAttr(heroInfo, noPet, attrLevel, _petAttrData, _manualAttr, noDust)
	local data = CombatAttr.getBodyAttr(heroInfo)
	local random = Random.new(heroInfo.seed)
	local qualityData = CsvParser.getCsvData("hero_quality", heroInfo.quality)

	for i, attrKey in ipairs(CombatAttr.attrs) do
		data[attrKey] = data[attrKey] * SheetUtil.getNumber(qualityData[attrKey .. "_ratio"], random)
		data[attrKey] = data[attrKey] + SheetUtil.getNumber(qualityData[attrKey .. "_add"], random)
	end

	local affixData = CsvParser.getCsvData("hero_affix", heroInfo.affix, nil, true)

	if affixData then
		for i, attrKey in ipairs(CombatAttr.attrs) do
			data[attrKey] = data[attrKey] * SheetUtil.getNumber(affixData[attrKey .. "_ratio"], random)
			data[attrKey] = data[attrKey] + SheetUtil.getNumber(affixData[attrKey .. "_add"], random)
		end

		local attrList = SheetUtil.getColumnList(affixData, {
			"attr_id",
			"attr_value"
		}, {
			"id",
			"value"
		})

		for i, v in ipairs(attrList) do
			if data[v.id] then
				data[v.id] = data[v.id] + v.value
			end
		end
	end

	local suitArr, dustLimitArr = CombatAttr.addEquipAttr(heroInfo, data, noDust)
	local manualAttr = _manualAttr or InfoManual.getAttr()

	for attr, value in pairs(manualAttr) do
		if data[attr] then
			data[attr] = data[attr] + value
		end
	end

	local petAttrData = nil

	if not noPet then
		petAttrData = _petAttrData or CombatAttr.getPetTohero()

		CombatAttr.addPetPercent(petAttrData, data)
	end

	local perkLevelCache, perkLevelPointCache, perkIdPointCache, perkPointIdCache = InfoHero.getPerkLevelCache()
	local perkLeft, perkMax = InfoHero.getPerkPoints(heroInfo)
	local perkMap = {}

	if not empty(heroInfo.perks) then
		local arr = string.split(heroInfo.perks, ",")

		for i, v in ipairs(arr) do
			local id = tonumber(v)

			if id then
				local points = perkIdPointCache[id]
				perkMap[points] = id
			end
		end
	end

	for i, v in ipairs(perkLevelCache) do
		if v.points <= perkMax then
			local id = perkMap[v.points]

			if not empty(id) then
				local csv = CsvParser.getCsvData("hero_peak_perk", id)
				local attrArr = SheetUtil.getColumnList(csv, {
					"attr_",
					"attr_value_"
				}, {
					"attr",
					"value"
				})

				for i1, v1 in ipairs(attrArr) do
					data[v1.attr] = (data[v1.attr] or 0) + v1.value
				end
			end
		else
			break
		end
	end

	local sigilArr = InfoSigil.getSigilList(heroInfo)

	for i, sigilInfo in ipairs(sigilArr) do
		local sigilAttrs = CombatAttr.getSigilAttr(sigilInfo)

		for attr, value in pairs(sigilAttrs) do
			if data[attr] then
				data[attr] = data[attr] + value
			end
		end
	end

	local artifactInfo = InfoArtifact.getArtifactOnHero(heroInfo.id)

	if artifactInfo then
		local artifactAttrs = CombatAttr.getArtifactAttr(artifactInfo, heroInfo)

		for attr, value in pairs(artifactAttrs) do
			if data[attr] then
				data[attr] = data[attr] + value
			end
		end
	end

	CombatAttr.finalize(data, nil, true)

	return data
end

function CombatAttr.getHeroAttr(heroInfo, noPet, attrLevel, _petAttrData, _manualAttr, noDust)
	local data = CombatAttr.getBodyAttr(heroInfo)
	local random = Random.new(heroInfo.seed)
	local qualityData = CsvParser.getCsvData("hero_quality", heroInfo.quality)

	for i, attrKey in ipairs(CombatAttr.attrs) do
		data[attrKey] = data[attrKey] * SheetUtil.getNumber(qualityData[attrKey .. "_ratio"], random)
		data[attrKey] = data[attrKey] + SheetUtil.getNumber(qualityData[attrKey .. "_add"], random)
	end

	local affixData = CsvParser.getCsvData("hero_affix", heroInfo.affix, nil, true)

	if affixData then
		for i, attrKey in ipairs(CombatAttr.attrs) do
			data[attrKey] = data[attrKey] * SheetUtil.getNumber(affixData[attrKey .. "_ratio"], random)
			data[attrKey] = data[attrKey] + SheetUtil.getNumber(affixData[attrKey .. "_add"], random)
		end

		local attrList = SheetUtil.getColumnList(affixData, {
			"attr_id",
			"attr_value"
		}, {
			"id",
			"value"
		})

		for i, v in ipairs(attrList) do
			if data[v.id] then
				data[v.id] = data[v.id] + v.value
			end
		end
	end

	local suitArr, dustLimitArr = CombatAttr.addEquipAttr(heroInfo, data, noDust)
	local cardArr = CombatAttr.addCardAttr(heroInfo, data)
	local manualAttr = _manualAttr or InfoManual.getAttr()

	for attr, value in pairs(manualAttr) do
		if data[attr] then
			data[attr] = data[attr] + value
		end
	end

	local petAttrData = nil

	if not noPet then
		petAttrData = _petAttrData or CombatAttr.getPetTohero()

		CombatAttr.addPetPercent(petAttrData, data)
	end

	CombatAttr.addPropConvert(data, attrLevel, suitArr, cardArr, dustLimitArr)

	local perkLevelCache, perkLevelPointCache, perkIdPointCache, perkPointIdCache = InfoHero.getPerkLevelCache()
	local perkLeft, perkMax = InfoHero.getPerkPoints(heroInfo)
	local perkMap = {}

	if not empty(heroInfo.perks) then
		local arr = string.split(heroInfo.perks, ",")

		for i, v in ipairs(arr) do
			local id = tonumber(v)

			if id then
				local points = perkIdPointCache[id]
				perkMap[points] = id
			end
		end
	end

	for i, v in ipairs(perkLevelCache) do
		if v.points <= perkMax then
			local id = perkMap[v.points]

			if not empty(id) then
				local csv = CsvParser.getCsvData("hero_peak_perk", id)
				local attrArr = SheetUtil.getColumnList(csv, {
					"attr_",
					"attr_value_"
				}, {
					"attr",
					"value"
				})

				for i1, v1 in ipairs(attrArr) do
					data[v1.attr] = (data[v1.attr] or 0) + v1.value
				end
			end
		else
			break
		end
	end

	local sigilArr = InfoSigil.getSigilList(heroInfo)

	for i, sigilInfo in ipairs(sigilArr) do
		local sigilAttrs = CombatAttr.getSigilAttr(sigilInfo)

		for attr, value in pairs(sigilAttrs) do
			if data[attr] then
				data[attr] = data[attr] + value
			end
		end
	end

	local artifactInfo = InfoArtifact.getArtifactOnHero(heroInfo.id)
	local artifactStarCSV = nil

	if artifactInfo then
		local artifactAttrs, _skillStarCSV = CombatAttr.getArtifactAttr(artifactInfo, heroInfo)

		for attr, value in pairs(artifactAttrs) do
			if data[attr] then
				data[attr] = data[attr] + value
			end
		end

		artifactStarCSV = _skillStarCSV
	end

	for attr, v in pairs(data) do
		if not CombatAttr.isPercentAttr(attr) then
			data[attr] = math.floor(v)
		end
	end

	local dustSkillMap = {}
	local dustBuffArr = {}
	local skillChangeMap = nil
	local dustProps = {
		"skill_cd_reduce",
		"skill_buff_exist_1",
		"skill_buff_exist_2",
		"skill_ignore_def",
		"skill_ignore_res"
	}

	for i, csv in ipairs(dustLimitArr) do
		if not empty(csv.skill_filter) then
			for j, prop in ipairs(dustProps) do
				if not empty(csv[prop]) then
					if not dustSkillMap[csv.skill_filter] then
						dustSkillMap[csv.skill_filter] = {}
					end

					if not dustSkillMap[csv.skill_filter].props then
						dustSkillMap[csv.skill_filter].props = {}
					end

					dustSkillMap[csv.skill_filter].props[prop] = (dustSkillMap[csv.skill_filter].props[prop] or 0) + csv[prop]
				end
			end

			local attrArr = SheetUtil.getColumnListFull(csv, {
				"skill_attr_",
				"skill_attr_value_"
			}, {
				"attr",
				"value"
			})

			if #attrArr > 0 then
				if not dustSkillMap[csv.skill_filter] then
					dustSkillMap[csv.skill_filter] = {}
				end

				if not dustSkillMap[csv.skill_filter].attrs then
					dustSkillMap[csv.skill_filter].attrs = {}
				end

				for j, v in ipairs(attrArr) do
					dustSkillMap[csv.skill_filter].attrs[v.attr] = (dustSkillMap[csv.skill_filter].attrs[v.attr] or 0) + v.value
				end
			end
		end

		local buffArr = SheetUtil.getColumnList(csv, {
			"buff_",
			"buff_type_",
			"buff_value_"
		}, {
			"id",
			"type",
			"value"
		})

		if #buffArr > 0 then
			for j, v in ipairs(buffArr) do
				table.insert(dustBuffArr, v)
			end
		end
	end

	if artifactStarCSV then
		local csv = artifactStarCSV

		if not empty(csv.skill_filter) then
			for j, prop in ipairs(dustProps) do
				if not empty(csv[prop]) then
					if not dustSkillMap[csv.skill_filter] then
						dustSkillMap[csv.skill_filter] = {}
					end

					if not dustSkillMap[csv.skill_filter].props then
						dustSkillMap[csv.skill_filter].props = {}
					end

					dustSkillMap[csv.skill_filter].props[prop] = (dustSkillMap[csv.skill_filter].props[prop] or 0) + csv[prop]
				end
			end

			local attrArr = SheetUtil.getColumnListFull(csv, {
				"skill_attr_",
				"skill_attr_value_"
			}, {
				"attr",
				"value"
			})

			if #attrArr > 0 then
				if not dustSkillMap[csv.skill_filter] then
					dustSkillMap[csv.skill_filter] = {}
				end

				if not dustSkillMap[csv.skill_filter].attrs then
					dustSkillMap[csv.skill_filter].attrs = {}
				end

				for j, v in ipairs(attrArr) do
					dustSkillMap[csv.skill_filter].attrs[v.attr] = (dustSkillMap[csv.skill_filter].attrs[v.attr] or 0) + v.value
				end
			end

			local attrLevelArr = SheetUtil.getColumnListFull(csv, {
				"skill_attr_add_level_",
				"skill_attr_value_add_level_"
			}, {
				"attr",
				"value"
			})

			if #attrLevelArr > 0 then
				if not dustSkillMap[csv.skill_filter] then
					dustSkillMap[csv.skill_filter] = {}
				end

				if not dustSkillMap[csv.skill_filter].attrs then
					dustSkillMap[csv.skill_filter].attrs = {}
				end

				for j, v in ipairs(attrLevelArr) do
					dustSkillMap[csv.skill_filter].attrs[v.attr] = (dustSkillMap[csv.skill_filter].attrs[v.attr] or 0) + v.value * artifactInfo.level
				end
			end

			if not empty(csv.skill_change) then
				skillChangeMap = skillChangeMap or {}
				skillChangeMap[csv.skill_filter] = csv.skill_change
			end
		end
	end

	return data, petAttrData, dustSkillMap, dustBuffArr, skillChangeMap
end

function CombatAttr.addPropConvert(data, attrLevel, suitArr, cardArr, dustLimitArr)
	if not noAttrAdd then
		attrLevel = attrLevel or CombatAttr.getAttrLevel()
	end

	local tempData = {}

	for k, v in pairs(data) do
		tempData[k] = v
	end

	local attrCSV = CsvParser.getCsvRaw("attr")

	for k, v in pairs(attrCSV) do
		if not empty(tempData[v.attr_add]) then
			if not attrLevel[v.attr_add] then
				print("$$$ attrLevel没有", v.attr_add)
			end

			tempData[k] = tempData[k] + tempData[v.attr_add] * attrLevel[v.attr_add] * v.attr_add_ratio
		end

		if not empty(tempData[v.percent]) then
			tempData[k] = tempData[k] * (1 + tempData[v.percent] / 100)
		end
	end

	local convertPropMap = {}

	for i, csv in ipairs(suitArr) do
		local attrArr = SheetUtil.getColumnListFull(csv, {
			"addition_attr_",
			"attr_index_",
			"attr_multi_"
		}, {
			"attr",
			"attr_index",
			"attr_multi"
		})

		for j, v in ipairs(attrArr) do
			if not empty(v.attr) then
				convertPropMap[v.attr] = (convertPropMap[v.attr] or 0) + tempData[v.attr_index] * (v.attr_multi or 0)
			end
		end
	end

	for i, cardInfo in ipairs(cardArr) do
		local cardData = CsvParser.getCsvData("card", cardInfo.base_id)
		local attrArr = SheetUtil.getColumnListFull(cardData, {
			"addition_attr_",
			"attr_index_",
			"attr_multi_"
		}, {
			"attr",
			"attr_index",
			"attr_multi"
		})

		for i, v in ipairs(attrArr) do
			local attr = v.attr

			if not empty(attr) then
				local multiArr = string.split(v.attr_multi, ",")
				local multi = tonumber(multiArr[math.min(#multiArr, cardInfo.star)])
				convertPropMap[attr] = (convertPropMap[attr] or 0) + tempData[v.attr_index] * (multi or 0)
			end
		end
	end

	if dustLimitArr then
		for i, csv in ipairs(dustLimitArr) do
			local attrArr = SheetUtil.getColumnListFull(csv, {
				"addition_attr_",
				"attr_index_",
				"attr_multi_"
			}, {
				"attr",
				"attr_index",
				"attr_multi"
			})

			for j, v in ipairs(attrArr) do
				if not empty(v.attr) then
					convertPropMap[v.attr] = (convertPropMap[v.attr] or 0) + tempData[v.attr_index] * (v.attr_multi or 0)
				end
			end
		end
	end

	for attr, value in pairs(convertPropMap) do
		data[attr] = data[attr] + value
	end
end

function CombatAttr.getBodyAttr(heroInfo)
	local baseData = CsvParser.getCsvData("hero", heroInfo.base_id)
	local data = CombatAttr.defaultData(baseData, true)
	local baseNum = CsvParser.getCsvData("hero_base_num", heroInfo.level)

	for i, attr in ipairs(CombatAttr.attrs) do
		local attrSeed = heroInfo[attr .. "_seed"] or 0
		local value = SheetUtil.getLinearNumber(baseData[attr .. "_ratio"], attrSeed / 65536)
		data[attr] = value / 100 * baseNum[attr]
	end

	return data
end

local heroSuitSkillCache = {}

function CombatAttr.suitStart(heroID, unit)
	local suitMap = {}
	local suitExMap = {}

	for i = 1, GameConfig.max_equip do
		local equipInfo = InfoEquip.getEquipOnHero(heroID, i)

		if equipInfo then
			local equipData = CsvParser.getCsvData("equip", equipInfo.base_id)

			if not empty(equipData.suit_id) then
				if not suitMap[equipData.suit_id] then
					suitMap[equipData.suit_id] = 0
				end

				suitMap[equipData.suit_id] = suitMap[equipData.suit_id] + 1
			end

			if not empty(equipData.suit_excellent_id) and equipInfo.suit_excellent and equipInfo.suit_excellent > 0 then
				if not suitExMap[equipData.suit_excellent_id] then
					suitExMap[equipData.suit_excellent_id] = 0
				end

				suitExMap[equipData.suit_excellent_id] = suitExMap[equipData.suit_excellent_id] + 1
			end
		end
	end

	heroSuitSkillCache[heroID] = {}
	local skillMap = heroSuitSkillCache[heroID]

	for suit_id, num in pairs(suitMap) do
		local suitCSV = CsvParser.getCsvData("suit", suit_id)
		local csv = CombatAttr.getSuitLevel(suit_id, math.min(suitCSV.suit_max, num))

		if csv then
			if not empty(csv.skill_filter) then
				if not skillMap[csv.skill_filter] then
					skillMap[csv.skill_filter] = {
						skill_dmg_add = 0,
						skill_critical_add = 0
					}
				end

				local obj = skillMap[csv.skill_filter]

				if not empty(csv.skill_dmg_add) then
					obj.skill_dmg_add = obj.skill_dmg_add + csv.skill_dmg_add
				end

				if not empty(csv.skill_critical_add) then
					obj.skill_critical_add = obj.skill_critical_add + csv.skill_critical_add
				end
			end

			local buffArr = SheetUtil.getColumnValueList(csv, "suit_buff_")

			for i, buffID in ipairs(buffArr) do
				print("$$$ CombatAttr.suitStart 111", buffID)
				unit:addBuff(buffID, nil, , unit.id, true)
			end
		end
	end

	for suit_id, num in pairs(suitExMap) do
		local suitCSV = CsvParser.getCsvData("suit", suit_id)
		local csv = CombatAttr.getSuitExcellentLevel(suit_id, math.min(suitCSV.suit_max, num))

		if csv then
			if not empty(csv.skill_filter) then
				if not skillMap[csv.skill_filter] then
					skillMap[csv.skill_filter] = {
						skill_dmg_add = 0,
						skill_critical_add = 0
					}
				end

				local obj = skillMap[csv.skill_filter]

				if not empty(csv.skill_dmg_add) then
					obj.skill_dmg_add = obj.skill_dmg_add + csv.skill_dmg_add
				end

				if not empty(csv.skill_critical_add) then
					obj.skill_critical_add = obj.skill_critical_add + csv.skill_critical_add
				end
			end

			local buffArr = SheetUtil.getColumnValueList(csv, "suit_buff_")

			for i, buffID in ipairs(buffArr) do
				print("$$$ CombatAttr.suitStart 222", buffID)
				unit:addBuff(buffID, nil, , unit.id, true)
			end
		end
	end
end

function CombatAttr.getSuitSkill(heroID, skillID)
	if heroSuitSkillCache[heroID] then
		local skillCSV = CsvParser.getCsvData("skill", skillID)

		if heroSuitSkillCache[heroID][skillCSV.base_id] then
			return heroSuitSkillCache[heroID][skillCSV.base_id]
		end
	end
end

local suitLevelMap = nil

function CombatAttr.getSuitLevel(suitID, num, isDisplay)
	if not suitLevelMap then
		suitLevelMap = {}
		local csvRaw = CsvParser.getCsvRaw("suit_level")

		for k, csv in pairs(csvRaw) do
			if not suitLevelMap[csv.suit_id] then
				suitLevelMap[csv.suit_id] = {}
			end

			suitLevelMap[csv.suit_id][csv.suit_num] = csv
		end
	end

	if isDisplay then
		if suitLevelMap[suitID] and suitLevelMap[suitID][num] then
			return suitLevelMap[suitID][num]
		end
	else
		local result = nil

		if suitLevelMap[suitID] then
			while not result and num > 0 do
				result = suitLevelMap[suitID][num]
				num = num - 1
			end
		end

		return result
	end
end

function CombatAttr.addEquipAttr(heroID, data, noDust)
	local suitMap = {}
	local suitExMap = {}
	local suitArr = {}
	local dustLimitArr = {}

	for i = 1, GameConfig.max_equip do
		local equipInfo = InfoEquip.getEquipOnHero(heroID, i)

		if equipInfo then
			local equipAttrData, limitArr = CombatAttr.getEquipAttr(equipInfo, nil, , , noDust)

			for attr, value in pairs(equipAttrData) do
				if data[attr] then
					data[attr] = data[attr] + value
				end
			end

			for j, v in ipairs(limitArr) do
				table.insert(dustLimitArr, v)
			end

			local equipData = CsvParser.getCsvData("equip", equipInfo.base_id)

			if not empty(equipData.suit_id) then
				if not suitMap[equipData.suit_id] then
					suitMap[equipData.suit_id] = 0
				end

				suitMap[equipData.suit_id] = suitMap[equipData.suit_id] + 1
			end

			if not empty(equipData.suit_excellent_id) and equipInfo.suit_excellent and equipInfo.suit_excellent > 0 then
				if not suitExMap[equipData.suit_excellent_id] then
					suitExMap[equipData.suit_excellent_id] = 0
				end

				suitExMap[equipData.suit_excellent_id] = suitExMap[equipData.suit_excellent_id] + 1
			end
		end
	end

	for suit_id, num in pairs(suitMap) do
		local suitCSV = CsvParser.getCsvData("suit", suit_id)
		local csv = CombatAttr.getSuitLevel(suit_id, math.min(suitCSV.suit_max, num))

		if csv then
			local attrList = SheetUtil.getColumnListFull(csv, {
				"attr_",
				"value_"
			}, {
				"attr",
				"value"
			})

			for j, v in ipairs(attrList) do
				if data[v.attr] then
					data[v.attr] = data[v.attr] + v.value
				end
			end

			table.insert(suitArr, csv)
		end
	end

	for suit_id, num in pairs(suitExMap) do
		local suitCSV = CsvParser.getCsvData("suit", suit_id)
		local csv = CombatAttr.getSuitExcellentLevel(suit_id, math.min(suitCSV.suit_max, num))

		if csv then
			local attrList = SheetUtil.getColumnListFull(csv, {
				"attr_",
				"value_"
			}, {
				"attr",
				"value"
			})

			for j, v in ipairs(attrList) do
				if data[v.attr] then
					data[v.attr] = data[v.attr] + v.value
				end
			end

			table.insert(suitArr, csv)
		end
	end

	local minEnhanceLevel = nil

	for i = 1, 4 do
		local equipInfo = InfoEquip.getEquipOnHero(heroID, i)

		if equipInfo then
			if not minEnhanceLevel then
				minEnhanceLevel = equipInfo.enhance_level
			else
				minEnhanceLevel = math.min(minEnhanceLevel, equipInfo.enhance_level)
			end
		else
			minEnhanceLevel = 0

			break
		end
	end

	minEnhanceLevel = minEnhanceLevel or 0
	local enhanceCSV = CsvParser.getCsvData("enhance_base_num", minEnhanceLevel)
	local attrList = SheetUtil.getColumnList(enhanceCSV, {
		"enhance_attr_",
		"enhance_value_"
	}, {
		"attr",
		"value"
	})

	for j, v in ipairs(attrList) do
		if data[v.attr] then
			data[v.attr] = data[v.attr] + v.value
		end
	end

	return suitArr, dustLimitArr
end

local enhanceAttrList = nil

function CombatAttr.getEnhanceAttrLevel(level)
	local preCode, preLevel = nil

	if not enhanceAttrList then
		enhanceAttrList = {}
		local csvList = CsvParser.getCsvList("enhance_base_num")

		for i, csv in ipairs(csvList) do
			local attrList = SheetUtil.getColumnList(csv, {
				"enhance_attr_",
				"enhance_value_"
			}, {
				"attr",
				"value"
			})
			local code = ""

			for j, v in ipairs(attrList) do
				code = code .. v.attr .. ":" .. v.value .. ","
			end

			if code ~= preCode then
				preCode = code

				if #enhanceAttrList > 0 then
					enhanceAttrList[#enhanceAttrList].endLevel = preLevel
				end

				table.insert(enhanceAttrList, {
					startLevel = csv.id,
					endLevel = csv.id
				})
			end

			preLevel = csv.id
		end
	end

	local currentID, nextID = nil

	for i, v in ipairs(enhanceAttrList) do
		if v.startLevel <= level and level <= v.endLevel then
			currentID = v.startLevel

			if enhanceAttrList[i + 1] then
				nextID = enhanceAttrList[i + 1].startLevel
			end

			break
		end
	end

	return currentID, nextID
end

function CombatAttr.getSuitNum(heroID, suitID)
	local num = 0

	for i = 1, GameConfig.max_equip do
		local equipInfo = InfoEquip.getEquipOnHero(heroID, i)

		if equipInfo then
			local equipData = CsvParser.getCsvData("equip", equipInfo.base_id)

			if equipData.suit_id == suitID then
				num = num + 1
			end
		end
	end

	return num
end

function CombatAttr.getSuitExcellentNum(heroID, suitID)
	local num = 0

	for i = 1, GameConfig.max_equip do
		local equipInfo = InfoEquip.getEquipOnHero(heroID, i)

		if equipInfo and equipInfo.suit_excellent and equipInfo.suit_excellent > 0 then
			local equipData = CsvParser.getCsvData("equip", equipInfo.base_id)

			if equipData.suit_excellent_id == suitID then
				num = num + 1
			end
		end
	end

	return num
end

local suitExcellentLevelMap = nil

function CombatAttr.getSuitExcellentLevel(suitID, num, isDisplay)
	if not suitExcellentLevelMap then
		suitExcellentLevelMap = {}
		local csvRaw = CsvParser.getCsvRaw("suit_excellent")

		for k, csv in pairs(csvRaw) do
			if not suitExcellentLevelMap[csv.suit_id] then
				suitExcellentLevelMap[csv.suit_id] = {}
			end

			suitExcellentLevelMap[csv.suit_id][csv.suit_num] = csv
		end
	end

	if isDisplay then
		if suitExcellentLevelMap[suitID] and suitExcellentLevelMap[suitID][num] then
			return suitExcellentLevelMap[suitID][num]
		end
	else
		local result = nil

		if suitExcellentLevelMap[suitID] then
			while not result and num > 0 do
				result = suitExcellentLevelMap[suitID][num]
				num = num - 1
			end
		end

		return result
	end
end

function CombatAttr.gePetSuitNum(petInfo, suitID)
	local num = 0

	for i = 1, GameConfig.max_pet_equip do
		local equipID = InfoPet.getEquipOnPet(petInfo, i)

		if equipID then
			local equipData = CsvParser.getCsvData("pet_equip", equipID)

			if equipData.suit_id == suitID then
				num = num + 1
			end
		end
	end

	return num
end

function CombatAttr.addCardAttr(heroID, data)
	local cardArr = {}

	for i = 1, GameConfig.max_card do
		local cardInfo = InfoCard.getCardOnHero(heroID, i)

		if cardInfo then
			local cardAttrData = CombatAttr.getCardAttr(cardInfo)

			for attr, value in pairs(cardAttrData) do
				if data[attr] then
					data[attr] = data[attr] + value
				end
			end

			local cardExtraData = CombatAttr.getCardExtra(cardInfo)

			for attr, value in pairs(cardExtraData) do
				if data[attr] then
					data[attr] = data[attr] + value
				end
			end

			table.insert(cardArr, cardInfo)
		end
	end

	return cardArr
end

function CombatAttr.getPetTohero(customPets)
	local buildingPercent = 0

	if InfoDungeon.isFixedTeam() then
		buildingPercent = CsvParser.getCsvData("config", "sp_stage_pet_percent").value
	else
		local buildingCSV = InfoBuilding.getBuildingData(InfoBuilding.TAG.PET)
		buildingPercent = buildingCSV.value4
	end

	local pets = customPets or InfoPet.getTeam()
	local data = {}

	for i, petInfo in ipairs(pets) do
		local qualityData = CsvParser.getCsvData("pet_quality", petInfo.quality)
		local attr_tohero = qualityData.attr_tohero
		attr_tohero = attr_tohero + buildingPercent
		local petAttr = CombatAttr.getPetAttr(petInfo)

		for i, attrKey in ipairs(CombatAttr.attrs) do
			if not data[attrKey] then
				data[attrKey] = 0
			end

			data[attrKey] = data[attrKey] + petAttr[attrKey] * attr_tohero / 100
		end
	end

	for attrKey, value in pairs(data) do
		if not CombatAttr.isPercentAttr(attrKey) then
			data[attrKey] = math.floor(value)
		end
	end

	return data
end

function CombatAttr.addPetPercent(petAttrData, data)
	for attr, value in pairs(petAttrData) do
		if data[attr] then
			data[attr] = data[attr] + value
		end
	end
end

function CombatAttr.getAttrIndex(attr)
	if not CombatAttr.attrIndexMap then
		CombatAttr.attrIndexMap = {}
		local csvList = CsvParser.getCsvList("attr", "__line")

		for i, v in ipairs(csvList) do
			CombatAttr.attrIndexMap[v.id] = i
		end
	end

	return CombatAttr.attrIndexMap[attr]
end

function CombatAttr.addPetEquipAttr(petInfo, data)
	local suitMap = {}

	for i = 1, GameConfig.max_pet_equip do
		local equipID = InfoPet.getEquipOnPet(petInfo, i)

		if not empty(equipID) then
			local equipAttrData = CombatAttr.getPetEquipAttr(equipID)

			for attr, value in pairs(equipAttrData) do
				if data[attr] then
					data[attr] = data[attr] + value
				end
			end

			local equipData = CsvParser.getCsvData("pet_equip", equipID)

			if not empty(equipData.suit_id) then
				if not suitMap[equipData.suit_id] then
					suitMap[equipData.suit_id] = 0
				end

				suitMap[equipData.suit_id] = suitMap[equipData.suit_id] + 1
			end
		end
	end

	for suit_id, num in pairs(suitMap) do
		local suitCSV = CsvParser.getCsvData("suit", suit_id)
		local csv = CombatAttr.getSuitLevel(suit_id, math.min(suitCSV.suit_max, num))

		if csv then
			local attrList = SheetUtil.getColumnList(csv, {
				"attr_",
				"value_"
			}, {
				"attr",
				"value"
			})

			for j, v in ipairs(attrList) do
				if data[v.attr] then
					data[v.attr] = data[v.attr] + v.value
				end
			end
		end
	end
end

function CombatAttr.getPetEquipAttr(equipID, isDisplay)
	local data = {}
	local dataForDisplay, mainAttr = nil

	if isDisplay then
		dataForDisplay = {}
		mainAttr = {}
	end

	local equipData = CsvParser.getCsvData("pet_equip", equipID)
	local index = 1

	while not empty(equipData["attr_" .. index]) do
		local attrStr = equipData["attr_" .. index]
		local value = equipData["value_" .. index]

		if value then
			data[attrStr] = (data[attrStr] or 0) + value

			if isDisplay then
				dataForDisplay[attrStr] = (dataForDisplay[attrStr] or 0) + value

				table.insert(mainAttr, {
					name = attrStr,
					value = value
				})
			end
		end

		index = index + 1
	end

	if isDisplay then
		local attrsForDisplay = {}

		for k, v in pairs(dataForDisplay) do
			table.insert(attrsForDisplay, {
				attr = k,
				value = v
			})
		end

		table.sort(attrsForDisplay, function (a, b)
			return CombatAttr.getAttrIndex(a.attr) < CombatAttr.getAttrIndex(b.attr)
		end)

		return data, attrsForDisplay, mainAttr
	else
		return data
	end
end

function CombatAttr.getArtifactAttr(artifactInfo, heroInfo)
	local artifactCSV = CsvParser.getCsvData("artifact", artifactInfo.base_id)
	local data = {}

	for i = 1, 3 do
		local attr = artifactInfo["attr_" .. i]

		if empty(attr) then
			attr = artifactCSV["attr_" .. i]
		end

		local attrCSV = CsvParser.getCsvData("artifact_attr", attr)
		local value = attrCSV.base + artifactInfo.level * attrCSV.add
		data[attr] = (data[attr] or 0) + value
	end

	local skillStarCSV = nil

	if heroInfo then
		local starCSV = InfoArtifact.getStarCSV(artifactInfo)
		local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)
		local skillCSV = CsvParser.getCsvData("skill", heroCSV.skill_id)

		print("$$$ getArtifactAttr", starCSV.skill_filter ~= skillCSV.base_id, starCSV.skill_filter, skillCSV.base_id, heroInfo.base_id)

		if starCSV.skill_filter ~= skillCSV.base_id then
			local attr = "dmgadd"
			local value = starCSV.unactivated_dmgadd
			data[attr] = (data[attr] or 0) + value
		else
			local attrList = SheetUtil.getColumnList(starCSV, {
				"attr_",
				"attr_value_"
			}, {
				"attr",
				"value"
			})

			for i, v in ipairs(attrList) do
				data[v.attr] = (data[v.attr] or 0) + v.value
			end

			local levelAttrList = SheetUtil.getColumnList(starCSV, {
				"extra_attr_",
				"extra_attr_add_level_"
			}, {
				"attr",
				"value"
			})

			for i, v in ipairs(levelAttrList) do
				local value = v.value * artifactInfo.level
				data[v.attr] = (data[v.attr] or 0) + value
			end

			skillStarCSV = starCSV
		end
	end

	return data, skillStarCSV
end

function CombatAttr.getSigilAttr(sigilInfo, isDisplay, customHeroInfo)
	local data = {}
	local baseData, affixData, echoData = nil

	if isDisplay then
		baseData = {}
		affixData = {}
		echoData = {}
	end

	local sigilCSV = CsvParser.getCsvData("sigil", sigilInfo.base_id)
	local baseCSV = CsvParser.getCsvData("sigil_base_num", sigilInfo.level)
	local qualityCSV = CsvParser.getCsvData("sigil_quality", sigilInfo.quality)
	local attrList = SheetUtil.getColumnList(sigilCSV, {
		"attr_",
		"value_"
	}, {
		"attr",
		"value"
	})
	local random = Random.new(sigilInfo.ran)

	for i, v in ipairs(attrList) do
		local value = SheetUtil.getNumber(v.value, random)
		value = value * baseCSV.attr_ratio * qualityCSV.attr_ratio
		data[v.attr] = (data[v.attr] or 0) + value

		if isDisplay then
			table.insert(baseData, {
				attr = v.attr,
				value = value
			})
		end
	end

	for i = 1, GameConfig.sigil_affix_max do
		local prefix = sigilInfo["prefix_" .. i]
		local preran = sigilInfo["preran_" .. i]

		if prefix ~= 0 then
			local csv = CsvParser.getCsvData("sigil_affix", prefix)
			local value = SheetUtil.getLinearNumber(csv.attr_value, preran / 65536)
			value = value * baseCSV["affix_ratio_" .. i] * qualityCSV["affix_ratio_" .. i]
			data[csv.attr] = (data[csv.attr] or 0) + value

			if isDisplay then
				table.insert(affixData, {
					attr = csv.attr,
					value = value
				})
			end
		end
	end

	local isColorActived = InfoSigil.checkEcho(sigilInfo, customHeroInfo)

	if sigilInfo.echo ~= 0 then
		local csv = CsvParser.getCsvData("sigil_echo", sigilInfo.echo)
		local value = SheetUtil.getLinearNumber(csv.attr_value, sigilInfo.echo_ran / 65536)

		if isColorActived then
			data[csv.attr] = (data[csv.attr] or 0) + value
		end

		if isDisplay then
			table.insert(echoData, {
				attr = csv.attr,
				value = value
			})
		end
	end

	return data, isColorActived, baseData, affixData, echoData
end

function CombatAttr.getEquipAttr(equipInfo, isDisplay, noEnhance, params, noDust)
	local data = {}
	local dataForDisplay, dataForDisplayBase, dataForDisplayPriority, mainAttr, mainAttrMap, enhanceAttr, dustAttr, dustMainUpMap = nil
	local dustMainPerm = 0
	local dustLimitArr = {}
	local dustGemMap = {}
	local dustSp = nil

	if isDisplay then
		dataForDisplay = {}
		dataForDisplayBase = {}
		dataForDisplayPriority = {}
		mainAttr = {}
		mainAttrMap = {}
		enhanceAttr = {}
		dustAttr = {}
		dustMainUpMap = {}
	end

	local equipData = CsvParser.getCsvData("equip", equipInfo.base_id)
	local agenData = CsvParser.getCsvData("affix_gen", equipInfo.quality)
	local equipBaseNum = CsvParser.getCsvData("equip_base_num", equipInfo.level)
	local baseValue = {}

	if not noDust and equipInfo.dust_id and equipInfo.dust_id > 0 then
		for i = 1, GameConfig.equip_dust_max do
			if not empty(equipInfo["dust_id_" .. i]) then
				local id = equipInfo["dust_id_" .. i]
				local level = equipInfo["dust_level_" .. i]
				local attrCSV = CsvParser.getCsvData("dust_attr", id)

				if InfoDungeon.checkInDust(equipInfo.dust_id) then
					dustMainPerm = dustMainPerm + attrCSV.attr_base_value + attrCSV.attr_growth_value * math.max(0, level - 1)
					local limitCSV = InfoEquip.getDustLimitAttr(equipInfo, i)

					if limitCSV then
						local attrList = SheetUtil.getColumnList(limitCSV, {
							"attr_",
							"value_"
						}, {
							"attr",
							"value"
						})

						for j, v in ipairs(attrList) do
							data[v.attr] = (data[v.attr] or 0) + v.value
						end

						table.insert(dustLimitArr, limitCSV)

						for j = 1, 2 do
							if not empty(limitCSV["gem" .. j .. "_add"]) then
								dustGemMap[j] = (dustGemMap[j] or 1) + limitCSV["gem" .. j .. "_add"]
							end
						end
					end
				end

				if isDisplay then
					local limitCSV = InfoEquip.getDustLimitAttr(equipInfo, i)

					table.insert(dustAttr, {
						id = id,
						index = i,
						level = level,
						limit = limitCSV
					})
				end
			end
		end
	end

	local random = Random.new(equipInfo.ran)
	local index = 1

	while not empty(equipData["attr_" .. index]) do
		local attrStr = equipData["attr_" .. index]
		local valueStr = equipData["value_" .. index]
		local value = nil

		if not empty(equipInfo.excellent) then
			value = SheetUtil.getLinearNumber(valueStr, equipInfo.ran / 65536)
		else
			value = SheetUtil.getNumber(valueStr, random)
		end

		if params then
			if params.isMin then
				local min, max = SheetUtil.getMinMax(valueStr, random)
				value = min
			elseif params.isMax then
				local min, max = SheetUtil.getMinMax(valueStr, random)
				value = max
			end
		end

		if value then
			value = value * agenData.attr_ratio * equipBaseNum.attr_ratio
			value = math.floor(value / 100)

			table.insert(baseValue, {
				attr = attrStr,
				value = value
			})

			data[attrStr] = (data[attrStr] or 0) + value

			if isDisplay then
				dataForDisplay[attrStr] = (dataForDisplay[attrStr] or 0) + value
				mainAttrMap[attrStr] = {
					name = attrStr,
					value = value
				}

				table.insert(mainAttr, mainAttrMap[attrStr])
			end
		end

		index = index + 1
	end

	if equipInfo.dust_id and equipInfo.dust_id > 0 then
		if not empty(equipInfo.dust_sp_attr) then
			local rr = Random.new(equipInfo.dust_sp_ran)
			local csv = CsvParser.getCsvData("dust_sp_attr", equipInfo.dust_sp_attr)
			local attrStr = csv.attr
			local value = SheetUtil.getNumber(csv.value, rr)

			if params then
				if params.isMin then
					local min, max = SheetUtil.getMinMax(csv.value, rr)
					value = min
				elseif params.isMax then
					local min, max = SheetUtil.getMinMax(csv.value, rr)
					value = max
				end
			end

			if value then
				data[attrStr] = (data[attrStr] or 0) + value
				dustSp = {
					attr = attrStr,
					value = value
				}

				if isDisplay then
					-- Nothing
				end
			end
		end
	else
		local index = 1

		while not empty(equipData["special_attr_" .. index]) do
			local attrStr = equipData["special_attr_" .. index]
			local valueStr = equipData["special_value_" .. index]
			local value = nil

			if not empty(equipInfo.excellent) then
				value = SheetUtil.getLinearNumber(valueStr, equipInfo.ran / 65536)
			else
				value = SheetUtil.getNumber(valueStr, random)
			end

			if params then
				if params.isMin then
					local min, max = SheetUtil.getMinMax(valueStr, random)
					value = min
				elseif params.isMax then
					local min, max = SheetUtil.getMinMax(valueStr, random)
					value = max
				end
			end

			if value then
				value = math.floor(value / 100)
				data[attrStr] = (data[attrStr] or 0) + value

				if isDisplay then
					dataForDisplay[attrStr] = (dataForDisplay[attrStr] or 0) + value
					dataForDisplayPriority[attrStr] = 1
				end
			end

			index = index + 1
		end
	end

	if isDisplay then
		for k, v in pairs(dataForDisplay) do
			dataForDisplayBase[k] = v
		end
	end

	local addData = {}
	local mulData = {}

	for i = 1, GameConfig.equip_affix_max do
		local prefix = equipInfo["prefix_" .. i]
		local preran = equipInfo["preran_" .. i]

		if prefix ~= 0 then
			local random = Random.new(preran)
			local affixData = CsvParser.getCsvData("affix", prefix)

			if affixData then
				local affixGen = CsvParser.getCsvData("affix_gen", affixData.quality)
				local index = 1

				while not empty(affixData["attr_add_" .. index]) do
					local attrStr = affixData["attr_add_" .. index]
					local equipAffixLevel = CsvParser.getCsvData("affix_add_level", equipInfo.level)[attrStr]
					local value = nil

					if not empty(equipInfo.excellent) then
						value = SheetUtil.getLinearNumber(affixGen.affix_attr_range, preran / 65536)
					else
						value = SheetUtil.getNumber(affixGen.affix_attr_range, random)
					end

					local valueAdd = equipAffixLevel * value * affixGen.affix_quality_ratio / 100
					addData[attrStr] = (addData[attrStr] or 0) + valueAdd
					index = index + 1
				end

				local index = 1

				while not empty(affixData["attr_mul_" .. index]) do
					local attrStr = affixData["attr_mul_" .. index]
					local equipAffixLevel = CsvParser.getCsvData("affix_mul_level", equipInfo.level)[attrStr]
					local value = nil

					if not empty(equipInfo.excellent) then
						value = SheetUtil.getLinearNumber(affixGen.affix_attr_range, preran / 65536)
					else
						value = SheetUtil.getNumber(affixGen.affix_attr_range, random)
					end

					local valueMul = equipAffixLevel * value * affixGen.affix_quality_ratio / 100
					mulData[attrStr] = (mulData[attrStr] or 0) + valueMul
					index = index + 1
				end
			end
		end
	end

	for i = 1, GameConfig.equip_affix_max do
		local suffix = equipInfo["suffix_" .. i]
		local sufran = equipInfo["sufran_" .. i]

		if suffix ~= 0 then
			local random = Random.new(sufran)
			local affixData = CsvParser.getCsvData("affix", suffix)

			if affixData then
				local affixGen = CsvParser.getCsvData("affix_gen", affixData.quality)
				local index = 1

				while not empty(affixData["attr_add_" .. index]) do
					local attrStr = affixData["attr_add_" .. index]
					local equipAffixLevel = CsvParser.getCsvData("affix_add_level", equipInfo.level)[attrStr]
					local value = nil

					if not empty(equipInfo.excellent) then
						value = SheetUtil.getLinearNumber(affixGen.affix_attr_range, sufran / 65536)
					else
						value = SheetUtil.getNumber(affixGen.affix_attr_range, random)
					end

					local valueAdd = equipAffixLevel * value * affixGen.affix_quality_ratio / 100
					addData[attrStr] = (addData[attrStr] or 0) + valueAdd
					index = index + 1
				end

				local index = 1

				while not empty(affixData["attr_mul_" .. index]) do
					local attrStr = affixData["attr_mul_" .. index]
					local equipAffixLevel = CsvParser.getCsvData("affix_mul_level", equipInfo.level)[attrStr]
					local value = nil

					if not empty(equipInfo.excellent) then
						value = SheetUtil.getLinearNumber(affixGen.affix_attr_range, sufran / 65536)
					else
						value = SheetUtil.getNumber(affixGen.affix_attr_range, random)
					end

					local valueMul = equipAffixLevel * value * affixGen.affix_quality_ratio / 100
					mulData[attrStr] = (mulData[attrStr] or 0) + valueMul
					index = index + 1
				end
			end
		end
	end

	for attr, mulValue in pairs(mulData) do
		if data[attr] then
			data[attr] = math.ceil(data[attr] * (1 + mulValue / 100))
		end

		if isDisplay and dataForDisplay[attr] then
			dataForDisplay[attr] = math.ceil(dataForDisplay[attr] * (1 + mulValue / 100))
		end
	end

	for attr, addValue in pairs(addData) do
		data[attr] = math.ceil((data[attr] or 0) + addValue)

		if isDisplay and dataForDisplay[attr] then
			dataForDisplay[attr] = math.ceil((dataForDisplay[attr] or 0) + addValue)
		end
	end

	if not noEnhance then
		for i = 1, GameConfig.equip_gem_max do
			if not empty(equipInfo["gem" .. i]) then
				local itemData = CsvParser.getCsvData("item", equipInfo["gem" .. i])
				local gemData = CsvParser.getCsvData("gem", itemData.use_value1)
				local attrList = SheetUtil.getColumnList(gemData, {
					"attr_",
					"value_"
				}, {
					"attr",
					"value"
				})

				for j, v in ipairs(attrList) do
					data[v.attr] = (data[v.attr] or 0) + v.value * (dustGemMap[gemData.class] or 1)
				end
			end
		end
	end

	local enhanceLevel = equipInfo.enhance_level or 0

	if noEnhance then
		enhanceLevel = 0
	end

	if enhanceLevel > 0 then
		local enhanceCSV = CsvParser.getCsvData("enhance_base_num", enhanceLevel)

		for i, v in ipairs(baseValue) do
			local attrStr = v.attr
			local value = v.value
			value = math.floor(enhanceCSV.attr_ratio * value - value)
			data[attrStr] = (data[attrStr] or 0) + value

			if isDisplay then
				if not enhanceAttr[attrStr] then
					enhanceAttr[attrStr] = {
						value = 0,
						attr = attrStr,
						index = i
					}
				end

				enhanceAttr[attrStr].value = enhanceAttr[attrStr].value + value
				dataForDisplay[attrStr] = (dataForDisplay[attrStr] or 0) + value
				mainAttrMap[attrStr].value = mainAttrMap[attrStr].value + value
			end
		end
	end

	if dustMainPerm > 0 then
		for i, v in ipairs(baseValue) do
			local attrStr = v.attr
			local value = math.floor(v.value * dustMainPerm / 1000)
			data[attrStr] = (data[attrStr] or 0) + value

			if isDisplay then
				dustMainUpMap[attrStr] = (dustMainUpMap[attrStr] or 0) + value
				dataForDisplay[attrStr] = (dataForDisplay[attrStr] or 0) + value
				mainAttrMap[attrStr].value = mainAttrMap[attrStr].value + value
			end
		end
	end

	if isDisplay then
		local attrsForDisplay = {}

		for k, v in pairs(dataForDisplay) do
			local obj = {
				attr = k,
				value = v
			}

			if dataForDisplayBase[k] then
				obj.base = dataForDisplayBase[k]

				if enhanceAttr[k] then
					obj.enhanceUp = enhanceAttr[k].value
				end

				if dustMainUpMap[k] and dustMainUpMap[k] > 0 then
					obj.dustUp = dustMainUpMap[k]
				end

				obj.affixUp = v - obj.base - (obj.enhanceUp or 0) - (obj.dustUp or 0)
			end

			table.insert(attrsForDisplay, obj)
		end

		table.sort(attrsForDisplay, function (a, b)
			local priorityA = dataForDisplayPriority[a.attr] or 0
			local priorityB = dataForDisplayPriority[b.attr] or 0

			if priorityA == priorityB then
				return CombatAttr.getAttrIndex(a.attr) < CombatAttr.getAttrIndex(b.attr)
			else
				return priorityA < priorityB
			end
		end)

		return data, attrsForDisplay, mainAttr, enhanceAttr, dustAttr, dustLimitArr, dustGemMap, dustSp
	else
		return data, dustLimitArr, dustSp
	end
end

function CombatAttr.getCardAttr(cardInfo)
	local data = {}
	local cardData = CsvParser.getCsvData("card", cardInfo.base_id)
	local cardBase = InfoCard.getBase(cardInfo)
	local attrArr = SheetUtil.getColumnValueList(cardData, "attr_")

	for i, attr in ipairs(attrArr) do
		if not empty(attr) then
			local growth = cardData["growth_" .. i] * cardInfo["growth_" .. i] / 1000
			local value = growth * cardBase.attr_ratio / 1000
			local perAttr = CsvParser.getCsvData("attr", attr).percent
			data[perAttr] = (data[perAttr] or 0) + value
			local base = cardData["base_attr_" .. i]

			if not empty(base) then
				local value = base * growth * cardBase.base_attr_ratio
				data[attr] = (data[attr] or 0) + value
			end
		end
	end

	return data
end

function CombatAttr.getCardExtra(cardInfo)
	local data = {}
	local cardData = CsvParser.getCsvData("card", cardInfo.base_id)
	local attrArr = SheetUtil.getColumnListFull(cardData, {
		"extra_attr_",
		"extra_value_"
	}, {
		"attr",
		"value"
	})

	for i, v in ipairs(attrArr) do
		local attr = v.attr

		if not empty(attr) then
			local valueArr = string.split(v.value, ",")
			local value = tonumber(valueArr[math.min(#valueArr, cardInfo.star)])
			data[attr] = (data[attr] or 0) + value
		end
	end

	return data
end

function CombatAttr.getMonsterAttr(monsterInfo)
	local monsterCSV = CsvParser.getCsvData("monster", monsterInfo.base_id)
	local data, baseNumData = nil

	if InfoDungeon.inDust() then
		local dustLevel = InfoDust.getLevel()
		data, baseNumData = CombatAttr.calculateAttr(TYPE.UNIT, InfoDungeon.getDustBaseNumFile(), dustLevel, monsterCSV)
	else
		data, baseNumData = CombatAttr.calculateAttr(TYPE.UNIT, "monster_base_num", monsterInfo.level, monsterCSV)
	end

	local terrainCSV = InfoDungeon.getTerrain()

	if terrainCSV then
		local attrList = SheetUtil.getColumnList(terrainCSV, {
			"monster_attr_",
			"monster_attr_value_"
		}, {
			"attr",
			"value"
		})

		for i, v in ipairs(attrList) do
			if data[v.attr] then
				data[v.attr] = data[v.attr] + v.value
			end
		end
	end

	local hpRatio = baseNumData["class" .. monsterCSV.class .. "_hp_ratio"]

	if hpRatio then
		data.hp = math.floor(data.hp * hpRatio)
	end

	return data
end

function CombatAttr.getPetAttr(petInfo)
	local data = CombatAttr.getPetBodyAttr(petInfo)
	local random = Random.new(petInfo.seed)
	local qualityData = CsvParser.getCsvData("pet_quality", petInfo.quality)

	for i, attrKey in ipairs(CombatAttr.attrs) do
		data[attrKey] = data[attrKey] * SheetUtil.getNumber(qualityData[attrKey .. "_ratio"], random)
		data[attrKey] = data[attrKey] + SheetUtil.getNumber(qualityData[attrKey .. "_add"], random)
	end

	CombatAttr.addPetEquipAttr(petInfo, data)

	for attr, v in pairs(data) do
		if not CombatAttr.isPercentAttr(attr) then
			data[attr] = math.floor(v)
		end
	end

	return data
end

function CombatAttr.getPetBodyAttr(petInfo)
	local baseData = CsvParser.getCsvData("pet", petInfo.base_id)
	local data = CombatAttr.defaultData(baseData, true)
	local baseNum = CsvParser.getCsvData("pet_base_num", petInfo.level)

	for i, attr in ipairs(CombatAttr.attrs) do
		local attrSeed = petInfo[attr .. "_seed"] or 0
		local value = SheetUtil.getLinearNumber(baseData[attr .. "_ratio"], attrSeed / 65536)
		data[attr] = value / 100 * baseNum[attr]
	end

	local attrList = SheetUtil.getColumnList(baseNum, {
		"attr_",
		"attr_value_"
	}, {
		"attr",
		"value"
	})

	for i, v in ipairs(attrList) do
		if data[v.attr] then
			data[v.attr] = data[v.attr] + v.value
		else
			data[v.attr] = v.value
		end
	end

	if InfoDungeon.inDust() or InfoDungeon.inDustPrepare() then
		local dustLevel = InfoDust.getLevel()
		local dustBaseNum = CsvParser.getCsvData(InfoDungeon.getDustBaseNumFile(), dustLevel, nil, true)

		if dustBaseNum then
			local attrList = SheetUtil.getColumnList(dustBaseNum, {
				"pet_attr_",
				"pet_attr_value_"
			}, {
				"attr",
				"value"
			})

			for i, v in ipairs(attrList) do
				if data[v.attr] then
					data[v.attr] = data[v.attr] + v.value
				else
					data[v.attr] = v.value
				end
			end
		end
	end

	return data
end

function CombatAttr.getSummonedAttr(summonedInfo, unit)
	local baseName = summonedInfo.base_type
	local numBaseName = "summoned_base_num"

	if summonedInfo.summonerType == "monster" then
		numBaseName = "monster_base_num"
	end

	local baseData = CsvParser.getCsvData(baseName, summonedInfo.base_id)
	local data = CombatAttr.calculateAttr(TYPE.UNIT, numBaseName, summonedInfo.level, baseData)
	local hoster = unit.superSummoner

	if not hoster then
		hoster = unit.summoner

		if hoster then
			while hoster.summoner do
				hoster = hoster.summoner
			end
		end
	end

	if hoster and hoster.attrs then
		for i, v in ipairs(summon_add) do
			if not empty(hoster.attrs["summon_" .. v]) then
				data[v] = data[v] + hoster.attrs["summon_" .. v]
			end
		end

		local attrAdd = baseData.summon_attr_add

		if not empty(attrAdd) then
			local arr1 = string.split(attrAdd, ";")

			for i, str1 in ipairs(arr1) do
				str1 = string.trim(str1)

				if not empty(str1) then
					local arr2 = string.split(str1, ",")
					data[arr2[1]] = data[arr2[1]] + math.floor(hoster.attrs[arr2[2]] * tonumber(arr2[3]) / 1000 * (1 + hoster.attrs.summon_attr / 100))
				end
			end
		end
	end

	return data
end

local baseFileAttrsCache = {}

function CombatAttr.getBaseFileAttrs(baseFilename)
	if not baseFileAttrsCache[baseFilename] then
		local mainAttrMap = {}

		for i, attr in ipairs(attrs) do
			mainAttrMap[attr] = true
		end

		local attrMap = {}
		local csvRaw = CsvParser.getCsvRaw("attr")

		for attr, csv in pairs(csvRaw) do
			if not mainAttrMap[attr] then
				attrMap[attr] = true
			end
		end

		local baseNumData = CsvParser.getCsvData(baseFilename, 1)
		local arr = {}

		for k, v in pairs(baseNumData) do
			if attrMap[k] then
				table.insert(arr, k)
			end
		end

		baseFileAttrsCache[baseFilename] = arr
	end

	return baseFileAttrsCache[baseFilename]
end

function CombatAttr.calculateAttr(type, baseFilename, level, baseData, seed)
	local max_level = CsvParser.getMaxID(baseFilename)
	local data = CombatAttr.defaultData(baseData)
	local baseNumData = nil

	if baseData then
		local random = nil

		if seed then
			random = Random.new(seed)
		end

		if not empty(baseData.ex_level) then
			level = level + baseData.ex_level
		end

		level = math.max(1, math.min(level, max_level))
		baseNumData = CsvParser.getCsvData(baseFilename, level)

		for i, attr in ipairs(attrs) do
			local ratio = nil

			if random then
				ratio = SheetUtil.getNumber(baseData[attr .. "_ratio"], random) / 100
			else
				ratio = baseData[attr .. "_ratio"]
			end

			local base = baseNumData[attr]
			local value = math.floor(base * ratio)
			data[attr] = value
		end

		for i, element in ipairs(elements) do
			if baseData[element .. "_res"] and baseData[element .. "_res"] ~= "" then
				data[element .. "_res"] = baseData[element .. "_res"]
			end
		end

		local attrList = SheetUtil.getColumnList(baseData, {
			"attr_index",
			"attr_value"
		}, {
			"attr",
			"value"
		})

		for i, v in ipairs(attrList) do
			if data[v.attr] then
				data[v.attr] = data[v.attr] + v.value
			else
				data[v.attr] = v.value
			end
		end
	else
		baseNumData = CsvParser.getCsvData(baseFilename, level)

		for i, attr in ipairs(attrs) do
			local attr = CombatAttr.attrs[i]
			local base = baseNumData[attr]
			local value = math.floor(baseNumData[attr])
			data[attr] = value
		end
	end

	local otherAttrs = CombatAttr.getBaseFileAttrs(baseFilename)

	for i, attr in ipairs(otherAttrs) do
		if baseNumData[attr] ~= "" then
			data[attr] = data[attr] + baseNumData[attr]
		end
	end

	return data, baseNumData
end

local mainAttrMap = nil

function CombatAttr.isMainAttr(attr)
	if not mainAttrMap then
		mainAttrMap = {}

		for i, v in ipairs(CombatAttr.attrs) do
			mainAttrMap[v] = true
		end
	end

	return mainAttrMap[attr]
end

function CombatAttr.clearOnScene()
	CombatAttr.attrLevel = nil

	CombatAttr.clearCache()

	heroSuitSkillCache = {}
	baseFileAttrsCache = {}
end

return CombatAttr
