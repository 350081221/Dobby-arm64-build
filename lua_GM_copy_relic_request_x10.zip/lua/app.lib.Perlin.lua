local Perlin = class("Perlin")

function Perlin.fade(t)
	return t * t * t * (t * (t * 6 - 15) + 10)
end

function Perlin.lerp(t, a, b)
	return a + t * (b - a)
end

function Perlin.grad(hash, x, y, z)
	local h = hash % 16
	local u = h < 8 and x or y
	local v = h < 4 and y or (h == 12 or h == 14) and x or z

	return (h % 2 == 0 and u or -u) + (h % 3 == 0 and v or -v)
end

function Perlin:ctor(size, random)
	self.size = size
	self.p = {}

	for i = 1, size do
		self.p[i] = random:getInt(1, size)
		self.p[size + i] = self.p[i]
	end
end

function Perlin:noise(x, y, z)
	local X = math.floor(x) % self.size
	local Y = math.floor(y) % self.size
	local Z = math.floor(z) % self.size
	x = x - math.floor(x)
	y = y - math.floor(y)
	z = z - math.floor(z)
	local u = Perlin.fade(x)
	local v = Perlin.fade(y)
	local w = Perlin.fade(z)
	local A = self.p[X + 1] + Y
	local AA = self.p[A + 1] + Z
	local AB = self.p[A + 2] + Z
	local B = self.p[X + 2] + Y
	local BA = self.p[B + 1] + Z
	local BB = self.p[B + 2] + Z

	return Perlin.lerp(w, Perlin.lerp(v, Perlin.lerp(u, Perlin.grad(self.p[AA + 1], x, y, z), Perlin.grad(self.p[BA + 1], x - 1, y, z)), Perlin.lerp(u, Perlin.grad(self.p[AB + 1], x, y - 1, z), Perlin.grad(self.p[BB + 1], x - 1, y - 1, z))), Perlin.lerp(v, Perlin.lerp(u, Perlin.grad(self.p[AB + 2], x, y, z - 1), Perlin.grad(self.p[BA + 2], x - 1, y, z - 1)), Perlin.lerp(u, Perlin.grad(self.p[AB + 2], x, y - 1, z - 1), Perlin.grad(self.p[BB + 2], x - 1, y - 1, z - 1))))
end

return Perlin
