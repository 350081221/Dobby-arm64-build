local PopManager = {
	existedMap = {}
}
local ANIM_TYPE = {
	RIGHT = 5,
	LEFT = 4,
	FADE = 3,
	CENTER = 2,
	JUMP = 1,
	NONE = 0
}
PopManager.ANIM_TYPE = ANIM_TYPE
local hideColor = cc.c3b(150, 150, 150)
local showColor = cc.c3b(255, 255, 255)
local hideOpacity = 255
local defaultOpacity = 153
local backgroundUiName = "background"
local backgroundUI = nil
local uiStack = {}
local forceMaskOpacity = nil

function PopManager.clear()
	backgroundUI = nil
	forceMaskOpacity = nil
	uiStack = {}
end

function PopManager.setBackground(uiName)
	backgroundUiName = uiName
end

function PopManager.getMask()
	if backgroundUI then
		return backgroundUI:getComponentByTag("mask")
	end
end

function PopManager.setMaskOpacity(opacity)
	if backgroundUI then
		local mask = backgroundUI:getComponentByTag("mask")

		mask:setOpacity(forceMaskOpacity or opacity)
	end
end

function PopManager.forceMaskOpacity(opacity)
	forceMaskOpacity = opacity

	PopManager.setMaskOpacity(opacity)
end

function PopManager.clearForceMaskOpacity()
	forceMaskOpacity = nil
end

function PopManager.getMaxOpacity(opacity)
	local maxOpacity = opacity

	for i, v in ipairs(uiStack) do
		local opacity = v.maskOpacity

		if not maxOpacity or maxOpacity < opacity then
			maxOpacity = opacity
		end
	end

	return maxOpacity or defaultOpacity
end

function PopManager.replace(ui, replacedUI, onOpen, onClose, animType, maskOpacity)
	animType = animType or ANIM_TYPE.JUMP
	maskOpacity = maskOpacity or defaultOpacity
	local foundReplaced = nil

	if replacedUI then
		for i, v in ipairs(uiStack) do
			if v.ui == replacedUI then
				foundReplaced = table.remove(uiStack, i)

				break
			end
		end
	end

	if foundReplaced then
		foundReplaced.ui:removeSelf()

		if #uiStack > 0 then
			uiStack[1].ui:setLocalZOrder(LayerConfig.sys - 2)
			uiStack[1].ui:setColor(hideColor)
			uiStack[1].ui:setOpacity(hideOpacity)

			if uiStack[1].ui.popDeactive then
				uiStack[1].ui:popDeactive()
			end
		elseif global.ui then
			global.ui:setColor(hideColor)
			global.ui:setOpacity(hideOpacity)
		end

		display.getRunningScene():addChild(ui, LayerConfig.sys)
		table.insert(uiStack, 1, {
			ui = ui,
			onClose = onClose,
			animType = animType,
			maskOpacity = maskOpacity
		})

		local mask = backgroundUI:getComponentByTag("mask")

		mask:setOpacity(forceMaskOpacity or PopManager.getMaxOpacity(maskOpacity))
		PopManager.popinAnim(ui, onOpen, animType)
	else
		PopManager.open(ui, onOpen, onClose, animType, maskOpacity)
	end
end

function PopManager.open(ui, onOpen, onClose, animType, maskOpacity)
	animType = animType or 1
	maskOpacity = maskOpacity or defaultOpacity

	if #uiStack == 0 then
		if backgroundUiName then
			backgroundUI = UIManager.getUI(backgroundUiName)
			local mask = backgroundUI:getComponentByTag("mask")

			mask:setOpacity(forceMaskOpacity or PopManager.getMaxOpacity(maskOpacity))
			mask:toTouchable()
			mask:addTap(function ()
				PopManager.close()
			end)
			display.getRunningScene():addChild(backgroundUI, LayerConfig.sys - 1)
		end

		LayerConfig.setPopLocked("PopManager", true)
		LayerConfig.setUiExist("PopManager", true)
	end

	display.getRunningScene():addChild(ui, LayerConfig.sys)
	table.insert(uiStack, 1, {
		ui = ui,
		onClose = onClose,
		animType = animType,
		maskOpacity = maskOpacity
	})

	local mask = backgroundUI:getComponentByTag("mask")

	mask:setOpacity(forceMaskOpacity or PopManager.getMaxOpacity(maskOpacity))
	PopManager.popinAnim(ui, onOpen, animType)

	if #uiStack > 1 then
		uiStack[2].ui:setLocalZOrder(LayerConfig.sys - 2)
		uiStack[2].ui:setColor(hideColor)
		uiStack[2].ui:setOpacity(hideOpacity)

		if uiStack[2].ui.popDeactive then
			uiStack[2].ui:popDeactive()
		end
	else
		if global.ui then
			global.ui:setColor(hideColor)
			global.ui:setOpacity(hideOpacity)
		end

		if ui.popActive then
			ui:popActive()
		end
	end
end

function PopManager.close(callback, isAll)
	if #uiStack > 0 then
		local obj = table.remove(uiStack, 1)
		local ui = obj.ui

		if obj.onClose then
			obj.onClose()
		end

		if #uiStack > 0 then
			ui:removeSelf()

			if callback then
				callback()
			end

			uiStack[1].ui:setLocalZOrder(LayerConfig.sys)
			uiStack[1].ui:setColor(showColor)

			if uiStack[1].ui.popActive then
				uiStack[1].ui:popActive()
			end

			local mask = backgroundUI:getComponentByTag("mask")

			mask:setOpacity(forceMaskOpacity or PopManager.getMaxOpacity(uiStack[1].maskOpacity))
			PopManager.fadeinAnim(uiStack[1].ui)
		else
			PopManager.fadeoutAnim(ui)

			local bg = backgroundUI

			PopManager.fadeoutAnim(backgroundUI, function ()
				bg:removeSelf()
				PopManager.onPopRemovedOut()

				if callback then
					callback()
				end
			end)

			backgroundUI = nil

			PopManager.onPopRemove()

			if global.ui then
				global.ui:setColor(showColor)
				global.ui:setOpacity(255)
			end
		end

		if not isAll then
			Sound.playSound("ui_close")
		end
	end
end

function PopManager.count()
	return #uiStack
end

function PopManager.closeAll(fromKey)
	while #uiStack > 0 do
		if fromKey then
			if DramaManager.opening or HintManager.opening then
				return
			end

			if uiStack[1].ui.noCloseByKey then
				break
			end
		end

		PopManager.close(nil, true)
		Sound.playSound("ui_close")
	end
end

function PopManager.closeTo(toUi, callback, noNeedFind)
	if #uiStack > 0 then
		local findInStack = false

		if noNeedFind then
			findInStack = true
		else
			for i, obj in ipairs(uiStack) do
				if obj.ui == toUi then
					findInStack = true

					break
				end
			end
		end

		if findInStack then
			while #uiStack > 0 do
				local obj = uiStack[1]
				local ui = obj.ui

				if ui == toUi then
					PopManager.close(callback, true)

					break
				else
					PopManager.close(nil, true)
				end
			end
		end

		Sound.playSound("ui_close")
	end
end

function PopManager.closeBefore(beforeUi, callback)
	if #uiStack > 0 then
		local findInStack = false

		for i, obj in ipairs(uiStack) do
			if obj.ui == beforeUi then
				findInStack = true

				break
			end
		end

		if findInStack then
			while #uiStack > 1 do
				local obj = uiStack[2]

				if obj then
					local ui = obj.ui

					if ui == beforeUi then
						PopManager.close(callback, true)

						break
					else
						PopManager.close(nil, true)
					end
				end
			end
		end

		Sound.playSound("ui_close")
	end
end

function PopManager.popinAnim(popui, callback, animType)
	if animType == ANIM_TYPE.NONE then
		if callback then
			callback()
		end
	elseif animType == ANIM_TYPE.JUMP then
		popui:setPositionY(-50)
		transition.moveTo(popui, {
			easing = "backOut",
			y = 0,
			time = 0.1
		})
		transition.fadeTo(popui, {
			easing = "sineOut",
			time = 0.1,
			opacity = 255,
			onComplete = callback
		})
	elseif animType == ANIM_TYPE.CENTER then
		local bigScale = UIManager.getBigScale()

		popui:setOpacity(0)

		if bigScale == 1 then
			popui:setContentSize(cc.size(display.width, display.height))
			popui:setAnchorPoint(cc.p(0.5, 0.5))
			popui:setPosition(display.width / 2, display.height / 2)
			popui:setScale(0)
			transition.scaleTo(popui, {
				easing = "backOut",
				time = 0.2,
				scale = 1
			})
		end

		transition.fadeTo(popui, {
			easing = "sineOut",
			time = 0.2,
			opacity = 255,
			onComplete = callback
		})
	elseif animType == ANIM_TYPE.FADE then
		transition.fadeTo(popui, {
			easing = "sineOut",
			time = 0.1,
			opacity = 255,
			onComplete = callback
		})
	elseif animType == ANIM_TYPE.LEFT then
		popui:setPositionX(-50)
		popui:setOpacity(0)
		transition.moveTo(popui, {
			easing = "backOut",
			x = 0,
			time = 0.1
		})
		transition.fadeTo(popui, {
			easing = "sineOut",
			time = 0.1,
			opacity = 255,
			onComplete = callback
		})
	elseif animType == ANIM_TYPE.RIGHT then
		popui:setPositionX(50)
		popui:setOpacity(0)
		transition.moveTo(popui, {
			easing = "backOut",
			x = 0,
			time = 0.1
		})
		transition.fadeTo(popui, {
			easing = "sineOut",
			time = 0.1,
			opacity = 255,
			onComplete = callback
		})
	end
end

function PopManager.fadeinAnim(popui, callback)
	transition.fadeTo(popui, {
		easing = "sineOut",
		time = 0.1,
		opacity = 255,
		onComplete = callback
	})
end

function PopManager.fadeoutAnim(popui, callback)
	transition.stopTarget(popui)
	transition.fadeTo(popui, {
		easing = "linear",
		time = 0.1,
		opacity = 0,
		onComplete = function ()
			if callback then
				callback()
			end

			popui:removeSelf()
		end
	})
end

function PopManager.onPopRemove()
	if PopManager.isPopClear() then
		LayerConfig.setPopLocked("PopManager", false)
		LayerConfig.setUiExist("PopManager", false)
	end
end

function PopManager.onPopRemovedOut()
	if PopManager.isPopClear() then
		-- Nothing
	end
end

function PopManager.isPopClear()
	if #uiStack > 0 then
		return false
	end

	if POP_dialog.isOpening() then
		return false
	end

	return true
end

return PopManager
