local InfoHome = {}
local DELAY_TYPES = {
	InfoDelayItem.TYPE.HOME_CRAFT,
	InfoDelayItem.TYPE.HOME_ALCHEMY,
	InfoDelayItem.TYPE.HOME_WORKSHOP,
	InfoDelayItem.TYPE.HOME_CRAFT_OTHER,
	InfoDelayItem.TYPE.HOME_ALCHEMY_OTHER
}
InfoHome.DELAY_TYPES = DELAY_TYPES
local MUSIC_ORDER = {
	{
		iconIndex = 2,
		name = "顺序"
	},
	{
		iconIndex = 1,
		name = "随机"
	}
}
InfoHome.MUSIC_ORDER = MUSIC_ORDER
local rawData = nil
local enterInfo = {}
local feedInfo = {}
local shopList = nil
local shopRefreshIndex = 0

function InfoHome.init()
	Connection.listen("home_sync", InfoHome.sync)
end

app:addToAppEnterCall(InfoHome.init)

function InfoHome.query(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "home_query")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoHome.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("home_query", callback)
end

function InfoHome.onQuery(rcvData)
	rawData = rcvData
end

function InfoHome.sync(syncData)
	for k, v in pairs(syncData) do
		rawData[k] = v
	end

	ManagerInfo.dataChange("home")
end

function InfoHome.enter(item_id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "home_enter")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			InfoHome.clearOnEnter()
			InfoHome.enterMap(InfoUser.getID(), rcvData)

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("home_enter", {
		item_id = item_id
	}, callback)
end

function InfoHome.visit(user_id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "home_visit")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			InfoHome.clearOnEnter()
			InfoHome.enterMap(user_id, rcvData)

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("home_visit", {
		user_id = user_id
	}, callback)
end

function InfoHome.getTips(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("home_get_tips", callback)
end

function InfoHome.checkVisitor(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "home_check_visitor")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("home_check_visitor", callback)
end

local visitorsCache = nil

function InfoHome.getVisitors(user_id, _callback)
	if visitorsCache then
		if _callback then
			_callback(visitorsCache)
		end

		return
	end

	local function callback(rcvData)
		if rcvData.err then
			-- Nothing
		else
			visitorsCache = rcvData.list

			table.sort(visitorsCache, function (a, b)
				return b.time < a.time
			end)

			if _callback then
				_callback(visitorsCache)
			end
		end
	end

	Connection.request("home_get_visitors", {
		user_id = user_id
	}, callback)
end

function InfoHome.enterMap(user_id, rcvData)
	enterInfo = rcvData.data
	enterInfo.isHome = true
	enterInfo.user_id = user_id
	feedInfo = rcvData.feed_arr or {}

	InfoHome.doEnterMap()
end

function InfoHome.doEnterMap()
	local homeMapCSV = CsvParser.getCsvData("home_map", enterInfo.map_id)
	local name = enterInfo.name

	if empty(name) then
		name = homeMapCSV.name
	end

	Transition.setTitle(name)
	DungeonScene.enterMap(DungeonScene.ENTER_TYPE.NEW, homeMapCSV.garden_map, enterInfo)
end

function InfoHome.resetMap()
	InfoHome.doEnterMap()
end

local itemByMapMap = nil

function InfoHome.initItemByMap()
	if not itemByMapMap then
		itemByMapMap = {}
		local csvRaw = CsvParser.getCsvRaw("item")

		for k, csv in pairs(csvRaw) do
			if csv.type == 40 then
				local map_id = csv.use_value1
				itemByMapMap[map_id] = csv.id
			end
		end
	end
end

function InfoHome.getFeedPets()
	return feedInfo or {}
end

function InfoHome.getUserID()
	return enterInfo.user_id
end

function InfoHome.isPublic()
	return rawData.is_public == 1
end

function InfoHome.getMapID()
	return rawData.map_id or 0
end

function InfoHome.getCurrentMapItem()
	InfoHome.initItemByMap()

	local map_id = rawData.map_id
	local itemID = nil

	if not empty(map_id) then
		itemID = itemByMapMap[map_id]
	end

	if itemID and InfoItem.getNum(itemID) == 0 then
		itemID = nil
	end

	if not itemID then
		for k, item_id in pairs(itemByMapMap) do
			if InfoItem.getNum(item_id) > 0 then
				itemID = item_id

				break
			end
		end
	end

	return itemID
end

function InfoHome.getOnlineMapName()
	if enterInfo then
		return "home_" .. enterInfo.map_id .. "_" .. enterInfo.user_id
	end
end

function InfoHome.isSelf()
	return enterInfo and enterInfo.user_id == InfoUser.getID()
end

function InfoHome.getHosterID()
	return enterInfo and enterInfo.user_id or InfoUser.getID()
end

function InfoHome.getHosterName()
	return enterInfo and enterInfo.user_name or ""
end

local musicData, deviceData = nil
local historyIndex = 1
local history = {}

function InfoHome.mapInit()
	local _deviceData = {}

	if enterInfo and enterInfo.device_str then
		local deviceObj = json.decode(enterInfo.device_str)

		if deviceObj then
			_deviceData = deviceObj
		end
	end

	deviceData = {}

	for i, v in ipairs(_deviceData) do
		local tile = global.map:getTile(v.x, v.y)

		if tile then
			table.insert(deviceData, v)
		end
	end

	musicData = {}

	if enterInfo and enterInfo.music_str then
		local musicObj = json.decode(enterInfo.music_str)

		if musicObj then
			musicData = musicObj
		end
	end

	if not musicData.list then
		musicData.list = {}
	end

	if not musicData.order then
		musicData.order = 1
	end
end

function InfoHome.getMusicData()
	return musicData
end

function InfoHome.initMusic()
	if musicData and musicData.list and #musicData.list > 0 then
		local arr = musicData.list

		if musicData.order == 2 then
			arr = ObjUtil.clone(arr)
			arr = Random.randomOrder(arr)
		end

		local sondArr = {}

		for i, v in ipairs(arr) do
			local itemData = CsvParser.getCsvData("item", v)
			local songName = itemData.use_value1

			if not empty(songName) then
				table.insert(sondArr, songName)
			end
		end

		if #sondArr > 0 then
			Sound.playMusicList(sondArr, true)

			return true
		end
	end
end

function InfoHome.setMusicList(list)
	musicData.list = list
end

function InfoHome.setMusicOrder(order)
	musicData.order = order
end

function InfoHome.saveMusic(onSuccess, onFailure)
	local music_str = json.encode(InfoHome.getMusicData())

	local function callback(rcvData)
		dump(rcvData, "home_music_save")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			enterInfo.music_str = music_str

			InfoHome.initMusic()

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("home_music_save", {
		music_str = music_str
	}, callback)
end

function InfoHome.saveDevice(onSuccess, onFailure)
	local device_str = json.encode(InfoHome.getDeviceData())

	local function callback(rcvData)
		dump(rcvData, "home_device_save")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			enterInfo.device_str = device_str

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("home_device_save", {
		device_str = device_str
	}, callback)
end

function InfoHome.setMap(item_id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "home_set_map")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("home_set_map", {
		item_id = item_id
	}, callback)
end

function InfoHome.setPublic(is_public, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "home_set_public")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("home_set_public", {
		is_public = is_public
	}, callback)
end

function InfoHome.cancelReset()
	InfoHome.mapInit()
	InfoHome.resetHistory()
end

function InfoHome.getDeviceData()
	return deviceData
end

function InfoHome.resetHistory()
	history = {
		json.encode(deviceData)
	}
	historyIndex = 1
end

function InfoHome.addHistory()
	local newHistory = {}
	local jsonStr = json.encode(deviceData)

	if jsonStr ~= newHistory[historyIndex] then
		for i = 1, historyIndex do
			table.insert(newHistory, history[i])
		end

		historyIndex = historyIndex + 1

		table.insert(newHistory, json.encode(deviceData))

		history = newHistory
	end
end

function InfoHome.getHistory()
	return history, historyIndex
end

function InfoHome.undo()
	if historyIndex > 1 then
		historyIndex = historyIndex - 1
		deviceData = json.decode(history[historyIndex])

		notify.dispatch("home_deserialize")
	end
end

function InfoHome.redo()
	if historyIndex < #history then
		historyIndex = historyIndex + 1
		deviceData = json.decode(history[historyIndex])

		notify.dispatch("home_deserialize")
	end
end

function InfoHome.countDevice()
	local count = 0

	for i, v in ipairs(deviceData) do
		count = count + 1
	end

	local homeMapCSV = CsvParser.getCsvData("home_map", enterInfo.map_id)

	return count, homeMapCSV.device_max
end

function InfoHome.addDevice(base_id, x, y)
	table.insert(deviceData, {
		base_id = base_id,
		x = x,
		y = y
	})
	InfoHome.addHistory()
end

function InfoHome.removeDevice(base_id, x, y)
	for i, v in ipairs(deviceData) do
		if v.base_id == base_id and v.x == x and v.y == y then
			table.remove(deviceData, i)
			notify.dispatch("home_deserialize")

			return
		end
	end
end

function InfoHome.turnDevice(base_id, x, y, _angle)
	for i, v in ipairs(deviceData) do
		if v.base_id == base_id and v.x == x and v.y == y then
			local angle = v.angle or 0
			v.angle = angle + _angle

			if v.angle < 0 then
				v.angle = v.angle + 360
			elseif v.angle > 360 then
				v.angle = v.angle - 360
			end

			return v.angle
		end
	end
end

function InfoHome.getDeviceItems(subtype)
	local usedItemMap = {}

	for i, v in ipairs(deviceData) do
		local tile = global.map:getTile(v.x, v.y)

		if tile then
			if not usedItemMap[v.base_id] then
				usedItemMap[v.base_id] = 1
			else
				usedItemMap[v.base_id] = usedItemMap[v.base_id] + 1
			end
		end
	end

	local arr = InfoItem.getList(41, subtype)
	local availableArr = {}

	for i, v in ipairs(arr) do
		local num = v.num

		if usedItemMap[v.base_id] then
			num = num - usedItemMap[v.base_id]
		end

		if num > 0 then
			table.insert(availableArr, {
				base_id = v.base_id,
				num = num
			})
		end
	end

	return availableArr
end

function InfoHome.getLandItems()
	local arr = InfoItem.getList(40)
	local currentItem = nil
	local items = {}

	for i, v in ipairs(arr) do
		local itemCSV = CsvParser.getCsvData("item", v.base_id)

		if itemCSV.use_value1 == enterInfo.map_id then
			currentItem = v
		else
			table.insert(items, v)
		end
	end

	if currentItem then
		table.insert(items, 1, currentItem)
	end

	return items
end

function InfoHome.getBuildingDeviceItems()
	local usedItemMap = {}

	for i, v in ipairs(deviceData) do
		if not usedItemMap[v.base_id] then
			usedItemMap[v.base_id] = 1
		else
			usedItemMap[v.base_id] = usedItemMap[v.base_id] + 1
		end
	end

	local arr = InfoItem.getList(41)
	local items = {}

	for i, v in ipairs(arr) do
		local itemCSV = CsvParser.getCsvData("item", v.base_id)
		local deviceCSV = CsvParser.getCsvData("device", itemCSV.use_value1)

		if not empty(deviceCSV.building) then
			table.insert(items, {
				info = v,
				building = deviceCSV.building,
				used = usedItemMap[v.base_id] ~= nil
			})
		end
	end

	table.sort(items, function (a, b)
		local usedA = a.used and 1 or 0
		local usedB = b.used and 1 or 0

		if usedA == usedB then
			return a.info.base_id < b.info.base_id
		else
			return usedB < usedA
		end
	end)

	return items
end

function InfoHome.findDeviceNPC(itemID)
	local npcArr = ClipOnMap.getUnitList("npc")

	for i, npc in ipairs(npcArr) do
		if npc.npcType == Npc.TYPE.DEVICE and npc.deviceItem == itemID then
			return npc
		end
	end
end

function InfoHome.findDeviceData(itemID)
	local data = nil

	for i, v in ipairs(deviceData) do
		if v.base_id == itemID then
			return v
		end
	end
end

function InfoHome.goDevice(itemID)
	local data = InfoHome.findDeviceData(itemID)

	if data then
		local mapX, mapY = global.map:tileToMap(data)
		local path = MapUtils.getPathClose(mapX, mapY)

		if path then
			global.player:goPath(path, true)
		end
	end
end

function InfoHome.clearOnEnter()
	InfoHomeCraft.clearVisitShop()

	visitorsCache = nil
end

function InfoHome.clearOnReconnect()
	InfoHomeCraft.clearVisitShop()

	shopList = nil
end

function InfoHome.getShopLabels()
	local shopCSVList = CsvParser.getCsvList("home_shop_label")

	return shopCSVList
end

function InfoHome.getShopList(_callback)
	local needQuery = shopList == nil

	if not needQuery and rawData.shop_refresh_time < Time.now() then
		needQuery = true
	end

	if needQuery then
		local function callback(rcvData)
			if rcvData.err then
				-- Nothing
			else
				shopRefreshIndex = shopRefreshIndex + 1
				shopList = rcvData.items

				if _callback then
					_callback(shopList)
				end
			end
		end

		Connection.request("home_shop_list", callback)
	else
		_callback(shopList)
	end
end

function InfoHome.getShopItems()
	local arr = {}
	local multiLabel = nil
	local shopCSVList = CsvParser.getCsvList("home_shop_label")

	if #shopCSVList > 1 then
		local labelMap = {}

		for i, v in ipairs(shopList) do
			local shopCSV = CsvParser.getCsvData("home_shop", v.shop_id, nil, true)

			if shopCSV and (empty(shopCSV.unlock_item) or InfoItem.getNum(shopCSV.unlock_item) > 0) and (shopCSV.no_supply ~= 1 or v.soldout < shopCSV.times) then
				if not labelMap[shopCSV.label] then
					labelMap[shopCSV.label] = {}
				end

				table.insert(labelMap[shopCSV.label], v)
			end
		end

		for i, v in ipairs(shopCSVList) do
			local itemArr = labelMap[v.id]

			if itemArr then
				table.sort(itemArr, function (a, b)
					return a.shop_id < b.shop_id
				end)

				local obj = {
					label = v,
					items = itemArr
				}

				table.insert(arr, obj)
			end
		end

		multiLabel = true
	else
		for i, v in ipairs(shopList) do
			local shopCSV = CsvParser.getCsvData("home_shop", v.shop_id, nil, true)

			if shopCSV and (empty(shopCSV.unlock_item) or InfoItem.getNum(shopCSV.unlock_item) > 0) and (shopCSV.no_supply ~= 1 or v.soldout < shopCSV.times) then
				table.insert(arr, v)
			end
		end

		table.sort(arr, function (a, b)
			return a.shop_id < b.shop_id
		end)

		multiLabel = false
	end

	return arr, multiLabel
end

function InfoHome.buy(shop_id, num, onSuccess, onFailure)
	local preIndex = shopRefreshIndex

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if rcvData.item then
				local item = rcvData.item

				if preIndex == shopRefreshIndex then
					for i, v in ipairs(shopList) do
						if v.shop_id == item.shop_id then
							for k1, v1 in pairs(item) do
								v[k1] = v1
							end
						end
					end
				end
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("home_shop_buy", {
		shop_id = shop_id,
		num = num
	}, callback)
end

function InfoHome.getShopCSV()
	return "home_shop"
end

function InfoHome.getCostNeed()
	return CsvParser.getCsvData("config", "home_shop_need").value
end

function InfoHome.getShopName()
	return "home_shop"
end

function InfoHome.getShopTime()
	return rawData.shop_refresh_time, RefreshManager.getNextTime(RefreshManager.TYPE.HOME_SHOP, Time.now())
end

function InfoHome.getRefreshType()
	return RefreshManager.TYPE.HOME_SHOP
end

return InfoHome
