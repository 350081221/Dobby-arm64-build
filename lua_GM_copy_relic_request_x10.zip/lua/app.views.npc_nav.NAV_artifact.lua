local NAV_base = import(".NAV_base")
local NAV_artifact = class("NAV_artifact", NAV_base)

function NAV_artifact.open(npc)
	local ui = NAV_artifact.new(npc)

	return ui
end

function NAV_artifact:ctor(npc)
	NAV_artifact.super.ctor(self, npc, "nav_artifact")
end

function NAV_artifact:init()
	NAV_artifact.super.init(self)
	self:refresh()
	ManagerInfo.onDataChange(self, "core", nil, function ()
		self:refresh()
	end)
end

function NAV_artifact:refresh()
	local index = 1
	local ui = self.buttons[index].ui
	local redotCount = InfoCore.countRedot()
	local redot = ui:getComponentByTag("redot")

	redot:setVisible(redotCount > 0)
end

function NAV_artifact:onTap(index)
	NAV_artifact.super.onTap(self, index)

	if index == 1 then
		FRAME_core.open()
	elseif index == 2 then
		FRAME_single_shop.open(InfoArtifact, self.npc)
	end
end

return NAV_artifact
