local List = import("...ui.List")
local LIST_naraka_mode = class("LIST_naraka_mode", List)

function LIST_naraka_mode:ctor(rect)
	LIST_naraka_mode.super.ctor(self, rect)

	self.isBounc = false

	self:setCols(2)
	self:setCellName("cell_naraka_mode")
	self:setCellSize(cc.size(self.touchRect.width, 160))
end

function LIST_naraka_mode:onCellInit(ui, csv, index)
	ui:createLabelOnFlag("flag_name", csv.name)
	ui:createLabelOnFlag("flag_desc", csv.desc, {
		wrap = true
	})
	ui:createLabelOnFlag("flag_star", csv.reward_score)

	local iconPath = IconManager.getNarakaMode(csv.id)

	ui:createIconOnFlag("flag_icon", iconPath, 100, 1)

	local skill_mask = ui:getComponentByTag("skill_mask")

	skill_mask:setOpacity(150)
	skill_mask:setLocalZOrder(1000)
	self:onCellSelected(ui, data, self.selectedIndex == index, true)
end

function LIST_naraka_mode:onCellSelected(ui, csv, selected, isInit)
	local _selected = ui:getComponentByTag("selected")

	_selected:setVisible(selected)

	if isInit then
		if selected then
			ui:setOpacity(255)
		else
			ui:setOpacity(150)
		end
	elseif selected then
		transition.stopTarget(ui)
		transition.fadeTo(ui, {
			time = 0.2,
			opacity = 255
		})
	else
		transition.stopTarget(ui)
		transition.fadeTo(ui, {
			time = 0.2,
			opacity = 150
		})
	end
end

return LIST_naraka_mode
