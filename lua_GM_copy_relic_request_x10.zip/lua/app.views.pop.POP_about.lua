local POP_about = class("POP_about", UI_base)

function POP_about.open()
	local ui = POP_about.new()

	display.getRunningScene():addChild(ui, LayerConfig.sys)
end

function POP_about:ctor()
	POP_about.super.ctor(self, "pop_about")
	self:init()
end

function POP_about:init()
	self:initUI()
end

function POP_about:initUI()
	local mask = self:getComponentByTag("mask")

	mask:toTouchable()

	local bg = self:getComponentByTag("bg")

	bg:toTouchable()
	mask:addTap(function ()
		self:removeSelf()
	end)
end

return POP_about
