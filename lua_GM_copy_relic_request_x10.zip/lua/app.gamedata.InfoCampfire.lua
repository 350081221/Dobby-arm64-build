local InfoCampfire = {}
local rawData, gsData = nil

function InfoCampfire.init()
	Connection.listen("campfire_sync", InfoCampfire.sync)
end

app:addToAppEnterCall(InfoCampfire.init)

function InfoCampfire.clear()
end

function InfoCampfire.getData()
	return rawData
end

function InfoCampfire.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoCampfire.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("campfire_query", callback)
end

function InfoCampfire.onQuery(rcvData)
	rawData = rcvData
end

function InfoCampfire.sync(data)
	for k, v in pairs(data) do
		rawData[k] = v
	end

	ManagerInfo.dataChange("campfire", data)
end

function InfoCampfire.checkSeason(force, onSuccess, onFailure)
	if not force and rawData.season_id == rawData.season then
		local section, moment = RefreshManager.getSection(RefreshManager.TYPE.CAMPFIRE, Time.now())

		if moment == rawData.season_time then
			if onSuccess then
				onSuccess()
			end

			return
		end
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if CONFIG.is_ta and rcvData.campfire_id then
				local params = {
					campfire_id = rcvData.campfire_id,
					campfire_level = rcvData.campfire_level,
					personal_score = rcvData.personal_score
				}

				TaHelper.taTrack("end_activity_campfire")
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("campfire_check_season", callback)
end

function InfoCampfire.addWood(wood_id, num, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if CONFIG.is_ta and rcvData.is_new == 1 then
				local params = {
					campfire_id = rawData.base_id
				}

				TaHelper.taTrack("join_activity_campfire")
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("campfire_add_wood", {
		wood_id = wood_id,
		num = num
	}, callback)
end

function InfoCampfire.getInfo(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			gsData = rcvData

			InfoCampfire.fixGsData()

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("campfire_get_info", callback)
end

function InfoCampfire.getExp(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("campfire_get_exp", callback)
end

function InfoCampfire.fixGsData()
	local nowTime = Time.now()
	local moments = RefreshManager.getMoments(RefreshManager.TYPE.CAMPFIRE, nowTime)
	local section = RefreshManager.getSection(RefreshManager.TYPE.CAMPFIRE, nowTime)
	local targetNum = InfoParams.getValue("campfire_num")
	gsData.fixed_user_num = nil
	gsData.fixed_score = nil

	if targetNum > 0 then
		local endTime = moments[2]
		local startTime, highTime = nil
		local interval = Time.SECONDS_PER_DAY * 7

		if section == 1 then
			endTime = moments[1]
			startTime = endTime - interval
			highTime = moments[2]
		else
			endTime = moments[1]
			startTime = endTime - interval
			highTime = moments[2] - interval
		end

		if endTime < highTime then
			highTime = highTime - interval
		end

		local highTarget = targetNum * 0.8
		local percent = math.max(0, math.min(1, (nowTime - startTime) / (endTime - startTime)))
		local bezPoints = {}

		table.insert(bezPoints, {
			y = 0,
			x = startTime
		})
		table.insert(bezPoints, {
			x = highTime,
			y = targetNum
		})
		table.insert(bezPoints, {
			x = endTime,
			y = targetNum
		})

		local pt = P_BEZ(percent, bezPoints)
		gsData.fixed_user_num = gsData.user_num
		gsData.fixed_score = gsData.score

		if gsData.user_num < pt.y then
			gsData.fixed_user_num = math.floor((gsData.user_num + pt.y) / 2)

			if gsData.user_num > 0 then
				gsData.fixed_score = math.floor(gsData.fixed_user_num / gsData.user_num * gsData.score)
			end
		end
	end
end

function InfoCampfire.getGsData()
	return gsData
end

function InfoCampfire.getCSV()
	local csv = CsvParser.getCsvData("campfire", rawData.base_id)

	return csv
end

function InfoCampfire.inExp()
	local season_step, next_time, last_time = RefreshManager.getSection(RefreshManager.TYPE.CAMPFIRE, Time.now())

	return season_step == 3
end

function InfoCampfire.getLevel(score)
	local level_list = CsvParser.getCsvList("campfire_level")
	local preID = 1

	for i, v in ipairs(level_list) do
		if v.score == 0 then
			return v.id
		elseif score < v.score then
			return v.id
		end
	end
end

function InfoCampfire.getExpTimes(level)
	local levelCsv = CsvParser.getCsvData("campfire_level", math.max(1, level))
	local abyssLevel = InfoDungeon.getAbyssMaxLevel()
	abyssLevel = math.max(1, math.min(abyssLevel, CsvParser.getMaxID("monster_base_num")))
	local monsterBase = CsvParser.getCsvData("monster_base_num", abyssLevel)
	local timesLeft = math.max(0, levelCsv.exp_times - rawData.exp_times)
	local expLeft = timesLeft * monsterBase.exp * levelCsv.exp_ratio

	return timesLeft, levelCsv.exp_times, expLeft
end

function InfoCampfire.checkExpTimes()
	return rawData.exp_time <= Time.now()
end

local campfireLevelRewardMap, campfireRewardMap = nil

function InfoCampfire.getRewards()
	local rewards = {}

	if gsData then
		if not campfireLevelRewardMap then
			campfireLevelRewardMap = {}
			local csvList = CsvParser.getCsvList("campfire_level_reward")

			for i, v in ipairs(csvList) do
				if not campfireLevelRewardMap[v.campfire_id] then
					campfireLevelRewardMap[v.campfire_id] = {}
				end

				if not campfireLevelRewardMap[v.campfire_id][v.level] then
					campfireLevelRewardMap[v.campfire_id][v.level] = {}
				end

				table.insert(campfireLevelRewardMap[v.campfire_id][v.level], v.id)
			end
		end

		if not campfireRewardMap then
			campfireRewardMap = {}
			local csvList = CsvParser.getCsvList("campfire_reward")

			for i, v in ipairs(csvList) do
				if not campfireRewardMap[v.campfire_id] then
					campfireRewardMap[v.campfire_id] = {}
				end

				table.insert(campfireRewardMap[v.campfire_id], v.id)
			end
		end

		local campfire_id = gsData.base_id
		local level = gsData.level
		local selfScore = rawData.score
		local abyssLevel = InfoDungeon.getAbyssMaxLevel()
		local scoreCsvReadyArr = {}
		local targetScore = nil
		local idList = campfireRewardMap[campfire_id]

		for i, id in ipairs(idList) do
			local v = CsvParser.getCsvData("campfire_reward", id)

			if not targetScore then
				if v.score == 0 then
					targetScore = v.score

					table.insert(scoreCsvReadyArr, v)
				elseif selfScore < v.score then
					targetScore = v.score

					table.insert(scoreCsvReadyArr, v)
				end
			elseif v.score == targetScore then
				table.insert(scoreCsvReadyArr, v)
			else
				break
			end
		end

		local scoreCsv = nil

		for i, v in ipairs(scoreCsvReadyArr) do
			if v.abyss_level == 0 then
				scoreCsv = v

				break
			elseif abyssLevel < v.abyss_level then
				scoreCsv = v

				break
			end
		end

		local levelCsv = nil
		local idList = campfireLevelRewardMap[campfire_id][math.max(1, level)]

		for i, id in ipairs(idList) do
			local v = CsvParser.getCsvData("campfire_level_reward", id)

			if v.abyss_level == 0 then
				levelCsv = v

				break
			elseif abyssLevel < v.abyss_level then
				levelCsv = v

				break
			end
		end

		if levelCsv then
			local reward_arr_level = SheetUtil.getColumnList(levelCsv, {
				"reward_id_",
				"reward_num_"
			}, {
				"base_id",
				"num"
			})

			for i, v in ipairs(reward_arr_level) do
				table.insert(rewards, v)
			end
		end

		if scoreCsv then
			local reward_arr_self = SheetUtil.getColumnList(scoreCsv, {
				"reward_id_",
				"reward_num_"
			}, {
				"base_id",
				"num"
			})

			for i, v in ipairs(reward_arr_self) do
				table.insert(rewards, v)
			end
		end
	end

	return rewards
end

return InfoCampfire
