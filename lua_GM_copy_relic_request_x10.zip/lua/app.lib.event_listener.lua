local single_listener = {
	__index = single_listener
}

function single_listener:register(event_name, handler)
	self.handlers[event_name] = handler
end

function single_listener:dispatch(event_name, ...)
	local handler = self.handlers[event_name]
	local count = 0

	if handler then
		handler(...)

		count = count + 1
	end

	return count
end

function single_listener:unregister(event_name)
	self.handlers[event_name] = nil
end

function single_listener:unregisterAll()
	self.handlers = {}
end

local multi_listener = {
	__index = multi_listener,
	register = function (self, event_name, handler)
		local handler_list = self.handlers[event_name]

		if not handler_list then
			handler_list = {
				max_num = 0
			}
			self.handlers[event_name] = handler_list
		end

		local insert = false

		for i = 1, handler_list.max_num do
			if not handler_list[i] then
				handler_list[i] = handler

				return i
			end
		end

		table.insert(handler_list, handler)

		handler_list.max_num = handler_list.max_num + 1

		return handler_list.max_num
	end,
	dispatch = function (self, event_name, ...)
		local handler_list = self.handlers[event_name]

		if not handler_list then
			return
		end

		local count = 0

		for i = 1, handler_list.max_num do
			local handler = handler_list[i]

			if handler then
				handler(...)

				count = count + 1
			end
		end

		return count
	end,
	unregister = function (self, event_name, handler_id)
		if not handler_id then
			Log.warn("multi_listener:unregister no handler_id", event_name)

			return
		end

		local handler_list = self.handlers[event_name]

		if handler_list then
			handler_list[handler_id] = nil
		else
			Log.warn("multi_listener:unregister no handler_list", event_name, handler_id)
		end
	end,
	unregisterAll = function (self)
		self.handlers = {}
	end
}
local event_listener = {
	new = function (type)
		local new_event_listener = {}

		if type == "multi" then
			new_event_listener.handlers = {}

			setmetatable(new_event_listener, multi_listener)
		else
			new_event_listener.handlers = {}

			setmetatable(new_event_listener, single_listener)
		end

		return new_event_listener
	end
}

function event_listener.extendMethods(target, replaceNodeEvent)
	target.event_listener = event_listener.new("multi")

	function target:addEventListener(eventName, listener)
		return self.event_listener:register(eventName, listener)
	end

	function target:removeEventListener(eventName, listener)
		self.event_listener:unregister(eventName, listener)
	end

	function target:dispatchEvent(event)
		event.target = self

		return self.event_listener:dispatch(event.name, event)
	end

	function target:removeAllEventListeners()
		self.event_listener:unregisterAll()
	end

	if replaceNodeEvent then
		function target:setNodeEventEnabled(enabled)
			if enabled then
				local function listener(event)
					local name = event.name

					self:dispatchEvent(event)

					if name == "enter" then
						self:onEnter()
					elseif name == "exit" then
						self:onExit()
					elseif name == "enterTransitionFinish" then
						self:onEnterTransitionFinish()
					elseif name == "exitTransitionStart" then
						self:onExitTransitionStart()
					elseif name == "cleanup" then
						self:removeAllEventListeners()
						self:onCleanup()
					end
				end

				self:addNodeEventListener(cc.NODE_EVENT, listener)
			else
				self:removeNodeEventListener(cc.NODE_EVENT)
			end

			return self
		end

		target:setNodeEventEnabled(true)
	end
end

return event_listener
