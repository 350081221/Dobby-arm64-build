local FrameLooper = class("FrameLooper")
local socket = require("socket")
local MODE = {
	NORMAL = 0,
	STEP = 1
}
FrameLooper.MODE = MODE

function FrameLooper.create(_owner)
	local FrameLooper = FrameLooper.new()

	FrameLooper:setOwner(_owner)

	return FrameLooper
end

function FrameLooper:ctor()
	self.mode = MODE.NORMAL
end

function FrameLooper:setMode(mode)
	self.mode = mode
end

function FrameLooper:setOwner(_owner)
	self.owner = _owner

	self.owner:addNodeEventListener(cc.NODE_ENTER_FRAME_EVENT, function (elapsed_time)
		self:onEnterFrame(elapsed_time)
	end)
	self.owner:scheduleUpdate()
	self:clear()
end

function FrameLooper:getOwner()
	return self.owner
end

function FrameLooper:next()
	self:onEnterFrame(0.016666666666666666)
end

function FrameLooper:clear()
	self.enterFrameFuncIndex = 0
	self.enterFrameFuncLoop = 0
	self.enterFrameFuncArray = {}
	self.paused = false
	self.frame = 0
	self.frameSpeed = 1
	self.absFrame = 0
	self.timeRatio = 1
	self.timeRatioTagMap = {}

	if self.tweenMap then
		for tweenID, v in pairs(self.tweenMap) do
			tween.stop(tweenID)
		end
	end

	self.tweenCount = 0
	self.tweenMap = {}
	self.tweenUpdateMap = {}
	self.pauseTagMap = nil
end

function FrameLooper:pause(tag)
	tag = tag or "_default"
	self.pauseTagMap = self.pauseTagMap or {}
	self.pauseTagMap[tag] = true
	self.paused = true
end

function FrameLooper:resume(tag)
	tag = tag or "_default"

	if self.pauseTagMap then
		self.pauseTagMap[tag] = nil

		if table.nums(self.pauseTagMap) == 0 then
			self.pauseTagMap = nil
		end
	end

	if not self.pauseTagMap then
		self.paused = false
	end
end

function FrameLooper:startLoop(obj, func)
	for i = 1, #self.enterFrameFuncArray do
		if self.enterFrameFuncArray[i].obj == obj and self.enterFrameFuncArray[i].func == func then
			return
		end
	end

	table.insert(self.enterFrameFuncArray, {
		obj = obj,
		func = func
	})
end

function FrameLooper:stopLoop(obj, func)
	for i = 1, #self.enterFrameFuncArray do
		if self.enterFrameFuncArray[i].obj == obj and self.enterFrameFuncArray[i].func == func then
			table.remove(self.enterFrameFuncArray, i)

			if i <= self.enterFrameFuncIndex then
				self.enterFrameFuncIndex = self.enterFrameFuncIndex - 1
			end

			self.enterFrameFuncLoop = self.enterFrameFuncLoop - 1

			return
		end
	end
end

function FrameLooper:clearLoop(obj)
	local i = 1
	local loop = #self.enterFrameFuncArray

	while i <= loop do
		if self.enterFrameFuncArray[i].obj == obj then
			table.remove(self.enterFrameFuncArray, i)

			if i <= self.enterFrameFuncIndex then
				self.enterFrameFuncIndex = self.enterFrameFuncIndex - 1
			end

			self.enterFrameFuncLoop = self.enterFrameFuncLoop - 1
			loop = loop - 1
		else
			i = i + 1
		end
	end
end

local function errorTraceback(errorMessage)
	local tracebackMsg = debug.traceback("", 2)

	InfoGM.sendError("trackback", tostring(errorMessage) .. "\n" .. tracebackMsg)

	if DEV_MODE then
		print(tostring(errorMessage) .. "\n" .. tracebackMsg)
		Console.markError()
		Console.logError("----------------------------------------\n" .. "LUA ERROR: " .. tostring(errorMessage) .. "\n" .. tracebackMsg .. "\n----------------------------------------")
	end
end

function FrameLooper:markTimeUsed()
	if DEV_MODE then
		self.devUpdateUsed = 0
	end
end

function FrameLooper:getTimeUsed()
	return self.devUpdateUsed
end

function FrameLooper:onEnterFrame(elapsed_time)
	if self.paused then
		return
	end

	local startTime = socket.gettime()

	if self.mode == MODE.STEP then
		local frameSpeed = 60 * elapsed_time * self.timeRatio
		frameSpeed = math.min(frameSpeed, 1000)
		self.frameSpeed = frameSpeed
		local preFrame = self.frame
		self.frame = self.frame + frameSpeed
		self.absFrame = self.absFrame + 1
		local frame = self.frame
		local passed = frameSpeed
		local sharp = math.floor(frame) - math.floor(preFrame)
		local startFrame = math.floor(preFrame)
		local elapsedTime = 0.016666666666666666
		local dislayLevel = Sound.getDislayLevel() or 0

		for i = 1, sharp do
			local timeOffset = socket.gettime() - startTime
			self.enterFrameFuncIndex = 1
			self.enterFrameFuncLoop = #self.enterFrameFuncArray

			while self.enterFrameFuncIndex <= self.enterFrameFuncLoop do
				if self.enterFrameFuncArray[self.enterFrameFuncIndex] == nil then
					break
				end

				local status = xpcall(self.enterFrameFuncArray[self.enterFrameFuncIndex].func, errorTraceback, self.enterFrameFuncArray[self.enterFrameFuncIndex].obj, startFrame + i, 1, 1, elapsedTime, elapsed_time, timeOffset)
				self.enterFrameFuncIndex = self.enterFrameFuncIndex + 1
			end

			if i < sharp then
				local timeThre = elapsedTime

				if dislayLevel == 0 then
					timeThre = elapsedTime * (0.5 + (sharp - i) / sharp)
				elseif dislayLevel == 1 then
					timeThre = elapsedTime * (2 + (sharp - i) / sharp)
				elseif dislayLevel == 2 then
					timeThre = elapsedTime * (3 + (sharp - i) / sharp * 3)
				end

				if timeOffset > timeThre then
					if DEV_MODE then
						print("==========onEnterFrame skip==========", i, sharp, timeOffset, timeThre)
					end

					break
				end
			end
		end
	else
		local frameSpeed = 60 * elapsed_time * self.timeRatio
		frameSpeed = math.min(frameSpeed, 5)
		self.frameSpeed = frameSpeed
		local preFrame = self.frame
		self.frame = self.frame + frameSpeed
		self.absFrame = self.absFrame + 1
		local frame = self.frame
		local passed = frameSpeed
		local sharp = math.floor(frame) - math.floor(preFrame)
		self.enterFrameFuncIndex = 1
		self.enterFrameFuncLoop = #self.enterFrameFuncArray

		while self.enterFrameFuncIndex <= self.enterFrameFuncLoop do
			if self.enterFrameFuncArray[self.enterFrameFuncIndex] == nil then
				break
			end

			local status = xpcall(self.enterFrameFuncArray[self.enterFrameFuncIndex].func, errorTraceback, self.enterFrameFuncArray[self.enterFrameFuncIndex].obj, frame, passed, sharp, elapsed_time)
			self.enterFrameFuncIndex = self.enterFrameFuncIndex + 1
		end
	end

	if DEV_MODE and self.devUpdateUsed then
		local timeUsed = socket.gettime() - startTime
		self.devUpdateUsed = self.devUpdateUsed + timeUsed
	end
end

function FrameLooper:tween(time, subject, target, easing, onComplete, onUpdate)
	local tweenID = nil

	local function onTweenComplete()
		self:stopTween(tweenID)

		if onComplete then
			onComplete()
		end
	end

	tweenID = tween(time, subject, target, easing, onTweenComplete)
	self.tweenMap[tweenID] = true
	self.tweenUpdateMap[tweenID] = onUpdate
	self.tweenCount = self.tweenCount + 1

	if self.tweenCount == 1 then
		self:startLoop(self, self.onTweenUpdate)
	end

	return tweenID
end

function FrameLooper:stopTween(tweenID)
	if self.tweenMap[tweenID] then
		tween.stop(tweenID)

		self.tweenMap[tweenID] = nil

		if self.tweenUpdateMap[tweenID] then
			self.tweenUpdateMap[tweenID]()

			self.tweenUpdateMap[tweenID] = nil
		end

		self.tweenCount = self.tweenCount - 1

		if self.tweenCount == 0 then
			self:stopLoop(self, self.onTweenUpdate)
		end
	end
end

function FrameLooper:onTweenUpdate(frame, passed, sharp)
	for tweenID, _ in pairs(self.tweenMap) do
		tween.updateOne(tweenID, passed)
	end

	for tweenID, func in pairs(self.tweenUpdateMap) do
		func()
	end
end

function FrameLooper:setTimeout(func, frameTime, existingNode)
	local countdown = frameTime
	local onTimeoutCountDown = nil

	function onTimeoutCountDown(obj, frame, passed, sharp)
		if existingNode and tolua.isnull(existingNode) then
			self:stopLoop(self, onTimeoutCountDown)

			return
		end

		if countdown > 0 then
			countdown = countdown - passed
		else
			self:stopLoop(self, onTimeoutCountDown)
			func()
		end
	end

	self:startLoop(self, onTimeoutCountDown)

	if existingNode then
		existingNode:addEventListener("cleanup", function ()
			self:stopLoop(self, onTimeoutCountDown)
		end)
	end

	return onTimeoutCountDown
end

function FrameLooper:clearTimeout(idFunc)
	if idFunc ~= nil then
		self:stopLoop(self, idFunc)
	end
end

function FrameLooper:getSecond()
	return math.floor(self.frame / 60)
end

function FrameLooper:getFrame()
	return self.frame
end

function FrameLooper:getAbsFrame()
	return self.absFrame
end

function FrameLooper:getFrameSpeed()
	return self.frameSpeed
end

function FrameLooper:setTimeRatio(tag, r)
	self.timeRatioTagMap[tag] = r
	self.timeRatio = 1

	for k, v in pairs(self.timeRatioTagMap) do
		self.timeRatio = self.timeRatio * v
	end
end

function FrameLooper:clearTimeRatio(tag)
	self.timeRatioTagMap[tag] = nil
	self.timeRatio = 1

	for k, v in pairs(self.timeRatioTagMap) do
		self.timeRatio = self.timeRatio * v
	end
end

return FrameLooper
