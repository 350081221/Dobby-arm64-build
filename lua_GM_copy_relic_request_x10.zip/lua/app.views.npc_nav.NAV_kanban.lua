local NAV_base = import(".NAV_base")
local NAV_kanban = class("NAV_kanban", NAV_base)

function NAV_kanban.open(npc)
	local ui = NAV_kanban.new(npc)

	return ui
end

function NAV_kanban:ctor(npc)
	NAV_kanban.super.ctor(self, npc, "nav_kanban")
	self:refreshRedot()
	ManagerInfo.onDataChange(self, "kanban", nil, function ()
		self:refreshRedot()
	end)
end

function NAV_kanban:refreshRedot()
	local index = 1
	local ui = self.buttons[index].ui
	local redotCount = InfoKanban.countRedot()
	local redot = ui:getComponentByTag("redot")

	redot:setVisible(redotCount > 0)
end

function NAV_kanban:onTap(index)
	NAV_kanban.super.onTap(self, index)

	if index == 1 then
		InfoBuilding.playOpenSfx(InfoBuilding.TAG.KANBAN)
		TaHelper.taGuideDetail(12700)
		FRAME_kanban.open(self.npc)
	end
end

return NAV_kanban
