local UILayout = class("UILayout", function ()
	return display.newNode()
end)
local CONTROL_ZORDER = 1000
local align_array = {
	Style.left,
	Style.center,
	Style.right
}

function UILayout:ctor(title, bigType, isBigInner)
	self:setTouchSwallowEnabled(false)
	self:setCascadeOpacityEnabled(true)
	self:setCascadeColorEnabled(true)
	event_listener.extendMethods(self, true)

	self.ui_title = title
	self.bigType = bigType
	self.isBigInner = isBigInner
	self.tagmap_Component = {}
	self.tagmap_Flag = {}
	self.tagmap_FlagLabel = {}
	self.tagmap_Progress = {}
	self.tagmap_Scroller = {}
	self.tagmap_UI = {}
	self.tagmap_Editbox = {}
	self.tagmap_Group = {}
	self.tagmap_Draw = {}
	self.duplicated_coms = {}

	self:addChildren(title)
end

function UILayout:getBigOffset()
	local bigScale = self:getBigScale()
	local bigX = 0
	local bigY = 0
	local isBig = false

	if bigScale ~= 1 then
		local scale = (1 / bigScale - 1) / 2
		bigX = display.width * scale
		bigY = self:getBigY()
		isBig = true
	end

	return isBig, bigX, bigY
end

function UILayout:getBigScale()
	return self.bigScale or 1
end

function UILayout:getBigY()
	return self.bigY or 0
end

function UILayout:getBigWidth()
	return self.bigWidth or display.width
end

function UILayout:addChildren(title)
	local layoutData = UIManager.uiList[title]
	local comList = layoutData.coms
	local isFrame = layoutData.isFrame

	assert(comList ~= nil, "UI not found:" .. title)

	local bigScale = nil
	local dWidth = display.width
	local dHeight = display.height

	if self.bigType then
		if CONFIG_SCREEN_AUTOSCALE == "FIXED_HEIGHT" then
			if display.width < 960 then
				bigScale = display.width / UIManager.BIG_WIDTH
				dWidth = UIManager.BIG_WIDTH
				self.bigWidth = dWidth

				if self.bigType == UIManager.BIG_TYPE.POP then
					self.bigY = math.min(64, dHeight * (1 / bigScale - 1) / 2)
				elseif self.bigType == UIManager.BIG_TYPE.CENTER then
					self.bigY = dHeight * (1 / bigScale - 1) / 2
				end
			end
		elseif CONFIG_SCREEN_AUTOSCALE == "FIXED_WIDTH" and display.height < 640 then
			bigScale = display.height / 640
			dHeight = 640
		end

		if bigScale then
			self.bigScale = bigScale

			if not self.isBigInner then
				self:setScale(bigScale)
			end
		end
	end

	local maxWidth = 0
	local maxHeight = 0

	for i = 1, #comList do
		local data = comList[i]

		if device.platform == "ios" then
			data = clone(data)
		end

		maxWidth = math.max(maxWidth, data.x + data.width)
		maxHeight = math.max(maxHeight, data.y + data.height)

		if data.flag then
			if isFrame == 1 and not data.widgetAlready then
				data.widgetAlready = true
				local widget = {}

				if data.widget and data.widget.widget ~= "" then
					data.scale = 0
					local widgetArr = string.split(data.widget.widget, ",")

					for j, way in ipairs(widgetArr) do
						way = tonumber(way)
						widget[way] = true
					end
				end

				local x = data.x
				local y = data.y
				local w = data.width
				local h = data.height

				if CONFIG_SCREEN_AUTOSCALE == "FIXED_HEIGHT" then
					local fromWidth = UIManager.design.width
					local toWidth = dWidth

					if bigScale then
						if self.bigType == UIManager.BIG_TYPE.FULL then
							y = (y + h / 2) / bigScale - h / 2 * bigScale
						elseif self.bigType == UIManager.BIG_TYPE.TOP then
							y = y + dHeight * (1 / bigScale - 1)
						elseif self.bigType == UIManager.BIG_TYPE.POP then
							y = y + math.min(64, dHeight * (1 / bigScale - 1) / 2)
						elseif self.bigType == UIManager.BIG_TYPE.CENTER then
							y = y + dHeight * (1 / bigScale - 1) / 2
						end
					end

					if widget then
						if widget[2] and widget[4] then
							w = w + toWidth - fromWidth

							if self.bigType == UIManager.BIG_TYPE.POP then
								if UIManager.getLiuhai() == "left" then
									x = x + UIManager.LIUHAI_WIDTH
									w = w - UIManager.LIUHAI_WIDTH
								elseif UIManager.getLiuhai() == "right" then
									w = w - UIManager.LIUHAI_WIDTH
								end
							end
						elseif widget[2] then
							x = x + toWidth - fromWidth

							if self.bigType == UIManager.BIG_TYPE.POP and UIManager.getLiuhai() == "right" then
								x = x - UIManager.LIUHAI_WIDTH
							end
						elseif widget[4] then
							if self.bigType == UIManager.BIG_TYPE.POP and UIManager.getLiuhai() == "left" then
								x = x + UIManager.LIUHAI_WIDTH
							end
						else
							x = x + (toWidth - fromWidth) / 2
						end
					else
						x = x + (toWidth - fromWidth) / 2
					end
				elseif CONFIG_SCREEN_AUTOSCALE == "FIXED_WIDTH" then
					local fromHeight = UIManager.design.height
					local toHeight = dHeight

					if bigScale then
						if self.bigType == UIManager.BIG_TYPE.FULL then
							x = (x + w / 2) / bigScale - w / 2 * bigScale
						elseif self.bigType == UIManager.BIG_TYPE.TOP then
							x = x + dWidth * (1 / bigScale - 1)
						end
					end

					if widget then
						if widget[1] and widget[3] then
							y = y + (toHeight - fromHeight) / 2
							h = h + toHeight - fromHeight
						elseif widget[1] then
							y = y + toHeight - fromHeight
						elseif not widget[3] then
							y = y + (toHeight - fromHeight) / 2
						end
					else
						y = y + (toHeight - fromHeight) / 2
					end
				end

				data.x = x
				data.y = y
				data.width = w
				data.height = h
			end

			local newData = nil

			if data.tag ~= "" then
				newData = {}

				for k, v in pairs(data) do
					if k ~= "label" then
						newData[k] = v
					end
				end

				newData.originalX = newData.x
				newData.originalY = newData.y
				newData.originalWidth = newData.width
				newData.originalHeight = newData.height
				newData.originalHeight = newData.height

				self:setFlagToTag(newData.tag, newData)
			end

			if data.label then
				local labelParams = data.label
				local labelStyle = {
					size = labelParams.size,
					color = cc.c4b(labelParams.color[1], labelParams.color[2], labelParams.color[3], 255),
					align = align_array[labelParams.align],
					outline = labelParams.outlineSize,
					outlineColor = cc.c4b(labelParams.outlineColor[1], labelParams.outlineColor[2], labelParams.outlineColor[3], 255),
					offsetX = labelParams.offsetX,
					offsetY = labelParams.offsetY,
					opacity = labelParams.opacity
				}

				if newData then
					newData.originalLabel = labelParams.text
					newData.labelStyle = labelStyle
				end

				if labelParams.text ~= "" then
					if newData then
						self:createLabelOnFlag(newData.tag, labelParams.text, labelStyle)
					else
						self:createLabelOnFlag(data, labelParams.text, labelStyle)
					end
				end
			end
		else
			local com = UIManager._getComponentByData(data, layoutData, self.bigType, bigScale, {
				width = dWidth,
				height = dHeight
			})

			if com ~= nil then
				com.data = data

				if data.tag ~= "" then
					self:setComponentToTag(data.tag, com)
				end

				self:addChild(com, i)

				com.uiLayout = self
				com.originalZOrder = i
			end

			if label ~= nil then
				com.label = label
			end
		end
	end

	self.width = maxWidth
	self.height = maxHeight

	self:setContentSize(cc.size(self.width, self.height))
end

function UILayout:getGlobalPosition()
	local x, y = self:getPosition()
	local pos = cc.p(x, y)
	pos = self:getParent():convertToWorldSpace(pos)

	return pos.x, pos.y
end

function UILayout:clearDuplicated(tag)
	if self.duplicated_coms[tag] then
		for i, com in ipairs(self.duplicated_coms[tag]) do
			com:removeSelf()
		end

		self.duplicated_coms[tag] = nil
	end
end

function UILayout:duplicateComponent(tag, num, xOffset, yOffset, align)
	self:clearDuplicated(tag)

	local originalCom = self:getComponentByTag(tag)

	originalCom:setPos(originalCom.x, originalCom.y)

	local startX, startY = originalCom:getPosition()
	local allArr = {}

	for i = 1, num + 1 do
		local com = nil

		if i == 1 then
			com = originalCom
		else
			com = self:duplicateComponentByTag(tag, originalCom)
		end

		local x, y = nil

		if align == Style.center then
			x = startX - xOffset * (num + 2) / 2 + xOffset * i
			y = startY - yOffset * (num + 2) / 2 + yOffset * i
		elseif align == Style.right then
			x = startX - xOffset * (num + 1 - i)
			y = startY - yOffset * (num + 1 - i)
		else
			x = startX + xOffset * (i - 1)
			y = startY + yOffset * (i - 1)
		end

		com:setPosition(x, y)
		table.insert(allArr, com)
	end

	return allArr
end

function UILayout:getComponentMap()
	return self.tagmap_Component
end

function UILayout:setComponentToTag(tag, component)
	self.tagmap_Component[tag] = component
end

function UILayout:getComponentByTag(tag)
	return self.tagmap_Component[tag]
end

function UILayout:removeComponentByTag(tag)
	local com = self.tagmap_Component[tag]

	if com ~= nil then
		com:removeSelf()

		self.tagmap_Component[tag] = nil
	end
end

function UILayout:replaceComponentByTag(tag, component)
	self:removeComponentByTag(tag)
	self:setComponentToTag(tag, component)
end

function UILayout:duplicateComponentByTag(tag, originalCom)
	local layoutData = UIManager.uiList[self.ui_title]
	local comList = layoutData.coms
	self.duplicated_coms[tag] = self.duplicated_coms[tag] or {}

	for i = 1, #comList do
		local data = comList[i]

		if not data.flag and data.tag == tag then
			local com = UIManager._getComponentByData(data)

			if com ~= nil then
				self:addChild(com, i)

				com.uiLayout = self
				com.originalZOrder = i

				table.insert(self.duplicated_coms[tag], com)

				if originalCom then
					com:setSize(originalCom.width, originalCom.height)
				end

				return com
			end
		end
	end

	return nil
end

function UILayout:setFlagToTag(tag, flag)
	self.tagmap_Flag[tag] = flag
end

function UILayout:getFlagByTag(tag)
	return self.tagmap_Flag[tag]
end

function UILayout:getFlagCenterByTag(tag)
	local flag = self:getFlagByTag(tag)

	if flag then
		local centerX = flag.x + flag.width / 2
		local centerY = flag.y + flag.height / 2

		return centerX, centerY
	end
end

function UILayout:removeFlagByTag(tag)
	self.tagmap_Flag[tag] = nil
end

function UILayout:getStyleByTag(tag)
	if self.tagmap_Flag[tag] then
		return self.tagmap_Flag[tag].labelStyle
	end
end

function UILayout:createScrollerByTag(blockName, rectFlag, callback, isVertical)
	if self.tagmap_Scroller[rectFlag] == nil then
		local block = self:getComponentByTag(blockName)
		local scrollFlag = self:getFlagByTag(rectFlag)

		block:toTouchable()
		block:addTouch(function (event, x, y)
			if event == "began" then
				self.touchData = {
					startTouchX = x,
					startX = block:getPositionX()
				}
			elseif event == "moved" or event == "ended" then
				local blockX = x - self.touchData.startTouchX + self.touchData.startX
				local max = scrollFlag.x + scrollFlag.width - block.width / 2
				local min = scrollFlag.x + block.width / 2
				blockX = math.max(min, math.min(max, blockX))

				block:setPositionX(blockX)

				local percent = (blockX - min) / (max - min)

				if callback then
					callback(percent, event == "ended")
				end
			end
		end)

		self.tagmap_Scroller[rectFlag] = {
			block = block,
			rect = scrollFlag,
			isVertical = isVertical
		}
	end
end

function UILayout:setScollerProgressByTag(rectFlag, percent)
	if self.tagmap_Scroller[rectFlag] then
		local block = self.tagmap_Scroller[rectFlag].block
		local scrollFlag = self.tagmap_Scroller[rectFlag].rect
		local max = scrollFlag.x + scrollFlag.width - block.width / 2
		local min = scrollFlag.x + block.width / 2

		block:setPositionX(min + (max - min) * percent)
	end
end

function UILayout:createMaskByFlag(tag, mask_tag)
	local com = self:getComponentByTag(tag)
	local flag = self:getFlagByTag(mask_tag)
	local rect = cc.rect(flag.x, flag.y, flag.width, flag.height)
	local node = display.newClippingRectangleNode(rect)

	node:setCascadeColorEnabled(true)
	node:setCascadeOpacityEnabled(true)
	self:addChild(node, com:getLocalZOrder())
	com:retain()

	if com:getParent() then
		com:removeSelf()
	end

	node:addChild(com)
	com:release()

	return node, com
end

function UILayout:createTrueMask(tag, maskTag)
	local node = self:getComponentByTag(tag)
	local maskLay = self:getComponentByTag(maskTag)

	maskLay:setVisible(true)
	maskLay:setBlendFunc(gl.DST_ALPHA, gl.ZERO)

	local x, y = node:getPosition()
	local size = node:getContentSize()
	local anchor = node:getAnchorPoint()
	local fontFlag = self:getFlagByTag(tag)

	if fontFlag then
		size.height = fontFlag.height
	end

	local xOffset = math.ceil(size.width / 2)
	local yOffset = math.ceil(size.height / 2)

	maskLay:setScaleX(size.width / maskLay.width)
	maskLay:setScaleY(size.height / maskLay.height * 2)
	maskLay:setPosition(xOffset, yOffset + size.height / 2)
	node:setPosition(xOffset, yOffset + size.height / 2)

	local renderTexture = cc.RenderTexture:create(size.width, size.height * 2)

	renderTexture:beginWithClear(1, 1, 1, 0)
	node:visit()
	maskLay:visit()
	renderTexture:endToLua()

	local sprite = cc.Sprite:createWithTexture(renderTexture:getSprite():getTexture())

	sprite:setFlippedY(true)
	self:addChild(sprite, node:getLocalZOrder())

	local anchor = sprite:getAnchorPoint()

	sprite:setPosition(x, y)
	maskLay:setVisible(false)
	self:removeComponentByTag(tag)
	self:setComponentToTag(tag, sprite)

	return sprite
end

function UILayout:createBarByTag(bar_tag, color, isVertical)
	if self.tagmap_Progress[bar_tag] == nil then
		local _bar = self:getComponentByTag(bar_tag)
		local rect = cc.rect(_bar.x, _bar.y, _bar.width, _bar.height)
		local node = display.newClippingRectangleNode(rect)

		node:setCascadeColorEnabled(true)
		node:setCascadeOpacityEnabled(true)
		self:addChild(node, _bar:getLocalZOrder())
		_bar:retain()

		if _bar:getParent() then
			_bar:removeSelf()
		end

		node:addChild(_bar)
		_bar:release()

		local rect = {
			x = _bar.x,
			y = _bar.y,
			width = _bar.width + 1,
			height = _bar.height + 1
		}

		if self.tagmap_Progress == nil then
			self.tagmap_Progress = {}
		end

		if self.tagmap_Progress[bar_tag] ~= nil then
			self.tagmap_Progress[bar_tag].node:removeSelf()
		end

		if color then
			_bar:setColor(color)
		end

		self.tagmap_Progress[bar_tag] = {
			node = node,
			rect = rect,
			bar = _bar,
			isVertical = isVertical
		}

		return node, rect
	else
		return self.tagmap_Progress[bar_tag].node, self.tagmap_Progress[bar_tag].rect
	end
end

function UILayout:setBarProgressByTag(bar_tag, percent)
	local obj = self.tagmap_Progress[bar_tag]

	if obj then
		percent = math.max(0, math.min(1, percent))
		local node = obj.node
		local rect = obj.rect

		if obj.isCircle then
			local maskNode = obj.maskNode
			local polygonPoints = obj.polygonPoints

			if percent > 0 then
				local nodeNum = math.floor((percent + 0.125) * 4) + 1
				local pts = {
					{
						0,
						0
					}
				}

				for i = 1, nodeNum do
					table.insert(pts, polygonPoints[i])
				end

				local ipt = polygonPoints[nodeNum]
				local ipt2 = polygonPoints[nodeNum + 1]
				local iangle = math.atan2(ipt2[2] - ipt[2], ipt2[1] - ipt[1])
				local ix, iy = nil

				if obj.isClockwise then
					ix, iy = GeomPlane.intersect(0, 0, -math.pi * 2 * (percent + 0.25), ipt[1], ipt[2], iangle)
				else
					ix, iy = GeomPlane.intersect(0, 0, math.pi * 2 * (percent + 0.25), ipt[1], ipt[2], iangle)
				end

				table.insert(pts, {
					ix,
					iy
				})
				table.insert(pts, {
					0,
					0
				})
				maskNode:setVisible(true)
				maskNode:clear()

				local xxx = display.newPolygon(pts, {
					borderWidth = 0,
					fillColor = cc.c4f(1, 0, 0, 1)
				}, maskNode)
			else
				maskNode:setVisible(false)
			end
		else
			local isVertical = obj.isVertical

			if isVertical then
				node:setClippingRegion(cc.rect(rect.x, rect.y, rect.width, rect.height * percent))
			else
				node:setClippingRegion(cc.rect(rect.x, rect.y, rect.width * percent, rect.height))
			end
		end
	end
end

function UILayout:setBarColorByTag(bar_tag, color)
	if self.tagmap_Progress[bar_tag] ~= nil then
		local bar = self.tagmap_Progress[bar_tag].bar

		bar:setColor(color)
	end
end

function UILayout:getBarByTag(bar_tag)
	if self.tagmap_Progress and self.tagmap_Progress[bar_tag] then
		return self.tagmap_Progress[bar_tag].bar
	end
end

function UILayout:removeBarByTag(bar_tag)
	if self.tagmap_Progress and self.tagmap_Progress[bar_tag] then
		self.tagmap_Progress[bar_tag].bar:removeSelf()
		self.tagmap_Progress[bar_tag].node:removeSelf()

		self.tagmap_Progress[bar_tag] = nil
	end
end

function UILayout:clearDrawByTag(flag_tag)
	if self.tagmap_Draw[flag_tag] then
		self.tagmap_Draw[flag_tag]:removeSelf()

		self.tagmap_Draw[flag_tag] = nil
	end
end

function UILayout:drawCircleByTag(flag_tag, thickness, color, percent, isClockwise)
	if self.tagmap_Draw[flag_tag] then
		self.tagmap_Draw[flag_tag]:removeSelf()

		self.tagmap_Draw[flag_tag] = nil
	end

	thickness = thickness or 2
	color = color or cc.c4f(1, 0, 0, 1)
	local flag = self:getFlagByTag(flag_tag)
	local centerX = flag.x + flag.width / 2
	local centerY = flag.y + flag.height / 2
	local radius = flag.width / 2
	local node = display.newDrawNode()

	node:setPosition(centerX, centerY)

	percent = math.max(0, math.min(1, 1 - percent))
	local num = 64
	local startIndex = 0
	local endIndex = num

	if isClockwise then
		startIndex = percent * num
	else
		endIndex = endIndex - percent * num
	end

	local prePoint = nil

	for i = math.floor(startIndex), math.ceil(endIndex) do
		local angle = math.min(endIndex, math.max(i, startIndex)) * math.pi * 2 / num
		angle = angle + math.pi / 2
		local point = cc.p(math.cos(angle) * radius, math.sin(angle) * radius)

		if prePoint then
			node:drawSegment(prePoint, point, thickness, color)
		end

		prePoint = point
	end

	self:addChild(node, 1000)

	self.tagmap_Draw[flag_tag] = node

	return node
end

local SCALE_TYPE = {
	SMALL = 2,
	FILL = 1,
	LARGE = 3
}
UILayout.SCALE_TYPE = SCALE_TYPE
local ALIGN_TYPE = {
	BOTTOM = 2,
	NONE = 0,
	TOP = 1,
	RIGHT = 4,
	LEFT = 3
}
UILayout.ALIGN_TYPE = ALIGN_TYPE

function UILayout:createIconOnFlag(tag, texture, zorder, scaleType, offset, isNew, alignType)
	if not isNew then
		self:removeIconOnFlag(tag)
	end

	zorder = zorder or 1000
	offset = offset or cc.p(0, 0)
	local flag = self:getFlagByTag(tag)

	if flag ~= nil then
		local icon = display.newSprite(texture, flag.x + flag.width / 2 + offset.x, flag.y + flag.height / 2 + offset.y)
		local size = icon:getContentSize()

		if scaleType == SCALE_TYPE.LARGE then
			local ratio = size.width / size.height
			local width, height = nil

			if flag.width < flag.height * ratio then
				height = flag.height
				width = flag.height * ratio
			else
				width = flag.width
				height = flag.width / ratio
			end

			icon:setScaleX(width / size.width)
			icon:setScaleY(height / size.height)

			size.width = width
			size.height = height
		elseif scaleType == SCALE_TYPE.SMALL then
			local ratio = size.width / size.height
			local width, height = nil

			if flag.width > flag.height * ratio then
				height = flag.height
				width = flag.height * ratio
			else
				width = flag.width
				height = flag.width / ratio
			end

			icon:setScaleX(width / size.width)
			icon:setScaleY(height / size.height)

			size.width = width
			size.height = height
		elseif scaleType then
			icon:setScaleX(flag.width / size.width)
			icon:setScaleY(flag.height / size.height)

			size.width = flag.width
			size.height = flag.height
		end

		if alignType == ALIGN_TYPE.TOP then
			icon:setPositionY(flag.y + flag.height - size.height + size.height / 2)
		elseif alignType == ALIGN_TYPE.BOTTOM then
			icon:setPositionY(flag.y + size.height / 2)
		elseif alignType == ALIGN_TYPE.LEFT then
			icon:setPositionX(flag.x + size.width / 2)
		elseif alignType == ALIGN_TYPE.RIGHT then
			icon:setPositionX(flag.x + flag.width - size.width + size.width / 2)
		end

		self:addChild(icon, zorder)

		icon.x = flag.x
		icon.y = flag.y
		icon.width = flag.width
		icon.height = flag.height

		self:setComponentToTag(tag, icon)

		return icon, size
	end

	return nil
end

function UILayout:removeIconOnFlag(tag)
	local icon = self:getComponentByTag(tag)

	if icon ~= nil then
		icon:removeSelf()
	end

	self:setComponentToTag(tag)
end

function UILayout:createPicScrollOnFlag(tag, textureArr, _zorder, scaleType, scrollInterval, scrollTime, scrollCallback)
	self:removePicOnFlag(tag)

	local zorder = 1000
	local rect = self:getFlagByTag(tag)
	local pic_mask = nil

	if not rect then
		rect = self:getComponentByTag(tag)
		pic_mask = rect

		pic_mask:setOpacity(5)

		zorder = pic_mask:getLocalZOrder()
	end

	if _zorder then
		zorder = _zorder
	end

	if rect then
		local container = display.newNode()

		container:setCascadeOpacityEnabled(true)

		local tempArr = {}

		for i, texture in ipairs(textureArr) do
			table.insert(tempArr, texture)
		end

		table.insert(tempArr, textureArr[1])

		for i, texture in ipairs(tempArr) do
			local addX = rect.width * (i - 1)
			local pic = display.newSprite(texture, addX + rect.x + rect.width / 2, rect.y + rect.height / 2)
			local size = pic:getContentSize()

			if scaleType == SCALE_TYPE.LARGE then
				local ratio = size.width / size.height
				local width, height = nil

				if rect.width < rect.height * ratio then
					height = rect.height
					width = rect.height * ratio
				else
					width = rect.width
					height = rect.width / ratio
				end

				pic:setScaleX(width / size.width)
				pic:setScaleY(height / size.height)
			elseif scaleType == SCALE_TYPE.SMALL then
				local ratio = size.width / size.height
				local width, height = nil

				if rect.width > rect.height * ratio then
					height = rect.height
					width = rect.height * ratio
				else
					width = rect.width
					height = rect.width / ratio
				end

				pic:setScaleX(width / size.width)
				pic:setScaleY(height / size.height)
			elseif scaleType then
				pic:setScaleX(rect.width / size.width)
				pic:setScaleY(rect.height / size.height)
			end

			container:addChild(pic)
		end

		local picContainer = container
		scrollInterval = scrollInterval or 3
		scrollTime = scrollTime or 0.2
		local scrollIndex = 1
		local scrollNext = nil

		function scrollNext()
			if scrollIndex > #textureArr then
				scrollIndex = 2

				picContainer:setPositionX(0)
			else
				scrollIndex = scrollIndex + 1
			end

			if scrollCallback then
				scrollCallback(scrollIndex - 1)
			end

			container:performWithDelay(function ()
				transition.moveTo(picContainer, {
					easing = "sineOut",
					time = scrollTime,
					x = -rect.width * (scrollIndex - 1),
					onComplete = scrollNext
				})
			end, scrollInterval)
		end

		scrollNext()

		if pic_mask then
			local clipNode = cc.ClippingNode:create()

			clipNode:setStencil(pic_mask)
			clipNode:setAlphaThreshold(0.0001)
			clipNode:addChild(container)
			clipNode:setCascadeOpacityEnabled(true)

			container = clipNode
		end

		container.x = rect.x
		container.y = rect.y
		container.width = rect.width
		container.height = rect.height

		self:addChild(container, zorder)
		self:setComponentToTag(tag .. "__pic", container)

		return container
	end
end

function UILayout:createPicOnFlag(tag, texture, _zorder, scaleType, alignType)
	self:removePicOnFlag(tag)

	local zorder = 1000
	local rect = self:getFlagByTag(tag)
	local pic_mask = nil

	if not rect then
		rect = self:getComponentByTag(tag)
		pic_mask = rect

		pic_mask:setOpacity(5)

		zorder = pic_mask:getLocalZOrder()
	end

	if _zorder then
		zorder = _zorder
	end

	if rect then
		local pic = display.newSprite(texture, rect.x + rect.width / 2, rect.y + rect.height / 2)
		local size = pic:getContentSize()

		if scaleType == SCALE_TYPE.LARGE then
			local ratio = size.width / size.height
			local width, height = nil

			if rect.width < rect.height * ratio then
				height = rect.height
				width = rect.height * ratio
			else
				width = rect.width
				height = rect.width / ratio
			end

			pic:setScaleX(width / size.width)
			pic:setScaleY(height / size.height)
		elseif scaleType == SCALE_TYPE.SMALL then
			local ratio = size.width / size.height
			local width, height = nil

			if rect.width > rect.height * ratio then
				height = rect.height
				width = rect.height * ratio
			else
				width = rect.width
				height = rect.width / ratio
			end

			pic:setScaleX(width / size.width)
			pic:setScaleY(height / size.height)
		elseif scaleType then
			pic:setScaleX(rect.width / size.width)
			pic:setScaleY(rect.height / size.height)
		end

		local size = pic:getContentSize()

		if alignType == ALIGN_TYPE.TOP then
			pic:setPositionY(rect.y + rect.height - size.height)
		elseif alignType == ALIGN_TYPE.BOTTOM then
			pic:setPositionY(rect.y)
		elseif alignType == ALIGN_TYPE.LEFT then
			pic:setPositionX(rect.x)
		elseif alignType == ALIGN_TYPE.RIGHT then
			pic:setPositionX(rect.x + rect.width - size.width)
		end

		if pic_mask then
			local clipNode = cc.ClippingNode:create()

			clipNode:setStencil(pic_mask)
			clipNode:setAlphaThreshold(0.0001)
			clipNode:addChild(pic)
			clipNode:setCascadeOpacityEnabled(true)

			pic = clipNode
		end

		self:addChild(pic, zorder)

		pic.x = rect.x
		pic.y = rect.y
		pic.width = rect.width
		pic.height = rect.height

		self:setComponentToTag(tag .. "__pic", pic)

		return pic
	end
end

function UILayout:createClippingOnFlag(tag, clippingName, picName, _zorder)
	self:removePicOnFlag(tag)

	local zorder = 1000
	local rect = self:getFlagByTag(tag)
	local pic_mask = nil

	if not rect then
		rect = self:getComponentByTag(tag)
		pic_mask = rect

		pic_mask:setOpacity(5)

		zorder = pic_mask:getLocalZOrder()
	end

	if _zorder then
		zorder = _zorder
	end

	if rect then
		local clippingData = JsonParser.parse("res/clipping/" .. clippingName .. ".json")
		local picPath = getFinalRes("res/image/" .. clippingData.path .. "/" .. picName .. ".png")
		local pic = display.newSprite(picPath)
		local picData = clippingData.clipping[picName .. ".png"]

		pic:setScale(picData.scale / 100)
		pic:setPosition(rect.x + math.floor(clippingData.width / 2) + picData.xoffset, rect.y + math.floor(clippingData.height / 2) - picData.yoffset)

		local originalPic = pic

		if pic_mask then
			local clipNode = cc.ClippingNode:create()

			clipNode:setStencil(pic_mask)
			clipNode:setAlphaThreshold(0.0001)
			clipNode:addChild(pic)
			clipNode:setCascadeOpacityEnabled(true)

			pic = clipNode
		end

		self:addChild(pic, zorder)

		pic.x = rect.x
		pic.y = rect.y
		pic.width = rect.width
		pic.height = rect.height

		self:setComponentToTag(tag .. "__pic", pic)

		return pic, originalPic
	end
end

function UILayout:createNodeOnFlag(tag, node, _zorder)
	self:removePicOnFlag(tag)

	local zorder = 1000
	local rect = self:getFlagByTag(tag)
	local pic_mask = nil

	if not rect then
		rect = self:getComponentByTag(tag)
		pic_mask = rect

		pic_mask:setOpacity(5)

		zorder = pic_mask:getLocalZOrder()
	end

	if _zorder then
		zorder = _zorder
	end

	local pic = node
	local x, y = pic:getPosition()

	if rect then
		pic:setPosition(rect.x + x, rect.y + y)

		local originalPic = pic

		if pic_mask then
			local clipNode = cc.ClippingNode:create()

			clipNode:setStencil(pic_mask)
			clipNode:setAlphaThreshold(0.0001)
			clipNode:addChild(pic)
			clipNode:setCascadeOpacityEnabled(true)

			pic = clipNode
		end

		self:addChild(pic, zorder)

		pic.x = rect.x
		pic.y = rect.y
		pic.width = rect.width
		pic.height = rect.height

		self:setComponentToTag(tag .. "__pic", pic)

		return pic, originalPic
	end
end

function UILayout:removeNodeOnFlag(tag)
	self:removePicOnFlag(tag)
end

function UILayout:removeClippingOnFlag(tag)
	self:removePicOnFlag(tag)
end

function UILayout:removePicOnFlag(tag)
	local pic = self:getComponentByTag(tag .. "__pic")

	if pic ~= nil then
		pic:removeSelf()
	end

	self:setComponentToTag(tag .. "__pic")
end

function UILayout:createEditBoxOnComponent(tag, onEditFunc)
	local com = self:getComponentByTag(tag)
	local texture = com.texture

	if com ~= nil then
		local editbox = ccui.EditBox:create(cc.size(com.width, com.height), texture, ccui.TextureResType.localType)

		editbox:setPosition(com.x + com.width / 2, com.y + com.height / 2)
		editbox:setFontSize(com.height)

		if onEditFunc then
			editbox:registerScriptEditBoxHandler(onEditFunc)
		end

		if com.labelStyle then
			editbox:setFontSize(com.labelStyle.size)
			editbox:setFontColor(com.labelStyle.color)
		end

		self:addChild(editbox, CONTROL_ZORDER)

		self.tagmap_Editbox[tag] = editbox
		editbox.component_tag = tag

		com:setVisible(false)

		return editbox
	end

	return nil
end

function UILayout:getEditBoxByTag(tag)
	return self.tagmap_Editbox[tag]
end

function UILayout:createBMFLabelOnFlag(tag, text, font)
	text = text or "Hello, World"
	local flag = self:getFlagByTag(tag)

	if flag ~= nil then
		local label = ccui.newBMFontLabel({
			text = text,
			font = font,
			x = flag.x,
			y = -flag.y
		})

		self:addChild(label, CONTROL_ZORDER)
		self:setComponentToTag(tag, label)

		label.flag_tag = tag

		return label
	end

	return nil
end

function UILayout:createLabelOnFlag(tag, text, style, noAddChild, noSetComponent)
	local newText = nil

	if style and style.noLocal then
		newText = text
	else
		newText = Localization.getUiText(text)
	end

	if not self.multiLangLabelStack then
		self.multiLangLabelStack = {}
	end

	table.insert(self.multiLangLabelStack, {
		tag = tag,
		text = text,
		style = style,
		noAddChild = noAddChild,
		noSetComponent = noSetComponent
	})

	return self:_createLabelOnFlag(tag, newText, style, noAddChild, noSetComponent)
end

function UILayout:replaceLabelOnFlag(tag, style, ...)
	local flagData = self:getFlagByTag(tag)

	if not flagData then
		return
	end

	local labelText = flagData.originalLabel or ""
	labelText = Localization.getUiText(labelText)
	labelText = StringUtil.replace(labelText, ...)

	return self:createLabelOnFlag(tag, labelText, style)
end

function UILayout:replaceLabelGroupOnFlag(tag, texts, styles, param)
	local flagData = self:getFlagByTag(tag)

	if not flagData then
		return
	end

	local labelText = flagData.originalLabel or ""

	if param and param._originalLabel then
		labelText = param._originalLabel
	end

	labelText = Localization.getUiText(labelText)
	local labelArr = StringUtil.replaceArr(labelText, unpack(texts))
	local _texts = {}
	local _styles = {}

	for i, v in ipairs(labelArr) do
		table.insert(_texts, v.str)

		if v.index then
			table.insert(_styles, styles[v.index])
		else
			table.insert(_styles, {})
		end
	end

	return self:createLabelGroupOnFlag(tag, _texts, _styles, param)
end

function UILayout:_createLabelOnFlag(tag, text, style, noAddChild, noSetComponent)
	self:removeLabelGroupOnFlag(tag)
	self:removeLabelOnFlag(tag)

	local flag = nil

	if type(tag) == "string" then
		flag = self:getFlagByTag(tag)
	else
		flag = tag
	end

	if flag ~= nil then
		flag.text = text
		local __style = flag.labelStyle and clone(flag.labelStyle) or {}

		if style then
			for k, v in pairs(style) do
				__style[k] = v
			end
		end

		if not __style.size then
			__style.size = flag.height
		end

		local label, labelWidth, labelHeight = self:createLabel(flag.x, flag.y, flag.width, flag.height, text, __style, noAddChild)

		if noSetComponent ~= true then
			self:setComponentToTag(tag, label)

			self.tagmap_FlagLabel[tag] = label
		end

		if flag.opacity ~= nil then
			label:setOpacity(flag.opacity)
		end

		label.flag_tag = tag

		return label, labelWidth, labelHeight, __style
	end

	return nil
end

function UILayout:removeLabelOnFlag(tag)
	self:removeComponentByTag(tag)

	self.tagmap_FlagLabel[tag] = nil
end

function UILayout:changeAllFlagLabelStyle(style)
	for tag, label in pairs(self.tagmap_FlagLabel) do
		local flag = self:getFlagByTag(tag)
		local text = flag.text

		if flag.labelStyle and style then
			for k, v in pairs(style) do
				flag.labelStyle[k] = v
			end
		end

		self:createLabelOnFlag(tag, text, flag.labelStyle)
	end
end

function UILayout:createLabelGroupOnFlag(tag, texts, styles, param, noAddChild, noSetComponent)
	self:removeLabelGroupOnFlag(tag)
	self:removeLabelOnFlag(tag)

	param = param or {}
	local align = param.align or Style.left
	local valign = param.valign or Style.vtop
	local xspace = param.xspace or 0
	local yspace = param.yspace or 5
	local wrap = param.wrap or false
	local limitWidth = param.limitWidth
	local limitWidthText = param.limitWidthText or ""

	if limitWidth then
		wrap = false
	end

	local flag = self:getFlagByTag(tag)

	if flag ~= nil then
		local lineWidth = 0
		local widthArray = {}
		local trueWidthArray = {}
		local heightArray = {}
		local labelArray = {}
		local lineHeight = 0

		if flag.labelStyle and flag.labelStyle.align and not param.align then
			align = flag.labelStyle.align
		end

		local symbolText = ""
		local firstText = nil
		local newTexts = {}

		for i = 1, #texts + 1 do
			local text = texts[i]
			local textType = type(text)
			local isSubSymbol = nil

			if textType == "string" or textType == "number" then
				text = tostring(text)
				isSubSymbol = textType == "string" and Localization.checkSubSymbol(text, customLang)
			end

			if not isSubSymbol and symbolText ~= "" then
				local __style = flag.labelStyle and clone(flag.labelStyle) or {}
				local style = nil

				if styles then
					style = styles[i - 1] or styles
				end

				if style then
					for k, v in pairs(style) do
						__style[k] = v
					end
				end

				if not __style.size then
					__style.size = flag.height
				end

				local label, labelWidth, labelHeight = self:createLabel(flag.x, flag.y, flag.width, flag.height, symbolText, __style, noAddChild)
				local trueWidth = nil

				if firstText ~= symbolText then
					trueWidth = labelWidth
					local _label, _labelWidth, _labelHeight = self:createLabel(flag.x, flag.y, flag.width, flag.height, firstText, __style, true)
					labelWidth = _labelWidth
				end

				if noSetComponent ~= true then
					self:setComponentToTag(tag .. "_label_" .. #labelArray + 1, label)
				end

				table.insert(labelArray, label)
				table.insert(widthArray, labelWidth)

				trueWidthArray[#widthArray] = trueWidth

				table.insert(heightArray, labelHeight)

				lineHeight = math.max(lineHeight, labelHeight)
				label.flag_tag = tag
				lineWidth = lineWidth + labelWidth

				if flag.opacity ~= nil then
					label:setOpacity(flag.opacity)
				end

				table.insert(newTexts, symbolText)

				symbolText = ""
			end

			if text ~= nil then
				if textType == "string" or textType == "number" then
					symbolText = symbolText .. text

					if not isSubSymbol then
						firstText = text
					end
				else
					symbolText = ""
					local label = text

					if noSetComponent ~= true then
						self:setComponentToTag(tag .. "_label_" .. #labelArray + 1, label)
					end

					table.insert(labelArray, label)
					table.insert(widthArray, label.width)
					table.insert(heightArray, label.height)

					lineHeight = math.max(lineHeight, label.height)
					label.flag_tag = tag
					lineWidth = lineWidth + label.width

					if not noAddChild then
						self:addChild(label, CONTROL_ZORDER)
					end

					if flag.opacity ~= nil then
						label:setOpacity(flag.opacity)
					end

					table.insert(newTexts, text)
				end
			end

			if limitWidth and limitWidth <= lineWidth then
				if i < #texts then
					local removeNum = 1

					if limitWidthText then
						removeNum = 2
					end

					for j = 1, removeNum do
						if #labelArray > 0 then
							local label = table.remove(labelArray, #labelArray)

							table.remove(widthArray, #widthArray)
							table.remove(heightArray, #heightArray)

							if not noAddChild then
								label:removeSelf()
							end
						end
					end

					if limitWidthText then
						local label, labelWidth, labelHeight = self:createLabel(flag.x, flag.y, flag.width, flag.height, limitWidthText, __style, noAddChild)

						table.insert(labelArray, label)
						table.insert(widthArray, labelWidth)
						table.insert(heightArray, labelHeight)

						label.flag_tag = tag

						if flag.opacity ~= nil then
							label:setOpacity(flag.opacity)
						end
					end
				end

				break
			end
		end

		local currentX = 0
		local lineWidth = 0
		local lineWidthArray = {}
		local lineCountArray = {}
		local lineArray = {}
		local lineIndex = 1
		local lineNum = 1
		local totalWidth = flag.width
		local totalHeight = lineHeight
		local maxWidth = 0
		local lineCount = 0

		for i = 1, #labelArray do
			local label = labelArray[i]
			local labelWidth = widthArray[i]

			if lineArray[lineIndex] == nil then
				lineArray[lineIndex] = {}
			end

			table.insert(lineArray[lineIndex], label)

			local text = newTexts[i]
			local textType = type(text)

			if (textType == "string" or textType == "number") and text == "\n" or wrap and flag.width < currentX + labelWidth then
				table.insert(lineWidthArray, lineWidth)
				table.insert(lineCountArray, lineCount)

				maxWidth = math.max(maxWidth, lineWidth)
				lineWidth = labelWidth
				lineIndex = lineIndex + 1
				lineNum = lineNum + 1
				lineCount = 1
				currentX = labelWidth
				totalHeight = totalHeight + lineHeight + yspace
			else
				lineWidth = lineWidth + labelWidth
				lineCount = lineCount + 1
				currentX = currentX + labelWidth
			end
		end

		maxWidth = math.max(maxWidth, lineWidth)

		table.insert(lineWidthArray, lineWidth)
		table.insert(lineCountArray, lineCount)

		local currentX = 0
		local currentY = 0
		local lineIndex = 1
		local lineCount = 0

		if valign == Style.vtop then
			currentY = flag.y + flag.height
		elseif valign == Style.vbottom then
			currentY = flag.y + totalHeight
		else
			currentY = flag.y + flag.height / 2 + totalHeight / 2
		end

		local lineWidth = lineWidthArray[lineIndex] or 0

		if align == Style.left then
			currentX = flag.x
		elseif align == Style.right then
			currentX = flag.x + flag.width - lineWidth
		elseif align == Style.center then
			currentX = flag.x + flag.width / 2 - lineWidth / 2
		elseif align == Style.left_in_center then
			currentX = flag.x + flag.width / 2 - maxWidth / 2
		elseif align == Style.right_in_center then
			currentX = flag.x + flag.width / 2 + maxWidth / 2 - lineWidth
		end

		for i = 1, #labelArray do
			local label = labelArray[i]
			local labelWidth = widthArray[i]
			local labelHeight = heightArray[i]
			local trueWidth = trueWidthArray[i]
			local text = newTexts[i]
			local textType = type(text)

			if (textType == "string" or textType == "number") and text == "\n" or wrap and lineCount >= (lineCountArray[lineIndex] or 0) then
				lineIndex = lineIndex + 1
				lineCount = 1
				currentY = currentY - lineHeight - yspace
				local lineWidth = lineWidthArray[lineIndex] or 0

				if align == Style.left then
					currentX = flag.x
				elseif align == Style.right then
					currentX = flag.x + flag.width - lineWidth
				elseif align == Style.center then
					currentX = flag.x + flag.width / 2 - lineWidth / 2
				elseif align == Style.left_in_center then
					currentX = flag.x + flag.width / 2 - maxWidth / 2
				elseif align == Style.right_in_center then
					currentX = flag.x + flag.width / 2 + maxWidth / 2 - lineWidth
				end
			else
				lineCount = lineCount + 1
			end

			local yAdjust = 0

			label:setPosition(currentX + (trueWidth or labelWidth) / 2, currentY + yspace - lineHeight / 2 + yAdjust)

			currentX = currentX + labelWidth
		end

		totalWidth = maxWidth

		return labelArray, lineArray, totalWidth, totalHeight, widthArray, heightArray
	end

	return nil
end

function UILayout:createLabelOnFlagVertical(tag, text, style)
	self:removeLabelGroupOnFlag(tag)

	local flag = self:getFlagByTag(tag)

	if flag ~= nil then
		local totalHeight = 0
		local heightArray = {}
		local labelArray = {}
		local strLen = string.utf8len(text)
		local __style = flag.labelStyle or {}
		local style = nil

		if styles then
			style = styles[i] or styles
		end

		if style then
			for k, v in pairs(style) do
				__style[k] = v
			end
		end

		if not __style.size then
			__style.size = flag.height
		end

		for i = 1, strLen do
			local str = StringUtil.utf8sub(text, i, 1)
			local label, labelWidth, labelHeight = self:createLabel(flag.x, flag.y, flag.width, flag.height, str, __style)

			self:setComponentToTag(tag .. "_label_" .. i, label)
			table.insert(labelArray, label)
			table.insert(heightArray, labelHeight)

			totalHeight = totalHeight + labelHeight
			label.flag_tag = tag

			if flag.opacity ~= nil then
				label:setOpacity(flag.opacity)
			end
		end

		local leftY = flag.y + flag.height / 2 - totalHeight / 2 - self.height

		for i = 1, #labelArray do
			local label = labelArray[i]
			local labelHeight = heightArray[i]

			label:setPositionY(-(leftY + labelHeight / 2))

			leftY = leftY + labelHeight
		end

		return labelArray
	end

	return nil
end

function UILayout:removeLabelGroupOnFlag(tag)
	if type(tag) ~= "string" then
		return
	end

	local i = 1

	while self:getComponentByTag(tag .. "_label_" .. i) ~= nil do
		self:removeComponentByTag(tag .. "_label_" .. i)

		i = i + 1
	end
end

function UILayout:createLabel(x, y, width, height, text, style, noAddChild)
	local label, labelWidth, labelHeigth = UIManager.createLabel(x, y, width, height, text, style)

	if noAddChild ~= true then
		self:addChild(label, CONTROL_ZORDER)
	end

	if device.platform == "ios" and (text == "\n" or text == "\r\n") then
		local _label, _labelWidth, _labelHeigth = UIManager.createLabel(x, y, width, height, " ", style)
		labelHeigth = _labelHeigth
	end

	return label, labelWidth, labelHeigth
end

function UILayout:createTextOnFlag(tag, text, param, _style)
	self:removeLabelGroupOnFlag(tag)
	self:removeLabelOnFlag(tag)

	local defaultStyle = defaultStyle or self:getStyleByTag(tag)
	local style = ObjUtil.copy(defaultStyle)

	if _style then
		for k, v in pairs(_style) do
			style[k] = v
		end
	end

	style = Style.getTTFStyle(style)
	local len = utf8.len(text)
	local textArray = {}
	local styleArray = {}

	for i = 1, len do
		table.insert(textArray, utf8.sub(text, i, i))
		table.insert(styleArray, style)
	end

	return self:createLabelGroupOnFlag(tag, textArray, styleArray, param, noAddChild, noSetComponent)
end

function UILayout:createUbbOnFlag(tag, _text, param, isLight, defaultStyle)
	self:removeLabelGroupOnFlag(tag)
	self:removeLabelOnFlag(tag)

	local defaultStyle = defaultStyle or self:getStyleByTag(tag)
	local style = ObjUtil.copy(defaultStyle)
	local text, ubbMap = Ubb.parse(_text)
	local __text = string.gsub(_text, "\\n", "\n")

	if isLight and text == __text then
		if param then
			for k, v in pairs(param) do
				style[k] = v
			end
		end

		local label, labelWidth, labelHeight, __style = self:_createLabelOnFlag(tag, __text, style)

		return ubbMap, {
			label
		}, {}, labelWidth, labelHeight
	else
		local len = utf8.len(text)
		local textArray = {}
		local styleArray = {}

		for i = 1, len + 1 do
			Ubb.style(ubbMap[i], style, defaultStyle)

			local iText, iStyle, iOnTouch = Ubb.insert(ubbMap[i], style, defaultStyle)

			if iText then
				if iOnTouch then
					local uiLabel = UIManager.getLabel(iText, iStyle)

					uiLabel:toTouchable()
					uiLabel:addTap(iOnTouch)
					table.insert(textArray, uiLabel)
					table.insert(styleArray, iStyle)
				else
					table.insert(textArray, iText)
					table.insert(styleArray, iStyle)
				end
			end

			if i <= len then
				table.insert(textArray, utf8.sub(text, i, i))
				table.insert(styleArray, Style.getTTFStyle(style))
			end
		end

		return ubbMap, self:createLabelGroupOnFlag(tag, textArray, styleArray, param, noAddChild, noSetComponent)
	end
end

function UILayout:animateUbb(ubbMap, labels, fadeTime, defaultInterval, defaultLineInterval, onComplete)
	fadeTime = fadeTime or 0.02
	defaultInterval = defaultInterval or 0.03
	defaultLineInterval = defaultLineInterval or 0.75
	local intervalSum = 0
	local preLabel = nil
	local _currentInterval = defaultInterval

	for i, label in ipairs(labels) do
		label:setOpacity(0)

		_currentInterval = Ubb.interval(ubbMap[i], defaultInterval) or _currentInterval
		local interval = _currentInterval

		if preLabel and label:getPositionX() < preLabel:getPositionX() then
			interval = defaultLineInterval
		end

		intervalSum = intervalSum + interval + Ubb.sleep(ubbMap[i])
		local _onComplete = nil

		if i == #labels and onComplete then
			function _onComplete()
				onComplete(intervalSum)
			end
		end

		transition.fadeIn(label, {
			delay = intervalSum,
			time = fadeTime,
			onComplete = _onComplete
		})

		preLabel = label
	end

	return intervalSum
end

function UILayout:createListOnFlag(flagName, ListClass, tapListener, touchListener, direction)
	local rect = self:getRectByFlag(flagName)
	local list = nil

	if type(ListClass) == "function" then
		list = ListClass(rect, direction)
	else
		list = ListClass.new(rect, direction)
	end

	self:addChild(list, 100)

	if tapListener then
		list:addEventListener("onTapListIcon", function (event)
			tapListener(event.ui, event.data, event.index, event.x, event.y)
		end)
	end

	if touchListener then
		list:addEventListener("onTouchListIcon", function (event)
			touchListener(event.ui, event.data, event.index, event.state, event.x, event.y)
		end)
	end

	list:setParentInfo(self, flagName)
	list:setEmptyText(Localization.getSrcText("当前没有内容"))

	return list
end

function UILayout:createTextAreaOnFlag(flagName)
	local rect = self:getRectByFlag(flagName)
	local list = TextArea.new(rect, self:getStyleByTag(flagName))

	self:addChild(list, 1000)

	return list
end

function UILayout:createScrollerOnFlag(flagName)
	local rect = self:getRectByFlag(flagName)
	local list = Scroller.new(rect)

	self:addChild(list, 1000)

	return list
end

function UILayout:getRectByFlag(flagName)
	local flag = self:getFlagByTag(flagName)

	return flag
end

function UILayout:hitTestByFlag(flagName, x, y, isWorldPos)
	if isWorldPos then
		local _pos = self:convertToNodeSpace(cc.p(x, y))
		x = _pos.x
		y = _pos.y
	else
		x = x / UIManager.getBigScale()
		y = y / UIManager.getBigScale()
	end

	local flag = self:getFlagByTag(flagName)

	if flag then
		return flag.x <= x and flag.y <= y and x <= flag.x + flag.width and y <= flag.y + flag.height
	end
end

function UILayout:hitTestByComponent(tag, x, y, isWorldPos)
	if isWorldPos then
		local _pos = self:convertToNodeSpace(cc.p(x, y))
		x = _pos.x
		y = _pos.y
	else
		x = x / UIManager.getBigScale()
		y = y / UIManager.getBigScale()
	end

	local com = self:getComponentByTag(tag)

	if com then
		return com.x <= x and com.y <= y and x <= com.x + com.width and y <= com.y + com.height
	end

	return false
end

function UILayout:createUIOnFlag(flagName, uiName, zorder, anchorPoint, container)
	local flag = self:getFlagByTag(flagName)
	local ui = UIManager.getUI(uiName)
	local x = flag.x
	local y = flag.y

	ui:setContentSize(cc.size(flag.width, flag.height))

	if anchorPoint then
		x = x + flag.width * anchorPoint.x
		y = y + flag.height * anchorPoint.y

		ui:setAnchorPoint(anchorPoint)
	end

	ui:setPosition(x, y)

	if container then
		container:setCascadeOpacityEnabled(true)
		container:setCascadeColorEnabled(true)
		container:addChild(ui, zorder or 0)

		container.ui_title = "container"
	else
		self:addChild(ui, zorder or 1000)
	end

	ui:setCascadeOpacityEnabled(true)
	ui:setCascadeColorEnabled(true)

	self.tagmap_UI[flagName] = ui

	return ui
end

function UILayout:getUIByTag(tag)
	return self.tagmap_UI[tag]
end

function UILayout:groupByFlag(tag, zIndex)
	local flag = self:getFlagByTag(tag)
	local layer = display.newNode()

	layer:setTouchSwallowEnabled(false)
	self:addChild(layer, zIndex or 0)

	local array = self:getChildren()

	for i = 1, #array do
		local component = array[i]

		if component.multiType then
			if self:checkInFlag(component, flag) then
				component:retain()
				component:removeFromParent(false)
				layer:addChild(component)
				component:release()
			end
		elseif component.flag_tag then
			local componentFlag = component.flag_tag

			if type(componentFlag) == "string" then
				componentFlag = self:getFlagByTag(componentFlag)
			end

			if self:checkInFlag(componentFlag, flag) then
				component:retain()
				component:removeFromParent(false)
				layer:addChild(component)
				component:release()
			end
		elseif component.component_tag and self:checkInFlag(self:getComponentByTag(component.component_tag), flag) then
			component:retain()
			component:removeFromParent(false)
			layer:addChild(component)
			component:release()
		end
	end

	self.tagmap_Group[tag] = layer
	layer.x = flag.x
	layer.y = flag.y
	layer.width = flag.width
	layer.height = flag.height
	layer.originalX = flag.originalX
	layer.originalY = flag.originalY
	layer.originalWidth = flag.originalWidth
	layer.originalHeight = flag.originalHeight

	return layer
end

function UILayout:checkInFlag(component, flag)
	local componentX = component.originalX or component.x
	local componentY = component.originalY or component.y
	local componentWidth = component.originalWidth or component.width
	local componentHeight = component.originalHeight or component.height

	if flag.originalX <= componentX and componentX + componentWidth <= flag.originalX + flag.originalWidth and flag.originalY <= componentY and componentY + componentHeight <= flag.originalY + flag.originalHeight then
		return true
	end
end

function UILayout:getGroupLayer(tag)
	return self.tagmap_Group[tag]
end

function UILayout:refreshLocalization()
	if self.multiLangLabelStack then
		for i, v in ipairs(self.multiLangLabelStack) do
			local newText = Localization.getUiText(v.text)

			self:_createLabelOnFlag(v.tag, newText, v.style, v.noAddChild, v.noSetComponent)
		end
	end
end

function UILayout:onEnter()
end

function UILayout:onExit()
end

return UILayout
