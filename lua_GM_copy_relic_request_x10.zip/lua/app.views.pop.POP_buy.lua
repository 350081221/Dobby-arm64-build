local POP_buy = class("POP_buy", UI_base)
local BUTTON_STYLE = {
	RED = 3,
	GREEN = 2,
	BLUE = 1
}
POP_buy.BUTTON_STYLE = BUTTON_STYLE

function POP_buy.open(msg, costArr, confirmFunc, cancelFunc, confirmDesc, cancelDesc, confirmButtonStyle, cancelButtonStyle)
	local ui = POP_buy.new(msg, costArr, confirmFunc, cancelFunc, confirmDesc, cancelDesc, confirmButtonStyle, cancelButtonStyle)

	PopManager.open(ui)
end

function POP_buy:ctor(msg, costArr, confirmFunc, cancelFunc, confirmDesc, cancelDesc, confirmButtonStyle, cancelButtonStyle)
	POP_buy.super.ctor(self, "pop_buy")

	self.costArr = costArr
	self.msg = msg
	self.confirmFunc = confirmFunc
	self.cancelFunc = cancelFunc
	self.confirmDesc = confirmDesc
	self.cancelDesc = cancelDesc
	self.confirmButtonStyle = confirmButtonStyle or BUTTON_STYLE.BLUE
	self.cancelButtonStyle = cancelButtonStyle or BUTTON_STYLE.BLUE

	self:init()
end

function POP_buy:init()
	self:initUI()
end

function POP_buy:initUI()
	local mask = self:getComponentByTag("mask")

	mask:toTouchable()
	self:createUbbOnFlag("flag_msg", self.msg, {
		wrap = true,
		align = Style.center,
		valign = Style.vcenter
	})

	for k, index in pairs(BUTTON_STYLE) do
		local confirmPB = self:getComponentByTag("confirm_pb_" .. index)

		confirmPB:setVisible(self.confirmButtonStyle == index)

		local cancelPB = self:getComponentByTag("cancel_pb_" .. index)

		cancelPB:setVisible(self.cancelButtonStyle == index)
	end

	local confirmPB = self:getComponentByTag("confirm_pb_" .. self.confirmButtonStyle)

	if self.confirmDesc then
		confirmPB:addLabel(self.confirmDesc)
	end

	confirmPB:toTouchable()

	local function handleConfirm()
		local confirmFunc = self.confirmFunc

		PopManager.close()

		if confirmFunc ~= nil then
			confirmFunc()
		end
	end

	confirmPB:addTap(handleConfirm)
	confirmPB:setTapGroup("button_click")

	local cancelPB = self:getComponentByTag("cancel_pb_" .. self.cancelButtonStyle)

	if self.cancelDesc then
		cancelPB:addLabel(self.cancelDesc)
	end

	cancelPB:toTouchable()

	local function handleCancel()
		local cancelFunc = self.cancelFunc

		PopManager.close()

		if cancelFunc ~= nil then
			cancelFunc()
		end
	end

	cancelPB:addTap(handleCancel)
	cancelPB:setTapGroup("button_click")

	local cellWidth = 130
	local costFlag = self:getFlagByTag("flag_cost")
	local costArr = self.costArr
	costFlag.x = costFlag.x + (3 - #costArr) * cellWidth / 2
	local costList = self:createListOnFlag("flag_cost", function (rect)
		return CostListH.new(rect, nil, cellWidth)
	end)

	costList:setItems(costArr)
end

return POP_buy
