local Unit = import(".Unit")
local CombatUnit = class("CombatUnit", Unit)
local HPBAR_STYLE = {
	CIRCLE = 1,
	BAR = 2
}
CombatUnit.HPBAR_STYLE = HPBAR_STYLE
local CURRENT_HPBAR_STYLE = HPBAR_STYLE.BAR
CombatUnit.CURRENT_HPBAR_STYLE = CURRENT_HPBAR_STYLE
local BUFF_TYPE = {
	CARD = 3,
	SHRINE = 2,
	NORMAL = 1,
	TEST = 10
}
CombatUnit.BUFF_TYPE = BUFF_TYPE
local BUFF_TIMING = {
	BATTLE_OVER_TRIGGER = 50,
	SELF_DIE_TRIGGER = 43,
	ENEMY_DIE_TRIGGER = 42,
	FRIEND_DIE_TRIGGER = 41,
	KILL_TRIGGER = 40,
	INTERVAL_TRIGGER = 30,
	HURT_TRIGGER = 21,
	BEHURT_TRIGGER = 20,
	DODGE_TRIGGER = 12,
	BE_CRITICAL_TRIGGER = 11,
	CRITICAL_TRIGGER = 10,
	SKILL_MULTIPLE = 7,
	ATTACK_MULTIPLE = 6,
	KNOCK = 5,
	SKILL_REPLACE = 4,
	SKILL_TRIGGER = 3,
	ATTACK_REPLACE = 2,
	ATTACK_TRIGGER = 1,
	DMG_ADDON = 73,
	CAST_MODAO = 72,
	BUFF_OVER = 71,
	SHIELD_BREAK = 70,
	HP_HIGHER_REPLACE = 61,
	HP_LOWER_REPLACE = 60
}
CombatUnit.BUFF_TIMING = BUFF_TIMING
local DAMAGE_TRIGGER = {
	CRITICAL = 1,
	NONE_BUFF = 12,
	HAS_BUFF = 11,
	HP_HIGHER = 3,
	HP_LOWER = 2
}
CombatUnit.DAMAGE_TRIGGER = DAMAGE_TRIGGER
local FRIEND_COLOR = cc.c4b(220, 0, 0, 255)
local ENEMY_COLOR = cc.c4b(0, 219, 65, 255)
local skillbar_color = cc.c3b(255, 255, 255)
local skillbar_full_color = cc.c3b(224, 218, 218)
local skillbar_recovering_color = cc.c3b(171, 165, 165)
local shieldbar_color = cc.c3b(57, 230, 255)
local shieldbar_restore_color = cc.c3b(215, 14, 47)

function CombatUnit.startIndex()
	CombatUnit.indexMap = {}
	CombatUnit.index = 1
end

function CombatUnit.clearIndex()
	CombatUnit.indexMap = nil
	CombatUnit.index = nil
end

function CombatUnit.getByIndex(index)
	return CombatUnit.indexMap[index]
end

function CombatUnit:ctor(type)
	CombatUnit.super.ctor(self, type)

	if CombatUnit.index then
		self.combatIndex = CombatUnit.index
		CombatUnit.indexMap[CombatUnit.index] = self
		CombatUnit.index = CombatUnit.index + 1
	end

	self.autoSkills = {}
	self.manualSkills = {}
	self.itemSkills = {}
	self.modaoSkills = {}
	self.buffIndex = 0
	self.additionalRange = 0
	self.buffStackMap = {}

	for k, v in pairs(BUFF_TYPE) do
		self.buffStackMap[v] = {}
	end

	self.toughnessMap = {}
	self.stateMap = {}
	self.stateEffectMap = {}
	self.isUseHate = false
	self.noEntity = false
	self.autoManual = true
	self.battleOut = false
	self.giveupOnRange = true
	self.attrs = {}
	self.battleData = {
		owner = self
	}

	self:resetBattle()
end

function CombatUnit:getItemSkill(itemBaseId)
	if not self.itemSkills[itemBaseId] then
		local itemData = CsvParser.getCsvData("item", itemBaseId)

		if itemData and InfoItem.getNum(itemBaseId) > 0 then
			local skillData = CsvParser.getCsvData("skill", itemData.skill)

			if skillData then
				self.itemSkills[itemBaseId] = {
					cd = 0,
					data = skillData,
					itemID = itemBaseId
				}
			end
		end
	end

	return self.itemSkills[itemBaseId]
end

function CombatUnit:getManualSkills()
	return self.manualSkills
end

function CombatUnit:getManualSkill(index)
	return self.manualSkills[index or 1]
end

function CombatUnit:getActiveSkill()
	return self:getManualSkill(1)
end

function CombatUnit:resetBattle()
	self.battleData.target = nil
	self.casting = {
		sharedCD = 0,
		autoCD = 0,
		autoCDStart = -100,
		skillPack = nil,
		target = nil,
		step = 0,
		time = 0
	}
	self.thinkFreezed = nil
	self.thinkFreezedAI = nil
	self.hpResumeFrame = nil

	self:clearBuff()

	self.toughnessMap = {}
end

function CombatUnit:clearSkillWarning()
	if self.casting and self.casting.warnAssets then
		SkillManager.removeWarning(self.casting.warnAssets)

		self.casting.warnAssets = nil
	end
end

function CombatUnit:interruptSkill()
	self:clearSkillWarning()

	if self.casting and self.casting.step ~= 0 then
		self.casting.step = 0
		self.casting.time = 0
		self.casting.target = nil

		self:setAction("idle")
	end
end

function CombatUnit:initSkill(skillPack)
	if not skillPack.inited then
		local args = skillPack.args

		if not empty(args) and args.hp then
			local hpPercent = self.battleData.hp / self.attrs.hp * 100

			if hpPercent < args.hp.min or args.hp.max < hpPercent then
				return false
			end
		end

		skillPack.inited = true
		local fullFrameTime = WarMachine.getFrame()

		if not empty(skillPack.data.pre_cd) then
			skillPack.cd = fullFrameTime + SheetUtil.getNumber(skillPack.data.pre_cd, self.warRandom)
		else
			skillPack.cd = 0
		end

		SkillManager.resetPower(self, skillPack, WarMachine.getFrame(), true)

		local buffList = SheetUtil.getColumnList(skillPack.data, {
			"start_buff_",
			"start_buff_time_"
		}, {
			"id",
			"time"
		})

		for i, v in ipairs(buffList) do
			self:addBuff(v.id, v.time, nil, self.id, true)
		end

		return true
	end
end

function CombatUnit:reinitSkills()
	for i, skillPack in ipairs(self.manualSkills) do
		self:initSkill(skillPack)
	end
end

function CombatUnit:initSkills()
	local fullFrameTime = WarMachine.getFrame()

	for i, skillPack in ipairs(self.autoSkills) do
		skillPack.inited = nil
		skillPack.opCD = nil
		skillPack.safeCD = nil

		self:initSkill(skillPack)
	end

	local isFirst = true

	for i, skillPack in ipairs(self.manualSkills) do
		skillPack.inited = nil
		skillPack.opCD = nil
		skillPack.safeCD = nil
		local initSucc = self:initSkill(skillPack)

		if initSucc and isFirst then
			isFirst = nil

			if not empty(skillPack.data.pre_cd) then
				self.casting.autoCD = skillPack.cd
				self.casting.autoCDStart = fullFrameTime

				self:refreshSkillbar()
			end
		end
	end
end

function CombatUnit:onBattleStart(warSeed)
	self.summonQueue = nil
	self.warSeed = warSeed
	self.warRandom = Random.new(warSeed)
	self.warStartFrame = WarMachine.getFrame()

	self:stop(24)
	self:resetBattle()

	if not self.noEntity then
		self:setHudVisible(true)
	end

	self.battleFreezeNID = notify.safeRegister(self, "battle_freeze", function (isFreeze)
	end)

	self:initSkills()

	if self.isUseHate then
		self:startHate()
	end

	if self.ai and self.ai.onBattleStart then
		self.ai.onBattleStart(self)
	end

	if not empty(self.data.skill_born) then
		self:castManualSkill(self.data.skill_born, self)
	end

	self:onShieldChanged()

	if self.action == "idle" and not empty(self.battleIdleAction) then
		self:setAction(self.battleIdleAction)
	end

	if self.debugAttrs then
		self.debugAttrs = nil

		self:refreshBattleData()
	end

	if self.battleData.camp == 1 then
		local buffID = InfoDungeon.getMutateFriendBuff()

		if buffID then
			print("添加乱流友方buff buffID:" .. buffID)
			self:addBuff(buffID, nil, , , true)
		end
	end
end

function CombatUnit:getManualSkillCD(index)
	if self.manualSkills[i] then
		return self.manualSkills[index].cd
	end
end

function CombatUnit:dispatchManualSkillsCD()
	local fullFrameTime = WarMachine.getFrame()

	for i, skillPack in ipairs(self.manualSkills) do
		local skillData = skillPack.data

		if skillData.power_as_cd == 1 then
			local power = skillPack.power
			local powerValue = skillPack.powerValue

			self:dispatchEvent({
				name = "skill_power",
				power = power,
				powerValue = powerValue,
				id = skillData.id
			})
			self:dispatchEvent({
				name = "skill_power_" .. skillData.id,
				power = power,
				powerValue = powerValue
			})
		elseif skillPack.cd + skillPack.cdPenal - fullFrameTime > 0 then
			local cd = math.max(skillPack.cd, self.casting.sharedCD)

			self:dispatchEvent({
				name = "skill_cd",
				cd = cd,
				cdMax = skillPack.cdMax,
				id = skillData.id
			})
			self:dispatchEvent({
				name = "skill_cd_" .. skillData.id,
				cd = cd,
				cdMax = skillPack.cdMax
			})
		end
	end
end

function CombatUnit:onBattleOver()
	self:clearBuff()
	self:clearTriggerBuffPack()
	self:clearSkillWarning()
	self:setHudVisible(false)
	self:setReviveHudVisible(false)
	self:stopRevive()
	notify.unregister("battle_freeze", self.battleFreezeNID)

	if self.isUseHate then
		self:stopHate()
	end

	self:setAction("idle")

	if self.debugAttrs then
		self.debugAttrs = nil

		self:refreshBattleData()
	end
end

function CombatUnit:addSkill(id, trigger, args)
	if trigger == nil then
		trigger = true
	end

	local skillData = CsvParser.getCsvData("skill", id)

	if skillData then
		local stack = nil

		if skillData.type == 1 then
			stack = self.autoSkills
		else
			stack = self.manualSkills
		end

		local skillPack = {
			cdMax = 0,
			power = 0,
			cdPenal = 0,
			powerValue = 0,
			cd = 0,
			data = skillData,
			trigger = trigger,
			args = args,
			already = {}
		}

		if not skillData.power_value then
			skillPack.powerValue = SheetUtil.getNumber(skillData.power_value, self.warRandom)
		end

		table.insert(stack, skillPack)

		local buffArr = SheetUtil.getColumnList(skillData, {
			"buff_"
		}, {
			"buffID"
		})

		for i, v in ipairs(buffArr) do
			local buffData = CsvParser.getCsvData("buff", v.buffID)

			if not empty(buffData.trigger_skill) and not self:getSkillPack(buffData.trigger_skill) then
				self:addSkill(buffData.trigger_skill, false)
			end
		end

		return skillPack
	else
		Log.warn("add skill not found id", id)
	end
end

function CombatUnit:getSkillPack(skillID)
	local stacks = {
		self.autoSkills,
		self.manualSkills
	}

	for i, stack in ipairs(stacks) do
		for j, skillPack in ipairs(stack) do
			if skillPack.data and tostring(skillPack.data.id) == tostring(skillID) then
				return skillPack
			end
		end
	end
end

function CombatUnit:clearSkill()
	self.autoSkills = {}
	self.manualSkills = {}
end

function CombatUnit:setData(data)
	CombatUnit.super.setData(self, data)

	self.noKnock = data.no_knock == 1

	if not empty(data.flee_type) then
		self:setFlee(data.flee_type, data.flee_prob, data.flee_step, data.flee_smart, data.flee_cd)
	end

	if not empty(data.ai) then
		self.ai = ScriptLoader.load("res/script/ai/" .. data.ai .. ".lu")

		if not self.ai then
			Log.warn("not found monster ai:" .. data.ai)
		else
			Log.verbose("load monster ai:" .. data.ai)
		end
	else
		self.ai = nil
	end
end

function CombatUnit:getBattleName()
	return self.data.name
end

function CombatUnit:setdebugAttrs(attr, value)
	if not DEV_MODE then
		return
	end

	if not self.debugAttrs then
		self.debugAttrs = {}
	end

	self.debugAttrs[attr] = value

	self:refreshBattleData()
end

function CombatUnit:setBattleData(data)
	self.level = self.info.level
	local preSpeed = self.speed
	data.attack_speed = data.attack_speed or 0
	data.battle_speed = data.battle_speed or 0

	if self.map and self.map.isBattle then
		self.speed = self.data.speed
	end

	for k, v in pairs(data) do
		self.attrs[k] = v
	end

	for type, buffTypeArr in pairs(self.buffStackMap) do
		if not empty(buffTypeArr) then
			for i, buffObj in ipairs(buffTypeArr) do
				if not SkillManager.isNoneAttrBuff(buffObj.id) then
					local buffData = CsvParser.getCsvData("buff", buffObj.id)
					local attrList = SheetUtil.getColumnList(buffData, {
						"attr_",
						"mul_value_",
						"add_value_",
						"attr_index",
						"attr_multi"
					}, {
						"attr",
						"mul",
						"add",
						"attr_index",
						"attr_multi"
					})

					if #attrList == 0 then
						SkillManager.markNoneAttrBuff(buffObj.id)
					else
						self:attrAddup(attrList, data, type, buffObj.seed)
					end
				end
			end
		end
	end

	CombatAttr.finalize(self.attrs, self.customAttrLevel)

	if DEV_MODE and self.debugAttrs then
		for k, v in pairs(self.debugAttrs) do
			self.attrs[k] = v
		end
	end

	if preSpeed ~= self.speed then
		self:reMovePath()
	end

	local scale = 1 + self.attrs.shape_change / 100

	self:setExScale(scale)
end

function CombatUnit:attrAddup(attrList, originaldata, type, seed)
	local random = Random.new(seed)

	for _, obj in ipairs(attrList) do
		local attr = obj.attr
		local mul = obj.mul
		local add = obj.add
		local attr_index = obj.attr_index
		local attr_multi = obj.attr_multi
		local attrCSV = CsvParser.getCsvData("attr", attr)

		if type ~= BUFF_TYPE.SHRINE or attrCSV.type == 1 then
			if self.attrs[attr] then
				if not empty(mul) then
					self.attrs[attr] = self.attrs[attr] + originaldata[attr] * SheetUtil.getNumber(mul, random) / 100
				end

				if not empty(add) then
					self.attrs[attr] = self.attrs[attr] + SheetUtil.getNumber(add, random)
				end

				if not empty(attr_index) and not empty(attr_multi) then
					self.attrs[attr] = self.attrs[attr] + originaldata[attr_index] * SheetUtil.getNumber(attr_multi, random) / 100
				end
			end

			if attr == "battle_speed" and WarMachine.on then
				self.speed = self.data.speed * (1 + self.attrs.battle_speed / 100)
			end
		end
	end
end

function CombatUnit:onShieldChanged()
	self:dispatchEvent({
		name = "shield_changed"
	})

	if not self.map then
		return
	end

	local shield, shieldTotal = self:getShield()

	if shield > 0 then
		if not global.noEffect then
			local effect = self:addLastingEffect(MiscConfig.shield_effect)

			effect:setScale(self:getFootWidth() / effect.originalWidth)
		end
	else
		self:removeLastingEffect(MiscConfig.shield_effect, true)
	end

	self:refreshShieldHud(shield, shieldTotal)
end

function CombatUnit:refreshBattleData()
end

function CombatUnit:getDustSkill(skillBaseID)
	if self.dustSkillMap and self.dustSkillMap[skillBaseID] then
		return self.dustSkillMap[skillBaseID].props
	end
end

function CombatUnit:getDustSkillAttrs(skillBaseID)
	if self.dustSkillMap and self.dustSkillMap[skillBaseID] then
		return self.dustSkillMap[skillBaseID].attrs
	end
end

function CombatUnit:die()
	if not self.battleData.die then
		self.battleData.die = true

		if WarMachine.on and not self.noEntity then
			local friends = WarMachine.getUnitsByCamp(self.battleData.camp)

			if friends then
				for i, unit in ipairs(friends) do
					if unit.battleData and unit.castBuffTrigger then
						unit:castBuffTrigger(BUFF_TIMING.FRIEND_DIE_TRIGGER)
					end
				end
			end

			if self.battleData.camp then
				local petArr = WarMachine.getPetCamp(self.battleData.camp)

				if petArr then
					for i, unit in ipairs(petArr) do
						if unit.battleData and unit.castBuffTrigger then
							unit:castBuffTrigger(BUFF_TIMING.FRIEND_DIE_TRIGGER)
						end
					end
				end

				local enemyCamp = WarMachine.getEnemyCamp(self.battleData.camp)
				local enemies = WarMachine.getUnitsByCamp(enemyCamp)

				if enemies then
					for i, unit in ipairs(enemies) do
						if unit.battleData and unit.castBuffTrigger then
							unit:castBuffTrigger(BUFF_TIMING.ENEMY_DIE_TRIGGER)
						end
					end
				end

				local petArr = WarMachine.getPetCamp(enemyCamp)

				if petArr then
					for i, unit in ipairs(petArr) do
						if unit.battleData and unit.castBuffTrigger then
							unit:castBuffTrigger(BUFF_TIMING.ENEMY_DIE_TRIGGER)
						end
					end
				end
			end

			if WarMachine.on and not empty(self.data.skill_die) then
				local skillData = CsvParser.getCsvData("skill", self.data.skill_die)

				self:castDo(skillData, {
					x = self.x,
					y = self.y
				})
			end
		end

		self:clearBuff()
		self:clearSkillWarning()
		self:clearBlade()
		self:clearEffect()
		CombatUnit.super.stop(self, 14)
		self:stopJump()
		self:resetBattle()
		self:setHudVisible(false)

		if self.type ~= "OnlinePlayer" and self.battleData.camp then
			WarMachine.removeUnit(self)
		end

		self:clearLight()
		self:dispatchEvent({
			name = "die"
		})
	end
end

function CombatUnit:startRevive(countTime)
	self:setReviveHudVisible(true)

	self.battleData.reviveTotal = countTime
	self.battleData.reviveCount = countTime

	MapFrameManager.startLoop(self, self.reviveLoop)
end

function CombatUnit:reviveLoop(frame, passed, sharp)
	self.battleData.reviveCount = self.battleData.reviveCount - passed

	if self.battleData.reviveCount > 0 then
		self.battleData.reviveCount = self.battleData.reviveCount - passed

		self:hudSetRevive(self.battleData.reviveCount / self.battleData.reviveTotal)
		self:dispatchEvent({
			name = "revive_changed",
			count = self.battleData.reviveCount,
			total = self.battleData.reviveTotal
		})
	else
		self:setReviveHudVisible(false)
		MapFrameManager.stopLoop(self, self.reviveLoop)
		self:refill()
		WarMachine.addUnit(self, self.battleData.camp, "CombatUnit:reviveLoop")
	end
end

function CombatUnit:stopRevive()
	self:setReviveHudVisible(false)
	MapFrameManager.stopLoop(self, self.reviveLoop)
end

function CombatUnit:setFlee(fleeType, fleeProb, fleeStep, fleeSmart, fleeCD)
	self.fleeData = {
		fleeCD = 0,
		fleeMark = 0,
		type = fleeType,
		prob = fleeProb,
		step = fleeStep,
		states = {},
		fleeSmart = fleeSmart,
		cd = fleeCD
	}
end

function CombatUnit:clearFleeMark()
	if self.fleeData then
		self.fleeData.fleeMark = 0
	end
end

function CombatUnit:inFlee()
	if self.fleeData and self.fleeData.fleeMark and WarMachine.getFrame() <= self.fleeData.fleeMark then
		return true
	end

	return false
end

function CombatUnit:addFleeState(fleeType)
	if self.fleeData then
		self.fleeData.states[fleeType] = true
	end
end

function CombatUnit:isFlee()
	if self:getState("lock_hate") then
		return
	end

	if self:inCastingStep() then
		return
	end

	local fullFrameTime = WarMachine.getFrame()

	if fullFrameTime < self.fleeData.fleeCD then
		return
	end

	if self.fleeData then
		if type(self.fleeData.type) == "string" then
			local arr = string.split(self.fleeData.type, ",")
			local probArr = string.split(tostring(self.fleeData.prob), ",")

			for i = 1, #arr do
				if self.fleeData.states[tonumber(arr[i])] then
					local prob = probArr[i] or probArr[#probArr]
					prob = tonumber(prob)

					if self.warRandom:next() < prob then
						return true
					end
				end
			end
		elseif self.warRandom:next() < self.fleeData.prob then
			return self.fleeData.states[self.fleeData.type]
		end
	end
end

function CombatUnit:clearFleeState()
	if self.fleeData then
		self.fleeData.states = {}
	end
end

function CombatUnit:damageAddon(value, attackPack)
	local fullFrameTime = WarMachine.getFrame()
	local buffs = self:triggerBuff(BUFF_TIMING.DMG_ADDON, attackPack)

	if buffs and #buffs > 0 then
		local newBuffs = {}

		for i, v in ipairs(buffs) do
			local buffPack = v.pack
			buffPack.dmgAddon = (buffPack.dmgAddon or 0) + value

			if not buffPack.cd or buffPack.cd <= fullFrameTime then
				local buffCSV = buffPack.data
				local checkValue = nil

				if empty(buffCSV.trigger_value_1) then
					checkValue = buffCSV.trigger_value_2
				else
					checkValue = self.attrs[buffCSV.trigger_value_1]
					checkValue = checkValue and checkValue * (buffCSV.trigger_value_2 or 1)
				end

				print("检查累积伤害：", buffCSV.name, buffPack.dmgAddon, checkValue)

				if checkValue and checkValue <= buffPack.dmgAddon then
					table.insert(newBuffs, v)
					print("累积伤害触发，累积清零：", buffCSV.name, buffPack.dmgAddon)

					buffPack.dmgAddon = 0
				end
			end
		end

		if #newBuffs > 0 then
			self:castBuffSkill(newBuffs, attackPack)
		end
	end
end

function CombatUnit:battleUpdate(think, forceThink)
	local fullFrameTime = WarMachine.getFrame()

	if self.battleData.die then
		return
	end

	if self.battleOut then
		return
	end

	if self.startOut and fullFrameTime < self.startOut then
		return
	end

	if self.battleData.hp <= 0 then
		WarMachine.onHpChange(self, self.battleData.hp, 0)

		if self.undeadable then
			self.battleData.hp = 1
		else
			self:die()

			return
		end
	end

	self:updateBuff()
	self:checkCDOver()
	self:checkTarget()

	if self.ai and self.ai.onUpdate then
		self.ai.onUpdate(self, think)
	end

	local inAttackPosition = false

	if not self.isTestBattle and self:checkAutoSkill() then
		if not self:isJumping() and not self:inFlee() then
			self:stop(6)
			self:castSkill()
		end

		inAttackPosition = true
	end

	if (forceThink or think and not self.thinkFreezed and not self.thinkFreezedAI) and not self.trapOnly then
		if self.fleeData then
			local leftTime = self.fleeData.fleeMark - fullFrameTime
			local fleeing = false

			local function findBestDig(neiboursInArea)
				if self.warRandom:next() < self.fleeData.fleeSmart then
					local enemies = WarMachine.getUnitsByCamp(WarMachine.getEnemyCamp(self.battleData.camp))
					local bestTile, bestScore = nil

					for i, tile in ipairs(neiboursInArea) do
						local score = 0

						for j, enemy in ipairs(enemies) do
							if enemy.tile then
								score = score + math.abs(enemy.tile.x - tile.x) + math.abs(enemy.tile.y - tile.y)
							end
						end

						if not bestTile or bestScore < score then
							bestTile = tile
							bestScore = score
						end
					end

					return bestTile
				else
					local warCenter = WarMachine.getCenterTile()

					if warCenter then
						local bestTile, bestScore = nil

						for i, tile in ipairs(neiboursInArea) do
							local score = math.sqrt(math.pow(warCenter.x - tile.x, 2) + math.pow(warCenter.y - tile.y, 2))

							if not bestTile or score < bestScore then
								bestTile = tile
								bestScore = score
							elseif score == bestScore and self.warRandom:next() < 0.5 then
								bestTile = tile
								bestScore = score
							end
						end

						return bestTile
					else
						return neiboursInArea[self.warRandom:getInt(1, #neiboursInArea)]
					end
				end
			end

			if leftTime < 0 then
				if self:isFlee() then
					local fleeStep = SheetUtil.getNumber(self.fleeData.step, self.warRandom) + 1
					local path = self.map:digPath(self.tile, self.walkLevel, self.size, fleeStep, WarMachine.getAreaTileMap(), self, nil, findBestDig, self.warRandom)

					if #path > 1 then
						local fleeTime = fleeStep * self.map.ptPerTile / self.speed

						if self:goPath(path) then
							self.fleeData.fleeMark = fullFrameTime + fleeTime

							if not empty(self.fleeData.cd) then
								self.fleeData.fleeCD = fullFrameTime + SheetUtil.getNumber(self.fleeData.cd, self.warRandom)
							end

							fleeing = true
						end
					end
				end
			elseif not self.moving then
				local fleeStep = math.ceil(self.speed * leftTime / self.map.ptPerTile)

				if fleeStep > 1 then
					local path = self.map:digPath(self.tile, self.walkLevel, self.size, fleeStep, WarMachine.getAreaTileMap(), self, nil, findBestDig, self.warRandom)

					if #path > 1 and self:goPath(path) then
						fleeing = true
					end
				end
			end

			if fleeing then
				self:clearFleeState()

				if self.isUseHate then
					self:clearCurrentHate()
				end

				self:clearTarget()

				return
			end
		end

		self:clearFleeState()

		if self.casting.step == 0 and not inAttackPosition then
			if self.battleData.target ~= nil and self.battleData.target.battleData then
				if not self.moving or self.battleData.preTargetTile ~= self.battleData.target.tile then
					self:tryBattleFollow()
				end
			else
				self:battleThink()
			end
		end
	end

	if not self.isTestBattle and self.moving ~= true then
		local checkOK = self:checkAutoSkill()

		if checkOK then
			self:stop(12)
			self:castSkill()
		end
	end

	self:updateCastSkill()

	if not self.battleData.die then
		self:hpResume()

		if self.casting.step == 4 and self.moving ~= true and not self:checkTileCenter() and self.tile:isMasterUnit(self) and not self:isJumping() and not self:getState("no_move") then
			self:moveToTileCenter()
		end
	end
end

function CombatUnit:battleThink()
	if self.trapOnly then
		return
	end

	if self.thinkStartTime and WarMachine.getFrame() < self.thinkStartTime then
		return
	end

	if self.isUseHate then
		self.battleData.target = self:getCurrentHate()
	end

	if self.battleData.target == nil then
		local enemies = WarMachine.getUnitsByCamp(WarMachine.getEnemyCamp(self.battleData.camp))

		if #enemies > 0 then
			local sortEnemies = {}
			local noTargetEnemies = {}

			for i, enemy in ipairs(enemies) do
				if enemy.battleData and not enemy.battleData.die and not enemy.battleOut and (not enemy.godTime or enemy.godTime < WarMachine.getFrame()) then
					if enemy.summonNoTarget then
						table.insert(noTargetEnemies, {
							target = enemy,
							r = self:getRange(enemy)
						})
					else
						table.insert(sortEnemies, {
							target = enemy,
							r = self:getRange(enemy)
						})
					end
				end
			end

			if #sortEnemies == 0 then
				sortEnemies = noTargetEnemies
			end

			table.sort(sortEnemies, function (a, b)
				if a.r == b.r then
					return a.target.id < b.target.id
				else
					return a.r < b.r
				end
			end)

			while #sortEnemies > 0 do
				self.battleData.target = table.remove(sortEnemies, 1).target

				if self:checkTarget() then
					break
				end
			end
		end
	end
end

function CombatUnit:reBattleThink()
	self:clearTarget()

	if not self.thinkFreezed and not self.thinkFreezedAI then
		self:battleThink()
	end
end

function CombatUnit:clearTarget()
	if self:getState("lock_hate") then
		return
	end

	self:removeTargetTile()

	self.battleData.target = nil
end

function CombatUnit:removeTarget()
	self:removeTargetTile()

	if self:getState("lock_hate") then
		return
	end

	self.battleData.target = nil
end

function CombatUnit:removeTargetTile()
	self.battleData.preTargetRange = nil
	self.battleData.preTargetTile = nil
end

function CombatUnit:checkTarget()
	if self.trapOnly then
		return
	end

	if self:getState("lock_hate") then
		if self.battleData.target ~= nil then
			local target = self.battleData.target

			if target.battleData == nil or target.battleData.die or target.battleOut then
				self:clearState("lock_hate")

				return false
			end
		end

		return true
	end

	if self.battleData.target ~= nil then
		local target = self.battleData.target

		if target.tile == nil or target.battleData == nil or target.battleData.die or target.battleOut then
			self:reBattleThink()

			return false
		end

		return true
	end
end

function CombatUnit:checkCDOver()
	local fullFrameTime = WarMachine.getFrame()

	if self.casting.step == 4 then
		local skillData = self.casting.skillData

		if skillData.is_jump == 1 and skillData.select_type ~= 1 and (not self.casting.target or self.map:mapToTile(self.casting.target.x, self.casting.target.y) ~= self.tile) then
			self:reBattleThink()

			if self.battleData.target then
				self:tryBattleFollow()
			end
		end

		if self.casting.time <= fullFrameTime then
			self.casting.step = 0
			self.casting.time = 0
			self.casting.skillPack = nil
			self.casting.target = nil
		end
	end
end

function CombatUnit:isFriendCross()
	if self.type == "hero" or self.type == "pet" or self.type == "summoned" and self.summonerType ~= "monster" then
		return true
	end

	return false
end

function CombatUnit:moveLoopCheck(nextTile, preTile)
	if not WarMachine.on then
		return true
	end

	local nextCanMove = true

	if self.size == 1 then
		nextCanMove = WarMachine.checkAreaTileMap(nextTile)
	else
		local dirtyX = nextTile.x - preTile.x
		local dirtyY = nextTile.y - preTile.y
		local minX = nextTile.x
		local maxX = nextTile.x + self.size - 1
		local minY = nextTile.y
		local maxY = nextTile.y + self.size - 1

		if dirtyX > 0 then
			local limit = math.max(minX, maxX - dirtyX + 1)

			for i = limit, maxX do
				for j = minY, maxY do
					local tile = self.map:getTile(i, j)

					if not WarMachine.checkAreaTileMap(tile) then
						nextCanMove = false

						break
					end
				end

				if not nextCanMove then
					break
				end
			end

			maxX = limit - 1
		elseif dirtyX < 0 then
			local limit = math.min(maxX, minX - dirtyX - 1)

			for i = minX, limit do
				for j = minY, maxY do
					local tile = self.map:getTile(i, j)

					if not WarMachine.checkAreaTileMap(tile) then
						nextCanMove = false

						break
					end
				end

				if not nextCanMove then
					break
				end
			end

			minX = limit + 1
		end

		if nextCanMove then
			if dirtyY > 0 then
				local limit = math.max(minY, maxY - dirtyY + 1)

				for j = limit, maxY do
					for i = minX, maxX do
						local tile = self.map:getTile(i, j)

						if not WarMachine.checkAreaTileMap(tile) then
							nextCanMove = false

							break
						end
					end

					if not nextCanMove then
						break
					end
				end
			elseif dirtyY < 0 then
				local limit = math.min(maxY, minY - dirtyY - 1)

				for j = minY, limit do
					for i = minX, maxX do
						local tile = self.map:getTile(i, j)

						if not WarMachine.checkAreaTileMap(tile) then
							nextCanMove = false

							break
						end
					end

					if not nextCanMove then
						break
					end
				end
			end
		end
	end

	return nextCanMove
end

function CombatUnit:getNextWalkable(nextTile, occupiedCheckUnit)
	if WarMachine.on and not WarMachine.checkAreaTileMap(nextTile) then
		return false
	end

	if self:isFriendCross() then
		return nextTile:getWalkable(self.walkLevel, function (tile, unitMap)
			return self:checkUnitBlockCamp(tile, unitMap)
		end)
	else
		return CombatUnit.super.getNextWalkable(self, nextTile, occupiedCheckUnit)
	end
end

function CombatUnit:getNextCanMove(nextTile, preTile, alwaysWalkable, occupiedCheckUnit)
	local nextCanMove, newTiles = CombatUnit.super.getNextCanMove(self, nextTile, preTile, alwaysWalkable, occupiedCheckUnit)

	if not nextCanMove then
		self:removeTargetTile()
	end

	return nextCanMove, newTiles
end

function CombatUnit:isSkillFree()
	return self.casting.step == 0
end

function CombatUnit:isRanSkill()
	return self.ranSkill ~= nil
end

function CombatUnit:onRanSkillOver(skillPack)
	if self.ranSkill then
		local stack = self.ranSkill.stack

		for index, obj in ipairs(stack) do
			local _skillPack = obj.skillPack

			if _skillPack ~= skillPack then
				_skillPack.cdMax = skillPack.cdMax
				_skillPack.cd = skillPack.cd
			end
		end

		self.ranSkill.currentIndex = nil
	end
end

function CombatUnit:getRanSkill()
	if self.ranSkill then
		if not self.ranSkill.currentIndex then
			self.ranSkill.currentIndex = SheetUtil.getPowerRandomIndex(self.ranSkill.stack, self.warRandom, "weight")
			local _obj = self.ranSkill.stack[self.ranSkill.currentIndex]
			local _skillPack = _obj.skillPack

			print("宠物随机技能切换", self.ranSkill.currentIndex, _skillPack.data.id, _skillPack.data.name)
		end

		local obj = self.ranSkill.stack[self.ranSkill.currentIndex]

		return obj.skillPack
	end
end

function CombatUnit:isSwitchSkill()
	return self.data and self.data.is_switch_skill == 1
end

function CombatUnit:checkAutoSkill(noTarget, exceptMap)
	if self.thinkFreezedAI then
		return false
	end

	if self.thinkStartTime and WarMachine.getFrame() < self.thinkStartTime then
		return false
	end

	local fullFrameTime = WarMachine.getFrame()

	if (self.casting.step == 0 or self.casting.target == nil) and not self.battleData.die and self.casting.sharedCD <= fullFrameTime then
		local autoSkills = self.autoSkills
		local manualSkills = self.manualSkills

		if self:getState("no_attack") then
			autoSkills = {}
		end

		local ranSkill = self:getRanSkill()

		if ranSkill then
			manualSkills = {
				ranSkill
			}
		end

		if self:getState("no_skill") then
			manualSkills = {}
		end

		local autoLoop = #autoSkills
		local manualLoop = 0
		local loop = autoLoop

		if self.autoManual then
			manualLoop = #manualSkills
			loop = loop + manualLoop
		end

		for i = 1, loop do
			local skillPack = nil

			if i <= manualLoop then
				skillPack = manualSkills[i]
			else
				skillPack = autoSkills[i - manualLoop]
			end

			if skillPack.inited and (skillPack.data.type == 1 or skillPack.data.type == 2) and fullFrameTime >= skillPack.cd + skillPack.cdPenal and (not skillPack.safeCD or skillPack.safeCD <= fullFrameTime) and SkillManager.checkPower(skillPack, fullFrameTime) then
				local skillData = SkillManager.getSkillData(self, skillPack)

				if skillData.is_jump ~= 1 or not self:getState("no_move") then
					local triggerOK = skillPack.trigger

					if triggerOK and (skillData.friend ~= 0 and skillData.friend ~= 3 or self.battleData.target ~= nil or noTarget or self.trapOnly) then
						local lockTargets = nil

						if self:getState("lock_hate") and self.battleData.target then
							lockTargets = {
								self.battleData.target
							}
						end

						local isReady, castTarget = SkillManager.findAutoSkillTarget(self, skillData, self.battleData.target, exceptMap, lockTargets)

						if isReady then
							if (self.type == "hero" or self.type == "hero_copy") and skillPack.data.type == 2 and skillData.cd ~= 0 then
								skillPack.safeCD = fullFrameTime + MiscConfig.castCD
							end

							self.casting.skillData = skillData
							self.casting.skillPack = skillPack
							self.casting.target = castTarget
							self.casting.isManual = i <= manualLoop

							return true
						end
					end
				end
			end
		end
	end

	return false
end

function CombatUnit:castManualSkill(skillPack, target)
	if self:getState("no_skill") then
		return false
	end

	if type(skillPack) ~= "table" then
		skillPack = self:getSkillPack(skillPack)

		if not skillPack then
			Log.warn("no skillpack at " .. skillPack)

			return false
		end
	end

	local fullFrameTime = WarMachine.getFrame()

	if skillPack.safeCD and fullFrameTime < skillPack.safeCD then
		return
	end

	if (self.type == "hero" or self.type == "hero_copy") and skillPack.data.type == 2 then
		local skillData = skillPack.data

		if skillData.cd ~= 0 then
			skillPack.safeCD = fullFrameTime + MiscConfig.castCD
		end
	end

	self.casting.skillData = SkillManager.getSkillData(self, skillPack)
	self.casting.skillPack = skillPack
	self.casting.target = target
	self.casting.isManual = true

	self:stop(13)
	self:castSkill()

	return true
end

function CombatUnit:castSkill()
	local fullFrameTime = WarMachine.getFrame()
	local skillData = self.casting.skillData
	self.casting.step = 1
	self.castPosition = {
		x = self.x,
		y = self.y
	}
	local effectGen = self:getEffectGen()

	if effectGen then
		effectGen:castEffect(skillData.focus_effect, self, nil, , self)
	end

	self.casting.time = fullFrameTime + skillData.pre_time

	if skillData.warning == 1 then
		self.casting.warnAssets = SkillManager.addWarning(self, self.casting.target, self.casting.skillPack)
	end
end

function CombatUnit:addPowerTimes(skillPack, type)
	SkillManager.addPowerTimes(skillPack, type)

	local originalSkillData = skillPack.data
	local power = skillPack.power
	local powerValue = skillPack.powerValue

	self:dispatchEvent({
		name = "skill_power",
		power = power,
		powerValue = powerValue,
		id = originalSkillData.id
	})
	self:dispatchEvent({
		name = "skill_power_" .. originalSkillData.id,
		power = power,
		powerValue = powerValue
	})
end

function CombatUnit:updateCastSkill()
	local fullFrameTime = WarMachine.getFrame()

	if self.casting.time <= fullFrameTime and self.casting.step > 0 then
		local skillPack = self.casting.skillPack
		local skillData = self.casting.skillData

		if self.casting.step == 1 or self.casting.step == 5 then
			if self.casting.step == 1 then
				if not empty(skillData.multiple) then
					local multipleArr = string.split(skillData.multiple, ",")
					skillPack.multiple = {
						interval = 0,
						leftTimes = SheetUtil.getNumber(multipleArr[1], self.warRandom) - 1
					}

					if multipleArr[2] then
						skillPack.multiple.interval = SheetUtil.getNumber(multipleArr[2], self.warRandom) or 0
					end
				end

				skillPack.already = {}
				local cdMax = SheetUtil.getNumber(skillData.cd, self.warRandom)
				local dustSkill = self:getDustSkill(skillData.base_id)

				if dustSkill and dustSkill.skill_cd_reduce then
					cdMax = math.max(0, cdMax - dustSkill.skill_cd_reduce)
				end

				local skillcd_reduce = self.attrs.skillcd_reduce

				if skillData.type == 1 then
					skillcd_reduce = 0
				end

				self.casting.skillPack.cdMax = math.floor(math.max(0, cdMax - skillcd_reduce) * 100 / (100 + self.attrs.skillcd_division))
				self.casting.skillPack.cd = fullFrameTime + self.casting.skillPack.cdMax

				if self:isRanSkill() then
					self:onRanSkillOver(self.casting.skillPack)
				end

				SkillManager.buffTriggerCD(self, self.casting.skillPack)

				if skillData.power_as_cd ~= 1 then
					self.casting.sharedCD = fullFrameTime + math.floor(self.attrs.attack_time / (1 + self.attrs.attack_speed / 100))
				end

				SkillManager.resetPower(self, self.casting.skillPack, WarMachine.getFrame())

				if skillData.type == 2 then
					if skillData.power_as_cd == 1 then
						local originalSkillData = self.casting.skillPack.data
						local power = self.casting.skillPack.power
						local powerValue = self.casting.skillPack.powerValue

						self:dispatchEvent({
							name = "skill_power",
							power = power,
							powerValue = powerValue,
							id = originalSkillData.id
						})
						self:dispatchEvent({
							name = "skill_power_" .. originalSkillData.id,
							power = power,
							powerValue = powerValue
						})

						if self.casting.skillPack == self.manualSkills[1] then
							self.casting.autoCD = self.casting.skillPack.cd
							self.casting.autoCDStart = fullFrameTime

							self:refreshSkillbar()
						end
					else
						local cd = math.max(self.casting.skillPack.cd, self.casting.sharedCD)
						local originalSkillData = self.casting.skillPack.data

						self:dispatchEvent({
							name = "skill_cd",
							cd = cd,
							cdMax = self.casting.skillPack.cdMax,
							id = originalSkillData.id
						})
						self:dispatchEvent({
							name = "skill_cd_" .. originalSkillData.id,
							cd = cd,
							cdMax = self.casting.skillPack.cdMax
						})

						if self.casting.skillPack == self.manualSkills[1] then
							self.casting.autoCD = self.casting.skillPack.cd
							self.casting.autoCDStart = fullFrameTime

							self:refreshSkillbar()
						end
					end
				end
			end

			local buffObj = self.casting.addSkillBuffObj

			if buffObj and buffObj.ammo and buffObj.ammo > 0 then
				buffObj.ammo = buffObj.ammo - 1
				local buffData = CsvParser.getCsvData("buff", buffObj.id)

				self:dispatchEvent({
					name = "buff_times_" .. buffObj.id,
					times = buffObj.ammo,
					maxTimes = buffData.ammo_times
				})

				if buffObj.ammo == 0 then
					self:removeBuff(buffObj)
				end
			end

			if skillData.is_jump == 1 then
				local jumpTarget = nil

				if skillData.select_type == 0 or skillData.select_type == 3 then
					jumpTarget = self.map:toTileCenter(self)
				else
					jumpTarget = self.casting.target
				end

				if skillData.select_type == 2 and skillData.select_auto == 3 and skillData.is_jump == 1 then
					local randomTile = SkillManager.findRandomTile(self, skillData, self.warRandom)

					if randomTile then
						local mapX, mapY = self.map:tileToMap(randomTile)
						jumpTarget = {
							x = mapX,
							y = mapY
						}
					end
				end

				SkillManager.trySummon(SkillManager.SUMMON_TIME.CAST, skillData, self, self)

				if jumpTarget then
					if skillData.select_type ~= 1 and self.map:mapToTile(jumpTarget.x, jumpTarget.y) ~= self.tile then
						self:clearTarget()
					end

					local frameTime = self:jump(jumpTarget, skillData.jump_speed, skillData.jump_height, nil, 30)
					local effectGen = self:getEffectGen()

					if effectGen then
						effectGen:castEffect(skillData.jump_start_effect, jumpTarget, nil, angle, self)
					end

					self.jumpStopEffect = skillData.jump_stop_effect
					local index = 1

					while not empty(skillData["buff_" .. index]) and not empty(skillData["buff_prob_" .. index]) and not empty(skillData["buff_time_" .. index]) do
						if skillData["buff_target_" .. index] == 2 and skillData["buff_time_" .. index] == "jump" and self.warRandom:next() < skillData["buff_prob_" .. index] then
							self:addBuff(skillData["buff_" .. index], frameTime, nil, self.id)
						end

						index = index + 1
					end

					if frameTime ~= false then
						self.casting.step = 2
						self.casting.time = fullFrameTime + frameTime
						local actionTime = math.floor(self:getActionTotalFrameTime(skillData.action) / 2)
						local target = jumpTarget

						if actionTime < frameTime then
							self:setAction("walk")
							MapFrameManager.setTimeout(function ()
								self:setAction("idle")
								self:attackAnimation(target)

								if skillData.select_type == 3 and self.casting.target then
									self:faceTo(self.casting.target)
								end
							end, frameTime - actionTime, self)
						else
							self:attackAnimation(target)

							if skillData.select_type == 3 and self.casting.target then
								self:faceTo(self.casting.target)
							end
						end
					end
				end
			else
				if skillPack.multiple and self.casting.step == 5 then
					self.casting.time = fullFrameTime + skillPack.multiple.interval

					self:attackAnimation(self.casting.target, skillPack.multiple.interval)
				else
					local actionTime = 0

					if not empty(skillData.action) then
						local spineAttackTime = nil

						if self.clipType == CLIP_TYPE.SPINE then
							spineAttackTime = self:getSpineEventTime(skillData.action, "attack")
						end

						actionTime = spineAttackTime or math.floor(self:getActionTotalFrameTime(skillData.action) * 3 / 4)
					end

					self.casting.time = fullFrameTime + actionTime

					self:attackAnimation(self.casting.target)
				end

				self.casting.step = 2
			end
		elseif self.casting.step == 2 then
			if skillData.is_jump ~= 1 then
				SkillManager.trySummon(SkillManager.SUMMON_TIME.CAST, skillData, self, self)
			end

			if self.casting and self.casting.warnAssets then
				SkillManager.removeWarning(self.casting.warnAssets)

				self.casting.warnAssets = nil
			end

			self:castDo(skillData, nil, self.casting.skillPack)

			local isMultiple = false

			if skillPack.multiple and skillPack.multiple.leftTimes > 0 then
				isMultiple = true

				if skillData.multiple_other == 1 or skillData.multiple_other == 2 then
					local already = nil

					if skillData.multiple_other == 1 then
						already = skillPack.already
					end

					local lockTargets = nil

					if self:getState("lock_hate") and self.battleData.target then
						lockTargets = {
							self.battleData.target
						}
					end

					local isReady, _target = SkillManager.findAutoSkillTarget(self, skillData, self.battleData.target, already, lockTargets)

					if isReady and _target then
						self.battleData.target = _target
						self.casting.target = _target
					else
						isMultiple = false
						skillPack.multiple.leftTimes = 0
					end
				end
			end

			if isMultiple then
				self.casting.step = 5
				skillPack.multiple.leftTimes = skillPack.multiple.leftTimes - 1
			else
				self.casting.step = 3
				local animTime = self:getActionTotalFrameTime(skillData.action)

				if skillData.is_jump == 1 then
					animTime = animTime / 2
				else
					animTime = animTime / 4
				end

				self.casting.time = fullFrameTime + math.floor(animTime) + skillData.post_time
			end

			if skillData.type == 1 then
				local stacks = {
					self.autoSkills,
					self.manualSkills
				}

				for i, stack in ipairs(stacks) do
					for j, skillPack in ipairs(stack) do
						self:addPowerTimes(skillPack, 2)
					end
				end
			end

			if self.casting.step == 3 then
				self:onCastOver()
			end
		elseif self.casting.step == 3 then
			self.casting.step = 4

			if skillData.friend ~= 0 and skillData.friend ~= 3 then
				self:clearTarget()
			end

			if skillData.terminate == 1 then
				local dmgValue = self.battleData.hp
				self.battleData.hp = 0

				WarMachine.onHpChange(self, self.battleData.hp, -dmgValue)
				self:die()
			elseif skillData.type == 1 then
				self:addFleeState(2)
			elseif skillData.type == 2 then
				self:addFleeState(3)
			end
		end
	end
end

function CombatUnit:onCastOver()
end

function CombatUnit:inCastingStep()
	return self.casting and self.casting.step and (self.casting.step == 5 or self.casting.step >= 1 and self.casting.step <= 3)
end

function CombatUnit:castDo(skillData, _castPosition, skillPack, _target, _caster, isBuffTrigger, originalAttrs, isOriginTrigger)
	local trueTarget = _target or self.casting.target

	if not trueTarget then
		return
	end

	if skillData.select_type == 1 and skillPack and trueTarget.id then
		skillPack.already[trueTarget.id] = true
	end

	local affectPack = nil

	if isOriginTrigger and originalAttrs then
		affectPack = SkillManager.cast(skillData, skillPack, originalAttrs, trueTarget, _caster or self, _castPosition)
	else
		affectPack = SkillManager.cast(skillData, skillPack, self.attrs, trueTarget, _caster or self, _castPosition)
	end

	local combineList = SheetUtil.getColumnValueList(skillData, "combine_")

	for i, skillID in ipairs(combineList) do
		local skillPack = self:getSkillPack(skillID)
		skillPack = skillPack or self:addSkill(skillID)

		self:castDo(skillPack.data, _castPosition, skillPack, _target, _caster)
	end

	local index = 1

	while not empty(skillData["buff_clear_" .. index]) and not empty(skillData["buff_clear_prob_" .. index]) do
		if skillData["buff_clear_target_" .. index] == 2 and self.warRandom:next() < skillData["buff_clear_prob_" .. index] then
			local buffID = skillData["buff_clear_" .. index]

			self:clearBuffTo(buffID)
		end

		index = index + 1
	end

	local index = 1

	while not empty(skillData["buff_" .. index]) and not empty(skillData["buff_prob_" .. index]) and not empty(skillData["buff_time_" .. index]) do
		if skillData["buff_target_" .. index] == 2 and skillData["buff_time_" .. index] ~= "jump" and self.warRandom:next() < skillData["buff_prob_" .. index] then
			local buffTime = skillData["buff_time_" .. index]
			local dustSkill = self:getDustSkill(skillData.base_id)

			if dustSkill and dustSkill.skill_buff_exist_1 then
				buffTime = math.max(0, buffTime + dustSkill.skill_buff_exist_1)
			end

			self:addBuff(skillData["buff_" .. index], buffTime, affectPack.attackPack, self.id, nil, originalAttrs)
		end

		index = index + 1
	end

	local angle = 0

	if self.casting.target and self.casting.target.x and self.casting.target.y then
		angle = self:getAngle(self.casting.target)
	end

	local effectGen = self:getEffectGen()

	if effectGen then
		effectGen:castEffect(skillData.cast_effect, self, nil, angle, self)
	end

	if not isBuffTrigger then
		if skillData.type == 1 then
			self:castBuffTrigger(BUFF_TIMING.ATTACK_TRIGGER, affectPack.attackPack)
		elseif skillData.type == 2 then
			self:castBuffTrigger(BUFF_TIMING.SKILL_TRIGGER, affectPack.attackPack)
		end
	end

	if not empty(skillData.trigger_skill) then
		local _skillPack = self:getSkillPack(skillData.trigger_skill)
		_skillPack = _skillPack or self:addSkill(skillData.trigger_skill, false)

		if _skillPack then
			if skillPack and skillData.trigger_other == 1 then
				_skillPack.already = skillPack.already
			else
				_skillPack.already = {}

				if trueTarget.id then
					_skillPack.already[trueTarget.id] = true
				end
			end

			local currentCaster = self

			if trueTarget.type and trueTarget.battleData then
				currentCaster = trueTarget
			end

			local tempOwner = self.tempOwner or self
			local caster = {
				isTemp = true,
				tempOwner = tempOwner,
				type = self.type,
				data = self.data,
				info = self.info,
				id = self.id,
				level = self.level,
				battleData = self.battleData,
				attrs = self.attrs,
				x = currentCaster.x,
				y = currentCaster.y,
				z = currentCaster.z,
				width = currentCaster.width,
				height = currentCaster.height,
				tile = currentCaster.tile,
				map = currentCaster.map,
				random = self.random,
				warRandom = self.warRandom,
				checkPathLimited = function (self, tag)
					return currentCaster:checkPathLimited(tag)
				end,
				checkMeleeAndRangedTile = function (self, skillRange, unit, isJump)
					return currentCaster:checkMeleeAndRangedTile(skillRange, unit, isJump)
				end,
				getEffectGen = function (self)
					if currentCaster.getEffectGen then
						return currentCaster:getEffectGen()
					end
				end,
				getCenter = function (self, obj)
					return currentCaster:getCenter(obj)
				end,
				getHpMax = function (self)
					return tempOwner:getHpMax()
				end,
				getDustSkill = function (self, skillBaseID)
					return tempOwner:getDustSkill(skillBaseID)
				end,
				getDustSkillAttrs = function (self, skillBaseID)
					return tempOwner:getDustSkillAttrs(skillBaseID)
				end
			}
			local multipleTimes = 1
			local multipleInterval = 1

			if skillData.no_multiple_trigger ~= 1 and not empty(skillData.multiple) then
				local multipleArr = string.split(skillData.multiple, ",")
				multipleTimes = SheetUtil.getNumber(multipleArr[1], self.warRandom)

				if multipleArr[2] then
					multipleInterval = SheetUtil.getNumber(multipleArr[2], self.warRandom) or 0
				end
			end

			for i = 1, multipleTimes do
				local lockTargets = nil

				if self:getState("lock_hate") and self.battleData.target then
					lockTargets = {
						self.battleData.target
					}
				end

				local isReady, newTarget = SkillManager.findAutoSkillTarget(caster, _skillPack.data, trueTarget, _skillPack.already, lockTargets)

				if newTarget then
					if newTarget.id then
						_skillPack.already[newTarget.id] = true
					end

					local function castTrigger()
						self:castDo(_skillPack.data, trueTarget, _skillPack, newTarget, caster)
					end

					local trigger_delay = skillData.trigger_delay

					if skillData.is_fly == 1 and not empty(skillData.fly_effect) then
						trigger_delay = trigger_delay + UnitEffect.getMissleTime(skillData.fly_effect, _caster or self, trueTarget)
					end

					trigger_delay = trigger_delay + multipleInterval * (i - 1)

					if trigger_delay > 0 then
						MapFrameManager.setTimeout(castTrigger, trigger_delay, self)
					else
						castTrigger()
					end
				end
			end
		end
	end
end

function CombatUnit:attackAnimation(unit, limitedActionTime)
	if not global.fake_battle and not self.map.isBattle then
		self:setAction("idle")

		return
	end

	if self.casting.skillPack then
		local skillData = self.casting.skillData

		self:faceTo(unit)

		local startFrame = 1

		if limitedActionTime then
			startFrame = math.floor(self:getFrameCount(skillData.action) - self:getFrameByFrameTime(skillData.action, limitedActionTime))
			startFrame = math.max(startFrame, 1)
		end

		self:setAction(skillData.action, 1, function ()
			self:setAction("idle")
		end, startFrame)

		local effectGen = self:getEffectGen()

		if effectGen then
			effectGen:castEffect(skillData.action_effect, self, nil, , self)
		end
	end
end

function CombatUnit:flyWord(text, style, zorder, lastingTime)
	if not self.flyWordStack then
		self.flyWordStack = {}
	end

	text = tostring(text)
	zorder = zorder or 0
	lastingTime = lastingTime or 120
	local len = utf8.len(text)
	local container = display.newNode()

	container:setCascadeOpacityEnabled(true)

	local totalWidth = 0
	local _style = {
		outline = 1,
		size = 16
	}

	if style then
		for k, v in pairs(style) do
			_style[k] = v
		end
	end

	local labelArr = {}
	local widthArr = {}

	for i = 1, len do
		local text = utf8.sub(text, i, i)
		local label, labelWidth, labelHeigth = UIManager.createLabel(totalWidth, 0, 0, 0, text, _style)

		label:setAnchorPoint(cc.p(0, 0))
		label:setCascadeOpacityEnabled(true)

		totalWidth = totalWidth + labelWidth

		container:addChild(label)
		table.insert(labelArr, label)
		table.insert(widthArr, label)
	end

	local delaySpace = 0.05

	for i, label in ipairs(labelArr) do
		label:setPositionX(label:getPositionX() - totalWidth / 2)
		label:setOpacity(0)
		transition.moveTo(label, {
			y = 20,
			easing = "backOut",
			time = 0.2,
			delay = delaySpace * (i - 1)
		})
		transition.fadeTo(label, {
			opacity = 255,
			easing = "sineOut",
			time = 0.2,
			delay = delaySpace * (i - 1)
		})
	end

	local flyObj = {
		label = container,
		zorder = zorder
	}

	table.insert(self.flyWordStack, flyObj)
	self.map.hudHighLayer:addChild(container)
	Looper.setTimeout(function ()
		transition.fadeTo(container, {
			easing = "sineOut",
			opacity = 0,
			time = 0.3,
			onComplete = function ()
				if self.flyWordStack then
					for i, v in ipairs(self.flyWordStack) do
						if v == flyObj then
							table.remove(self.flyWordStack, i)

							break
						end
					end
				end

				container:removeSelf()
			end
		})
	end, lastingTime, self)
end

function CombatUnit:hpResume()
	if self.attrs.hp_resume ~= 0 then
		local fullFrameTime = WarMachine.getFrame()
		local hp_resume_interval = CsvParser.getCsvData("config", "hp_resume_interval").value

		if not self.hpResumeFrame or hp_resume_interval < fullFrameTime - self.hpResumeFrame then
			if self.hpResumeFrame then
				self.hpResumeFrame = self.hpResumeFrame + hp_resume_interval
			else
				self.hpResumeFrame = fullFrameTime
			end

			local hpUp = math.max(0, self.attrs.hp_resume * (100 + self.attrs.heal_dmgadd) / 100)
			hpUp = math.ceil(hpUp)
			self.battleData.hp = math.min(self.battleData.hp + hpUp, self:getHpMax())

			WarMachine.onHpChange(self, self.battleData.hp, hpUp)
			self:jumpDmg(hpUp, "font_heal_", 0)
		end
	end
end

function CombatUnit:getShield()
	local buffTypeArr = self.buffStackMap[BUFF_TYPE.NORMAL]
	local shield = 0
	local shieldTotal = 0

	for i, obj in ipairs(buffTypeArr) do
		if obj.shield then
			shield = shield + obj.shield
			shieldTotal = shieldTotal + obj.shieldTotal
		end
	end

	if DEV_MODE then
		local buffTypeArr = self.buffStackMap[BUFF_TYPE.TEST]

		for i, obj in ipairs(buffTypeArr) do
			if obj.shield then
				shield = shield + obj.shield
				shieldTotal = shieldTotal + obj.shieldTotal
			end
		end
	end

	return shield, shieldTotal
end

function CombatUnit:getHpMax()
	local hpMax = self.attrs.hp

	if self.type == "hero" then
		hpMax = math.floor(hpMax * (1 - InfoDungeon.getHeroHPLose(self.info.id) / 100))
	end

	return hpMax
end

function CombatUnit:jumpDmg(fontText, fontFamily, fontZ, lastingTime, yOffset, noRandomPosition, holding, jumpHeight)
	local isShowDmg = Cookie.get("isShowDmg") or 1

	if isShowDmg == 1 then
		self:jumpWord(fontText, fontFamily, fontZ, lastingTime, yOffset, noRandomPosition, holding, jumpHeight)
	end
end

function CombatUnit:beDamage(attackPack, customDmgRatio)
	if not WarMachine.on then
		return 0, 0
	end

	if self.battleData.die then
		return 0, 0
	end

	if self.godTime and WarMachine.getFrame() <= self.godTime then
		return 0, 0
	end

	local preHP = self.battleData.hp
	local skillData = attackPack.skillData
	local monsterClass = nil

	if self.type == "monster" then
		monsterClass = self.data.class
	end

	local index = 1

	while not empty(skillData["buff_clear_" .. index]) and not empty(skillData["buff_clear_prob_" .. index]) do
		if skillData["buff_clear_target_" .. index] == 3 and self.warRandom:next() < skillData["buff_clear_prob_" .. index] then
			local buffID = skillData["buff_clear_" .. index]

			self:clearBuffTo(buffID)
		end

		index = index + 1
	end

	if not empty(skillData.debuff_clear_prob) and self.warRandom:next() < skillData.debuff_clear_prob then
		self:clearDebuff()
	end

	local index = 1

	while not empty(skillData["buff_" .. index]) and not empty(skillData["buff_prob_" .. index]) and not empty(skillData["buff_time_" .. index]) do
		if skillData["buff_target_" .. index] == 3 and self.warRandom:next() < skillData["buff_prob_" .. index] then
			local buffID = skillData["buff_" .. index]
			local buffTime = skillData["buff_time_" .. index]
			buffTime = self:calculateBuffResist(buffID, buffTime)

			if attackPack.caster and attackPack.caster.getDustSkill then
				local dustSkill = attackPack.caster:getDustSkill(skillData.base_id)

				if dustSkill and dustSkill.skill_buff_exist_2 then
					buffTime = math.max(0, buffTime + dustSkill.skill_buff_exist_2)
				end
			end

			if buffTime > 0 then
				local casterID = nil

				if attackPack.caster then
					casterID = attackPack.caster.id
				end

				self:addBuff(buffID, buffTime, attackPack, casterID)
			end
		end

		index = index + 1
	end

	local dmgValue, healValue, breakValue, isCritical, isDodge, isBlock, bestElement, bloodDrainValue, manaDrainValue = DamageRule.getDamageValue(attackPack, self.attrs, self.level, monsterClass, self.battleData, self)

	if customDmgRatio then
		dmgValue = math.floor(dmgValue * customDmgRatio)
	end

	WarMachine.log("id:" .. (self.info.id or self.data.id) .. " dmgValue:" .. dmgValue .. " healValue:" .. healValue)

	local hasShield = false
	local shieldChanged = false
	local buffTypeArr = self.buffStackMap[BUFF_TYPE.NORMAL]
	local buffToRemoveStack = {}
	local shieldLeft = 0
	local shieldDmgRatio = 1

	if attackPack and attackPack.attrs then
		shieldDmgRatio = 1 + attackPack.attrs.shield_dmgadd / 100
	end

	local pierceRatio = 0

	if not empty(skillData.pierce_ratio) then
		pierceRatio = skillData.pierce_ratio
	end

	local dmgValueShield = math.ceil(dmgValue * (1 - pierceRatio))

	for i, obj in ipairs(buffTypeArr) do
		if obj.shield then
			if obj.shield > 0 then
				hasShield = true
			end

			if obj.shield > 0 and breakValue > 0 then
				local shieldDmg = math.min(obj.shield, breakValue)
				obj.shield = obj.shield - shieldDmg
				breakValue = breakValue - shieldDmg
				shieldChanged = true
			end

			if obj.shield > 0 and dmgValueShield > 0 then
				if pierceRatio > 0 then
					-- Nothing
				end

				local shieldDmg = math.min(obj.shield, math.floor(dmgValueShield * shieldDmgRatio))
				obj.shield = obj.shield - shieldDmg
				dmgValueShield = dmgValueShield - math.ceil(shieldDmg / shieldDmgRatio)
				shieldChanged = true
			end

			if obj.shield <= 0 then
				table.insert(buffToRemoveStack, obj)
			end

			shieldLeft = shieldLeft + obj.shield
		end
	end

	for i, obj in ipairs(buffToRemoveStack) do
		self:removeBuff(obj)
		self:onRemoveBuff(obj)
	end

	if isDodge then
		self:jumpWord("m", "font_misc_", 0)
	end

	if self.attrs.hit_hp then
		dmgValue = math.min(dmgValue, 1)
	end

	if hasShield then
		dmgValue = math.ceil(dmgValue * pierceRatio)
	end

	if isINF(dmgValue) then
		dmgValue = 0
	end

	if dmgValue > 0 then
		if attackPack.caster and attackPack.caster.battleData and attackPack.caster.battleData.camp == 1 then
			if attackPack.caster.type == "hero" or attackPack.caster.type == "hero_copy" then
				DmgCount.addHeroDmg(attackPack.caster.info.id, dmgValue, skillData.type ~= 1)
			elseif attackPack.caster.type == "pet" then
				DmgCount.addPetDmg(attackPack.caster.info.id, dmgValue, skillData.type ~= 1)
			elseif attackPack.caster.type == "summoned" then
				if attackPack.caster.summonerType == "hero" or attackPack.caster.summonerType == "hero_copy" or attackPack.caster.summonerType == "pet" then
					local caster = attackPack.caster

					while caster.summoner do
						caster = caster.summoner
					end

					if caster.type == "hero" or caster.type == "hero_copy" then
						DmgCount.addHeroDmg(caster.info.id, dmgValue, true)
					elseif caster.type == "pet" then
						DmgCount.addPetDmg(caster.info.id, dmgValue, true)
					end
				end
			elseif attackPack.caster.type == "modao" then
				DmgCount.addModaoDmg(dmgValue)
			end
		end

		if self.isUseHate then
			local caster = attackPack.caster

			if caster and caster.battleData and not caster.battleData.die then
				self:addHate(attackPack.caster, dmgValue)
			end
		end

		self:hurtAnimation()

		if isCritical then
			self:dispatchEvent({
				name = "hurt",
				isCritical = isCritical
			})
			MapEffect.quake(3)
		end

		if isBlock and not global.noEffect then
			local effect = self:addEffect(MiscConfig.block_effect)
			local caster = attackPack.caster

			if caster and caster.x and caster.y and caster.z then
				effect:setRotateByPosition(self.map.topType == Map.TOP_90, caster.x, caster.y, caster.z, self.x, self.y, self.z)
			end
		end

		local effectGen = self:getEffectGen()

		if effectGen then
			effectGen:castEffect(skillData.hurt_effect, self, nil, , attackPack.caster)
		end

		if skillData.type == 1 and bestElement and not global.noEffect then
			local elementEffect = CombatAttr.getElementEffect(bestElement)

			if not empty(elementEffect) then
				self:addEffect(elementEffect)
			end
		end

		self:damageAddon(dmgValue, attackPack)

		local fontFamily = "font_dmg_"
		local fontZ = 0

		if isCritical then
			fontFamily = "font_dmg_s_"
			fontZ = 100
		end

		self:jumpDmg(dmgValue, fontFamily, fontZ)
	end

	if self.attrs.no_heal then
		healValue = 0
	end

	if healValue > 0 then
		self:jumpDmg(healValue, "font_heal_", 0)

		local caster = attackPack.caster

		if caster.type == "hero" or caster.type == "hero_copy" then
			DmgCount.addHeroHeal(caster.info.id, healValue)
		end

		local effectGen = self:getEffectGen()

		if effectGen then
			effectGen:castEffect(skillData.hurt_effect, self, nil, , attackPack.caster)
		end
	end

	if bloodDrainValue > 0 then
		local caster = attackPack.caster

		if caster.battleData then
			caster.battleData.hp = math.min(caster.battleData.hp + bloodDrainValue, caster:getHpMax())

			WarMachine.onHpChange(caster, caster.battleData.hp, bloodDrainValue)

			if caster.jumpDmg then
				caster:jumpDmg(bloodDrainValue, "font_heal_", 0)
			end
		end
	end

	self:dotFin(skillData)

	if manaDrainValue > 0 then
		InfoModao.addMp(manaDrainValue)

		local caster = attackPack.caster

		if caster.battleData and caster.jumpDmg then
			caster:jumpDmg(manaDrainValue, "font_mana_", 0)
		end
	end

	if self.ai and self.ai.onBeDamage then
		self.ai.onBeDamage(self, dmgValue - healValue)
	end

	if not empty(skillData.damage_trigger) and skillData.damage_trigger_after ~= 1 then
		local skillID = skillData.damage_trigger
		local caster = attackPack.caster

		if caster.battleData then
			local checkCond = false

			if skillData.damage_trigger_cond == DAMAGE_TRIGGER.CRITICAL then
				checkCond = isCritical
			elseif skillData.damage_trigger_cond == DAMAGE_TRIGGER.HP_LOWER then
				local currentPercent = self.battleData.hp / self.attrs.hp * 100
				checkCond = currentPercent < skillData.damage_trigger_value
			elseif skillData.damage_trigger_cond == DAMAGE_TRIGGER.HP_HIGHER then
				local currentPercent = self.battleData.hp / self.attrs.hp * 100
				checkCond = skillData.damage_trigger_value < currentPercent
			elseif skillData.damage_trigger_cond == DAMAGE_TRIGGER.HAS_BUFF then
				checkCond = self:hasBuff(skillData.damage_trigger_value)
			elseif skillData.damage_trigger_cond == DAMAGE_TRIGGER.NONE_BUFF then
				checkCond = not self:hasBuff(skillData.damage_trigger_value)
			else
				checkCond = true
			end

			if checkCond and caster.getSkillPack then
				local skillData = CsvParser.getCsvData("skill", skillID)
				local skillPack = caster:getSkillPack(skillID)
				skillPack = skillPack or caster:addSkill(skillID, false)

				caster:castDo(skillData, nil, skillPack, self)
			end
		end
	end

	if DEV_MODE then
		if not global.safe and (not global.god or self.battleData.camp == 2) then
			self.battleData.hp = math.min(self.battleData.hp - dmgValue + healValue, self:getHpMax())

			WarMachine.onHpChange(self, self.battleData.hp, healValue - dmgValue)

			if global.super then
				if self.type == "monster" or self.type == "summoned" and self.summonerType == "monster" then
					self.battleData.hp = 0
				end
			elseif global.weak and self.type == "hero" then
				self.battleData.hp = 0
			end
		end
	else
		self.battleData.hp = math.min(self.battleData.hp - dmgValue + healValue, self:getHpMax())

		WarMachine.onHpChange(self, self.battleData.hp, healValue - dmgValue)
	end

	if (self.undeadable or self:checkBuffNoDie()) and self.battleData.hp < 1 then
		local preHp = self.battleData.hp
		self.battleData.hp = math.max(self.battleData.hp, 1)

		WarMachine.onHpChange(self, self.battleData.hp, self.battleData.hp - preHp)
	end

	self:hudSetHP(self.battleData.hp / self.attrs.hp)
	self:dispatchEvent({
		name = "hp_changed"
	})

	if shieldChanged then
		self:onShieldChanged()

		if shieldLeft <= 0 then
			self:castBuffTrigger(BUFF_TIMING.SHIELD_BREAK, attackPack)

			if not empty(MiscConfig.shield_broken_effect) then
				local effectGen = self:getEffectGen()

				if effectGen then
					effectGen:castEffect(MiscConfig.shield_broken_effect, self, nil, , attackPack.caster)
				end
			end
		elseif not empty(MiscConfig.shield_hit_effect) then
			local effectGen = self:getEffectGen()

			if effectGen then
				effectGen:castEffect(MiscConfig.shield_hit_effect, self, nil, , attackPack.caster)
			end
		end
	end

	local index = 1

	while not empty(skillData["buff_clear_" .. index]) and not empty(skillData["buff_clear_prob_" .. index]) do
		if skillData["buff_clear_target_" .. index] == 1 and self.warRandom:next() < skillData["buff_clear_prob_" .. index] then
			local buffID = skillData["buff_clear_" .. index]

			self:clearBuffTo(buffID)
		end

		index = index + 1
	end

	local index = 1

	while not empty(skillData["buff_" .. index]) and not empty(skillData["buff_prob_" .. index]) and not empty(skillData["buff_time_" .. index]) do
		if skillData["buff_target_" .. index] == 1 then
			if self.warRandom:next() < skillData["buff_prob_" .. index] then
				local buffID = skillData["buff_" .. index]
				local buffTime = skillData["buff_time_" .. index]
				buffTime = self:calculateBuffResist(buffID, buffTime)

				if attackPack.caster and attackPack.caster.getDustSkill then
					local dustSkill = attackPack.caster:getDustSkill(skillData.base_id)

					if dustSkill and dustSkill.skill_buff_exist_2 then
						buffTime = math.max(0, buffTime + dustSkill.skill_buff_exist_2)
					end
				end

				if buffTime > 0 then
					local casterID = nil

					if attackPack.caster then
						casterID = attackPack.caster.id
					end

					self:addBuff(buffID, buffTime, attackPack, casterID)
				end
			end
		elseif skillData["buff_target_" .. index] == 4 then
			local caster = attackPack.caster

			if caster and caster.battleData and not caster.battleData.die and caster.warRandom:next() < skillData["buff_prob_" .. index] then
				local buffTime = skillData["buff_time_" .. index]

				if attackPack.caster and attackPack.caster.getDustSkill then
					local dustSkill = attackPack.caster:getDustSkill(skillData.base_id)

					if dustSkill and dustSkill.skill_buff_exist_1 then
						buffTime = math.max(0, buffTime + dustSkill.skill_buff_exist_1)
					end
				end

				caster:addBuff(skillData["buff_" .. index], buffTime, attackPack, caster.id)
			end
		end

		index = index + 1
	end

	if attackPack.skillPack then
		local stacks = {
			self.autoSkills,
			self.manualSkills
		}

		for i, stack in ipairs(stacks) do
			for j, skillPack in ipairs(stack) do
				self:addPowerTimes(skillPack, 3)
			end
		end
	end

	if not empty(skillData.damage_trigger) and skillData.damage_trigger_after == 1 then
		local skillID = skillData.damage_trigger
		local caster = attackPack.caster

		if caster.battleData then
			local checkCond = false

			if skillData.damage_trigger_cond == DAMAGE_TRIGGER.CRITICAL then
				checkCond = isCritical
			elseif skillData.damage_trigger_cond == DAMAGE_TRIGGER.HP_LOWER then
				local currentPercent = self.battleData.hp / self.attrs.hp * 100
				checkCond = currentPercent < skillData.damage_trigger_value
			elseif skillData.damage_trigger_cond == DAMAGE_TRIGGER.HP_HIGHER then
				local currentPercent = self.battleData.hp / self.attrs.hp * 100
				checkCond = skillData.damage_trigger_value < currentPercent
			elseif skillData.damage_trigger_cond == DAMAGE_TRIGGER.HAS_BUFF then
				checkCond = self:hasBuff(skillData.damage_trigger_value)
			elseif skillData.damage_trigger_cond == DAMAGE_TRIGGER.NONE_BUFF then
				checkCond = not self:hasBuff(skillData.damage_trigger_value)
			else
				checkCond = true
			end

			if checkCond and caster.getSkillPack then
				local skillData = CsvParser.getCsvData("skill", skillID)
				local skillPack = caster:getSkillPack(skillID)
				skillPack = skillPack or caster:addSkill(skillID, false)

				caster:castDo(skillData, nil, skillPack, self)
			end
		end
	end

	if isDodge then
		self:castBuffTrigger(BUFF_TIMING.DODGE_TRIGGER, attackPack)
	end

	if not hasShield then
		if isCritical then
			self:castBuffTrigger(BUFF_TIMING.BE_CRITICAL_TRIGGER, attackPack)

			if attackPack.caster.castBuffTrigger then
				attackPack.caster:castBuffTrigger(BUFF_TIMING.CRITICAL_TRIGGER, attackPack)
			end
		end

		if dmgValue > 0 then
			local caster = attackPack.caster

			self:castBuffTrigger(BUFF_TIMING.BEHURT_TRIGGER, attackPack, caster)

			if caster.battleData and caster.castBuffTrigger then
				caster:castBuffTrigger(BUFF_TIMING.HURT_TRIGGER, attackPack, self)
			end
		end
	end

	if self.battleData.hp <= 0 then
		local caster = attackPack.caster

		if dmgValue > 0 and caster.battleData and caster.castBuffTrigger then
			caster:castBuffTrigger(BUFF_TIMING.KILL_TRIGGER, attackPack)
		end

		if caster.battleData and (not empty(caster.attrs.heal_kill) or not empty(caster.attrs.heal_kill_pro)) then
			local hpRecover = (caster.attrs.heal_kill + caster.attrs.hp * caster.attrs.heal_kill_pro / 100) * (1 + caster.attrs.getheal_dmgadd / 100)
			hpRecover = math.max(0, hpRecover)
			hpRecover = math.ceil(hpRecover)

			if hpRecover > 0 and not caster.battleData.die and caster.battleData.hp > 0 then
				caster.battleData.hp = math.min(caster.battleData.hp + hpRecover, caster:getHpMax())

				WarMachine.onHpChange(caster, caster.battleData.hp, hpRecover)

				if caster.jumpDmg then
					caster:jumpDmg(hpRecover, "font_heal_", 0)
				end
			end
		end

		self:onDieTrigger(1, attackPack)
	elseif self.battleData and self.castBuffSkill then
		local fullFrameTime = WarMachine.getFrame()
		local currentPercent = math.floor(self.battleData.hp / self.attrs.hp * 100)
		local buffs = self:triggerBuff(BUFF_TIMING.HP_LOWER_REPLACE, attackPack)

		if buffs and #buffs > 0 then
			local newBuffs = {}

			for i, v in ipairs(buffs) do
				local buffPack = v.pack

				if not buffPack.cd or buffPack.cd <= fullFrameTime then
					local buffCSV = buffPack.data

					if currentPercent < buffCSV.trigger_value_1 then
						table.insert(newBuffs, v)
					end
				end
			end

			if #newBuffs > 0 then
				self:castBuffSkill(newBuffs, attackPack)
			end
		end

		local buffs = self:triggerBuff(BUFF_TIMING.HP_HIGHER_REPLACE, attackPack)

		if buffs and #buffs > 0 then
			local newBuffs = {}

			for i, v in ipairs(buffs) do
				local buffPack = v.pack

				if not buffPack.cd or buffPack.cd <= fullFrameTime then
					local buffCSV = buffPack.data

					if buffCSV.trigger_value_1 < currentPercent then
						table.insert(newBuffs, v)
					end
				end
			end

			if #newBuffs > 0 then
				self:castBuffSkill(newBuffs, attackPack)
			end
		end
	end

	if dmgValue > 0 and skillData.can_dmgref == 1 and self.attrs.dmgref_hit > 0 and WarMachine.random:next() < self.attrs.dmgref_hit / 100 then
		local caster = attackPack.caster

		if caster.battleData and not caster.noEntity then
			local dmgRatio = WarMachine.dmg_ratio or 1
			local drValue = self.attrs.dmgref_val * dmgRatio + dmgValue * self.attrs.dmgref_pro / 100
			drValue = math.ceil(drValue)

			if drValue > 0 and caster.battleData.hp and caster.battleData.hp > 0 and not global.safe then
				caster.battleData.hp = caster.battleData.hp - drValue

				if caster.battleData.hp <= 0 and caster.onDieTrigger then
					caster:onDieTrigger(2)
				end

				if self.type == "hero" or self.type == "hero_copy" then
					DmgCount.addHeroDmg(self.info.id, drValue, skillData.type ~= 1)
				elseif self.type == "pet" then
					DmgCount.addPetDmg(self.info.id, drValue, skillData.type ~= 1)
				end

				WarMachine.onHpChange(caster, caster.battleData.hp, -drValue)

				if caster.damageAddon then
					caster:damageAddon(drValue, attackPack)
				end

				if caster.jumpDmg then
					caster:jumpDmg(drValue, "font_dmg_")
				end

				if caster.hudSetHP then
					caster:hudSetHP(caster.battleData.hp / caster.attrs.hp)
				end

				if caster.dispatchEvent then
					caster:dispatchEvent({
						name = "hp_changed"
					})
				end
			end
		end
	end

	return dmgValue, healValue
end

function CombatUnit:onDieTrigger(fromCode, attackPack)
	if self.battleData and self.castBuffTrigger then
		print("$$$ SELF_DIE_TRIGGER", fromCode)
		self:castBuffTrigger(BUFF_TIMING.SELF_DIE_TRIGGER, attackPack)
	end
end

function CombatUnit:calculateBuffResist(id, time)
	local buffResistArray = SheetUtil.getColumnList(self.data, {
		"buff_resist_",
		"buff_resist_ratio_"
	}, {
		"id",
		"ratio"
	})

	for i, v in ipairs(buffResistArray) do
		if v.id == id then
			return time * (1 - v.ratio)
		end
	end

	return time
end

function CombatUnit:addShrineBuff(id, seed)
	return self:_addBuff(BUFF_TYPE.SHRINE, id, nil, , seed)
end

function CombatUnit:addCardBuff(id, seed)
	return self:_addBuff(BUFF_TYPE.CARD, id, nil, , seed)
end

function CombatUnit:addToughness(buffID, time)
	if not self.toughnessMap[buffID] then
		self.toughnessMap[buffID] = {}
	end

	local endTime = WarMachine.getFrame() + time

	table.insert(self.toughnessMap[buffID], endTime)
end

function CombatUnit:updateToughness()
	local fullFrameTime = WarMachine.getFrame()

	for buffID, arr in pairs(self.toughnessMap) do
		local index = 1

		while arr[index] do
			if arr[index] < fullFrameTime then
				table.remove(arr, index)
			else
				index = index + 1
			end
		end
	end
end

function CombatUnit:getToughness(buffID)
	local times = 0

	if self.toughnessMap[buffID] then
		times = #self.toughnessMap[buffID]
	end

	return times
end

function CombatUnit:hasBuff(base_id)
	local buffStack = self.buffStackMap[BUFF_TYPE.NORMAL]

	for i, v in ipairs(buffStack) do
		if v.id == base_id then
			return true
		end
	end

	return false
end

function CombatUnit:addBuff(id, time, attackPack, casterID, force, originalAttrs)
	if not force and not WarMachine.on then
		return
	end

	local buffData = CsvParser.getCsvData("buff", id)

	if buffData.is_tough_add == 1 then
		local originalTime = time
		local isFixTough = InfoDungeon.isFixTough()

		print("------ isFixTough", tostring(isFixTough))

		if DEV_MODE then
			print("------ 是否韧性修复", tostring(isFixTough))
		end

		if isFixTough then
			local ratio = 1

			if self.attrs.toughness == 0 then
				ratio = math.max(0, 1 - self.attrs.debuff_res / 100)
			else
				ratio = math.max(0, 1 - self.attrs.debuff_res / 100) * math.max(0, 1 - self.attrs.toughness * self:getToughness(id) / 100)
			end

			time = time * ratio

			if DEV_MODE and self.type == "monster" then
				print("------韧性计算（新） debuff_res：" .. self.attrs.debuff_res .. " toughness：" .. self.attrs.toughness .. "," .. self:getToughness(id) .. " 状态时间比例：" .. ratio .. " 时间：" .. time .. " buff：" .. buffData.name)
			end

			time = math.max(time, 0)
		else
			local ratio = 1

			if self.attrs.debuff_res ~= 0 then
				if self.attrs.toughness == 0 then
					ratio = math.max(0, 1 - self.attrs.debuff_res / 100)
				else
					ratio = math.max(0, 1 - self.attrs.debuff_res / 100) * math.max(0, 1 - self.attrs.toughness * self:getToughness(id) / 100)
				end
			end

			time = time * ratio

			if DEV_MODE and self.type == "monster" then
				print("------韧性计算（老） debuff_res：" .. self.attrs.debuff_res .. " toughness：" .. self.attrs.toughness .. "," .. self:getToughness(id) .. " 状态时间比例：" .. ratio .. " 时间：" .. time .. " buff：" .. buffData.name)
			end

			time = math.max(time, 0)
		end

		self:addToughness(id, originalTime * self.attrs.toughness_time_ratio / 100)

		local shield = self:getShield()

		if shield > 0 then
			time = 0
		end
	end

	if not time or time > 0 then
		return self:_addBuff(BUFF_TYPE.NORMAL, id, time, attackPack, nil, casterID, originalAttrs)
	end
end

function CombatUnit:_addBuff(type, id, time, attackPack, seed, casterID, originalAttrs)
	local buffStack = self.buffStackMap[type]
	local buffData = CsvParser.getCsvData("buff", id)
	local toRemoveObj, isOverStack = nil

	if not empty(buffData.buff_stack_max) then
		if buffData.stack_type == 1 then
			local count = 0

			for i, v in ipairs(buffStack) do
				if v.id == id and v.casterID == casterID then
					toRemoveObj = toRemoveObj or v
					count = count + 1

					if buffData.buff_stack_max <= count then
						isOverStack = true

						break
					end
				end
			end
		else
			local count = 0

			for i, v in ipairs(buffStack) do
				if v.id == id then
					toRemoveObj = toRemoveObj or v
					count = count + 1

					if buffData.buff_stack_max <= count then
						isOverStack = true

						break
					end
				end
			end
		end
	end

	if isOverStack and toRemoveObj then
		self:_removeBuff(type, toRemoveObj)
	end

	local statusKey = "buff_type_" .. type .. "_status_" .. id .. "_" .. self.buffIndex
	self.buffIndex = self.buffIndex + 1

	if buffData.no_move == 1 then
		self:addState("no_move", statusKey)
		self:removeTargetTile()
		self:stop(25)

		if not self.jumpForce then
			self:stopJump()
		end

		self.battleData.battleFollowLockTime = nil
	end

	if buffData.no_attack == 1 then
		if self.casting and not self.casting.isManual then
			self:interruptSkill()
		end

		self:addState("no_attack", statusKey)
		self:removeTargetTile()
	end

	if buffData.no_skill == 1 then
		if self.casting and self.casting.isManual then
			self:interruptSkill()
		end

		self:addState("no_skill", statusKey)
		self:removeTargetTile()
	end

	if buffData.lock_hate == 1 and attackPack then
		self:addState("lock_hate", statusKey)
		self:setCurrentHate(attackPack.caster)

		self.battleData.target = attackPack.caster

		self:clearFleeMark()
	end

	if not empty(buffData.effect) then
		self:addStateEffect(buffData.effect, statusKey)
	end

	if not empty(buffData.effect_color) then
		self:addColor("buff_color_" .. id, string.split(buffData.effect_color, ","))
	end

	if not empty(buffData.start_effect) then
		local effectGen = self:getEffectGen()

		if effectGen then
			effectGen:castEffect(buffData.start_effect, self, nil, angle, self)
		end
	end

	local fullFrameTime = WarMachine.getFrame()
	local obj = {
		frame = 0,
		id = id,
		seed = seed,
		statusKey = statusKey,
		startTime = fullFrameTime,
		casterID = casterID
	}
	local shieldValue = 0

	if type == BUFF_TYPE.NORMAL or type == BUFF_TYPE.TEST then
		if not empty(buffData.shield_base) then
			shieldValue = buffData.shield_base

			print("盾值 基础", shieldValue)
		end

		if attackPack and not empty(buffData.shield_multi) then
			shieldValue = shieldValue + buffData.shield_multi * attackPack.attrs.atk

			print("盾值 攻击", buffData.shield_multi, attackPack.attrs.atk, buffData.shield_multi * attackPack.attrs.atk)
		end

		local moreList = SheetUtil.getColumnList(buffData, {
			"shield_target",
			"shield_index",
			"shield_multi"
		}, {
			"target",
			"attr",
			"multi"
		})

		for i, v in ipairs(moreList) do
			if v.target == 1 then
				shieldValue = shieldValue + v.multi * self.attrs[v.attr]

				print("盾值 目标", v.attr, v.multi, self.attrs[v.attr], v.multi * self.attrs[v.attr])
			elseif v.target == 2 then
				if originalAttrs then
					shieldValue = shieldValue + v.multi * originalAttrs[v.attr]

					print("盾值 源", v.attr, v.multi, originalAttrs[v.attr], v.multi * originalAttrs[v.attr])
				else
					print("盾值 源未找到", buffData.id, buffData.name)
				end
			elseif attackPack then
				shieldValue = shieldValue + v.multi * attackPack.attrs[v.attr]

				print("盾值 我的", v.attr, v.multi, attackPack.attrs[v.attr], v.multi * attackPack.attrs[v.attr])
			end
		end

		shieldValue = math.floor(shieldValue * (WarMachine.shield_ratio or 1))
	end

	if shieldValue > 0 then
		obj.shield = shieldValue
		obj.shieldTotal = shieldValue

		print("上盾 值：", shieldValue, " 系数：", WarMachine.shield_ratio or 1)
	end

	if time and time >= 0 then
		obj.endTime = fullFrameTime + time
	end

	if attackPack and buffData.no_ot ~= 1 then
		if buffData.origin_trigger ~= 1 then
			obj.dotPack = DamageRule.generateDotPack(attackPack.caster, attackPack.attrs, buffData)
		end
	end

	if not empty(buffData.ammo_times) then
		obj.ammo = buffData.ammo_times

		self:dispatchEvent({
			name = "buff_times_" .. buffData.id,
			times = buffData.ammo_times,
			maxTimes = buffData.ammo_times
		})
	end

	if buffData.origin_trigger == 1 and originalAttrs then
		obj.originalAttrs = originalAttrs
	elseif attackPack then
		obj.originalAttrs = attackPack.attrs
	end

	table.insert(buffStack, obj)

	if not SkillManager.isNoneAvatarBuff(buffData.id) then
		if SkillManager.isAvatarBuff(buffData.id) then
			self:refreshBuffModel()
		else
			local avatarTemp = SheetUtil.getColumnListFull(buffData, {
				"avatar_index_",
				"avatar_id_"
			}, {
				"avatar",
				"value"
			})

			if buffData.change_monster ~= "" or buffData.change_model ~= "" or #avatarTemp > 0 then
				SkillManager.markAvatarBuff(buffData.id)
				self:refreshBuffModel()
			else
				SkillManager.markNoneAvatarBuff(buffData.id)
			end
		end
	end

	if not SkillManager.isNoneAttrBuff(buffData.id) then
		local attrList = SheetUtil.getColumnList(buffData, {
			"attr_",
			"mul_value_",
			"add_value_",
			"attr_index",
			"attr_multi"
		}, {
			"attr",
			"mul",
			"add",
			"attr_index",
			"attr_multi"
		})

		if #attrList == 0 then
			SkillManager.markNoneAttrBuff(buffData.id)
		else
			self:refreshBattleData()

			if self.battleData.camp == 1 and InfoModao.checkModaoAttr(attrList) then
				InfoModao.refreshModaoData()
			end
		end
	end

	if shieldValue > 0 then
		self:onShieldChanged()
	end

	return obj
end

function CombatUnit:onRemoveBuff(obj)
	local fullFrameTime = WarMachine.getFrame()
	local buffs = self:triggerBuff(BUFF_TIMING.BUFF_OVER)

	if buffs and #buffs > 0 then
		local newBuffs = {}

		for i, v in ipairs(buffs) do
			local buffPack = v.pack

			if not buffPack.cd or buffPack.cd <= fullFrameTime then
				local buffCSV = buffPack.data
				local checkBuffID = false

				if empty(buffCSV.trigger_value_1) then
					checkBuffID = buffCSV.id
				else
					checkBuffID = buffCSV.trigger_value_1
				end

				if obj.id == checkBuffID then
					table.insert(newBuffs, v)
				end
			end
		end

		if #newBuffs > 0 then
			self:castBuffSkill(newBuffs, attackPack)
		end
	end
end

function CombatUnit:removeBuff(obj)
	self:_removeBuff(BUFF_TYPE.NORMAL, obj)
end

function CombatUnit:removeShrineBuff(obj)
	self:_removeBuff(BUFF_TYPE.SHRINE, obj)
end

function CombatUnit:removeCardBuff(obj)
	self:_removeBuff(BUFF_TYPE.CARD, obj)
end

function CombatUnit:_removeBuff(type, obj)
	local id = obj.id
	local statusKey = obj.statusKey
	local buffData = CsvParser.getCsvData("buff", id)

	if buffData.no_move == 1 then
		self:removeState("no_move", statusKey)
	end

	if buffData.no_attack == 1 then
		self:removeState("no_attack", statusKey)
	end

	if buffData.no_skill == 1 then
		self:removeState("no_skill", statusKey)
	end

	if buffData.lock_hate == 1 then
		self:removeState("lock_hate", statusKey)
		self:reorderHate()
	end

	if not empty(buffData.effect) then
		self:removeStateEffect(buffData.effect, statusKey)
	end

	if not empty(buffData.effect_color) then
		self:removeColor("buff_color_" .. id)
	end

	if not empty(buffData.over_effect) then
		local effectGen = self:getEffectGen()

		if effectGen then
			effectGen:castEffect(buffData.over_effect, self, nil, angle, self)
		end
	end

	local buffStack = self.buffStackMap[type]

	for i, v in ipairs(buffStack) do
		if obj == v then
			table.remove(buffStack, i)

			break
		end
	end

	if not SkillManager.isNoneAvatarBuff(buffData.id) then
		if SkillManager.isAvatarBuff(buffData.id) then
			self:refreshBuffModel()
		else
			local avatarTemp = SheetUtil.getColumnListFull(buffData, {
				"avatar_index_",
				"avatar_id_"
			}, {
				"avatar",
				"value"
			})

			if buffData.change_monster ~= "" or buffData.change_model ~= "" or #avatarTemp > 0 then
				SkillManager.markAvatarBuff(buffData.id)
				self:refreshBuffModel()
			else
				SkillManager.markNoneAvatarBuff(buffData.id)
			end
		end
	end

	if not SkillManager.isNoneAttrBuff(buffData.id) then
		local attrList = SheetUtil.getColumnList(buffData, {
			"attr_",
			"mul_value_",
			"add_value_",
			"attr_index",
			"attr_multi"
		}, {
			"attr",
			"mul",
			"add",
			"attr_index",
			"attr_multi"
		})

		if #attrList == 0 then
			SkillManager.markNoneAttrBuff(buffData.id)
		else
			self:refreshBattleData()

			if self.battleData.camp == 1 and InfoModao.checkModaoAttr(attrList) then
				InfoModao.refreshModaoData()
			end
		end
	end

	if obj.shield then
		self:onShieldChanged()
	end
end

function CombatUnit:clearDebuff()
	local buffStack = self.buffStackMap[BUFF_TYPE.NORMAL]
	local toRemoveArr = {}

	for i, obj in ipairs(buffStack) do
		local buffData = CsvParser.getCsvData("buff", obj.id)

		if buffData.is_helpful == 2 then
			table.insert(toRemoveArr, obj)
		end
	end

	for i, obj in ipairs(toRemoveArr) do
		self:_removeBuff(BUFF_TYPE.NORMAL, obj)
	end
end

function CombatUnit:clearBuff()
	self:_clearBuff(BUFF_TYPE.NORMAL)
end

function CombatUnit:clearBuffTo(buffID)
	local toRemoveStack = self:_clearBuffTo(BUFF_TYPE.NORMAL, buffID)

	for i, obj in ipairs(toRemoveStack) do
		self:onRemoveBuff(obj)
	end
end

function CombatUnit:clearShrineBuff()
	self:_clearBuff(BUFF_TYPE.SHRINE)
end

function CombatUnit:clearCardBuff()
	self:_clearBuff(BUFF_TYPE.CARD)
end

function CombatUnit:_clearBuff(type)
	local buffStack = self.buffStackMap[type]

	while #buffStack > 0 do
		self:_removeBuff(type, buffStack[1])
	end
end

function CombatUnit:_clearBuffTo(type, buffID)
	local buffStack = self.buffStackMap[type]
	local index = 1
	local toRemoveStack = {}

	while buffStack[index] do
		local obj = buffStack[index]

		if obj.id == buffID then
			self:_removeBuff(type, obj)
			table.insert(toRemoveStack, obj)
		else
			index = index + 1
		end
	end

	return toRemoveStack
end

function CombatUnit:updateBuff()
	local startTime = nil

	if DEV_MODE then
		startTime = Time.time()
	end

	local fullFrameTime = WarMachine.getFrame()

	for type, buffTypeArr in pairs(self.buffStackMap) do
		for i, obj in ipairs(buffTypeArr) do
			local buffData = CsvParser.getCsvData("buff", obj.id)

			if not empty(buffData.interval) then
				local intervalStart = 0

				if not empty(buffData.interval_start) then
					intervalStart = buffData.interval_start
				end

				if fullFrameTime >= obj.startTime + intervalStart then
					local preInterval = math.floor((obj.frame - obj.startTime - intervalStart) / buffData.interval)
					local curInterval = math.floor((fullFrameTime - obj.startTime - intervalStart) / buffData.interval)

					if preInterval < curInterval then
						if obj.dotPack then
							self:beDamage(obj.dotPack)
						end

						local effectGen = self:getEffectGen()

						if effectGen then
							effectGen:castEffect(buffData.hurt_effect, self, nil, , obj.dotPack and obj.dotPack.caster)
						end

						if buffData.trigger_timing == BUFF_TIMING.INTERVAL_TRIGGER then
							local countOK = true

							if not empty(buffData.trigger_count) then
								obj.triggerCount = (obj.triggerCount or 0) + 1

								if buffData.trigger_count <= obj.triggerCount then
									obj.triggerCount = 0
								else
									countOK = false
								end
							end

							if countOK then
								self:castBuffTriggerOne(obj, obj.dotPack)
							end
						end
					end

					obj.frame = fullFrameTime
				end
			end
		end

		if type == BUFF_TYPE.NORMAL then
			local toRemoveStack = {}

			for i, obj in ipairs(buffTypeArr) do
				if obj.ammo and obj.ammo <= 0 or obj.endTime and obj.endTime <= fullFrameTime then
					table.insert(toRemoveStack, obj)
				end
			end

			for i, obj in ipairs(toRemoveStack) do
				self:_removeBuff(type, obj)
				self:onRemoveBuff(obj)
			end
		end
	end

	if DEV_MODE and global.buffUsed then
		global.buffUsed = global.buffUsed + Time.time() - startTime
	end

	self:updateToughness()
end

function CombatUnit:checkBuffNoDie()
	for type, buffTypeArr in pairs(self.buffStackMap) do
		for i, obj in ipairs(buffTypeArr) do
			local buffData = CsvParser.getCsvData("buff", obj.id)

			if buffData.no_die == 1 then
				return true
			end
		end
	end
end

function CombatUnit:refreshBuffModel()
	if not self.data then
		return
	end

	local changeMonster, changeModel, avatarArr = nil

	for type, buffTypeArr in pairs(self.buffStackMap) do
		for i, obj in ipairs(buffTypeArr) do
			local buffData = CsvParser.getCsvData("buff", obj.id)

			if not empty(buffData.change_monster) then
				changeMonster = buffData.change_monster
			end

			if not empty(buffData.change_model) then
				changeModel = buffData.change_model
			end

			local avatarTemp = SheetUtil.getColumnListFull(buffData, {
				"avatar_index_",
				"avatar_id_"
			}, {
				"avatar",
				"value"
			})

			if not empty(avatarTemp) then
				avatarArr = avatarTemp
			end
		end
	end

	if self.type == "monster" then
		local idChange = nil

		if changeMonster then
			if self.data.id ~= changeMonster then
				idChange = changeMonster
			end
		elseif self.data.id ~= self.info.base_id then
			idChange = self.info.base_id
		end

		if idChange then
			self:clearBornBuff()
			self:clearSkill()
			self:setBaseID(idChange)
			self:addBornBuff()
			self:initSkills()
		end
	end

	local modelChange = nil

	if changeModel then
		if self.modelName ~= changeModel then
			modelChange = changeModel
		end

		self.noAvatar = true
	else
		if self.modelName ~= self.data.model then
			modelChange = self.data.model
		end

		self.noAvatar = nil
	end

	local changed = false

	if modelChange then
		self:load(modelChange)

		changed = true
	end

	if avatarArr then
		if not self:hasExtraAvatar() then
			self:setExtraAvatar(avatarArr)

			changed = true
		end
	elseif self:hasExtraAvatar() then
		self:clearExtraAvatar()

		changed = true
	end

	if changed then
		self:setAction(self.action)
	end
end

function CombatUnit:dotFin(skillData)
	local fin_buff = skillData.dot_fin_buff
	local fin_time = skillData.dot_fin_time
	local fin_ratio = skillData.dot_fin_ratio

	if not empty(fin_buff) and not empty(fin_time) and not empty(fin_ratio) then
		local fullFrameTime = WarMachine.getFrame()
		local fin_buff_arr = SkillManager.getDotFinBuffs(fin_buff)
		local buffIdMap = {}

		for i, v in ipairs(fin_buff_arr) do
			buffIdMap[tonumber(v)] = true
		end

		local buffTypeArr = self.buffStackMap[BUFF_TYPE.NORMAL]

		for i, obj in ipairs(buffTypeArr) do
			if buffIdMap[obj.id] then
				local buffData = CsvParser.getCsvData("buff", obj.id)

				if not empty(buffData.interval) then
					local intervalStart = 0

					if not empty(buffData.interval_start) then
						intervalStart = buffData.interval_start
					end

					if fullFrameTime >= obj.startTime + intervalStart then
						local timeLeft = obj.endTime - fullFrameTime
						obj.endTime = fullFrameTime + math.floor(timeLeft * (1 - fin_time))
						local dotFinTime = fullFrameTime + math.ceil(timeLeft * fin_time)
						local preInterval = math.floor((obj.frame - obj.startTime - intervalStart) / buffData.interval)
						local curInterval = math.floor((dotFinTime - obj.startTime - intervalStart) / buffData.interval)

						if preInterval < curInterval then
							for i = preInterval, curInterval - 1 do
								if obj.dotPack then
									self:beDamage(obj.dotPack, fin_ratio)
								end

								if buffData.trigger_timing == BUFF_TIMING.INTERVAL_TRIGGER then
									local countOK = true

									if not empty(buffData.trigger_count) then
										obj.triggerCount = (obj.triggerCount or 0) + 1

										if buffData.trigger_count <= obj.triggerCount then
											obj.triggerCount = 0
										else
											countOK = false
										end
									end

									if countOK then
										self:castBuffTriggerOne(obj, obj.dotPack)
									end
								end
							end

							local effectGen = self:getEffectGen()

							if effectGen then
								effectGen:castEffect(buffData.hurt_effect, self, nil, , obj.dotPack and obj.dotPack.caster)
							end
						end

						obj.frame = fullFrameTime
					end
				end
			end
		end
	end
end

function CombatUnit:getTriggerBuffPack(buffID)
	if not self.triggerBuffPackMap then
		self.triggerBuffPackMap = {}
	end

	if not self.triggerBuffPackMap[buffID] then
		local pack = {
			data = CsvParser.getCsvData("buff", buffID)
		}
		self.triggerBuffPackMap[buffID] = pack
	end

	return self.triggerBuffPackMap[buffID]
end

function CombatUnit:clearTriggerBuffPack()
	self.triggerBuffPackMap = nil
end

function CombatUnit:triggerBuff(timing, attackPack)
	local buffs = {}
	local fullFrameTime = WarMachine.getFrame()

	for type, buffTypeArr in pairs(self.buffStackMap) do
		if not empty(buffTypeArr) then
			for i, buffObj in ipairs(buffTypeArr) do
				local buffCSV = CsvParser.getCsvData("buff", buffObj.id)

				if buffCSV.trigger_timing == timing then
					local countOK = true

					if not empty(buffCSV.trigger_count) then
						buffObj.triggerCount = (buffObj.triggerCount or 0) + 1

						if buffCSV.trigger_count <= buffObj.triggerCount then
							buffObj.triggerCount = 0
						else
							countOK = false
						end
					end

					if countOK and (buffCSV.trigger_timing == BUFF_TIMING.BEHURT_TRIGGER or buffCSV.trigger_timing == BUFF_TIMING.HURT_TRIGGER) and attackPack and attackPack.skillData then
						local skillData = attackPack.skillData

						if buffCSV.trigger_value_2 == 1 and skillData.dmg_type ~= 1 or buffCSV.trigger_value_2 == 2 and skillData.dmg_type ~= 2 and skillData.dmg_type ~= 4 then
							countOK = false
						end
					end

					if countOK and (buffCSV.trigger_prob == "" or self.warRandom:next() < buffCSV.trigger_prob) then
						local buffPack = self:getTriggerBuffPack(buffObj.id)

						if not buffPack.cd or buffPack.cd <= fullFrameTime then
							table.insert(buffs, {
								pack = buffPack,
								originalAttrs = buffObj.originalAttrs
							})
						end
					end
				end
			end
		end
	end

	return buffs
end

function CombatUnit:triggerBuffOne(buffObj, attackPack)
	local buffs = {}
	local fullFrameTime = WarMachine.getFrame()
	local buffCSV = CsvParser.getCsvData("buff", buffObj.id)

	if buffCSV.trigger_prob == "" or self.warRandom:next() < buffCSV.trigger_prob then
		local buffPack = self:getTriggerBuffPack(buffObj.id)

		if not buffPack.cd or buffPack.cd <= fullFrameTime then
			table.insert(buffs, {
				pack = buffPack,
				originalAttrs = buffObj.originalAttrs
			})
		end
	end

	return buffs
end

function CombatUnit:castBuffSkill(buffs, attackPack, target)
	local fullFrameTime = WarMachine.getFrame()

	if buffs and #buffs > 0 then
		for i, v in ipairs(buffs) do
			local originalAttrs = v.originalAttrs
			local buffPack = v.pack
			local buffCSV = buffPack.data
			local triggerOK = false
			local forceTarget = nil

			if (buffCSV.trigger_timing == BUFF_TIMING.BEHURT_TRIGGER or buffCSV.trigger_timing == BUFF_TIMING.HURT_TRIGGER) and buffCSV.trigger_value_1 == 1 and target then
				forceTarget = target
			end

			local skillID = buffCSV.trigger_skill
			local times = 1

			if buffCSV.trigger_skill_times and buffCSV.trigger_skill_times ~= "" then
				times = SheetUtil.getNumber(buffCSV.trigger_skill_times, self.warRandom)
			end

			if not empty(skillID) then
				local skillData = CsvParser.getCsvData("skill", skillID)
				local skillPack = self:getSkillPack(skillID)
				skillPack = skillPack or self:addSkill(skillID, false)

				if skillPack then
					skillPack.already = {}

					for j = 1, times do
						local isReady, castTarget = SkillManager.findAutoSkillTarget(self, skillData, forceTarget or self.battleData.target)

						if isReady then
							if skillData.select_type == 2 and skillData.select_auto == 3 and skillData.is_jump == 1 then
								if not empty(buffCSV.trigger_cd) then
									buffPack.cd = fullFrameTime + buffCSV.trigger_cd
								end

								self:castManualSkill(skillPack, self.casting.target)
							else
								if not empty(buffCSV.trigger_cd) then
									buffPack.cd = fullFrameTime + buffCSV.trigger_cd
								end

								self:castDo(skillData, nil, skillPack, castTarget, nil, true, originalAttrs, buffCSV.origin_trigger == 1)
							end

							triggerOK = true
						else
							break
						end
					end
				end
			end

			local trigger_buff_add = buffCSV.trigger_buff_add
			local trigger_buff_time = buffCSV.trigger_buff_time

			if not empty(trigger_buff_add) and not empty(trigger_buff_time) then
				triggerOK = true

				self:addBuff(trigger_buff_add, trigger_buff_time, attackPack, self.id, nil, originalAttrs)
			end

			local trigger_buff_clear = buffCSV.trigger_buff_clear

			if not empty(trigger_buff_clear) then
				triggerOK = true

				self:clearBuffTo(trigger_buff_clear)
			end

			local trigger_cd_reduce = buffCSV.trigger_cd_reduce

			if not empty(trigger_cd_reduce) then
				local skillPack = self:getActiveSkill()

				if skillPack and fullFrameTime < skillPack.cd + skillPack.cdPenal then
					triggerOK = true
					skillPack.cd = skillPack.cd - trigger_cd_reduce

					self:dispatchEvent({
						name = "skill_cd",
						cd = skillPack.cd,
						cdMax = skillPack.cdMax,
						id = skillPack.data.id,
						trigger_cd_reduce = trigger_cd_reduce
					})
					self:dispatchEvent({
						name = "skill_cd_" .. skillPack.data.id,
						cd = skillPack.cd,
						cdMax = skillPack.cdMax,
						trigger_cd_reduce = trigger_cd_reduce
					})
				end
			end

			if triggerOK and not empty(buffCSV.trigger_cd) then
				buffPack.cd = fullFrameTime + buffCSV.trigger_cd
			end
		end
	end
end

function CombatUnit:castBuffTrigger(timing, attackPack, target)
	if self.antiBeDamageNesting and self.antiBeDamageNesting[timing] then
		return
	end

	self.antiBeDamageNesting = self.antiBeDamageNesting or {}
	self.antiBeDamageNesting[timing] = true
	local buffs = self:triggerBuff(timing, attackPack)

	if buffs and #buffs > 0 then
		self:castBuffSkill(buffs, attackPack, target)
	end

	self.antiBeDamageNesting[timing] = nil
end

function CombatUnit:castBuffTriggerOne(obj, attackPack)
	local buffs = self:triggerBuffOne(obj, attackPack)

	if buffs and #buffs > 0 then
		self:castBuffSkill(buffs, attackPack)
	end
end

function CombatUnit:addState(name, key)
	local preIsState = self:getState(name)

	if not self.stateMap[name] then
		self.stateMap[name] = {}
	end

	self.stateMap[name][key] = 1

	if not preIsState then
		self:dispatchEvent({
			name = "state_changed_" .. name
		})
	end
end

function CombatUnit:removeState(name, key)
	if self.stateMap[name] then
		self.stateMap[name][key] = nil
	end

	if self.stateMap[name] and table.nums(self.stateMap[name]) == 0 then
		self.stateMap[name] = nil

		self:dispatchEvent({
			name = "state_changed_" .. name
		})
	end
end

function CombatUnit:clearState(name)
	self.stateMap[name] = nil
end

function CombatUnit:getState(name)
	return self.stateMap[name] ~= nil
end

function CombatUnit:addStateEffect(nameStr, key)
	local nameArr = string.split(nameStr, ";")

	for i, name in ipairs(nameArr) do
		if not empty(name) then
			local preState = self:getState(name)

			self:addState(name, key)

			if not preState and not global.noEffect then
				self:addLastingEffect(name, nil)
			end
		end
	end
end

function CombatUnit:removeStateEffect(nameStr, key)
	local nameArr = string.split(nameStr, ";")

	for i, name in ipairs(nameArr) do
		if not empty(name) then
			local preState = self:getState(name)

			self:removeState(name, key)

			if preState and not self:getState(name) then
				self:removeLastingEffect(name)
			end
		end
	end
end

function CombatUnit:hurtAnimation()
	self:addFleeState(1)

	local function doHurtAnimation()
		if self:hasAction("hurt") and self.action == "idle" and (self.casting.step == 0 or self.casting.step == 4) then
			self:setAction("hurt")
		end

		self.hurtAnimationData = {}

		if self.noHurtColor ~= 1 then
			self:setColor(cc.c3b(128, 0, 0))
		end

		self.hurtAnimationData.timeoutID = MapFrameManager.setTimeout(function ()
			self.hurtAnimationData = nil

			self:refreshVisible()

			if self.action == "hurt" then
				self:setAction("idle")
			end
		end, 10, self)
	end

	if self.hurtAnimationData ~= nil then
		MapFrameManager.clearTimeout(self.hurtAnimationData.timeoutID)
		self:refreshVisible()
		MapFrameManager.setTimeout(doHurtAnimation, 2, self)
	else
		doHurtAnimation()
	end
end

function CombatUnit:refill()
	self:clearBuff()

	if self.battleData.die then
		self.battleData.die = nil

		self:setAction("idle")
	end

	self.battleData.hp = self:getHpMax()

	self:dispatchEvent({
		name = "hp_changed"
	})
end

function CombatUnit:tryBattleFollow(noFreeze)
	if self.limitedNoMove then
		return
	end

	if self:getState("no_move") then
		return
	end

	if self:inFlee() then
		return
	end

	if self.speed <= 0 then
		return
	end

	if self.trapOnly then
		return
	end

	local fullFrameTime = WarMachine.getFrame()

	if self.battleData.target then
		MapFrameManager.clearTimeout(self.tryBattleFollowTimeoutID)

		local function doBattleFollow()
			if not self.battleData then
				return
			end

			if self.battleData.target == nil then
				return
			end

			if self.giveupOnRange and self.battleData.target ~= nil and self.battleData.target.battleData then
				local range = self:getRange(self.battleData.target)

				if self.battleData.preTargetRange and (self.speed < self.battleData.target.speed and math.max(self.battleData.preTargetRange, 1.42 * self.map.ptPerTile) < range or math.max(self.battleData.preTargetRange, 2.84 * self.map.ptPerTile) < range) then
					self:removeTarget()

					if self.isUseHate then
						self:reduceCurrentHate()
					end

					return
				end

				self.battleData.preTargetRange = range
			end

			self:battleFollow(self.battleData.target, fullFrameTime)

			if self.battleData.target == nil and not noFreeze then
				self.thinkFreezed = true

				WarMachine.addToFreezeArray(self)
			end
		end

		if self.jumpWalkLockTime and MapFrameManager.getFrame() < self.jumpWalkLockTime then
			self.tryBattleFollowTimeoutID = MapFrameManager.setTimeout(doBattleFollow, self.jumpWalkLockTime - MapFrameManager.getFrame())
		elseif self.jumpData then
			self:setJumpCallback(doBattleFollow)
		else
			doBattleFollow()
		end
	end
end

function CombatUnit:battleFollow(unit)
	local fullFrameTime = WarMachine.getFrame()

	if self.battleData.battleFollowLockTime and fullFrameTime <= self.battleData.battleFollowLockTime then
		return true
	end

	if self:getState("no_move") then
		return true
	end

	if self.speed <= 0 then
		return
	end

	if self.trapOnly then
		return
	end

	local path, pathFound = nil
	local range = 0

	if self.casting.skillPack ~= nil and self.casting.step > 0 then
		local skillData = self.casting.skillPack.data
		range = skillData.range

		if skillData.type == 1 and range > 0 then
			range = range + self.attrs.range_add
		end
	else
		local sortSkill = {}
		local minRange = nil

		for i = 1, #self.autoSkills do
			local skillPack = self.autoSkills[i]
			local skillData = SkillManager.getSkillData(self, skillPack)
			local tempRange = skillData.range

			if skillData.type == 1 and tempRange > 0 then
				tempRange = tempRange + self.attrs.range_add
			end

			if not minRange or tempRange < minRange then
				minRange = tempRange
			end
		end

		if minRange then
			range = minRange
		end
	end

	if range == 0 then
		path, pathFound = self:findMeleeTile(unit)
	else
		path, pathFound = self:findRangedTile(unit, range)
	end

	if path == true then
		self.battleData.preTargetTile = unit.tile
	elseif #path > 0 then
		if not empty(self.data.battle_step) and not empty(self.data.battle_wait) then
			local battleStep = SheetUtil.getNumber(self.data.battle_step, self.warRandom)

			if battleStep then
				battleStep = math.max(2, battleStep + 1)

				if battleStep < #path then
					local cutPath = {}

					for i = 1, battleStep do
						table.insert(cutPath, path[i])
					end

					path = cutPath
				end
			end
		end

		if self:goPath(path) then
			if not empty(self.data.battle_wait) then
				local waitTime = SheetUtil.getNumber(self.data.battle_wait, self.warRandom)
				self.battleData.battleFollowLockTime = fullFrameTime + waitTime + self:getGoTime(path)
			end

			self.battleData.preTargetTile = unit.tile
		end
	else
		if not pathFound then
			self:removeTarget()

			if self.isUseHate then
				self:reduceCurrentHate()
			end
		end

		return false
	end

	return true
end

function CombatUnit:setPathLimited(tileMap, noMove)
	self.limitedTileMap = tileMap
	self.limitedNoMove = noMove
end

function CombatUnit:checkPathLimited(tileTag)
	if self.limitedTileMap then
		return self.limitedTileMap[tileTag]
	else
		return true
	end
end

function CombatUnit:checkFourSideWalkable()
	local tileOffsets = {
		{
			1,
			0
		},
		{
			-1,
			0
		},
		{
			0,
			-1
		},
		{
			0,
			1
		}
	}
	local sortNeibours = {}

	for i = 1, #tileOffsets do
		local neibourTile = self.map:getTile(self.tile.x + tileOffsets[i][1], self.tile.y + tileOffsets[i][2])

		if neibourTile and neibourTile:getWalkable(self.walkLevel, self) then
			return true
		end
	end

	return false
end

function CombatUnit:checkMeleeAndRangedTile(skillRange, unit, isJump)
	if skillRange == -1 then
		return true
	elseif skillRange == 0 then
		return self:checkMeleeTile(unit)
	else
		if isJump == 1 then
			local tile = self.map:mapToTile(unit.x, unit.y)

			if tile and not self:checkPathLimited(tile.tag) then
				return false
			end
		end

		return self:checkRangedTile(unit, skillRange)
	end
end

function CombatUnit:setAdditionalRange(range)
	self.additionalRange = range
end

function CombatUnit:checkRangedTile(unit, range, specializedTile)
	if not unit or not unit.tile then
		return false
	end

	if range < 0 then
		return true
	end

	specializedTile = specializedTile or self.tile

	if not specializedTile then
		return false
	end

	local x1 = specializedTile.x + (self.size - 1) / 2
	local y1 = specializedTile.y + (self.size - 1) / 2
	local x2 = unit.tile.x + (unit.size - 1) / 2
	local y2 = unit.tile.y + (unit.size - 1) / 2
	local mhdRange = math.abs(x2 - x1) + math.abs(y2 - y1)
	local minDistance = mhdRange - (self.size - 1 + unit.size - 1) / 2

	return minDistance <= range + self.additionalRange
end

function CombatUnit:findRangedTile(unit, range)
	if unit.tile == nil then
		return {}, false
	end

	local preBlock = self.isBlock
	self.isBlock = false
	local path, pathFound = nil

	if self.limitedTileMap then
		self.map:setPathLimited(self.limitedTileMap)
	end

	if self:checkRangedTile(unit, range) then
		path = true
		pathFound = true
	elseif self:getState("no_move") then
		path = {}
		pathFound = false
	else
		path, pathFound = self.map:findPath(self.tile, unit.tile, self.walkLevel, self.size, function (tile)
			return self:checkRangedTile(unit, range, tile)
		end, self)

		if not pathFound and self:isFriendCross() then
			path, pathFound = self.map:findPath(self.tile, unit.tile, self.walkLevel, self.size, function (tile)
				return self:checkRangedTile(unit, range, tile)
			end, function (tile, unitMap)
				return self:checkUnitBlockCamp(tile, unitMap)
			end)
		end
	end

	if self.limitedTileMap then
		self.map:clearPathLimited()
	end

	self.isBlock = preBlock

	return path, pathFound
end

function CombatUnit:checkMeleeTile(unit, specializedTile, isCheckUnitBlockAll)
	specializedTile = specializedTile or self.tile

	if not specializedTile then
		return false
	end

	if not unit or not unit.tile then
		return false
	end

	if isCheckUnitBlockAll and not self:checkUnitBlockAll(specializedTile, specializedTile.unitMap) then
		return false
	end

	if (specializedTile.y - unit.tile.y - (unit.size - 1) == 1 or unit.tile.y - specializedTile.y - (self.size - 1) == 1) and specializedTile.x - unit.tile.x < unit.size and unit.tile.x - specializedTile.x < self.size then
		return true
	end

	if (specializedTile.x - unit.tile.x - (unit.size - 1) == 1 or unit.tile.x - specializedTile.x - (self.size - 1) == 1) and specializedTile.y - unit.tile.y < unit.size and unit.tile.y - specializedTile.y < self.size then
		return true
	end

	return false
end

function CombatUnit:checkUnitBlockAll(tile, unitMap)
	if self.noBlock then
		return true
	end

	if unitMap then
		for unitID, unit in pairs(unitMap) do
			if unit ~= self and unit.isBlock then
				return false
			end
		end

		return true
	else
		if tile.occupiedUnit == nil or tile.occupiedUnit == self then
			return true
		end

		return false
	end
end

function CombatUnit:checkUnitBlockCamp(tile, unitMap)
	if self.noBlock then
		return true
	end

	if unitMap then
		for unitID, unit in pairs(unitMap) do
			if unit ~= self and unit.isBlock and unit.battleData and (unit.battleData.camp ~= self.battleData.camp or unit.isTDBlock) then
				return false
			end
		end

		return true
	else
		if tile.occupiedUnit == nil or tile.occupiedUnit == self or tile.occupiedUnit.battleData.camp == self.battleData.camp and unit.isTDBlock then
			return true
		end

		return false
	end
end

function CombatUnit:findMeleeTile(unit)
	if unit.tile == nil then
		return {}, false
	end

	local preBlock = self.isBlock
	self.isBlock = false

	if self.limitedTileMap then
		self.map:setPathLimited(self.limitedTileMap)
	end

	local path, pathFound = nil

	if self:checkMeleeTile(unit) then
		path = true
		pathFound = true
	elseif self:getState("no_move") then
		path = {}
		pathFound = false
	else
		path, pathFound = self.map:findPath(self.tile, unit.tile, self.walkLevel, self.size, function (tile)
			return self:checkMeleeTile(unit, tile)
		end, self)

		if not pathFound and self:isFriendCross() then
			path, pathFound = self.map:findPath(self.tile, unit.tile, self.walkLevel, self.size, function (tile)
				return self:checkMeleeTile(unit, tile, true)
			end, function (tile, unitMap)
				return self:checkUnitBlockCamp(tile, unitMap)
			end)
		end
	end

	if self.limitedTileMap then
		self.map:clearPathLimited()
	end

	self.isBlock = preBlock

	return path, pathFound
end

function CombatUnit:setHudLabel(text, style)
	if not self.hud then
		return
	end

	self:removeHudLabel()

	local labelX = 0

	if CURRENT_HPBAR_STYLE == HPBAR_STYLE.BAR then
		labelX = self.hud.ui:getContentSize().width / 2
	else
		labelX = self.hud.hpbarHigh:getContentSize().width / 2
	end

	local label = UIManager.createLabel(labelX, -10, 0, 0, text, style)
	local size = label:getContentSize()

	if CURRENT_HPBAR_STYLE == HPBAR_STYLE.BAR then
		self.hud.ui:addChild(label)
	else
		self.hud.hpbarHigh:addChild(label)
		label:setScale(1 / self.hud.hpbarHigh:getScale())
	end

	self.hud.label = label

	return label
end

function CombatUnit:removeHudLabel()
	if self.hud and self.hud.label then
		self.hud.label:removeSelf()

		self.hud.label = nil
	end
end

function CombatUnit:setHudColor(color)
	if self.hud and self.hud.hpbar then
		self.hud.hpbar:setColor(color)
	end
end

function CombatUnit:refreshShieldHud(shield, shieldTotal)
	if self.hud then
		if not shield then
			shield, shieldTotal = self:getShield()
		end

		self.hud.shieldPercent = shield / shieldTotal

		if shield > 0 then
			if not self.hud.shieldbg then
				local shieldbarBG = display.newSprite("#map_assets_hudbar_bg"):align(display.LEFT_CENTER, -1, 4.5)
				local shieldbar = display.newSprite("#map_assets_hudbar"):align(display.LEFT_CENTER, 0, 4)

				shieldbar:setScaleY(0.5)
				shieldbarBG:setScaleY(0.75)
				self.hud.ui:addChild(shieldbarBG)
				self.hud.ui:addChild(shieldbar)

				self.hud.shieldbg = shieldbarBG
				self.hud.shieldbar = shieldbar

				self.hud.shieldbar:setColor(shieldbar_color)
				self:refreshShadow()
			end

			self:refreshShieldbar()
		elseif self.hud.shieldbg then
			self.hud.shieldbg:removeSelf()
			self.hud.shieldbar:removeSelf()

			self.hud.shieldbg = nil
			self.hud.shieldbar = nil
		end
	end
end

function CombatUnit:refreshShieldbar()
	if self.hud and self.hud.shieldbar then
		local percent = self.hud.shieldPercent or 0

		self.hud.shieldbar:setScaleX(self.hud.width / 64 * percent)
	end
end

function CombatUnit:setHudVisible(visible, color, style, noSkillbar)
	if self.hpBarVisible ~= visible then
		self.hpBarVisible = visible

		if self.hpBarVisible then
			if CURRENT_HPBAR_STYLE == HPBAR_STYLE.BAR then
				local hudUI = display.newNode():align(display.LEFT_CENTER)
				local hpbarBG = display.newSprite("#map_assets_hudbar_bg"):align(display.LEFT_CENTER, -1, 0)
				local hpbar = display.newSprite("#map_assets_hudbar"):align(display.LEFT_CENTER)
				local dmgbar = display.newSprite("#map_assets_hudbar"):align(display.LEFT_CENTER)

				hpbarBG:setScaleY(1.5)

				local skillbarBG, skillbar = nil

				if not noSkillbar and #self.manualSkills > 0 then
					skillbarBG = display.newSprite("#map_assets_hudbar_bg"):align(display.LEFT_CENTER, -1, -4.5)
					skillbar = display.newSprite("#map_assets_hudbar"):align(display.LEFT_CENTER, 0, -4)

					skillbar:setColor(skillbar_color)
					skillbar:setScaleY(0.5)
					skillbarBG:setScaleY(0.75)
				end

				if color then
					hpbar:setColor(color)
				end

				dmgbar:setColor(cc.c3b(255, 0, 0))
				hudUI:addChild(hpbarBG)
				hudUI:addChild(dmgbar)
				hudUI:addChild(hpbar)

				if skillbarBG then
					hudUI:addChild(skillbarBG)
					hudUI:addChild(skillbar)
				end

				hudUI:setCascadeOpacityEnabled(true)
				transition.fadeIn(hudUI, {
					time = 0.4
				})
				dmgbar:setVisible(false)

				self.hud = {
					percent = 1,
					prePercent = 1,
					ui = hudUI,
					hpbar = hpbar,
					dmgbar = dmgbar,
					hpbg = hpbarBG,
					skillbar = skillbar,
					skillbg = skillbarBG
				}

				self.map.highLayer:addChild(hudUI)
				self:refreshShieldHud()
			else
				local hpbarLow = display.newSprite(style or "#map_assets_unit_circle")
				local hpbarHigh = display.newSprite(style or "#map_assets_unit_circle")

				transition.fadeIn(hpbarLow, {
					time = 0.4
				})
				hpbarHigh:setOpacity(0)
				transition.fadeTo(hpbarHigh, {
					opacity = 100,
					time = 0.4
				})

				self.hud = {
					hpbarLow = hpbarLow,
					hpbarHigh = hpbarHigh
				}

				self.map.lowLayer:addChild(hpbarLow)
				self.map.highLayer:addChild(hpbarHigh)
			end

			self:refreshShadow()
			self:draw()
			self:hudSetHP(self.battleData.hp / self.attrs.hp, true)
			self:refreshSkillbar()
		elseif self.hud then
			if CURRENT_HPBAR_STYLE == HPBAR_STYLE.BAR then
				self:dmgbarDecreaceStop()
				self:skillbarDecreaceStop()

				local hudUI = self.hud.ui

				transition.fadeOut(hudUI, {
					time = 0.2,
					onComplete = function ()
						hudUI:removeSelf()
					end
				})
			else
				local hudUI = self.hud.hpbarLow

				transition.fadeOut(hudUI, {
					time = 0.2,
					onComplete = function ()
						hudUI:removeSelf()
					end
				})

				local hudUI = self.hud.hpbarHigh

				transition.fadeOut(hudUI, {
					time = 0.2,
					onComplete = function ()
						hudUI:removeSelf()
					end
				})
			end

			self.hud = nil
		end
	end
end

function CombatUnit:hudSetHP(percent, isInit)
	if self.hud == nil then
		return
	end

	percent = math.max(0, math.min(percent, 1))

	if CURRENT_HPBAR_STYLE == HPBAR_STYLE.BAR then
		MapFrameManager.clearTimeout(self.hud.dmgbarRemainID)
		MapFrameManager.stopLoop(self, self.dmgbarDecreace)

		local prePercent = self.hud.prePercent

		if not isInit then
			if percent < prePercent then
				local dmgbar = self.hud.dmgbar

				dmgbar:setVisible(true)
				dmgbar:setPositionX(self.hud.width * percent)

				local scaleX = self.hud.width / 64 * (prePercent - percent)

				dmgbar:setScaleX(scaleX)

				self.hud.dmgbarScaleX = scaleX
				self.hud.dmgbarRemainID = MapFrameManager.setTimeout(function ()
					if self.hud then
						self.hud.prePercent = percent

						MapFrameManager.startLoop(self, self.dmgbarDecreace)
					end
				end, 30, self)
			end
		else
			self.hud.prePercent = percent
		end

		self.hud.percent = percent

		self.hud.hpbar:setScaleX(self.hud.width / 64 * self.hud.percent)
	else
		percent = math.max(0, math.min(percent, 1))
		local color = InfoHero.getHpColor(percent)

		self.hud.hpbarLow:setColor(color)
		self.hud.hpbarHigh:setColor(color)
	end
end

function CombatUnit:dmgbarDecreace(frame, passed, sharp)
	if not self.hud.dmgbarScaleX then
		return
	end

	local scaleX = math.max(self.hud.dmgbarScaleX - 0.02 * passed, 0)
	local dmgbar = self.hud.dmgbar

	dmgbar:setScaleX(scaleX)

	self.hud.dmgbarScaleX = scaleX

	if scaleX <= 0 then
		self:dmgbarDecreaceStop()
	end
end

function CombatUnit:dmgbarDecreaceStop()
	local dmgbar = self.hud.dmgbar

	dmgbar:setVisible(false)
	MapFrameManager.stopLoop(self, self.dmgbarDecreace)
end

function CombatUnit:setReviveHudVisible(visible, color)
	if self.reviveHudVisible ~= visible then
		self.reviveHudVisible = visible

		if self.reviveHudVisible then
			local hudUI = display.newNode():align(display.LEFT_CENTER)
			local barBG = display.newSprite("#map_assets_hudbar_bg"):align(display.LEFT_CENTER)
			local bar = display.newSprite("#map_assets_hudbar"):align(display.LEFT_CENTER, 1, 1)

			barBG:setScaleY(1.5)

			if color then
				bar:setColor(color)
			end

			hudUI:addChild(barBG)
			hudUI:addChild(bar)
			hudUI:setCascadeOpacityEnabled(true)
			transition.fadeIn(hudUI, {
				time = 0.4
			})

			self.reviveHud = {
				ui = hudUI,
				bar = bar,
				barbg = barBG
			}

			self.map.highLayer:addChild(hudUI)
			self:refreshShadow()
			self:draw()
			self:hudSetRevive(self.battleData.hp / self.attrs.hp)
		elseif self.reviveHud then
			local hudUI = self.reviveHud.ui

			transition.fadeOut(hudUI, {
				time = 0.2,
				onComplete = function ()
					hudUI:removeSelf()
				end
			})

			self.reviveHud = nil
		end
	end
end

function CombatUnit:hudSetRevive(percent)
	if self.reviveHud == nil then
		return
	end

	percent = math.max(0, math.min(percent, 1))

	self.reviveHud.bar:setScaleX(self.reviveHud.width / 64 * percent)
end

local hateOrderRatio = 1.5

function CombatUnit:startHate()
	self.hateStack = {
		unitMap = {}
	}
	local enemyCamp = WarMachine.getEnemyCamp(self.battleData.camp)
	local enemies = WarMachine.getUnitsByCamp(enemyCamp)

	for i, unit in ipairs(enemies) do
		self.hateStack.unitMap[unit.id] = 0
	end

	local function handleEnemyAdd(unit)
		self.hateStack.unitMap[unit.id] = 0

		self:addHate(unit)
	end

	local function handleEnemyRemove(unit)
		self.hateStack.unitMap[unit.id] = nil

		if self.hateStack.current == unit then
			self.hateStack.current = nil

			self:reorderHate()
		end
	end

	self.addEnemyHandler = notify.safeRegister(self, "warmachine_addunit_" .. enemyCamp, handleEnemyAdd)
	self.removeEnemyHandler = notify.safeRegister(self, "warmachine_removeunit_" .. enemyCamp, handleEnemyRemove)
end

function CombatUnit:stopHate()
	self.hateStack = nil
	local enemyCamp = WarMachine.getEnemyCamp(self.battleData.camp)

	notify.unregister("warmachine_addunit_" .. enemyCamp, self.addEnemyHandler)
	notify.unregister("warmachine_removeunit_" .. enemyCamp, self.removeEnemyHandler)
end

function CombatUnit:addHate(unit, value)
	if not self.hateStack then
		return
	end

	value = value or 0

	if self.hateStack.unitMap[unit.id] then
		self.hateStack.unitMap[unit.id] = self.hateStack.unitMap[unit.id] + value

		if self:getState("lock_hate") then
			return
		end

		if self.hateStack.current ~= unit then
			if self.hateStack.current then
				if not self.hateStack.unitMap[unit.id] then
					Log.debug("CombatUnit:addHate unit.id:", unit.id)
				end

				if not self.hateStack.unitMap[self.hateStack.current.id] then
					Log.debug("CombatUnit:addHate self.hateStack.current.id:", self.hateStack.current.id)
				end
			end

			if not self.hateStack.current or self.hateStack.unitMap[unit.id] > self.hateStack.unitMap[self.hateStack.current.id] * hateOrderRatio then
				local preHate = nil

				if self.hateStack.current then
					preHate = self.hateStack.unitMap[self.hateStack.current.id]
				end

				self.hateStack.current = unit

				self:reBattleThink()
			end
		end
	end
end

function CombatUnit:setCurrentHate(unit)
	if not self.hateStack then
		return
	end

	self.hateStack.current = unit

	self:reBattleThink()
end

function CombatUnit:reduceCurrentHate()
	if self.hateStack.current and self.hateStack.unitMap[self.hateStack.current.id] then
		self.hateStack.unitMap[self.hateStack.current.id] = math.floor(self.hateStack.unitMap[self.hateStack.current.id] / hateOrderRatio)

		self:reorderHate()
	end
end

function CombatUnit:getCurrentHate()
	if not self.hateStack then
		return
	end

	if not self.hateStack.current then
		self:reorderHate()
	end

	return self.hateStack.current
end

function CombatUnit:clearCurrentHate()
	self.hateStack.current = nil
end

function CombatUnit:reorderHate()
	if not self.hateStack then
		return
	end

	if self:getState("lock_hate") then
		return
	end

	local bestValue, bestUnit, bestRange = nil

	for unitID, value in pairs(self.hateStack.unitMap) do
		local unit = ClipOnMap.getUnit(unitID)
		local range = nil
		local isBetter = false

		if not bestUnit or bestValue < value then
			isBetter = true
		elseif value == bestValue then
			range = self:getRange(unit)

			if range < bestRange then
				isBetter = true
			end
		end

		if isBetter then
			bestValue = value
			bestUnit = unit
			bestRange = range or self:getRange(unit)
		end
	end

	self.hateStack.current = bestUnit
end

function CombatUnit:stop(code)
	if self.jumpStopEffect then
		local effectGen = self:getEffectGen()

		if effectGen then
			effectGen:castEffect(self.jumpStopEffect, self, nil, angle, self)
		end

		self.jumpStopEffect = nil
	end

	CombatUnit.super.stop(self, code)
	MapFrameManager.clearTimeout(self.tryBattleFollowTimeoutID)

	if self.z ~= 0 then
		self.z = 0

		self:setBmpY()
		self:setAvatarZ()
	end

	if WarMachine.on and not self.battleData.die and not self.noWayout and self.tile and not self.tile:isMasterUnit(self) and not self.summonNoBlock then
		if self.casting.step ~= 0 then
			return
		end

		local tileOffsets = {
			{
				1,
				0
			},
			{
				-1,
				0
			},
			{
				0,
				-1
			},
			{
				0,
				1
			}
		}
		local sortNeibours = {}

		for i = 1, #tileOffsets do
			local neibourTile = self.map:getTile(self.tile.x + tileOffsets[i][1], self.tile.y + tileOffsets[i][2])

			if neibourTile then
				local obj = {
					tile = neibourTile
				}

				if self.battleData.target then
					obj.distance = math.sqrt(math.pow(self.tile.y - neibourTile.y, 2) + math.pow(self.tile.x - neibourTile.x, 2))
				end

				table.insert(sortNeibours, obj)
			end
		end

		if self.battleData.target then
			table.sort(sortNeibours, function (a, b)
				if a.distance == b.distance then
					return a.tile.sortTag < b.tile.sortTag
				else
					return a.distance < b.distance
				end
			end)
		elseif self.warRandom then
			sortNeibours = self.warRandom:order(sortNeibours)
		end

		local preTile = self.map:mapToTile(self.x, self.y)

		for i = 1, #sortNeibours do
			local nextTile = sortNeibours[i].tile
			local nextCanMove, newTiles = self:getNextCanMove(nextTile, preTile)

			if nextCanMove then
				self:goPath({
					self.tile,
					nextTile
				})
				Log.verbose("不占有当前tile，移动到邻近tile", self.data.name, self.tile.tag, nextTile.tag)

				break
			end
		end
	end

	if self.map and self.map.isBattle then
		self.battleData.preTargetTile = nil

		if self.battleData.target ~= nil and self.battleData.target.battleData then
			self:faceTo(self.battleData.target)
		end
	end
end

function CombatUnit:setAction(action, loop, overFunc, startFrame)
	if self.battleData.die then
		return
	end

	if action == "idle_atk" then
		if not empty(self.battleIdleAction) and self:hasAction(self.battleIdleAction) then
			action = self.battleIdleAction
		else
			action = "idle"
		end
	end

	if WarMachine.on and action == "idle" and not empty(self.battleIdleAction) and self:hasAction(self.battleIdleAction) then
		action = self.battleIdleAction
	end

	CombatUnit.super.setAction(self, action, loop, overFunc, startFrame)
end

function CombatUnit:refreshShadow(isNew)
	CombatUnit.super.refreshShadow(self, isNew)

	if self.hud then
		local barWidth = math.floor(self:getFootWidth() * self.map.config.scale.unit)
		barWidth = math.round((barWidth + self.size * self.map.ptPerTile / 2) * 0.7 / 2)

		if CURRENT_HPBAR_STYLE == HPBAR_STYLE.BAR then
			self.hud.hpbg:setScaleX((barWidth + 2) / 64)

			self.hud.width = barWidth

			self.hud.hpbar:setScaleX(self.hud.width / 64 * self.hud.percent)

			if self.hud.skillbg then
				self.hud.skillbg:setScaleX((barWidth + 2) / 64)
				self.hud.skillbar:setScaleX(barWidth / 64)
				self:refreshSkillbar()
			end

			if self.hud.shieldbg then
				self.hud.shieldbg:setScaleX((barWidth + 2) / 64)
				self.hud.shieldbar:setScaleX(barWidth / 64)
				self:refreshShieldbar()
			end
		else
			self.hud.hpbarLow:setScale(barWidth / 88 * 1.5)
			self.hud.hpbarHigh:setScale(barWidth / 88 * 1.5)
		end
	end

	if self.reviveHud then
		local barWidth = math.floor(self:getFootWidth() * self.map.config.scale.unit)
		barWidth = math.sqrt(barWidth * self.size * self.map.ptPerTile / 2) * 0.7

		self.reviveHud.bar:setScaleX(barWidth / 64)
		self.reviveHud.barbg:setScaleX((barWidth + 2) / 64)

		self.reviveHud.width = barWidth
	end
end

function CombatUnit:refreshSkillbar()
	if self.hud and self.hud.skillbar then
		self.hud.skillbar:setVisible(true)
		self.hud.skillbg:setVisible(true)

		local fullFrameTime = WarMachine.getFrame()

		self:skillbarDecreaceStop()

		local percent = (math.min(fullFrameTime, self.casting.autoCD) - self.casting.autoCDStart) / (self.casting.autoCD - self.casting.autoCDStart)
		percent = math.max(0, percent)

		self.hud.skillbar:setScaleX(self.hud.width / 64 * percent)

		if fullFrameTime < self.casting.autoCD then
			self.hud.skillbar:setColor(skillbar_recovering_color)
			MapFrameManager.startLoop(self, self.skillbarDecreace)
		else
			self:skillbarDecreaceStop()
		end
	end
end

function CombatUnit:skillbarDecreace(frame, passed, sharp)
	local fullFrameTime = WarMachine.getFrame()
	local percent = (math.min(fullFrameTime, self.casting.autoCD) - self.casting.autoCDStart) / (self.casting.autoCD - self.casting.autoCDStart)
	percent = math.max(0, percent)

	self.hud.skillbar:setScaleX(self.hud.width / 64 * percent)

	if percent >= 1 then
		self:skillbarDecreaceStop()
	end
end

function CombatUnit:skillbarDecreaceStop()
	if self.hud and self.hud.skillbar then
		self.hud.skillbar:setColor(skillbar_full_color)
	end

	MapFrameManager.stopLoop(self, self.skillbarDecreace)
end

function CombatUnit:display(map, x, y, customLayer)
	CombatUnit.super.display(self, map, x, y, customLayer)
	self:onShieldChanged()
end

function CombatUnit:setScale(scale)
	CombatUnit.super.setScale(self, scale)
	self:onShieldChanged()
end

function CombatUnit:setBmpY()
	CombatUnit.super.setBmpY(self)

	if not self.drawY then
		return
	end

	local selfZ = self:getZ()

	if self.hud and self.drawX then
		if CURRENT_HPBAR_STYLE == HPBAR_STYLE.BAR then
			local hudY = -self.drawY + self.height + selfZ + 20

			self.hud.ui:setPosition(self.drawX - self.hud.width / 2, hudY)
		else
			local hudY = -self.drawY

			self.hud.hpbarLow:setPosition(self.drawX, hudY)
			self.hud.hpbarHigh:setPosition(self.drawX, hudY)
		end
	end

	if self.reviveHud and self.drawX then
		local hudY = -self.drawY + self.height + selfZ + 20

		self.reviveHud.ui:setPosition(self.drawX - self.reviveHud.width / 2, hudY)
	end

	if self.flyWordStack then
		for i, flyObj in ipairs(self.flyWordStack) do
			local effectY = -self.drawY + self.height + selfZ

			flyObj.label:setPosition(self.drawX, effectY)
			flyObj.label:setLocalZOrder(self.drawY + flyObj.zorder)
		end
	end
end

function CombatUnit:go(x, y, occupiedCheckUnit)
	if self:getState("no_move") then
		if global.debugGoFail then
			Log.debug("CombatUnit:go failure no_move")
		end

		return
	end

	return CombatUnit.super.go(self, x, y, occupiedCheckUnit)
end

function CombatUnit:goPath(path, alwaysWalkable)
	if self:getState("no_move") then
		if self.isPlayer then
			Log.debug("goPath failed no_move:", self:getState("no_move"))
		end

		return
	end

	return CombatUnit.super.goPath(self, path, alwaysWalkable)
end

function CombatUnit:jump(dest, speed, height, callback, minTime, onUpdate, force)
	if self.jumpStopEffect then
		local effectGen = self:getEffectGen()

		if effectGen then
			effectGen:castEffect(self.jumpStopEffect, self, nil, angle, self)
		end

		self.jumpStopEffect = nil
	end

	if not force and self:getState("no_move") then
		return false
	end

	if force then
		self.battleData.battleFollowLockTime = nil
	end

	self.jumpForce = force

	return CombatUnit.super.jump(self, dest, speed, height, callback, minTime, onUpdate)
end

function CombatUnit:stopJump()
	if self.jumpStopEffect then
		local effectGen = self:getEffectGen()

		if effectGen then
			effectGen:castEffect(self.jumpStopEffect, self, nil, angle, self)
		end

		self.jumpStopEffect = nil
	end

	self.jumpForce = nil

	return CombatUnit.super.stopJump(self)
end

function CombatUnit:getPlaySkip(action, isLastFrame)
	local skip = CombatUnit.super.getPlaySkip(self, action, isLastFrame)

	if WarMachine.on then
		if self.casting and self.casting.skillData and self.casting.skillData.type == 1 and self.attrs and self.attrs.attack_speed then
			action = action or self.action

			if action == "attack" or action == "atk_w" or action == "atk_a" or action == "atk_m" then
				skip = skip / (1 + self.attrs.attack_speed / 100)
			end
		end

		if self.attrs and self.attrs.battle_speed and action == "walk" then
			skip = skip / (1 + self.attrs.battle_speed / 100)
		end
	end

	return skip
end

function CombatUnit:openWeakPoint(maxTime, maxValue, onBreak)
	self:closeWeakPoint()

	self.weakpointInfo = {
		value = 0,
		startTime = MapFrameManager.getFrame(),
		maxValue = maxValue,
		onBreak = onBreak
	}
	self.weakpoint = Weakpoint.new(maxTime, maxValue)

	self.weakpoint:setPositionY(self:getTotalHeight() / 2)
	self:addUI("weakpoint", self.weakpoint, 2, 10000)
	MapFrameManager.startLoop(self, self.refreshWeakPoint)
	self:refreshWeakPoint()
end

function CombatUnit:closeWeakPoint(isBreak)
	if self.weakpoint then
		local weakpoint = self.weakpoint
		self.weakpoint = nil
		self.weakpointInfo = nil

		MapFrameManager.stopLoop(self, self.refreshWeakPoint)
		weakpoint:close(isBreak, function ()
			self:removeUI("weakpoint")
		end)
	end
end

function CombatUnit:addWeakpointValue(value)
	if self.weakpoint then
		self.weakpointInfo.value = math.min(self.weakpointInfo.maxValue, self.weakpointInfo.value + value)

		self.weakpoint:setValue(self.weakpointInfo.value)
		self.weakpoint:shock()

		if self.weakpointInfo.maxValue <= self.weakpointInfo.value then
			local onBreak = self.weakpointInfo.onBreak

			if onBreak then
				onBreak()
			end
		end
	end
end

function CombatUnit:refreshWeakPoint()
	self.weakpoint:setTime(MapFrameManager.getFrame() - self.weakpointInfo.startTime)
end

function CombatUnit:markTime(tag)
	local time = MapFrameManager.getFrame()

	if tag then
		if not self.aiTimeTagMap then
			self.aiTimeTagMap = {}
		end

		self.aiTimeTagMap[tag] = time
	end

	return time
end

function CombatUnit:timeMark(tag)
	return self.aiTimeTagMap[tag]
end

function CombatUnit:aiThinkFreeze(isFreeze)
	self.thinkFreezedAI = isFreeze
end

function CombatUnit:aiCheckSkillReady(skillID)
	local fullFrameTime = WarMachine.getFrame()

	if self:getState("no_skill") then
		return false
	end

	local skillPack = self:getSkillPack(skillID)

	if skillPack then
		if fullFrameTime >= skillPack.cd + skillPack.cdPenal and SkillManager.checkPower(skillPack, fullFrameTime) then
			return true
		end
	else
		print("CombatUnit:aiCastSkill 没有skillPack")
	end

	return false
end

function CombatUnit:aiSetSkillCD(skillID, customCD)
	local fullFrameTime = WarMachine.getFrame()
	local skillPack = self:getSkillPack(skillID)

	if skillPack then
		local skillData = skillPack.data
		local skillcd_reduce = self.attrs.skillcd_reduce

		if skillData.type == 1 then
			skillcd_reduce = 0
		end

		local cdMax = customCD or SheetUtil.getNumber(skillData.cd, self.warRandom)
		skillPack.cdMax = math.floor(math.max(0, cdMax - skillcd_reduce) * 100 / (100 + self.attrs.skillcd_division))
		skillPack.cd = fullFrameTime + self.casting.skillPack.cdMax
		self.casting.sharedCD = fullFrameTime + math.floor(self.attrs.attack_time / (1 + self.attrs.attack_speed / 100))
	end
end

function CombatUnit:aiCastSkill(skillID, target)
	self:castManualSkill(skillID, target or self.battleData.target or self)
end

function CombatUnit:aiGetTargetRandom()
end

function CombatUnit:aiGetTargetFar()
	local enemies = WarMachine.getUnitsByCamp(WarMachine.getEnemyCamp(self.battleData.camp))

	if #enemies == 0 then
		return nil
	end

	local sortArr = {}

	for i, enemy in ipairs(enemies) do
		local distance = self:getRange(enemy)

		table.insert(sortArr, {
			distance = distance,
			enemy = enemy
		})
	end

	table.sort(sortArr, function (a, b)
		return b.distance < a.distance
	end)

	return sortArr[1].enemy
end

function CombatUnit:aiGetEnemies()
end

function CombatUnit:aiGetFriends()
end

function CombatUnit:setUndeadable(enabled)
	self.undeadable = enabled
end

function CombatUnit:onExit()
	Looper.stopLoop(self, self.snapshootShining)

	if not app.sceneChanging then
		self:clearSkillWarning()
		self:closeWeakPoint()

		if self.hud then
			if CURRENT_HPBAR_STYLE == HPBAR_STYLE.BAR then
				if self.hud.ui then
					self.hud.ui:removeSelf()
				end
			else
				self.hud.hpbarLow:removeSelf()
				self.hud.hpbarHigh:removeSelf()
			end

			self.hud = nil
		end
	end

	CombatUnit.super.onExit(self)
end

function CombatUnit:getBladeColor(bladeLayer, params, alpha)
	local skillData = self.casting.skillData

	if skillData then
		local colorStr = skillData["blade_color_" .. bladeLayer]

		if not empty(colorStr) then
			local colorArr1 = string.split(colorStr, ",")
			local fillColor = cc.c4f(tonumber(colorArr1[1]) / 255, tonumber(colorArr1[2]) / 255, tonumber(colorArr1[3]) / 255, alpha)

			return fillColor
		end
	end

	return CombatUnit.super.getBladeColor(self, i, params, alpha)
end

return CombatUnit
