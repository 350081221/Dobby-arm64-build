local InfoGather = {}
local rawData = {}

function InfoGather.init()
	Connection.listen("gather_sync", InfoGather.sync)
end

app:addToAppEnterCall(InfoGather.init)

function InfoGather.query(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ gather_query")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoGather.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("gather_query", callback)
end

function InfoGather.onQuery(rcvData)
	rawData = {}

	for i, data in ipairs(rcvData.list) do
		rawData[tostring(data.gather_id)] = data
	end
end

function InfoGather.sync(data)
	dump(data, "$$$ InfoGather.sync")

	local changedIdStack = {}

	for i, syncData in ipairs(data.list) do
		local gather_id = tostring(syncData.gather_id)

		if not rawData[gather_id] then
			rawData[gather_id] = syncData
		else
			for k, v in pairs(syncData) do
				rawData[gather_id][k] = v
			end
		end

		changedIdStack[gather_id] = rawData[gather_id]
	end

	ManagerInfo.dataChange("gather", changedIdStack, "gather_id")
end

function InfoGather.isMarked(gather_id)
	return rawData[tostring(gather_id)] ~= nil
end

return InfoGather
