local UIFont = class("UIFont", function (title, tag, fontIndexArray)
	return display.newBatchNode(UIManager.getGroupTexture("font"))
end)

function UIFont:ctor(title, prefix, str, xSpace)
	self:setTouchSwallowEnabled(false)
	self:setCascadeOpacityEnabled(true)
	event_listener.extendMethods(self, true)

	self.title = title
	self.prefix = prefix
	self.xSpace = xSpace or 0

	if str ~= nil then
		self:setString(str)
	end

	self.tweenID = 0
end

function UIFont:setString(str)
	if self.chars ~= nil then
		for i = 1, #self.chars do
			local char = self.chars[i]

			char:removeSelf()
		end
	end

	local totalWidth = 0
	local comDatas = {}

	for i = 1, string.len(str) do
		local char = string.sub(str, i, i)
		local tag = self.prefix .. char
		local comData = UIManager.getComponentData(self.title, tag)

		if comData ~= nil then
			table.insert(comDatas, comData)

			totalWidth = totalWidth + comData.width + self.xSpace
		end
	end

	self.chars = {}
	local totalAdd = 0

	for i = 1, #comDatas do
		local comData = comDatas[i]
		local char = display.newSprite(UIManager.getGroupedPicurl(comData.origin.pic))

		char:setPositionX(totalAdd - totalWidth / 2 + comData.width / 2)
		self:addChild(char)
		table.insert(self.chars, char)

		totalAdd = totalAdd + comData.width + self.xSpace
	end

	self.width = totalAdd
end

function UIFont:update(step)
	if self.scaleNum ~= nil then
		self:setScale(self.scaleNum)
	end

	if self.alpha ~= nil then
		self:setOpacity(self.alpha)
	end

	if self.x ~= nil and self.y ~= nil then
		self:setPosition(self.x, self.y)
	elseif self.x ~= nil then
		self:setPositionX(self.x)
	elseif self.y ~= nil then
		self:setPositionY(self.y)
	end
end

function UIFont:jumpIn(holding)
	self.scaleNum = 1
	self.actHolding = holding or 30

	tween.stop(self.tweenID)

	self.tweenID = tween(10, self, {
		scaleNum = 1.5
	}, "outQuad", handler(self, self.jumpIn1))
end

function UIFont:jumpIn1()
	tween.stop(self.tweenID)

	self.tweenID = tween(5, self, {
		scaleNum = 1
	}, "inQuad", handler(self, self.jumpOutDelay))
end

function UIFont:jumpOutDelay()
	tween.stop(self.tweenID)

	self.tweenID = tween(self.actHolding, self, {}, "linear", handler(self, self.jumpOut))
end

function UIFont:jumpOut()
	tween.stop(self.tweenID)

	self.tweenID = tween(10, self, {
		scaleNum = 0
	}, "outQuad", handler(self, self.jumpFinish))
end

function UIFont:jumpFinish()
	tween.stop(self.tweenID)
	self:dispatchEvent({
		name = "OVER"
	})
end

function UIFont:jumpAndFade(holding)
	self.scaleNum = 0
	self.alpha = 255

	self:update()

	self.actHolding = holding or 30

	tween.stop(self.tweenID)

	self.tweenID = tween(10, self, {
		scaleNum = 1
	}, "outQuad", handler(self, self.jumpAndFade1))
end

function UIFont:jumpAndFade1()
	tween.stop(self.tweenID)

	self.tweenID = tween(self.actHolding, self, {}, "linear", handler(self, self.jumpAndFade2))
end

function UIFont:jumpAndFade2()
	tween.stop(self.tweenID)

	self.tweenID = tween(15, self, {
		alpha = 0
	}, "outQuad", handler(self, self.jumpAndFadeFinish))
end

function UIFont:jumpAndFadeFinish()
	tween.stop(self.tweenID)
	self:dispatchEvent({
		name = "OVER"
	})
end

function UIFont:moveAndFade(distance, holding)
	self.y = self:getPositionY()
	self.alpha = 0

	self:update()

	self.actHolding = holding or 30

	tween.stop(self.tweenID)

	self.tweenID = tween(20, self, {
		alpha = 255,
		y = self.y + distance
	}, "linear", handler(self, self.moveAndFade1))
end

function UIFont:moveAndFade1()
	tween.stop(self.tweenID)

	self.tweenID = tween(self.actHolding, self, {}, "linear", handler(self, self.moveAndFade2))
end

function UIFont:moveAndFade2()
	tween.stop(self.tweenID)

	self.tweenID = tween(15, self, {
		alpha = 0
	}, "outQuad", handler(self, self.moveAndFadeFinish))
end

function UIFont:moveAndFadeFinish()
	tween.stop(self.tweenID)
	self:dispatchEvent({
		name = "OVER"
	})
end

function UIFont:seal(scale, time, interval, fadeOutTime, fadeOutDelay)
	time = time or 0.1
	interval = interval or 0.05
	scale = scale or 2
	fadeOutTime = fadeOutTime or 0.2
	fadeOutDelay = fadeOutDelay or 0.1

	for i = 1, #self.chars do
		local char = self.chars[i]

		char:setScale(scale)
		char:setOpacity(0)
		transition.scaleTo(char, {
			scale = 1,
			easing = "sineIn",
			time = time,
			delay = interval * (i - 1)
		})

		if i == #self.chars then
			local function fadeAndDestroy()
				transition.fadeOut(self, {
					easing = "sineIn",
					time = fadeOutTime,
					delay = fadeOutDelay,
					onComplete = handler(self, self.destroy)
				})
			end

			transition.fadeIn(char, {
				time = time,
				delay = interval * (i - 1),
				onComplete = fadeAndDestroy
			})
		else
			transition.fadeIn(char, {
				time = time,
				delay = interval * (i - 1)
			})
		end
	end
end

function UIFont:destroy()
	self:removeAllEventListeners()
	self:removeSelf()
end

return UIFont
