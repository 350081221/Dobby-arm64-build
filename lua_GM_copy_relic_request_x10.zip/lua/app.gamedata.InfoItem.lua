local InfoItem = {}
local rawData = {}

function InfoItem.init()
	Connection.listen("item_sync", InfoItem.sync)
end

app:addToAppEnterCall(InfoItem.init)

function InfoItem.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			rawData = {}

			for i = 1, #rcvData.list do
				local data = rcvData.list[i]
				rawData[data.base_id] = data
			end

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("item_query", callback)
end

function InfoItem.sync(data)
	local changedIdStack = {}
	local changedMap = {}

	for i, syncData in ipairs(data.list) do
		local base_id = syncData.base_id

		if CONFIG.is_ta then
			local itemCSV = CsvParser.getCsvData("item", base_id, nil, true)

			if itemCSV and itemCSV.item_track == 1 and syncData.num then
				local changedValue = nil

				if rawData[base_id] then
					changedValue = syncData.num - rawData[base_id].num
				else
					changedValue = syncData.num
				end

				changedMap[base_id] = (changedMap[base_id] or 0) + changedValue
			end
		end

		if not rawData[base_id] then
			rawData[base_id] = syncData
		else
			for k, v in pairs(syncData) do
				rawData[base_id][k] = v
			end
		end

		changedIdStack[base_id] = rawData[base_id]
	end

	if CONFIG.is_ta and table.nums(changedMap) > 0 then
		TaHelper.onItemSync(changedMap)
	end

	ManagerInfo.dataChange("item", changedIdStack, "base_id")
end

function InfoItem.getRawData()
	return rawData
end

function InfoItem.getGemComposeInWare()
	local list = InfoItem.getWareList(nil, function (a)
		local itemData = CsvParser.getCsvData("item", a.info.base_id)

		return itemData.type_page == 1
	end, function (a, b)
		local dataA = CsvParser.getCsvData("item", a.info.base_id)
		local dataB = CsvParser.getCsvData("item", b.info.base_id)
		local pageIndexA = dataA.page_index == "" and 0 or dataA.page_index
		local pageIndexB = dataB.page_index == "" and 0 or dataB.page_index

		if pageIndexA == pageIndexB then
			if dataA.quality == dataB.quality then
				return a.info.base_id < b.info.base_id
			else
				return dataB.quality < dataA.quality
			end
		else
			return pageIndexA < pageIndexB
		end
	end)

	for i, v in ipairs(list) do
		local itemData = CsvParser.getCsvData("item", v.info.base_id)

		if itemData.type == 4 and InfoItem.isCompose(itemData) then
			local num = InfoItem.getNum(itemData.id)

			if itemData.compose_num <= num then
				return i
			end
		end
	end
end

function InfoItem.getWareList(types, filterFunc, sortFunc)
	local sortList = {}
	local typeCheckMap = nil

	if types then
		if type(types) == "table" then
			typeCheckMap = {}

			for i, v in ipairs(types) do
				typeCheckMap[v] = true
			end
		else
			typeCheckMap = {
				[types] = true
			}
		end
	end

	for id, itemInfo in pairs(rawData) do
		local newItemInfo = itemInfo

		if InfoItem.isGrowth(itemInfo.base_id) then
			newItemInfo = ObjUtil.copy(itemInfo)
			newItemInfo.num = InfoItem.getNum(itemInfo.base_id)
		end

		local tempData = {
			type = DropManager.TYPE.ITEM,
			info = newItemInfo
		}
		local itemData = CsvParser.getCsvData("item", newItemInfo.base_id)

		if itemData then
			local typeCheck = typeCheckMap == nil or typeCheckMap[itemData.type]

			if typeCheck and (not filterFunc or filterFunc(tempData)) and newItemInfo.num > 0 then
				table.insert(sortList, tempData)
			end
		end
	end

	table.sort(sortList, sortFunc or function (a, b)
		local dataA = CsvParser.getCsvData("item", a.info.base_id)
		local dataB = CsvParser.getCsvData("item", b.info.base_id)

		if dataA.quality == dataB.quality then
			return a.info.base_id < b.info.base_id
		else
			return dataB.quality < dataA.quality
		end
	end)

	return sortList
end

function InfoItem.getList(types, subtype)
	local sortList = {}

	for id, itemInfo in pairs(rawData) do
		local itemData = CsvParser.getCsvData("item", itemInfo.base_id)

		if itemData then
			local typeCheck = false

			if types == nil then
				typeCheck = true
			elseif type(types) == "table" then
				for i, v in ipairs(types) do
					if v == itemData.type then
						typeCheck = true

						break
					end
				end
			else
				typeCheck = types == itemData.type
			end

			if itemData and typeCheck and (subtype == nil or itemData.subtype == subtype) and (itemData.show_empty == 1 or InfoItem.getNum(itemInfo.base_id) > 0) then
				table.insert(sortList, itemInfo)
			end
		end
	end

	local function sortMethod(a, b)
		return a.base_id < b.base_id
	end

	table.sort(sortList, sortMethod)

	return sortList
end

function InfoItem.isGrowth(baseID)
	local index = GameConfig.item_growth_map[baseID]

	return index ~= nil
end

function InfoItem.getGrowth(baseID)
	local row = rawData[baseID]

	if row then
		return row.num, row.growth, row.growth_time
	else
		local now = Time.now()

		return 0, 0, now
	end
end

function InfoItem.getGrowthMax(baseID)
	local index = GameConfig.item_growth_map[baseID]

	if index then
		local buildingCSV = InfoBuilding.getBuildingData(InfoBuilding.TAG.STORAGE)
		local growthMax = buildingCSV["value" .. index]

		return growthMax
	end
end

function InfoItem.checkPermitItem(baseID)
	if empty(baseID) or InfoItem.getNum(baseID) > 0 then
		return true
	end

	return false
end

function InfoItem.getNum(baseID)
	local itemData = CsvParser.getCsvData("item", baseID)

	if not itemData then
		return 0
	end

	local index = GameConfig.item_growth_map[baseID]

	if index then
		local num, growth, growth_time = InfoItem.getGrowth(baseID)

		if growth > 0 then
			local buildingCSV = InfoBuilding.getBuildingData(InfoBuilding.TAG.STORAGE)
			local growthMax = buildingCSV["value" .. index]

			if num < growthMax then
				local nowTime = Time.now()
				local timeOffset = math.max(0, nowTime - growth_time)
				local newNum = math.min(growthMax, num + math.floor(growth * timeOffset / Time.SECONDS_PER_HOUR))
				num = newNum
			end
		end

		return num
	else
		local row = rawData[baseID]
		local num = 0

		if row then
			num = row.num
		else
			num = 0
		end

		return num
	end
end

function InfoItem.getFullTimeLeft(baseID)
	local row = rawData[baseID]
	local num = 0

	if row then
		num = row.num
	else
		num = 0
	end

	local itemData = CsvParser.getCsvData("item", baseID)

	if not itemData then
		return 0
	end

	return nil
end

function InfoItem.getResourceList()
	local resourceList = CsvParser.getCsvList("item", "resource_index", {
		is_resource = 1
	})

	return resourceList
end

function InfoItem.getItemInfo(baseID)
	return rawData[baseID]
end

local function checkDistance(unit, mapX, mapY)
	local distance = math.sqrt(math.pow(unit.x - mapX, 2) + math.pow(unit.y - mapY, 2))

	return distance <= 196
end

function InfoItem.getUseTarget(itemID, mapX, mapY)
	local select_type = 0
	local affectUnits = nil
	local hasTarget = true
	local itemData = CsvParser.getCsvData("item", itemID)

	if itemData.use_type == 1 or itemData.use_type == 2 then
		if itemData.use_type == 1 then
			select_type = 1
		else
			select_type = 0
		end

		local heros = ClipOnMap.getUnitList("hero")
		affectUnits = {}

		for i, hero in ipairs(heros) do
			if hero.battleData.hp < hero.attrs.hp then
				table.insert(affectUnits, hero)
			end
		end

		hasTarget = #affectUnits > 0
	elseif itemData.use_type == 3 then
		select_type = 1
		affectUnits = ClipOnMap.getUnitList("hero")
	elseif itemData.use_type == 6 then
		select_type = 2
	elseif itemData.use_type == 7 then
		select_type = 1
		local heros = ClipOnMap.getUnitList("hero")
		affectUnits = {}

		for i, hero in ipairs(heros) do
			if hero.battleData.die then
				table.insert(affectUnits, hero)
			end
		end

		hasTarget = #affectUnits > 0
	elseif itemData.use_type == 21 then
		if itemData.use_value1 == 1 then
			select_type = 1
		else
			select_type = 0
		end

		local heros = ClipOnMap.getUnitList("hero")
		affectUnits = {}

		for i, hero in ipairs(heros) do
			if hero.battleData.hp < hero.attrs.hp then
				table.insert(affectUnits, hero)
			end
		end

		hasTarget = #affectUnits > 0
	elseif itemData.use_type == 22 then
		select_type = 0
	elseif itemData.use_type == 23 then
		select_type = 0

		if InfoModao.getMpMax() <= InfoDungeon.getModaoMP() then
			hasTarget = false
		end
	elseif itemData.use_type == 24 then
		select_type = 0
	elseif itemData.use_type == 25 then
		select_type = 0
	elseif itemData.use_type == 26 then
		select_type = 1
		local npcs = ClipOnMap.getUnitList("npc")
		affectUnits = {}

		for i, npc in ipairs(npcs) do
			if npc.npcType == Npc.TYPE.RELIC and npc.data.type == 9 and npc:isInteractive() and not npc:isHidden() and checkDistance(npc, mapX, mapY) then
				table.insert(affectUnits, npc)
			end
		end

		hasTarget = #affectUnits > 0
	else
		hasTarget = false
	end

	return select_type, affectUnits, hasTarget, itemData
end

function InfoItem.use(item_id, item_num, bag_index, target_id, onSuccess, onFailure, params)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if InfoDungeon.inDungeon() then
				local stageType, stageID = InfoDungeon.getStage()

				TaHelper.taTrack("item_use", {
					item_id = item_id,
					item_num = item_num,
					dungeon_type = InfoDungeon.getType(),
					dungeon_level = InfoDungeon.getLevel(),
					stage_id = stageID
				})
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	local requestParams = {
		item_id = item_id,
		item_num = item_num,
		bag_index = bag_index,
		target_id = target_id
	}

	if params then
		requestParams.params = json.encode(params)
	end

	Connection.request("item_use", requestParams, callback)
end

function InfoItem.isCompose(itemData)
	if not empty(itemData.compose_num) and not empty(itemData.compose_type) and not empty(itemData.compose_id) then
		return true
	end
end

function InfoItem.compose(item_id, bag_index, num, onSuccess, onFailure)
	local itemData = CsvParser.getCsvData("item", item_id)

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if onSuccess then
				onSuccess(rcvData)
			end

			local rewardList = {}

			if itemData.compose_type == 2 then
				for i, v in ipairs(rcvData.item_list) do
					table.insert(rewardList, {
						type = DropManager.TYPE.ITEM,
						info = v
					})
				end
			elseif itemData.compose_type == 3 then
				for i, v in ipairs(rcvData.card_list) do
					table.insert(rewardList, {
						type = DropManager.TYPE.CARD,
						info = v
					})
				end
			end

			if #rewardList > 0 then
				POP_reward.open(rewardList, onClose, Localization.getSrcText("合成成功"))
			end
		end
	end

	Connection.request("item_compose", {
		item_id = item_id,
		bag_index = bag_index,
		num = num
	}, callback)
end

function InfoItem.isSeparate(itemData)
	if not empty(itemData.separate_num) and not empty(itemData.separate_id) then
		return true
	end
end

function InfoItem.separate(item_id, bag_index, onSuccess, onFailure)
	local itemData = CsvParser.getCsvData("item", item_id)

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if onSuccess then
				onSuccess(rcvData)
			end

			local rewardList = {}

			for i, v in ipairs(rcvData.item_list) do
				table.insert(rewardList, {
					type = DropManager.TYPE.ITEM,
					info = v
				})
			end

			if #rewardList > 0 then
				POP_reward.open(rewardList, onClose, Localization.getSrcText("分解成功"))
			end
		end
	end

	Connection.request("item_separate", {
		item_id = item_id,
		bag_index = bag_index
	}, callback)
end

function InfoItem.isChoose(itemData)
	if not empty(itemData.choose_items) and not empty(itemData.choose_num) then
		return true
	end
end

function InfoItem.choose(item_id, bag_index, choose_item, num, onSuccess, onFailure)
	print("$$$ InfoItem.choose", item_id, bag_index, choose_item, num)

	local itemData = CsvParser.getCsvData("item", item_id)

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if onSuccess then
				onSuccess(rcvData)
			end

			local rewardList = {}

			for i, v in ipairs(rcvData.item_list) do
				table.insert(rewardList, {
					type = DropManager.TYPE.ITEM,
					info = v
				})
			end

			if #rewardList > 0 then
				POP_reward.open(rewardList, onClose, Localization.getSrcText("获得物品"))
			end
		end
	end

	Connection.request("item_choose", {
		item_id = item_id,
		bag_index = bag_index,
		choose_item = choose_item,
		num = num
	}, callback)
end

function InfoItem.isUsedrop(itemData)
	if not empty(itemData.use_drop) then
		return true
	end
end

function InfoItem.usedrop(item_id, bag_index, num, onSuccess, onFailure)
	local itemData = CsvParser.getCsvData("item", item_id)

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if onSuccess then
				onSuccess(rcvData)
			end

			local rewards = rcvData.rewards

			if rewards and #rewards > 0 then
				POP_reward.openMixed(rewards, nil, Localization.getSrcText("获得物品"))
			end
		end
	end

	Connection.request("item_usedrop", {
		item_id = item_id,
		bag_index = bag_index,
		num = num or 1
	}, callback)
end

function InfoItem.getDropCheckList()
	local csvRaw = CsvParser.getCsvRaw("item")
	local abyssLevel = InfoDungeon.getAbyssMaxLevel()
	local arr = {}

	for k, csv in pairs(csvRaw) do
		if csv.is_precious == 1 and csv.drop_level_min <= abyssLevel and InfoItem.getNum(csv.id) == 0 then
			table.insert(arr, csv.id)
		end
	end

	return arr
end

function InfoItem.dropCheck(arr, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("item_drop_check", {
		list = arr
	}, callback)
end

function InfoItem.checkCost(costArr)
	local enough = true
	local lackArr = {}
	local lackStr = ""

	for i, v in ipairs(costArr) do
		local itemID = v.base_id or v.id
		local itemNum = v.num
		local currentNum = InfoItem.getNum(itemID)

		if currentNum < itemNum then
			enough = false

			table.insert(lackArr, {
				base_id = itemID,
				num = itemNum - currentNum
			})

			local itemData = CsvParser.getCsvData("item", itemID)

			if lackStr ~= "" then
				lackStr = lackStr .. ","
			end

			lackStr = lackStr .. itemData.name .. "x" .. itemNum - currentNum
		end
	end

	if not enough then
		return false, lackArr, lackStr
	end

	return true
end

function InfoItem.getNameDisplay(itemInfo)
	local itemData = CsvParser.getCsvData("item", itemInfo.base_id)
	local name = itemData.name
	local style = {
		color = InfoHero.getQualityColor(itemData.quality)
	}

	return name, style, itemData.quality
end

function InfoItem.getConvertID(itemID)
	local itemData = CsvParser.getCsvData("item", itemID)

	if empty(itemData.convert_item) then
		return itemID
	else
		return itemData.convert_item
	end
end

function InfoItem.isPrecious(itemID)
	local itemData = CsvParser.getCsvData("item", itemID)

	return itemData.is_precious == 1
end

function InfoItem.getItemGem(itemID)
	local itemData = CsvParser.getCsvData("item", itemID)
	local gemData = CsvParser.getCsvData("gem", itemData.use_value1)

	return gemData
end

function InfoItem.getGemUpgradeItem(itemID)
	local gemUpgradeItemMap = CacheData.get("InfoItem_gemUpgradeItemMap")

	if not gemUpgradeItemMap then
		gemUpgradeItemMap = {}
		local csvRaw = CsvParser.getCsvRaw("item")

		for k, csv in pairs(csvRaw) do
			if csv.type == 4 then
				local gemCSV = CsvParser.getCsvData("gem", csv.use_value1)

				if not empty(gemCSV.compose_item) then
					gemUpgradeItemMap[gemCSV.compose_item] = csv.id
				end
			end
		end

		CacheData.set("InfoItem_gemUpgradeItemMap", gemUpgradeItemMap)
	end

	return gemUpgradeItemMap[itemID]
end

function InfoItem.getGemComposeList()
	local arr = {}
	local buildingData = InfoBuilding.getBuildingData(InfoBuilding.TAG.FORGE)
	local csvList = CsvParser.getCsvList("gem")

	for i, csv in ipairs(csvList) do
		if not empty(csv.compose_item) and not empty(csv.compose_num) and buildingData and not empty(buildingData.value2) and csv.level <= buildingData.value2 then
			local num = InfoItem.getNum(csv.compose_item)

			if csv.compose_num <= num then
				table.insert(arr, {
					gem_id = csv.id,
					item = {
						base_id = csv.compose_item,
						num = num
					}
				})
			end
		end
	end

	table.sort(arr, function (a, b)
		local gemA = CsvParser.getCsvData("gem", a.gem_id)
		local gemB = CsvParser.getCsvData("gem", b.gem_id)

		if gemA.level == gemB.level then
			return a.gem_id < b.gem_id
		else
			return gemA.level < gemB.level
		end
	end)

	return arr
end

function InfoItem.getGemComposeBatch(underLevel)
	local csvList = CsvParser.getCsvList("gem")
	local gemMap = {}
	local initMap = {}
	local composeMap = {}

	for i, csv in ipairs(csvList) do
		if not empty(csv.compose_item) and not empty(csv.compose_num) and csv.level <= underLevel then
			local num = InfoItem.getNum(csv.compose_item)
			gemMap[csv.compose_item] = num
			initMap[csv.compose_item] = num
			composeMap[csv.compose_item] = csv.id
		end
	end

	local composeLoop = 0
	local composeCount = 0

	while true do
		local none = true

		for base_id, num in pairs(gemMap) do
			local gemID = composeMap[base_id]

			if gemID then
				local csv = CsvParser.getCsvData("gem", gemID)

				if csv.compose_num <= num then
					local composeTimes = math.floor(num / csv.compose_num)
					gemMap[gemID] = (gemMap[gemID] or 0) + composeTimes
					gemMap[base_id] = gemMap[base_id] - composeTimes * csv.compose_num
					composeCount = composeCount + 1
					none = false
				end
			end
		end

		composeLoop = composeLoop + 1

		if none then
			break
		end
	end

	print("递归次数", composeLoop, composeCount)

	local beforeArr = {}
	local afterArr = {}

	for base_id, num in pairs(gemMap) do
		local initNum = initMap[base_id] or 0

		if num > initNum then
			table.insert(afterArr, {
				type = DropManager.TYPE.ITEM,
				info = {
					base_id = base_id,
					num = num - initNum
				}
			})
		elseif num < initNum then
			table.insert(beforeArr, {
				type = DropManager.TYPE.ITEM,
				info = {
					base_id = base_id,
					num = initNum - num
				}
			})
		end
	end

	table.sort(beforeArr, function (a, b)
		local gemA = CsvParser.getCsvData("gem", a.info.base_id)
		local gemB = CsvParser.getCsvData("gem", b.info.base_id)

		if gemA.level == gemB.level then
			return a.info.base_id < b.info.base_id
		else
			return gemA.level < gemB.level
		end
	end)
	table.sort(afterArr, function (a, b)
		local gemA = CsvParser.getCsvData("gem", a.info.base_id)
		local gemB = CsvParser.getCsvData("gem", b.info.base_id)

		if gemA.level == gemB.level then
			return a.info.base_id < b.info.base_id
		else
			return gemB.level < gemA.level
		end
	end)

	return beforeArr, afterArr
end

function InfoItem.composeGem(gem_id, onSuccess, onFailure, num)
	local function callback(rcvData)
		dump(rcvData, "$$$ item_compose_gem")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("item_compose_gem", {
		gem_id = gem_id,
		num = num
	}, callback)
end

function InfoItem.composeGemBatch(underLevel, initItems, onSuccess, onFailure)
	local csvList = CsvParser.getCsvList("gem")
	local next = nil
	local rewardsAllMap = {}

	for i, v in ipairs(initItems) do
		rewardsAllMap[v.info.base_id] = (rewardsAllMap[v.info.base_id] or 0) + v.info.num
	end

	function next()
		local gemMap = {}
		local composeMap = {}

		for i, csv in ipairs(csvList) do
			if not empty(csv.compose_item) and not empty(csv.compose_num) and csv.level <= underLevel then
				local num = InfoItem.getNum(csv.compose_item)

				if csv.compose_num <= num then
					num = math.floor(num / csv.compose_num) * csv.compose_num
					gemMap[csv.compose_item] = num
				end

				composeMap[csv.compose_item] = csv.id
			end
		end

		local gem_id, gem_num = nil

		for base_id, num in pairs(gemMap) do
			local gemID = composeMap[base_id]

			if gemID then
				local csv = CsvParser.getCsvData("gem", gemID)

				if csv.compose_num <= num then
					gem_id = gemID
					gem_num = math.floor(num / csv.compose_num)

					break
				end
			end
		end

		print("$$$ gem_id", gem_id, gem_num)

		if gem_id and gem_num then
			local function onComposeComplete(rcvData)
				local csv = CsvParser.getCsvData("gem", gem_id)
				rewardsAllMap[csv.compose_item] = (rewardsAllMap[csv.compose_item] or 0) - csv.compose_num * gem_num
				local rewards = rcvData.rewards

				if rewards and #rewards > 0 then
					for i, v in ipairs(rewards) do
						rewardsAllMap[v.item_id] = (rewardsAllMap[v.item_id] or 0) + v.item_num
					end
				end

				next()
			end

			InfoItem.composeGem(gem_id, onComposeComplete, onFailure, gem_num)
		else
			local rewards = {}

			for base_id, num in pairs(rewardsAllMap) do
				if num ~= 0 then
					table.insert(rewards, {
						type = DropManager.TYPE.ITEM,
						item_id = base_id,
						item_num = num
					})
				end
			end

			table.sort(rewards, function (a, b)
				local gemA = CsvParser.getCsvData("gem", a.item_id)
				local gemB = CsvParser.getCsvData("gem", b.item_id)

				if gemA.level == gemB.level then
					return a.item_id < b.item_id
				else
					return gemA.level < gemB.level
				end
			end)
			onSuccess({
				rewards = rewards
			})
		end
	end

	next()
end

function InfoItem.getPetEquipComposeList()
	local arr = {}
	local buildingData = InfoBuilding.getBuildingData(InfoBuilding.TAG.PET)
	local csvList = CsvParser.getCsvList("pet_equip")

	for i, csv in ipairs(csvList) do
		if not empty(csv.compose_item) and not empty(csv.compose_num) and buildingData and not empty(buildingData.value5) and csv.level <= buildingData.value5 then
			local num = InfoItem.getNum(csv.compose_item)

			if csv.compose_num <= num then
				table.insert(arr, {
					pet_equip_id = csv.id,
					item = {
						base_id = csv.compose_item,
						num = num
					},
					cost = csv.compose_cost
				})
			end
		end
	end

	table.sort(arr, function (a, b)
		local csvA = CsvParser.getCsvData("pet_equip", a.pet_equip_id)
		local csvB = CsvParser.getCsvData("pet_equip", b.pet_equip_id)

		if csvA.level == csvB.level then
			return a.pet_equip_id < b.pet_equip_id
		else
			return csvA.level < csvB.level
		end
	end)

	return arr
end

function InfoItem.getPetEquipComposeBatch(underLevel)
	local csvList = CsvParser.getCsvList("pet_equip")
	local gemMap = {}
	local initMap = {}
	local composeMap = {}

	for i, csv in ipairs(csvList) do
		if not empty(csv.compose_item) and not empty(csv.compose_num) and csv.level <= underLevel then
			local num = InfoItem.getNum(csv.compose_item)
			gemMap[csv.compose_item] = num
			initMap[csv.compose_item] = num
			composeMap[csv.compose_item] = csv.id
		end
	end

	local composeLoop = 0
	local composeCount = 0
	local costID = nil
	local costTotal = 0

	while true do
		local none = true

		for base_id, num in pairs(gemMap) do
			local gemID = composeMap[base_id]

			if gemID then
				local csv = CsvParser.getCsvData("pet_equip", gemID)

				if csv.compose_num <= num then
					local composeTimes = math.floor(num / csv.compose_num)
					gemMap[gemID] = (gemMap[gemID] or 0) + composeTimes
					gemMap[base_id] = gemMap[base_id] - composeTimes * csv.compose_num
					composeCount = composeCount + 1
					costID = csv.compose_cost
					costTotal = costTotal + csv.compose_cost_num * composeTimes
					none = false
				end
			end
		end

		composeLoop = composeLoop + 1

		if none then
			break
		end
	end

	print("递归次数", composeLoop, composeCount)

	local beforeArr = {}
	local afterArr = {}

	for base_id, num in pairs(gemMap) do
		local initNum = initMap[base_id] or 0

		if num > initNum then
			table.insert(afterArr, {
				type = DropManager.TYPE.ITEM,
				info = {
					base_id = base_id,
					num = num - initNum
				}
			})
		elseif num < initNum then
			table.insert(beforeArr, {
				type = DropManager.TYPE.ITEM,
				info = {
					base_id = base_id,
					num = initNum - num
				}
			})
		end
	end

	table.sort(beforeArr, function (a, b)
		local gemA = CsvParser.getCsvData("pet_equip", a.info.base_id)
		local gemB = CsvParser.getCsvData("pet_equip", b.info.base_id)

		if gemA.level == gemB.level then
			return a.info.base_id < b.info.base_id
		else
			return gemA.level < gemB.level
		end
	end)
	table.sort(afterArr, function (a, b)
		local gemA = CsvParser.getCsvData("pet_equip", a.info.base_id)
		local gemB = CsvParser.getCsvData("pet_equip", b.info.base_id)

		if gemA.level == gemB.level then
			return a.info.base_id < b.info.base_id
		else
			return gemB.level < gemA.level
		end
	end)

	return beforeArr, afterArr, {
		base_id = costID,
		num = costTotal
	}
end

function InfoItem.composePetEquip(pet_equip_id, onSuccess, onFailure, num)
	local function callback(rcvData)
		dump(rcvData, "$$$ item_compose_pet_equip")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("item_compose_pet_equip", {
		pet_equip_id = pet_equip_id,
		num = num
	}, callback)
end

function InfoItem.composePetEquipBatch(underLevel, initItems, onSuccess, onFailure)
	local csvList = CsvParser.getCsvList("pet_equip")
	local next = nil
	local rewardsAllMap = {}

	for i, v in ipairs(initItems) do
		rewardsAllMap[v.info.base_id] = (rewardsAllMap[v.info.base_id] or 0) + v.info.num
	end

	function next()
		local equipMap = {}
		local composeMap = {}

		for i, csv in ipairs(csvList) do
			if not empty(csv.compose_item) and not empty(csv.compose_num) and csv.level <= underLevel then
				local num = InfoItem.getNum(csv.compose_item)

				if csv.compose_num <= num then
					num = math.floor(num / csv.compose_num) * csv.compose_num
					equipMap[csv.compose_item] = num
				end

				composeMap[csv.compose_item] = csv.id
			end
		end

		local equip_id, equip_num = nil

		for base_id, num in pairs(equipMap) do
			local equipID = composeMap[base_id]

			if equipID then
				local csv = CsvParser.getCsvData("pet_equip", equipID)

				if csv.compose_num <= num then
					equip_id = equipID
					equip_num = math.floor(num / csv.compose_num)

					break
				end
			end
		end

		print("$$$ equip_id", equip_id, equip_num)

		if equip_id and equip_num then
			local function onComposeComplete(rcvData)
				local csv = CsvParser.getCsvData("pet_equip", equip_id)
				rewardsAllMap[csv.compose_item] = (rewardsAllMap[csv.compose_item] or 0) - csv.compose_num * equip_num
				local rewards = rcvData.rewards

				if rewards and #rewards > 0 then
					for i, v in ipairs(rewards) do
						rewardsAllMap[v.item_id] = (rewardsAllMap[v.item_id] or 0) + v.item_num
					end
				end

				next()
			end

			InfoItem.composePetEquip(equip_id, onComposeComplete, onFailure, equip_num)
		else
			local rewards = {}

			for base_id, num in pairs(rewardsAllMap) do
				if num ~= 0 then
					table.insert(rewards, {
						type = DropManager.TYPE.ITEM,
						item_id = base_id,
						item_num = num
					})
				end
			end

			table.sort(rewards, function (a, b)
				local equipA = CsvParser.getCsvData("pet_equip", a.item_id)
				local equipB = CsvParser.getCsvData("pet_equip", b.item_id)

				if equipA.level == equipB.level then
					return a.item_id < b.item_id
				else
					return equipA.level < equipB.level
				end
			end)
			onSuccess({
				rewards = rewards
			})
		end
	end

	next()
end

function InfoItem.mixItemArr(...)
	local arrStack = {
		...
	}
	local costMap = {}

	for j, costArr in ipairs(arrStack) do
		for i, v in ipairs(costArr) do
			costMap[v.base_id] = (costMap[v.base_id] or 0) + v.num
		end
	end

	local newCostArr = {}

	for base_id, num in pairs(costMap) do
		table.insert(newCostArr, {
			base_id = base_id,
			num = num
		})
	end

	table.sort(newCostArr, function (a, b)
		return a.base_id < b.base_id
	end)

	return newCostArr
end

return InfoItem
