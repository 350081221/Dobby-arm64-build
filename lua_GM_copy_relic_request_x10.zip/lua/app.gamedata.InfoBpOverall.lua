local InfoBpOverall = {}
local rawData = {}

function InfoBpOverall.init()
	Connection.listen("bp_overall_sync", InfoBpOverall.sync)
end

app:addToAppEnterCall(InfoBpOverall.init)

function InfoBpOverall.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoBpOverall.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("bp_overall_query", callback)
end

function InfoBpOverall.onQuery(rcvData)
	dump(rcvData, "bp_overall_query")

	rawData = rcvData
end

function InfoBpOverall.sync(data)
	dump(data, "$$$ InfoBpOverall.sync")

	for k, v in pairs(data) do
		rawData[k] = v
	end

	ManagerInfo.dataChange("bp_overall", data)
end

function InfoBpOverall.getData()
	return rawData
end

return InfoBpOverall
