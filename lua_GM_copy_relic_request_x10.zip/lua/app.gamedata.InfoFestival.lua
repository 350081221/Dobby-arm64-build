local InfoFestival = {}
local current_map = {}
local my_map = {}

function InfoFestival.init()
	Connection.listen("festival_sync", InfoFestival.sync)
end

app:addToAppEnterCall(InfoFestival.init)

function InfoFestival.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoFestival.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("festival_query", callback)
end

function InfoFestival.onQuery(rcvData)
	dump(rcvData, "festival_query")

	my_map = {}
	current_map = {}

	for i, v in ipairs(rcvData.current_list) do
		current_map[v.actv_id] = v.base_id
	end

	for i, v in ipairs(rcvData.list) do
		if v.actv_id and v.base_id then
			my_map[v.actv_id] = v.base_id
		end
	end
end

function InfoFestival.sync(data)
	dump(data, "$$$ InfoFestival.sync")

	if data.current_list then
		current_map = {}

		for i, v in ipairs(data.current_list) do
			current_map[v.actv_id] = v.base_id
		end
	end

	if data.list then
		my_map = {}

		for i, v in ipairs(data.list) do
			if v.actv_id and v.base_id then
				my_map[v.actv_id] = v.base_id
			end
		end
	end

	ManagerInfo.dataChange("festival")
end

function InfoFestival.checkOpeningByActv(actv_id)
	if actv_id then
		local opening = InfoActv.checkBindOpening(actv_id, GameConfig.ACTV_TYPE.festival)

		return opening, actv_id
	end

	return false
end

function InfoFestival.checkShopOpeningByActv(actv_id)
	if actv_id then
		local opening = InfoActv.checkBindShopOpening(actv_id, GameConfig.ACTV_TYPE.festival)

		return opening, actv_id
	end

	return false
end

function InfoFestival.checkOpening(festival_id)
	for actv_id, base_id in pairs(current_map) do
		if base_id == festival_id and InfoFestival.checkOpeningByActv(actv_id) then
			return true, actv_id
		end
	end

	return false
end

function InfoFestival.checkShopOpening(festival_id)
	for actv_id, base_id in pairs(current_map) do
		if base_id == festival_id and InfoFestival.checkShopOpeningByActv(actv_id) then
			return true, actv_id
		end
	end

	return false
end

function InfoFestival.getDataForNPC(npcID, alwaysOpening)
	for actv_id, festival_id in pairs(current_map) do
		local csv = CsvParser.getCsvData("festival", festival_id, nil, true)

		if csv and csv.npc == npcID and (alwaysOpening or InfoFestival.checkShopOpening(festival_id)) then
			return csv
		end
	end
end

function InfoFestival.getNpsListByPos(pos)
	local csvRaw = CsvParser.getCsvRaw("actv_npc")
	local arr = {}

	for id, csv in pairs(csvRaw) do
		if csv.pos == pos then
			local npcID = csv.id
			local festivalCSV = InfoFestival.getDataForNPC(npcID)

			if festivalCSV then
				table.insert(arr, csv.id)
			end
		end
	end

	return arr
end

function InfoFestival.checkCurrent(actv_id)
	if current_map then
		return current_map[actv_id]
	end
end

function InfoFestival.getKanbanDropList(target_id)
	local dropArr = {}

	for actv_id, festival_id in pairs(current_map) do
		if InfoActv.checkOpening(actv_id) and InfoFestival.checkOpening(festival_id) then
			local csv = CsvParser.getCsvData("festival", festival_id)

			if not empty(csv["festival_quest_drop_" .. target_id]) then
				table.insert(dropArr, csv["festival_quest_drop_" .. target_id])
			end
		end
	end

	return dropArr
end

function InfoFestival.useItemSound(item_id, index)
	local csv = CsvParser.getCsvData("festival_item", item_id)
	index = index or 1

	return SheetUtil.getString(csv["sound_" .. index])
end

function InfoFestival.useItem(item_index, item_id, num, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "festival_item_use")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("festival_item_use", {
		item_index = item_index,
		item_id = item_id,
		num = num
	}, callback)
end

function InfoFestival.useItemOver(item_id, onSuccess, onFailure)
	local csv = CsvParser.getCsvData("festival_item", item_id)

	if empty(csv.marquee) then
		return
	end

	local function callback(rcvData)
		dump(rcvData, "festival_item_use_over")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("festival_item_use_over", {
		item_id = item_id
	}, callback)
end

local shopActvID = nil
local shopListMap = {}
local shopRefreshIndex = 0
local shopRefreshTime = nil

function InfoFestival.setShopActvID(actv_id)
	print("$$$ setShopActvID", actv_id)

	shopActvID = actv_id
end

function InfoFestival.getShopLabels()
	return nil
end

function InfoFestival.clearOnReconnect()
	shopListMap = {}
end

function InfoFestival.getShopList(_callback)
	local shopList = shopListMap[shopActvID]
	local needQuery = shopList == nil

	if not shopRefreshTime or Time.checkDayPassed(shopRefreshTime) then
		needQuery = true
	end

	shopRefreshTime = Time.now()

	if needQuery then
		local function callback(rcvData)
			if rcvData.err then
				-- Nothing
			else
				shopRefreshIndex = shopRefreshIndex + 1
				shopListMap[shopActvID] = rcvData.items

				if _callback then
					_callback(shopList)
				end
			end
		end

		Connection.request("festival_shop_list", {
			actv_id = shopActvID
		}, callback)
	else
		_callback(shopList)
	end
end

function InfoFestival.getShopItems()
	local shopList = shopListMap[shopActvID]
	local festivalID = InfoFestival.checkCurrent(shopActvID)

	print("$$$ getShopItems", shopActvID, festivalID)

	local itemArr = {}

	for i, v in ipairs(shopList) do
		local shopCSV = CsvParser.getCsvData("festival_shop", v.shop_id)

		if shopCSV and v.actv_id == shopActvID and shopCSV.festival_id == festivalID then
			table.insert(itemArr, v)
		end
	end

	local soldoutCache = {}

	local function isSoldout(data)
		if not soldoutCache[data.shop_id] then
			local soldout = data.soldout
			local csv = CsvParser.getCsvData("festival_shop", data.shop_id)

			if not empty(csv.item_check) and InfoItem.getNum(csv.item_check) > 0 then
				soldoutCache[data.shop_id] = 2
			elseif not empty(csv.times) and csv.times <= soldout then
				soldoutCache[data.shop_id] = 1
			else
				soldoutCache[data.shop_id] = 0
			end
		end

		return soldoutCache[data.shop_id]
	end

	table.sort(itemArr, function (a, b)
		local soldoutA = isSoldout(a)
		local soldoutB = isSoldout(b)

		if soldoutA == soldoutB then
			return a.shop_id < b.shop_id
		else
			return soldoutA < soldoutB
		end
	end)

	return itemArr
end

function InfoFestival.buy(shop_id, num, onSuccess, onFailure)
	local shopList = shopListMap[shopActvID]
	local preIndex = shopRefreshIndex

	local function callback(rcvData)
		dump(rcvData, "festival_shop_buy")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			local shopCSV = CsvParser.getCsvData("festival_shop", shop_id)
			local costArr = SheetUtil.getColumnList(shopCSV, {
				"cost_id_",
				"cost_num_"
			}, {
				"base_id",
				"num"
			})
			local _costArr = {}

			for i, v in ipairs(costArr) do
				table.insert(_costArr, {
					item_id = v.base_id,
					num = v.num * num
				})
			end

			local params = {
				exchange_item_id = shopCSV.product_id,
				exchange_item_num = shopCSV.product_num * num,
				cost_item_id = _costArr
			}

			TaHelper.taTrack("event_exchange", params)

			if rcvData.item then
				local item = rcvData.item

				if preIndex == shopRefreshIndex then
					for i, v in ipairs(shopList) do
						if v.shop_id == item.shop_id then
							for k1, v1 in pairs(item) do
								v[k1] = v1
							end
						end
					end
				end
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("festival_shop_buy", {
		shop_id = shop_id,
		num = num,
		actv_id = shopActvID
	}, callback)
end

function InfoFestival.getShopCSV()
	return "festival_shop"
end

function InfoFestival.getCostNeed()
	return nil
end

function InfoFestival.getShopName()
	return "festival"
end

function InfoFestival.getShopTime()
	if not empty(shopActvID) then
		local actvData = InfoActv.get(shopActvID)

		if actvData then
			return actvData.shop_time
		end
	end
end

function InfoFestival.getRefreshType()
	return nil
end

function InfoFestival.getRefreshDesc()
	return Localization.getSrcText("距离兑换结束还有")
end

function InfoFestival.getSupplyLabel(csv)
	if csv.refresh_type == 1 then
		return Localization.getSrcText("每日限购")
	elseif csv.refresh_type == 2 then
		return Localization.getSrcText("每周限购")
	else
		return Localization.getSrcText("活动限购")
	end
end

function InfoFestival.getCampItems()
	for actv_id, festival_id in pairs(current_map) do
		if InfoActv.checkOpening(actv_id) and InfoFestival.checkOpening(festival_id) then
			local csv = CsvParser.getCsvData("festival", festival_id)
			local itemList = SheetUtil.getColumnValueList(csv, "camp_item_")

			return itemList
		end
	end

	return {}
end

function InfoFestival.getCampMap()
	for actv_id, festival_id in pairs(current_map) do
		if InfoActv.checkOpening(actv_id) and InfoFestival.checkOpening(festival_id) then
			local csv = CsvParser.getCsvData("festival", festival_id)

			if not empty(csv.camp_map) then
				return csv.camp_map
			end
		end
	end
end

function InfoFestival.getDropList(abyss_level)
	local dropArr = {}

	for actv_id, festival_id in pairs(current_map) do
		if InfoActv.checkOpening(actv_id) and InfoFestival.checkOpening(festival_id) then
			local csv = CsvParser.getCsvData("festival", festival_id)

			if not empty(csv.festival_drop) then
				table.insert(dropArr, csv.festival_drop)
			end
		end
	end

	return dropArr
end

return InfoFestival
