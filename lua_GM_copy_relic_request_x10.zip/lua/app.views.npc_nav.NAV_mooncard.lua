local NAV_base = import(".NAV_base")
local NAV_mooncard = class("NAV_mooncard", NAV_base)

function NAV_mooncard.open(npc)
	local ui = NAV_mooncard.new(npc)

	return ui
end

function NAV_mooncard:ctor(npc)
	NAV_mooncard.super.ctor(self, npc, "nav_mooncard")
end

function NAV_mooncard:init()
	NAV_mooncard.super.init(self)

	local index = 1
	local ui = self.buttons[index].ui
	local button = self.buttons[index].button
	local progress = ui:getComponentByTag("progress")

	if InfoOrder.moonToday() then
		self:setButtonName(ui, Localization.getSrcText("领取"))
		progress:setColor(NAV_base.COLOR.READY)
	else
		self:setButtonName(ui, Localization.getSrcText("今日已领取"))
		progress:setColor(NAV_base.COLOR.NONE)
	end

	local index = 2
	local ui = self.buttons[index].ui
	local button = self.buttons[index].button
	local data = CsvParser.getCsvData("rmb_member", 1000)
	self.data = data
	local costPic = IconManager.getIcon("image/pic/item/icon/" .. data.pic .. ".png")
	local icon = ui:createIconOnFlag("flag_icon", costPic, 100, true)

	icon:setOpacity(60)
	ui:replaceLabelOnFlag("flag_day", nil, math.max(0, InfoOrder.getMoonDayLeft()))
end

function NAV_mooncard:onTap(index)
	NAV_mooncard.super.onTap(self, index)
	print("NAV_mooncard:onTap", index, self.npc)

	if index == 1 then
		if InfoOrder.moonToday() then
			InfoOrder.getMoonToday(function ()
				if self.npc then
					self.npc:refreshOpened(true)
				end

				if global.player then
					global.player:checkNearNpc()
				end
			end)
		end
	elseif index == 2 then
		FRAME_mooncard.open(true)
	end
end

return NAV_mooncard
