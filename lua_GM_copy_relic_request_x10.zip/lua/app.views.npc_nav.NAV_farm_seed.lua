local NAV_base = import(".NAV_base")
local NAV_farm_seed = class("NAV_farm_seed", NAV_base)

function NAV_farm_seed.open(npc, newSeed)
	local ui = NAV_farm_seed.new(npc, newSeed)

	return ui
end

function NAV_farm_seed:ctor(npc, newSeed)
	NAV_farm_seed.super.ctor(self, npc, "nav_farm_seed")

	self.newSeed = newSeed
end

function NAV_farm_seed:init()
	NAV_farm_seed.super.init(self)
end

function NAV_farm_seed:showSeed(preSeed, newSeed)
	local units = TeamManager.getTeam()

	for i, unit in ipairs(units) do
		local effectGen = unit:getEffectGen()

		if effectGen then
			effectGen:fadeTo(30, 0, "outQuad")
		end
	end

	POP_lock.open()

	if global.ui then
		global.ui:stopControl()
	end

	local preGrowSpeed = 0

	if not empty(preSeed) then
		local pre_csv = CsvParser.getCsvData("farm_seed", preSeed)

		if not empty(pre_csv) then
			preGrowSpeed = math.floor(pre_csv.farm_num / pre_csv.grow_time * 3600)
		end
	end

	local farm_seed_csv = CsvParser.getCsvData("farm_seed", newSeed)
	local newGrowSpeed = math.floor(farm_seed_csv.farm_num / farm_seed_csv.grow_time * 3600)
	local itemID = farm_seed_csv.permit_item
	local seedEvent = MapEventManager.getEventByTagOne("farm_seed")
	local mapX, mapY = global.map:tileToMap(seedEvent)
	local dropItem = DropItem.new()

	dropItem:setDrop({
		type = DropManager.TYPE.ITEM,
		info = {
			num = 1,
			base_id = itemID
		}
	})
	dropItem:display(global.map, global.player.x, global.player.y)

	local function animeOver()
		global.map:tweenFov(global.player.x, global.player.y, 30, "outQuad")
		global.map:tweenScrollTo(global.player.x, global.player.y, 30, nil, "outQuad")
		global.map:tweenViewZoom(1, 60)

		for i, unit in ipairs(units) do
			local effectGen = unit:getEffectGen()

			if effectGen then
				effectGen:fadeTo(60, 255, "outQuad")
			end
		end

		global.ui:setVisible(true)
	end

	local flyHeight = 100
	local seedItemScale = 0.4

	local function seedOpen()
		local effectGen = dropItem:getEffectGen()

		if effectGen then
			effectGen:fadeTo(30, 0, nil, function ()
				dropItem:removeSelf()
			end)
		end

		MapEffect.quake(10)

		local farmModel = farm_seed_csv.seed_pic
		local customPic = IconManager.getMiscFarm(farmModel)
		local farmTiles = InfoFarm.getFarmTiles()

		for i, event in ipairs(farmTiles) do
			local seedItem = DropItem.new()

			seedItem:setDrop({
				type = DropManager.TYPE.ITEM,
				info = {
					num = 1,
					base_id = itemID
				}
			})
			seedItem:loadPic(customPic)
			seedItem:setScale(seedItemScale)
			seedItem:display(global.map, mapX, mapY)

			seedItem.z = flyHeight / seedItemScale

			seedItem:setBmpY()

			local eventX, eventY = global.map:tileToMap(event)
			local delayTime = math.random(0, 15)
			local flySpeed = math.random(15, 30)

			seedItem:performWithDelay(function ()
				seedItem:jump(cc.p(eventX, eventY), flySpeed, 30, function ()
					local effectGen = seedItem:getEffectGen()

					if effectGen then
						effectGen:fadeTo(30, 0, nil, function ()
							seedItem:removeSelf()
						end)
					end
				end)
			end, delayTime / 60)
		end

		Looper.setTimeout(function ()
			POP_lock.close()
			POP_farm_seed.open(farm_seed_csv, preGrowSpeed, newGrowSpeed, animeOver)
		end, 80, global.map)
	end

	local function onJumpComplete()
		MapEffect.quake(10)
		Looper.setTimeout(function ()
			dropItem:flyShake(120, flyHeight, 20, 60, seedOpen)
		end, 30, global.map)
	end

	local scale = 0.2

	dropItem:setScale(0)

	local function onJumpUpdate()
		scale = math.min(1, scale + 0.15)

		dropItem:setScale(scale)
	end

	dropItem:jump(cc.p(mapX, mapY), 10, 30, onJumpComplete, nil, onJumpUpdate)
	global.map:tweenFov(mapX, mapY, 10, "outQuad")
	global.map:tweenScrollTo(mapX, mapY, 10, nil, "outQuad")
	global.map:tweenViewZoom(1.5, 30)
	global.ui:setVisible(false)
end

function NAV_farm_seed:onTap(index)
	NAV_farm_seed.super.onTap(self, index)

	if index == 1 then
		local preSeed = InfoFarm.getFarmSeed()

		InfoFarm.putSeed(self.newSeed, function ()
			if global.player then
				global.player:npcChanged(true)
			end

			local newSeed = InfoFarm.getFarmSeed()

			print("$$$ showSeed", preSeed, newSeed)
			self:showSeed(preSeed, newSeed)
		end, onFailure)
	end
end

return NAV_farm_seed
