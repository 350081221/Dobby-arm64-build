local FRAME_abyss_reward = class("FRAME_abyss_reward", UI_base)

function FRAME_abyss_reward.open(rewardList, exp, onClose)
	local ui = FRAME_abyss_reward.new(rewardList, exp)

	Sound.playSound("gotitem")

	local mask = ui:getComponentByTag("mask")

	PopManager.open(ui, function ()
		mask:setVisible(false)
	end, onClose, PopManager.ANIM_TYPE.CENTER)
end

function FRAME_abyss_reward.openMixed(rewards, exp, onClose)
	local rewardList = {}

	for i, v in ipairs(rewards) do
		local rewardInfo = DropManager.getRewardInfo(v)

		table.insert(rewardList, rewardInfo)
	end

	FRAME_abyss_reward.open(rewardList, exp, onClose)
end

local maxCol = 6
local spaceX = 150
local spaceY = 144

function FRAME_abyss_reward:ctor(rewardList, exp)
	FRAME_abyss_reward.super.ctor(self, "frame_abyss_reward", UIManager.BIG_TYPE.CENTER)

	self.rewardList = rewardList
	self.exp = exp

	self:init()
end

function FRAME_abyss_reward:init()
	self:initUI()
end

function FRAME_abyss_reward:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local mask = self:getComponentByTag("mask")

	mask:setOpacity(0)
	mask:toTouchable()

	local centerFlag = self:getFlagByTag("flag_center")
	local row = math.ceil(#self.rewardList / maxCol)
	local col = math.ceil(#self.rewardList / row)
	local bg = self:getComponentByTag("bg")
	local bgHeight = bg.originalHeight + (row - 1) * spaceY + 40
	local bgY = bg.y - (row - 1) * spaceY / 2 - 40

	if self.exp > 0 then
		bgHeight = bgHeight + 40
		bgY = bgY - 40
	end

	bg:setSize(nil, bgHeight)
	bg:setPos(nil, bgY)

	for i, rewardInfo in ipairs(self.rewardList) do
		local bagSlot = DropSlot.new(centerFlag, "slot_02")

		bagSlot:setDrop(rewardInfo.type, rewardInfo.info)
		bagSlot:setDetailEnabled(true)

		local x = (i - 1) % col
		local y = math.floor((i - 1) / col)

		bagSlot:setPosition(centerFlag.x + spaceX * (x - (col - 1) / 2), centerFlag.y - spaceY * (y - (row - 1) / 2))
		self:addChild(bagSlot, 100)
	end

	local label_title = self:getComponentByTag("label_title")

	label_title:setPositionY(bgY + bgHeight + 50)

	local label_continue = self:getComponentByTag("label_continue")

	label_continue:setPositionY(bgY - 50)

	local expFlag = self:getFlagByTag("flag_exp")
	expFlag.y = bgY + 50

	if self.exp > 0 then
		self:replaceLabelOnFlag("flag_exp", nil, self.exp)
	else
		self:removeLabelOnFlag("flag_exp")
	end
end

return FRAME_abyss_reward
