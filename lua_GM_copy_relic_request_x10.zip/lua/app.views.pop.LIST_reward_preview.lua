local LIST_reward_preview = import("...ui.List")
local LIST_reward_preview = class("LIST_reward_preview", LIST_reward_preview)

function LIST_reward_preview:ctor(rect, lineNum)
	LIST_reward_preview.super.ctor(self, rect)
	self:setCellName("cell_reward_preview")

	self.lineNum = lineNum

	self:setCellSize(cc.size(90, self.touchRect.height))
end

function LIST_reward_preview:getCellName(index)
	local data = self.items[index]

	if data.label then
		return "cell_reward_preview_label"
	else
		return self.cellName
	end
end

function LIST_reward_preview:getCellSize(index)
	local data = self.items[index]

	if data.label then
		return cc.size(self.touchRect.width, 50)
	else
		local h = math.ceil(#data.arr / self.lineNum) * 90 + 10

		return cc.size(self.touchRect.width, h)
	end
end

function LIST_reward_preview:onCellInit(ui, data, index)
	if data.label then
		local label, labelWidth = ui:createLabelOnFlag("flag_label", data.label, data.style)
		local line = ui:getComponentByTag("line")
		local lineX = label:getPositionX() + labelWidth / 2 + 15
		local lineWidth = self.touchRect.width - lineX - 15

		if lineWidth > 0 then
			line:setVisible(true)
			line:setPos(lineX)
			line:setSize(lineWidth)
		else
			line:setVisible(false)
		end
	else
		if ui.coms then
			for i, com in ipairs(ui.coms) do
				com:removeSelf()
			end

			ui.coms = nil
		end

		local h = 90
		ui.coms = {}
		local startX = 5
		local startY = math.ceil(#data.arr / self.lineNum) * h + 10 - h
		local blockX = 0
		local blockY = 0

		for i, v in ipairs(data.arr) do
			local com = UIManager.getUI("com_reward_preview")

			com:setPosition(startX + blockX * 90, startY - blockY * h)
			ui:addChild(com, 100)
			table.insert(ui.coms, com)

			blockX = blockX + 1

			if self.lineNum <= blockX then
				blockX = 0
				blockY = blockY + 1
			end

			local slot = DropSlot.new(com:getFlagByTag("flag_slot"), "slot_01")

			slot:setAlwaysShowNumber(true)
			com:addChild(slot, 100)

			com.slot = slot

			slot:setDrop(v.type, v.info)
		end
	end
end

function LIST_reward_preview:onCellRemove(ui, data, index)
	if ui.coms then
		for i, com in ipairs(ui.coms) do
			com:removeSelf()
		end

		ui.coms = nil
	end
end

return LIST_reward_preview
