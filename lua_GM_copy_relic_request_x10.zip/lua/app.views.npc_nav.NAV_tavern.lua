local NAV_base = import(".NAV_base")
local NAV_tavern = class("NAV_tavern", NAV_base)

function NAV_tavern.open(npc)
	local ui = NAV_tavern.new(npc)

	return ui
end

function NAV_tavern:ctor(npc)
	NAV_tavern.super.ctor(self, npc, "nav_tavern")
end

function NAV_tavern:init()
	NAV_tavern.super.init(self)
	self:setBuildingLvupIndex(2)

	local index = 3
	local funcCSV = InfoFunction.checkFuncOpen(10060)

	if funcCSV then
		self:setButtonVisible(index, true)

		local ui = self.buttons[index].ui

		self:setButtonName(ui, funcCSV.name)
	else
		self:setButtonVisible(index, false)
	end
end

function NAV_tavern:onTap(index)
	NAV_tavern.super.onTap(self, index)

	if index == 1 then
		InfoBuilding.playOpenSfx(InfoBuilding.TAG.TAVERN)
		FRAME_tavern.open(self.npc)
	elseif index == 3 then
		FRAME_building_plus.open(self.npc)
	end
end

return NAV_tavern
