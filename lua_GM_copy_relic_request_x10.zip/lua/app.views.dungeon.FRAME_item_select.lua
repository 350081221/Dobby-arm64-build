local FRAME_item_select = class("FRAME_item_select", UI_base)
local OPEN_TYPE = {
	QUICK = 1,
	NONE = 0,
	QUICK_REMOVE = 3,
	QUICK_EMPTY = 2
}
FRAME_item_select.OPEN_TYPE = OPEN_TYPE
local type_buttons = {
	[OPEN_TYPE.NONE] = {},
	[OPEN_TYPE.QUICK] = {
		"btn_quick_select",
		"btn_quick_remove"
	},
	[OPEN_TYPE.QUICK_EMPTY] = {
		"btn_quick_empty_select"
	},
	[OPEN_TYPE.QUICK_REMOVE] = {
		"btn_quick_remove_remove"
	}
}

function FRAME_item_select.open(items, currentItem, openType, ...)
	local ui = FRAME_item_select.new(items, currentItem, openType, ...)

	PopManager.open(ui, function ()
		ui:onOpen()
	end)
end

function FRAME_item_select:ctor(items, currentItem, openType, ...)
	FRAME_item_select.super.ctor(self, "frame_item_select", UIManager.BIG_TYPE.POP)

	self.items = items
	self.currentItem = currentItem
	self.openType = openType
	self.callbackStack = {
		...
	}

	self:init()
end

function FRAME_item_select:onOpen()
	if self.questData then
		self:doGuide()
	end
end

function FRAME_item_select:init()
	self:refreshOpenType(self.openType)
	self:initUI()

	local dropList = DropManager.convertDropList(DropManager.TYPE.ITEM, self.items)

	self.list:setItems(dropList)

	if self.currentItem then
		if #dropList > 0 then
			local selectedIndex = 1

			for i, v in ipairs(self.items) do
				if v.base_id == self.currentItem.base_id then
					selectedIndex = i

					break
				end
			end

			self.list:setSelectedIndex(selectedIndex)
			self:refreshDetail(dropList[selectedIndex])
		else
			self:refreshDetail(DropManager.convertDrop(DropManager.TYPE.ITEM, self.currentItem))
		end
	elseif #dropList > 0 then
		self.list:setSelectedIndex(1)
		self:refreshDetail(dropList[1])
	end
end

function FRAME_item_select:refreshOpenType(openType)
	local allButtonMap = {}
	local openButtonMap = {}

	for type, buttons in pairs(type_buttons) do
		for i, buttonName in ipairs(buttons) do
			allButtonMap[buttonName] = true

			if openType == type then
				openButtonMap[buttonName] = i
			end
		end
	end

	for buttonName, v in pairs(allButtonMap) do
		local com = self:getComponentByTag(buttonName)
		local index = openButtonMap[buttonName]

		com:setVisible(index ~= nil)

		if index then
			com:setTapGroup("button_click")
			com:toTouchable()
			com:addTap(function ()
				local selectItem = self.list:getSelectedItem()
				local selectItemInfo = nil

				if selectItem then
					selectItemInfo = selectItem.info
				end

				if self.callbackStack and self.callbackStack[index] then
					local callback = self.callbackStack[index]

					if callback then
						callback(self, selectItemInfo)
					end
				end
			end)
		end
	end
end

function FRAME_item_select:doGuide()
	if self.questData and #self.list.items > 0 then
		local step = 1
		local doGuideNext = nil

		function doGuideNext()
			POP_hint.close()
			POP_focus.close()

			if step == 1 then
				local cell = self.list:getCellUI(1)

				POP_focus.openOnNode(cell, 200, nil, doGuideNext)
				POP_hint.openOnNode(cell, Localization.getSrcText("选择道具"))

				step = 2
			elseif step == 2 then
				local selectBtn = self:getComponentByTag("btn_select")

				POP_focus.openOnNode(selectBtn, 200, nil, doGuideNext)

				step = 3
			end
		end

		doGuideNext()
	end
end

function FRAME_item_select:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local function tapListener(ui, data, index)
		self:refreshDetail(data)
	end

	self.list = self:createListOnFlag("flag_list", function (rect)
		return LIST_bag.new(rect, 3)
	end, tapListener, touchListener)

	self.list:setSelectEnabled(true)

	self.slot = DropSlot.new(self:getFlagByTag("flag_icon"), "slot_01")

	self:addChild(self.slot, 100)

	local textArea = self:createTextAreaOnFlag("flag_desc")

	textArea:setSpace(13, 13)

	self.textArea = textArea
end

function FRAME_item_select:refreshDetail(dropData)
	local itemInfo = dropData.info
	local itemData = CsvParser.getCsvData("item", itemInfo.base_id or itemInfo.id)

	self.slot:setDrop(DropManager.TYPE.ITEM, itemInfo)
	self:createLabelOnFlag("flag_name", itemData.name, {
		wrap = true
	})

	local desc = string.gsub(itemData.desc, "\\n", "\n")

	self.textArea:setText(desc)
end

return FRAME_item_select
