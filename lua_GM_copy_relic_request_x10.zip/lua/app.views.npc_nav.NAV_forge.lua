local NAV_base = import(".NAV_base")
local NAV_forge = class("NAV_forge", NAV_base)

function NAV_forge.open(npc)
	local ui = NAV_forge.new(npc)

	return ui
end

function NAV_forge:ctor(npc)
	NAV_forge.super.ctor(self, npc, "nav_forge")
end

function NAV_forge:init()
	NAV_forge.super.init(self)
	self:setBuildingLvupIndex(2)

	local index = 3
	local funcCSV = InfoFunction.checkFuncOpen(10010)

	if funcCSV then
		self:setButtonVisible(index, true)

		local ui = self.buttons[index].ui

		self:setButtonName(ui, funcCSV.name)
	else
		self:setButtonVisible(index, false)
	end

	local index = 4
	local funcCSV = InfoFunction.checkFuncOpen(10020)

	if funcCSV then
		self:setButtonVisible(index, true)

		local ui = self.buttons[index].ui

		self:setButtonName(ui, funcCSV.name)
	else
		self:setButtonVisible(index, false)
	end

	local index = 6
	local funcCSV = InfoFunction.checkFuncOpen(10020)

	if funcCSV then
		self:setButtonVisible(index, true)
	else
		self:setButtonVisible(index, false)
	end

	local index = 5
	local funcCSV = InfoFunction.checkFuncOpen(10030)

	if funcCSV then
		self:setButtonVisible(index, true)

		local ui = self.buttons[index].ui

		self:setButtonName(ui, funcCSV.name)
	else
		self:setButtonVisible(index, false)
	end

	local index = 7
	local funcCSV = InfoFunction.checkFuncOpen(10150)

	if funcCSV then
		self:setButtonVisible(index, true)

		local ui = self.buttons[index].ui

		self:setButtonName(ui, funcCSV.name)
	else
		self:setButtonVisible(index, false)
	end

	local index = 8
	local funcCSV = InfoFunction.checkFuncOpen(10180)

	if funcCSV then
		self:setButtonVisible(index, true)

		local ui = self.buttons[index].ui

		self:setButtonName(ui, funcCSV.name)
	else
		self:setButtonVisible(index, false)
	end
end

function NAV_forge:onTap(index)
	NAV_forge.super.onTap(self, index)

	if index == 1 then
		InfoBuilding.playOpenSfx(InfoBuilding.TAG.FORGE)
		FRAME_equip_enhance.open(self.npc)
	elseif index == 3 then
		FRAME_building_plus.open(self.npc)
	elseif index == 4 then
		InfoBuilding.playOpenSfx(InfoBuilding.TAG.FORGE)
		FRAME_equip_gem.open(self.npc)
	elseif index == 5 then
		InfoBuilding.playOpenSfx(InfoBuilding.TAG.FORGE)
		FRAME_equip_reform.open(self.npc)
	elseif index == 6 then
		InfoBuilding.playOpenSfx(InfoBuilding.TAG.FORGE)
		FRAME_gem_compose.open(self.npc)
	elseif index == 7 then
		InfoBuilding.playOpenSfx(InfoBuilding.TAG.FORGE)
		FRAME_illusion.open(self.npc)
	elseif index == 8 then
		InfoBuilding.playOpenSfx(InfoBuilding.TAG.FORGE)
		FRAME_suit.open(self.npc)
	end
end

return NAV_forge
