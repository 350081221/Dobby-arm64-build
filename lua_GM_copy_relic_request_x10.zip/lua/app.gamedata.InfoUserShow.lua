local InfoUserShow = {}
local TYPE = {
	HERO = 3,
	FISH = 2,
	MEDAL = 1,
	PET = 4
}
InfoUserShow.TYPE = TYPE
local rawData = nil

function InfoUserShow.init()
	Connection.listen("user_show_sync", InfoUserShow.sync)
end

app:addToAppEnterCall(InfoUserShow.init)

function InfoUserShow.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoUserShow.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("user_show_query", callback)
end

function InfoUserShow.onQuery(rcvData)
	rawData = {}

	for i, v in ipairs(rcvData.list) do
		if not rawData[v.type] then
			rawData[v.type] = {}
		end

		rawData[v.type][v.index] = v.id
	end
end

function InfoUserShow.sync(syncData)
	local hasMedal = false

	for i, v in ipairs(syncData.list) do
		if not rawData[v.type] then
			rawData[v.type] = {}
		end

		rawData[v.type][v.index] = v.id

		if v.type == TYPE.MEDAL then
			hasMedal = true
		end
	end

	ManagerInfo.dataChange("user_show")

	if hasMedal then
		if OnlineCamp.isOnline() and global.player then
			global.player:refreshTitle()
		end

		if OnlineCamp.inRoom() then
			OnlineCamp.updateMedals()
		end
	end
end

function InfoUserShow.setUserInfo(type, index, id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("user_show_set", {
		type = type,
		index = index,
		id = id
	}, callback)
end

function InfoUserShow.getMedals()
	local arr = {}

	for i = 1, 3 do
		if rawData[TYPE.MEDAL] and rawData[TYPE.MEDAL][i] and not empty(rawData[TYPE.MEDAL][i]) then
			table.insert(arr, rawData[TYPE.MEDAL][i])
		end
	end

	return arr
end

function InfoUserShow.getUserInfo()
	local info = {
		user_id = InfoUser.getID()
	}
	local nickname, nicklang = InfoUser.getNickAndLang()
	info.nickname = nickname
	info.nicklang = nicklang
	local headInfo = InfoUser.getHead()
	info.head = headInfo.icon
	info.head_frame = headInfo.frame
	info.arena_points = InfoArena.selfPoints()
	info.home_is_public = InfoHome.isPublic() and 1 or 0
	info.home_map_id = InfoHome.getMapID()
	info.likes = InfoLikes.countLikes()
	info.fish_arr = {}
	info.hero_arr = {}
	info.medal_arr = {}
	info.pet_arr = {}

	for i = 1, 3 do
		if rawData[1] and not empty(rawData[1][i]) then
			info.medal_arr[i] = rawData[1][i]
		else
			info.medal_arr[i] = ""
		end

		if rawData[2] and not empty(rawData[2][i]) then
			local fishInfo = InfoFishing.getDataByID(rawData[2][i])

			if fishInfo then
				local obj = {
					weight = fishInfo.best_weight,
					count = fishInfo.count,
					base_id = fishInfo.base_id
				}
				info.fish_arr[i] = json.encode(obj)
			else
				info.fish_arr[i] = ""
			end
		else
			info.fish_arr[i] = ""
		end

		if rawData[3] and not empty(rawData[3][i]) then
			local heroInfo = InfoHero.getHero(rawData[3][i])

			if heroInfo then
				local obj = {
					level = heroInfo.level,
					_id = heroInfo.id,
					body = heroInfo.body,
					hair = heroInfo.hair,
					quality = heroInfo.quality,
					base_id = heroInfo.base_id
				}
				info.hero_arr[i] = json.encode(obj)
			else
				info.hero_arr[i] = ""
			end
		else
			info.hero_arr[i] = ""
		end

		if rawData[4] and not empty(rawData[4][i]) then
			local petInfo = InfoPet.getPet(rawData[4][i])

			if petInfo then
				local obj = {
					level = petInfo.level,
					_id = petInfo.id,
					quality = petInfo.quality,
					base_id = petInfo.base_id
				}
				info.pet_arr[i] = json.encode(obj)
			else
				info.pet_arr[i] = ""
			end
		else
			info.pet_arr[i] = ""
		end
	end

	local unionInfo = InfoUnion.getUnionInfo()

	if unionInfo then
		info.union_id = unionInfo.union_id
		info.union_name = unionInfo.union_name
		info.union_lang = unionInfo.lang
	end

	return info
end

return InfoUserShow
