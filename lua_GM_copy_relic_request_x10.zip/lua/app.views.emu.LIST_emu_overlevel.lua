local List = import("...ui.List")
local LIST_emu_overlevel = class("LIST_emu_overlevel", List)

function LIST_emu_overlevel:ctor(rect)
	LIST_emu_overlevel.super.ctor(self, rect)
	self:setCellName("cell_emu_overlevel")
	self:setSpace(0, 5)
	self:setCellSize(cc.size(self.touchRect.width, 40))
end

function LIST_emu_overlevel:onCellInit(ui, data, index)
	local csv = CsvParser.getCsvData("emu_hero_team", data.id)

	ui:createLabelOnFlag("flag_id", csv.id)
	ui:createLabelOnFlag("flag_name", csv.name)

	if data.passLevel then
		ui:createLabelOnFlag("flag_level", data.teamLevel .. "(" .. data.passLevel .. ")")
	else
		ui:createLabelOnFlag("flag_level", data.teamLevel)
	end

	if data.score then
		ui:createLabelOnFlag("flag_score", data.score)
	else
		ui:removeLabelOnFlag("flag_score")
	end

	ui:createLabelOnFlag("flag_battle", data.winCount .. "/" .. data.battleCount)
	self:onCellSelected(ui, data, self.selectedIndex == index)
end

function LIST_emu_overlevel:onCellSelected(ui, data, selected)
	local bg = ui:getComponentByTag("bg")

	bg:setOpacity(150)
	bg:setVisible(selected)
end

return LIST_emu_overlevel
