local DropSlot = import("..component.DropSlot")
local DungeonSlot = class("DungeonSlot", DropSlot)

function DungeonSlot:ctor(rect, uiName)
	DungeonSlot.super.ctor(self, rect, uiName or "com_dungeon_slot")
	self:init()
end

function DungeonSlot:init()
	DungeonSlot.super.init(self)
	self:setAlwaysShowNumber(true)
end

function DungeonSlot:initUI()
	DungeonSlot.super.initUI(self)

	local iconFlag = self:getFlagByTag("flag_icon")
	self.polygonPoints = {
		{
			0,
			iconFlag.height / 2
		},
		{
			-iconFlag.width / 2,
			iconFlag.height / 2
		},
		{
			-iconFlag.width / 2,
			-iconFlag.height / 2
		},
		{
			iconFlag.width / 2,
			-iconFlag.height / 2
		},
		{
			iconFlag.width / 2,
			iconFlag.height / 2
		},
		{
			0,
			iconFlag.height / 2
		}
	}

	self:getComponentByTag("bg"):setOpacity(0)
	self:getComponentByTag("border"):setOpacity(0)
	self:getComponentByTag("mp_bar"):setVisible(false)

	local cdFlash = self:getComponentByTag("cd_flash")

	cdFlash:setVisible(false)
	cdFlash:setLocalZOrder(900)
	transition.stopTarget(cdFlash)
end

function DungeonSlot:setTouchEnabledTag(tag, enabled)
	if enabled then
		if not self._touchEnabledStateMap then
			self._touchEnabledStateMap = {}
		end

		self._touchEnabledStateMap[tag] = 1
	else
		if self._touchEnabledStateMap then
			self._touchEnabledStateMap[tag] = nil
		end

		if self._touchEnabledStateMap and table.nums(self._touchEnabledStateMap) == 0 then
			self._touchEnabledStateMap = nil
		end
	end
end

function DungeonSlot:isTouchEnabledTag()
	return self._touchEnabledStateMap == nil
end

function DungeonSlot:setAuto(isAuto)
	self:getComponentByTag("border"):setOpacity(isAuto and 255 or 0)
end

function DungeonSlot:clearContent()
	self:getComponentByTag("border"):setOpacity(0)
	self:reset()
	self:clearDrop()

	local bar_bg = self:getComponentByTag("bar_bg")
	local hp_bar = self:getComponentByTag("hp_bar")

	if bar_bg then
		bar_bg:setVisible(false)
	end

	if hp_bar then
		hp_bar:setVisible(false)
	end
end

function DungeonSlot:setContent(unit, type, info)
	self:reset()

	self.unit = unit
	self.type = tonumber(type)
	self.info = info

	self:setDrop(type, info)

	local skillData = nil

	if self.type == DropManager.TYPE.SKILL then
		if self.info then
			skillData = self.info.data
			local isAmmoCD = false
			local addSkillArr = SheetUtil.getColumnList(skillData, {
				"buff_"
			}, {
				"buffID"
			})

			for i, v in ipairs(addSkillArr) do
				local buffData = CsvParser.getCsvData("buff", v.buffID)

				if not empty(buffData.ammo_times) then
					self.cdTag = "buff_times_" .. v.buffID
					self.cdHandler = self:safeListen(unit, self.cdTag, function (event)
						self:onAddSkillCD(event)
					end)
					isAmmoCD = true

					break
				end
			end

			if not isAmmoCD then
				if skillData.power_as_cd == 1 then
					self.cdTag = "skill_power_" .. skillData.id
					self.cdHandler = self:safeListen(unit, self.cdTag, function (event)
						self:onHeroSkillPower(event, skillData.id)
					end)

					unit:dispatchManualSkillsCD()
				else
					self.cdTag = "skill_cd_" .. skillData.id
					self.cdHandler = self:safeListen(unit, self.cdTag, function (event)
						self:onHeroSkillCD(event, skillData.id)
					end)

					unit:dispatchManualSkillsCD()
				end
			end

			if unit.type == "hero" or unit.type == "hero_copy" then
				self.stateHandler = self:safeListen(unit, "state_changed_no_skill", function (event)
					self:onHeroSkillStateChanged(unit)
				end)
				self.stateNomoveHandler = self:safeListen(unit, "state_changed_no_move", function (event)
					self:onHeroSkillStateChanged(unit)
				end)
				self.dieHandler = self:safeListen(unit, "die", function (event)
					self:onHeroSkillStateChanged(unit)
				end)
				self.switchSkillHandler = self:safeListen(unit, "switch_skill", function (event)
					self:onSwitchSkill(unit, event.noCD)
				end)

				if unit.type == "hero_copy" then
					self.autoSkillHandler = self:safeListen(unit, "set_auto_skill", function (event)
						self:onAutoSkill(unit)
					end)
				end

				self:onHeroSkillStateChanged(unit)
			end

			local bg = self:getComponentByTag("bg")

			if self.icon then
				Shader.recover(self.icon)
			end

			self:setTouchEnabledTag("no_skill", false)

			local bar_bg = self:getComponentByTag("bar_bg")
			local hp_bar = self:getComponentByTag("hp_bar")

			if bar_bg then
				bar_bg:setVisible(true)
			end

			if hp_bar then
				if not self:getBarByTag("hp_bar") then
					self:createBarByTag("hp_bar", cc.c3b(35, 180, 28))
				end

				hp_bar:setVisible(true)

				self.hpHandler = self:safeListen(unit, "hp_changed", function (event)
					self:onHeroHpChanged(unit)
				end)

				self:onHeroHpChanged(unit)
			end
		end
	elseif self.type == DropManager.TYPE.ITEM and self.info and self.info.base_id > 0 then
		local itemData = CsvParser.getCsvData("item", self.info.base_id)
		skillData = CsvParser.getCsvData("skill", itemData.use_skill)
		self.cdTag = "skill_cd_" .. skillData.id
		self.cdHandler = self:safeListen(unit, self.cdTag, function (event)
			self:onHeroSkillCD(event, skillData.id)
		end)
		self.sharedCdHandler = self:safeListen(unit, "shared_cd", function (event)
			self:onHeroSkillCD(event, skillData.id)
		end)

		self:setSkillEnabled(self.info.num > 0)
	end

	if skillData and not empty(skillData.pre_cd) then
		self:startCD(WarMachine.getFrame() + skillData.pre_cd, skillData.pre_cd)
	end
end

function DungeonSlot:clearMp()
	self:clearDuplicated("mp_bar")
end

function DungeonSlot:setMp(blockNum)
	self:clearMp()

	if blockNum == 0 then
		self:getComponentByTag("mp_bar"):setVisible(false)
	else
		self:getComponentByTag("mp_bar"):setVisible(true)

		local bNum = math.ceil(blockNum)
		local bArr = self:duplicateComponent("mp_bar", bNum - 1, 19, 0, Style.left)

		for i, block in ipairs(bArr) do
			block:setLocalZOrder(200)

			if blockNum - i >= 0 then
				block:setScaleX(1)
			else
				block:setScaleX(blockNum - i + 1)
			end
		end
	end
end

function DungeonSlot:removeHandlers()
	if self.cdHandler then
		self.unit:removeEventListener(self.cdTag, self.cdHandler)

		self.cdHandler = nil
	end

	if self.sharedCdHandler then
		self.unit:removeEventListener("shared_cd", self.sharedCdHandler)

		self.sharedCdHandler = nil
	end

	if self.stateHandler then
		self.unit:removeEventListener("state_changed_no_skill", self.stateHandler)

		self.stateHandler = nil
	end

	if self.stateNomoveHandler then
		self.unit:removeEventListener("state_changed_no_move", self.stateNomoveHandler)

		self.stateNomoveHandler = nil
	end

	if self.dieHandler then
		self.unit:removeEventListener("die", self.dieHandler)

		self.dieHandler = nil
	end

	if self.hpHandler then
		self.unit:removeEventListener("hp_changed", self.hpHandler)

		self.hpHandler = nil
	end

	if self.switchSkillHandler then
		self.unit:removeEventListener("switch_skill", self.switchSkillHandler)

		self.switchSkillHandler = nil
	end

	if self.autoSkillHandler then
		self.unit:removeEventListener("set_auto_skill", self.autoSkillHandler)

		self.autoSkillHandler = nil
	end
end

function DungeonSlot:onHeroHpChanged(unit)
	local percent = unit.battleData.hp / unit.attrs.hp
	local color = InfoHero.getHpColor(percent)

	self:setBarProgressByTag("hp_bar", percent)
	self:setBarColorByTag("hp_bar", color)
end

function DungeonSlot:setSkillEnabled(enabled)
	local bg = self:getComponentByTag("bg")

	if enabled then
		if self.icon then
			Shader.recover(self.icon)
		end

		self:setTouchEnabledTag("disabled", false)
	else
		if self.icon then
			Shader.gray(self.icon)
		end

		self:setTouchEnabledTag("disabled", true)
	end
end

function DungeonSlot:onModaoManaChanged(mana)
	if self.info then
		if mana < self.info.data.mp then
			if self.icon then
				Shader.gray(self.icon)
			end

			self:setTouchEnabledTag("no_skill", true)
		else
			if self.icon then
				Shader.recover(self.icon)
			end

			self:setTouchEnabledTag("no_skill", false)
		end
	end
end

function DungeonSlot:onHeroSkillStateChanged(unit)
	local disabled = unit:getState("no_skill") or unit.battleData.die

	if not disabled then
		local skillData = self.info.data

		if skillData.is_jump == 1 then
			disabled = unit:getState("no_move")
		end
	end

	if disabled then
		if self.icon then
			Shader.gray(self.icon)
		end

		self:setTouchEnabledTag("no_skill", true)
	else
		if self.icon then
			Shader.recover(self.icon)
		end

		self:setTouchEnabledTag("no_skill", false)
	end
end

function DungeonSlot:onSwitchSkill(unit, noCD)
	local skillInfo = unit:getActiveSkill()

	self:setContent(unit, DropManager.TYPE.SKILL, skillInfo)

	if not noCD then
		local cd = CsvParser.getCsvData("config", "switch_skill_cd").value

		self:startCD(WarMachine.getFrame() + cd, cd, true)
	end
end

function DungeonSlot:onAutoSkill(unit)
	if not unit:isSwitchSkill() then
		self:setAuto(unit:isAutoSkill())
	end
end

function DungeonSlot:onHeroSkillPower(event, skillID)
	if event.powerValue > 0 then
		self:setTouchEnabledTag("cd", event.power < event.powerValue)

		local powerLeft = event.powerValue - event.power

		if powerLeft > 0 then
			local bg = self:getComponentByTag("bg")
			local label = self:createLabelOnFlag("flag_cd", powerLeft, nil, true)

			self:addChild(label, 1000)
		else
			self:removeLabelOnFlag("flag_cd")
		end

		local percent = powerLeft / event.powerValue

		self:setPercent(math.min(1, percent))
	end
end

function DungeonSlot:onHeroSkillCD(event, skillID)
	local force = nil

	if event.trigger_cd_reduce then
		force = true
	end

	self:startCD(event.cd, event.cdMax, force)
end

function DungeonSlot:startCD(cdOverTime, cdMax, force)
	if not cdMax then
		return
	end

	if force then
		-- Nothing
	elseif not empty(self.cdOverTime) and cdOverTime < self.cdOverTime then
		return
	end

	self.cdOverTime = cdOverTime

	if self.cdLoop then
		MapFrameManager.stopLoop(self, self.cdLoop)

		self.cdLoop = nil
	end

	local fullFrameTime = WarMachine.getFrame()
	local bg = self:getComponentByTag("bg")
	local cdFlash = self:getComponentByTag("cd_flash")
	local cdLeft = cdOverTime - fullFrameTime
	local fadeStep = 1

	self:setTouchEnabledTag("cd", true)

	local cdLoop = nil

	function cdLoop(obj, frame, passed, sharp)
		if tolua.isnull(self) then
			MapFrameManager.stopLoop(self, cdLoop)

			return
		end

		local secStr = nil

		if cdLeft > 60 then
			secStr = math.ceil(cdLeft / 60)
		else
			secStr = math.ceil(math.max(0, cdLeft) * 10 / 60) / 10
		end

		if secStr ~= self.preSec then
			self.preSec = secStr
			local label = self:createLabelOnFlag("flag_cd", secStr, nil, true)

			self:addChild(label, 1000)
		end

		cdLeft = cdLeft - passed

		if fadeStep == 1 and cdLeft <= 10 then
			fadeStep = 2

			cdFlash:setOpacity(255)
			cdFlash:setVisible(true)
			transition.fadeTo(cdFlash, {
				easing = "sineIn",
				opacity = 0,
				time = 0.4,
				onComplete = function ()
					cdFlash:setVisible(false)
				end
			})

			return
		end

		if cdLeft <= 0 then
			self:setPercent(0)
			self:setTouchEnabledTag("cd", false)
			self:removeLabelOnFlag("flag_cd")
			MapFrameManager.stopLoop(self, cdLoop)

			self.cdLoop = nil
		else
			self:setPercent(math.min(1, cdLeft / cdMax))
		end
	end

	self.cdLoop = cdLoop

	MapFrameManager.startLoop(self, cdLoop)
end

function DungeonSlot:onAddSkillCD(event)
	local bg = self:getComponentByTag("bg")
	local label = self:createLabelOnFlag("flag_cd", event.times, nil, true)

	self:addChild(label, 1000)
	self:setPercent(event.times / event.maxTimes)

	if event.times <= 0 then
		self:setTouchEnabledTag("cd", false)
		self:removeLabelOnFlag("flag_cd")
	else
		self:setTouchEnabledTag("cd", true)
	end
end

function DungeonSlot:reset()
	self:removeHandlers()

	self.preSec = nil
	local cdFlash = self:getComponentByTag("cd_flash")

	cdFlash:setVisible(false)
	cdFlash:setOpacity(0)
	transition.stopTarget(cdFlash)

	local bg = self:getComponentByTag("bg")

	self:setPercent(0)
	self:setTouchEnabledTag("cd", false)
	self:removeLabelOnFlag("flag_cd")

	if self.cdLoop then
		MapFrameManager.stopLoop(self, self.cdLoop)

		self.cdLoop = nil
	end

	if self.cdPolygon then
		self.cdPolygon:removeSelf()

		self.cdPolygon = nil
	end

	self.cdOverTime = nil
end

function DungeonSlot:setPercent(percent)
	local bg = self:getComponentByTag("bg")
	local polygonPoints = self.polygonPoints

	if percent > 0 then
		local nodeNum = math.floor((percent + 0.125) * 4) + 1
		local pts = {
			{
				0,
				0
			}
		}

		for i = 1, nodeNum do
			table.insert(pts, polygonPoints[i])
		end

		local ipt = polygonPoints[nodeNum]
		local ipt2 = polygonPoints[nodeNum + 1]
		local iangle = math.atan2(ipt2[2] - ipt[2], ipt2[1] - ipt[1])
		local ix, iy = GeomPlane.intersect(0, 0, math.pi * 2 * (percent + 0.25), ipt[1], ipt[2], iangle)

		table.insert(pts, {
			ix,
			iy
		})
		table.insert(pts, {
			0,
			0
		})

		local newPolygon = self.cdPolygon == nil

		if self.cdPolygon then
			self.cdPolygon:setVisible(true)
			self.cdPolygon:clear()
		end

		self.cdPolygon = display.newPolygon(pts, {
			borderWidth = 0,
			fillColor = cc.c4f(0, 0, 0, 0.8)
		}, self.cdPolygon)

		if newPolygon then
			self.cdPolygon:setPosition(bg.width / 2 - bg.x, bg.height / 2 - bg.y)
			self:addChild(self.cdPolygon, 800)
		end
	elseif self.cdPolygon then
		self.cdPolygon:setVisible(false)
	end
end

function DungeonSlot:onExit()
	self:reset()
	DungeonSlot.super.onExit(self)
end

return DungeonSlot
