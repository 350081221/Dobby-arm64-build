local InfoTaskQuest = {}
local rawData = {}
local autoAcceptLocked = false

function InfoTaskQuest.init()
	Connection.listen("task_quest_sync", InfoTaskQuest.sync)
	Connection.listen("task_quest_sync_remove", InfoTaskQuest.syncRemove)
end

app:addToAppEnterCall(InfoTaskQuest.init)

function InfoTaskQuest.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoTaskQuest.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("task_quest_query", callback)
end

function InfoTaskQuest.onQuery(rcvData)
	rawData = {}

	for i, data in ipairs(rcvData.list) do
		local taskCSV = CsvParser.getCsvData("task", data.base_id)

		if taskCSV then
			rawData[data.id] = data
		end
	end

	if global.map then
		InfoTaskQuest.snapshotReset()
	end
end

function InfoTaskQuest.sync(data)
	local changedIdStack = {}

	for i, syncData in ipairs(data.list) do
		local id = syncData.id
		rawData[id] = syncData
		changedIdStack[id] = rawData[id]
	end

	ManagerInfo.dataChange("task_quest", changedIdStack)
end

function InfoTaskQuest.syncRemove(data)
	local changedIdStack = {}

	for i, id in ipairs(data.list) do
		if rawData[id] then
			changedIdStack[id] = rawData[id]
			rawData[id] = nil
		end
	end

	ManagerInfo.dataChange("task_quest", changedIdStack)
end

function InfoTaskQuest.snapshotReset()
	InfoTaskQuest.snapshot()

	local unitList = ClipOnMap.getUnitList("npc")

	for _, unit in ipairs(unitList) do
		if unit.npcType == Npc.TYPE.NPC then
			local data = InfoTaskQuest.getDataForNPC(unit.baseID)

			if data then
				unit:refreshTaskAndFestival(animated)
			else
				unit:removeTask()
			end
		end
	end

	if global.player then
		global.player:npcChanged(true)
	end
end

local snapshotData = nil

function InfoTaskQuest.snapshot()
	snapshotData = {}

	for k, data in pairs(rawData) do
		local taskCSV = CsvParser.getCsvData("task", data.base_id)

		if data.fin ~= 2 then
			snapshotData[taskCSV.npc] = data
		end
	end

	notify.dispatch("InfoTaskQuest_snapshot")
end

function InfoTaskQuest.getData(id)
	dump(rawData, "$$$ rawData")

	return rawData[id]
end

function InfoTaskQuest.getDataForNPC(npcID)
	return snapshotData[npcID]
end

function InfoTaskQuest.removeDataForNPC(npcID)
	snapshotData[npcID] = nil
end

function InfoTaskQuest.getList()
	local arr = {}

	for k, v in pairs(snapshotData) do
		table.insert(arr, v)
	end

	table.sort(arr, function (a, b)
		local taskA = CsvParser.getCsvData("task", a.base_id)
		local taskB = CsvParser.getCsvData("task", b.base_id)

		if taskA.type == taskB.type then
			return a.base_id < b.base_id
		else
			return taskB.type < taskA.type
		end
	end)

	return arr
end

function InfoTaskQuest.finish(id, onSuccess, onFailure)
	local preData = nil

	if CONFIG.is_ta then
		preData = ObjUtil.copy(rawData[id])
	end

	local function callback(rcvData)
		dump(rcvData, "$$$ task_quest_finish")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if CONFIG.is_ta then
				-- Nothing
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("task_quest_finish", {
		id = id
	}, callback)
end

function InfoTaskQuest.reject(id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ task_quest_reject")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("task_quest_reject", {
		id = id
	}, callback)
end

function InfoTaskQuest.getQuestReward(quest_csv, quest_seed, level)
	if empty(quest_csv.reward_type) then
		return {}
	end

	local random = Random.new(quest_seed)
	local reward_type = SheetUtil.getString(quest_csv.reward_type, random)
	local quest_reward_type_map = CacheData.get("InfoTaskQuest_quest_reward_type_map")

	if not quest_reward_type_map then
		quest_reward_type_map = {}
		local quest_reward_csv_list = CsvParser.getCsvList("task_quest_reward")
		local index = 1

		for i, v in ipairs(quest_reward_csv_list) do
			if v.level < index then
				index = 1
			end

			for j = index, v.level do
				quest_reward_type_map[v.reward_type .. "_" .. j] = v
			end

			index = v.level + 1
		end

		CacheData.set("InfoTaskQuest_quest_reward_type_map", quest_reward_type_map)
	end

	local quest_reward_csv = quest_reward_type_map[reward_type .. "_" .. level]
	local rewardArr = nil

	if quest_reward_csv then
		rewardArr = SheetUtil.getColumnList(quest_reward_csv, {
			"reward_id_",
			"reward_num_"
		}, {
			"id",
			"num"
		})
	else
		rewardArr = {}
	end

	return rewardArr
end

function InfoTaskQuest.getIconName(taskData)
	local taskCSV = CsvParser.getCsvData("task", taskData.base_id)
	local effectType = 1

	if taskCSV.type == 4 then
		effectType = 3
	elseif taskCSV.type == 3 then
		effectType = 2
	elseif taskCSV.type == 5 then
		effectType = 1
	end

	local finType = 2

	if taskData.fin == 1 then
		finType = 1
	end

	return "quest_" .. effectType .. "_" .. finType
end

return InfoTaskQuest
