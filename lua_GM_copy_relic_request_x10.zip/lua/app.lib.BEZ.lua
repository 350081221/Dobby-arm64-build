local function jie_cheng(i)
	local n = 1

	for j = 1, i do
		n = n * j
	end

	return n
end

local function C(n, k)
	local son = jie_cheng(n)
	local mother = jie_cheng(k) * jie_cheng(n - k)

	return son / mother
end

local function BEZ(n, k, t)
	return C(n, k) * math.pow(t, k) * math.pow(1 - t, n - k)
end

function P_BEZ(k, sz)
	local x_p = 0
	local y_p = 0
	local num = #sz

	for i = 1, num do
		local b = BEZ(num - 1, i - 1, k)
		x_p = x_p + sz[i].x * b
		y_p = y_p + sz[i].y * b
	end

	return {
		x = x_p,
		y = y_p
	}
end
