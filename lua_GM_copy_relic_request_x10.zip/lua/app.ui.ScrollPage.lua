local ScrollPage = class("ScrollPage", function (rect, frameName, pageTotal, pageWidth)
	local node = display.newClippingRectangleNode(rect)

	node:setNodeEventEnabled(true)

	return node
end)

function ScrollPage:ctor(rect, frameName, pageTotal, pageWidth)
	event_listener.extendMethods(self, true)
	self:setTouchSwallowEnabled(true)

	self.frame = UIManager.getUI(frameName)

	self.frame:setPosition(rect.x, rect.y)
	self:addChild(self.frame)

	self.rect = rect
	self.pageCount = pageTotal or 1
	self.pageIndex = 1
	self.pageListMap = {}
	self.pageButtonMap = {}
	self.pageWidth = pageWidth or display.width
	self.preIndex = 1
	self.stdDragTime = 2
	self.flipThreshold = 10
	self.angleRange = math.pi / 6
	self.draggable = true

	self:setTouchEnabled(true)
	self:addNodeEventListener(cc.NODE_TOUCH_EVENT, function (event)
		return self:onTouch(event.name, event.x, event.y)
	end)
end

function ScrollPage:setDraggable(b)
	self.draggable = b
end

function ScrollPage:onTouch(event, x, y)
	if UIManager.isLocked() then
		return false
	end

	if event ~= "began" or cc.rectContainsPoint(self.rect, cc.p(x, y)) then
		local list = self.pageListMap[self.pageIndex]
		local offsetX = 0
		local offsetY = 0

		if event == "began" then
			local layerX, layerY = self.frame:getPosition()
			self.drag = {
				speed = 0,
				startLayerX = layerX,
				startLayerY = layerY,
				startX = x,
				startY = y,
				preX = x,
				preY = y,
				preTime = os.clock()
			}

			if not self.draggable then
				self.drag.type = 1
			end

			self:stopMove()

			if list ~= nil then
				list:onTouch("began", self.drag.startX - offsetX, self.drag.startY - offsetY)
			end
		else
			if self.drag.type == nil then
				local distance = math.sqrt(math.pow(x - self.drag.startX, 2) + math.pow(y - self.drag.startY, 2))

				if self.flipThreshold < distance then
					local angle = math.atan2(y - self.drag.startY, x - self.drag.startX)

					if math.abs(angle) < self.angleRange or math.abs(math.abs(angle) - math.pi) < self.angleRange then
						self.drag.type = 0

						if list ~= nil then
							list:onTouchCancelled(self.drag.startX - offsetX, self.drag.startY - offsetY)
						end
					else
						self.drag.type = 1

						if list ~= nil then
							list:onTouch("began", self.drag.startX - offsetX, self.drag.startY - offsetY)
						end
					end
				end
			end

			if self.drag.type == 0 then
				if event == "moved" then
					self:setOffset(self:getLegalX(self.drag.startLayerX + x - self.drag.startX))

					local clock = os.clock()
					local offsetTime = clock - self.drag.preTime

					if offsetTime > 0 then
						local standardTime = self.stdDragTime / 100
						self.drag.speed = (self.drag.speed * standardTime + (x - self.drag.preX) * standardTime / offsetTime * offsetTime) / (offsetTime + standardTime)
					end

					self.drag.preTime = clock
					self.drag.preX = x
					self.drag.preY = y
				elseif event == "ended" then
					self:flip(self:getLegalX(self.drag.startLayerX + x - self.drag.startX), self.drag.speed)
				end
			else
				if self.drag.type == 1 then
					if list ~= nil then
						list:onTouch(event, x - offsetX, y - offsetY)
					end
				elseif event == "ended" then
					if list ~= nil then
						list:onTouch("began", self.drag.startX - offsetX, self.drag.startY - offsetY)
						list:onTouch("ended", self.drag.startX - offsetX, self.drag.startY - offsetY)
					else
						self:dispatchEvent({
							name = "TAP",
							x = x,
							y = y
						})
					end
				end

				if event == "ended" and self:getPositionX() % self.pageWidth ~= 0 then
					self:flip(self:getLegalX(self.drag.startLayerX + x - self.drag.startX), self.drag.speed)
				end
			end
		end

		return true
	end
end

function ScrollPage:addList(pageIndex, flagName, ListClass)
	local list = ListClass.new(self.frame:getRectByFlag(flagName))

	list:setTouchDelegate()
	self.frame:addChild(list, 1000)

	if self.pageCount == 1 then
		list:setActive(true)
	end

	self.pageListMap[pageIndex] = list

	return list
end

function ScrollPage:stopMove()
	transition.stopTarget(self)
end

function ScrollPage:setPage(index, animated)
	if animated == nil then
		animated = true
	end

	self:setOffset(self.rect.x - (index - 1) * self.pageWidth, animated)

	self.pageIndex = index

	for k, list in pairs(self.pageListMap) do
		if index == k then
			list:setActive(true)
		else
			list:setActive(false)
		end
	end

	local list = self.pageListMap[index]

	if list ~= nil then
		list:resetHolder()
	end

	if index ~= self.preIndex then
		self.preIndex = index

		self:dispatchEvent({
			name = "setPage",
			index = index,
			count = self.pageCount
		})
	end
end

function ScrollPage:flip(x, speed)
	local t = math.abs(speed) / 1
	local dis = speed * t / 2
	local compareX = x + dis
	local pageX = self.rect.x - (self.pageIndex - 1) * self.pageWidth

	if compareX < pageX - self.pageWidth / 3 then
		if self.pageIndex < self.pageCount then
			self:setPage(self.pageIndex + 1)

			return
		end
	elseif compareX > pageX + self.pageWidth / 3 and self.pageIndex > 1 then
		self:setPage(self.pageIndex - 1)

		return
	end

	self:setPage(self.pageIndex)
end

function ScrollPage:setOffset(x, animated, time, easing)
	time = time or 0.1
	easing = easing or "sineOut"

	if self.rect.x < x then
		x = self.rect.x
	elseif x < self.rect.x - (self.pageCount - 1) * self.pageWidth then
		x = self.rect.x - (self.pageCount - 1) * self.pageWidth
	end

	if animated then
		transition.stopTarget(self)
		transition.moveTo(self.frame, {
			x = x,
			time = time,
			easing = easing
		})
	else
		self.frame:setPositionX(x)
	end
end

function ScrollPage:getLegalX(x)
	if self.rect.x < x then
		return self.rect.x
	elseif x < self.rect.x - (self.pageCount - 1) * self.pageWidth then
		return self.rect.x - (self.pageCount - 1) * self.pageWidth
	else
		return x
	end
end

function ScrollPage:onEnter()
end

function ScrollPage:onExit()
	self:setTouchEnabled(false)
	self:removeNodeEventListener(cc.NODE_TOUCH_EVENT)
	self:removeAllEventListeners()
	self:stopMove()
end

return ScrollPage
