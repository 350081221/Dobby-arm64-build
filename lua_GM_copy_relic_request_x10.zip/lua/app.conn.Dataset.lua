local Dataset = class("Dataset", ByteArray)
Dataset.ERROR_CMD_CODE = 10001
Dataset.ERROR_CMD_NAME = "ERROR_CMD"

function Dataset.forSend(cmd, data)
	local dataset = Dataset.new()
	dataset.cmd = cmd
	local protocol = Protocol.getByName(cmd)

	dataset:writeShort(protocol.code)

	if protocol:isEmpty() then
		dataset:writeUByte(0)
	end

	local looperArray, looperValueMap = nil

	while protocol:next() do
		if protocol:isLooperStart() then
			protocol:markLooperStart()

			local loopName = protocol:getLooperName()
			looperArray = data[loopName]

			dataset:writeUShort(#looperArray)

			if #looperArray > 0 then
				looperValueMap = table.remove(looperArray, 1)
			else
				protocol:skipLooper()
			end
		elseif protocol:isLooperOver() then
			if #looperArray > 0 then
				protocol:returnLooperStart()

				looperValueMap = table.remove(looperArray, 1)
			else
				looperValueMap = nil
				looperArray = nil
			end
		else
			local name, type = protocol:getNameAndType()

			if looperValueMap and looperValueMap[name] or data[name] then
				local value = nil

				if looperValueMap then
					value = looperValueMap[name]
				else
					value = data[name]
				end

				if type == "utf" then
					dataset:writeStringUShort(value)
				elseif type == "u32" then
					dataset:writeUInt(value)
				elseif type == "32" then
					dataset:writeInt(value)
				elseif type == "u16" then
					dataset:writeUShort(value)
				elseif type == "16" then
					dataset:writeShort(value)
				elseif type == "u8" then
					dataset:writeUByte(value)
				elseif type == "8" then
					dataset:writeByte(value)
				elseif type == "f" then
					dataset:writeFloat(value)
				elseif type == "d" then
					dataset:writeDouble(value)
				end
			else
				print("缺少封包数据 协议:", cmd, "数据:", name)
			end
		end
	end

	return dataset
end

function Dataset.forReceive(code, bytes)
	if code == Dataset.ERROR_CMD_CODE then
		local cmdCode = bytes:readUShort()
		local protocol = Protocol.getByCode(cmdCode)
		local cmdName = protocol.name
		local code = bytes:readUByte()

		print("Dataset.forReceive ERROR_CMD", cmdCode)

		return cmdName, {
			cmdCode = cmdCode,
			cmdName = cmdName,
			error = code
		}
	end

	local protocol = Protocol.getByCode(code)

	print("Dataset.forReceive", protocol.name)

	if protocol:isEmpty() then
		bytes:readUByte()
	end

	local data = {}
	local loopCount = 0
	local looperArray, looperValueMap = nil

	while protocol:next() do
		if protocol:isLooperStart() then
			loopCount = bytes:readUShort()

			protocol:markLooperStart()

			local loopName = protocol:getLooperName()
			looperArray = {}
			data[loopName] = looperArray

			if loopCount > 0 then
				looperValueMap = {}

				table.insert(looperArray, looperValueMap)

				loopCount = loopCount - 1
			else
				protocol:skipLooper()
			end
		elseif protocol:isLooperOver() then
			if loopCount > 0 then
				loopCount = loopCount - 1

				protocol:returnLooperStart()

				looperValueMap = {}

				table.insert(looperArray, looperValueMap)
			else
				looperValueMap = nil
				looperArray = nil
			end
		else
			local name, type = protocol:getNameAndType()
			local value = nil

			if type == "utf" then
				value = bytes:readStringUShort()
			elseif type == "u32" then
				value = bytes:readUInt()
			elseif type == "32" then
				value = bytes:readInt()
			elseif type == "u16" then
				value = bytes:readUShort()
			elseif type == "16" then
				value = bytes:readShort()
			elseif type == "u8" then
				value = bytes:readUByte()
			elseif type == "8" then
				value = bytes:readByte()
			elseif type == "f" then
				value = bytes:readFloat()
			elseif type == "d" then
				value = bytes:readDouble()
			end

			if looperValueMap then
				looperValueMap[name] = value
			else
				data[name] = value
			end
		end
	end

	return protocol.name, data
end

function Dataset:ctor()
	Dataset.super.ctor(self, ByteArray.ENDIAN_BIG)
end

function Dataset:getPack(__offset, __length)
	__offset = __offset or 1
	__length = __length or #self._buf
	local __t = {}
	local __len = string.pack(self:_getLC("h"), __length)

	for i = 1, #__len do
		__t[#__t + 1] = string.byte(string.sub(__len, i, i))
	end

	for i = __offset, __length do
		__t[#__t + 1] = string.byte(self._buf[i])
	end

	local __fmt = self:_getLC("b" .. #__t)
	local __s = string.pack(__fmt, unpack(__t))

	return __s
end

return Dataset
