local socket = require("socket")
local ListCell = import(".ListCell")
local List = class("List", function (rect, direction, noClipping)
	rect = rect or cc.rect(0, 0, 0, 0)
	local node = nil

	if noClipping and type(noClipping) == "boolean" then
		node = display.newNode()
	else
		node = display.newClippingRectangleNode(cc.rect(0, 0, rect.width + 1, rect.height + 1))
	end

	node.noClipping = noClipping

	node:setPosition(rect.x, rect.y)
	node:setContentSize(cc.size(rect.width + 1, rect.height + 1))

	return node
end)
List.DIRECTION_VERTICAL = 1
List.DIRECTION_HORIZONTAL = 2
List.cellPoolMap = {}

function List.putCellPool(cellSize, cellName, cellAlias, cols, direction, cell)
	local tagName = cellName or cellAlias

	transition.stopTarget(cell)
	cell:setPosition(0, 0)
	cell:removeAllEventListeners()
	cell:removeAllNodeEventListeners()
	cell:retain()
	cell:removeSelf()

	if tagName then
		local poolTag = tagName .. "_" .. cellSize.width .. "_" .. cellSize.height .. "_" .. cols .. "_" .. direction

		if not List.cellPoolMap[poolTag] then
			List.cellPoolMap[poolTag] = {}
		end

		table.insert(List.cellPoolMap[poolTag], cell)
	end
end

function List.getCellPool(cellSize, cellName, cellAlias, cols, direction, leftSpace, rightSpace)
	local tagName = cellName or cellAlias

	if tagName then
		local poolTag = tagName .. "_" .. cellSize.width .. "_" .. cellSize.height .. "_" .. cols .. "_" .. direction

		if List.cellPoolMap[poolTag] and #List.cellPoolMap[poolTag] > 0 then
			local cell = table.remove(List.cellPoolMap[poolTag], 1)

			return cell, true
		end
	end

	local cell = ListCell.new(cellSize, cellName, cols, direction, leftSpace, rightSpace)
	cell._poolData = {
		cellSize = cellSize,
		cellName = cellName,
		cellAlias = cellAlias
	}

	return cell, false
end

function List.clearCellPool()
	for poolTag, pool in pairs(List.cellPoolMap) do
		for i = 1, #pool do
			pool[i]:release()
		end
	end

	List.cellPoolMap = {}
end

function List:setRect(rect)
	self:setPosition(rect.x, rect.y)
	self:setContentSize(cc.size(rect.width + 1, rect.height + 1))

	if not self.noClipping then
		self:setClippingRegion(cc.rect(0, 0, rect.width + 1, rect.height + 1))
	end

	self.rect = rect
	self.touchRect = cc.rect(0, 0, rect.width, rect.height)

	self.view:setContentSize(cc.size(rect.width, rect.height))
end

function List:ctor(rect, direction)
	event_listener.extendMethods(self, true)

	direction = direction or List.DIRECTION_VERTICAL

	self:setTouchSwallowEnabled(false)
	assert(direction == List.DIRECTION_VERTICAL or direction == List.DIRECTION_HORIZONTAL, "List:ctor() - invalid direction")
	self:setCascadeOpacityEnabled(true)
	self:setCascadeColorEnabled(true)

	self.type = "list"
	self.dragThreshold = 20
	self.isTap = true
	self.isBounc = true
	self.bouncDecay = 0.7
	self.bouncValue = 0
	self.stdDragTime = 2
	self.speedDecay = 0.95
	self.speed = 0
	self.inertialThreshold = 2
	self.defaultAnimateTime = 0.2
	self.defaultAnimateEasing = "sineOut"
	self.direction = direction
	self.rect = rect
	self.touchRect = cc.rect(0, 0, rect.width, rect.height)
	self.absX = 0
	self.absY = 0
	self.cells = {}
	self.datas = {}
	self.cellSpaces = {
		0
	}
	self.totalHeight = 0
	self.active = true
	self.cols = 1
	self.leftSpace = 0
	self.rightSpace = 0
	self.topSpace = 0
	self.bottomSpace = 0
	self.view = display.newNode()

	self.view:setContentSize(cc.size(rect.width, rect.height))
	self.view:setCascadeOpacityEnabled(true)
	self.view:setCascadeColorEnabled(true)
	self.view:setTouchSwallowEnabled(false)
	self:addChild(self.view)
	self:setNodeEventEnabled(true)
	self:addNodeEventListener(cc.NODE_TOUCH_EVENT, function (event)
		if UIManager.isLocked() and self.ignoreLock ~= true then
			return false
		end

		local eventName = event.name

		if eventName == "cancelled" then
			eventName = "ended"
		end

		return self:onTouch(eventName, event.x, event.y)
	end)
	self:setTouchMode(cc.TOUCH_MODE_ONE_BY_ONE)
	self:setTouchEnabled(true)
end

function List:setTouchDelegate()
	self:setTouchSwallowEnabled(true)
	self.view:removeNodeEventListener(cc.NODE_TOUCH_EVENT)
end

function List:setSpace(topSpace, bottomSpace)
	self.topSpace = topSpace or self.topSpace
	self.bottomSpace = bottomSpace or self.bottomSpace
end

function List:setCols(cols, leftSpace, rightSpace)
	self.cols = cols
	self.leftSpace = leftSpace or self.leftSpace
	self.rightSpace = rightSpace or self.rightSpace
end

function List:setCellName(name)
	self.cellName = name
end

function List:setCellAlias(alias)
	self.cellAlias = alias
end

function List:setCellSize(size)
	self.cellSize = size
end

function List:getCellName(index)
	return self.cellName
end

function List:getCellAlias(index)
	return self.cellAlias
end

function List:getCellSize(index)
	return self.cellSize
end

function List:getData(index)
	return self.datas[index]
end

function List:setPickable(pickable, minIndex, maxIndex, oneDirection)
	self.pickable = pickable
	self.pickableMinIndex = minIndex
	self.pickableMaxIndex = maxIndex
	self.pickableOneDirection = oneDirection
end

function List:setPickCallback(callback)
	self.pickCallback = callback
end

function List:checkPickable(ui, data, x, y)
	return true
end

function List:onCellPicked(ui, data, picked)
end

function List:getPickNode(cell)
	return cell
end

function List:stopPickAnimation(isHide)
	if self.afterPick then
		local dragNode = self.afterPick.node

		transition.stopTarget(dragNode)
		dragNode:retain()
		dragNode:removeFromParent()
		dragNode:setPosition(self.afterPick.x, self.afterPick.y)
		dragNode:setLocalZOrder(self.afterPick.zorder)
		self.afterPick.parent:addChild(dragNode)

		if self.afterPick.preScale then
			dragNode:setScale(self.afterPick.preScale)
		end

		dragNode:release()
		dragNode:setVisible(not isHide)

		self.afterPick = nil

		self:onMoveStop()
	end
end

function List:setItems(datas, keepOffset)
	self:removeAll()

	self.items = datas
	local preScrollOffset = self.scrollOffset

	if self.cols > 1 then
		local items = {}

		for i = 1, math.ceil(#datas / self.cols) do
			local item = {}

			for j = 1, self.cols do
				local index = (i - 1) * self.cols + j

				if datas[index] ~= nil then
					table.insert(item, datas[index])
				else
					break
				end
			end

			table.insert(items, item)
		end

		datas = items
	end

	self:stopMove()

	local isKeepOffset = keepOffset and preScrollOffset
	local rs = self:addRawItems(datas, nil, isKeepOffset)

	if isKeepOffset then
		local minX, maxX = self:getMinMax()
		preScrollOffset = math.max(minX, math.min(maxX, preScrollOffset))

		self:setContentOffset(preScrollOffset)
		self:moveHolder()
	end

	self:refreshEmptyText()

	return rs
end

function List:addRawItems(datas, isAddToItems, keepOffset)
	for pageIndex = 1, #datas do
		if isAddToItems then
			table.insert(self.items, datas[pageIndex])
		end

		table.insert(self.datas, datas[pageIndex])

		local index = #self.cellSpaces
		local cellSize = self:getCellSize(index, datas[pageIndex])

		if self.direction == List.DIRECTION_HORIZONTAL then
			table.insert(self.cellSpaces, self.cellSpaces[index] + cellSize.width)

			self.totalHeight = self.totalHeight + cellSize.width
		else
			table.insert(self.cellSpaces, self.cellSpaces[index] + cellSize.height)

			self.totalHeight = self.totalHeight + cellSize.height
		end
	end

	if not keepOffset then
		if self.direction == List.DIRECTION_HORIZONTAL then
			self:scrollToMax()
		else
			self:scrollToMin()
		end
	end

	if self.active then
		self:resetHolder()
	end

	self:refreshEmptyText()
end

function List:addItems(datas)
	self.items = self.items or {}
	local preScrollOffset = self.scrollOffset

	self:addRawItems(datas, true, preScrollOffset)

	if preScrollOffset then
		self:setContentOffset(preScrollOffset)
		self:moveHolder()
	end

	self:refreshEmptyText()
end

function List:removeLast()
	if #self.datas > 0 then
		local lastData = self.datas[#self.datas]
		local cellSize = self:getCellSize(#self.datas, lastData)

		if self.direction == List.DIRECTION_HORIZONTAL then
			self.totalHeight = self.totalHeight - cellSize.width
		else
			self.totalHeight = self.totalHeight - cellSize.height
		end

		local preTotal = #self.datas

		self:removeCell(preTotal)

		if self.preEndIndex == preTotal then
			self.preEndIndex = self.preEndIndex - 1
		end

		table.remove(self.datas, #self.datas)
		table.remove(self.items, #self.items)
		table.remove(self.cellSpaces, #self.cellSpaces)
	end
end

function List:removeFirst()
	if #self.datas > 0 then
		local lastData = self.datas[1]
		local cellSize = self:getCellSize(1, lastData)

		if self.direction == List.DIRECTION_HORIZONTAL then
			self.totalHeight = self.totalHeight - cellSize.width
		else
			self.totalHeight = self.totalHeight - cellSize.height
		end

		local minX, maxX = self:getMinMax()

		self:removeCell(1)

		local cellTotal = #self.cells

		for i = 1, cellTotal - 1 do
			self.cells[i] = self.cells[i + 1]

			if self.cells[i] then
				if self.direction == List.DIRECTION_HORIZONTAL then
					self.cells[i]:setPositionX(self.cells[i]:getPositionX() - cellSize.width)
				else
					self.cells[i]:setPositionY(self.cells[i]:getPositionY() + cellSize.height)
				end
			end
		end

		self.cells[cellTotal] = nil
		self.preStartIndex = self.preStartIndex - 1

		if self.preEndIndex == cellTotal then
			self.preEndIndex = self.preEndIndex - 1
		end

		table.remove(self.datas, 1)
		table.remove(self.items, 1)
		table.remove(self.cellSpaces, 1)

		for i, v in ipairs(self.cellSpaces) do
			self.cellSpaces[i] = v - cellSize.height
		end
	end
end

function List:removeAll()
	for index, cell in pairs(self.cells) do
		local _poolData = cell._poolData

		self:onCellRemove(cell.ui, cell.data, cell.index)
		List.putCellPool(_poolData.cellSize, _poolData.cellName, _poolData.cellAlias, self.cols, self.direction, cell)
	end

	self.cells = {}
	self.datas = {}
	self.cellSpaces = {
		0
	}
	self.preStartIndex = nil
	self.preEndIndex = nil
	self.selectedCell = nil
	self.totalHeight = 0
end

function List:addCell(index)
	local data = self.datas[index]
	local cellSize = self:getCellSize(index, data)
	local cell, isRecycle = List.getCellPool(self:getCellSize(index), self:getCellName(index), self:getCellAlias(index), self.cols, self.direction, self.leftSpace, self.rightSpace)

	if self.pickable then
		display.getRunningScene():addChild(cell)
		cell:removeAllEventListeners()
		cell:removeAllNodeEventListeners()
		cell:retain()
		cell:removeSelf()

		isRecycle = true
	end

	cell:setData(data)
	cell:addEventListener("onTapListIcon", function (event)
		return self:onTapListIcon(event)
	end)
	cell:addEventListener("onTouchListIcon", function (event)
		return self:onTouchListIcon(event)
	end)

	cell.index = index
	self.cells[index] = cell

	self:onCellInitRaw(cell)

	if self.direction == List.DIRECTION_HORIZONTAL then
		cell:setPositionX(self:getCellPxByIndex(index))
	else
		cell:setPositionY(self.touchRect.height - self:getCellPxByIndex(index + 1))
	end

	if self.selectedIndex then
		local rawIndex = math.floor((self.selectedIndex - 1) / self.cols) + 1

		if rawIndex == index then
			self.selectedCell = cell

			if self.cols > 1 then
				local colIndex = (self.selectedIndex - 1) % self.cols + 1

				if cell.ui_cols[colIndex] then
					self:onCellSelected(cell.ui_cols[colIndex], cell.data[colIndex], true, true)
				end
			else
				self:onCellSelected(cell.ui, cell.data, true, true)
			end
		end
	end

	self.view:addChild(cell)

	if isRecycle then
		cell:release()
	end
end

function List:removeCell(index)
	local cell = self.cells[index]

	if self.selectedCell == cell then
		self.selectedCell = nil
	end

	if cell then
		local _poolData = cell._poolData

		self:onCellRemove(cell.ui, cell.data, cell.index)
		List.putCellPool(_poolData.cellSize, _poolData.cellName, _poolData.cellAlias, self.cols, self.direction, cell)

		self.cells[index] = nil
	end
end

function List:getCell(index)
	return self.cells[index]
end

function List:getCells()
	return self.cells
end

function List:getCellUI(index)
	if self.cols > 1 then
		local cellIndex = math.floor((index - 1) / self.cols) + 1
		local cell = self:getCell(cellIndex)
		local colIndex = (index - 1) % self.cols + 1

		if not cell then
			return nil
		end

		return cell.ui_cols[colIndex]
	else
		local cell = self:getCell(index)

		if not cell then
			return nil
		end

		return cell.ui
	end
end

function List:getCurrentCell(x, y)
	local index = nil
	local viewX, viewY = self.view:getPosition()

	if self.direction == List.DIRECTION_HORIZONTAL then
		index = self:getCellIndexByPx(x - viewX)
	else
		index = self:getCellIndexByPx(self.touchRect.height + viewY - y)
	end

	return self.cells[index]
end

function List:getCellPxByIndex(index)
	return self.cellSpaces[index]
end

function List:getCellIndexByPx(px)
	if px < self.cellSpaces[1] then
		return 0
	end

	if self.cellSpaces[#self.cellSpaces] < px then
		return #self.cellSpaces
	end

	local left = 1
	local right = #self.cellSpaces
	local mid = math.ceil((left + right) / 2)

	while true do
		if px < self.cellSpaces[mid] then
			right = mid - 1
		elseif self.cellSpaces[mid + 1] and self.cellSpaces[mid + 1] <= px then
			left = mid + 1
		else
			return math.min(mid, #self.cellSpaces - 1)
		end

		mid = math.ceil((left + right) / 2)
	end
end

function List:onCellInitRaw(cell)
	if self.cols > 1 then
		for i = 1, self.cols do
			if cell.ui_cols[i] and cell.data[i] then
				local index = (cell.index - 1) * self.cols + i

				self:onCellInit(cell.ui_cols[i], cell.data[i], index)

				if self.selectEnabled then
					self:onCellSelected(cell.ui_cols[i], cell.data[i], self.selectedIndex == index, true)
				end
			end
		end
	else
		self:onCellInit(cell.ui, cell.data, cell.index)

		if self.selectEnabled then
			self:onCellSelected(cell.ui, cell.data, self.selectedIndex == cell.index, true)
		end
	end
end

function List:onCellInit(ui, data, index)
end

function List:onCellRemove(ui, data, index)
end

function List:setActive(active)
	self.active = active

	if not active then
		self:removeEnterFrame("holderScroll")
		self:removeEnterFrame("inertialScroll")
	end
end

function List:setHolders(holders, alwaysVisible, holderSpace)
	self.hasHolder = true
	self.holderAlwaysVisible = alwaysVisible
	self.holders = holders
	self.holderSpace = holderSpace or 0

	for i = 1, #self.holders do
		local holder = self.holders[i]

		if not self.holderAlwaysVisible then
			holder:setVisible(false)
			holder:setOpacity(0)
		end
	end
end

function List:resetHolder()
	self.moving = false

	if self.hasHolder then
		if self.direction == List.DIRECTION_HORIZONTAL then
			local viewWidth = self.touchRect.width
			local totalWidth = self.totalHeight + self.topSpace + self.bottomSpace
			self.holderWidth = math.floor(viewWidth * viewWidth / totalWidth)

			for i = 1, #self.holders do
				local holder = self.holders[i]

				holder:setVisible(true)
				transition.stopTarget(holder)

				if viewWidth < totalWidth then
					if not self.holderAlwaysVisible then
						holder:setVisible(true)
						holder:setOpacity(0)
					end

					holder:setSize(self.holderWidth)
				else
					holder:setVisible(false)
				end
			end
		else
			local viewHeight = self.touchRect.height
			local totalHeight = self.totalHeight + self.topSpace + self.bottomSpace
			self.holderHeight = math.floor(viewHeight * viewHeight / totalHeight)

			for i = 1, #self.holders do
				local holder = self.holders[i]

				holder:setVisible(true)
				transition.stopTarget(holder)

				if viewHeight < totalHeight then
					if not self.holderAlwaysVisible then
						holder:setVisible(true)
						holder:setOpacity(0)
					end

					holder:setSize(nil, self.holderHeight)
				else
					holder:setVisible(false)
				end
			end
		end

		self:moveHolder()
	end
end

function List:onMoveStart()
	if self.moving ~= true then
		self.moving = true

		self:removeEnterFrame("holderScroll")

		if self.hasHolder then
			self:addEnterFrame("holderScroll", handler(self, self.moveHolder))

			if not self.holderAlwaysVisible then
				for i = 1, #self.holders do
					local holder = self.holders[i]

					transition.stopTarget(holder)
					transition.fadeIn(holder, {
						easing = "sineOut",
						time = 0.2
					})
				end
			end
		end
	end
end

function List:onMoveStop()
	if self.moving == true then
		self.moving = false

		if self.hasHolder and not self.holderAlwaysVisible then
			for i = 1, #self.holders do
				local holder = self.holders[i]

				transition.stopTarget(holder)
				transition.fadeOut(holder, {
					easing = "sineOut",
					delay = 0.2,
					time = 0.2
				})
			end
		end
	end
end

function List:moveHolder()
	if self.hasHolder then
		if self.direction == List.DIRECTION_HORIZONTAL then
			local viewWidth = self.touchRect.width
			local viewX = 0
			local holderWidth = self.holderWidth or 100
			local totalWidth = self.totalHeight + self.topSpace + self.bottomSpace
			local holderX = -self.view:getPositionX()
			holderX = holderX * (viewWidth - math.floor(viewWidth * viewWidth / totalWidth)) / (totalWidth - viewWidth) + viewX
			holderX = math.max(viewX + self.holderSpace, math.min(holderX, viewWidth - holderWidth + viewX - self.holderSpace))

			for i = 1, #self.holders do
				local holder = self.holders[i]

				holder:setPos(holderX + self.rect.x)
			end
		else
			local viewHeight = self.touchRect.height
			local viewY = 0
			local holderHeight = self.holderHeight or 100
			local totalHeight = self.totalHeight + self.topSpace + self.bottomSpace
			local holderY = self.totalHeight - viewHeight - self.view:getPositionY() + viewY + self.bottomSpace
			holderY = holderY * (viewHeight - math.floor(viewHeight * viewHeight / totalHeight)) / (totalHeight - viewHeight) + viewY
			holderY = math.max(viewY + self.holderSpace, math.min(holderY, viewHeight - holderHeight + viewY - self.holderSpace))

			for i = 1, #self.holders do
				local holder = self.holders[i]

				holder:setPos(nil, holderY + self.rect.y)
			end
		end
	end

	if self.moving ~= true then
		self:removeEnterFrame("holderScroll")
	end
end

function List:setSelectEnabled(selectEnabled, unselectEnabled)
	self.selectEnabled = selectEnabled
	self.unselectEnabled = unselectEnabled

	if not selectEnabled then
		self:setUnselected()
	end
end

function List:setMultiSelectEnabled(multiSelectEnabled, isManual)
	self.multiSelectEnabled = multiSelectEnabled
	self.selectManual = isManual
	self.multiSelectIndex = {}

	if not selectEnabled then
		self:setUnselected()
		self:setUnselectedMulti()
	end
end

function List:setSelectedIndex(index, _multiSelected)
	if not index then
		if self.multiSelectEnabled then
			return
		else
			self:setUnselected()

			return
		end
	end

	local cell = self:getCell(math.floor((index - 1) / self.cols) + 1)

	if not cell then
		if self.multiSelectEnabled then
			local selected = nil
			selected = _multiSelected ~= nil and _multiSelected or self.multiSelectIndex[index] == nil

			if selected then
				self.multiSelectIndex[index] = true
			else
				self.multiSelectIndex[index] = nil
			end
		else
			self.selectedCell = nil
			self.selectedIndex = index
		end

		return
	end

	local data = cell.data

	if self.cols > 1 then
		local colIndex = (index - 1) % self.cols + 1
		data = cell.data[colIndex]
	end

	if self.selectableCheckFunc and not self.selectableCheckFunc(data) then
		return
	end

	if self.multiSelectEnabled then
		local selected = nil
		selected = _multiSelected ~= nil and _multiSelected or self.multiSelectIndex[index] == nil

		if selected then
			self.multiSelectIndex[index] = true
		else
			self.multiSelectIndex[index] = nil
		end

		if self.cols > 1 then
			local colIndex = (index - 1) % self.cols + 1

			if cell.ui_cols[colIndex] then
				self:onCellSelected(cell.ui_cols[colIndex], self.items[index], selected)
			end
		else
			self:onCellSelected(cell.ui, data, selected)
		end
	else
		local cell = self:getCell(math.floor((index - 1) / self.cols) + 1)

		if self.selectedIndex ~= index then
			if self.selectedCell then
				if self.cols > 1 then
					local colIndex = (self.selectedIndex - 1) % self.cols + 1

					if self.selectedCell.ui_cols[colIndex] then
						self:onCellSelected(self.selectedCell.ui_cols[colIndex], self.selectedCell.data[colIndex], false)
					end
				else
					self:onCellSelected(self.selectedCell.ui, self.selectedCell.data, false)
				end
			end

			self.selectedCell = cell
			self.selectedIndex = index

			if self.cols > 1 then
				local colIndex = (self.selectedIndex - 1) % self.cols + 1

				if self.selectedCell.ui_cols[colIndex] then
					self:onCellSelected(self.selectedCell.ui_cols[colIndex], self.selectedCell.data[colIndex], true)
				end
			else
				self:onCellSelected(self.selectedCell.ui, self.selectedCell.data, true)
			end

			self:dispatchEvent({
				name = "select",
				data = data,
				ui = cell.ui,
				index = index,
				colIndex = colIndex
			})
		elseif self.unselectEnabled and self.selectedIndex then
			self:setUnselected()
		end
	end
end

function List:setUnselected()
	if self.selectedCell then
		if self.cols > 1 then
			local colIndex = (self.selectedIndex - 1) % self.cols + 1

			if self.selectedCell.ui_cols[colIndex] then
				self:onCellSelected(self.selectedCell.ui_cols[colIndex], self.selectedCell.data[colIndex], false)
			end
		else
			self:onCellSelected(self.selectedCell.ui, self.selectedCell.data, false)
		end
	end

	self.selectedIndex = nil
	self.selectedCell = nil

	if self.multiSelectEnabled then
		self.multiSelectIndex = {}
	end

	self:dispatchEvent({
		name = "select"
	})
end

function List:setUnselectedMulti()
	if not self.multiSelectIndex then
		return
	end

	for index, _ in pairs(self.multiSelectIndex) do
		self.multiSelectIndex[index] = nil
		local cell = self:getCell(math.floor((index - 1) / self.cols) + 1)

		if cell then
			local data = cell.data

			if self.cols > 1 then
				local colIndex = (index - 1) % self.cols + 1
				data = cell.data[colIndex]
			end

			if self.cols > 1 then
				local colIndex = index % self.cols + 1

				if cell.ui_cols[colIndex] then
					self:onCellSelected(cell.ui_cols[colIndex], data[colIndex], false)
				end
			else
				self:onCellSelected(cell.ui, data, false)
			end
		end
	end
end

function List:getSelectedIndex()
	return self.selectedIndex
end

function List:getSelectedItem()
	if self.selectedIndex then
		return self.items[self.selectedIndex]
	end
end

function List:getSelectedMulti()
	local arr = {}

	if self.multiSelectIndex then
		for index, v in pairs(self.multiSelectIndex) do
			table.insert(arr, index)
		end
	end

	return arr
end

function List:isSelectedMulti(_index)
	if self.multiSelectIndex then
		for index, v in pairs(self.multiSelectIndex) do
			if index == _index then
				return true
			end
		end
	end

	return false
end

function List:setSelectedMulti(arr)
	self:setUnselectedMulti()

	if arr then
		for i, index in ipairs(arr) do
			self:setSelectedIndex(index)
		end
	end
end

function List:onCellSelected(ui, data, selected, isInit)
end

function List:setSelectedData(data)
	if self.selectedCell then
		self.items[self.selectedIndex] = data

		if self.cols > 1 then
			local colIndex = (self.selectedIndex - 1) % self.cols + 1

			if self.selectedCell.ui_cols[colIndex] then
				self:onCellInit(self.selectedCell.ui_cols[colIndex], data, (self.selectedCell.index - 1) * self.cols + colIndex)
				self:onCellSelected(self.selectedCell.ui_cols[colIndex], data, true)
			end
		else
			self:onCellInit(self.selectedCell.ui, data, self.selectedCell.index)
			self:onCellSelected(self.selectedCell.ui, data, true)
		end
	end
end

function List:setSelectableCheck(func)
	self.selectableCheckFunc = func
end

function List:setTapGroup(groupName)
	self.tapGroupName = groupName
end

function List:onTapListIcon(event)
	if self.cols > 1 then
		local data = event.data
		local ui = event.ui
		local colIndex = nil

		if self.direction == List.DIRECTION_HORIZONTAL then
			if self.leftSpace <= event.y and event.y <= self.touchRect.height - self.rightSpace then
				local colHeight = (self.touchRect.height - self.leftSpace - self.rightSpace) / self.cols
				colIndex = math.floor((event.y - self.leftSpace) / colHeight) + 1
				colIndex = self.cols + 1 - colIndex
			end
		elseif self.leftSpace <= event.x and event.x <= self.touchRect.width - self.rightSpace then
			local colWidth = (self.touchRect.width - self.leftSpace - self.rightSpace) / self.cols
			colIndex = math.floor((event.x - self.leftSpace) / colWidth) + 1
		end

		if colIndex and data[colIndex] ~= nil then
			if (self.selectEnabled or self.multiSelectEnabled) and not self.selectManual then
				self:setSelectedIndex((event.index - 1) * self.cols + colIndex)
			end

			UIManager.callTapCallback(self.tapGroupName, event.ui_cols[colIndex])
			self:dispatchEvent({
				name = "onTapListIcon",
				data = data[colIndex],
				x = event.x,
				y = event.y,
				ui = event.ui_cols[colIndex],
				index = (event.index - 1) * self.cols + colIndex
			})
		end
	else
		if (self.selectEnabled or self.multiSelectEnabled) and not self.selectManual then
			self:setSelectedIndex(event.index)
		end

		UIManager.callTapCallback(self.tapGroupName, event.ui)
		self:dispatchEvent({
			name = "onTapListIcon",
			data = event.data,
			x = event.x,
			y = event.y,
			ui = event.ui,
			index = event.index
		})
	end
end

function List:onTouchListIcon(event)
	if self.cols > 1 then
		local data = event.data
		local ui = event.ui
		local colIndex = nil

		if self.direction == List.DIRECTION_HORIZONTAL then
			if self.leftSpace <= event.y and event.y <= self.touchRect.height - self.rightSpace then
				local colHeight = (self.touchRect.height - self.leftSpace - self.rightSpace) / self.cols
				colIndex = math.floor((event.y - self.leftSpace) / colHeight) + 1
				colIndex = self.cols + 1 - colIndex
			end
		elseif self.leftSpace <= event.x and event.x <= self.touchRect.width - self.rightSpace then
			local colWidth = (self.touchRect.width - self.leftSpace - self.rightSpace) / self.cols
			colIndex = math.floor((event.x - self.leftSpace) / colWidth) + 1
		end

		if colIndex and data[colIndex] ~= nil then
			UIManager.callTapCallbackTouch(self.tapGroupName, event.ui_cols[colIndex], event.state, self)
			self:dispatchEvent({
				name = "onTouchListIcon",
				data = data[colIndex],
				state = event.state,
				x = event.x,
				y = event.y,
				ui = event.ui,
				index = (event.index - 1) * self.cols + colIndex
			})
		end
	else
		UIManager.callTapCallbackTouch(self.tapGroupName, event.ui, event.state, self)
		self:dispatchEvent({
			name = "onTouchListIcon",
			state = event.state,
			data = event.data,
			x = event.x,
			y = event.y,
			ui = event.ui,
			index = event.index
		})
	end
end

function List:getOverRange(testValue)
	if self.direction == List.DIRECTION_HORIZONTAL then
		local x = testValue or self.absX
		local minX, maxX = self:getMinMax()

		if maxX < x then
			return maxX
		elseif x < minX then
			return minX
		end
	else
		local y = testValue or self.absY
		local minY, maxY = self:getMinMax()

		if maxY < y then
			return maxY
		elseif y < minY then
			return minY
		end
	end

	return false
end

function List:getMinMax()
	if self.direction == List.DIRECTION_HORIZONTAL then
		local maxX = self.topSpace
		local minX = math.min(maxX, self.touchRect.width - self.cellSpaces[#self.cellSpaces] - self.bottomSpace)

		return minX, maxX
	else
		local minY = 0 - self.topSpace
		local maxY = math.max(minY, 0 - self.touchRect.height + self.cellSpaces[#self.cellSpaces] + self.bottomSpace)

		return minY, maxY
	end
end

function List:scrollToIndex(index, animated, offset)
	if self.cols > 1 then
		index = math.min(index / self.cols)
	end

	if self.preStartIndex and self.preEndIndex then
		index = index + math.floor((self.preEndIndex - self.preStartIndex) / 2 + 2)
	end

	index = math.max(1, math.min(#self.cellSpaces, index))

	if not self.cellSpaces[index] then
		return
	end

	local pos = nil

	if self.direction == List.DIRECTION_HORIZONTAL then
		local maxX = self.topSpace
		pos = math.min(maxX, self.touchRect.width - self.cellSpaces[index] - self.bottomSpace)
	else
		local minY = 0 - self.topSpace
		pos = math.max(minY, 0 - self.touchRect.height + self.cellSpaces[index] + self.bottomSpace)
	end

	offset = offset or 0

	self:stopMove()
	self:setContentOffset(pos + offset, animated)
	self:moveHolder()
end

function List:toIndex(index, animated)
	index = math.max(1, math.min(#self.cellSpaces, index))

	if not self.cellSpaces[index] then
		return
	end

	local pos = self.cellSpaces[index]

	self:stopMove()
	self:setContentOffset(pos, animated)
	self:moveHolder()
end

function List:isMax()
	local min, max = self:getMinMax()

	return self.scrollOffset == max
end

function List:scrollToMax(animated)
	local min, max = self:getMinMax()

	self:setContentOffset(max, animated)
end

function List:isMin()
	local min, max = self:getMinMax()

	return self.scrollOffset == min
end

function List:scrollToMin(animated)
	local min, max = self:getMinMax()

	self:setContentOffset(min, animated)
end

function List:setContentOffset(abs, animated, time, easing)
	local x = 0
	local y = 0

	if self.direction == List.DIRECTION_HORIZONTAL then
		self.absX = abs
		x = abs
		local minX, maxX = self:getMinMax()

		if self.isBounc then
			if maxX < x then
				x = maxX + math.pow(abs - maxX, self.bouncDecay)
				self.bouncValue = abs - maxX
			elseif x < minX then
				x = minX - math.pow(minX - abs, self.bouncDecay)
				self.bouncValue = abs - minX
			end
		elseif maxX < x then
			x = maxX
		elseif x < minX then
			x = minX
		end

		self.scrollOffset = x
	else
		self.absY = abs
		y = abs
		local minY, maxY = self:getMinMax()

		if self.isBounc then
			if maxY < y then
				y = maxY + math.pow(abs - maxY, self.bouncDecay)
				self.bouncValue = abs - maxY
			elseif y < minY then
				y = minY - math.pow(minY - abs, self.bouncDecay)
				self.bouncValue = abs - minY
			end
		elseif maxY < y then
			y = maxY
		elseif y < minY then
			y = minY
		end

		self.scrollOffset = y
	end

	if animated then
		transition.stopTarget(self.view)
		self:addEnterFrame("onSetContentOffsetLoop", function ()
			local x, y = self.view:getPosition()

			self:onSetContentOffset(x, y)
		end)
		transition.moveTo(self.view, {
			x = x,
			y = y,
			time = time or self.defaultAnimateTime,
			easing = easing or self.defaultAnimateEasing,
			onComplete = function ()
				self:removeEnterFrame("onSetContentOffsetLoop")

				local x, y = self.view:getPosition()

				self:onSetContentOffset(x, y)
				self:onMoveStop()
			end
		})
	else
		self.view:setPosition(x, y)
		self:onSetContentOffset(x, y)
	end
end

function List:onSetContentOffset(x, y)
	local startIndex, endIndex = nil

	if self.direction == List.DIRECTION_HORIZONTAL then
		startIndex = self:getCellIndexByPx(-x)
		endIndex = self:getCellIndexByPx(self.touchRect.width - x)
	else
		startIndex = self:getCellIndexByPx(y)
		endIndex = self:getCellIndexByPx(y + self.touchRect.height)
	end

	startIndex = math.max(1, startIndex)
	endIndex = math.min(#self.datas, endIndex)

	if not self.preStartIndex then
		for i = startIndex, endIndex do
			self:addCell(i)
		end
	else
		local existMap = {}

		for i = self.preStartIndex, self.preEndIndex do
			if i < startIndex or endIndex < i then
				self:removeCell(i)
			else
				existMap[i] = true
			end
		end

		for i = startIndex, endIndex do
			if not existMap[i] then
				self:addCell(i)
			end
		end
	end

	self.preStartIndex = startIndex
	self.preEndIndex = endIndex

	if self.direction == List.DIRECTION_VERTICAL and self.arc then
		local viewY = self.view:getPositionY()

		for i, cell in pairs(self.cells) do
			if self.cols <= 1 then
				local cellX, cellY = cell:getPosition()
				local xOffset = 0 - self.arc.center.x
				local yOffset = cellY - self.arc.center.y + viewY + self.cellSize.height / 2
				local angle = math.atan2(yOffset, xOffset)
				local newX = math.cos(angle) * self.arc.center.x + self.arc.center.x

				cell:setPositionX(newX)
				cell:setScale(self.arc.scale.max - (self.arc.scale.max - self.arc.scale.min) * (1 + math.cos(angle)))
			end
		end
	end

	if self.direction == List.DIRECTION_HORIZONTAL then
		self:dispatchEvent({
			name = "scroll",
			position = self.scrollOffset
		})
	else
		self:dispatchEvent({
			name = "scroll",
			position = self.scrollOffset
		})
	end
end

function List:stopMove()
	self:removeEnterFrame("inertialScroll")
	transition.stopTarget(self.view)
	self:removeEnterFrame("onSetContentOffsetLoop")
end

function List:onTouchBegan(x, y)
	self:stopMove()

	self.bouncValue = 0
	self.drag = {
		isTap = true,
		speed = 0,
		startViewX = self.absX,
		startViewY = self.absY,
		startX = x,
		startY = y,
		preX = x,
		preY = y,
		preTime = socket.gettime()
	}
	self.isTap = true
	local cell = self:getCurrentCell(x, y)

	if cell ~= nil then
		cell:onTouch("began", x, y)
	end

	local isCheckPickable = false
	local colIndex = nil

	if self.pickable and cell then
		isCheckPickable = true

		if isCheckPickable then
			if self.cols > 1 then
				if self.direction == List.DIRECTION_HORIZONTAL then
					if self.leftSpace <= y and y <= self.touchRect.height - self.rightSpace then
						local colHeight = (self.touchRect.height - self.leftSpace - self.rightSpace) / self.cols
						colIndex = math.floor((y - self.leftSpace) / colHeight) + 1
						colIndex = self.cols + 1 - colIndex
					end
				elseif self.leftSpace <= x and x <= self.touchRect.width - self.rightSpace then
					local colWidth = (self.touchRect.width - self.leftSpace - self.rightSpace) / self.cols
					colIndex = math.floor((x - self.leftSpace) / colWidth) + 1
				end

				local colCell = colIndex and cell.ui_cols[colIndex]
				isCheckPickable = isCheckPickable and colCell and colCell:isVisible() and self:checkPickable(colCell, colCell.data, x, y)
			else
				isCheckPickable = isCheckPickable and cell and self:checkPickable(cell, cell.data, x, y)
			end
		end
	end

	if isCheckPickable then
		if self.cols > 1 then
			local colCell = colIndex and cell.ui_cols[colIndex]

			if colCell and colCell.data then
				self.drag.cell = colCell
			end
		elseif (not self.pickableMinIndex or self.pickableMinIndex <= cell.index) and (not self.pickableMaxIndex or cell.index <= self.pickableMaxIndex) then
			self.drag.cell = cell
		end

		if self.drag.cell then
			local dragNode = self:getPickNode(self.drag.cell)

			if dragNode then
				local cellX, cellY = dragNode:getPosition()
				self.drag.cellStartX = cellX
				self.drag.cellStartY = cellY
				self.drag.cellStartZOrder = dragNode:getLocalZOrder()
			else
				local cellX, cellY = self.drag.cell:getPosition()
				self.drag.cellStartX = cellX
				self.drag.cellStartY = cellY
				self.drag.cellStartZOrder = self.drag.cell:getLocalZOrder()
			end
		else
			self.drag.cell = nil
		end
	end

	return true
end

function List:onTouchMoved(x, y)
	local cell = self:getCurrentCell(x, y)
	local clock = socket.gettime()

	if self.direction == List.DIRECTION_HORIZONTAL then
		if self.drag.isTap and (self.dragThreshold <= math.abs(x - self.drag.startX) or self.pickable and self.dragThreshold <= math.abs(y - self.drag.startY)) then
			self.drag.isTap = false
			self.isTap = false
			local isCheckPickable = false

			if self.pickable then
				if self.pickableOneDirection then
					if self.dragThreshold <= math.abs(y - self.drag.startY) then
						isCheckPickable = true
					end
				else
					isCheckPickable = true
				end
			end

			isCheckPickable = isCheckPickable and self.drag.cell and self.drag.cell:isVisible() and self:checkPickable(self.drag.cell, self.drag.cell.data, self.drag.startX, self.drag.startY)

			if isCheckPickable and self.drag.cell then
				local dragNode = self:getPickNode(self.drag.cell)

				if dragNode then
					dragNode:setLocalZOrder(LayerConfig.pickCell)

					self.drag.preContainer = dragNode:getParent()
					local _x, _y = dragNode:getPosition()
					local pos = self.drag.preContainer:convertToWorldSpace(cc.p(_x, _y))
					self.drag.pickOffset = cc.p(pos.x - _x, pos.y - _y)

					dragNode:retain()
					dragNode:removeFromParent()
					display.getRunningScene():addChild(dragNode)

					local bigScale = UIManager.getBigScale()

					if bigScale ~= 1 and bigScale > 0 then
						self.drag.preScale = dragNode:getScale()

						dragNode:setScale(bigScale)
					end

					dragNode:release()
				end

				self:onCellPicked(self.drag.cell.ui or self.drag.cell, self.drag.cell.data, true)

				self.drag.pickStarted = true
				self.pickIndex = self:getPickIndex(self.drag)
				local pickPos = self:convertToWorldSpace(cc.p(x, y))
				local pickObj = {
					event = "began",
					name = "pickBegan",
					index = self.pickIndex,
					data = self.items[self.pickIndex],
					cell = self.drag.cell,
					x = pickPos.x,
					y = pickPos.y
				}

				self:dispatchEvent(pickObj)

				if self.pickCallback then
					self.pickCallback(pickObj)
				end
			else
				self.drag.startX = self.drag.startX + (self.drag.startX < x and self.dragThreshold or -self.dragThreshold)
			end

			if cell ~= nil then
				cell:onTouch("cancelled", x, y)
			end

			self:onMoveStart()
		end

		if not self.drag.pickStarted then
			local offsetTime = clock - self.drag.preTime

			if offsetTime > 0 then
				local standardTime = self.stdDragTime / 100
				self.drag.speed = (self.drag.speed * standardTime + (x - self.drag.preX) * standardTime / offsetTime * offsetTime) / (offsetTime + standardTime)
			end
		end

		if not self.drag.isTap then
			if not self.drag.pickStarted then
				self:setContentOffset(x - self.drag.startX + self.drag.startViewX)
			elseif self.drag.cell then
				local dragNode = self:getPickNode(self.drag.cell)

				if dragNode then
					local cellX = self.drag.cellStartX + x - self.drag.startX
					local cellY = self.drag.cellStartY + y - self.drag.startY
					local bigScale = UIManager.getBigScale()

					if bigScale ~= 1 and bigScale > 0 then
						cellX = self.drag.cellStartX + (x - self.drag.startX) * bigScale
						cellY = self.drag.cellStartY + (y - self.drag.startY) * bigScale
					end

					dragNode:setPosition(cellX + self.drag.pickOffset.x, cellY + self.drag.pickOffset.y)
				end

				local pickPos = self:convertToWorldSpace(cc.p(x, y))
				local pickObj = {
					event = "moved",
					name = "pickMoved",
					index = self.pickIndex,
					data = self.items[self.pickIndex],
					cell = self.drag.cell,
					x = pickPos.x,
					y = pickPos.y
				}

				self:dispatchEvent(pickObj)

				if self.pickCallback then
					self.pickCallback(pickObj)
				end
			end
		elseif cell ~= nil then
			cell:onTouch("moved", x, y)
		end
	else
		if self.drag.isTap and (self.dragThreshold <= math.abs(y - self.drag.startY) or self.pickable and self.dragThreshold <= math.abs(x - self.drag.startX)) then
			self.drag.isTap = false
			self.isTap = false
			local isCheckPickable = false

			if self.pickable then
				if self.pickableOneDirection then
					if self.dragThreshold <= math.abs(x - self.drag.startX) then
						isCheckPickable = true
					end
				else
					isCheckPickable = true
				end
			end

			isCheckPickable = isCheckPickable and self.drag.cell and self.drag.cell:isVisible() and self:checkPickable(self.drag.cell, self.drag.cell.data, self.drag.startX, self.drag.startY)

			if isCheckPickable and self.drag.cell then
				local dragNode = self:getPickNode(self.drag.cell)

				if dragNode then
					dragNode:setLocalZOrder(LayerConfig.pickCell)

					self.drag.preContainer = dragNode:getParent()
					local _x, _y = dragNode:getPosition()
					local pos = self.drag.preContainer:convertToWorldSpace(cc.p(_x, _y))
					self.drag.pickOffset = cc.p(pos.x - _x, pos.y - _y)

					dragNode:retain()
					dragNode:removeFromParent()
					display.getRunningScene():addChild(dragNode)

					local bigScale = UIManager.getBigScale()

					if bigScale ~= 1 and bigScale > 0 then
						self.drag.preScale = dragNode:getScale()

						dragNode:setScale(bigScale)
					end

					dragNode:release()
				end

				self:onCellPicked(self.drag.cell.ui or self.drag.cell, self.drag.cell.data, true)

				self.drag.pickStarted = true
				self.pickIndex = self:getPickIndex(self.drag)
				local pickPos = self:convertToWorldSpace(cc.p(x, y))
				local pickObj = {
					event = "began",
					name = "pickBegan",
					index = self.pickIndex,
					data = self.items[self.pickIndex],
					cell = self.drag.cell,
					x = pickPos.x,
					y = pickPos.y
				}

				self:dispatchEvent(pickObj)

				if self.pickCallback then
					self.pickCallback(pickObj)
				end
			else
				self.drag.startY = self.drag.startY + (self.drag.startY < y and self.dragThreshold or -self.dragThreshold)
			end

			if cell ~= nil then
				cell:onTouch("cancelled", x, y)
			end

			self:onMoveStart()
		end

		if not self.drag.pickStarted then
			local offsetTime = clock - self.drag.preTime

			if offsetTime > 0 then
				local standardTime = self.stdDragTime / 100
				self.drag.speed = (self.drag.speed * standardTime + (y - self.drag.preY) * standardTime / offsetTime * offsetTime) / (offsetTime + standardTime)
			end
		end

		if not self.drag.isTap then
			if not self.drag.pickStarted then
				self:setContentOffset(y - self.drag.startY + self.drag.startViewY)
			elseif self.drag.cell then
				local dragNode = self:getPickNode(self.drag.cell)

				if dragNode then
					local cellX = self.drag.cellStartX + x - self.drag.startX
					local cellY = self.drag.cellStartY + y - self.drag.startY
					local bigScale = UIManager.getBigScale()

					if bigScale ~= 1 and bigScale > 0 then
						cellX = self.drag.cellStartX + (x - self.drag.startX) * bigScale
						cellY = self.drag.cellStartY + (y - self.drag.startY) * bigScale
					end

					dragNode:setPosition(cellX + self.drag.pickOffset.x, cellY + self.drag.pickOffset.y)
				end

				local pickPos = self:convertToWorldSpace(cc.p(x, y))
				local pickObj = {
					event = "moved",
					name = "pickMoved",
					index = self.pickIndex,
					data = self.items[self.pickIndex],
					cell = self.drag.cell,
					x = pickPos.x,
					y = pickPos.y
				}

				self:dispatchEvent(pickObj)

				if self.pickCallback then
					self.pickCallback(pickObj)
				end
			end
		elseif cell ~= nil then
			cell:onTouch("moved", x, y)
		end
	end

	self.drag.preTime = clock
	self.drag.preX = x
	self.drag.preY = y
end

function List:getPickIndex(drag)
	local px, cellpos, cellpx, size = nil

	if self.cols > 1 then
		if self.direction == List.DIRECTION_HORIZONTAL then
			size = cc.size(self.cellSize.width, (self.cellSize.height - self.leftSpace - self.rightSpace) / self.cols)
		else
			size = cc.size((self.cellSize.width - self.leftSpace - self.rightSpace) / self.cols, self.cellSize.height)
		end
	else
		size = drag.cell.size
	end

	if self.direction == List.DIRECTION_HORIZONTAL then
		cellpos = drag.cell:getPositionX()
		px = cellpos
		cellpx = size.width
	else
		cellpos = drag.cell:getPositionY()
		px = self.touchRect.height - cellpos - drag.cell:getContentSize().height / 2
		cellpx = size.height
	end

	local index = self:getCellIndexByPx(px)

	return index
end

function List:onTouchEnded(x, y)
	local clock = socket.gettime()
	local offsetTime = clock - self.drag.preTime

	if offsetTime > 0 then
		local standardTime = self.stdDragTime / 100
		self.drag.speed = (self.drag.speed * standardTime + math.abs(y - self.drag.preY) * standardTime / offsetTime * offsetTime) / (offsetTime + standardTime)
	end

	local drag = self.drag
	self.drag = nil
	local cell = self:getCurrentCell(x, y)

	if cell then
		cell:onTouch("ended", x, y)
	end

	if self.bouncValue ~= 0 then
		self:dispatchEvent({
			name = "bouncRelease",
			value = self.bouncValue
		})
	end

	UIManager.callTapCallbackTouch(self.tapGroupName, nil, "ended", self)

	if drag.isTap then
		self:onTouchEndedWithTap(x, y)
	elseif not drag.pickStarted then
		self:onTouchEndedWithoutTap(x, y, drag)
	elseif drag.cell then
		transition.stopTarget(drag.cell)

		local dragNode = self:getPickNode(drag.cell)

		if dragNode then
			self.afterPick = {
				node = dragNode,
				x = drag.cellStartX,
				y = drag.cellStartY,
				zorder = drag.cellStartZOrder,
				parent = drag.preContainer,
				preScale = drag.preScale
			}

			transition.moveTo(dragNode, {
				time = 0.1,
				x = drag.cellStartX + drag.pickOffset.x,
				y = drag.cellStartY + drag.pickOffset.y,
				onComplete = function ()
					dragNode:retain()
					dragNode:removeFromParent()
					dragNode:setPosition(drag.cellStartX, drag.cellStartY)
					dragNode:setLocalZOrder(drag.cellStartZOrder)
					drag.preContainer:addChild(dragNode)

					if drag.preScale then
						dragNode:setScale(drag.preScale)
					end

					dragNode:release()

					self.afterPick = nil

					self:resetHolder()
				end
			})
		end

		local pickPos = self:convertToWorldSpace(cc.p(x, y))
		local pickObj = {
			event = "ended",
			name = "pickEnded",
			index = self.pickIndex,
			data = self.items[self.pickIndex],
			cell = drag.cell,
			x = pickPos.x,
			y = pickPos.y
		}

		self:dispatchEvent(pickObj)

		if self.pickCallback then
			self.pickCallback(pickObj)
		end

		self:onCellPicked(drag.cell.ui or drag.cell, drag.cell.data, false)
	end
end

function List:onTouchEndedWithTap(x, y)
	self:onMoveStop()

	local cell = self:getCurrentCell(x, y)

	if cell == nil then
		return
	end

	cell:onTouch("ended", x, y)
	cell:onTap(x, y)
end

function List:onTouchEndedWithoutTap(x, y, drag)
	if self.direction == List.DIRECTION_HORIZONTAL then
		local desXInRange = self:getOverRange(self.absX)

		if desXInRange == false then
			if self.inertialThreshold < math.abs(drag.speed) then
				self.speed = drag.speed

				self:addEnterFrame("inertialScroll", handler(self, self.inertialScroll))
			else
				self.speed = 0

				self:onMoveStop()
			end
		else
			self:setContentOffset(desXInRange, true)
		end
	else
		local desYInRange = self:getOverRange(self.absY)

		if desYInRange == false then
			if drag and self.inertialThreshold < math.abs(drag.speed) then
				self.speed = drag.speed

				self:addEnterFrame("inertialScroll", handler(self, self.inertialScroll))
			else
				self.speed = 0

				self:onMoveStop()
			end
		else
			self:setContentOffset(desYInRange, true)
		end
	end
end

function List:inertialScroll()
	self.speed = self.speed * self.speedDecay

	if math.abs(self.speed) < 1 then
		self:removeEnterFrame("inertialScroll")
		self:onMoveStop()
	end

	if self.direction == List.DIRECTION_HORIZONTAL then
		local desX = self.absX + self.speed
		local desXInRange = self:getOverRange(desX)

		if desXInRange == false then
			self:setContentOffset(desX)
		else
			self:removeEnterFrame("inertialScroll")

			if desX < desXInRange then
				self:setContentOffset(math.max(desX, desXInRange - 32))
				self:setContentOffset(desXInRange, true, 0.1)
			elseif desXInRange < desX then
				self:setContentOffset(math.min(desX, desXInRange + 32))
				self:setContentOffset(desXInRange, true, 0.1)
			else
				self:setContentOffset(desXInRange)
				self:onMoveStop()
			end
		end
	else
		local desY = self.absY + self.speed
		local desYInRange = self:getOverRange(desY)

		if desYInRange == false then
			self:setContentOffset(desY)
		else
			self:removeEnterFrame("inertialScroll")

			if desY < desYInRange then
				self:setContentOffset(math.max(desY, desYInRange - 32))
				self:setContentOffset(desYInRange, true, 0.1)
			elseif desYInRange < desY then
				self:setContentOffset(math.min(desY, desYInRange + 32))
				self:setContentOffset(desYInRange, true, 0.1)
			else
				self:setContentOffset(desYInRange)
				self:onMoveStop()
			end
		end
	end
end

function List:onTouchCancelled(x, y)
	self.drag = nil
end

function List:onTouch(event, x, y)
	local pos = self:convertToNodeSpace(cc.p(x, y))
	x = pos.x
	y = pos.y

	if event == "began" then
		if not cc.rectContainsPoint(self.touchRect, cc.p(x, y)) then
			return false
		end

		return self:onTouchBegan(x, y)
	elseif event == "moved" then
		if self.drag ~= nil then
			self:onTouchMoved(x, y)
		end
	elseif event == "ended" then
		if self.drag ~= nil then
			self:onTouchEnded(x, y)
		end
	elseif self.drag ~= nil then
		self:onTouchCancelled(x, y)
	end
end

function List:addEnterFrame(name, func)
	if self.enterFrameStack == nil then
		self.enterFrameStack = {}
	end

	self.enterFrameStack[name] = func

	if table.nums(self.enterFrameStack) == 1 then
		self:unscheduleUpdate()
		self:addNodeEventListener(cc.NODE_ENTER_FRAME_EVENT, function (dt)
			self:onEnterFrame(dt)
		end)
		self:scheduleUpdate()
	end
end

function List:removeEnterFrame(name)
	if self.enterFrameStack == nil then
		return
	end

	self.enterFrameStack[name] = nil

	if table.nums(self.enterFrameStack) == 0 then
		self:unscheduleUpdate()
	end
end

function List:onEnterFrame(dt)
	for name, func in pairs(self.enterFrameStack) do
		func(dt)
	end
end

function List:setParentInfo(parent, flagName)
	self.uiParent = parent
	self.uiFlag = flagName

	self:refreshEmptyText()
end

function List:setEmptyText(text)
	if self.noEmptyText then
		return
	end

	text = text and string.gsub(text, "\\n", "\n")
	self.emptyText = text

	self:refreshEmptyText()
end

function List:refreshEmptyText()
	if self.noEmptyText then
		return
	end

	if self.uiParent and self.uiFlag then
		if self.items and #self.items > 0 then
			self.uiParent:removeLabelOnFlag(self.uiFlag)
		elseif self.emptyText then
			self.uiParent:createLabelOnFlag(self.uiFlag, self.emptyText, {
				size = 24,
				color = Style.font1
			})
		end
	end
end

function List:hitTestCell(x, y)
	for i, cell in pairs(self.cells) do
		if self.cols > 1 then
			for j = 1, self.cols do
				if cell.ui_cols[j] and cell.ui_cols[j]:hitTest(cc.p(x, y)) then
					local index = (i - 1) * self.cols + j

					return index, cell.ui_cols[j], cell.data[colIndex]
				end
			end
		elseif cell.ui:hitTest(cc.p(x, y)) then
			return i, cell.ui, cell.data
		end
	end
end

function List:setArc(center, scaleMinMax, magnetPos, isLoop)
	self.arc = {
		center = center,
		scale = scaleMinMax,
		magnetPos = magnetPos,
		isLoop = isLoop
	}
end

function List:onExit()
	if app and not app.sceneChanging and self.pickable and self.drag and self.drag.cell then
		local drag = self.drag
		local dragNode = self:getPickNode(drag.cell)

		if dragNode and not tolua.isnull(dragNode) then
			dragNode:retain()
			dragNode:removeFromParent()
			dragNode:setPosition(drag.cellStartX, drag.cellStartY)
			dragNode:setLocalZOrder(drag.cellStartZOrder)

			if drag.preContainer then
				drag.preContainer:addChild(dragNode)
			end

			if drag.preScale then
				dragNode:setScale(drag.preScale)
			end

			dragNode:release()

			self.afterPick = nil
		end
	end
end

return List
