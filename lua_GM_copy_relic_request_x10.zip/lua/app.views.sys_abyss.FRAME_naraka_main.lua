local UI_base = import("..UI_base")
local FRAME_naraka_main = class("FRAME_naraka_main", UI_base)

function FRAME_naraka_main:ctor()
	FRAME_naraka_main.super.ctor(self, "frame_naraka_main", UIManager.BIG_TYPE.BOTTOM)
	self:init()
end

function FRAME_naraka_main:init()
	self:initUI()

	local openMap = {}
	local modes = InfoNaraka.getModes()

	for i, v in ipairs(modes) do
		openMap[tonumber(v)] = true
	end

	local csvList = CsvParser.getCsvList("naraka_mode")
	local arr = {}

	for i, v in ipairs(csvList) do
		table.insert(arr, {
			csv = v,
			open = openMap[v.id]
		})
	end

	self.list:setItems(arr)
end

function FRAME_naraka_main:initUI()
	local function onDetail()
		FRAME_naraka_boss.open()
	end

	local bg = self:getComponentByTag("bg")

	bg:toTouchable()
	bg:setTapGroup("bg_click")
	bg:addTap(onDetail)

	local function tapListener(ui, data, index)
		onDetail()
	end

	self.list = self:createListOnFlag("flag_list", LIST_naraka_main, tapListener, touchListener)

	self.list:setTapGroup("list_click")
end

return FRAME_naraka_main
