local NAV_base = import(".NAV_base")
local NAV_home_workshop = class("NAV_home_workshop", NAV_base)

function NAV_home_workshop.open(npc)
	local ui = NAV_home_workshop.new(npc)

	return ui
end

function NAV_home_workshop:ctor(npc)
	NAV_home_workshop.super.ctor(self, npc, "nav_home_workshop")
end

function NAV_home_workshop:init()
	NAV_pet.super.init(self)

	local index = 2
	local ui = self.buttons[index].ui

	ui:createBarByTag("progress", NAV_base.COLOR.HIGH, true)
	self:refresh()
	ManagerInfo.onDataChange(self, "delay_item", nil, function (data)
		self:refresh()
	end)
end

function NAV_home_workshop:refresh()
	local index = 2
	local ui = self.buttons[index].ui
	local redotCount = InfoDelayItem.countReady(InfoHome.DELAY_TYPES)
	local redot = ui:getComponentByTag("redot")

	redot:setVisible(redotCount > 0)

	local percent = InfoDelayItem.getBestProgress(InfoHome.DELAY_TYPES)

	if percent > 0 then
		ui:setBarProgressByTag("progress", math.min(1, percent))
	else
		ui:setBarProgressByTag("progress", 0)
	end
end

function NAV_home_workshop:onTap(index)
	NAV_home.super.onTap(self, index)

	if index == 1 then
		FRAME_craft_shop.open(InfoHomeWorkshop, self.npc)
	elseif index == 2 then
		FRAME_delay_item.open(InfoHome.DELAY_TYPES)
	end
end

return NAV_home_workshop
