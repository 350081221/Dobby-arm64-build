local InfoPetFeed = {}
local rawData = nil

function InfoPetFeed.init()
	Connection.listen("pet_feed_sync", InfoPetFeed.sync)
end

app:addToAppEnterCall(InfoPetFeed.init)

function InfoPetFeed.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoPetFeed.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("pet_feed_query", callback)
end

function InfoPetFeed.onQuery(rcvData)
	dump(rcvData, "pet_feed_query")

	rawData = {}

	for i = 1, #rcvData.list do
		local data = rcvData.list[i]
		rawData[data.pos] = data
	end
end

function InfoPetFeed.sync(data)
	dump(data, "$$$ InfoPetFeed.sync")

	for i, syncData in ipairs(data.list) do
		local pos = syncData.pos

		if not rawData[pos] then
			rawData[pos] = syncData
		else
			for k, v in pairs(syncData) do
				rawData[pos][k] = v
			end
		end
	end

	ManagerInfo.dataChange("pet_feed", data)
end

function InfoPetFeed.on(pos, pet_id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("pet_feed_on", {
		pos = pos,
		pet_id = pet_id
	}, callback)
end

function InfoPetFeed.off(pos, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("pet_feed_off", {
		pos = pos
	}, callback)
end

function InfoPetFeed.checkReward(onSuccess, onFailure)
	local needCheck = false
	local nowTime = Time.now()

	for pos, data in pairs(rawData) do
		if not empty(data.pet_id) then
			local petInfo = InfoPet.getPet(data.pet_id)

			if petInfo then
				if data.visit_feed > 0 then
					needCheck = true

					break
				end

				if RefreshManager.checkTimePassed(RefreshManager.TYPE.PET_FEED, nowTime, data.reward_time) then
					needCheck = true

					break
				end
			end
		end
	end

	print("$$$ InfoPetFeed.checkReward", needCheck)

	if needCheck then
		local function callback(rcvData)
			if rcvData.err then
				if onFailure then
					onFailure(rcvData.err)
				end
			elseif onSuccess then
				onSuccess(rcvData)
			end
		end

		Connection.request("pet_feed_check", callback)
	end
end

function InfoPetFeed.getReward(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("pet_feed_reward", callback)
end

function InfoPetFeed.feed(pos, item_id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("pet_feed_feed", {
		pos = pos,
		item_id = item_id
	}, callback)
end

function InfoPetFeed.feedVisit(id, pet_base_id, item_id, user_id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("pet_feed_visit", {
		id = id,
		pet_base_id = pet_base_id,
		item_id = item_id,
		user_id = user_id
	}, callback)
end

function InfoPetFeed.inFeed(pet_id)
	for pos, v in pairs(rawData) do
		if v.pet_id == pet_id then
			return true, pos
		end
	end

	return false
end

function InfoPetFeed.getFeedMap()
	local feedMap = {}

	for pos, v in pairs(rawData) do
		if not empty(v.pet_id) then
			feedMap[v.pet_id] = true
		end
	end

	return feedMap
end

function InfoPetFeed.getData(pos)
	return rawData[pos]
end

function InfoPetFeed.canOff(pos)
	local data = rawData[pos]

	if data and not empty(data.pet_id) then
		return RefreshManager.checkTimePassed(RefreshManager.TYPE.PET_FEED, Time.now(), data.start_time)
	end

	return false
end

function InfoPetFeed.getList()
	local arr = {}

	for pos = 1, GameConfig.pet_feed_num do
		table.insert(arr, {
			pos = pos,
			data = rawData[pos]
		})
	end

	return arr
end

function InfoPetFeed.rewardList()
	local itemMap = {}

	for pos, data in pairs(rawData) do
		local reward_feed = math.min(100, data.reward_feed)

		if not empty(data.reward_pet_id) then
			local petCSV = CsvParser.getCsvData("pet", data.reward_pet_id)

			if petCSV then
				local random = Random.new(data.reward_seed)
				local itemArr = SheetUtil.getColumnList(petCSV, {
					"product_id_",
					"base_prob_",
					"base_num_"
				}, {
					"item_id",
					"base_prob",
					"base_num"
				})

				print("$$$ petCSV ", pos, petCSV.id, petCSV.name, reward_feed)

				for i, v in ipairs(itemArr) do
					local num = SheetUtil.getNumber(v.base_num, random) * (1 + reward_feed / 100)
					local itemCSV = CsvParser.getCsvData("item", v.item_id)

					print("$$$ item_id", v.item_id, itemCSV.name, v.base_prob, v.base_num, num)

					num = math.ceil(num)

					for j = 1, num do
						local prob = v.base_prob * (1 + reward_feed / 100)
						local ran = random:next()

						print("$$$ prob", j, prob, ran, reward_feed)

						if ran < prob then
							itemMap[v.item_id] = (itemMap[v.item_id] or 0) + 1
						end
					end
				end
			end
		end
	end

	local rewardArr = {}

	for base_id, num in pairs(itemMap) do
		table.insert(rewardArr, {
			base_id = base_id,
			num = num
		})
	end

	return rewardArr
end

function InfoPetFeed.getPetList()
	local arr = {}

	for pos, data in pairs(rawData) do
		if not empty(data.pet_id) then
			local petInfo = InfoPet.getPet(data.pet_id)

			if petInfo then
				local petCSV = CsvParser.getCsvData("pet", petInfo.base_id)

				if petCSV then
					table.insert(arr, {
						petInfo = petInfo,
						feedData = data
					})
				end
			end
		end
	end

	return arr
end

function InfoPetFeed.onVisitFeed()
	if InfoDungeon.isHome() and InfoHome.isSelf() then
		InfoPetFeed.checkReward(function (rcvData)
			if rcvData.visit_feed and rcvData.visit_feed > 0 then
				local str = Localization.getSrcText("收获访客投喂[color=238,199,111]{1}[/color]点")

				POP_msg.open(StringUtil.replace(str, rcvData.visit_feed))
			end
		end)
	end
end

return InfoPetFeed
