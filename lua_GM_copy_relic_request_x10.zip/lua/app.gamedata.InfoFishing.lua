local InfoFishing = {}
local rawData = {}
local pondData = {}
local shop_refresh_time, shopList = nil
local shopRefreshIndex = 0
local rod_id = 0
local currentBaitItem, currentBaitIndex, currentFishnet = nil
local recordCached = {}
local fishingEventEffectMap = {}

function InfoFishing.clear()
	recordCached = {}
	fishingEventEffectMap = {}

	InfoFishing.clearPond()
end

function InfoFishing.init()
	Connection.listen("fishing_sync", InfoFishing.sync)
end

app:addToAppEnterCall(InfoFishing.init)

function InfoFishing.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoFishing.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("fishing_query", callback)
end

function InfoFishing.onQuery(rcvData)
	rawData = {}

	for i, data in ipairs(rcvData.list) do
		rawData[data.base_id] = data
	end

	pondData = {}

	for i, data in ipairs(rcvData.ponds) do
		pondData[data.base_id] = data
	end

	shop_refresh_time = rcvData.shop_refresh_time
	rod_id = rcvData.rod_id
end

function InfoFishing.sync(data)
	dump(data, "$$$ InfoFishing.sync")

	if data.shop_refresh_time then
		shop_refresh_time = data.shop_refresh_time
	end

	if data.rod_id then
		rod_id = data.rod_id
	end

	if data.list then
		for i, syncData in ipairs(data.list) do
			local base_id = syncData.base_id

			if rawData[base_id] then
				for k, v in pairs(syncData) do
					rawData[base_id][k] = v
				end
			else
				rawData[base_id] = syncData
			end
		end
	end

	if data.ponds then
		for i, syncData in ipairs(data.ponds) do
			local base_id = syncData.base_id

			if pondData[base_id] then
				for k, v in pairs(syncData) do
					pondData[base_id][k] = v
				end
			else
				pondData[base_id] = syncData
			end
		end
	end

	ManagerInfo.dataChange("fishing")
end

function InfoFishing.enterSpot(spot_id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			local result = rcvData.dungeon_result
			local title, subTitle = InfoDungeon.getTitle(result.type, result.dungeon_id, result.quest_id, result.abyss_seed)

			Transition.setTitle(title, subTitle)
			Transition.leave(function ()
				if onSuccess then
					onSuccess(result)
				end
			end)
		end
	end

	Connection.request("fishing_enter_spot", {
		spot_id = spot_id
	}, callback)
end

function InfoFishing.getRecord(fish_id, onSuccess, onFailure)
	if recordCached[fish_id] then
		onSuccess(recordCached[fish_id])
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			recordCached[fish_id] = rcvData

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("fishing_get_record", {
		fish_id = fish_id
	}, callback)
end

function InfoFishing.setRod(rod_id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("fishing_set_rod", {
		rod_id = rod_id
	}, callback)
end

function InfoFishing.fishingStart(onSuccess, onFailure)
	local fishingEvent = InfoFishing.getFishingEvent()
	local eventIndex = fishingEvent.index
	local rodCSV = InfoFishing.getRod()

	InfoDungeon.fishingStart(eventIndex, currentBaitItem, currentBaitIndex, rodCSV.id, onSuccess, onFailure)
end

function InfoFishing.fishingOver(succ, onSuccess, onFailure)
	local fishingEvent = InfoFishing.getFishingEvent()
	local eventIndex = fishingEvent.index

	InfoDungeon.fishingOver(eventIndex, succ, onSuccess, onFailure)
end

function InfoFishing.fishnet(onSuccess, onFailure)
	local netInfo = currentFishnet

	if netInfo and netInfo.num > 0 then
		local fishingEvent = InfoFishing.getFishingEvent()
		local eventIndex = fishingEvent.index

		InfoDungeon.fishnet(eventIndex, netInfo.bait_id, onSuccess, onFailure)
	end
end

function InfoFishing.getSpotID()
	local stageType, stageID = InfoDungeon.getStage()

	return stageID
end

local pondID = nil
local baitList = {}
local netList = {}

function InfoFishing.enterPond(_pondID)
	pondID = _pondID
	baitList = {}
	netList = {}
	local pondCSV = CsvParser.getCsvData("fishing_pond", pondID)
	local baitArr = CsvParser.getCsvList("fishing_bait")

	for i, v in ipairs(baitArr) do
		if v.group == pondCSV.bait_group then
			if v.is_net == 1 then
				table.insert(netList, {
					base_id = v.item_id,
					num = InfoItem.getNum(v.item_id),
					bait_id = v.id
				})
			else
				table.insert(baitList, {
					base_id = v.item_id,
					num = InfoItem.getNum(v.item_id)
				})
			end
		end
	end
end

function InfoFishing.clearPond()
	pondID = nil
	baitList = {}
	netList = {}
end

function InfoFishing.inPond()
	return pondID ~= nil
end

function InfoFishing.getPondID()
	return pondID
end

function InfoFishing.getPondCSV()
	if pondID then
		local pondCSV = CsvParser.getCsvData("fishing_pond", pondID)

		return pondCSV
	end
end

function InfoFishing.getBaitList()
	local arr = {}

	for i, v in ipairs(baitList) do
		table.insert(arr, {
			base_id = v.base_id,
			num = InfoItem.getNum(v.base_id)
		})
	end

	return arr
end

function InfoFishing.getBaitItem(index)
	if baitList[index] then
		return baitList[index].base_id
	end
end

local fishingEvent, targetEvent = nil

function InfoFishing.onFishingReady(isEnter, eventData)
	fishingEvent = MapEventManager.findLinkOne(eventData, "fishing")
	targetEvent = MapEventManager.findLinkOne(fishingEvent, "fishing_target")
	local info = ConfParser.parse(fishingEvent.info)

	if isEnter then
		InfoFishing.enterPond(info.id)
	else
		InfoFishing.clearPond()
	end

	if global.ui then
		global.ui:refreshQuickSlots()
	end

	if isEnter then
		global.map:tweenViewZoom(MiscConfig.fishing_zoom, 20)
	else
		global.map:tweenViewZoom(1, 15)
	end
end

function InfoFishing.checkOpenTime(customEvent)
	customEvent = customEvent or fishingEvent

	if customEvent then
		local info = ConfParser.parse(customEvent.info)
		local eventInfo = InfoDungeon.getEventInfo(customEvent.index)
		local pondCSV = CsvParser.getCsvData("fishing_pond", info.id)

		if pondCSV then
			if empty(pondCSV.open_time) then
				return true
			end

			return RefreshManager.checkOpenTime(pondCSV.open_time, Time.now())
		end
	end
end

function InfoFishing.getGlobalAmount(pondID)
	local pondCSV = CsvParser.getCsvData("fishing_pond", pondID)
	local currentAmount = 0

	if not empty(pondCSV.amount_time) and pondData[pondCSV.id] then
		local data = pondData[pondCSV.id]
		local amount_count = data.amount_count

		if RefreshManager.checkTimePassed(pondCSV.amount_time, Time.now(), data.amount_time) then
			amount_count = 0
		end

		currentAmount = math.max(amount_count, currentAmount)
	end

	local available = pondCSV.amount == 0 or currentAmount < pondCSV.amount

	return currentAmount, pondCSV.amount, available, pondCSV
end

function InfoFishing.getFishAmount(customEvent)
	customEvent = customEvent or fishingEvent

	if customEvent then
		local info = ConfParser.parse(customEvent.info)
		local eventInfo = InfoDungeon.getEventInfo(customEvent.index)
		local pondCSV = CsvParser.getCsvData("fishing_pond", info.id)
		local currentAmount = eventInfo.fin

		if not empty(pondCSV.amount_time) and pondData[pondCSV.id] then
			local data = pondData[pondCSV.id]
			local amount_count = data.amount_count

			if RefreshManager.checkTimePassed(pondCSV.amount_time, Time.now(), data.amount_time) then
				amount_count = 0
			end

			currentAmount = math.max(amount_count, currentAmount)
		end

		local available = pondCSV.amount == 0 or currentAmount < pondCSV.amount

		return currentAmount, pondCSV.amount, available
	end
end

function InfoFishing.isAvailable(customEvent)
	local fin, amount, available = InfoFishing.getFishAmount(customEvent)

	if available and InfoFishing.checkOpenTime(customEvent) then
		return true
	end

	return false
end

function InfoFishing.getFishingEvent()
	local targetX, targetY = MapEventManager.getEventCenter(targetEvent)
	local fishingX, fishingY = MapEventManager.getEventCenter(fishingEvent)
	local faceAngle = math.atan2(targetY - fishingY, targetX - fishingX)

	return fishingEvent, targetEvent, faceAngle
end

function InfoFishing.startFishing(baitItem, baitIndex)
	local rod = InfoFishing.getRod()

	if rod then
		currentBaitItem = baitItem
		currentBaitIndex = baitIndex

		if InfoFishing.isAvailable() then
			FRAME_fishing.open()
		else
			Alert.open(Localization.getSrcText("没有鱼群"))
		end
	else
		Alert.open(Localization.getSrcText("没有钓竿"))
	end
end

function InfoFishing.startFishnet(netInfo, onSuccess, onFailure)
	currentFishnet = netInfo

	if InfoFishing.isAvailable() then
		FRAME_fishing.openNet()
	else
		Alert.open(Localization.getSrcText("没有鱼群"))
	end
end

function InfoFishing.getCurrentFishnet()
	return currentFishnet
end

function InfoFishing.getFishnet()
	if netList then
		for i, v in ipairs(netList) do
			v.num = InfoItem.getNum(v.base_id)

			return v
		end
	end
end

function InfoFishing.getRod()
	if empty(rod_id) then
		local rodCSVList = CsvParser.getCsvList("fishing_rod")
		local rodCSV = nil

		for i, v in ipairs(rodCSVList) do
			if InfoItem.getNum(v.item_id) > 0 then
				rodCSV = v

				break
			end
		end

		return rodCSV
	else
		local rodCSV = CsvParser.getCsvData("fishing_rod", rod_id)

		return rodCSV
	end
end

function InfoFishing.getRodList()
	local arr = {}
	local rodCSVList = CsvParser.getCsvList("fishing_rod")
	local rodCSV = nil

	for i, v in ipairs(rodCSVList) do
		if InfoItem.getNum(v.item_id) > 0 then
			table.insert(arr, v)
		end
	end

	return arr
end

function InfoFishing.setFishingEffect(eventIndex, effect)
	fishingEventEffectMap[eventIndex] = effect
end

function InfoFishing.getFishingEffect(eventIndex)
	return fishingEventEffectMap[eventIndex]
end

function InfoFishing.getHeadList()
	local csvList = CsvParser.getCsvList("fishing_fish")
	local arr = {}

	for i, v in ipairs(csvList) do
		if rawData[v.id] then
			table.insert(arr, v)
		end
	end

	return arr
end

function InfoFishing.getMaxWeight(fishID)
	local fishCSV = CsvParser.getCsvData("fishing_fish", fishID)
	local maxWeight = math.floor(fishCSV.base_weight * (GameConfig.fish_max_weight_ratio + 1))

	return maxWeight
end

function InfoFishing.getShopLabels()
	local shopCSVList = CsvParser.getCsvList("fishing_shop_label")

	return shopCSVList
end

function InfoFishing.clearOnReconnect()
	shopList = nil
end

function InfoFishing.getShopList(_callback)
	local needQuery = shopList == nil

	if not needQuery and shop_refresh_time < Time.now() then
		needQuery = true
	end

	if needQuery then
		local function callback(rcvData)
			if rcvData.err then
				-- Nothing
			else
				shopRefreshIndex = shopRefreshIndex + 1
				shopList = rcvData.items

				if _callback then
					_callback(shopList)
				end
			end
		end

		Connection.request("fishing_shop_list", callback)
	else
		_callback(shopList)
	end
end

function InfoFishing.getShopItems()
	local abyssLevel = InfoDungeon.getAbyssMaxLevel()
	local arr = {}
	local multiLabel = nil
	local shopCSVList = CsvParser.getCsvList("fishing_shop_label")

	if #shopCSVList > 1 then
		local labelMap = {}

		for i, v in ipairs(shopList) do
			local shopCSV = CsvParser.getCsvData("fishing_shop", v.shop_id, nil, true)

			if shopCSV and shopCSV.abyss_level_min <= abyssLevel and abyssLevel <= shopCSV.abyss_level_max and (shopCSV.no_supply ~= 1 or v.soldout < shopCSV.times) then
				if not labelMap[shopCSV.label] then
					labelMap[shopCSV.label] = {}
				end

				table.insert(labelMap[shopCSV.label], v)
			end
		end

		for i, v in ipairs(shopCSVList) do
			local itemArr = labelMap[v.id]

			if itemArr then
				table.sort(itemArr, function (a, b)
					return a.shop_id < b.shop_id
				end)

				local obj = {
					label = v,
					items = itemArr
				}

				table.insert(arr, obj)
			end
		end

		multiLabel = true
	else
		local abyssLevel = InfoDungeon.getAbyssMaxLevel()

		for i, v in ipairs(shopList) do
			local shopCSV = CsvParser.getCsvData("fishing_shop", v.shop_id, nil, true)

			if shopCSV and shopCSV.abyss_level_min <= abyssLevel and abyssLevel <= shopCSV.abyss_level_max and (shopCSV.no_supply ~= 1 or v.soldout < shopCSV.times) then
				table.insert(arr, v)
			end
		end

		table.sort(arr, function (a, b)
			return a.shop_id < b.shop_id
		end)

		multiLabel = false
	end

	return arr, multiLabel
end

function InfoFishing.buy(shop_id, num, onSuccess, onFailure)
	local preIndex = shopRefreshIndex

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if rcvData.item then
				local item = rcvData.item

				if preIndex == shopRefreshIndex then
					for i, v in ipairs(shopList) do
						if v.shop_id == item.shop_id then
							for k1, v1 in pairs(item) do
								v[k1] = v1
							end
						end
					end
				end
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("fishing_shop_buy", {
		shop_id = shop_id,
		num = num
	}, callback)
end

function InfoFishing.getShopCSV()
	return "fishing_shop"
end

function InfoFishing.getCostNeed()
	return nil
end

function InfoFishing.getShopName()
	return "fishing"
end

function InfoFishing.getShopTime()
	return shop_refresh_time, RefreshManager.getNextTime(RefreshManager.TYPE.FISHING_SHOP, Time.now())
end

function InfoFishing.getRefreshType()
	return RefreshManager.TYPE.FISHING_SHOP
end

function InfoFishing.getManualList()
	local csvList = CsvParser.getCsvList("fishing_fish", nil, {
		type = 1
	})
	local classArr = {}
	local classMap = {}

	for i, csv in ipairs(csvList) do
		if csv.fish_type == 1 or csv.fish_type == 2 then
			if not classMap[csv.fish_type] then
				classMap[csv.fish_type] = {
					fish_type = csv.fish_type,
					arr = {}
				}

				table.insert(classArr, classMap[csv.fish_type])
			end

			table.insert(classMap[csv.fish_type].arr, {
				csv = csv,
				info = rawData[csv.id]
			})
		end
	end

	table.sort(classArr, function (a, b)
		return a.fish_type < b.fish_type
	end)

	local arr = {}

	for i, v in ipairs(classArr) do
		table.sort(v.arr, function (a, b)
			local itemA = CsvParser.getCsvData("item", a.csv.item_id)
			local itemB = CsvParser.getCsvData("item", b.csv.item_id)

			if itemA.quality == itemB.quality then
				return a.csv.id < b.csv.id
			else
				return itemA.quality < itemB.quality
			end
		end)
		table.insert(arr, {
			fish_type = v.fish_type
		})
		table.insert(arr, {
			fishes = v.arr
		})
	end

	return arr
end

function InfoFishing.getBestWeight(fish_id)
	if rawData[fish_id] then
		return rawData[fish_id].best_weight, rawData[fish_id].count
	end
end

function InfoFishing.getDataByID(id)
	for k, v in pairs(rawData) do
		if v.id == id then
			return v
		end
	end
end

return InfoFishing
