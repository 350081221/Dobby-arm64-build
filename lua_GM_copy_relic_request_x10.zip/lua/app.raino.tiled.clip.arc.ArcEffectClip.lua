local Effect = import("..Effect")
local ArcEffectClip = class("ArcEffectClip", Effect)

function ArcEffectClip:ctor()
	ArcEffectClip.super.ctor(self, "arc_effect_clip")
end

function ArcEffectClip:load(type, name)
	if type == ArcParam.PARTICLE_CLIP then
		ArcEffectClip.super.load(self, name)
	elseif type == ArcParam.PARTICLE_SPINE then
		ArcEffectClip.super.loadSpine(self, name)
	end
end

function ArcEffectClip:enterTile(tile)
end

function ArcEffectClip:leaveTile(tile)
end

return ArcEffectClip
