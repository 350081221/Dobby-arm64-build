local FRAME_area_gift = class("FRAME_area_gift", UI_base)

function FRAME_area_gift:ctor()
	FRAME_area_gift.super.ctor(self, "frame_area_gift")
	self:init()
end

function FRAME_area_gift:init()
	self:initUI()
end

function FRAME_area_gift:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local bg = self:getComponentByTag("bg")

	bg:toTouchable()
	bg:setTapGroup("bg_click")
	bg:addTap(function ()
		if self.areaID then
			FRAME_area_gift_detail.open(self.areaID)
		end
	end)
end

function FRAME_area_gift:setGift(areaID)
	local giftCSV, onceCSV, dayLeft = InfoAbyssArea.getGift(areaID)

	if giftCSV and InfoOrder.getOnce(onceCSV.id) == 0 then
		self.areaID = areaID

		self:createLabelOnFlag("flag_name", onceCSV.goods_name)

		local icon = self:createIconOnFlag("flag_icon", IconManager.getIcon("image/pic/item/icon/" .. giftCSV.pic .. ".png"), 100, true)

		self:replaceLabelOnFlag("flag_day_left", nil, dayLeft)
		self:setVisible(true)
	else
		self:clearGift()
	end
end

function FRAME_area_gift:clearGift()
	self.giftID = nil

	self:setVisible(false)
end

return FRAME_area_gift
