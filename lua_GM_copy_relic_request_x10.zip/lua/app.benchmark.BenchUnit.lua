local BenchUnit = class("BenchUnit")

function BenchUnit:ctor(code, index, params, eventMap)
	self.code = code
	self.index = index
	self.params = params
	self.eventMap = eventMap
	self.eventTimeMap = {}
	self.eventCountMap = {}
	self.eventLagStackMap = {}

	self:init()
end

function BenchUnit:init()
	self.conn = ConnBench.new()

	if not CONFIG.dafu then
		self.conn:init(SERVER_HOST, SERVER_PORT)
	end
end

function BenchUnit:countEvent(eventName, lag)
	if not self.eventCountMap[eventName] then
		self.eventCountMap[eventName] = 1
	else
		self.eventCountMap[eventName] = self.eventCountMap[eventName] + 1
	end

	if not self.eventLagStackMap[eventName] then
		self.eventLagStackMap[eventName] = {}
	end

	table.insert(self.eventLagStackMap[eventName], lag)
end

function BenchUnit:lockTime(eventName)
	local now = Time.time()
	self.eventTimeMap[eventName] = now + self.eventMap[eventName].interval
end

function BenchUnit:checkTime(eventName)
	local now = Time.time()

	return not self.eventTimeMap[eventName] or self.eventTimeMap[eventName] <= now
end

function BenchUnit:update()
	if not self.locked then
		if self.conn:getStat() == "connected" then
			if not self.conn:isLocked() then
				if not self.id then
					self:login()
				elseif empty(self.guideID) then
					self:makeGuide()
				elseif not self.heros or #self.heros < 3 then
					self:makeHero()
				elseif empty(self.maxLayer) then
					self:makeAbyssLayer()
				else
					if self.eventMap.abyss_battle and self:checkTime("abyss_battle") then
						if not self.dungeonData or not self.anchorArr then
							local layer = BenchUnit.getAbyssLayer()

							self:enterDungeon(layer, function ()
								print(self:getName() .. " 进入地城 " .. layer)

								local eventInfoMap = self.dungeonData.eventInfoMap
								local eventMap = eventInfoMap[self.dungeonData.mapIndex]
								local anchorArr = {}

								for index, v in pairs(eventMap) do
									if v.fin == 0 and v.data.tag == "anchor" then
										table.insert(anchorArr, {
											eventIndex = index
										})
									end
								end

								self.anchorArr = Random.randomOrder(anchorArr)
							end)
						else
							local preBattleTime = Time.time()

							if #self.anchorArr > 0 then
								local eventIndex = table.remove(self.anchorArr, 1).eventIndex

								self:dungeonFight(eventIndex)
							else
								self.dungeonData = nil
							end
						end
					end

					if self.eventMap.tavern_refresh and self:checkTime("tavern_refresh") then
						self:tavernRefresh()
					end

					if self.eventMap.camp_move and self:checkTime("camp_move") then
						if not self.inOnlineCamp then
							local tile = self:getCampRandomTile()

							self:campEnter(tile.x, tile.y)
						else
							local tile = self:getCampRandomTile()

							self:campMove(tile.x, tile.y)
						end
					end
				end
			end
		elseif CONFIG.dafu then
			self:login()
		end
	end

	local eventCountMap = self.eventCountMap
	self.eventCountMap = {}
	local eventLagStackMap = self.eventLagStackMap
	self.eventLagStackMap = {}

	return eventCountMap, eventLagStackMap
end

function BenchUnit:makeHero()
	if not self.heros then
		self:heroQuery()
	else
		local function hireHero(index, hash)
			self.locked = true

			local function callback(rcvData)
				self.locked = nil

				if not rcvData.err then
					self:heroQuery()
				end
			end

			self.conn:request("tavern_hire", {
				index = index,
				hash = hash
			}, callback)
		end

		local function refreshTavern()
			self.locked = true

			local function callback(rcvData)
				self.locked = nil
			end

			self.conn:request("gm_refresh_tavern", callback)
		end

		self.locked = true

		local function callback(rcvData)
			self.locked = nil

			if rcvData.err then
				if onFailure then
					onFailure()
				end
			else
				local found = false

				for i, v in ipairs(rcvData.list) do
					if v.hired == 0 and v.base_id ~= 0 then
						hireHero(i, v.hash)

						found = true

						break
					end
				end

				if not found then
					refreshTavern()
				end

				if onSuccess then
					onSuccess()
				end
			end
		end

		self.conn:request("tavern_query", callback)
	end
end

function BenchUnit:heroQuery()
	self.locked = true

	local function callback(rcvData)
		self.locked = nil

		if not rcvData.err then
			self.heros = rcvData.list
		end
	end

	self.conn:request("hero_query", callback)
end

function BenchUnit:getName()
	return self.code .. "_" .. self.index
end

function BenchUnit:makeNickname()
	local nickname = self:getName()
	self.locked = true

	local function callback(rcvData)
		self.locked = nil
		self.nickname = nickname

		if rcvData.err then
			-- Nothing
		end
	end

	self.conn:request("user_nickname", {
		lang = "",
		nickname = nickname
	}, callback)
end

function BenchUnit:login()
	if self.logining then
		return
	end

	local username = self:getName()
	local password = crypto.md5("")

	if CONFIG.dafu then
		local function loginGate(token, onSuccess, onFailure, onProgress)
			local params = {
				type = InfoUser.AUTH_TYPE.GATE,
				token = tostring(token),
				sys_lang = CONFIG.lang_sys,
				sys_country = CONFIG.country_sys,
				ta_device_id = CONFIG.ta_device_id,
				ta_distinct_id = CONFIG.ta_distinct_id,
				appsflyer_id = CONFIG.appsflyer_id,
				client_os = CONFIG.os,
				lang = Localization.getLang(),
				pack_tag = PACK_TAG
			}

			local function callback(rcvData)
				if not rcvData.err then
					self.id = rcvData.id
					self.logining = nil
				end
			end

			self.conn:request("auth_login_gate", params, callback)
		end

		local function onDafuLogin(rcvData, onSuccess, onFailure, onProgress)
			if not rcvData.err then
				local serverArr = string.split(rcvData.gateAddr, ":")
				SERVER_HOST = serverArr[1]
				SERVER_PORT = tonumber(serverArr[2])

				self.conn:init(SERVER_HOST, SERVER_PORT)
				loginGate(rcvData.token, onSuccess, onFailure, onProgress)
			end
		end

		local params = {
			type = InfoUser.AUTH_TYPE.DIRECT,
			username = username,
			password = password,
			appsflyer_id = CONFIG.appsflyer_id,
			client_os = CONFIG.os,
			lang = Localization.getLang(),
			pack_tag = PACK_TAG,
			mark = mark,
			beat = math.floor(Time.lifeTime())
		}

		local function loginCallback(rcvData1)
			if rcvData1.err then
				local function registerCallback(rcvData2)
					dump(rcvData2, "$$$ auth_register")

					if not rcvData2.err then
						onDafuLogin(rcvData2)
					end
				end

				Http.request("http://" .. CONFIG.center_addr .. "/?cmd=auth_register", params, registerCallback)
			else
				onDafuLogin(rcvData1)
			end
		end

		Http.request("http://" .. CONFIG.center_addr .. "/?cmd=auth_login", params, loginCallback)

		self.logining = true

		return
	end

	local function loginCallback(rcvData1)
		if rcvData1.err then
			local function registerCallback(rcvData2)
				if not rcvData2.err then
					self.id = rcvData2.id
					self.nickname = rcvData2.nickname
				end

				self.logining = nil
			end

			self.conn:request("auth_register", {
				username = username,
				password = password,
				mark = mark
			}, registerCallback)
		else
			self.id = rcvData1.id
			self.nickname = rcvData1.nickname
		end

		self.logining = nil
	end

	self.conn:request("auth_login", {
		username = username,
		password = password,
		mark = mark
	}, loginCallback)

	self.logining = true
end

function BenchUnit:getStat()
	if self.conn then
		return self.conn:getStat()
	else
		return "ready"
	end
end

function BenchUnit:isLoginReady()
	return self.id ~= nil
end

function BenchUnit:isHeroReady()
	if self.heros and #self.heros >= 3 then
		return true
	end
end

local abyssLayerCache = nil

function BenchUnit.getAbyssLayer()
	if not abyssLayerCache then
		abyssLayerCache = {}
		local csvRaw = CsvParser.getCsvRaw("abyss")
		local existMap = {}

		for k, v in pairs(csvRaw) do
			if v.entrance == 0 and not existMap[v.layer] then
				existMap[v.layer] = true

				table.insert(abyssLayerCache, v.layer)
			end
		end
	end

	return abyssLayerCache[math.random(1, #abyssLayerCache)]
end

function BenchUnit:dungeonFight(eventIndex, onComplete)
	self.locked = true

	local function callback(rcvData)
		if rcvData.err then
			-- Nothing
		else
			print(self:getName() .. " 战斗成功")
			self:countEvent("abyss_battle", rcvData.lag)
			self:lockTime("abyss_battle")

			if onComplete then
				onComplete()
			end
		end

		self.locked = nil
	end

	self.conn:request("gm_dungeon_monster", {
		map_index = self.dungeonData.mapIndex,
		event_index = eventIndex
	}, callback)
end

function BenchUnit:enterDungeon(layer, onComplete)
	self.locked = true

	local function callback(rcvData)
		self.locked = nil

		if rcvData.err then
			-- Nothing
		else
			self:countEvent("abyss_enter", rcvData.lag)
			self:makeMaps(rcvData)

			if onComplete then
				onComplete()
			end
		end
	end

	self.conn:request("gm_dungeon_enter", {
		layer = layer
	}, callback)
end

function BenchUnit:exitDungeon()
	local function callback(rcvData)
		dump(rcvData, "$$$ rcvData")

		if rcvData.err then
			-- Nothing
		end
	end

	self.conn:request("gm_dungeon_exit", {
		layer = 50
	}, callback)
end

function BenchUnit:makeMaps(rcvData)
	self.dungeonData = {
		type = rcvData.type,
		dungeonID = rcvData.dungeon_id,
		dungeonLevel = rcvData.level
	}

	if rcvData.abyss_seed then
		self.dungeonData.abyssSeed = rcvData.abyss_seed
	end

	self.dungeonData.dungeonSeed = rcvData.seed
	self.dungeonData.session = rcvData.session
	self.dungeonData.mapSeedArr = rcvData.map_seeds
	self.dungeonData.questID = rcvData.quest_id
	self.dungeonData.questLevel = rcvData.quest_level
	self.dungeonData.questSeed = rcvData.quest_seed
	self.dungeonData.passCount = rcvData.pass_count
	self.dungeonData.passTotal = rcvData.pass_total
	self.dungeonData.missionID = rcvData.mission_id
	self.dungeonData.questDbID = rcvData.quest_db_id
	self.dungeonData.stageType = rcvData.stage_type
	self.dungeonData.stageID = rcvData.stage_id
	local maps = InfoDungeon.getDungeonMaps(self.dungeonData.type, self.dungeonData.dungeonID, self.dungeonData.questID, self.dungeonData.abyssSeed)
	self.dungeonData.relicData = {}
	self.dungeonData.finalRelic = {}
	self.dungeonData.shrineData = {}
	self.dungeonData.eventInfoMap = {}
	local eventInfos, relicInfos = nil

	if rcvData.events then
		eventInfos = json.decode(rcvData.events)
	end

	if rcvData.relic then
		relicInfos = json.decode(rcvData.relic)
	end

	if rcvData.shrine then
		for i, v in ipairs(rcvData.shrine) do
			shrineData[v.index] = v
		end

		InfoDungeon.refreshShrine()
	end

	local eventInfoMap = self.dungeonData.eventInfoMap
	local relicData = self.dungeonData.relicData
	local mapSeedArr = self.dungeonData.mapSeedArr

	for mapIndex, mapName in ipairs(maps) do
		local mapSeed = mapSeedArr[mapIndex]
		local random = Random.new(mapSeed)
		eventInfoMap[mapIndex] = {}
		relicData[mapIndex] = {}
		local mapObj = Map.getMapData(mapName, mapSeed)

		for eventIndex, eventData in ipairs(mapObj.eventData) do
			local eventIndexStr = tostring(eventIndex)
			local eventSeed = random:getInt(1, 65535)

			if relicInfos and relicInfos[mapIndex] then
				relicData[mapIndex][eventIndex] = relicInfos[mapIndex][eventIndexStr]
			end

			if eventInfos and eventInfos[mapIndex] and eventInfos[mapIndex][eventIndexStr] then
				table.insert(eventInfoMap[mapIndex], {
					data = eventData,
					seed = eventSeed,
					fin = eventInfos[mapIndex][eventIndexStr].fin
				})
			else
				table.insert(eventInfoMap[mapIndex], {
					fin = 0,
					data = eventData,
					seed = eventSeed
				})
			end
		end
	end

	self.dungeonData.lifeData = {}
	self.dungeonData.mapIndex = 1
end

local campRandomTiles = nil

function BenchUnit:getCampRandomTile()
	if not campRandomTiles then
		local exceptTiles = {
			{
				y = 97,
				x = 92
			},
			{
				y = 102,
				x = 95
			}
		}
		local exceptTilesMap = {}

		for i, v in ipairs(exceptTiles) do
			exceptTilesMap[v.x .. "_" .. v.y] = true
		end

		campRandomTiles = {}

		for x = 92, 96 do
			for y = 95, 115 do
				if not exceptTilesMap[x .. "_" .. y] then
					table.insert(campRandomTiles, {
						x = x,
						y = y
					})
				end
			end
		end
	end

	return campRandomTiles[math.random(1, #campRandomTiles)]
end

function BenchUnit:campEnter(x, y)
	self.locked = true

	local function callback(rcvData)
		dump(rcvData, "$$$ camp_enter")

		if not rcvData.err then
			self.inOnlineCamp = true
		end

		self.locked = nil
	end

	self.conn:request("camp_enter", {
		map_name = "camp",
		x = x,
		y = y
	}, callback)
end

function BenchUnit:campMove(x, y)
	self.locked = true

	local function callback(rcvData)
		if not rcvData.err then
			self:countEvent("camp_move", rcvData.lag)
			self:lockTime("camp_move")
		end

		self.locked = nil
	end

	self.conn:request("camp_move", {
		x = x,
		y = y
	}, callback)
end

function BenchUnit:makeGuide()
	self.locked = true
	local id = CsvParser.getMaxID("guide")

	local function callback(rcvData)
		self.locked = nil

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			self.guideID = id
		end
	end

	self.conn:request("gm_guide", {
		id = id
	}, callback)
end

function BenchUnit:makeAbyssLayer()
	local entrance = math.random(1, 100)
	local layer = entrance * 4
	local level = entrance * 3 + 1
	self.locked = true

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			self.locked = nil
			self.maxLayer = layer
		end
	end

	self.conn:request("gm_set_abyss", {
		max_layer = layer,
		max_level = level
	}, callback)
end

function BenchUnit:tavernRefresh(onComplete)
	self.locked = true

	local function callback(rcvData)
		if rcvData.err then
			-- Nothing
		else
			self:countEvent("tavern_refresh", rcvData.lag)
			self:lockTime("tavern_refresh")

			if onComplete then
				onComplete()
			end
		end

		self.locked = nil
	end

	self.conn:request("gm_refresh_tavern", callback)
end

return BenchUnit
