local DamageRule = {}

function DamageRule.generateDotPack(caster, attrs, buffData)
	return DamageRule.generateAttackPack(caster, attrs, buffData)
end

function DamageRule.generateAttackPack(caster, attrs, skillData, skillPack)
	if caster.type == "OnlinePlayer" then
		return nil
	end

	local attrs = ObjUtil.copy(attrs)
	local dustSkill = nil

	if caster.getDustSkillAttrs then
		local dustAttrs = caster:getDustSkillAttrs(skillData.base_id)

		if dustAttrs then
			for k, v in pairs(dustAttrs) do
				if attrs[k] then
					attrs[k] = attrs[k] + v
				end
			end
		end
	end

	if caster.getDustSkill then
		dustSkill = caster:getDustSkill(skillData.base_id)
	end

	local pack = {
		type = caster.type,
		level = caster.level,
		attrs = attrs,
		skillData = skillData,
		skillPack = skillPack,
		caster = caster,
		dustSkill = dustSkill
	}

	if caster.type == "monster" then
		pack.monsterClass = caster.data.class
	end

	if caster.type == "hero" and skillData.select_type ~= nil then
		pack.suitSkill = CombatAttr.getSuitSkill(caster.info.id, skillData.id)
	end

	return pack
end

function DamageRule.getDamageValue(attackPack, targetAttrs, targetLevel, targetMonsterClass, targetBattleData, target)
	local dmgRatio = WarMachine.dmg_ratio or 1
	local healRatio = WarMachine.heal_ratio or 1
	local skillData = attackPack.skillData
	local attrs = attackPack.attrs
	local monsterClass = attackPack.monsterClass
	local casterBattleData = nil

	if attackPack.caster then
		casterBattleData = attackPack.caster.battleData
	end

	local criticalFloat = 1
	local isCritical = false
	local isDodge = false
	local isBlock = false
	local bestElement, bestElementValue = nil

	if skillData.must_hit ~= 1 then
		isDodge = WarMachine.random:next() > 1 + (attrs.hit - targetAttrs.dodge) / 100
	end

	if isDodge then
		criticalFloat = 0
	elseif skillData.can_critical ~= 0 then
		local skill_critical = 0

		if not empty(skillData.skill_critical) then
			skill_critical = skillData.skill_critical
		end

		local criticalValue = nil

		if skillData.ignore_res == 1 then
			criticalValue = attrs.critical + skill_critical

			if skillData.dmg_type == 2 then
				criticalValue = criticalValue + attrs.skill_critical
			end
		else
			criticalValue = attrs.critical + skill_critical - targetAttrs.critical_resist

			if skillData.dmg_type == 2 then
				criticalValue = criticalValue + attrs.skill_critical - targetAttrs.skill_critical_resist
			end
		end

		if attackPack.suitSkill then
			criticalValue = criticalValue + attackPack.suitSkill.skill_critical_add
		end

		isCritical = WarMachine.random:next() < criticalValue / 100

		if isCritical then
			local criticalmp = nil

			if skillData.ignore_res == 1 then
				criticalmp = attrs.criticalmp

				if skillData.dmg_type == 2 then
					criticalmp = criticalmp + attrs.skill_criticalmp
				end
			else
				criticalmp = attrs.criticalmp - targetAttrs.criticalmp_resist

				if skillData.dmg_type == 2 then
					criticalmp = criticalmp + attrs.skill_criticalmp - targetAttrs.skill_criticalmp_resist
				end
			end

			criticalFloat = math.max(1, criticalmp / 100)
		end
	end

	local tempValue = 0

	if not isDodge and skillData.can_dmg ~= 0 then
		local damage = skillData.atk_base + attrs.atk * skillData.atk_multi
		local arr = SheetUtil.getColumnList(skillData, {
			"atk_target",
			"atk_index",
			"atk_multi"
		}, {
			"target",
			"attr",
			"multi"
		})

		for i, v in ipairs(arr) do
			if not empty(v.attr) then
				local value = 0

				if v.target == 0 then
					if v.attr == "curr_shield" then
						if attackPack.caster then
							value = attackPack.caster:getShield()
						end
					elseif v.attr == "curr_hp" then
						if casterBattleData then
							value = casterBattleData.hp
						end
					elseif v.attr == "curr_hp_lose" then
						if casterBattleData then
							value = attrs.hp - casterBattleData.hp
						end
					elseif v.attr == "curr_hp_per" then
						if casterBattleData then
							value = casterBattleData.hp / attrs.hp * 100
						end
					elseif v.attr == "curr_hp_lose_per" then
						if casterBattleData then
							value = (1 - casterBattleData.hp / attrs.hp) * 100
						end
					else
						value = attrs[v.attr]
					end
				elseif v.target == 1 then
					if v.attr == "curr_shield" then
						if target then
							value = target:getShield()
						end
					elseif v.attr == "curr_hp" then
						value = targetBattleData.hp
					elseif v.attr == "curr_hp_lose" then
						value = targetAttrs.hp - targetBattleData.hp
					elseif v.attr == "curr_hp_per" then
						value = targetBattleData.hp / targetAttrs.hp * 100
					elseif v.attr == "curr_hp_lose_per" then
						value = (1 - targetBattleData.hp / targetAttrs.hp) * 100
					else
						value = targetAttrs[v.attr]
					end
				end

				if v.target == 0 then
					damage = damage + value * v.multi
				elseif v.target == 1 then
					damage = damage + value * v.multi
				end
			end
		end

		local def = targetAttrs.def

		if attackPack.dustSkill and attackPack.dustSkill.skill_ignore_def and def > 0 then
			def = def * (1 - attackPack.dustSkill.skill_ignore_def)
		end

		local damageRatio = 0

		if attrs.atk == 0 then
			if def * skillData.use_defense == 0 then
				damageRatio = 1
			end
		else
			local fenmu = attrs.atk + def * skillData.use_defense

			if fenmu > 0 then
				damageRatio = attrs.atk / fenmu
			else
				damageRatio = 1
			end
		end

		tempValue = tempValue + damage * damageRatio

		for i, v in ipairs(CombatAttr.elements) do
			local element_res = targetAttrs.element_res

			if attackPack.dustSkill and attackPack.dustSkill.skill_ignore_res and element_res > 0 then
				element_res = element_res * (1 - attackPack.dustSkill.skill_ignore_res)
			end

			local elementValue = nil

			if skillData.ignore_res == 1 then
				elementValue = (skillData[v .. "_base"] + attrs.atk * skillData[v .. "_base_multi"] + attrs[v .. "_atk"] * skillData[v .. "_atk_multi"]) * 100 * (100 + attrs[v .. "_dmgadd"]) / 10000
			else
				elementValue = (skillData[v .. "_base"] + attrs.atk * skillData[v .. "_base_multi"] + attrs[v .. "_atk"] * skillData[v .. "_atk_multi"]) * (100 - targetAttrs[v .. "_res"] - element_res) * (100 + attrs[v .. "_dmgadd"]) / 10000
			end

			local elementValue = math.max(elementValue, 0)
			tempValue = tempValue + elementValue

			if elementValue > 0 and (not bestElementValue or bestElementValue < elementValue) then
				bestElement = v
				bestElementValue = elementValue
			end
		end

		local dmgTypeRatio = 1
		local skill_dmg_add = 0

		if attackPack.suitSkill then
			skill_dmg_add = attackPack.suitSkill.skill_critical_add
		end

		if skillData.ignore_res == 1 then
			if skillData.dmg_type == 1 then
				dmgTypeRatio = (100 + attrs.attack_dmgadd + skill_dmg_add) / 100
			elseif skillData.dmg_type == 2 then
				dmgTypeRatio = (100 + attrs.skill_dmgadd + skill_dmg_add) / 100
			elseif skillData.dmg_type == 3 then
				dmgTypeRatio = (100 + attrs.heal_dmgadd + skill_dmg_add) / 100
			end
		elseif skillData.dmg_type == 1 then
			if targetAttrs.attack_dmgresis >= 0 then
				dmgTypeRatio = (100 + attrs.attack_dmgadd + skill_dmg_add) / (100 + targetAttrs.attack_dmgresis)
			else
				dmgTypeRatio = (100 + attrs.attack_dmgadd + skill_dmg_add) * (100 - targetAttrs.attack_dmgresis) / 10000
			end
		elseif skillData.dmg_type == 2 then
			if targetAttrs.skill_dmgresis >= 0 then
				dmgTypeRatio = (100 + attrs.skill_dmgadd + skill_dmg_add) / (100 + targetAttrs.skill_dmgresis)
			else
				dmgTypeRatio = (100 + attrs.skill_dmgadd + skill_dmg_add) * (100 - targetAttrs.skill_dmgresis) / 10000
			end
		elseif skillData.dmg_type == 3 then
			dmgTypeRatio = (100 + attrs.heal_dmgadd + skill_dmg_add) * (100 + targetAttrs.getheal_dmgadd) / 10000
		end

		local monsterAdd = 0
		local monsterResis = 0

		if monsterClass then
			if monsterClass <= 10 then
				monsterResis = targetAttrs.normal_dmgresis
			else
				monsterResis = targetAttrs.elite_dmgresis
			end
		end

		if targetMonsterClass then
			if targetMonsterClass <= 10 then
				monsterAdd = attrs.normal_dmgadd
			else
				monsterAdd = attrs.elite_dmgadd
			end
		end

		local targetTypeRatio = (100 + monsterAdd) / (100 + monsterResis)

		if skillData.is_heal == 1 then
			tempValue = tempValue * dmgTypeRatio * criticalFloat
		else
			local holy_atk = skillData.holyatk_base + attrs.atk * skillData.holyatk_base_multi + attrs.holy_atk * skillData.holyatk_atk_multi
			local level_advance_range = CsvParser.getCsvData("config", "level_advance_range").value
			local level_advance_ratio = CsvParser.getCsvData("config", "level_advance_ratio").value
			local levelAdvance = 1

			if attackPack.type ~= "modao" and attackPack.level then
				local levelOffset = attackPack.level - targetLevel + level_advance_range

				if levelOffset < 0 then
					levelAdvance = math.max(0.1, (100 + levelOffset) / (100 * level_advance_ratio))
				end
			end

			if skillData.dmg_type == 4 then
				tempValue = (tempValue * dmgTypeRatio * targetTypeRatio + holy_atk) * criticalFloat * levelAdvance
			elseif skillData.ignore_res == 1 then
				tempValue = (tempValue * dmgTypeRatio * targetTypeRatio * (100 + attrs.dmgadd) / 100 + holy_atk) * criticalFloat * levelAdvance
			else
				tempValue = (tempValue * dmgTypeRatio * targetTypeRatio * (100 + attrs.dmgadd) / (100 + targetAttrs.dmgresis) + holy_atk - targetAttrs.holy_def) * criticalFloat * levelAdvance
			end
		end
	end

	tempValue = math.max(0, tempValue)
	local dmgValue = 0
	local breakValue = 0
	local healValue = 0

	if skillData.can_dmg ~= 0 then
		if skillData.is_heal ~= 1 then
			dmgValue = tempValue

			if attackPack.type == "modao" then
				local modaoData = InfoModao.getModaoData()
				dmgValue = dmgValue * (100 + modaoData.levipower_dmgadd) / (100 + targetAttrs.levipower_res)
			elseif skillData.dmg_type ~= 4 and targetAttrs.block_hit > 0 and targetAttrs.block_dmgresis > 0 and WarMachine.random:next() < targetAttrs.block_hit / 100 then
				dmgValue = dmgValue * (1 - targetAttrs.block_dmgresis / 100)
				isBlock = true
			end

			if not isDodge then
				breakValue = (skillData.break_base + attrs.atk * skillData.break_base_multi + attrs.break_atk * skillData.break_atk_multi) * (100 - targetAttrs.break_res) / 100
				breakValue = math.max(math.floor(breakValue), 0)
			end
		else
			healValue = tempValue
		end
	end

	if not dmgValue or dmgValue ~= dmgValue then
		dump(attackPack)
	end

	local bloodDrainValue = 0

	if dmgValue > 0 then
		local blood_drain = 0

		if not empty(skillData.blood_drain) then
			blood_drain = blood_drain + skillData.blood_drain
		end

		if not empty(attrs.hp_drain_ratio) then
			blood_drain = blood_drain + attrs.hp_drain_ratio / 100
		end

		if bloodDrainValue > 0 then
			bloodDrainValue = dmgValue * skillData.blood_drain
		end
	end

	if not empty(attrs.hp_drain_value) then
		bloodDrainValue = bloodDrainValue * attrs.hp_drain_value
	end

	local manaDrainValue = 0

	if not empty(attrs.mp_drain_value) then
		manaDrainValue = attrs.mp_drain_value
	end

	dmgValue = math.ceil(dmgValue * dmgRatio)
	breakValue = math.ceil(breakValue * dmgRatio)
	healValue = math.ceil(healValue * healRatio)
	bloodDrainValue = math.ceil(bloodDrainValue * healRatio)
	local isInf = false

	if isINF(dmgValue) then
		isInf = true
		dmgValue = 0
	end

	if isINF(breakValue) then
		isInf = true
		breakValue = 0
	end

	if isINF(healValue) then
		isInf = true
		healValue = 0
	end

	healValue = math.max(0, healValue)

	if isINF(bloodDrainValue) then
		isInf = true
		bloodDrainValue = 0
	end

	return dmgValue, healValue, breakValue, isCritical, isDodge, isBlock, bestElement, bloodDrainValue, manaDrainValue
end

return DamageRule
