local POP_mapname = class("POP_mapname", UI_base)

function POP_mapname.open(title, subTitle)
	local ui = POP_mapname.new(title, subTitle)
	POP_mapname.instance = ui

	display.getRunningScene():addChild(ui, LayerConfig.pop)
end

function POP_mapname.close()
	if POP_mapname.instance then
		POP_mapname.instance:removeSelf()
	end
end

function POP_mapname:ctor(title, subTitle)
	POP_mapname.super.ctor(self, "pop_mapname")

	self.title = title
	self.subTitle = subTitle

	self:init()
end

function POP_mapname:init()
	self:initUI()
	self:fadeIn()
end

function POP_mapname:initUI()
	local label1, labelWidth1 = self:createLabelOnFlag("flag_title", self.title)

	if not empty(self.subTitle) then
		self:createLabelOnFlag("flag_subtitle", self.subTitle)
	else
		self:removeLabelOnFlag("flag_subtitle")
	end

	self.lineWidth = display.width
end

function POP_mapname:fadeIn()
	transition.moveTo(self, {
		y = 100,
		time = 0.5,
		easing = "sineOut"
	})

	local line = self:getComponentByTag("line")

	line:setSize(0)

	local countMax = 120
	local count = 0

	local function openAnimate(elapsed_time)
		if count < countMax then
			count = math.min(countMax, count + 60 * elapsed_time)
			local width = self.lineWidth * count / countMax

			line:setSize(width, nil, true)
			line:setPos(display.cx - width / 2)
		else
			self:removeEnterFrame("openAnimate")
		end
	end

	self:addEnterFrame("openAnimate", openAnimate)
	self:fadeOut()
end

function POP_mapname:fadeOut()
	transition.fadeTo(self, {
		time = 0.3,
		delay = 1.7,
		easing = "sineOut",
		opacity = 0,
		onComplete = function ()
			self:removeSelf()
		end
	})
end

function POP_mapname:onExit()
	POP_mapname.instance = nil

	POP_mapname.super.onExit(self)
end

return POP_mapname
