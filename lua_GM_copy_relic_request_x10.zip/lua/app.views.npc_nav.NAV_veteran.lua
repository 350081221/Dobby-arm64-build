local NAV_base = import(".NAV_base")
local NAV_veteran = class("NAV_veteran", NAV_base)

function NAV_veteran.open(npc)
	local ui = NAV_veteran.new(npc)

	return ui
end

function NAV_veteran:ctor(npc)
	NAV_veteran.super.ctor(self, npc, "nav_veteran")
end

function NAV_veteran:init()
	NAV_veteran.super.init(self)

	local index = 2
	local funcCSV = InfoFunction.checkFuncOpen(10140)

	if funcCSV then
		self:setButtonVisible(index, true)
	else
		self:setButtonVisible(index, false)
	end

	local index = 3
	local funcCSV = InfoFunction.checkFuncOpen(10141)

	if funcCSV then
		self:setButtonVisible(index, true)
	else
		self:setButtonVisible(index, false)
	end

	local index = 4
	local funcCSV = InfoFunction.checkFuncOpen(10142)

	if funcCSV then
		self:setButtonVisible(index, true)
	else
		self:setButtonVisible(index, false)
	end
end

function NAV_veteran:onTap(index)
	NAV_veteran.super.onTap(self, index)

	if not InfoGuide.isFin() then
		local currentGuide = InfoGuide.getCurrent()

		if currentGuide and currentGuide == 7040 then
			local checkBlueLevel = nil
			local team = InfoHero.getTeam()

			for i, heroInfo in ipairs(team) do
				if heroInfo.quality == 2 and heroInfo.level >= 20 then
					checkBlueLevel = true

					break
				end
			end

			if checkBlueLevel then
				InfoGuide.finish(currentGuide)
				InfoGuide.setID(currentGuide)

				currentGuide = InfoGuide.getCurrent()
			end
		end

		if currentGuide and currentGuide < 8010 then
			Alert.open(Localization.getSrcText("请先完成前序引导"))

			return
		end
	end

	if index == 1 then
		FRAME_hero_transfer.open(self.npc)
	elseif index == 2 then
		FRAME_hero_reborn.open(self.npc)
	elseif index == 3 then
		local arr = FRAME_hero_wash.getHeroReady()

		if #arr > 0 then
			FRAME_hero_wash.open(self.npc)
		else
			Alert.open(Localization.getSrcText("只能洗练红色冒险者"))
		end
	elseif index == 4 then
		FRAME_hero_exchange.open(self.npc)
	end
end

return NAV_veteran
