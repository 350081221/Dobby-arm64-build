local LoginScene = class("LoginScene", function ()
	return display.newScene("LoginScene")
end)

function LoginScene:ctor()
end

function LoginScene:init()
	Sound.playMusic("overworld")
	self:initUI()
end

function LoginScene:initUI()
	local ui = FRAME_login.new()

	self:addChild(ui)
end

function LoginScene:onEnter()
	app:onSceneEnter(self)
	self:init()
end

function LoginScene:onExit()
	app:onSceneExit(self)
end

return LoginScene
