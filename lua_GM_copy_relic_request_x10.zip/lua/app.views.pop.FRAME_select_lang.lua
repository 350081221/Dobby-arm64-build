local FRAME_select_lang = class("FRAME_select_lang", UI_base)

function FRAME_select_lang.open()
	local ui = FRAME_select_lang.new()

	PopManager.open(ui)
end

function FRAME_select_lang:ctor()
	FRAME_select_lang.super.ctor(self, "frame_select_lang", UIManager.BIG_TYPE.POP)
	self:init()
end

function FRAME_select_lang:init()
	self:initUI()

	self.initLang = Localization.getLang()
	self.lang = self.initLang

	self:refresh()
end

function FRAME_select_lang:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local function tapListener(ui, data, index, x, y)
		self.lang = data.id

		self:refresh()
	end

	self.list = self:createListOnFlag("flag_list", LIST_select_lang, tapListener)

	self.list:setTapGroup("list_click")

	local holder = self:getComponentByTag("holder")

	self.list:setHolders({
		holder
	}, nil, 5)

	local confirmPB = self:getComponentByTag("bt_confirm")

	confirmPB:toTouchable()
	confirmPB:setTapGroup("button_click")
	confirmPB:addTap(function ()
		if self.initLang ~= self.lang then
			Localization.setLang(self.lang)
		else
			Localization.setLangVar(self.lang)
			PopManager.close()
		end
	end)
end

function FRAME_select_lang:refresh()
	local langArr = Localization.getLangList()
	local selectedIndex = nil

	for i, v in ipairs(langArr) do
		if v.id == self.lang then
			selectedIndex = i

			break
		end
	end

	self.list:setItems(langArr, true)

	if selectedIndex then
		self.list:setSelectedIndex(selectedIndex)
	end
end

return FRAME_select_lang
