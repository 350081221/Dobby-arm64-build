local RefreshManager = {}
local TYPE = {
	PET_FEED = 90001,
	BACK_STAGE = 80003,
	BACK_ACHIEVE_DAY = 80002,
	BACK_SIGN = 80001,
	BP_ACHIEVE_WEEK = 50002,
	BP_ACHIEVE_DAY = 50001,
	UNION_PVE_REFRESH_CHALLENGE_TIMES = 40020,
	UNION_PVE_END = 40014,
	UNION_PVE_BOSS3 = 40013,
	UNION_PVE_BOSS2 = 40012,
	UNION_PVE_BOSS1 = 40011,
	UNION_PVE_PREPARE = 40010,
	UNION_WAR_END = 40009,
	UNION_WAR_ROUND_5 = 40008,
	UNION_WAR_ROUND_4 = 40007,
	UNION_WAR_ROUND_3 = 40006,
	UNION_WAR_ROUND_2 = 40005,
	UNION_WAR_ROUND_1 = 40004,
	UNION_WAR_ENROLL = 40003,
	UNION_MEMBER_SHOP = 40002,
	UNION_DONATE = 40001,
	DUST_SHOP = 33001,
	DUST_BOSS_REWARD = 32001,
	DUST_ACHIEVE_WEEK = 31002,
	DUST_ACHIEVE_DAY = 30001,
	DAILY_ORDER = 25001,
	HOME_SHOP = 24001,
	NARAKA_SHOP = 23001,
	MARUKA_REWARD = 22001,
	NAKARA = 21001,
	CAMPFIRE = 18001,
	ABYSS_GIFT_SHOP = 16001,
	ABYSS_GIFT = 14001,
	FISHING_SHOP = 13001,
	GACHA_SHOP = 11001,
	FARM_SHOP = 10001,
	LIKES_DAILY = 9001,
	INVEST = 8001,
	GIFT_SHOP_3 = 7003,
	GIFT_SHOP_2 = 7002,
	GIFT_SHOP_1 = 7001,
	SIGN_IN = 6001,
	ARENA_SHOP = 5010,
	ARENA_WEEK_REWARD = 5004,
	ARENA_SEASON = 5003,
	ARENA_REFRESH = 5002,
	ARENA_TIMES = 5001,
	TRAVEL = 4001,
	TASK = 3001,
	KANBAN = 3000,
	SHOP_2 = 2001,
	SHOP_1 = 2000,
	TAVERN = 1000
}
RefreshManager.TYPE = TYPE
local refresh_moments_map = nil

function RefreshManager.getRefreshMoments(type)
	if not refresh_moments_map then
		refresh_moments_map = {}
		local refresh_csv_list = CsvParser.getCsvList("refresh")

		for i, v in ipairs(refresh_csv_list) do
			if not refresh_moments_map[v.type] then
				refresh_moments_map[v.type] = {}
			end

			table.insert(refresh_moments_map[v.type], v)
		end
	end

	return refresh_moments_map[type]
end

function RefreshManager.getMoments(type, nowTime)
	nowTime = math.floor(nowTime) + Time.getTimezoneOffset()
	local moments = RefreshManager.getRefreshMoments(type)
	local momentTimes = {}

	for i, v in ipairs(moments) do
		local moment = nil

		if v.time_type == 1 then
			moment = Time.getNextMomentWeek(nowTime, v.start_time)
		elseif v.time_type == 2 then
			moment = Time.getNextMomentMonth(nowTime, v.start_time)
		else
			moment = Time.getNextMomentInterval(nowTime, v.interval, v.start_time)
		end

		table.insert(momentTimes, moment - Time.getTimezoneOffset())
	end

	return momentTimes
end

function RefreshManager.checkTimePassed(type, nowTime, preTime)
	nowTime = math.floor(nowTime)
	local moment1 = RefreshManager.getNextTime(type, preTime)
	local moment2 = RefreshManager.getNextTime(type, nowTime)

	return moment1 < moment2
end

function RefreshManager.checkTimePassedDays(type, nowTime, preTime)
	local moment1 = RefreshManager.getNextTime(type, preTime)
	local moment2 = RefreshManager.getNextTime(type, nowTime)
	local days = math.floor((moment2 - moment1) / Time.SECONDS_PER_DAY)

	return days
end

function RefreshManager.checkOpenTime(type, nowTime)
	local section = RefreshManager.getSection(type, nowTime)

	return section == 1
end

function RefreshManager.getSection(type, nowTime)
	local originalTime = nowTime
	nowTime = math.floor(nowTime) + Time.getTimezoneOffset()
	local moments = RefreshManager.getRefreshMoments(type)
	local minMonent, minIndex, lastMonent = nil
	local allTimeElements = {}

	for i, v in ipairs(moments) do
		local moment = nil

		if v.time_type == 1 then
			moment = Time.getNextMomentWeek(nowTime, v.start_time)
		elseif v.time_type == 2 then
			moment = Time.getNextMomentMonth(nowTime, v.start_time)
		elseif v.time_type == 3 then
			moment = Time.getFirstWeekTimeInMonth(originalTime) + v.start_time
			moment = moment + Time.getTimezoneOffset()
		else
			moment = Time.getNextMomentInterval(nowTime, v.interval, v.start_time)
		end

		if not minMonent or moment < minMonent then
			minMonent = moment
			minIndex = i
		end

		if i == #moments then
			lastMonent = moment
		end

		table.insert(allTimeElements, moment - Time.getTimezoneOffset())
	end

	if minIndex then
		minIndex = minIndex - 1

		if minIndex < 1 then
			minIndex = #moments
		end
	end

	return minIndex, minMonent - Time.getTimezoneOffset(), lastMonent - Time.getTimezoneOffset(), allTimeElements
end

function RefreshManager.getSharp(type, nowTime)
	nowTime = math.floor(nowTime) + Time.getTimezoneOffset()
	local moments = RefreshManager.getRefreshMoments(type)
	local moment = moments[1]
	local sharp = nil

	if moment.time_type == 1 then
		sharp = Time.getSharpWeek(nowTime, moment.start_time)
	elseif moment.time_type == 2 then
		sharp = Time.getSharpMonth(nowTime, moment.start_time)
	else
		sharp = Time.getSharpInterval(nowTime, moment.interval, moment.start_time)
	end

	return sharp
end

function RefreshManager.getNextTime(type, nowTime)
	nowTime = math.floor(nowTime) + Time.getTimezoneOffset()
	local moments = RefreshManager.getRefreshMoments(type)
	local minMonent = nil

	for i, v in ipairs(moments) do
		local moment = nil

		if v.time_type == 1 then
			moment = Time.getNextMomentWeek(nowTime, v.start_time)
		elseif v.time_type == 2 then
			moment = Time.getNextMomentMonth(nowTime, v.start_time)
		else
			moment = Time.getNextMomentInterval(nowTime, v.interval, v.start_time)
		end

		if not minMonent or moment < minMonent then
			minMonent = moment
		end
	end

	return minMonent - Time.getTimezoneOffset()
end

local refresh_data = nil

function RefreshManager.get(type, times)
	if not refresh_data then
		local refresh_csv_raw = CsvParser.getCsvRaw("refresh_cost")
		local refreshMatMap = {}
		local refreshMaxTimes = {}

		for k, v in pairs(refresh_csv_raw) do
			if not refreshMatMap[v.type] then
				refreshMatMap[v.type] = {}
			end

			if v.fin == 1 then
				refreshMatMap[v.type][v.times] = false
			else
				refreshMatMap[v.type][v.times] = SheetUtil.getColumnList(v, {
					"mat_id_",
					"mat_num_"
				}, {
					"base_id",
					"num"
				})
			end

			if not refreshMaxTimes[v.type] then
				refreshMaxTimes[v.type] = v.times
			else
				refreshMaxTimes[v.type] = math.max(refreshMaxTimes[v.type], v.times)
			end
		end

		refresh_data = {
			matMap = refreshMatMap,
			maxMap = refreshMaxTimes
		}
	end

	local maxTimes = refresh_data.maxMap[type]
	local mats = refresh_data.matMap[type][math.min(maxTimes, times)]

	return mats, maxTimes
end

local refresh_desc_map, refresh_desc_arr_map = nil

function RefreshManager.getDesc(type, index)
	if not refresh_desc_map then
		refresh_desc_map = {}
		refresh_desc_arr_map = {}
		local refresh_csv_list = CsvParser.getCsvList("refresh")

		for i, v in ipairs(refresh_csv_list) do
			refresh_desc_map[v.type] = v.desc

			if not refresh_desc_arr_map[v.type] then
				refresh_desc_arr_map[v.type] = {}
			end

			table.insert(refresh_desc_arr_map[v.type], v.desc)
		end
	end

	if index then
		if refresh_desc_arr_map[type] and refresh_desc_arr_map[type][index] then
			return refresh_desc_arr_map[type][index]
		end
	elseif refresh_desc_map[type] then
		return refresh_desc_map[type]
	end

	return Localization.getSrcText("未找到刷新配置")
end

function RefreshManager.clearCache()
	refresh_desc_map = nil
	refresh_desc_arr_map = nil
end

return RefreshManager
