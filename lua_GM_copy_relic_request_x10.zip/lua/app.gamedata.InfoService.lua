local InfoService = {}
local sns_list = {}
local feedback_list = {}
local rawData = {}

function InfoService.init()
	Connection.listen("service_feedback_sync", InfoService.sync)
	Connection.listen("service_review_reward_sync", InfoService.syncReward)
end

app:addToAppEnterCall(InfoService.init)

function InfoService.syncReward(data)
	dump(data, "$$$ InfoService.syncReward")

	if data.review_reward then
		rawData.review_reward = data.review_reward
	end
end

function InfoService.sync(data)
	dump(data, "$$$ InfoService.sync")

	if not feedback_list then
		return
	end

	local found = false

	for i, v in ipairs(feedback_list) do
		if v.id == data.id then
			for k1, v1 in pairs(data) do
				v[k1] = v1
			end

			found = true

			break
		end
	end

	if not found then
		table.insert(feedback_list, data)
	end

	ManagerInfo.dataChange("service")
end

function InfoService.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoService.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("service_query", callback)
end

function InfoService.onQuery(rcvData)
	dump(rcvData, "service_query")

	rawData = {
		review_reward = rcvData.review_reward
	}
	sns_list = rcvData.sns_list or {}
	feedback_list = rcvData.feedback_list or {}
end

function InfoService.feedback(text, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("service_feedback", {
		text = text
	}, callback)
end

function InfoService.feedbackRead(id_arr, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			local idMap = {}

			for i, id in ipairs(id_arr) do
				idMap[id] = true
			end

			for i, v in ipairs(feedback_list) do
				if idMap[v.id] then
					v.is_read = 1
				end
			end

			ManagerInfo.dataChange("service")

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("service_feedback_read", {
		id_arr = id_arr
	}, callback)
end

function InfoService.countRedot()
	local redotCount = 0

	for i, v in ipairs(feedback_list) do
		if v.is_read == 0 then
			redotCount = redotCount + 1
		end
	end

	return redotCount
end

function InfoService.getFeedbackList()
	local arr = {}

	if feedback_list then
		for i, v in ipairs(feedback_list) do
			table.insert(arr, v)
		end
	end

	table.sort(arr, function (a, b)
		if a.is_read == b.is_read then
			return b.id < a.id
		else
			return a.is_read < b.is_read
		end
	end)

	return arr
end

function InfoService.getSnsList()
	local arr = {}

	if sns_list then
		for i, v in ipairs(sns_list) do
			if v.sns_id ~= 0 then
				table.insert(arr, v)
			end
		end
	end

	table.sort(arr, function (a, b)
		return a.id < b.id
	end)

	return arr
end

function InfoService.report(text, user_id, nickname, hash, data_json, onSuccess, onFailure)
	local reportArr = Cookie.get("report_arr") or {}

	if reportArr then
		for i, v in ipairs(reportArr) do
			if v == hash then
				onSuccess()

				return
			end
		end
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("service_report", {
		text = text,
		user_id = user_id,
		nickname = nickname,
		hash = hash,
		data_json = data_json
	}, callback)
	table.insert(reportArr, hash)
	Cookie.set("report_arr", reportArr, true)
end

function InfoService.reportCheat(user_id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "service_report_cheating_precheck")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("service_report_cheating_precheck", {
		user_id = user_id
	}, callback)
end

function InfoService.reportCheatSubmit(user_id, token, content, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "service_report_cheating_submit")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("service_report_cheating_submit", {
		user_id = user_id,
		token = token,
		content = content
	}, callback)
end

function InfoService.reviewRewardAvailable()
	return rawData.review_reward == 0
end

function InfoService.reviewReward(onSuccess, onFailure)
	if rawData.review_reward ~= 0 then
		return
	end

	local function callback(rcvData)
		dump(rcvData, "service_review_reward")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("service_review_reward", {}, callback)
end

function InfoService.reviewMark(onSuccess, onFailure)
	if rawData.review_reward ~= 0 then
		return
	end

	local function callback(rcvData)
		dump(rcvData, "service_review_mark")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("service_review_mark", {}, callback)
end

return InfoService
