local InfoRanking = {}
local rawData = {}

function InfoRanking.init()
	Connection.listen("ranking_sync", InfoRanking.sync)
end

app:addToAppEnterCall(InfoRanking.init)

function InfoRanking.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoRanking.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("ranking_query", callback)
end

function InfoRanking.onQuery(rcvData)
	dump(rcvData, "ranking_query")

	rawData = {}

	for i, data in ipairs(rcvData.list) do
		rawData[data.type] = data
	end
end

function InfoRanking.sync(data)
	for i, syncData in ipairs(data.list) do
		local type = syncData.type

		if rawData[type] then
			for k, v in pairs(syncData) do
				rawData[type][k] = v
			end
		else
			rawData[type] = syncData
		end
	end

	ManagerInfo.dataChange("ranking")
end

function InfoRanking.getTypes(buildingTag)
	local csvList = CsvParser.getCsvList("ranking_type", "index", {
		building_tag = buildingTag
	})
	local arr = {}

	for i, v in ipairs(csvList) do
		if empty(v.open_time) or RefreshManager.getSection(v.open_time, Time.now()) == 2 then
			table.insert(arr, v)
		end
	end

	return arr
end

local ranking_map_type = {}
local requesting_map_type = {}
local request_time_map_type = {}
local rankingAmount_type = {}
local rankingStart_type = {}
local rankingStart_time_type = {}

function InfoRanking.getSeasonData(type)
	return rankingStart_type[type].season_data
end

function InfoRanking.getMyPoints(type)
	local data = rankingStart_type[type]
	local points = data.self_points

	if data.self_season ~= data.season_data.season then
		points = 0
	end

	return points
end

function InfoRanking.getMyRank(type)
	return rankingStart_type[type].self_rank
end

function InfoRanking.getRankingAmount(type)
	return rankingStart_type[type].amount
end

function InfoRanking.startRanking(type, onSuccess, onFailure)
	if rankingStart_type[type] and Time.time() - rankingStart_time_type[type] <= GameConfig.ranking_local_time then
		onSuccess()

		return
	end

	print("$$$ startRanking", type)

	local function callback(rcvData)
		dump(rcvData, "$$$ ranking_ranking_start")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			rankingStart_type[type] = rcvData
			rankingStart_time_type[type] = Time.time()

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("ranking_ranking_start", {
		type = type
	}, callback)
end

function InfoRanking.getRanking(type, page, onSuccess, onFailure)
	local ranking_map, requesting_map, request_time_map = InfoRanking.initRankingType(type)
	local start_index = (page - 1) * GameConfig.ranking_page + 1
	local csv = CsvParser.getCsvData("ranking_type", type)

	if csv.ranking_max < start_index then
		return
	end

	local function callback(rcvData)
		dump(rcvData, "$$$ ranking_ranking")

		requesting_map[page] = nil
		request_time_map[page] = Time.time()

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			local list = rcvData.list

			for i, v in ipairs(list) do
				local rank = start_index + i - 1
				ranking_map[rank] = {
					rank = rank,
					id = v.user_id,
					name = v.name,
					points = v.points,
					head = v.head,
					head_frame = v.head_frame
				}
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	requesting_map[page] = true

	Connection.request("ranking_ranking", {
		type = type,
		start_index = start_index
	}, callback)
end

function InfoRanking.getRankingData(type, rank)
	local ranking_map, requesting_map, request_time_map = InfoRanking.initRankingType(type)
	local page = math.floor((rank - 1) / GameConfig.ranking_page) + 1

	if not ranking_map[rank] or GameConfig.ranking_local_time < Time.time() - request_time_map[page] then
		if not requesting_map[page] then
			InfoRanking.getRanking(type, page)
		end
	else
		return ranking_map[rank]
	end
end

function InfoRanking.initRankingType(type)
	if not ranking_map_type[type] then
		ranking_map_type[type] = {}
	end

	local ranking_map = ranking_map_type[type]

	if not requesting_map_type[type] then
		requesting_map_type[type] = {}
	end

	local requesting_map = requesting_map_type[type]

	if not request_time_map_type[type] then
		request_time_map_type[type] = {}
	end

	local request_time_map = request_time_map_type[type]

	return ranking_map, requesting_map, request_time_map
end

function InfoRanking.clearRanking(type)
	ranking_map_type[type] = {}
	requesting_map_type[type] = {}
	request_time_map_type[type] = {}
	rankingStart_type[type] = {}
	rankingStart_time_type[type] = {}
end

function InfoRanking.getDescTime(points)
	local level = math.floor(points / 65536) + 1
	local time = 65536 - points % 65536

	return level, time
end

return InfoRanking
