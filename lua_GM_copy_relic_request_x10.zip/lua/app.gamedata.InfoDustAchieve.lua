local InfoDustAchieve = {}
local TYPE = {
	DAY = 1,
	WEEK = 2
}
InfoDustAchieve.TYPE = TYPE
local rawData = {}
local day_refresh, day_rewarded, day_rewarded_time, week_refresh, week_rewarded, week_rewarded_time = nil

function InfoDustAchieve.init()
	Connection.listen("dust_achieve_sync", InfoDustAchieve.sync)
	Connection.listen("dust_achieve_sync_remove", InfoDustAchieve.syncRemove)
end

app:addToAppEnterCall(InfoDustAchieve.init)

function InfoDustAchieve.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoDustAchieve.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("dust_achieve_query", callback)
end

function InfoDustAchieve.onQuery(rcvData)
	dump(rcvData, "dust_achieve_query")

	rawData = {}

	for i, data in ipairs(rcvData.list) do
		rawData[data.base_id] = data
	end

	day_refresh = rcvData.day_refresh
	day_rewarded = rcvData.day_rewarded
	day_rewarded_time = rcvData.day_rewarded_time
	week_refresh = rcvData.week_refresh
	week_rewarded = rcvData.week_rewarded
	week_rewarded_time = rcvData.week_rewarded_time
end

function InfoDustAchieve.sync(data)
	dump(data, "$$$ InfoDustAchieve.sync")

	if data.list then
		for i, syncData in ipairs(data.list) do
			local base_id = syncData.base_id

			if rawData[base_id] then
				for k, v in pairs(syncData) do
					rawData[base_id][k] = v
				end
			else
				rawData[base_id] = syncData
			end
		end
	end

	if data.day_refresh then
		day_refresh = data.day_refresh
	end

	if data.day_rewarded then
		day_rewarded = data.day_rewarded
	end

	if data.day_rewarded_time then
		day_rewarded_time = data.day_rewarded_time
	end

	if data.week_refresh then
		week_refresh = data.week_refresh
	end

	if data.week_rewarded then
		week_rewarded = data.week_rewarded
	end

	if data.week_rewarded_time then
		week_rewarded_time = data.week_rewarded_time
	end

	ManagerInfo.dataChange("dust_achieve")
end

function InfoDustAchieve.syncRemove(data)
	dump(data, "$$$ InfoDustAchieve.syncRemove")

	if data.list then
		for i, base_id in ipairs(data.list) do
			rawData[base_id] = nil
		end
	end
end

function InfoDustAchieve.getList(type)
	local arr = {}

	for base_id, data in pairs(rawData) do
		if data.type == type then
			table.insert(arr, data)
		end
	end

	table.sort(arr, function (a, b)
		return a.base_id < b.base_id
	end)

	return arr
end

function InfoDustAchieve.isFinished(type)
	local arr = InfoDustAchieve.getList(type)

	for i = 1, 3 do
		local data = arr[i]

		if data then
			local count = data.count

			if type == TYPE.DAY then
				if RefreshManager.checkTimePassed(RefreshManager.TYPE.DUST_ACHIEVE_DAY, Time.now(), data.count_time) then
					count = 0
				end
			elseif type == TYPE.WEEK and RefreshManager.checkTimePassed(RefreshManager.TYPE.DUST_ACHIEVE_WEEK, Time.now(), data.count_time) then
				count = 0
			end

			local csv = CsvParser.getCsvData("dust_pass_achieve", data.base_id)

			if count < csv.num then
				return false
			end
		else
			return false
		end
	end

	return true
end

function InfoDustAchieve.isRewarded(type)
	local rewarded = 0

	if type == TYPE.DAY then
		rewarded = day_rewarded

		if RefreshManager.checkTimePassed(RefreshManager.TYPE.DUST_ACHIEVE_DAY, Time.now(), day_rewarded_time) then
			rewarded = 0
		end
	elseif type == TYPE.WEEK then
		rewarded = week_rewarded

		if RefreshManager.checkTimePassed(RefreshManager.TYPE.DUST_ACHIEVE_WEEK, Time.now(), week_rewarded_time) then
			rewarded = 0
		end
	end

	return rewarded > 0
end

function InfoDustAchieve.getRewardList(type)
	local _, dustID = InfoDust.getState()
	local csv = CsvParser.getCsvData("dust_pass", dustID)

	if csv then
		if type == TYPE.DAY then
			local arr = SheetUtil.getColumnList(csv, {
				"daily_reward_",
				"daily_reward_num_"
			}, {
				"base_id",
				"num"
			})

			return arr
		elseif type == TYPE.WEEK then
			local arr = SheetUtil.getColumnList(csv, {
				"weekly_reward_",
				"weekly_reward_num_"
			}, {
				"base_id",
				"num"
			})

			return arr
		end
	end

	return {}
end

function InfoDustAchieve.countRedot(type)
	local redotCount = 0
	local csvList = CsvParser.getCsvList("first_achieve", nil, {
		day = day
	})

	for i, csv in ipairs(csvList) do
		local count, max, rewarded = InfoDustAchieve.getProgress(csv.id)

		if rewarded == 0 and max <= count then
			redotCount = redotCount + 1
		end
	end

	return redotCount
end

function InfoDustAchieve.getReward(type, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("dust_achieve_get_reward", {
		type = type
	}, callback)
end

function InfoDustAchieve.getExp(base_id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("dust_achieve_get_exp", {
		base_id = base_id
	}, callback)
end

function InfoDustAchieve.refresh(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("dust_achieve_refresh", callback)
end

function InfoDustAchieve.checkRefresh(onSuccess, onFailure)
	local typeArr = {
		TYPE.DAY,
		TYPE.WEEK
	}
	local nowTime = Time.now()
	local needRefresh = false

	for i, type in ipairs(typeArr) do
		if type == TYPE.DAY then
			if RefreshManager.checkTimePassed(RefreshManager.TYPE.DUST_ACHIEVE_DAY, nowTime, day_refresh) then
				needRefresh = true
			end
		elseif type == TYPE.WEEK and RefreshManager.checkTimePassed(RefreshManager.TYPE.DUST_ACHIEVE_WEEK, nowTime, week_refresh) then
			needRefresh = true
		end
	end

	if needRefresh then
		InfoDustAchieve.refresh(onSuccess, onFailure)
	end
end

return InfoDustAchieve
