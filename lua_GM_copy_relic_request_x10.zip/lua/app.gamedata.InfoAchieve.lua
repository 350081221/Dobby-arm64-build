local InfoAchieve = {}
local rawData = {}

function InfoAchieve.init()
	Connection.listen("achieve_sync", InfoAchieve.sync)
end

app:addToAppEnterCall(InfoAchieve.init)

function InfoAchieve.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoAchieve.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("achieve_query", callback)
end

function InfoAchieve.onQuery(rcvData)
	rawData = {}

	for i, data in ipairs(rcvData.list) do
		rawData[data.achieve_id] = data
	end
end

function InfoAchieve.sync(data)
	for i, syncData in ipairs(data.list) do
		local achieve_id = syncData.achieve_id
		rawData[achieve_id] = syncData
	end

	ManagerInfo.dataChange("achieve")
end

function InfoAchieve.getReward(id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("achieve_get_reward", {
		id = id
	}, callback)
end

function InfoAchieve.getAchieveInfo(achieve_id)
	local count = 0
	local step = 0

	if rawData[achieve_id] then
		count = rawData[achieve_id].count
		step = rawData[achieve_id].step
	end

	return step, count
end

function InfoAchieve.countRedot()
	local csvRaw = CsvParser.getCsvRaw("achievement")
	local redotCount = 0
	local labelList = InfoAchieve.getLabelList()

	for i, labelData in ipairs(labelList) do
		redotCount = redotCount + labelData.redot
	end

	return redotCount
end

function InfoAchieve.getLabelList()
	local csvList = CsvParser.getCsvList("achievement_label")
	local arr = {}

	for i, csv in ipairs(csvList) do
		local items, doneCount = InfoAchieve.getList(csv.id)
		local redot = 0

		for j, item in ipairs(items) do
			if item.csv.value <= item.count then
				redot = redot + 1
			end
		end

		table.insert(arr, {
			csv = csv,
			redot = redot
		})
	end

	return arr
end

local maxStepCache = nil

function InfoAchieve.getMaxStep(achieveID)
	if not maxStepCache then
		maxStepCache = {}
		local csvRaw = CsvParser.getCsvRaw("achievement")

		for k, csv in pairs(csvRaw) do
			if not maxStepCache[csv.achieve_id] then
				maxStepCache[csv.achieve_id] = csv.step
			else
				maxStepCache[csv.achieve_id] = math.max(maxStepCache[csv.achieve_id], csv.step)
			end
		end
	end

	return maxStepCache[achieveID]
end

function InfoAchieve.isFinished(achieveID)
	if rawData[achieveID] and InfoAchieve.getMaxStep(achieveID) <= rawData[achieveID].step then
		return true
	end

	return false
end

function InfoAchieve.getList(label)
	local csvRaw = CsvParser.getCsvRaw("achievement")
	local arr = {}
	local doneCount = 0

	for k, v in pairs(csvRaw) do
		local preCheck = true

		if not empty(v.pre_achieve) and not InfoAchieve.isFinished(v.pre_achieve) then
			preCheck = false
		end

		if preCheck then
			local step, count = InfoAchieve.getAchieveInfo(v.achieve_id)

			if step + 1 == v.step then
				if label == v.label then
					table.insert(arr, {
						csv = v,
						count = count
					})
				end
			elseif v.step <= step then
				doneCount = doneCount + 1
			end
		end
	end

	table.sort(arr, function (a, b)
		local percentA = math.min(1, a.count / a.csv.value)
		local percentB = math.min(1, b.count / b.csv.value)

		if percentA == percentB then
			return a.csv.achieve_id < b.csv.achieve_id
		else
			return percentB < percentA
		end
	end)

	return arr, doneCount
end

return InfoAchieve
