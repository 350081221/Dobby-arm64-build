local InfoActvMonster = {}
local data_self = {}
local data_config = {}

function InfoActvMonster.init()
	Connection.listen("actv_monster_sync", InfoActvMonster.sync)
end

app:addToAppEnterCall(InfoActvMonster.init)

function InfoActvMonster.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoActvMonster.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("actv_monster_query", callback)
end

function InfoActvMonster.onQuery(rcvData)
	dump(rcvData, "actv_monster_query")

	for i, v in ipairs(rcvData.list) do
		data_self[v.actv_id] = data_self[v.actv_id] or {}
		data_self[v.actv_id][v.base_id] = v
	end

	for i, v in ipairs(rcvData.config_list) do
		data_config[v.actv_id] = v
	end
end

function InfoActvMonster.sync(data)
	dump(data, "$$$ InfoActvMonster.sync")

	if data.list then
		for i, syncData in ipairs(data.list) do
			data_self[syncData.actv_id] = data_self[syncData.actv_id] or {}

			if not data_self[syncData.actv_id][syncData.base_id] then
				data_self[syncData.actv_id][syncData.base_id] = syncData
			else
				for k, v in pairs(syncData) do
					data_self[syncData.actv_id][syncData.base_id][k] = v
				end
			end
		end
	end

	if data.config_list then
		for i, syncData in ipairs(data.config_list) do
			if not data_config[syncData.actv_id] then
				data_config[syncData.actv_id] = syncData
			else
				for k, v in pairs(syncData) do
					data_config[syncData.actv_id][k] = v
				end
			end
		end
	end

	ManagerInfo.dataChange("actv_monster")
	notify.dispatch("actv_redot")
end

function InfoActvMonster.checkOpening(actv_id)
	local opening = InfoActv.checkBindOpening(actv_id, GameConfig.ACTV_TYPE.monster)

	return opening, actv_id
end

function InfoActvMonster.checkShopOpening(actv_id)
	local opening = InfoActv.checkBindShopOpening(actv_id, GameConfig.ACTV_TYPE.monster)

	return opening, actv_id
end

function InfoActvMonster.getMonsterList(actv_id)
	local opening = InfoActvMonster.checkOpening(actv_id)

	if opening and data_config[actv_id] and data_config[actv_id].monster then
		local monster = data_config[actv_id].monster
		local dataOne = data_self[actv_id]
		local arr = {}

		for i, v in ipairs(monster) do
			local obj = {}

			for k1, v1 in pairs(v) do
				obj[k1] = v1
			end

			obj.count = 0

			if dataOne then
				local data = dataOne[obj.id]

				if data then
					local day_count = data.day_count

					if data.actv_id ~= actv_id then
						day_count = 0
					end

					if Time.checkDayPassed(data.day_time) then
						day_count = 0
					end

					obj.count = day_count
				end
			end

			table.insert(arr, obj)
		end

		return arr
	else
		return {}
	end
end

return InfoActvMonster
