local NAV_base = import(".NAV_base")
local NAV_monster = class("NAV_monster", NAV_base)

function NAV_monster.open(npc)
	local ui = NAV_monster.new(npc)

	return ui
end

function NAV_monster:ctor(npc)
	NAV_monster.super.ctor(self, npc, "nav_monster")
end

function NAV_monster:init()
	NAV_monster.super.init(self)

	local index = 1
	local ui = self.buttons[index].ui
	local button = self.buttons[index].button
	local negative_text = self.npc.data.negative_text

	if empty(negative_text) then
		negative_text = Localization.getSrcText("偷袭")
	end

	negative_text = string.gsub(negative_text, "\\n", "\n")

	self:setButtonName(ui, negative_text)
end

function NAV_monster:onTap(index)
	NAV_monster.super.onTap(self, index)

	if index == 1 then
		self.npc:checkBattle(global.player, true)
	end
end

return NAV_monster
