local MiscConfig = {
	akasa_step_level = 5,
	akasa_last_level = 6,
	gem_remind_level = 6,
	sfxTurntable = "sfx_turntable",
	castCD = 30,
	sigilColor = {
		cc.c4b(253, 33, 48, 255),
		cc.c4b(249, 172, 45, 255),
		cc.c4b(8, 153, 254, 255)
	},
	sigilColorName = {
		"红色",
		"黄色",
		"蓝色"
	},
	gwar_effect_heal = "effect:@heal_03;sfx:zhiliao_01",
	chat_less_tower_time = 300,
	chat_less_msg_time = 300,
	union_cache_time = 60,
	default_union_flag_bg = 1000,
	default_union_flag_icon = 2000,
	default_union_color_bg = 1000,
	default_union_color_icon = 2000,
	gc_threhold_time = 0.1,
	create_order_interval = 2,
	ranking_cache_time = 60,
	circle_num = {
		"①",
		"②",
		"③",
		"④",
		"⑤",
		"⑥",
		"⑦",
		"⑧",
		"⑨",
		"⑩"
	},
	effect_dust = "effect_dust_3",
	sfx_area_open = "area_open",
	area_open_bgm = "crystal",
	sneak_effect = "@halo_deep",
	eventset_model = "@halo_2",
	rune_type = 30,
	bard_npc = 10005,
	top_center = cc.c4b(239, 65, 54, 255),
	top_already = cc.c4b(255, 230, 0, 255),
	top_die = cc.c4b(129, 211, 248, 255),
	UP_PERCENT = 0.25,
	guide_move_aura_effect = "groud_arrow",
	guide_move_arrow = "guide_arrow",
	guide_move_aim = "guide_aim",
	bgm_camp = "camp",
	bgm_arena = "battle_elite",
	bgm_td = "battle_elite",
	moonDailyEffect = "delay=50#quake;delay=40#sfx:chest_drop;fall:50,500,inCubic",
	moonDailyGather = 1000,
	buyMaxNum = 100,
	fishing_zoom = 1.25,
	farm_model = "@nongdi",
	sfx_harvest = "harvest",
	GACHA_COST = {
		100200,
		112001,
		112000
	},
	DEFAULT_BLANKET = 400601,
	itemUseStartTime = 1,
	JOB_CLASS_NAME = {
		"战士",
		"弓手",
		"法师"
	},
	FISH_TYPE = {}
}
MiscConfig.FISH_TYPE[1] = "料理鱼"
MiscConfig.FISH_TYPE[2] = "深渊特产鱼"
MiscConfig.MONSTER_CLASS = {
	"普通怪",
	"喽啰",
	[11] = "精英怪",
	[12] = "首领怪"
}
MiscConfig.TD_SIGN_TIME = 300
MiscConfig.TD_SIGN_FIRST_START_TIME = 60
MiscConfig.TD_SIGN_FIRST_INTERVAL_TIME = 300
MiscConfig.EMOJI_TIME = 336
MiscConfig.EMOJI_SCALE = 1.5
MiscConfig.MONSTAR_PATROL_RATIO = 0.5
MiscConfig.BOSS_PATROL_RATIO = 0.6
MiscConfig.afterBattleTalkInterval = "2:2;3:5;4:2"
MiscConfig.THUNDER_SOUND = {
	"thunder_1",
	"thunder_2",
	"thunder_3"
}
MiscConfig.WEATHER_SCALE = 28800
MiscConfig.WEATHERS = {
	{
		ran = 0.7,
		weather = 1
	},
	{
		ran = 0.9,
		weather = 2
	},
	{
		ran = 1,
		weather = 3
	}
}
MiscConfig.HOUR_COLOR = {
	{
		hour = 0,
		star = 255,
		dark = 255,
		color = {
			108,
			134,
			142
		}
	},
	{
		hour = 4,
		star = 200,
		dark = 200,
		color = {
			150,
			160,
			180
		}
	},
	{
		hour = 6,
		star = 0,
		dark = 100,
		color = {
			200,
			190,
			180
		}
	},
	{
		hour = 8,
		star = 0,
		dark = 50,
		color = {
			230,
			230,
			230
		}
	},
	{
		hour = 10,
		star = 0,
		dark = 0,
		color = {
			255,
			255,
			255
		}
	},
	{
		hour = 14,
		star = 0,
		dark = 0,
		color = {
			255,
			255,
			255
		}
	},
	{
		hour = 16,
		star = 0,
		dark = 50,
		color = {
			230,
			230,
			230
		}
	},
	{
		hour = 18,
		star = 0,
		dark = 100,
		color = {
			220,
			200,
			170
		}
	},
	{
		hour = 20,
		star = 0,
		dark = 150,
		color = {
			190,
			180,
			170
		}
	},
	{
		hour = 22,
		star = 200,
		dark = 200,
		color = {
			140,
			150,
			160
		}
	},
	{
		hour = 24,
		star = 255,
		dark = 255,
		color = {
			108,
			134,
			142
		}
	}
}
MiscConfig.MP_BLOCK = 200
MiscConfig.unit_delay_remove = 300
MiscConfig.build_guide_time = 86400
MiscConfig.drop_item_scale = 0.5
MiscConfig.precious_item_scale = 0.75
MiscConfig.precious_item_effect = "@card_quality_4"
MiscConfig.npc_guide_distance = 5
MiscConfig.block_effect = "@hit_block"
MiscConfig.campfire_effect = "@gouhuo"
MiscConfig.sfx_shrine_read = "shrine_read"
MiscConfig.sfx_shrine_active = "shrine_active"
MiscConfig.effect_itemFly = "effect_ef46"
MiscConfig.effect_monsterBattle = "effect_tanhao"
MiscConfig.effect_targetMark = "tap_arrow"
MiscConfig.effect_levelup = "effect:@levelup"
MiscConfig.effect_transfer = "quake:20;effect:@zhuanzhi"
MiscConfig.effect_nextwave_prepare = "fadeto:0,0"
MiscConfig.effect_nextwave_start = "fadeto:30,255"
MiscConfig.dialog_default_emoji = "emoji_dialog"
MiscConfig.battle_arrow = "map_arrow"
MiscConfig.leader_effect = {
	"aura_1001"
}
MiscConfig.shield_effect = "@dmgresis_shield"
MiscConfig.shield_hit_effect = "effect:@dmgresis_shield_hit"
MiscConfig.shield_broken_effect = ""

return MiscConfig
