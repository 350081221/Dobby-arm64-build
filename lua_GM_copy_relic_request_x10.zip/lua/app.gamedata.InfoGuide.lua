local InfoGuide = {}
local rawData = nil

function InfoGuide.init()
	Connection.listen("guide_sync", InfoGuide.sync)
	notify.register("pop_clear", function ()
		Looper.setTimeout(function ()
			if InfoGuide.changed then
				InfoGuide.recover()
			end
		end, 1)
	end)
end

app:addToAppEnterCall(InfoGuide.init)

function InfoGuide.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoGuide.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("guide_query", callback)
end

function InfoGuide.onQuery(rcvData)
	rawData = rcvData
end

function InfoGuide.sync(data)
	local preGuideID = rawData.guide_id

	for k, v in pairs(data) do
		rawData[k] = v
	end

	if preGuideID ~= rawData.guide_id then
		if InfoGuide.getID() == 1010 then
			TaHelper.taGuideDetail(10600)
		elseif InfoGuide.getID() == 1030 then
			TaHelper.taGuideDetail(10700)
		elseif InfoGuide.getID() == 4010 then
			TaHelper.taGuideDetail(13000)
		elseif InfoGuide.getID() == 4020 then
			TaHelper.taGuideDetail(13100)
		elseif InfoGuide.getID() == 4030 then
			TaHelper.taGuideDetail(13500)
		elseif InfoGuide.getID() == 5010 then
			TaHelper.taGuideDetail(13600)
		elseif InfoGuide.getID() == 5020 then
			TaHelper.taGuideDetail(13700)
		elseif InfoGuide.getID() == 5030 then
			TaHelper.taGuideDetail(13800)
		elseif InfoGuide.getID() == 7010 then
			TaHelper.taGuideDetail(14500)
		elseif InfoGuide.getID() == 7030 then
			TaHelper.taGuideDetail(14600)
		elseif InfoGuide.getID() == 7010 then
			TaHelper.taGuideDetail(14500)
		elseif InfoGuide.getID() == 8010 then
			TaHelper.taGuideDetail(14700)
		elseif InfoGuide.getID() == 10010 then
			TaHelper.taGuideDetail(15200)
		elseif InfoGuide.getID() == 10020 then
			TaHelper.taGuideDetail(15300)
		elseif InfoGuide.getID() == 11010 then
			TaHelper.taGuideDetail(15500, true)
		end

		local guideData = CsvParser.getCsvData("guide", rawData.guide_id)

		if CONFIG.is_ta then
			TaHelper.taTrack("guide_complete", {
				guide_step = rawData.guide_id
			})
		end

		if guideData.fin_clear == 1 then
			PopManager.closeAll()
		end

		if not empty(guideData.fin_hint) then
			HintManager.open(guideData.fin_hint)
		end

		local delayDispatch = nil
		local count = 5

		function delayDispatch()
			if count <= 0 then
				Looper.stopLoop(InfoGuide, delayDispatch)
				ManagerInfo.dataChange("main_guide", data)

				if InfoGuide.isFin() then
					notify.dispatch("main_guide_fin")
				end
			else
				count = count - 1
			end
		end

		Looper.startLoop(InfoGuide, delayDispatch)

		if CsvParser.getMaxID("guide") <= rawData.guide_id then
			LuaBridge.call("luaAfCompleteTutorial")
			WingHelper.ghw_self_tutorial_completed()
		end

		LuaBridge.call("luaAfEvent", {
			eventName = "tutorial_completion"
		})
	end

	ManagerInfo.dataChange("guide", data)
end

function InfoGuide.getGuidePetState()
	return rawData.pet_state
end

function InfoGuide.getGuidePetTime()
	if rawData.pet_state == 1 then
		return rawData.pet_time
	end
end

function InfoGuide.getGuidePet(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			local perHatchID = rcvData.id
			local petInfo = InfoPet.getPet(perHatchID)

			POP_pet_born.open(petInfo)

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("guide_pet_get", callback)
end

function InfoGuide.getID()
	return rawData.guide_id
end

function InfoGuide.setID(id)
	rawData.guide_id = id
end

function InfoGuide.getCurrent()
	local preGuideMap = CacheData.get("InfoGuide_preGuideMap")

	if not preGuideMap then
		preGuideMap = {}
		local csvRaw = CsvParser.getCsvRaw("guide")

		for k, v in pairs(csvRaw) do
			preGuideMap[v.pre] = v.id
		end

		CacheData.set("InfoGuide_preGuideMap", preGuideMap)
	end

	return preGuideMap[InfoGuide.getID()]
end

function InfoGuide.getCurrentCSV()
	local currentGuide = InfoGuide.getCurrent()

	if currentGuide then
		local csv = CsvParser.getCsvData("guide", currentGuide)

		return csv
	end
end

function InfoGuide.isFin()
	return CsvParser.getMaxID("guide") <= rawData.guide_id
end

function InfoGuide.isAfter(guide_id)
	return guide_id <= rawData.guide_id
end

function InfoGuide.drama(guideID)
	local guideData = CsvParser.getCsvData("guide", guideID)

	if not empty(guideData.drama) then
		DramaManager.start(guideData.drama, nil, , function ()
			if guideData.fin_type == 1 then
				InfoGuide.finish(guideID, function ()
					notify.dispatch("guide_drama_over")
				end)
			else
				notify.dispatch("guide_drama_over")
			end
		end)
	end
end

function InfoGuide.tryTrigger(...)
	local guideArr = {
		...
	}

	for i, guideID in ipairs(guideArr) do
		local result = InfoGuide.trigger(guideID)

		if result then
			return true
		end
	end

	return false
end

function InfoGuide.trigger(guideID)
	local guideData = CsvParser.getCsvData("guide", guideID)

	if guideData and guideData.pre == rawData.guide_id then
		print("$$$ InfoGuide.start", guideID)
		InfoGuide.drama(guideID)

		return true
	end

	return false
end

function InfoGuide.finish(guideID, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ guide_finish")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("guide_finish", {
		guide_id = guideID
	}, callback)
end

function InfoGuide.recover()
	if LayerConfig.isPopLocked() then
		return
	end

	InfoGuide.changed = false

	if not empty(InfoGuide.currentID) then
		local guideData = CsvParser.getCsvData("guide", InfoGuide.currentID)

		if not empty(guideData.drama) then
			Log.debug("InfoGuide.recover", guideData.drama)

			if guideData.mask == 1 then
				local function onComplete()
					DramaManager.start(guideData.drama)
				end

				POP_mask.open(60, 255, nil, , onComplete)
			else
				DramaManager.start(guideData.drama)
			end

			return true
		end
	end

	return false
end

function InfoGuide.reset()
	InfoGuide.changed = false

	if not empty(InfoGuide.currentID) then
		local guideData = CsvParser.getCsvData("guide", InfoGuide.currentID)

		if not empty(guideData.drama) then
			if guideData.mask == 1 then
				local function onComplete()
					DramaManager.start(guideData.drama, nil, , , , true)
				end

				POP_mask.open(60, 255, nil, , onComplete)
			else
				DramaManager.start(guideData.drama, nil, , , , true)
			end

			return true
		end
	end

	return false
end

function InfoGuide.getFreeRecord(id)
	if not rawData then
		return 1
	end

	local section, position = BitUtil.split(20, id)
	local recordNum = rawData["free_" .. section]

	return BitUtil.getBitByIndex(recordNum, position)
end

function InfoGuide.dramaFree(guideID, onComplete)
	local guideData = CsvParser.getCsvData("guide_free", guideID)

	if not empty(guideData.drama) then
		local succ = DramaManager.start(guideData.drama, nil, , function ()
			if guideData.fin_on_drama == 1 then
				InfoGuide.finishFree(guideID)
			end

			if onComplete then
				onComplete()
			end
		end)

		if succ and guideData.fin_on_drama == 2 then
			InfoGuide.finishFree(guideID)
		end
	end
end

function InfoGuide.tryTriggerFree(...)
	local guideArr = {
		...
	}

	for i, guideID in ipairs(guideArr) do
		local result = InfoGuide.triggerFree(guideID)

		if result then
			return true
		end
	end

	return false
end

function InfoGuide.triggerFree(guideID, force, onComplete)
	if force or InfoGuide.getFreeRecord(guideID) == 0 then
		print("$$$ InfoGuide.startFree", guideID)
		InfoGuide.dramaFree(guideID, onComplete)

		return true
	end

	return false
end

function InfoGuide.finishFree(guideID, onSuccess, onFailure)
	if tostring(guideID) == "4" then
		TaHelper.taGuideDetail(11800)
	elseif tostring(guideID) == "4" then
		TaHelper.taGuideDetail(11800)
	elseif tostring(guideID) == "17" then
		TaHelper.taGuideDetail(14000)
	elseif tostring(guideID) == "13" then
		TaHelper.taGuideDetail(14100)
	elseif tostring(guideID) == "37" then
		TaHelper.taGuideDetail(14200)
	elseif tostring(guideID) == "16" then
		TaHelper.taGuideDetail(14300)
	elseif tostring(guideID) == "19" then
		TaHelper.taGuideDetail(14900)
	elseif tostring(guideID) == "27" then
		TaHelper.taGuideDetail(15000)
	elseif tostring(guideID) == "28" then
		TaHelper.taGuideDetail(15100)
	end

	if InfoGuide.getFreeRecord(guideID) == 0 then
		local function callback(rcvData)
			dump(rcvData, "$$$ guide_free_finish")

			if rcvData.err then
				if onFailure then
					onFailure()
				end
			elseif onSuccess then
				onSuccess()
			end
		end

		Connection.request("guide_free_finish", {
			guide_id = guideID
		}, callback)
	end
end

function InfoGuide.guideFree(guideID, pos, onTrigger, safeView, guideDistance, force)
	local handlerID1, handlerID2 = nil
	guideDistance = guideDistance or MiscConfig.npc_guide_distance

	local function checkGuideFree()
		if global.player and not global.player:isGoDirectionLocked() and not WarMachine.on and pos.x and pos.y then
			local tile = global.player.tile
			local selfTile = global.map:mapToTile(pos.x, pos.y)

			if selfTile and tile then
				local distance = math.sqrt(math.pow(selfTile.x - tile.x, 2) + math.pow(selfTile.y - tile.y, 2))

				if distance <= guideDistance then
					notify.unregister("player_retile", handlerID1)
					notify.unregister("recover_godirection", handlerID2)
					DramaManager.presetUnit(pos)
					InfoGuide.triggerFree(guideID, force)

					if onTrigger then
						onTrigger()
					end
				end
			end
		end
	end

	safeView = safeView or global.player
	handlerID1 = notify.safeRegister(safeView, "player_retile", checkGuideFree)
	handlerID2 = notify.safeRegister(safeView, "recover_godirection", checkGuideFree)

	checkGuideFree()

	return checkGuideFree
end

function InfoGuide.isAbyssNextLocked()
	if not InfoGuide.isFin() then
		local guideCSV = InfoGuide.getCurrentCSV()

		if guideCSV and guideCSV.fin_type == 4 then
			local abyssCSV = InfoDungeon.getDungeonCSV()

			if guideCSV.fin_value <= abyssCSV.layer then
				return true
			end
		end
	end
end

function InfoGuide.isAbyssExitLocked()
	if not InfoGuide.isFin() then
		local abyssCSV = InfoDungeon.getDungeonCSV()

		if abyssCSV.layer < 7 then
			return true
		elseif abyssCSV.layer == 7 then
			return not InfoDungeon.isLayerSafe()
		end
	end
end

function InfoGuide.isAbyssExitGuide()
	if InfoDungeon.getType() == InfoDungeon.TYPE.ABYSS then
		local abyssCSV = InfoDungeon.getDungeonCSV()

		if abyssCSV.layer >= 7 and abyssCSV.entrance == 0 then
			return InfoDungeon.isLayerSafe()
		end
	end
end

function InfoGuide.guideHeroUseItemLock(heroInfo)
	if InfoGuide.isFin() then
		return
	end

	if not InfoGuide.isAfter(8010) and heroInfo.quality < 2 then
		return true
	end
end

function InfoGuide.buildingLvupLock(tag)
	if InfoGuide.isFin() then
		return
	end

	local level = InfoBuilding.getBuildingLevel(tag)
	local csvList = CsvParser.getCsvList("guide", "__line")
	local limitLevel = nil
	local breakID = InfoGuide.getCurrent()

	for i = #csvList, 1, -1 do
		local csv = csvList[i]
		local buildingList = SheetUtil.getColumnList(csv, {
			"building_",
			"building_level_"
		}, {
			"tag",
			"level"
		})

		for j, v in ipairs(buildingList) do
			if v.tag == tag then
				limitLevel = v.level
			end
		end

		if csv.id == breakID then
			break
		end
	end

	if limitLevel and limitLevel <= level then
		return true
	end
end

function InfoGuide.getList()
	local csvList = CsvParser.getCsvList("guide")
	local arr = {}

	for i, csv in ipairs(csvList) do
		if not empty(csv.text_detail) then
			table.insert(arr, csv)
		end
	end

	return arr
end

return InfoGuide
