local InfoBackRecord = {}
local rawData = nil

function InfoBackRecord.init()
	Connection.listen("back_record_sync", InfoBackRecord.sync)
end

app:addToAppEnterCall(InfoBackRecord.init)

function InfoBackRecord.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoBackRecord.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("back_record_query", callback)
end

function InfoBackRecord.onQuery(rcvData)
	dump(rcvData, "back_record_query")

	rawData = {}

	for i = 1, #rcvData.list do
		local data = rcvData.list[i]
		rawData[data.back_id] = data
	end
end

function InfoBackRecord.sync(data)
	for i, syncData in ipairs(data.list) do
		local back_id = syncData.back_id

		if not rawData[back_id] then
			rawData[back_id] = syncData
		else
			for k, v in pairs(syncData) do
				rawData[back_id][k] = v
			end
		end
	end

	notify.dispatch("campaign_changed")
	ManagerInfo.dataChange("back_record")
end

function InfoBackRecord.getReward(back_id, day, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("back_record_get_reward", {
		back_id = back_id,
		day = day
	}, callback)
end

function InfoBackRecord.checkSign(back_id, day)
	local data = rawData[back_id]

	if data then
		return day <= InfoBackRecord.getDays(back_id)
	end

	return false
end

function InfoBackRecord.checkRewarded(back_id, day)
	local data = rawData[back_id]

	if data then
		return BitUtil.getBitByIndex(data.reward_record, day) > 0
	end

	return false
end

function InfoBackRecord.getDays(back_id)
	local nowTime = Time.now()
	local data = rawData[back_id]

	if data then
		local login_time = data.login_time
		local login_days = data.login_days
		local dayPassed = RefreshManager.checkTimePassedDays(RefreshManager.TYPE.BACK_SIGN, nowTime, login_time)

		return login_days + dayPassed
	else
		return 0
	end
end

local recordDayCacheMap = nil

function InfoBackRecord.getList(back_id)
	if not recordDayCacheMap then
		recordDayCacheMap = {}
		local csvList = CsvParser.getCsvList("back_record")

		for i, csv in ipairs(csvList) do
			local base_id_arr = string.split(csv.back_id, ",")

			for j, base_id_str in ipairs(base_id_arr) do
				local base_id = tonumber(base_id_str)

				if base_id then
					if not recordDayCacheMap[base_id] then
						recordDayCacheMap[base_id] = {}
					end

					table.insert(recordDayCacheMap[base_id], csv)
				end
			end
		end
	end

	return recordDayCacheMap[back_id]
end

function InfoBackRecord.countRedot(backData)
	local redotCount = 0
	local csvArr = InfoBackRecord.getList(backData.base_id)

	for day, csv in ipairs(csvArr) do
		local data = rawData[backData.id]

		if data and day <= InfoBackRecord.getDays(backData.id) and not InfoBackRecord.checkRewarded(backData.id, day) then
			redotCount = redotCount + 1
		end
	end

	return redotCount
end

return InfoBackRecord
