local InfoReclaim = {
	init = function ()
	end
}

app:addToAppEnterCall(InfoReclaim.init)

function InfoReclaim.getList(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "reclaim_get_list")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("reclaim_get_list", callback)
end

function InfoReclaim.buy(index, price, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("reclaim_buy", {
		index = index,
		price = price
	}, callback)
end

function InfoReclaim.getPrice(type, info)
	local reclaim_need = CsvParser.getCsvData("config", "reclaim_need").value
	local costNum = 0

	if type == DropManager.TYPE.EQUIP then
		local equipCSV = CsvParser.getCsvData("equip", info.base_id)
		local baseNum = CsvParser.getCsvData("equip_base_num", info.level)
		local agenCSV = CsvParser.getCsvData("affix_gen", info.quality)
		costNum = equipCSV.reclaim_cost * baseNum.reclaim_ratio * agenCSV.quality_reclaim_ratio
	elseif type == DropManager.TYPE.SIGIL then
		local sigilCSV = CsvParser.getCsvData("sigil", info.base_id)
		local baseNum = CsvParser.getCsvData("sigil_base_num", info.level)
		local qualityCSV = CsvParser.getCsvData("sigil_quality", info.quality)
		costNum = sigilCSV.reclaim_cost * baseNum.reclaim_ratio * qualityCSV.reclaim_ratio
	elseif type == DropManager.TYPE.CARD then
		local cardCSV = CsvParser.getCsvData("card", info.base_id)
		costNum = cardCSV.reclaim_cost
	end

	return {
		base_id = reclaim_need,
		num = math.ceil(costNum)
	}
end

return InfoReclaim
