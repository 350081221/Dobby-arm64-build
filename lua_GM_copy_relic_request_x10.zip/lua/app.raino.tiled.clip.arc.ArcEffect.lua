local ArcEffect = class("ArcEffect")

function ArcEffect:ctor(map, center, angle, paramStr, seed)
	event_listener.extendMethods(self)

	seed = seed or math.random(65535)
	self.random = Random.new(seed)
	self.randomSpeed = Random.new(self.random:getInt(1, 65535))
	self.param = ArcParam.new(self, paramStr)
	self.map = map
	self.center = center
	self.baseAngle = angle
	self.centerNode = {
		y = 0,
		z = 0,
		x = 0
	}
	self.pts = {}
end

function ArcEffect:start()
	self.countStarted = 0
	self.allStarted = false
	self.count = 0
	self.frame = 0

	self:trySetOne()
	MapFrameManager.startLoop(self, self.loop)
end

function ArcEffect:trySetOne()
	if not self.allStarted then
		if self.param.startInterval == 0 then
			for i = 1, self.param.amount do
				self:setOne()
			end
		elseif self.count % self.param.startInterval == 0 then
			self:setOne()
		end
	end
end

function ArcEffect:setOne()
	local radius, z = nil

	if self.param.startType == ArcParam.START_FIXED then
		radius = self.param.startRadius
		z = self.param.startZ
	elseif self.param.startType == ArcParam.START_RANDOM_RADIUS then
		radius = self.param.startRadius * self.random:next()
		z = self.param.startZ
	elseif self.param.startType == ArcParam.START_RANDOM then
		radius = self.param.boxMinRadius + (self.param.boxMaxRadius - self.param.boxMinRadius) * self.random:next()
		z = self.param.boxMinZ + (self.param.boxMaxZ - self.param.boxMinZ) * self.random:next()
	end

	local perA, pt = nil

	if self.param.angle == -1 then
		if self.param.startType == ArcParam.START_FIXED then
			perA = math.pi * 2 / self.param.amount
			pt = ArcParticle.new(self, radius, self.countStarted * perA + self.baseAngle, z)
		else
			pt = ArcParticle.new(self, radius, self.random:next() * math.pi * 2, z)
		end

		table.insert(self.pts, pt)
	else
		if self.param.startType == ArcParam.START_FIXED then
			if self.param.amount == 1 then
				perA = 0
			else
				perA = self.param.angle * math.pi / 180 / (self.param.amount - 1)
			end

			pt = ArcParticle.new(self, radius, (self.countStarted - (self.param.amount - 1) / 2) * perA + self.baseAngle, z)
		else
			pt = ArcParticle.new(self, radius, (self.random:next() - 0.5) * self.param.angle * math.pi / 180 + self.baseAngle, z)
		end

		table.insert(self.pts, pt)
	end

	self.countStarted = self.countStarted + 1

	if self.countStarted == self.param.amount then
		self.allStarted = true
	end
end

function ArcEffect:loop(frame, passed, sharp)
	if self.center.x and self.center.y then
		for i = 1, sharp do
			self.frame = self.frame + 1

			self:update()

			if #self.pts == 0 and self.allStarted then
				self:destroy()
			else
				self.count = self.count + 1

				self:trySetOne()
			end
		end
	else
		self:destroy()
	end
end

function ArcEffect:destroy()
	MapFrameManager.stopLoop(self, self.loop)

	for i = 1, #self.pts do
		self.pts[i]:destroy()
	end

	self.pts = {}

	self:dispatchEvent({
		name = "destroy"
	})
end

function ArcEffect:update()
	local i = 1

	for l = 1, #self.pts do
		local destroyed = false

		self.pts[i]:update()

		if not self:checkBox(self.pts[i]) then
			self.pts[i]:reverse()

			if self.param.lifeType == ArcParam.LIFE_BOX then
				self.pts[i].lifeCount = self.pts[i].lifeCount + 1

				if self.param.lifeCount <= self.pts[i].lifeCount then
					destroyed = true
				end
			end
		end

		if not destroyed and self.param.lifeType == ArcParam.LIFE_TIME then
			self.pts[i].lifeCount = self.pts[i].lifeCount + 1

			if self.param.lifeCount <= self.pts[i].lifeCount then
				destroyed = true
			end
		end

		if destroyed then
			self.pts[i]:destroy()
			table.remove(self.pts, i)
		end

		if not destroyed then
			self.pts[i]:draw()

			i = i + 1
		end
	end
end

function ArcEffect:checkBox(particle)
	if particle.radius < self.param.boxMinRadius or self.param.boxMaxRadius < particle.radius or particle.z < self.param.boxMinZ or self.param.boxMaxZ < particle.z then
		return false
	end

	return true
end

return ArcEffect
