local MeteorEffect = class("MeteorEffect")

function MeteorEffect:ctor(map, center, model, height, angle, time, seed)
	event_listener.extendMethods(self)

	seed = seed or math.random(65535)
	self.random = Random.new(seed)
	self.startInfo = {
		map = map,
		center = center,
		model = model,
		height = height or 300,
		angle = -(angle or 0) / 180 * math.pi,
		time = time or 30,
		easing = "inQuad"
	}
end

function MeteorEffect:start()
	self.effect = Effect.new()

	self.effect:load(self.startInfo.model)
	self.effect:display(self.startInfo.map, self.startInfo.center.x, self.startInfo.center.y)

	if self.effect.rotate then
		self.effect:setRotate(self.startInfo.angle + math.pi / 2)
	end

	local width = math.tan(self.startInfo.angle) * self.startInfo.height

	local function onComplete()
		self:destroy()
	end

	local function onUpdate()
		local xoffset = self.effect.z / self.startInfo.height * width
		self.effect.effectOffset = cc.p(xoffset, 0)

		self.effect:setBmpX()
	end

	local effectGen = self.effect:getEffectGen()

	if effectGen then
		effectGen:fall(self.startInfo.time, self.startInfo.height, self.startInfo.easing, onComplete, onUpdate)
	end
end

function MeteorEffect:destroy()
	if self.effect then
		self.effect:removeSelf()
	end
end

return MeteorEffect
