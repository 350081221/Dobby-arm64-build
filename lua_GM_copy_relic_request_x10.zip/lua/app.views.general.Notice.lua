local UI_base = import("..UI_base")
local Notice = class("Notice", UI_base)
local instance = nil

function Notice.open(msg, confirmFunc, cancelFunc, confirmDesc, cancelDesc)
	if not instance then
		instance = Notice.new("com_notice")

		instance:show(msg, confirmFunc, cancelFunc, confirmDesc, cancelDesc)
		display.getRunningScene():addChild(instance, LayerConfig.notice)
	end
end

function Notice.err(msg, confirmFunc)
	if not instance then
		instance = Notice.new("com_err")

		instance:show(msg, confirmFunc)
		display.getRunningScene():addChild(instance, LayerConfig.notice_exit)
	end
end

function Notice.exit()
	if not instance then
		local function onExitClicked(event)
			if app then
				app.exit()
			else
				os.exit()
			end
		end

		instance = Notice.new("com_exit")

		instance:show("", onExitClicked)
		display.getRunningScene():addChild(instance, LayerConfig.notice_exit)
	end
end

function Notice:ctor(uiName)
	Notice.super.ctor(self, uiName)
end

function Notice:show(msg, confirmFunc, cancelFunc, confirmDesc, cancelDesc)
	local mask = self:getComponentByTag("mask")

	mask:toTouchable()
	self:createLabelOnFlag("flag_msg", msg, {
		wrap = true,
		valign = Style.vcenter
	})

	local confirmPB = self:getComponentByTag("confirm_pb")

	if confirmDesc then
		confirmPB:addLabel(confirmDesc)
	end

	confirmPB:toTouchable()
	confirmPB:setTapGroup("button_click")

	local function handleEnterTest()
		self:removeSelf()

		instance = nil

		if confirmFunc ~= nil then
			confirmFunc()
		end
	end

	confirmPB:addTap(handleEnterTest)

	local cancelPB = self:getComponentByTag("cancel_pb")

	if cancelDesc then
		cancelPB:addLabel(cancelDesc)
	end

	local function handleCancel()
		self:removeSelf()

		instance = nil

		if cancelFunc ~= nil then
			cancelFunc()
		end
	end

	if cancelPB then
		cancelPB:toTouchable()
		cancelPB:setTapGroup("button_click")
		cancelPB:addTap(handleCancel)

		if not cancelDesc and app then
			app:setKeyBackCallback(handleCancel)
		end
	end
end

function Notice:onExit()
	instance = nil

	if app then
		app:clearKeyBackCallback()
	end

	Notice.super.onExit(self)
end

return Notice
