local Unit = import("..Unit")
local BoxClip = class("BoxClip", Unit)

function BoxClip:ctor()
	BoxClip.super.ctor(self, "box_clip")

	self.speed = 5
end

function BoxClip:display(map, x, y)
	self:setScale(1 / map.config.scale.unit)
	BoxClip.super.display(self, map, x, y)

	if self.tile then
		self.boxLight = self.tile:getUnitLight()
	else
		self.boxLight = map.config.light.min
	end

	self:clearRefreshVisibleFrame()
	self:refreshVisibleLoop()
end

function BoxClip:changeLayer(layer)
	self:retain()
	self:removeFromParent()
	layer:addChild(self)
	self:release()
	self:retile()
end

function BoxClip:refreshVisible()
	if not self.tile then
		return
	end

	if self.preRefreshFrame == MapFrameManager.getFrame() then
		return
	end

	self.preRefreshFrame = MapFrameManager.getFrame()
	self.targetColor = self.tile:getUnitLight()

	if self.boxLight ~= self.targetColor then
		MapFrameManager.startLoop(self, self.refreshVisibleLoop)
	else
		MapFrameManager.stopLoop(self, self.refreshVisibleLoop)
	end

	return visible
end

function BoxClip:refreshVisibleLoop()
	if math.abs(self.boxLight - self.targetColor) > 0.001 then
		self.boxLight = (self.targetColor - self.boxLight) / 5 + self.boxLight
	else
		self.boxLight = self.targetColor

		MapFrameManager.stopLoop(self, self.refreshVisibleLoop)
	end
end

return BoxClip
