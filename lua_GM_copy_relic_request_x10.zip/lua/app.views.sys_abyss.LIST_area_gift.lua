local List = import("...ui.List")
local LIST_area_gift = class("LIST_area_gift", List)

function LIST_area_gift:ctor(rect)
	LIST_area_gift.super.ctor(self, rect, List.DIRECTION_HORIZONTAL)

	self.isBounc = false

	self:setCellName("cell_area_gift")
	self:setCellSize(cc.size(120, self.touchRect.height))
	self:addEventListener("onTapListIcon", function (event)
		DropManager.popDetail(DropManager.TYPE.ITEM, event.data)
	end)
	self:setTapGroup("list_click")
end

function LIST_area_gift:onCellInit(ui, itemInfo)
	if not ui.slot then
		ui.slot = DropSlot.new(ui:getFlagByTag("flag_slot"), "slot_02")

		ui:addChild(ui.slot, 100)
		ui.slot:setAlwaysShowNumber(true)
	end

	ui.slot:setDrop(DropManager.TYPE.ITEM, itemInfo)
end

return LIST_area_gift
