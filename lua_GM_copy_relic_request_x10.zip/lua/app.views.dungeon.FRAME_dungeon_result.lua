local FRAME_dungeon_result = class("FRAME_dungeon_result", UI_base)
local OPEN_TYPE = {
	EXIT = 1,
	VERSION = 2
}
FRAME_dungeon_result.OPEN_TYPE = OPEN_TYPE
local LIST_TYPE = {
	reward_got = 2,
	reward_resource = 1,
	reward_sell = 4,
	reward_lost = 3
}
FRAME_dungeon_result.LIST_TYPE = LIST_TYPE

function FRAME_dungeon_result.open(rcvData, openType)
	PopManager.closeAll()
	dump(rcvData, "$$$ FRAME_dungeon_result.open")

	if not rcvData.reward_lost then
		rcvData.reward_lost = {}
	end

	local ui = FRAME_dungeon_result.new(rcvData, openType)

	PopManager.open(ui, nil, , , 200)
end

function FRAME_dungeon_result:ctor(rcvData, openType)
	local uiName = "frame_dungeon_result"

	if openType == OPEN_TYPE.VERSION then
		uiName = "frame_dungeon_result_version"
	end

	FRAME_dungeon_result.super.ctor(self, uiName, UIManager.BIG_TYPE.POP)

	self.rcvData = rcvData
	self.openType = openType

	self:init()
end

function FRAME_dungeon_result:init()
	self.noCloseByKey = true

	self:initUI()

	local function getQuality(v)
		if v.type == DropManager.TYPE.ITEM then
			local itemData = CsvParser.getCsvData("item", v.info.base_id)

			return itemData.quality
		elseif v.type == DropManager.TYPE.CARD then
			return InfoCard.getQuality(v.info)
		elseif v.type == DropManager.TYPE.EQUIP then
			return InfoEquip.getQualityExcellent(v.info)
		elseif v.type == DropManager.TYPE.SIGIL then
			return InfoSigil.getQuality(v.info)
		else
			return 0
		end
	end

	local function sortFunc(a, b)
		local qualityA = getQuality(a)
		local qualityB = getQuality(b)

		return qualityB < qualityA
	end

	local items = {}
	local arr = {}

	for i, v in ipairs(self.rcvData.reward_resource) do
		table.insert(arr, {
			type = DropManager.TYPE.ITEM,
			info = {
				base_id = v.id,
				num = v.num
			}
		})
	end

	table.sort(arr, sortFunc)
	table.insert(items, {
		label = Localization.getSrcText("收获资源")
	})
	table.insert(items, {
		type = LIST_TYPE.reward_resource,
		arr = arr
	})

	if self.rcvData.safe == 1 then
		table.insert(items, {
			label = Localization.getSrcText("获得物品")
		})

		local gotArr = {}

		for i, v in ipairs(self.rcvData.reward_got) do
			if v.type == DropManager.TYPE.ITEM then
				table.insert(gotArr, {
					type = DropManager.TYPE.ITEM,
					info = {
						base_id = v.id,
						num = v.num
					}
				})
			else
				local info = InfoBag.getBagItemInfo(v.type, v.id)

				if info then
					table.insert(gotArr, {
						type = v.type,
						info = info
					})
				end
			end
		end

		table.insert(items, {
			type = LIST_TYPE.reward_got,
			arr = gotArr
		})
	else
		if #self.rcvData.reward_got > 0 then
			table.insert(items, {
				label = Localization.getSrcText("获得物品")
			})

			local gotArr = {}

			for i, v in ipairs(self.rcvData.reward_got) do
				if v.type == DropManager.TYPE.ITEM then
					table.insert(gotArr, {
						type = DropManager.TYPE.ITEM,
						info = {
							base_id = v.id,
							num = v.num
						}
					})
				else
					local info = InfoBag.getBagItemInfo(v.type, v.id)

					if info then
						table.insert(gotArr, {
							type = v.type,
							info = info
						})
					end
				end
			end

			table.insert(items, {
				type = LIST_TYPE.reward_got,
				arr = gotArr
			})
		end

		table.insert(items, {
			label = Localization.getSrcText("失去物品"),
			style = {
				color = Style.disableColor
			}
		})

		local lostArr = {}

		for i, v in ipairs(self.rcvData.reward_lost) do
			if v.type == DropManager.TYPE.ITEM then
				table.insert(lostArr, {
					type = DropManager.TYPE.ITEM,
					info = {
						base_id = v.id,
						num = v.num
					}
				})
			else
				local info = InfoBag.getBagItemInfo(v.type, v.id)

				if info then
					table.insert(lostArr, {
						type = v.type,
						info = info
					})
				end
			end
		end

		table.insert(items, {
			type = LIST_TYPE.reward_lost,
			arr = lostArr
		})
	end

	local arr = {}

	for i, v in ipairs(self.rcvData.reward_sell) do
		table.insert(arr, {
			type = DropManager.TYPE.ITEM,
			info = {
				base_id = v.id,
				num = v.num
			}
		})
	end

	table.sort(arr, sortFunc)
	table.insert(items, {
		label = Localization.getSrcText("出售物品")
	})
	table.insert(items, {
		type = LIST_TYPE.reward_sell,
		arr = arr
	})

	local index = 1
	local count = 0

	local function addItemLoop()
		if count <= 0 then
			local item = items[index]

			self.list:addItems({
				item
			})
			self.list:scrollToMax(true)

			if item.label then
				count = 5
			else
				count = math.min(60, #item.arr * 5)
			end

			index = index + 1

			if index > #items then
				self:removeEnterFrame("addItemLoop")
			end
		else
			count = count - 1
		end
	end

	self:addEnterFrame("addItemLoop", addItemLoop)
end

function FRAME_dungeon_result:initUI()
	local mask = self:getComponentByTag("mask")

	mask:toTouchable()
	mask:setOpacity(0)

	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local bg1 = self:getComponentByTag("bg1")
	local title = self:getComponentByTag("title")
	local flag_list = self:getFlagByTag("flag_list")
	local widthOffset = math.max(self:getBigWidth(), display.width) - 960
	local cellWidth = 90
	local moreCols = math.floor(widthOffset / cellWidth)
	moreCols = math.max(0, math.min(2, moreCols))

	if self.openType == OPEN_TYPE.VERSION then
		if moreCols > 0 then
			bg:setSize(bg.originalWidth + cellWidth * moreCols)
			bg:setPos(bg.x - cellWidth * moreCols / 2)
			bg1:setSize(bg1.originalWidth + cellWidth * moreCols)
			bg1:setPos(bg1.x - cellWidth * moreCols / 2)

			flag_list.width = flag_list.originalWidth + cellWidth * moreCols
			flag_list.x = flag_list.x - cellWidth * moreCols / 2
		end
	elseif moreCols > 0 then
		bg:setSize(bg.originalWidth + cellWidth * moreCols)
		bg:setPos(bg.x - cellWidth * moreCols)
		bg1:setSize(bg1.originalWidth + cellWidth * moreCols)
		bg1:setPos(bg1.x - cellWidth * moreCols)
		title:setPositionX(title:getPositionX() - cellWidth * moreCols)

		flag_list.width = flag_list.originalWidth + cellWidth * moreCols
		flag_list.x = flag_list.x - cellWidth * moreCols
	end

	local flag_hero = self:getFlagByTag("flag_hero")

	if flag_hero then
		flag_hero.x = (bg.x - flag_hero.width) / 2
	end

	local confirmPB = self:getComponentByTag("bt_confirm")

	confirmPB:toTouchable()
	confirmPB:setTapGroup("button_click")

	if self.openType == OPEN_TYPE.VERSION then
		confirmPB:addTap(function ()
			PopManager.closeTo(self)
		end)
	else
		confirmPB:addTap(function ()
			InfoDungeon.onLeave(self.rcvData)
		end)
	end

	local function tapListener(ui, data, index, x, y)
		if ui.coms then
			local worldPos = self.list:convertToWorldSpace(cc.p(x, y))

			for i, com in ipairs(ui.coms) do
				local slot = com.slot

				if slot:hitTestByComponent("bg", worldPos.x, worldPos.y, true) then
					UIManager.callTapGroup("slot_click", slot, function ()
						DropManager.popDetail(slot.type, slot.info)
					end)

					break
				end
			end
		end
	end

	self.list = self:createListOnFlag("flag_list", function (rect)
		return LIST_dungeon_result.new(rect, 6 + moreCols)
	end, tapListener)

	if self.openType == OPEN_TYPE.EXIT then
		local heroUI = self:createUIOnFlag("flag_hero", "frame_dungeon_result_hero", 100)
		self.heroUI = heroUI
		self.units = {}
		local angles = {
			0,
			math.pi / 2,
			math.pi / 2 * 3
		}
		local actions = {
			"idle_attack",
			"idle_attack",
			"idle_attack"
		}
		local heroArr = {}
		local totalDmg = 0

		for i = 1, GameConfig.hero_team_num do
			table.insert(heroArr, {
				pos = i,
				info = InfoHero.getHeroByPos(i),
				dmg = self.rcvData["hero_dmg_" .. i]
			})

			totalDmg = totalDmg + self.rcvData["hero_dmg_" .. i]
		end

		table.sort(heroArr, function (a, b)
			if a.dmg == b.dmg then
				return a.pos < b.pos
			else
				return b.dmg < a.dmg
			end
		end)

		for i, v in ipairs(heroArr) do
			local heroInfo = v.info
			local dmg = v.dmg
			local label_dmg = heroUI:getComponentByTag("label_dmg_" .. i)
			local dmgLabel = nil

			if totalDmg > 0 then
				dmgLabel = heroUI:replaceLabelOnFlag("flag_dmg_" .. i, nil, math.round(dmg / totalDmg * 100))
			else
				dmgLabel = heroUI:replaceLabelOnFlag("flag_dmg_" .. i, nil, 0)
			end

			local tile = heroUI:getComponentByTag("tile_" .. i)

			tile:setOpacity(200)

			local unit = Hero.new()
			unit.angle = angles[i]

			unit:setInfo(heroInfo)
			unit:setScale(2)
			unit:selfUpdate()

			local flag = heroUI:getFlagByTag("flag_hero_" .. i)

			unit:setPosition(flag.x + flag.width / 2, flag.y + flag.height / 2 + 50)

			local shadow = display.newSprite("#map_assets_shadow")

			shadow:setScale(0.5)
			unit:addChild(shadow, -100)
			heroUI:addChild(unit, 1000)

			local action = actions[i]

			if action == "idle_attack" then
				unit:setAction(unit.battleIdleAction)
			else
				unit:setAction(action)
			end

			self.units[i] = unit
			local delay = (#heroArr - i + 1) * 0.25

			transition.moveTo(tile, {
				time = 0.2,
				easing = "backOut",
				delay = delay,
				y = tile:getPositionY() - 20
			})
			transition.moveTo(label_dmg, {
				time = 0.2,
				easing = "backOut",
				delay = delay,
				y = label_dmg:getPositionY() - 20
			})
			transition.moveTo(dmgLabel, {
				time = 0.2,
				easing = "backOut",
				delay = delay,
				y = dmgLabel:getPositionY() - 20
			})
			tile:setOpacity(0)
			label_dmg:setOpacity(0)
			dmgLabel:setOpacity(0)
			transition.fadeTo(tile, {
				easing = "linear",
				time = 0.2,
				opacity = 200,
				delay = delay
			})
			transition.fadeTo(label_dmg, {
				easing = "linear",
				time = 0.2,
				opacity = 255,
				delay = delay
			})
			transition.fadeTo(dmgLabel, {
				easing = "linear",
				time = 0.2,
				opacity = 255,
				delay = delay
			})
			transition.moveTo(unit, {
				time = 0.2,
				easing = "backOut",
				delay = delay - 0.05,
				y = flag.y + flag.height / 2 - 20
			})
			unit:setVisible(false)
			tile:performWithDelay(function ()
				unit:setVisible(true)
			end, delay - 0.05)
		end
	end
end

return FRAME_dungeon_result
