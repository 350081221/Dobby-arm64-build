local InfoLikes = {}
local rawData = nil

function InfoLikes.init()
	Connection.listen("likes_sync", InfoLikes.sync)
end

app:addToAppEnterCall(InfoLikes.init)

function InfoLikes.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			InfoLikes.onQuery(rcvData)

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("likes_query", callback)
end

function InfoLikes.onQuery(rcvData)
	rawData = rcvData
end

function InfoLikes.harvest(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("likes_harvest", callback)
end

function InfoLikes.dailyReward(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("likes_daily_reward", callback)
end

function InfoLikes.sync(data)
	for k, v in pairs(data) do
		rawData[k] = v
	end

	ManagerInfo.dataChange("likes", data)
end

function InfoLikes.countLikes()
	return rawData.likes
end

function InfoLikes.countLikesOffline()
	return rawData.likes_offline
end

function InfoLikes.countRedot()
	local redotCount = 0
	local likeCount, rewardCount = InfoLikes.likesDaily()
	local daily_reward_list = CsvParser.getCsvList("likes_daily_reward")

	if rewardCount > #daily_reward_list - 1 then
		-- Nothing
	else
		local daily_reward = daily_reward_list[rewardCount + 1]

		if likeCount >= daily_reward.count then
			redotCount = 1
		end
	end

	return redotCount
end

function InfoLikes.likesDaily()
	local likeCount = rawData.like_count

	if RefreshManager.checkTimePassed(RefreshManager.TYPE.LIKES_DAILY, Time.now(), rawData.like_time) then
		likeCount = 0
	end

	local rewardCount = rawData.daily_reward_count

	if RefreshManager.checkTimePassed(RefreshManager.TYPE.LIKES_DAILY, Time.now(), rawData.daily_reward_time) then
		rewardCount = 0
	end

	local daily_reward = CsvParser.getCsvData("likes_daily_reward", 1)
	local maxCount = daily_reward.count

	return likeCount, rewardCount, maxCount
end

return InfoLikes
