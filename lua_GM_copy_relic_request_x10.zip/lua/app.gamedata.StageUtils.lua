local StageUtils = {}
local heroData = {}
local petData = {}
local petIndex = 1

function StageUtils.getFixedHero()
	return heroData
end

function StageUtils.getFixedPet()
	return petData
end

function StageUtils.getFixedIndex()
	return petIndex
end

function StageUtils.setFixedIndex(index)
	petIndex = index
end

function StageUtils.initFixed(fixed_team, seed)
	petIndex = 1
	local teamCSV = CsvParser.getCsvData("stage_team", fixed_team)
	local random = Random.new(seed or math.random(1, 65535))
	heroData = {}
	petData = {}

	for i = 1, 3 do
		local temp_id = teamCSV["hero" .. i .. "_id"]
		local level = teamCSV["hero" .. i .. "_level"]
		local quality = teamCSV["hero" .. i .. "_quality"]

		if not empty(temp_id) then
			local templeteData = CsvParser.getCsvData("hero_templete", temp_id)
			local heroInfo = {
				templeteID = temp_id,
				id = i,
				name = SheetUtil.getString(templeteData.name, random),
				base_id = SheetUtil.getString(templeteData.base_id, random),
				gender = SheetUtil.getString(templeteData.gender, random),
				body = SheetUtil.getString(templeteData.body, random),
				hair = SheetUtil.getString(templeteData.hair, random),
				affix = SheetUtil.getString(templeteData.affix, random),
				seed = random:getInt(1, 65535),
				exp = 0,
				quality = quality,
				level = level,
				auto_skill = 1
			}

			for j, attr in ipairs(CombatAttr.attrs) do
				heroInfo[attr .. "_seed"] = random:getInt(1, 65535)
			end

			local skillArr = {}

			if not empty(templeteData.skill_choice) then
				local arr = string.split(templeteData.skill_choice, ",")

				for j, v in ipairs(arr) do
					table.insert(skillArr, tonumber(v))
				end
			end

			for j = 1, 5 do
				heroInfo["skill_enc_" .. i] = skillArr[j] or 1
			end

			heroInfo.equips = {}

			for j = 1, 4 do
				local equipStr = SheetUtil.getString(teamCSV["hero" .. i .. "_equip" .. j], random)

				if not empty(equipStr) then
					local equipArr = string.split(equipStr, ",")
					local equipStack = {}

					if not empty(equipArr[1]) and equipArr[1] ~= "0" then
						local isolated_random = Random.new(math.random(1, 65535))
						local equipStack = DropManager.dropLibLocal(equipArr[1], tonumber(equipArr[2]), 0, random, isolated_random)
						local equipInfo = equipStack[1]

						if equipInfo then
							equipInfo.enhance_level = tonumber(equipArr[3])

							for i = 1, equipInfo.slot do
								if not empty(equipArr[4]) and equipArr[4] ~= "0" then
									local gemID = tonumber(equipArr[4])

									if gemID and gemID ~= 0 then
										equipInfo["gem" .. i] = gemID
									end
								end
							end

							heroInfo.equips[equipInfo.equip_pos] = equipInfo
						end
					end
				end
			end

			heroInfo.cards = {}

			for j = 1, 1 do
				local cardStr = SheetUtil.getString(teamCSV["hero" .. i .. "_card" .. j], random)

				if not empty(cardStr) then
					local cardArr = string.split(cardStr, ",")

					if not empty(cardArr[1]) and cardArr[1] ~= "0" then
						local isolated_random = Random.new(math.random(1, 65535))
						local cardStack = DropManager.dropLibLocal(cardArr[1], 1, 0, random, isolated_random)
						local cardInfo = cardStack[1]

						if cardInfo then
							cardInfo.level = tonumber(cardArr[2])
							cardInfo.star = tonumber(cardArr[3])
							cardInfo.level_limit = InfoCard.getLimitByLevel(cardInfo)
							cardInfo.pos = 1

							table.insert(heroInfo.cards, cardInfo)
						end
					end
				end
			end

			dump(heroInfo, "$$$ heroInfo")

			heroInfo.pos = #heroData + 1

			table.insert(heroData, heroInfo)
		end
	end

	local petLevelTotal = 0
	local petCount = 0

	for i = 1, 3 do
		local pet_id = teamCSV["pet" .. i]
		local pet_level = teamCSV["pet" .. i .. "_level"]
		local pet_quality = teamCSV["pet" .. i .. "_quality"]

		if not empty(pet_id) then
			local pet_csv = CsvParser.getCsvData("pet", pet_id)
			petLevelTotal = petLevelTotal + pet_level
			petCount = petCount + 1
			local petInfo = {
				exp = 0,
				id = i,
				base_id = pet_id,
				quality = pet_quality,
				level = pet_level,
				seed = random:getInt(1, 65535)
			}

			for j, attr in ipairs(CombatAttr.attrs) do
				petInfo[attr .. "_seed"] = random:getInt(1, 65535)
			end

			petInfo.equips = {}

			for j = 1, 4 do
				local equipID = teamCSV["pet" .. i .. "_equip" .. j]

				if not empty(equipID) then
					local petEquipCSV = CsvParser.getCsvData("pet_equip", equipID)
					petInfo["equip_" .. j] = equipID
				end
			end

			table.insert(petData, petInfo)
		end
	end
end

return StageUtils
