local POP_confirm = class("POP_confirm", UI_base)
local BUTTON_STYLE = {
	BLUE = 1,
	RED = 3,
	GREEN = 2
}
POP_confirm.BUTTON_STYLE = BUTTON_STYLE

function POP_confirm.open(msg, confirmFunc, confirmDesc, confirmButtonStyle, style)
	local ui = POP_confirm.new("pop_confirm", msg, confirmFunc, confirmDesc, confirmButtonStyle, style)

	display.getRunningScene():addChild(ui, LayerConfig.notice)
end

function POP_confirm.openBig(msg, confirmFunc, confirmDesc, confirmButtonStyle, style)
	local ui = POP_confirm.new("pop_confirm_big", msg, confirmFunc, confirmDesc, confirmButtonStyle, style)

	display.getRunningScene():addChild(ui, LayerConfig.notice)
end

function POP_confirm:ctor(uiName, msg, confirmFunc, confirmDesc, confirmButtonStyle, style)
	POP_confirm.super.ctor(self, uiName or "pop_confirm")

	self.msg = msg
	self.confirmFunc = confirmFunc
	self.confirmDesc = confirmDesc
	self.confirmButtonStyle = confirmButtonStyle
	self.style = style

	self:init()
end

function POP_confirm:init()
	self:initUI()
end

function POP_confirm:initUI()
	local mask = self:getComponentByTag("mask")

	mask:toTouchable()

	local style = {
		wrap = true,
		align = Style.center,
		valign = Style.vcenter
	}

	if self.style then
		for k, v in pairs(self.style) do
			style[k] = v
		end
	end

	self:createUbbOnFlag("flag_msg", self.msg, style)

	local confirmPB = self:getComponentByTag("confirm_pb")

	if self.confirmDesc then
		confirmPB:addLabel(self.confirmDesc)
	end

	confirmPB:toTouchable()

	local function handleConfirm()
		local confirmFunc = self.confirmFunc

		self:removeSelf()

		if confirmFunc ~= nil then
			confirmFunc()
		end
	end

	confirmPB:addTap(handleConfirm)
	confirmPB:setTapGroup("button_click")
end

return POP_confirm
