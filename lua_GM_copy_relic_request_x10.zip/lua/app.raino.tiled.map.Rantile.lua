local Rantile = class("Rantile")
local zlib = require("zlib")
local MAP_TYPE = {
	CHEST = "chest",
	SHRINE = "shrine",
	EQUIP_SAVE = "eqsave",
	EQUIP_SHOP = "eqshop",
	ENEGY = "enegy",
	GLADIATOR = "gla",
	MINE = "mine",
	EXIT = "exit",
	ENTER = "enter",
	HOME = "home",
	GATE = "gate",
	SHADOW_MCT = "merchant",
	DUST_MCT = "merchant",
	EQUIP_EX = "eqex",
	ASAKA_MCT = "merchant",
	LIFE = "life",
	RUNE = "rune",
	DELIVER = "deliver"
}
Rantile.MAP_TYPE = MAP_TYPE
local cache = {}

function Rantile.clearOnScene()
	local removeArr = {}
	local now = Time.time()

	for k, v in pairs(cache) do
		if not v.time or Time.SECONDS_PER_MIN < now - v.time then
			table.insert(removeArr, k)
		end
	end

	dump(removeArr, "$$$ Rantile.clearOnScene")

	for i, k in ipairs(removeArr) do
		cache[k] = nil
	end
end

function Rantile.makeFix(mapName)
	local fixtileName = string.sub(mapName, 2)
	local data = JsonParser.parse("res/fixtile/" .. fixtileName .. ".json")
	local now = Time.time()
	local cacheKey = "fixtile_" .. fixtileName

	if not cache[cacheKey] then
		if data.count == 1 then
			local jsonStr = JsonParser.getJsonStr("res/map/" .. data.root.name .. "/data.json", true)
			local mapObj = JsonParser.parseStr(jsonStr, true)
			local eventDataArr = mapObj.eventData

			for i, eventData in ipairs(eventDataArr) do
				eventData.abyssEventID = data.root.abyssEventID
			end

			local newStr = json.encode(mapObj)
			cache[cacheKey] = {
				isSingle = true,
				json = newStr,
				topMap = {},
				topTileMap = {},
				time = now
			}
		else
			local rantile = Rantile.new()
			local jsonStr, topMap, topTileMap = rantile:combine(data.root, data)
			cache[cacheKey] = {
				json = jsonStr,
				topMap = topMap,
				topTileMap = topTileMap,
				time = now
			}
		end
	end

	cache[cacheKey].time = now

	return cache[cacheKey].json, cache[cacheKey].topMap, cache[cacheKey].topTileMap, cache[cacheKey].isSingle
end

function Rantile.make(mapName, seed, code)
	local rantileName = string.sub(mapName, 2)
	local summary = JsonParser.parse("res/rantile/" .. rantileName .. "/summary.json")
	local amount = summary.amount
	local random = Random.new(seed)
	local index = random:getInt(1, amount)
	local now = Time.time()
	local cacheKey = "rantile_" .. rantileName .. "_" .. index

	if not cache[cacheKey] then
		print("$$$ Rantile.make", mapName, code)

		local maps = JsonParser.parse("res/rantile/" .. rantileName .. "/maps.json", true)
		local info = maps[index]
		local rantile = Rantile.new()

		print("$$$ Rantile.make 1")

		local jsonStr, topMap, topTileMap = rantile:combine(info.root, summary)

		print("$$$ Rantile.make 2")

		cache[cacheKey] = {
			json = jsonStr,
			topMap = topMap,
			topTileMap = topTileMap,
			time = now
		}
	end

	cache[cacheKey].time = now

	return cache[cacheKey].json, cache[cacheKey].topMap, cache[cacheKey].topTileMap
end

function Rantile:ctor()
end

function Rantile:combine(info, summary)
	return self:combineMapTree(info, summary)
end

function Rantile:combineMapTree(info, summary)
	self._mapIndex = 0
	self._mapLinkMap = {}
	self._mapLinkEventMap = {}
	self._depthCache = {}
	self.tileCanvas = {}
	self.tileMapAll = {}
	self.tileMapExist = {}
	self.objCanvas = {}
	self.tilespCanvas = {}
	self.objspCanvas = {}
	self.objMapAll = {}
	self.objMapExist = {}
	self.borderAll = {}
	self.eventDataAll = {}
	self.eventDataLinkAll = {}
	self.topMatrix = {}
	self.topMap = {}
	self.topMapIndex = 1
	self.topTileMap = {}

	self:addMap(info)

	return self:mergeMap(info, summary)
end

function Rantile:mergeMap(info, summary)
	print("$$$ mergeMap 1")

	local minX, minY, maxX, maxY = nil

	for tag, tileIndex in pairs(self.tileCanvas) do
		local tagArr = string.split(tag, "_")
		local x = tonumber(tagArr[1])
		local y = tonumber(tagArr[2])

		if not minX or x < minX then
			minX = x
		end

		if not minY or y < minY then
			minY = y
		end

		if not maxX or maxX < x then
			maxX = x
		end

		if not maxY or maxY < y then
			maxY = y
		end
	end

	print("$$$ mergeMap 2")

	local rootObj = JsonParser.parse("res/map/" .. info.name .. "/data.json", true)
	local rootData = rootObj.mapData
	local angle = math.atan2(display.width, display.height)
	local extendDistance = math.cos(math.pi / 2 - angle) * display.height
	extendDistance = math.ceil(extendDistance / rootData.ptPerTile)
	minX = minX - extendDistance
	minY = minY - extendDistance
	maxX = maxX + extendDistance
	maxY = maxY + extendDistance

	print("$$$ mergeMap 3")

	local samplingTiles = nil

	if not empty(summary.sampling) then
		local samplingMapJson = JsonParser.parse("res/map/" .. summary.sampling .. "/data.json", true)

		if samplingMapJson then
			samplingTiles = {}
			local samplingMapData = samplingMapJson.mapData
			local tileMapMapping = {}

			for i, v in ipairs(samplingMapData.tileMap) do
				local hash = crypto.md5(json.encode(v))

				if not self.tileMapExist[hash] then
					table.insert(self.tileMapAll, v)

					self.tileMapExist[hash] = #self.tileMapAll
				end

				tileMapMapping[i] = self.tileMapExist[hash]
			end

			local objMapMapping = {}

			for i, v in ipairs(samplingMapData.objMap) do
				local hash = crypto.md5(json.encode(v))

				if not self.objMapExist[hash] then
					table.insert(self.objMapAll, v)

					self.objMapExist[hash] = #self.objMapAll
				end

				objMapMapping[i] = self.objMapExist[hash]
			end

			local tileStackArr = string.split(samplingMapData.tileStack, ",")
			local objStackArr = string.split(samplingMapData.objStack, ",")
			local tilespStackArr = string.split(samplingMapData.tileSpStack, ",")
			local objspStackArr = string.split(samplingMapData.objSpStack, ",")

			for i = 1, samplingMapData.tileW * samplingMapData.tileH do
				table.insert(samplingTiles, {
					tile = tileMapMapping[tonumber(tileStackArr[i])],
					obj = objMapMapping[tonumber(objStackArr[i])],
					tilesp = objMapMapping[tonumber(tilespStackArr[i])],
					objsp = objMapMapping[tonumber(objspStackArr[i])]
				})
			end
		end
	end

	print("$$$ mergeMap 4")

	local newTileW = maxX - minX + 1
	local newTileH = maxY - minY + 1
	local mapData = {
		tileMap = self.tileMapAll,
		objMap = self.objMapAll,
		tileW = newTileW,
		tileH = newTileH,
		solidW = newTileW,
		solidH = newTileH
	}
	local tileStackBuf = {}
	local objStackBuf = {}
	local tileSpStackBuf = {}
	local objSpStackBuf = {}

	print("$$$ mergeMap 5", newTileW, newTileH)

	local newTopTileMap = {}

	for i = 1, newTileW do
		for j = 1, newTileH do
			local tileTag = i + minX - 1 .. "_" .. j + minY - 1
			local tileIndex, objIndex, objspIndex, tilespIndex = nil

			if self.tileCanvas[tileTag] == nil and samplingTiles then
				local sampling = samplingTiles[math.random(1, #samplingTiles)]
				tileIndex = sampling.tile or 0
				objIndex = sampling.obj or 0
				objspIndex = sampling.objsp or 0
				tilespIndex = sampling.tilesp or 0
			else
				tileIndex = self.tileCanvas[tileTag] or 0
				objIndex = self.objCanvas[tileTag] or 0
				tilespIndex = self.tilespCanvas[tileTag] or 0
				objspIndex = self.objspCanvas[tileTag] or 0
			end

			if i > 1 or j > 1 then
				table.insert(tileStackBuf, ",")
				table.insert(objStackBuf, ",")
				table.insert(tileSpStackBuf, ",")
				table.insert(objSpStackBuf, ",")
			end

			table.insert(tileStackBuf, tileIndex)
			table.insert(objStackBuf, objIndex)
			table.insert(tileSpStackBuf, tilespIndex)
			table.insert(objSpStackBuf, objspIndex)

			newTopTileMap[i .. "_" .. j] = self.topTileMap[tileTag]
		end
	end

	mapData.tileStack = table.concat(tileStackBuf)
	mapData.objStack = table.concat(objStackBuf)
	mapData.tileSpStack = table.concat(tileSpStackBuf)
	mapData.objSpStack = table.concat(objSpStackBuf)

	print("$$$ mergeMap 6")

	local eventMaxDepth = 0

	for i, eventData in ipairs(self.eventDataAll) do
		eventData.x = eventData.x - (minX - 1)
		eventData.y = eventData.y - (minY - 1)
		eventData.ox = eventData.ox - (minX - 1)
		eventData.oy = eventData.oy - (minY - 1)
		eventData.xOffset = eventData.xOffset - (minX - 1)
		eventData.yOffset = eventData.yOffset - (minY - 1)
		local depth, enterEvent = self:getEventDepth(eventData.mapIndex)
		eventData.depth = depth

		if enterEvent then
			eventData.enterEvent = {
				x = enterEvent.x + eventData.xOffset,
				y = enterEvent.y + eventData.yOffset,
				w = enterEvent.w,
				h = enterEvent.h
			}
		end

		eventData.mapIndex = nil
		eventMaxDepth = math.max(eventMaxDepth, eventData.depth)
	end

	print("$$$ mergeMap 7")

	local newEventDataLinkAll = {}

	for tag, v in pairs(self.eventDataLinkAll) do
		v = clone(v)
		local tagArr = string.split(tag, "_")

		for i, vv in ipairs(tagArr) do
			if i % 2 == 1 then
				tagArr[i] = tonumber(vv) - (minX - 1)
			else
				tagArr[i] = tonumber(vv) - (minY - 1)
			end
		end

		local newTag = table.concat(tagArr, "_")

		for i, vv in ipairs(v.nodes) do
			vv.x = vv.x - (minX - 1)
			vv.y = vv.y - (minY - 1)
		end

		newEventDataLinkAll[newTag] = v
	end

	self.eventDataLinkAll = newEventDataLinkAll

	print("$$$ mergeMap 8")

	local borderKeys = {
		"x",
		"y",
		"x1",
		"y1",
		"x2",
		"y2"
	}
	local borderOffset = {
		minX - 1,
		minY - 1,
		minX - 1,
		minY - 1,
		minX - 1,
		minY - 1
	}
	local newBorder = {}

	for i, v in ipairs(self.borderAll) do
		for i, vv in ipairs(borderKeys) do
			if v[vv] then
				v[vv] = v[vv] - borderOffset[i]
			end
		end

		newBorder[tostring(i)] = v
	end

	self.borderAll = newBorder

	print("$$$ mergeMap 9")

	mapData.bgs = rootData.bgs
	mapData.border = self.borderAll
	mapData.name = rootData.name
	mapData.texture = rootData.texture
	mapData.topType = rootData.topType
	mapData.tileType = rootData.tileType
	mapData.ptPerTile = rootData.ptPerTile
	mapData.name = summary.setup.name
	local mapObj = {
		mapData = mapData,
		setup = summary.setup,
		eventData = self.eventDataAll,
		eventLinkData = self.eventDataLinkAll,
		maxDepth = eventMaxDepth
	}

	print("$$$ mergeMap 10")

	for k, v in pairs(self.topMap) do
		v.xOffset = v.xOffset - (minX - 1)
		v.yOffset = v.yOffset - (minY - 1)
		local code = math.floor(tonumber(k)) - 1
		local depth, enterEvent = self:getEventDepth(code)
		v.entrance = enterEvent
		v.depth = depth
	end

	print("$$$ mergeMap 11")

	return json.encode(mapObj), self.topMap, newTopTileMap
end

function Rantile:moveTop(topInfo, wallX, wallY)
	local offX = 0
	local offY = 0
	local lineX, lineY = nil
	local oriX = topInfo.x
	local oriY = topInfo.y

	if topInfo.x == wallX then
		lineY = topInfo.y

		if wallY < topInfo.y then
			offY = 1
		else
			offY = -1
		end
	elseif topInfo.y == wallY then
		lineX = topInfo.x
		offX = wallX < topInfo.x and 1 or -1
	end

	if offX ~= 0 or offY ~= 0 then
		local newTopMap = {}

		for code, info in pairs(self.topMatrix) do
			local needMove = false
			local needOther = false

			if lineX then
				if (info.x - lineX) * offX >= 0 then
					if info ~= topInfo and info.x == oriX then
						needOther = true
					end

					needMove = true
				end
			elseif lineY and (info.y - lineY) * offY >= 0 then
				if info ~= topInfo and info.y == oriY then
					needOther = true
				end

				needMove = true
			end

			if needMove then
				if needOther then
					info.others = info.others or {}

					table.insert(info.others, {
						x = info.x,
						y = info.y
					})
				end

				self.topMatrix[code] = nil
				info.x = info.x + offX
				info.y = info.y + offY
				local newCode = info.x .. "_" .. info.y
				newTopMap[newCode] = info
			end
		end

		for k, v in pairs(newTopMap) do
			self.topMatrix[k] = v
		end
	end

	return offX, offY
end

function Rantile:addMap(info, xOffset, yOffset, topX, topY, prePlugLink, currPlugCode, parentIndex, plugEvent, preTopX, preTopY)
	parentIndex = parentIndex or -1
	local mapIndex = self._mapIndex
	self._mapLinkMap[mapIndex] = {}

	if parentIndex >= 0 then
		table.insert(self._mapLinkMap[mapIndex], parentIndex)

		self._mapLinkEventMap[parentIndex .. "_" .. mapIndex] = plugEvent
	end

	xOffset = xOffset or 0
	yOffset = yOffset or 0
	topX = topX or 0
	topY = topY or 0
	local mapObj = JsonParser.parse("res/map/" .. info.name .. "/data.json", true)
	local mapData = mapObj.mapData
	local linkMap = {}
	local eventLinkData = mapObj.eventLinkData

	for tag, v in pairs(eventLinkData) do
		for i = 1, 2 do
			local node = v.nodes[i]
			local otherNode = v.nodes[3 - i]

			if linkMap[node.x .. "_" .. node.y] == nil then
				linkMap[node.x .. "_" .. node.y] = {}
			end

			table.insert(linkMap[node.x .. "_" .. node.y], otherNode)
		end

		local tagArr = string.split(tag, "_")

		for i, vv in ipairs(tagArr) do
			if i % 2 == 1 then
				tagArr[i] = tonumber(vv) + xOffset
			else
				tagArr[i] = tonumber(vv) + yOffset
			end
		end

		local newTag = table.concat(tagArr, "_")
		local newEventLinkData = clone(v)

		for i, vv in ipairs(newEventLinkData.nodes) do
			vv.x = vv.x + xOffset
			vv.y = vv.y + yOffset
		end

		self.eventDataLinkAll[newTag] = newEventLinkData
	end

	local eventData = mapObj.eventData
	local plugLinks = {}
	local mapType = nil

	for i, v in ipairs(eventData) do
		local code = v.x .. "_" .. v.y

		if v.tag == "plug" then
			if linkMap[code] then
				for i1, v1 in ipairs(linkMap[code]) do
					table.insert(plugLinks, {
						x = v1.x + xOffset,
						y = v1.y + yOffset,
						code = v.x .. "_" .. v.y
					})
				end

				if prePlugLink then
					for i1, v1 in ipairs(plugLinks) do
						if v1.code == currPlugCode then
							local obj = {
								nodes = {}
							}

							table.insert(obj.nodes, v1)
							table.insert(obj.nodes, prePlugLink)

							self.eventDataLinkAll[v1.x .. "_" .. v1.y .. "_" .. prePlugLink.x .. "_" .. prePlugLink.y] = obj
						end
					end
				end
			end
		elseif v.tag == "enter" then
			mapType = MAP_TYPE.ENTER
			self._enterMapIndex = mapIndex
		elseif v.tag == "exit" or v.tag == "go_next" or v.tag == "go_map" then
			mapType = MAP_TYPE.EXIT
		end
	end

	for i, v in ipairs(eventData) do
		local newEventData = clone(v)
		newEventData.x = newEventData.x + xOffset
		newEventData.y = newEventData.y + yOffset
		newEventData.ox = newEventData.ox + xOffset
		newEventData.oy = newEventData.oy + yOffset
		newEventData.xOffset = xOffset
		newEventData.yOffset = yOffset
		newEventData.mapIndex = mapIndex
		newEventData.abyssEventID = info.abyssEventID

		table.insert(self.eventDataAll, newEventData)
	end

	local plugMap = self:getPlugMapFromMap(mapObj)
	local topLink = ""

	for i = 1, 4 do
		if plugMap[i - 1] then
			topLink = topLink .. "1"
		else
			topLink = topLink .. "0"
		end
	end

	local topCode = topX .. "_" .. topY
	local preTopCode = ""
	local preTop = nil

	if preTopX and preTopY then
		preTopCode = preTopX .. "_" .. preTopY
		preTop = self.topMatrix[preTopCode]
	end

	local topObj = {
		x = topX,
		y = topY,
		link = topLink,
		type = mapType,
		parent = preTop,
		children = {},
		index = self.topMapIndex,
		xOffset = xOffset,
		yOffset = yOffset
	}
	local topIndex = tostring(self.topMapIndex)
	self.topMapIndex = self.topMapIndex + 1
	self.topMatrix[topCode] = topObj
	self.topMap[topIndex] = topObj

	if preTop then
		table.insert(preTop.children, topObj)
	end

	local tileMapMapping = {}

	for i, v in ipairs(mapData.tileMap) do
		local hash = crypto.md5(json.encode(v))

		if not self.tileMapExist[hash] then
			table.insert(self.tileMapAll, v)

			self.tileMapExist[hash] = #self.tileMapAll
		end

		tileMapMapping[i] = self.tileMapExist[hash]
	end

	local objMapMapping = {}

	for i, v in ipairs(mapData.objMap) do
		local hash = crypto.md5(json.encode(v))

		if not self.objMapExist[hash] then
			table.insert(self.objMapAll, v)

			self.objMapExist[hash] = #self.objMapAll
		end

		objMapMapping[i] = self.objMapExist[hash]
	end

	local tileStackArr = string.split(mapData.tileStack, ",")
	local objStackArr = string.split(mapData.objStack, ",")
	local tilespStackArr = string.split(mapData.tileSpStack, ",")
	local objspStackArr = string.split(mapData.objSpStack, ",")

	for i = 1, mapData.tileW do
		for j = 1, mapData.tileH do
			local localIndex = tonumber(tileStackArr[(i - 1) * mapData.tileH + j])
			self.tileCanvas[i + xOffset .. "_" .. j + yOffset] = tileMapMapping[localIndex] or 0
			local localIndex = tonumber(objStackArr[(i - 1) * mapData.tileH + j])
			self.objCanvas[i + xOffset .. "_" .. j + yOffset] = objMapMapping[localIndex] or 0
			local localIndex = tonumber(tilespStackArr[(i - 1) * mapData.tileH + j])
			self.tilespCanvas[i + xOffset .. "_" .. j + yOffset] = objMapMapping[localIndex] or 0
			local localIndex = tonumber(objspStackArr[(i - 1) * mapData.tileH + j])
			self.objspCanvas[i + xOffset .. "_" .. j + yOffset] = objMapMapping[localIndex] or 0
			self.topTileMap[i + xOffset .. "_" .. j + yOffset] = topIndex
		end
	end

	local border = mapData.border
	local borderKeys = {
		"x",
		"y",
		"x1",
		"y1",
		"x2",
		"y2"
	}
	local borderOffset = {
		xOffset,
		yOffset,
		xOffset,
		yOffset,
		xOffset,
		yOffset
	}

	for k, v in pairs(border) do
		local newBorder = clone(v)

		for i, vv in ipairs(borderKeys) do
			if newBorder[vv] then
				newBorder[vv] = newBorder[vv] + borderOffset[i]
			end
		end

		table.insert(self.borderAll, newBorder)
	end

	if info.children then
		local childrenArr = {}

		for k, v in pairs(info.children) do
			table.insert(childrenArr, {
				direction = tonumber(k),
				data = v
			})
		end

		table.sort(childrenArr, function (a, b)
			return a.direction < b.direction
		end)

		for i, v in ipairs(childrenArr) do
			local direction = v.direction
			local data = v.data
			local currentPlug = plugMap[direction]

			if currentPlug then
				local childObj = JsonParser.parse("res/map/" .. data.name .. "/data.json", true)
				local childMapData = childObj.mapData
				local childPlugMap = self:getPlugMapFromMap(childObj)
				local childPlug = childPlugMap[(direction + 2) % 4]

				if childPlug then
					local xoff, yoff = nil
					local xoffTop = 0
					local yoffTop = 0
					local antiDirection = nil

					if direction == 0 then
						xoff = xOffset + currentPlug.x - childPlug.x
						yoff = yOffset - childMapData.tileH
						yoffTop = -1
						antiDirection = 2
					elseif direction == 1 then
						xoff = xOffset + mapData.tileW
						yoff = yOffset + currentPlug.y - childPlug.y
						xoffTop = 1
						antiDirection = 3
					elseif direction == 2 then
						xoff = xOffset + currentPlug.x - childPlug.x
						yoff = yOffset + mapData.tileH
						yoffTop = 1
						antiDirection = 0
					elseif direction == 3 then
						xoff = xOffset - childMapData.tileW
						yoff = yOffset + currentPlug.y - childPlug.y
						xoffTop = -1
						antiDirection = 1
					end

					local plugLink = nil

					for i1, v1 in ipairs(plugLinks) do
						if currentPlug.x .. "_" .. currentPlug.y == v1.code then
							plugLink = v1

							break
						end
					end

					self._mapIndex = self._mapIndex + 1

					table.insert(self._mapLinkMap[mapIndex], self._mapIndex)

					self._mapLinkEventMap[self._mapIndex .. "_" .. mapIndex] = currentPlug
					currentPlug.direction = antiDirection
					childPlug.direction = direction
					local topObj1 = self:addMap(data, xoff, yoff, topObj.x + xoffTop, topObj.y + yoffTop, plugLink, childPlug.x .. "_" .. childPlug.y, mapIndex, childPlug, topObj.x, topObj.y)
				else
					Log.warn("rantile childPlugMap no child " .. data.name)
				end
			else
				Log.warn("rantile childPlugMap no child " .. info.name)
			end
		end
	end

	return topObj
end

function Rantile:getEventDepth(mapIndex)
	if self._depthCache[mapIndex] then
		return self._depthCache[mapIndex]
	end

	local depth = 0
	local enterEvent = nil

	if mapIndex ~= self._enterMapIndex then
		local openArr = {
			mapIndex
		}
		local closedMap = {
			[mapIndex] = true
		}
		local finished = false
		local parentMap = {}

		while #openArr > 0 do
			depth = depth + 1
			local newOpenArr = {}

			for i, v in ipairs(openArr) do
				local linkArr = self._mapLinkMap[v]

				for j, u in ipairs(linkArr) do
					if not closedMap[u] then
						parentMap[u] = v

						if u == self._enterMapIndex then
							finished = true

							break
						else
							table.insert(newOpenArr, u)

							closedMap[u] = true
						end
					end
				end

				if finished then
					break
				end
			end

			openArr = newOpenArr

			if finished then
				break
			end
		end

		local mIndex = self._enterMapIndex
		local path = {
			mIndex
		}

		while parentMap[mIndex] do
			mIndex = parentMap[mIndex]

			if mIndex == mapIndex then
				break
			else
				table.insert(path, 1, mIndex)
			end
		end

		local enterTag = path[1] .. "_" .. mapIndex
		enterEvent = self._mapLinkEventMap[enterTag]
	end

	return depth, enterEvent
end

function Rantile:getPlugMapFromMap(mapObj)
	local plugMap = {}
	local eventData = mapObj.eventData
	local mapData = mapObj.mapData

	for i, v in ipairs(eventData) do
		if v.tag == "plug" then
			local direction = nil

			if v.y == 0 and v.h == 1 then
				direction = 0
			elseif v.x == 0 and v.w == 1 then
				direction = 3
			elseif v.y == mapData.tileH - 1 and v.h == 1 then
				direction = 2
			elseif v.x == mapData.tileW - 1 and v.w == 1 then
				direction = 1
			end

			if direction and not plugMap[direction] then
				plugMap[direction] = v
			end
		end
	end

	return plugMap
end

return Rantile
