local POP_sheet_select = class("POP_sheet_select", UI_base)

function POP_sheet_select.open(tag, items, callback)
	local ui = POP_sheet_select.new(tag, items, callback)

	display.getRunningScene():addChild(ui, LayerConfig.notice + 1)
end

function POP_sheet_select:ctor(tag, items, callback)
	POP_sheet_select.super.ctor(self, "pop_sheet_select")

	self.tag = tag or ""
	self.items = items
	self.callback = callback

	self:init()
end

function POP_sheet_select:init()
	self:initUI()
	self:refresh()
end

function POP_sheet_select:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local mask = self:getComponentByTag("mask")

	mask:toTouchable()
	mask:setOpacity(200)
	mask:addTap(function ()
		self:removeSelf()
	end)

	local cookieKey = "POP_sheet_select@" .. self.tag
	local filterEB = nil
	filterEB = self:createEditBoxOnComponent("eb_filter", function ()
		self:refresh()

		if not empty(self.tag) then
			Cookie.set(cookieKey, filterEB:getText(), true)
		end
	end)

	if Cookie.get(cookieKey) then
		filterEB:setText(Cookie.get(cookieKey))
	end

	self.filterEB = filterEB

	local function tapListener(ui, data, index, x, y)
		if self.callback then
			self.callback(data)
		end

		self:removeSelf()
	end

	self.list = self:createListOnFlag("flag_list", LIST_sheet_select, tapListener)

	self.list:setHolders({
		self:getComponentByTag("holder")
	})
end

function POP_sheet_select:refresh()
	local filter = self.filterEB:getText()
	local items = {}

	for i, v in ipairs(self.items) do
		if empty(filter) or v.id and string.find(v.id, filter) or v.name and string.find(v.name, filter) or v.key and string.find(v.key, filter) then
			table.insert(items, v)
		end
	end

	self.list:setItems(items)
end

return POP_sheet_select
