local zlib = require("zlib")
local CURRENT_MODULE_NAME = ...
local UILayout = import(".UILayout")
local UIComponent = import(".UIComponent")
local UILabel = import(".UILabel")
local UIManager = {
	uiList = {},
	uiSpriteFrames = {}
}
local BIG_TYPE = {
	CENTER = 5,
	POP = 4,
	TOP = 3,
	BOTTOM = 2,
	FULL = 1
}
UIManager.BIG_TYPE = BIG_TYPE
UIManager.BIG_WIDTH = 1280
local emptyTexture = nil

function UIManager.getEmptyTexture()
	if not emptyTexture then
		local ui = UIManager.getUI("empty")
		local bg = ui:getComponentByTag("bg")
		emptyTexture = bg:getTexture()
	end

	return emptyTexture
end

UIManager.LIUHAI_WIDTH = 60
local liuhai = "none"

function UIManager.setLiuhai(_liuhai, _width)
	if _width then
		UIManager.LIUHAI_WIDTH = _width
	end

	if liuhai ~= _liuhai then
		liuhai = _liuhai

		notify.dispatch("liuhai_change")
	end
end

function UIManager.getLiuhai()
	return liuhai
end

UIManager.locked = false
UIManager.lockedFrame = -1

function UIManager.setLocked(b)
	UIManager.locked = b
end

function UIManager.lockFrame(frame)
	if Looper then
		print(debug.traceback())

		UIManager.lockedFrame = math.max(UIManager.lockedFrame, Looper.getFrame() + frame)
	end
end

function UIManager.isLocked()
	if UIManager.locked then
		print("$$$ UIManager.isLocked locked")

		return true
	end

	if Looper and Looper.getFrame() <= UIManager.lockedFrame then
		print("$$$ UIManager.isLocked time", Looper.getFrame(), UIManager.lockedFrame)

		return true
	end
end

function UIManager.getGroupTexture(name)
	UIManager.addSpriteFrames(name)

	return getFinalRes("ui/" .. name .. "_texture.png")
end

function UIManager.addSpriteFrames(name)
	if UIManager.uiSpriteFrames[name] == nil then
		UIManager.uiSpriteFrames[name] = true

		display.addSpriteFrames(getFinalRes("ui/" .. name .. "_sprites.plist"), getFinalRes("ui/" .. name .. "_texture.png"))
	end
end

function UIManager.clear()
	UIManager.uiSpriteFrames = {}
	emptyTexture = nil
end

function UIManager.init()
	UILayout = import(".UILayout", CURRENT_MODULE_NAME)
	UIComponent = import(".UIComponent", CURRENT_MODULE_NAME)
	UILabel = import(".UILabel", CURRENT_MODULE_NAME)

	UIManager.clear()

	local content = getFileData("res/ui/ui_list.json")
	local uncompress = zlib.inflate()
	local ok, _str = pcall(uncompress, content)
	local uiliststr = nil

	if ok then
		uiliststr = _str
	else
		uiliststr = getFileString("res/ui/ui_list.json")
	end

	local obj = json.decode(uiliststr)
	UIManager.design = obj.design
	UIManager.uiList = obj.uilist

	UIManager.addSameComponent("frame_equip_detail", "frame_equip_detail_ab")
	UIManager.addSameComponent("cell_paygift", "cell_paygift_ab")
end

function UIManager.getGroupedPicurl(picurl)
	local textureGroup = string.split(picurl, "@")

	if #textureGroup == 2 then
		UIManager.addSpriteFrames(textureGroup[1])

		return "#" .. textureGroup[2]
	else
		return "#" .. picurl
	end
end

function UIManager.getUI(title, bigType)
	return UILayout.new(title, bigType)
end

function UIManager.getComponent(title, tag)
	local layoutData = UIManager.uiList[title]
	local comList = layoutData.coms

	for i = 1, #comList do
		local data = comList[i]

		if data.tag == tag then
			local component = UIManager._getComponentByData(data, layoutData)

			component:setPosition(0, 0)

			return component
		end
	end

	return nil
end

function UIManager.getComponentData(title, tag)
	local layoutData = UIManager.uiList[title]
	local comList = layoutData.coms

	for i = 1, #comList do
		local data = comList[i]

		if data.tag == tag then
			return data
		end
	end

	return nil
end

function UIManager.getComponentTexture(title, tag)
	local data = UIManager.getComponentData(title, tag)

	if data then
		return data.origin.pic
	else
		return nil
	end
end

function UIManager.createLabel(x, y, width, height, text, style)
	text = text or "Hello, World"
	style = style or {}

	if not style.__styled then
		style = Style.getTTFStyle(style)
	end

	local font = style.font or "Arial"
	local size = style.size or 24
	local align = style.align or Style.center
	local valign = style.valign or Style.vcenter
	local opacity = style.opacity or 255
	local offsetX = style.offsetX or 0
	local offsetY = style.offsetY or 0
	size = math.min(100, tonumber(size) or 24)

	if align == Style.center then
		x = x + width / 2
	elseif align == Style.right then
		x = x + width
	end

	local dimensions = nil
	local lineOffset = 3

	if global and global.LINE_OFFSET then
		lineOffset = lineOffset + global.LINE_OFFSET
	end

	local lineHeight = 8

	if style.wrap then
		dimensions = cc.size(width, 0)
	elseif valign == Style.vtop then
		y = y + size / 2 + lineOffset
	elseif valign == Style.vcenter then
		y = y + height / 2 + lineOffset
	elseif valign == Style.vbottom then
		y = y - size / 2 + lineOffset
	end

	x = x + offsetX
	y = y - offsetY
	local labelWidth = 0
	local labelHeight = 0
	local label = display.newTTFLabel({
		text = text,
		font = font,
		size = size,
		color = style.color,
		align = align,
		valign = valign,
		dimensions = dimensions,
		x = x,
		y = y
	})

	if opacity ~= 255 then
		label:setOpacity(opacity)
	end

	if style.shadowDistance ~= nil and style.shadowDistance ~= 0 then
		label:enableShadow(style.shadowColor or cc.c4b(0, 0, 0, 255), cc.size(style.shadowDistance, -style.shadowDistance))
	elseif style.outlineDistance ~= nil and style.outlineDistance ~= 0 then
		label:enableOutline(style.outlineColor or cc.c4b(0, 0, 0, 255), style.outlineDistance)
	end

	if font ~= "Arial" then
		label:setLineHeight(size + lineHeight)
	end

	local _size = label:getContentSize()
	labelWidth = _size.width
	labelHeight = _size.height

	if style.wrap then
		if valign == Style.vtop then
			label:setPositionY(y + height - labelHeight / 2 + lineOffset)
		elseif valign == Style.vcenter then
			label:setPositionY(y + height / 2 + lineOffset)
		elseif valign == Style.vbottom then
			label:setPositionY(y + labelHeight / 2 + lineOffset)
		end
	end

	if align == Style.left then
		label:setPositionX(x + labelWidth / 2)
	elseif align == Style.right then
		label:setPositionX(x - labelWidth / 2)
	end

	label.originalWidth = _size.width
	label.originalHeight = _size.height
	label.width = label.originalWidth
	label.height = label.originalHeight
	local posX, posY = label:getPosition()
	label.originalX = posX
	label.originalY = posY
	label.x = label.originalX
	label.y = label.originalY

	return label, labelWidth, labelHeight
end

function UIManager.createLabelGroup(flag, texts, styles, param)
	param = param or {}
	local align = param.align or Style.left
	local valign = param.valign or Style.vtop
	local xspace = param.xspace or 0
	local yspace = param.yspace or 5
	local wrap = param.wrap or false
	local widthArray = {}
	local heightArray = {}
	local labelArray = {}
	local lineHeight = 0

	for i = 1, #texts do
		local __style = flag.labelStyle and clone(flag.labelStyle) or {}
		local style = nil

		if styles then
			style = styles[i] or styles
		end

		if style then
			for k, v in pairs(style) do
				__style[k] = v
			end
		end

		if not __style.size then
			__style.size = flag.height
		end

		local label, labelWidth, labelHeight = UIManager.createLabel(flag.x, flag.y, flag.width, flag.height, texts[i], __style)

		table.insert(labelArray, label)
		table.insert(widthArray, labelWidth)
		table.insert(heightArray, labelHeight)

		lineHeight = math.max(lineHeight, labelHeight)

		if flag.opacity ~= nil then
			label:setOpacity(flag.opacity)
		end
	end

	local currentX = 0
	local lineWidth = 0
	local lineWidthArray = {}
	local lineArray = {}
	local lineIndex = 1
	local totalWidth = flag.width
	local totalHeight = 0
	local maxWidth = 0
	local isNewLine = true

	for i = 1, #labelArray do
		local label = labelArray[i]
		local labelWidth = widthArray[i]

		if isNewLine then
			currentX = flag.x
			isNewLine = false

			if totalHeight == 0 then
				totalHeight = lineHeight
			else
				totalHeight = totalHeight + lineHeight + yspace
			end
		end

		currentX = currentX + labelWidth

		if lineArray[lineIndex] == nil then
			lineArray[lineIndex] = {}
		end

		table.insert(lineArray[lineIndex], label)

		lineWidth = lineWidth + labelWidth

		if texts[i] == "\n" or wrap and currentX + labelWidth > flag.x + flag.width then
			table.insert(lineWidthArray, lineWidth)

			maxWidth = math.max(maxWidth, lineWidth)
			lineWidth = 0
			lineIndex = lineIndex + 1
			isNewLine = true
		end
	end

	if lineWidth > 0 then
		maxWidth = math.max(maxWidth, lineWidth)

		table.insert(lineWidthArray, lineWidth)
	end

	local currentX = 0
	local currentY = 0

	if valign == Style.vtop then
		currentY = flag.y + flag.height
	elseif valign == Style.vbottom then
		currentY = flag.y + totalHeight
	else
		currentY = flag.y + flag.height / 2 + totalHeight / 2
	end

	local isNewLine = true
	local lineIndex = 1

	for i = 1, #labelArray do
		local label = labelArray[i]
		local labelWidth = widthArray[i]
		local labelHeight = heightArray[i]

		if texts[i] == "\n" or wrap and currentX + labelWidth > flag.x + flag.width then
			currentY = currentY - lineHeight - yspace
			lineIndex = lineIndex + 1
			isNewLine = true
		end

		if isNewLine then
			local lineWidth = lineWidthArray[lineIndex]

			if align == Style.left then
				currentX = flag.x
			elseif align == Style.right then
				currentX = flag.x + flag.width - lineWidth
			elseif align == Style.center then
				currentX = flag.x + flag.width / 2 - lineWidth / 2
			elseif align == Style.left_in_center then
				currentX = flag.x + flag.width / 2 - maxWidth / 2
			elseif align == Style.right_in_center then
				currentX = flag.x + flag.width / 2 + maxWidth / 2 - lineWidth
			end

			isNewLine = false
		end

		label:setPosition(currentX + labelWidth / 2, currentY - labelHeight / 2 + yspace - (lineHeight - labelHeight) / 2)

		currentX = currentX + labelWidth
	end

	totalWidth = maxWidth

	return labelArray, lineArray, totalWidth, totalHeight, widthArray, heightArray
end

local sameNamesMap = {}

function UIManager.addSameComponent(uiName, ...)
	local sameNames = {
		...
	}

	for i, v in ipairs(sameNames) do
		if not sameNamesMap[uiName] then
			sameNamesMap[uiName] = {}
		end

		table.insert(sameNamesMap[uiName], v)
	end
end

function UIManager.checkSameComponent(uiName, sameName)
	if sameNamesMap[uiName] then
		for i, v in ipairs(sameNamesMap[uiName]) do
			if v == sameName then
				return true
			end
		end
	end

	return false
end

function UIManager.findComponent(uiStr)
	local currNode = display.getRunningScene()
	local uiArr = string.split(uiStr, ".")
	local index = 1

	while currNode.getChildren do
		Log.verbose("UIManager.findComponent", index, #uiArr, uiArr[index])

		if index < #uiArr then
			local children = currNode:getChildren()
			local found = false

			for i, node in ipairs(children) do
				if node.ui_title == uiArr[index] or UIManager.checkSameComponent(uiArr[index], node.ui_title) then
					currNode = node
					index = index + 1
					found = true
				end
			end

			if not found then
				for i, node in ipairs(children) do
					if node.ui_title == "container" then
						currNode = node
						found = true
					end
				end
			end

			if not found then
				local arrA, arrB = string.find(uiArr[index], "%b[]")

				if arrA then
					local str = string.sub(uiArr[index], 1, arrA - 1)
					local idx = tonumber(string.sub(uiArr[index], arrA + 1, arrB - 1))

					if currNode[str] then
						if currNode[str].type == "list" then
							local _cellNode = currNode[str]:getCellUI(idx)

							if _cellNode then
								currNode = _cellNode
								index = index + 1
								found = true
							end
						elseif currNode[str][idx] and currNode[str][idx].getChildren then
							currNode = currNode[str][idx]
							index = index + 1
							found = true
						end
					end
				elseif currNode[uiArr[index]] and currNode[uiArr[index]].getChildren then
					currNode = currNode[uiArr[index]]
					index = index + 1
					found = true
				end
			end

			if not found then
				break
			end
		else
			if currNode.getComponentByTag and currNode:getComponentByTag(uiArr[index]) then
				return currNode:getComponentByTag(uiArr[index])
			end

			local arrA, arrB = string.find(uiArr[index], "%b[]")

			if arrA then
				local str = string.sub(uiArr[index], 1, arrA - 1)
				local idx = tonumber(string.sub(uiArr[index], arrA + 1, arrB - 1))

				if currNode[str] then
					if currNode[str].type == "list" then
						return currNode[str]:getCellUI(idx)
					elseif currNode[str][idx] and currNode[str][idx].getChildren then
						return currNode[str][idx]
					end
				end
			elseif currNode[uiArr[index]] and currNode[uiArr[index]].getChildren then
				return currNode[uiArr[index]]
			end

			return nil
		end
	end
end

function UIManager.getLabel(text, style)
	return UILabel.new(text, style)
end

function UIManager._getComponentByData(data, layoutData, bigType, bigScale, bigDisplay)
	return UIComponent.new(data, layoutData, bigType, bigScale, bigDisplay)
end

local groupCallbackMap = {}

function UIManager.setTapCallback(groupName, onTap, onTouch)
	groupCallbackMap[groupName] = {
		onTap = onTap,
		onTouch = onTouch
	}
end

function UIManager.callTapCallback(groupName, node, isManual, onManualComplete)
	if groupName then
		local obj = groupCallbackMap[groupName]

		if obj and obj.onTap then
			obj.onTap(node, isManual, onManualComplete)

			return
		end
	end

	if onManualComplete then
		onManualComplete()
	end
end

function UIManager.callTapCallbackTouch(groupName, node, event, container)
	if groupName then
		local obj = groupCallbackMap[groupName]

		if obj and obj.onTouch then
			obj.onTouch(node, event, container)
		end
	end
end

function UIManager.callTapGroup(groupName, node, onComplete, noManual)
	local isManual = true

	if noManual then
		isManual = false
	end

	UIManager.callTapCallback(groupName, node, isManual, onComplete)
end

function UIManager.getWorldScale(_node)
	local scale = 1

	while _node do
		scale = scale * _node:getScaleX()
		_node = _node:getParent()
	end

	return scale
end

function UIManager.getBigScale()
	local bigScale = nil

	if CONFIG_SCREEN_AUTOSCALE == "FIXED_HEIGHT" then
		if display.width < 960 then
			bigScale = display.width / UIManager.BIG_WIDTH
		end
	elseif CONFIG_SCREEN_AUTOSCALE == "FIXED_WIDTH" and display.height < 640 then
		bigScale = display.height / 640
	end

	return bigScale or 1
end

function UIManager.getBigWidth()
	local bigWidth = nil

	if CONFIG_SCREEN_AUTOSCALE == "FIXED_HEIGHT" and display.width < 960 then
		bigWidth = UIManager.BIG_WIDTH
	end

	return bigWidth or display.width
end

return UIManager
