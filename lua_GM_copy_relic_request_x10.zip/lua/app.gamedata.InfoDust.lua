local InfoDust = {}
local STATE = {
	ENDED = 4,
	TO_END = 3,
	BEGAN = 2,
	TO_BEGIN = 1,
	NONE = 0
}
InfoDust.STATE = STATE
local shopList = nil
local shopRefreshIndex = 0
local rawData, gmData = nil

function InfoDust.init()
	Connection.listen("dust_sync", InfoDust.sync)
end

app:addToAppEnterCall(InfoDust.init)

function InfoDust.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoDust.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("dust_query", callback)
end

function InfoDust.onQuery(rcvData)
	dump(rcvData, "dust_query")

	rawData = {}

	for i, data in ipairs(rcvData.list) do
		rawData[data.base_id] = data
	end

	gmData = {}

	for i, data in ipairs(rcvData.gm_list) do
		gmData[data.id] = data
	end
end

function InfoDust.sync(data)
	dump(data, "$$$ InfoDust.sync")

	if data.list then
		for i, syncData in ipairs(data.list) do
			local base_id = syncData.base_id

			if rawData[base_id] then
				for k, v in pairs(syncData) do
					rawData[base_id][k] = v
				end
			else
				rawData[base_id] = syncData
			end
		end
	end

	if data.gm_list then
		for i, syncData in ipairs(data.gm_list) do
			local id = syncData.id

			if gmData[id] then
				for k, v in pairs(syncData) do
					gmData[id][k] = v
				end
			else
				gmData[id] = syncData
			end
		end
	end

	ManagerInfo.dataChange("dust")
end

function InfoDust.getSubHero(base_id, pos, index)
	local subArr = InfoDust.getSubHeroArr(base_id, pos)

	return subArr[index]
end

function InfoDust.getSubHeroArr(base_id, pos)
	local subArr = {}
	local data = rawData[base_id]

	if data then
		for i = 1, GameConfig.dust_sub_num do
			local heroID = data["hero" .. pos .. "_" .. i]

			if not empty(heroID) then
				local heroInfo = InfoHero.getHero(heroID)

				if heroInfo then
					table.insert(subArr, heroInfo)
				end
			end
		end
	end

	return subArr
end

function InfoDust.getSubHeroAll(base_id)
	local subArr = {}
	local subMap = {}
	local data = rawData[base_id]

	if data then
		for pos = 1, GameConfig.hero_team_num do
			for i = 1, GameConfig.dust_sub_num do
				local heroID = data["hero" .. pos .. "_" .. i]

				if not empty(heroID) then
					local heroInfo = InfoHero.getHero(heroID)

					if heroInfo then
						table.insert(subArr, heroInfo)

						subMap[heroInfo.id] = true
					end
				end
			end
		end
	end

	return subArr, subMap
end

function InfoDust.isSub(hero_id)
	local opening = InfoParams.getValue("dust")

	if opening == 1 then
		local dustData = InfoDust.getCurrentData()

		if dustData and InfoDust.inSeason() then
			for pos = 1, GameConfig.hero_team_num do
				for i = 1, GameConfig.dust_sub_num do
					local heroID = dustData["hero" .. pos .. "_" .. i]

					if not empty(heroID) and heroID == hero_id then
						return true
					end
				end
			end
		end
	end

	return false
end

function InfoDust.setSubHero(data, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "dust_sub_hero")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("dust_sub_hero", data, callback)
end

function InfoDust.setSubOn(pos, index, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "dust_sub_on")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			TeamManager.refreshTeam(true)

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("dust_sub_on", {
		pos = pos,
		index = index
	}, callback)
end

function InfoDust.subFix(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "dust_sub_fix")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("dust_sub_fix", callback)
end

function InfoDust.enterPrepare(base_id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			local result = rcvData.dungeon_result
			local title, subTitle = InfoDungeon.getTitle(result.type, result.dungeon_id, result.quest_id, result.abyss_seed)

			Transition.setTitle(title, subTitle)
			Transition.leave(function ()
				if onSuccess then
					onSuccess(result)
				end
			end)
		end
	end

	Connection.request("dust_prepare", {
		base_id = base_id
	}, callback)
end

function InfoDust.enterStage(level, speedup, onSuccess, onFailure)
	local count, countMax = InfoEquip.count()

	if countMax <= count then
		Alert.open(Localization.getSrcText("装备数量达到上限，请先处理"))

		return
	end

	local count, countMax = InfoSigil.count()

	if countMax <= count then
		Alert.open(Localization.getSrcText("魔纹数量达到上限，请先处理"))

		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			local result = rcvData.dungeon_result
			local title, subTitle = InfoDungeon.getTitle(result.type, result.dungeon_id, result.quest_id, result.abyss_seed)

			Transition.setTitle(title, subTitle)
			Transition.leave(function ()
				if onSuccess then
					onSuccess(result)
				end
			end)
		end
	end

	Connection.request("dust_enter", {
		level = level,
		speedup = speedup
	}, callback)
end

function InfoDust.enterNext(event_index, speedup, curr_level, enterIndex, onSuccess, onFailure, isAutoDown, onData)
	print("$$$ InfoDust.enterNext", event_index, speedup, curr_level)

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif rcvData.dungeon_result then
			if onData then
				onData(rcvData)
			end

			local function enterDungeon()
				local result = rcvData.dungeon_result
				local title, subTitle = InfoDungeon.getTitle(result.type, result.dungeon_id, result.quest_id, result.abyss_seed)

				Transition.setTitle(title, subTitle)
				Transition.leave(function ()
					if onSuccess then
						onSuccess(result)
					end
				end)
			end

			if isAutoDown then
				enterDungeon()
			else
				local rewards = rcvData.rewards

				if rewards and #rewards > 0 then
					FRAME_dust_next_reward.open(rcvData, enterDungeon)
				else
					enterDungeon()
				end
			end
		end
	end

	Connection.request("dust_next", {
		map_index = InfoDungeon.getMapIndex(),
		speedup = speedup,
		event_index = event_index,
		curr_level = curr_level,
		enter_index = enterIndex
	}, callback)
end

function InfoDust.getDataByID(base_id)
	return rawData[base_id]
end

function InfoDust.getData()
	local stageType, stageID = InfoDungeon.getStage()
	local base_id = stageID
	local csv = CsvParser.getCsvData("dust", base_id)

	return rawData[base_id], csv, base_id
end

function InfoDust.getCurrentData()
	local dustState, dustID, dustNextTime = InfoDust.getState()

	if dustID then
		return rawData[dustID]
	end
end

function InfoDust.getCurrLevel()
	local _, base_id = InfoDungeon.getStage()
	local data = rawData[base_id]

	return data.curr_level
end

function InfoDust.getLevel()
	local stageType, stageID = InfoDungeon.getStage()
	local base_id = stageID
	local csv = CsvParser.getCsvData("dust", base_id)
	local data = rawData[base_id]

	return data.curr_level + csv.start_level - 1
end

function InfoDust.getSampleHero(pos)
	local data, csv = InfoDust.getData()
	local sampleHeroID = data["hero_" .. pos]

	if not empty(sampleHeroID) then
		return InfoHero.getHero(sampleHeroID)
	end
end

function InfoDust.findSub(_heroID)
	local data, csv = InfoDust.getData()
	local _pos, _index = nil
	local heroInfo = InfoHero.getHero(_heroID)

	if heroInfo.pos > 0 then
		_pos = heroInfo.pos
		_index = 0
	else
		for pos = 1, GameConfig.hero_team_num do
			for i = 1, GameConfig.dust_sub_num do
				local heroID = data["hero" .. pos .. "_" .. i]

				if not empty(heroID) and heroID == _heroID then
					_pos = pos
					_index = i
				end
			end
		end
	end

	if _pos then
		local sampleHeroID = data["hero_" .. _pos]

		if _heroID ~= sampleHeroID then
			return _pos, _index
		end
	end
end

function InfoDust.cloneSample(heroInfo)
	local pos, index = InfoDust.findSub(heroInfo.id)

	if pos then
		local sampleHero = InfoDust.getSampleHero(pos)

		if sampleHero then
			local sampleCSV = CsvParser.getCsvData("hero", sampleHero.base_id)
			local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)

			if heroInfo.level < sampleHero.level or heroCSV.job_level < sampleCSV.job_level then
				heroInfo = ObjUtil.clone(heroInfo)
				local newCSV = InfoHero.getJobLevelCSV(heroInfo.base_id, sampleCSV.job_level)
				heroInfo.level = sampleHero.level
				heroInfo.base_id = newCSV.id

				return heroInfo
			end
		end
	end
end

function InfoDust.getStageNum(dust_csv)
	local stageArr = SheetUtil.getColumnList(dust_csv, {
		"stage_",
		"mutate_prob_"
	}, {
		"stage",
		"mutate_prob"
	})

	return #stageArr
end

local dustBossCache = nil

function InfoDust.checkBossStage(dustID, level)
	if not dustBossCache then
		dustBossCache = {}
		local csvRaw = CsvParser.getCsvRaw("dust_boss")

		for i, csv in pairs(csvRaw) do
			if not dustBossCache[csv.dust_id] then
				dustBossCache[csv.dust_id] = {}
			end

			dustBossCache[csv.dust_id][csv.dust_level] = csv.id
		end
	end

	if dustBossCache[dustID] and dustBossCache[dustID][level] then
		return dustBossCache[dustID][level]
	end
end

function InfoDust.getStageName(dustData, dust_csv, seed, isEnter, enterIndex, level)
	local stage = nil
	local isSp = false
	local isMutate = false
	local isBoss = false
	local mutateID = 0
	local terrainID = 0
	local bossID = InfoDust.checkBossStage(dust_csv.id, level)

	if bossID then
		local bossCSV = CsvParser.getCsvData("dust_boss", bossID)
		stage = bossCSV.stage_id
		isBoss = true
	else
		local sp_cd = dustData.sp_cd

		if isEnter then
			local ran = Random.new(seed)
			sp_cd = SheetUtil.getNumber(dust_csv.sp_cd_init, ran)
		end

		enterIndex = enterIndex or 1
		local ran = Random.new(seed)
		local stageArr = SheetUtil.getColumnList(dust_csv, {
			"stage_",
			"mutate_prob_"
		}, {
			"stage",
			"mutate_prob"
		})
		stageArr = ran:order(stageArr)
		local spIndex = 0

		if sp_cd <= 0 and ran:next() < dust_csv.sp_prob then
			spIndex = ran:getInt(1, #stageArr)
		end

		local stageGen = Random.new(seed + enterIndex)

		if spIndex == enterIndex then
			stage = SheetUtil.getString(dust_csv.sp_stage, stageGen)
			isSp = true
		else
			local obj = stageArr[enterIndex]
			local stageGen = Random.new(seed + enterIndex)
			stage = SheetUtil.getString(obj.stage, stageGen)
			isMutate = stageGen:next() < obj.mutate_prob
		end

		local stageCSV = CsvParser.getCsvData("stage", stage)
		local mutateGen = Random.new(seed + enterIndex)

		if isMutate then
			mutateID = InfoDungeon.getStageMutate(stageCSV.id, mutateGen)
		end

		if not empty(stageCSV.terrain_id) then
			terrainID = SheetUtil.getNumber(stageCSV.terrain_id, mutateGen)
		end
	end

	print("$$$ getStageName", stage, isSp, isMutate, mutateID, terrainID, seed, enterIndex)

	return stage, isSp, isMutate, isBoss, mutateID, terrainID
end

function InfoDust.needSaveEnc(heroInfo, job_level)
	if not InfoHero.isTrueSp(heroInfo) then
		local heroCSV = InfoHero.getJobLevelCSV(heroInfo.base_id, job_level)
		local newHeroInfo = ObjUtil.clone(heroInfo)
		newHeroInfo.base_id = heroCSV.id
		local zeroCount = 0

		for i = 1, heroCSV.job_level do
			if newHeroInfo["skill_enc_" .. i] == 0 then
				zeroCount = zeroCount + 1
			end
		end

		return zeroCount > 0
	end
end

function InfoDust.getSpeedupLife()
	local data = InfoDust.getData()

	return data.speedup_life
end

local ranking_map = {}
local requesting_map = {}
local request_time_map = {}
local rankingAmount, selfRank = nil

function InfoDust.getMyRank()
	return selfRank
end

function InfoDust.getRankingAmount()
	return rankingAmount
end

local preRankingTime = nil

function InfoDust.startRanking(onSuccess, onFailure)
	local nowTime = math.floor(Time.now())

	if preRankingTime and nowTime - preRankingTime < MiscConfig.ranking_cache_time then
		onSuccess()

		return
	end

	local function callback(rcvData)
		dump(rcvData, "$$$ dust_ranking_start")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			preRankingTime = nowTime
			rankingAmount = rcvData.amount
			selfRank = rcvData.self_rank

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("dust_ranking_start", callback)
end

function InfoDust.lastRanking(dust_id, onSuccess, onFailure)
	print("$$$ lastRanking", dust_id)

	local function callback(rcvData)
		dump(rcvData, "$$$ dust_ranking_last")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("dust_ranking_last", {
		dust_id = dust_id
	}, callback)
end

function InfoDust.getRanking(page, onSuccess, onFailure)
	local start_index = (page - 1) * GameConfig.ranking_page + 1
	local dust_ranking_look_num = CsvParser.getCsvData("config", "dust_ranking_look_num").value

	if dust_ranking_look_num < start_index then
		return
	end

	local function callback(rcvData)
		dump(rcvData, "$$$ dust_ranking")

		requesting_map[page] = nil
		request_time_map[page] = Time.time()

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			local list = rcvData.list

			for i, v in ipairs(list) do
				local rank = start_index + i - 1
				ranking_map[rank] = {
					rank = rank
				}

				for k, v in pairs(v) do
					ranking_map[rank][k] = v
				end
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	requesting_map[page] = true

	Connection.request("dust_ranking", {
		start_index = start_index
	}, callback)
end

function InfoDust.getRankingData(rank)
	local page = math.floor((rank - 1) / GameConfig.ranking_page) + 1

	if not ranking_map[rank] or GameConfig.ranking_local_time < Time.time() - request_time_map[page] then
		if not requesting_map[page] then
			InfoDust.getRanking(page)
		end
	else
		return ranking_map[rank]
	end
end

function InfoDust.inSeason()
	local dustState, dustID = InfoDust.getState()
	local inSeason = false

	for base_id, data in pairs(rawData) do
		if base_id == dustID and STATE.TO_BEGIN <= dustState and dustState < STATE.ENDED then
			inSeason = true

			break
		end
	end

	return inSeason
end

function InfoDust.showNav()
	local dustState, dustID, dustNextTime = InfoDust.getState()
	local opening = InfoParams.getValue("dust")

	if opening == 1 then
		if opening == 1 and (dustState == InfoDust.STATE.TO_BEGIN or dustState == InfoDust.STATE.BEGAN or dustState == InfoDust.STATE.TO_END) then
			return true
		elseif dustState == InfoDust.STATE.ENDED then
			local nowDay = Time.getToday()
			local endDay = Time.getDay(dustNextTime)
			local dust_ranking_display = CsvParser.getCsvData("config", "dust_ranking_display").value

			if nowDay <= endDay + dust_ranking_display then
				return true
			end
		end
	end

	return false
end

function InfoDust.getState()
	local areaID = InfoWorld.getAbyssArea()
	local areaOpened = InfoAbyssReward.getAreaOpened()

	if areaID <= areaOpened then
		local state = STATE.NONE
		local nowTime = Time.now()

		for k, data in pairs(gmData) do
			local dustCSV = CsvParser.getCsvData("dust", data.id)

			if dustCSV and dustCSV.abyss_area == areaID then
				if nowTime < data.stime then
					return STATE.TO_BEGIN, data.id, data.stime
				elseif nowTime <= data.pre_etime then
					return STATE.BEGAN, data.id, data.pre_etime
				elseif nowTime <= data.etime then
					return STATE.TO_END, data.id, data.etime
				else
					return STATE.ENDED, data.id, data.etime
				end
			end
		end
	end

	return STATE.NONE
end

function InfoDust.getDustData()
	local areaID = InfoWorld.getAbyssArea()
	local areaOpened = InfoAbyssReward.getAreaOpened()

	if areaID <= areaOpened then
		local state = STATE.NONE
		local nowTime = Time.now()

		for k, data in pairs(gmData) do
			local dustCSV = CsvParser.getCsvData("dust", data.id)

			if dustCSV.abyss_area == areaID then
				return data
			end
		end
	end
end

function InfoDust.checkEquip(equipInfo)
	local dustData = InfoDust.getData()

	if dustData and equipInfo.dust_id > 0 then
		local growthCSV = CsvParser.getCsvData("dust_growth_base", dustData.base_id)

		if growthCSV then
			local min, max = SheetUtil.getMinMax(growthCSV.equip_level)

			if min <= equipInfo.level and equipInfo.level <= max then
				return true
			end
		end
	end

	return false
end

function InfoDust.isAreaReady(dustID)
	local csv = CsvParser.getCsvData("dust", dustID)

	if csv and InfoDungeon.isAreaFinished(csv.abyss_area) then
		return true
	end

	return false
end

function InfoDust.checkSeason()
	local dustState, dustID = InfoDust.getState()
	local checkList = {}

	for base_id, data in pairs(rawData) do
		if data.season_rewarded == 0 and (data.max_level > 1 or data.level_time > 0) and (base_id ~= dustID or dustState == STATE.ENDED) then
			table.insert(checkList, base_id)

			break
		end
	end

	dump(checkList, "$$$ InfoDust.checkSeason")

	if #checkList == 0 then
		return
	end

	local checkIndex = 1
	local checkNext = nil

	local function onClose()
		checkIndex = checkIndex + 1

		if checkList[checkIndex] then
			checkNext()
		end
	end

	function checkNext()
		local dust_id = checkList[checkIndex]

		if dust_id then
			local function callback(rcvData)
				if rcvData.err then
					onClose()
				elseif rcvData.rewards then
					FRAME_dust_season_reward.open(dust_id, rcvData, onClose)
				end
			end

			Connection.request("dust_check_season", {
				dust_id = dust_id
			}, callback)
		end
	end

	checkNext()
end

function InfoDust.getBossDaily(id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("dust_boss_daily", {
		dust_id = id
	}, callback)
end

function InfoDust.mirrorLvup(id, group, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ dust_mirror_lvup")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("dust_mirror_lvup", {
		dust_id = id,
		group = group
	}, callback)
end

function InfoDust.getPassExp(dustID)
	local dustData = rawData[dustID]

	if dustData then
		return dustData.exp
	end

	return 0
end

function InfoDust.getPassLevel(dustID)
	local exp = InfoDust.getPassExp(dustID)
	local csvList = CsvParser.getCsvList("dust_pass_gift", nil, {
		pass_id = dustID
	})
	local level = 0
	local expLeft = exp
	local expTotal = 100
	local isMax = true

	for i, csv in ipairs(csvList) do
		exp = exp - csv.next_exp

		if exp >= 0 then
			level = csv.pass_level
			expLeft = exp
		else
			expTotal = csv.next_exp
			isMax = false

			break
		end
	end

	return level, expLeft, expTotal, isMax
end

function InfoDust.getPassExpMax(dustID)
	local exp = 0
	local csvList = CsvParser.getCsvList("dust_pass_gift", nil, {
		pass_id = dustID
	})

	for i, csv in ipairs(csvList) do
		exp = exp + csv.next_exp
	end

	return exp
end

function InfoDust.getSeasonRewardPass(level)
	local currentCSV, nextCSV = nil
	local csvList = CsvParser.getCsvList("dust_season_reward", nil, {
		type = 1
	})
	local arr = {}

	for i, csv in ipairs(csvList) do
		table.insert(arr, csv)
	end

	table.sort(arr, function (a, b)
		return b.value < a.value
	end)

	for i, csv in ipairs(arr) do
		if csv.value <= level then
			currentCSV = csv

			break
		else
			nextCSV = csv
		end
	end

	return currentCSV, nextCSV
end

function InfoDust.getSeasonRewardRanking(ranking, hasLevel)
	ranking = ranking or 0
	local currentCSV, nextCSV = nil
	local csvList = CsvParser.getCsvList("dust_season_reward", nil, {
		type = 2
	})
	local arr = {}
	local zeroCSV = nil

	for i, csv in ipairs(csvList) do
		if csv.value == 0 then
			zeroCSV = csv
		else
			table.insert(arr, csv)
		end
	end

	if hasLevel then
		table.sort(arr, function (a, b)
			return a.value < b.value
		end)

		if ranking == 0 then
			return zeroCSV, arr[#arr]
		else
			for i, csv in ipairs(arr) do
				if ranking <= csv.value then
					currentCSV = csv

					break
				else
					nextCSV = csv
				end
			end

			return currentCSV or zeroCSV, nextCSV
		end
	else
		return nil, zeroCSV
	end
end

function InfoDust.getBossLevel(base_id)
	local data = rawData[base_id]

	if data then
		return data.boss_level
	end

	return 0
end

function InfoDust.getBossDailyRewardList(base_id)
	local csvList = CsvParser.getCsvList("dust_boss", nil, {
		dust_id = base_id
	})
	local bossLevel = InfoDust.getBossLevel(base_id)
	local hasReward = false
	local rewardItemMap = {}
	local rewardArr = {}

	for index, csv in ipairs(csvList) do
		if csv.dust_level <= bossLevel then
			hasReward = true
			local dailyArr = string.split(csv.daily_reward_display, ";")

			for i, value in ipairs(dailyArr) do
				local itemArr = string.split(value, ",")
				local itemID = tonumber(itemArr[1])
				local itemNum = tonumber(itemArr[2])

				if not empty(itemID) and not empty(itemNum) then
					if not rewardItemMap[itemID] then
						rewardItemMap[itemID] = {
							num = 0,
							base_id = itemID
						}

						table.insert(rewardArr, rewardItemMap[itemID])
					end

					rewardItemMap[itemID].num = rewardItemMap[itemID].num + itemNum
				end
			end
		else
			break
		end
	end

	return hasReward, rewardArr
end

function InfoDust.hasBossReward(base_id)
	local data = rawData[base_id]

	if data then
		local nowTime = Time.now()

		return RefreshManager.checkTimePassed(RefreshManager.TYPE.DUST_BOSS_REWARD, nowTime, data.boss_daily)
	end

	return false
end

function InfoDust.countRedotBossDaily(base_id)
	if InfoDust.getState() == InfoDust.STATE.ENDED then
		return 0
	end

	local hasReward, rewardArr = InfoDust.getBossDailyRewardList(base_id)
	local hasDaily = InfoDust.hasBossReward(base_id)

	if hasReward and hasDaily then
		return 1
	end

	return 0
end

function InfoDust.countRedotDayReward(base_id)
	if InfoDust.getState() == InfoDust.STATE.ENDED then
		return 0
	end

	local isRewarded = InfoDustAchieve.isRewarded(InfoDustAchieve.TYPE.DAY)
	local isFinished = InfoDustAchieve.isFinished(InfoDustAchieve.TYPE.DAY)
	local redotCount = 0

	if not isRewarded and isFinished then
		redotCount = redotCount + 1
	end

	local arr = InfoDustAchieve.getList(InfoDustAchieve.TYPE.DAY)

	for index, data in ipairs(arr) do
		local csv = CsvParser.getCsvData("dust_pass_achieve", data.base_id)
		local count = data.count

		if RefreshManager.checkTimePassed(RefreshManager.TYPE.DUST_ACHIEVE_DAY, Time.now(), data.count_time) then
			count = 0
		end

		if data.rewarded == 0 and csv.num <= count then
			redotCount = redotCount + 1
		end
	end

	return redotCount
end

function InfoDust.countRedotWeekReward(base_id)
	if InfoDust.getState() == InfoDust.STATE.ENDED then
		return 0
	end

	local isRewarded = InfoDustAchieve.isRewarded(InfoDustAchieve.TYPE.WEEK)
	local isFinished = InfoDustAchieve.isFinished(InfoDustAchieve.TYPE.WEEK)

	if not isRewarded and isFinished then
		return 1
	end

	return 0
end

local mirrorCsvMap = {}

function InfoDust.getMirrorCsvID(base_id, group, level)
	if not mirrorCsvMap[base_id] then
		local csvList = CsvParser.getCsvList("dust_mirror_skill", nil, {
			dust_id = base_id
		})
		local csvMap = {}

		for index, v in ipairs(csvList) do
			if not csvMap[v.group] then
				csvMap[v.group] = {}
			end

			csvMap[v.group][v.level] = v.id
		end

		mirrorCsvMap[base_id] = csvMap
	end

	local csvMap = mirrorCsvMap[base_id]

	if csvMap[group] and csvMap[group][level] then
		return csvMap[group][level]
	end
end

local mirrorGroupMap = {}

function InfoDust.getMirrorList(base_id)
	if not mirrorGroupMap[base_id] then
		local csvList = CsvParser.getCsvList("dust_mirror_skill", nil, {
			dust_id = base_id
		})
		local groupExist = {}
		local groupArr = {}

		for index, v in ipairs(csvList) do
			if not groupExist[v.group] then
				groupExist[v.group] = true

				table.insert(groupArr, v.group)
			end
		end

		mirrorGroupMap[base_id] = groupArr
	end

	local dustData = rawData[base_id]

	if dustData then
		local groupArr = mirrorGroupMap[base_id]

		dump(groupArr, "$$$ groupArr")

		local arr = {}

		for index, group in ipairs(groupArr) do
			local level = InfoDust.getMirrorLevel(base_id, group)
			local csvID = InfoDust.getMirrorCsvID(base_id, group, level)

			if csvID then
				local csv = CsvParser.getCsvData("dust_mirror_skill", csvID)

				if csv then
					table.insert(arr, {
						group = group,
						level = level,
						csv = csv
					})
				end
			end
		end

		return arr
	end

	return {}
end

function InfoDust.getMirrorLevel(base_id, group)
	local dustData = rawData[base_id]

	if dustData then
		return dustData["mirror_" .. group] or 0
	end

	return 0
end

function InfoDust.getMirrorData(base_id, group)
	local level = InfoDust.getMirrorLevel(base_id, group)
	local csvID = InfoDust.getMirrorCsvID(base_id, group, level)
	local csv = CsvParser.getCsvData("dust_mirror_skill", csvID)

	return {
		group = group,
		level = level,
		csv = csv
	}
end

function InfoDust.getShopLabels()
	return nil
end

function InfoDust.clearOnReconnect()
	shopList = nil
end

function InfoDust.getShopList(_callback)
	local dustData = InfoDust.getData()

	if not dustData then
		return
	end

	local needQuery = shopList == nil

	if not needQuery and dustData.shop_refresh_time < Time.now() then
		needQuery = true
	end

	if needQuery then
		local function callback(rcvData)
			dump(rcvData, "dust_shop_list")

			if rcvData.err then
				-- Nothing
			else
				shopRefreshIndex = shopRefreshIndex + 1
				shopList = rcvData.items

				if _callback then
					_callback(shopList)
				end
			end
		end

		Connection.request("dust_shop_list", callback)
	else
		_callback(shopList)
	end
end

function InfoDust.getShopItems()
	local dustData = InfoDust.getData()

	if not dustData then
		return {}
	end

	local arr = {}
	local multiLabel = false

	for i, v in ipairs(shopList) do
		local shopCSV = CsvParser.getCsvData("dust_shop", v.shop_id, nil, true)

		if shopCSV and shopCSV.dust_level_min <= dustData.max_level and dustData.max_level <= shopCSV.dust_level_max and (shopCSV.no_supply ~= 1 or v.soldout < shopCSV.times) then
			table.insert(arr, v)
		end
	end

	table.sort(arr, function (a, b)
		return a.shop_id < b.shop_id
	end)

	return arr, multiLabel
end

function InfoDust.buy(shop_id, num, onSuccess, onFailure)
	if InfoDust.getState() == InfoDust.STATE.ENDED then
		Alert.open(Localization.getSrcText("尘封赛季已结束"))
	end

	local preIndex = shopRefreshIndex

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if rcvData.item then
				local item = rcvData.item

				if preIndex == shopRefreshIndex and shopList then
					for i, v in ipairs(shopList) do
						if v.shop_id == item.shop_id then
							for k1, v1 in pairs(item) do
								v[k1] = v1
							end
						end
					end
				end
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("dust_shop_buy", {
		shop_id = shop_id,
		num = num
	}, callback)
end

function InfoDust.getShopCSV()
	return "dust_shop"
end

function InfoDust.getCostNeed()
	return nil
end

function InfoDust.getShopName()
	return "dust"
end

function InfoDust.getShopTime()
	local dustData = InfoDust.getData()

	return dustData.shop_refresh_time, RefreshManager.getNextTime(RefreshManager.TYPE.DUST_SHOP, Time.now())
end

function InfoDust.getRefreshType()
	return RefreshManager.TYPE.DUST_SHOP
end

return InfoDust
