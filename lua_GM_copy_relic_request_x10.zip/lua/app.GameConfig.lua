local GameConfig = {
	pet_feed_num = 3,
	pet_peak_level = 296,
	sigil_affix_max = 2,
	hero_peak_level = 296,
	yd_check_interval = 300,
	yd_token_interval = 1800,
	dust_mirror_max = 6,
	user_union_info_cache_time = 300,
	mail_person_query_max = 50,
	equip_count_query_max = 200,
	card_count_query_max = 500,
	sigil_count_query_max = 500,
	artifact_count_query_max = 300,
	cardup_mat_type = 17,
	dustup_mat_type = 34,
	dust_sub_num = 2,
	ranking_page = 5,
	ranking_local_time = 60,
	ACTV_TYPE = {
		stage = 6,
		monster = 5,
		achieve = 4,
		charge = 3,
		probup = 2,
		festival = 1,
		turntable = 9,
		record = 8,
		achieve_full = 7
	},
	hero_affix_use_type = 9,
	default_head = 7000001,
	default_head_frame = 7100001,
	armory_name_len_min = 1,
	armory_name_len_max = 6,
	fish_max_weight_ratio = 2,
	default_lang = "cn",
	std_lang = "en",
	rune_num = 4,
	pet_equip_type = 22,
	abyss_gift_max = 10000,
	CHAT_CACHE_NUM = 30,
	DUST_QUALITY = 5,
	SUIT_QUALITY = 4,
	EXCELLENT_QUALITY = 5,
	item_growth_list = {
		100700,
		100600,
		100500,
		100300
	},
	item_growth_map = {}
}

for i, v in ipairs(GameConfig.item_growth_list) do
	GameConfig.item_growth_map[v] = i
end

GameConfig.exchange_test = 0
GameConfig.exchange_price_step = 10
GameConfig.stall_num = 3
GameConfig.EXCHANGE_PAGE_NUM = 5
GameConfig.stall_name_min = 4
GameConfig.stall_name_max = 8
GameConfig.exchange_sell_max = 5
GameConfig.farm_item = 100800
GameConfig.farm_grow_speedup = 1.5
GameConfig.invest_star_num = 3
GameConfig.td_hero_max = 6
GameConfig.arena_ranking_num = 100
GameConfig.arena_replay_num = 20
GameConfig.arena_lock_time = 300
GameConfig.arena_safe_time = 240
GameConfig.arena_battle_time = 180
GameConfig.travel_hour_list = {
	4,
	8,
	12
}
GameConfig.travel_hero_num = 3
GameConfig.equip_shop_num = 5
GameConfig.gladiator_max = 5
GameConfig.building_plug_num = 4
GameConfig.growth_ratio = 100
GameConfig.hero_quality_max = 6
GameConfig.equip_affix_max = 5
GameConfig.equip_dust_max = 3
GameConfig.equip_gem_max = 3
GameConfig.modao_skill_num = 3
GameConfig.user_nickname_len_min = 2
GameConfig.user_nickname_len_max = 8
GameConfig.hero_name_len_min = 1
GameConfig.hero_name_len_max = 6
GameConfig.pet_name_len_min = 1
GameConfig.pet_name_len_max = 6
GameConfig.tp_item = 300001
GameConfig.max_equip = 9
GameConfig.show_equip_pos = {
	[6.0] = true
}
GameConfig.avatar_hide_pos = {
	nil,
	nil,
	nil,
	nil,
	true,
	true,
	true,
	true
}
GameConfig.display_equip_arr = {
	1,
	5,
	6,
	7,
	8,
	9,
	10
}
GameConfig.display_equip_pos = {}

for i, pos in ipairs(GameConfig.display_equip_arr) do
	GameConfig.display_equip_pos[pos] = true
end

GameConfig.max_card = 1
GameConfig.max_pet_equip = 4
GameConfig.BATTLE_LEADER_CHANGE = false
GameConfig.max_pet = 2
GameConfig.hero_revive = 1200
GameConfig.coin_item = 100100
GameConfig.zuan_item = 100200
GameConfig.hero_team_num = 3
GameConfig.pet_team_num = 3
GameConfig.quick_slots_num = 4
GameConfig.hero_skill_level = 4
GameConfig.bag_slot_num = 12
GameConfig.moonID = 1000
GameConfig.seasonID = 1010
GameConfig.max_num = 2147483647

function GameConfig.adjustNum(num)
	return math.min(GameConfig.max_num, num)
end

GameConfig.request_lock_c = 2
GameConfig.request_lock_s = 1.5

return GameConfig
