local FRAME_redeem = class("FRAME_redeem", UI_base)

function FRAME_redeem.open()
	local ui = FRAME_redeem.new()

	PopManager.open(ui)
end

function FRAME_redeem:ctor()
	FRAME_redeem.super.ctor(self, "frame_redeem")
	self:init()
end

function FRAME_redeem:init()
	self:initUI()
end

function FRAME_redeem:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local inputEB = self:createEditBoxOnComponent("eb_input")

	inputEB:setInputMode(6)

	local confirmPB = self:getComponentByTag("confirm_pb")

	confirmPB:toTouchable()
	confirmPB:setTapGroup("button_click")
	confirmPB:addTap(function ()
		local code = inputEB:getText()

		if empty(code) then
			Alert.open(Localization.getSrcText("请输入兑换码"))

			return
		end

		InfoUser.redeem(code, function (rcvData)
			local rewards = rcvData.rewards

			if rewards and #rewards > 0 then
				POP_reward.openMixed(rewards, function ()
					PopManager.close()
				end)
			else
				PopManager.close()
			end
		end)
	end)
end

return FRAME_redeem
