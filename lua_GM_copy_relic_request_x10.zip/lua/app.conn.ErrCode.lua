local ErrCode = {
	init = function ()
	end
}

app:addToAppEnterCall(ErrCode.init)

function ErrCode.getDesc(csv)
	local lang = Localization.getLang()

	return csv[lang]
end

function ErrCode.getMsg(code)
	local csv = CsvParser.getCsvData("err_code", code)

	if csv then
		return ErrCode.getDesc(csv)
	end

	return ""
end

function ErrCode.onErr(err_msg)
	local err_arr = string.split(err_msg, ":")
	local err = err_arr[1] or err_msg
	local err_big = false

	if err_arr[2] == "big" then
		err_big = true
	end

	if global.isBenchmark then
		return
	end

	local codeMap = CsvParser.getCsvRaw("err_code")

	if err == "prepare event already_completed" then
		return
	end

	if app.inScene then
		if codeMap and codeMap[err] then
			local desc = ErrCode.getDesc(codeMap[err])

			if not empty(desc) then
				if err_big then
					POP_msg.open(desc, {
						align = Style.center
					})
				else
					Alert.open(desc)
				end
			elseif DEV_MODE then
				if err_big then
					POP_msg.open(err, {
						align = Style.center
					})
				else
					Alert.open(err)
				end
			end
		elseif DEV_MODE then
			if err_big then
				POP_msg.open(err, {
					align = Style.center
				})
			else
				Alert.open(err)
			end
		end
	end
end

return ErrCode
