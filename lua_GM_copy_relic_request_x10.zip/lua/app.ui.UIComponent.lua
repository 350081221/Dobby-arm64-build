local SCALE_NONE = 0
local SCALE_3V = 1
local SCALE_3H = 2
local SCALE_9 = 3
local MULTI_NONE = 0
local MULTI_V = 1
local MULTI_H = 2
local UIComponent = class("UIComponent", function (data, layoutData, bigScale, bigDisplay)
	layoutData = layoutData or {}
	local multiArr = string.split(data.origin.multi, "^")
	local multiType = tonumber(multiArr[1])
	local multiNum = tonumber(multiArr[2]) or 1
	local scaleType = data.origin.scale
	local picurl = data.origin.pic
	local params = nil

	if data.origin.params ~= nil then
		params = string.split(data.origin.params, "^")
	end

	local texture = nil
	local textureGroup = string.split(data.origin.pic, "@")

	if #textureGroup == 2 then
		local groupName = textureGroup[1]
		local picName = textureGroup[2]

		UIManager.addSpriteFrames(groupName)

		texture = "#" .. picName
	elseif multiType == MULTI_NONE then
		texture = getFinalRes("ui/" .. data.origin.pic)
	else
		UIManager.addSpriteFrames(data.origin.pic)

		texture = "#" .. data.origin.pic .. "_frame_0"
	end

	local sprite = nil

	if scaleType == SCALE_NONE then
		sprite = display.newSprite(texture, data.x + data.width / 2, data.y + data.height / 2)
	else
		local scale9Sprites = {}

		for i = 1, multiNum do
			local textureGroup = string.split(data.origin.pic, "@")

			if #textureGroup == 2 then
				local picName = textureGroup[2]
				texture = "#" .. picName
			elseif multiType ~= MULTI_NONE then
				texture = "#" .. data.origin.pic .. "_frame_" .. i - 1
			end

			local scale9Sprite = display.newScale9Sprite(texture)

			if scaleType == SCALE_9 then
				if params ~= nil then
					scale9Sprite:setCapInsets(cc.rect(params[1], params[3], params[2] - params[1], params[4] - params[3]))
				else
					local size = scale9Sprite:getContentSize()
					local cap1 = math.ceil(size.width / 2) - 1
					local cap2 = size.width - cap1
					local cap3 = math.ceil(size.height / 2) - 1
					local cap4 = size.height - cap3

					scale9Sprite:setCapInsets(cc.rect(cap1, cap3, cap2 - cap1, cap4 - cap3))
				end
			elseif scaleType == SCALE_3H then
				local size = scale9Sprite:getContentSize()

				if params ~= nil then
					scale9Sprite:setCapInsets(cc.rect(params[1], 0, params[2] - params[1], size.height))
				else
					local cap1 = math.ceil(size.width / 2) - 1
					local cap2 = size.width - cap1

					scale9Sprite:setCapInsets(cc.rect(cap1, 0, cap2 - cap1, size.height))
				end
			elseif scaleType == SCALE_3V then
				local size = scale9Sprite:getContentSize()

				if params ~= nil then
					scale9Sprite:setCapInsets(cc.rect(0, params[1], size.width, params[2] - params[1]))
				else
					local cap1 = math.ceil(size.height / 2) - 1
					local cap2 = size.height - cap1

					scale9Sprite:setCapInsets(cc.rect(0, cap1, size.width, cap2 - cap1))
				end
			end

			scale9Sprite:setContentSize(cc.size(data.width, data.height))
			scale9Sprite:setPosition(data.width / 2, data.height / 2)
			table.insert(scale9Sprites, scale9Sprite)
		end

		sprite = display.newNode()

		for i = 1, multiNum do
			sprite:addChild(scale9Sprites[i])

			if i ~= 1 then
				scale9Sprites[i]:setVisible(false)
			end
		end

		sprite.frames = scale9Sprites

		sprite:setAnchorPoint(cc.p(0.5, 0.5))
		sprite:setContentSize(cc.size(data.width, data.height))
		sprite:setPosition(data.x + data.width / 2, data.y + data.height / 2)
	end

	sprite.texture = texture

	return sprite
end)

function UIComponent:getDefaultPosition()
	return self.x + self.width / 2, self.y + self.height / 2
end

function UIComponent:ctor(data, layoutData, bigType, bigScale, bigDisplay)
	layoutData = layoutData or {}

	self:setTouchSwallowEnabled(false)
	self:setCascadeOpacityEnabled(true)
	self:setCascadeColorEnabled(true)
	event_listener.extendMethods(self, true)

	local multiArr = string.split(data.origin.multi, "^")
	local multiType = tonumber(multiArr[1])
	local multiNum = tonumber(multiArr[2]) or 1
	local scaleType = data.origin.scale
	local picurl = data.origin.pic
	self.multiType = multiType
	self.multiNum = multiNum
	self.scaleType = scaleType
	self.frames = self.frames or {}
	self.picurl = data.origin.pic
	self.frame = 1
	self.x = data.x
	self.y = data.y
	self.width = data.width
	self.height = data.height
	self.originalWidth = data.width
	self.originalHeight = data.height
	self.originalX = data.x
	self.originalY = data.y
	self.tag = data.tag
	self.scale = data.scale
	self.buttonIcon = nil

	if data.label then
		self:addLabelParams(data.label)
	end

	if data.shader and Shader then
		if self.scaleType ~= SCALE_NONE then
			local sprite = self:drawScale9Sprite()

			Shader.custom(sprite, data.shader.shader)
		else
			Shader.custom(self, data.shader.shader)
		end
	end

	if layoutData.isFrame == 1 then
		if data.widget and data.widget.widget ~= "" then
			self.scale = 0
			self.widget = {}
			local widgetArr = string.split(data.widget.widget, ",")

			for i, way in ipairs(widgetArr) do
				way = tonumber(way)
				self.widget[way] = true
			end
		end

		local x = data.x
		local y = data.y
		local w = data.width
		local h = data.height

		if CONFIG_SCREEN_AUTOSCALE == "FIXED_HEIGHT" then
			fromWidth = UIManager.design.width
			toWidth = display.width

			if bigDisplay then
				toWidth = bigDisplay.width
			end

			if bigScale then
				if bigType == UIManager.BIG_TYPE.FULL then
					y = (y + h / 2) / bigScale - h / 2 * bigScale
				elseif bigType == UIManager.BIG_TYPE.TOP then
					y = y + bigDisplay.height * (1 / bigScale - 1)
				elseif bigType == UIManager.BIG_TYPE.POP then
					y = y + math.min(64, bigDisplay.height * (1 / bigScale - 1) / 2)
					self.originalY = self.originalY + math.min(64, bigDisplay.height * (1 / bigScale - 1) / 2)
				elseif bigType == UIManager.BIG_TYPE.CENTER then
					y = y + bigDisplay.height * (1 / bigScale - 1) / 2
				end
			end

			if self.widget then
				if self.widget[2] and self.widget[4] then
					w = w + toWidth - fromWidth

					if bigType == UIManager.BIG_TYPE.POP then
						if UIManager.getLiuhai() == "left" then
							x = x + UIManager.LIUHAI_WIDTH
							w = w - UIManager.LIUHAI_WIDTH
						elseif UIManager.getLiuhai() == "right" then
							w = w - UIManager.LIUHAI_WIDTH
						end
					end
				elseif self.widget[2] then
					x = x + toWidth - fromWidth

					if bigType == UIManager.BIG_TYPE.POP and UIManager.getLiuhai() == "right" then
						x = x - UIManager.LIUHAI_WIDTH
					end
				elseif self.widget[4] then
					if bigType == UIManager.BIG_TYPE.POP and UIManager.getLiuhai() == "left" then
						x = x + UIManager.LIUHAI_WIDTH
					end
				else
					x = x + (toWidth - fromWidth) / 2
				end
			else
				x = x + (toWidth - fromWidth) / 2
			end
		elseif CONFIG_SCREEN_AUTOSCALE == "FIXED_WIDTH" then
			fromHeight = UIManager.design.height
			toHeight = display.height

			if bigDisplay then
				toHeight = bigDisplay.height
			end

			if bigScale then
				if bigType == UIManager.BIG_TYPE.FULL then
					x = (x + w / 2) / bigScale - w / 2 * bigScale
				elseif bigType == UIManager.BIG_TYPE.TOP then
					x = x + bigDisplay.width * (1 / bigScale - 1)
				end
			end

			if self.widget then
				if self.widget[1] and self.widget[3] then
					y = y + (toHeight - fromHeight) / 2
					h = h + toHeight - fromHeight
				elseif self.widget[1] then
					y = y + toHeight - fromHeight
				elseif not self.widget[3] then
					y = y + (toHeight - fromHeight) / 2
				end
			else
				y = y + (toHeight - fromHeight) / 2
			end
		end

		self.x = x
		self.y = y
		self.width = w
		self.height = h

		self:setPosition(x + w / 2, y + h / 2)

		if self.scaleType ~= SCALE_NONE then
			for i = 1, #self.frames do
				self.frames[i]:setContentSize(cc.size(w, h))
				self.frames[i]:setPosition(w / 2, h / 2)
			end

			self:setContentSize(cc.size(w, h))
		else
			self:setContentSize(cc.size(w, h))
		end
	end
end

function UIComponent:drawScale9Sprite()
	local textureKey = "UI_scale9Sprite_" .. self.texture .. "_" .. self.width .. "_" .. self.height
	local x, y = self.frames[1]:getPosition()
	local anchor = self.frames[1]:getAnchorPoint()
	local texture = cc.Director:getInstance():getTextureCache():getTextureForKey(textureKey)

	if not texture then
		self.frames[1]:setAnchorPoint(cc.p(0, 0))
		self.frames[1]:setPosition(0, 0)

		local renderTexture = cc.RenderTexture:create(self.width, self.height)

		renderTexture:begin()
		self.frames[1]:visit()
		renderTexture:endToLua()
		cc.Director:getInstance():flushScene()

		local renderImage = renderTexture:newImage()
		texture = cc.Director:getInstance():getTextureCache():addImage(renderImage, textureKey)
	end

	local sprite = display.newSprite(texture)

	sprite:setAnchorPoint(anchor)
	sprite:setPosition(x, y)
	self:addChild(sprite, self.frames[1]:getLocalZOrder())

	for i, frame in ipairs(self.frames) do
		frame:removeSelf()
	end

	self.frames = {}

	return sprite
end

local align_array = {
	Style.left,
	Style.center,
	Style.right
}

function UIComponent:addLabelParams(labelParams)
	self.labelStyle = {
		size = labelParams.size,
		color = cc.c4b(labelParams.color[1], labelParams.color[2], labelParams.color[3], 255),
		align = align_array[labelParams.align],
		outline = labelParams.outlineSize,
		outlineColor = cc.c4b(labelParams.outlineColor[1], labelParams.outlineColor[2], labelParams.outlineColor[3], 255),
		offsetX = labelParams.offsetX,
		offsetY = labelParams.offsetY,
		opacity = labelParams.opacity
	}

	if labelParams.text ~= "" then
		self.originalText = labelParams.text
		local text = Localization.getUiText(self.originalText)

		self:addLabel(text)
	end
end

function UIComponent:setFrame(index)
	if index < 1 then
		return
	end

	if self.frame ~= index then
		self.frame = index

		if self.scaleType == SCALE_NONE then
			local spriteFrame = display.newSpriteFrame(self.picurl .. "_frame_" .. index - 1)

			if spriteFrame then
				self:setSpriteFrame(spriteFrame)
			end
		else
			if not self.frames[index] then
				return
			end

			for i = 1, #self.frames do
				local scale9Sprite = self.frames[i]

				if i == index then
					scale9Sprite:setVisible(true)
				else
					scale9Sprite:setVisible(false)
				end
			end
		end

		self:adjustLabelOffsetByFrame()
	end
end

function UIComponent:adjustLabelOffsetByFrame()
	if self.labelOffsetByFrames and self.label then
		local offset = self.labelOffsetByFrames[self.frame]
		local style = self.labelStyle
		local size = style.size or 32
		local align = style.align or Style.center
		local valign = style.valign or Style.vcenter
		local offsetX = style.offsetX or 0
		local offsetY = style.offsetY or 0
		local x = 0
		local y = 0

		if align == Style.center then
			x = x + self.width / 2
		elseif align == Style.right then
			x = x + self.width
		end

		if valign == Style.vtop then
			y = y + size / 2
		elseif valign == Style.vcenter then
			y = y + self.height / 2
		elseif valign == Style.vbottom then
			y = y - size / 2
		end

		x = x + offset.x
		y = y + offset.y

		if offset then
			self.label:setPosition(x, y)
		end
	end
end

function UIComponent:resetLabel(style, zorder)
	if self.text then
		self:addLabel(self.text, style, zorder)
	end
end

function UIComponent:addLabel(text, style, zorder)
	self:removeLabel()

	self.text = text
	local __style = self.labelStyle or {}

	if style then
		for k, v in pairs(style) do
			__style[k] = v
		end
	end

	local label, labelWidth, labelHeight = UIManager.createLabel(0, 0, self.width, self.height, text, __style)
	self.label = label
	self.labelWidth = labelWidth

	if zorder then
		self:addChild(label, zorder)
	else
		self:addChild(label)
	end

	return label, labelWidth, labelHeight
end

function UIComponent:removeLabel()
	if self.label then
		self.label:removeSelf()

		self.label = nil
	end
end

function UIComponent:setLabelOffsetByFrames(...)
	self.labelOffsetByFrames = {
		...
	}

	self:adjustLabelOffsetByFrame()
end

function UIComponent:removeTouchable()
	if self._isTouchable then
		self:setTouchSwallowEnabled(false)

		self._isTouchable = nil

		self:removeNodeEventListener(cc.NODE_TOUCH_EVENT)
		self:setTouchEnabled(false)
	end
end

function UIComponent:toTouchable()
	if not self._isTouchable then
		self:setTouchSwallowEnabled(true)

		self._isTouchable = true

		self:addNodeEventListener(cc.NODE_TOUCH_EVENT, function (event)
			local eventName = event.name

			if eventName == "cancelled" then
				eventName = "ended"
			end

			return self:onTouch(eventName, event.x, event.y)
		end)
		self:setTouchEnabled(true)
	end
end

function UIComponent:forceTouch(event, x, y)
	if self.touchHandler and event then
		self:onTouch(event, x, y)
	end
end

function UIComponent:forceTap(x, y)
	if self.tapHandler then
		self.tapHandler(x, y)
	end
end

function UIComponent:addTouch(handler)
	self.touchHandler = handler
end

function UIComponent:removeTouch()
	self.touchHandler = nil
end

function UIComponent:addTap(handler)
	self.tapHandler = handler
end

function UIComponent:removeTap()
	self.tapHandler = nil
end

function UIComponent:clearTouch()
	self.touchHandler = nil
	self.tapHandler = nil
end

function UIComponent:onTouch(event, x, y)
	local touchOver = nil

	local function getTouchOver()
		if touchOver == nil then
			local pos = cc.p(x, y)
			pos = self:getParent():convertToNodeSpace(pos)
			local comX, comY = self:getPosition()

			if pos.x >= comX - self.width / 2 and pos.x <= comX + self.width / 2 and pos.y >= comY - self.height / 2 and pos.y <= comY + self.height / 2 then
				touchOver = true
			else
				touchOver = false
			end

			return touchOver
		else
			return touchOver
		end
	end

	UIManager.callTapCallbackTouch(self.tapGroupName, self.customTapTarget or self, event)

	if event == "ended" and self.tapHandler and getTouchOver() then
		UIManager.callTapCallback(self.tapGroupName, self.customTapTarget or self)

		if not UIManager.isLocked() then
			self.tapHandler(x, y)
		end
	end

	if self.touchHandler and not UIManager.isLocked() then
		self.touchHandler(event, x, y)
	end

	return true
end

function UIComponent:getTouchOver(x, y)
	local pos = cc.p(x, y)
	pos = self:getParent():convertToNodeSpace(pos)
	local comX, comY = self:getPosition()

	if pos.x >= comX - self.width / 2 and pos.x <= comX + self.width / 2 and pos.y >= comY - self.height / 2 and pos.y <= comY + self.height / 2 then
		return true
	else
		return false
	end
end

function UIComponent:getGlobalPosition()
	local x, y = self:getPosition()
	local pos = cc.p(x, y)
	pos = self:getParent():convertToWorldSpace(pos)

	return pos.x - self.width / 2, pos.y + self.height / 2
end

function UIComponent:clearIcon()
	if self.icon ~= nil then
		local icon = self.icon
		self.icon = nil

		icon:removeSelf()
	end
end

function UIComponent:setPos(x, y)
	self.x = x or self.x
	self.y = y or self.y

	self:setPosition(self.x + self.width / 2, self.y + self.height / 2)
end

function UIComponent:setSize(w, h, noSetPosition)
	self.width = w or self.width
	self.height = h or self.height

	if self.scaleType ~= SCALE_NONE then
		for i = 1, #self.frames do
			self.frames[i]:setContentSize(cc.size(self.width, self.height))
			self.frames[i]:setPosition(self.width / 2, self.height / 2)
		end

		self:setContentSize(cc.size(self.width, self.height))
	else
		self:setContentSize(cc.size(self.width, self.height))
	end

	if not noSetPosition then
		self:setPosition(self.x + self.width / 2, self.y + self.height / 2)
	end
end

function UIComponent:setIcon(urlOrSprite, autoScale, indent)
	self:clearIcon()

	if tolua.type(urlOrSprite) == "string" then
		self.icon = display.newSprite(urlOrSprite)
	else
		self.icon = urlOrSprite
	end

	local anchor = self:getAnchorPoint()

	self.icon:setPosition(self.width * anchor.x, self.height * anchor.y)
	self:addChild(self.icon)

	if autoScale then
		indent = indent or 0
		local size = self.icon:getContentSize()

		self.icon:setScaleX((self.width - indent * 2) / size.width)
		self.icon:setScaleY((self.height - indent * 2) / size.height)
	end

	return self.icon
end

function UIComponent:addIcon(icon, zorder)
	self:removeIcon()
	self:addChild(icon, zorder or 0)

	self.icon = icon

	return icon
end

function UIComponent:removeIcon()
	if self.icon then
		self.icon:removeSelf()

		self.icon = nil
	end
end

function UIComponent:createIcon(texture, fixedSize, zorder, scaleMode)
	scaleMode = scaleMode or 2
	local icon = display.newSprite(texture, self.width / 2, self.height / 2)
	local size = icon:getContentSize()

	if fixedSize then
		if scaleMode == 3 then
			icon:setScaleX(fixedSize.width / size.width)
			icon:setScaleY(fixedSize.height / size.height)
		elseif scaleMode == 2 or fixedSize.width < size.width and fixedSize.height < size.height then
			local ratio = size.width / size.height
			local fixedRatio = fixedSize.width / fixedSize.height
			local scale = nil

			if fixedRatio < ratio then
				scale = fixedSize.width / size.width
			else
				scale = fixedSize.height / size.height
			end

			icon:setScaleX(scale)
			icon:setScaleY(scale)
		end
	end

	return self:setIcon(icon)
end

function UIComponent:getIcon()
	return self.icon
end

function UIComponent:refreshLocalization()
	if self.originalText then
		local text = Localization.getUiText(self.originalText)

		self:addLabel(text)
	end
end

function UIComponent:setTapGroup(groupName, customTapTarget)
	self.tapGroupName = groupName
	self.customTapTarget = customTapTarget
end

function UIComponent:onEnter()
end

function UIComponent:onExit()
	self:clearIcon()

	self.touchHandler = nil
	self.tapHandler = nil

	self:setTouchEnabled(false)
	self:removeAllNodeEventListeners()

	if self.componentType == "radio" then
		local group = radioGroups[self.radioGroup]

		for i = 1, #group do
			if group[i] == self then
				table.remove(group, i)

				break
			end
		end
	end
end

return UIComponent
