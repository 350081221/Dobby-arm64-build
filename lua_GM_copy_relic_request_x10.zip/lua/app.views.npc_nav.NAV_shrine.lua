local NAV_base = import(".NAV_base")
local NAV_shrine = class("NAV_shrine", NAV_base)

function NAV_shrine.open(npc)
	local ui = NAV_shrine.new(npc)

	return ui
end

function NAV_shrine:ctor(npc)
	NAV_shrine.super.ctor(self, npc, "nav_shrine")
end

function NAV_shrine:init()
	NAV_shrine.super.init(self)

	local index = 1
	local ui = self.buttons[index].ui
	local button = self.buttons[index].button

	self:setButtonName(ui, self.npc.data.name)

	if not empty(self.npc.data.read_time) and self.npc.data.read_time > 0 then
		self:openTouch()
	end

	if not empty(self.npc.data.show_desc) then
		self:addButtonInfo(1, self.npc.data.show_desc)
	end
end

function NAV_shrine:onTouch(event, index)
	NAV_shrine.super.onTouch(self, event, index)

	if index == 1 and not empty(self.npc.data.read_time) and self.npc.data.read_time > 0 then
		if event == "began" and global.player then
			global.player:faceTo(self.npc)
		end

		self:onRead(event, self.npc.data.read_msg, MiscConfig.sfx_shrine_read, MiscConfig.sfx_shrine_active, function ()
			if self.npc then
				self.npc:openShrine()
			end
		end)
	end
end

function NAV_shrine:onTap(index)
	NAV_shrine.super.onTap(self, index)

	if index == 1 and empty(self.npc.data.read_time) then
		if global.player then
			global.player:faceTo(self.npc)
		end

		self.npc:openShrine()
	end
end

return NAV_shrine
