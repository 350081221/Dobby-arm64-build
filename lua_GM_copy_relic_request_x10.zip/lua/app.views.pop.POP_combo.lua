local POP_combo = class("POP_combo", UI_base)
local FADEOUT_TIME = 60
local RECOUNT_TIME = 30

function POP_combo:ctor(rect)
	POP_combo.super.ctor(self, "pop_combo")

	self.rect = rect

	self:init()
end

function POP_combo:init()
	self:initUI()

	self.comboCount = 0
	self.comboBest = 0
	self.damageCount = 0
	self.damageBest = 0

	notify.safeRegister(self, "skill_hit", function (caster, unit, affectPack, dmgValue)
		self:onSkillHit(caster, unit, affectPack, dmgValue)
	end)
	notify.safeRegister(self, "battle_over", function ()
		self:comboOver()
	end)
end

function POP_combo:initUI()
	self:setAnchorPoint(cc.p(0.5, 0.5))
end

function POP_combo:onSkillHit(caster, unit, affectPack, dmgValue)
	if caster and unit and caster.battleData and unit.battleData and caster.battleData.camp == 1 and unit.battleData.camp == 2 and dmgValue and dmgValue > 0 then
		self:addCombo(dmgValue)
	end
end

function POP_combo:addCombo(dmgValue)
	self.comboCount = self.comboCount + 1
	self.damageCount = self.damageCount + dmgValue

	if self.comboBest <= self.comboCount then
		if self.comboBest < self.comboCount then
			self.comboBest = self.comboCount
			self.damageBest = self.damageCount

			self:replaceLabelOnFlag("flag_text", nil, self.comboBest)
			self:replaceLabelOnFlag("flag_damage", nil, self.damageBest)

			if self.comboBest == 3 then
				self:fadeIn()
			end
		end

		self:startTimeoutCount()

		if self.comboBest > 2 then
			self:setScale(1.5)
			transition.scaleTo(self, {
				time = 0.05,
				easing = "sineOut",
				scale = 1
			})
		end
	end
end

function POP_combo:startTimeoutCount()
	self.timeoutStart = MapFrameManager.getFrame()

	MapFrameManager.startLoop(self, self.timeoutLoop)
end

function POP_combo:stopTimeoutCount()
	MapFrameManager.stopLoop(self, self.timeoutLoop)
end

function POP_combo:timeoutLoop(frame, passed, sharp)
	if RECOUNT_TIME < frame - self.timeoutStart then
		self.comboCount = 0
		self.damageCount = 0
	end

	if FADEOUT_TIME < frame - self.timeoutStart then
		self:comboOver()
	end
end

function POP_combo:comboOver()
	self.comboCount = 0
	self.comboBest = 0
	self.damageCount = 0
	self.damageBest = 0

	self:stopTimeoutCount()
	self:fadeOut()
	self:setScale(1)
end

function POP_combo:fadeIn()
	transition.stopTarget(self)

	local xOffset = 0

	if UIManager.getLiuhai() == "left" then
		xOffset = UIManager.LIUHAI_WIDTH
	end

	transition.moveTo(self, {
		time = 0.05,
		easing = "sineOut",
		x = self.rect.width / 2 + xOffset
	})
end

function POP_combo:fadeOut()
	transition.stopTarget(self)
	transition.moveTo(self, {
		time = 0.2,
		easing = "sineOut",
		x = -self.rect.width / 2
	})
end

return POP_combo
