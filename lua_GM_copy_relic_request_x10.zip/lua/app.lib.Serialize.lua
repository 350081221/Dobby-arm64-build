local M = {}

function M.serialize(obj, nest)
	nest = nest or 1
	local lua = ""
	local t = type(obj)

	if t == "number" then
		lua = lua .. obj
	elseif t == "boolean" then
		lua = lua .. tostring(obj)
	elseif t == "string" then
		lua = lua .. string.format("%q", obj)
	elseif t == "table" then
		lua = lua .. "{\n"
		local infoAry = {}

		for k, v in pairs(obj) do
			table.insert(infoAry, {
				key = k,
				val = v
			})
		end

		table.sort(infoAry, function (infoA, infoB)
			return tostring(infoA.key) < tostring(infoB.key)
		end)

		local tab = ""

		for var = 1, nest do
			tab = tab .. "    "
		end

		for _, info in ipairs(infoAry) do
			lua = lua .. tab .. "[" .. M.serialize(info.key, nest + 1) .. "]=" .. M.serialize(info.val, nest + 1) .. ",\n"
		end

		local metatable = getmetatable(obj)

		if metatable ~= nil and type(metatable.__index) == "table" then
			for k, v in pairs(metatable.__index) do
				for var = 1, nest do
					lua = lua .. "    "
				end

				lua = lua .. "[" .. M.serialize(k, nest + 1) .. "]=" .. M.serialize(v, nest + 1) .. ",\n"
			end
		end

		for var = 1, nest - 1 do
			lua = lua .. "    "
		end

		lua = lua .. "}"
	elseif t == "nil" then
		return nil
	else
		error("can not serialize a " .. t .. " type.")
	end

	return lua
end

function M.unserialize(lua)
	local t = type(lua)

	if t == "nil" or lua == "" then
		return nil
	elseif t == "number" or t == "string" or t == "boolean" then
		lua = tostring(lua)
	else
		error("can not unserialize a " .. t .. " type.")
	end

	local sBegan, sEnd = string.find(lua, "return", 1, true)

	if sBegan ~= 1 then
		lua = "return " .. lua
	end

	local func = loadstring(lua)

	if func == nil then
		return nil
	end

	return func()
end

return M
