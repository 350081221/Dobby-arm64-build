local OnlineRoom = {}

function OnlineRoom.init()
	Connection.listen("room_enter", OnlineRoom.onEnter)
	Connection.listen("room_exit", OnlineRoom.onExit)
	Connection.listen("room_ready", OnlineRoom.onReady)
	Connection.listen("room_countdown_start", OnlineRoom.onCountdownStart)
	Connection.listen("room_countdown_cancel", OnlineRoom.onCountdownCancel)
	Connection.listen("room_clear", OnlineRoom.onClear)
end

app:addToAppEnterCall(OnlineRoom.init)

local roomID = nil
local roomMap = {}
local onEnterListener, onExitListener, countdownTime = nil

function OnlineRoom.onEnter(data)
	dump(data, "$$$ OnlineRoom.onEnter")

	roomMap[data.user_id] = data

	notify.dispatch("room_player_change")
end

function OnlineRoom.onExit(data)
	dump(data, "$$$ OnlineRoom.onExit")

	roomMap[data.user_id] = nil

	notify.dispatch("room_player_change")
end

function OnlineRoom.onClear(data)
	dump(data, "$$$ OnlineRoom.onClear")
	notify.dispatch("room_clear")
end

function OnlineRoom.onReady(data)
	dump(data, "$$$ OnlineRoom.onReady")

	if roomMap[data.user_id] then
		roomMap[data.user_id].is_ready = data.is_ready
	end

	notify.dispatch("room_player_change")
end

function OnlineRoom.onCountdownStart(data)
	countdownTime = data.time

	notify.dispatch("room_countdown_change")
end

function OnlineRoom.onCountdownCancel(data)
	countdownTime = nil

	notify.dispatch("room_countdown_change")
end

function OnlineRoom.getCountdown()
	return countdownTime
end

function OnlineRoom.getList()
	local arr = {}

	for k, data in pairs(roomMap) do
		table.insert(arr, data)
	end

	table.sort(arr, function (a, b)
		return a.time < b.time
	end)

	return arr
end

function OnlineRoom.create(room_name, room_id, onSuccess, onFailure)
	OnlineRoom.enter(room_name, room_id, nil, 1, onSuccess, onFailure)
end

function OnlineRoom.join(room_name, room_id, inst_id, onSuccess, onFailure)
	OnlineRoom.enter(room_name, room_id, inst_id, nil, onSuccess, onFailure)
end

function OnlineRoom.match(room_name, room_id, onSuccess, onFailure)
	OnlineRoom.enter(room_name, room_id, nil, , onSuccess, onFailure)
end

function OnlineRoom.enter(room_name, room_id, inst_id, is_private, onSuccess, onFailure)
	roomMap = {}
	countdownTime = nil

	local function callback(rcvData)
		dump(rcvData, "$$$ room_enter")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			roomID = rcvData.room_id

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("room_enter", {
		room_name = room_name,
		room_id = room_id,
		inst_id = inst_id,
		is_private = is_private
	}, callback)
end

function OnlineRoom.exit(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ room_exit")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			roomID = nil
			roomMap = {}
			countdownTime = nil

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("room_exit", callback)
end

function OnlineRoom.ready(is_ready, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ room_ready")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("room_ready", {
		is_ready = is_ready
	}, callback)
end

function OnlineRoom.setRoomID(id)
	roomID = id
end

function OnlineRoom.clear()
	roomMap = {}
	countdownTime = nil
end

return OnlineRoom
