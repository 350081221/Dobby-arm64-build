local InfoSigil = {}
local rawData = {}
local disableColor = cc.c4b(168, 40, 13, 255)
InfoSigil.disableColor = disableColor

function InfoSigil.init()
	Connection.listen("sigil_sync", InfoSigil.sync)
	Connection.listen("sigil_sync_remove", InfoSigil.syncRemove)
end

app:addToAppEnterCall(InfoSigil.init)

function InfoSigil.query(onSuccess, onFailure)
	rawData = {}
	local nextIndex, queryNext = nil

	function queryNext()
		local function callback(rcvData)
			dump(rcvData, "sigil_query")

			if rcvData.err then
				if onFailure then
					onFailure()
				end
			else
				for i, data in ipairs(rcvData.list) do
					if data.base_id ~= 0 then
						rawData[data.id] = data
					end
				end

				if rcvData.next_index then
					nextIndex = rcvData.next_index

					queryNext()
				elseif onSuccess then
					onSuccess()
				end
			end
		end

		Connection.request("sigil_query", {
			start_index = nextIndex
		}, callback)
	end

	queryNext()
end

function InfoSigil.sync(data)
	dump(data, "$$$ InfoSigil.sync")

	local changedIdStack = {}

	for i, syncData in ipairs(data.list) do
		if syncData.base_id ~= 0 then
			local id = syncData.id

			if not rawData[id] then
				rawData[id] = syncData
			else
				for k, v in pairs(syncData) do
					rawData[id][k] = v
				end
			end

			changedIdStack[id] = rawData[id]
		end
	end

	ManagerInfo.dataChange("sigil", changedIdStack)
end

function InfoSigil.syncRemove(data)
	dump(data, "$$$ InfoSigil.syncRemove")

	local teamChanged = false
	local changedIdStack = {}

	for i, id in ipairs(data.list) do
		if rawData[id] then
			changedIdStack[id] = rawData[id]
			rawData[id] = nil
		end
	end

	ManagerInfo.dataChange("sigil", changedIdStack)
end

function InfoSigil.equipon(sigilID, heroID, pos, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ sigil_on")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("sigil_on", {
		hero_id = heroID,
		sigil_id = sigilID,
		pos = pos
	}, callback)
end

function InfoSigil.autoOff()
	local arr = {}
	local heroCache = {}

	for id, sigilInfo in pairs(rawData) do
		local heroInfo = InfoSigil.getEquipedHero(sigilInfo)

		if heroInfo then
			if not heroCache[heroInfo] then
				local setCsv = InfoHero.getSigilSet(heroInfo, true)

				if setCsv then
					heroCache[heroInfo] = setCsv.id
				else
					heroCache[heroInfo] = 0
				end
			end

			local maxPos = heroCache[heroInfo]

			if maxPos < sigilInfo.equip_pos then
				table.insert(arr, sigilInfo.id)
			end
		end
	end

	if #arr > 0 then
		dump(arr, "$$$ InfoSigil.autoOff")

		local count = 0

		for i, id in ipairs(arr) do
			InfoSigil.equipoff(id, function ()
				count = count + 1

				if count == #arr then
					Alert.open(Localization.getSrcText("已将未满足装备条件的魔纹卸下至仓库"))
				end
			end)
		end
	end
end

function InfoSigil.equipoff(sigilID, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ sigil_off")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("sigil_off", {
		sigil_id = sigilID
	}, callback)
end

function InfoSigil.lock(sigilID, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("sigil_lock", {
		sigil_id = sigilID
	}, callback)
end

function InfoSigil.fusion(ids, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("sigil_fusion", {
		ids = ids
	}, callback)
end

function InfoSigil.getInfo(id)
	return rawData[id]
end

function InfoSigil.getEquipedHero(sigilInfo)
	if not empty(sigilInfo.hero_id) then
		return InfoHero.getHero(sigilInfo.hero_id)
	end
end

function InfoSigil.getQuality(sigilInfo)
	return sigilInfo.quality
end

function InfoSigil.getUnsaved()
	local arr = {}

	for id, sigilInfo in pairs(rawData) do
		if sigilInfo.saved ~= 1 then
			table.insert(arr, sigilInfo)
		end
	end

	return arr
end

function InfoSigil.getIsnew()
	local arr = {}

	for id, sigilInfo in pairs(rawData) do
		if sigilInfo.is_new == 1 then
			table.insert(arr, sigilInfo)
		end
	end

	return arr
end

local scoreBuff = nil

function InfoSigil.buffScoreStart()
	scoreBuff = {}
end

function InfoSigil.buffScoreOver()
	scoreBuff = nil
end

function InfoSigil.getScore(sigilInfo, noEnhance, valueModify)
	if scoreBuff and scoreBuff[sigilInfo.id] then
		return scoreBuff[sigilInfo.id]
	end

	local attr = CombatAttr.getSigilAttr(sigilInfo)
	local attr_raw = CsvParser.getCsvRaw("attr")
	local addTotal = 0

	for k, v in pairs(attr_raw) do
		if attr[k] and v.ability_value1 ~= 0 then
			if valueModify then
				addTotal = addTotal + valueModify(k, attr[k] * v.ability_value1)
			else
				addTotal = addTotal + attr[k] * v.ability_value1
			end
		end
	end

	local score = math.floor(addTotal)

	if scoreBuff then
		scoreBuff[sigilInfo.id] = score
	end

	return score
end

local function defaultSort(a, b)
	local qualityA = a.info.quality
	local qualityB = b.info.quality

	if qualityA == qualityB then
		if a.info.level == b.info.level then
			local scoreA = InfoSigil.getScore(a.info)
			local scoreB = InfoSigil.getScore(b.info)

			if scoreA == scoreB then
				if a.info.base_id == b.info.base_id then
					return a.info.id < b.info.id
				else
					return a.info.base_id < b.info.base_id
				end
			else
				return scoreB < scoreA
			end
		else
			return b.info.level < a.info.level
		end
	else
		return qualityB < qualityA
	end
end

function InfoSigil.getWareList(filterFunc, sortFunc)
	local arr = {}

	for id, sigilInfo in pairs(rawData) do
		if not InfoSigil.getEquipedHero(sigilInfo) then
			local tempData = {
				type = DropManager.TYPE.SIGIL,
				info = sigilInfo
			}

			if not filterFunc or filterFunc(tempData) then
				table.insert(arr, tempData)
			end
		end
	end

	local sortMethod = sortFunc or defaultSort

	InfoSigil.buffScoreStart()
	table.sort(arr, sortMethod)
	InfoSigil.buffScoreOver()

	return arr
end

function InfoSigil.checkHeroOpen(heroInfo)
	local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)
	local sigil_job_level = CsvParser.getCsvData("config", "sigil_job_level").value

	return sigil_job_level <= heroCSV.job_level
end

function InfoSigil.getSigilList(heroInfo, isDisplay, isCopy)
	local arr = {}
	local displayArr = nil

	if isDisplay then
		displayArr = {}
	end

	local sigilSet = InfoHero.getSigilSet(heroInfo, isDisplay)

	if not sigilSet then
		return arr, displayArr
	end

	local sigilMax = CsvParser.getMaxID("sigil_set")
	local equipedMap = {}

	if isCopy or heroInfo.sigils then
		if heroInfo.sigils then
			for i, sigilInfo in pairs(heroInfo.sigils) do
				equipedMap[sigilInfo.equip_pos] = sigilInfo
			end
		end
	else
		for id, sigilInfo in pairs(rawData) do
			if sigilInfo.hero_id == heroInfo.id then
				equipedMap[sigilInfo.equip_pos] = sigilInfo
			end
		end
	end

	for pos = 1, sigilSet.id do
		if equipedMap[pos] then
			table.insert(arr, equipedMap[pos])
		end
	end

	if isDisplay then
		local colorMap = InfoSigil.getColorMap(heroInfo)

		for pos = 1, sigilSet.id do
			local c = colorMap[pos] or CsvParser.getCsvData("sigil_set", pos).color
			local csv = CsvParser.getCsvData("sigil_set", pos)

			table.insert(displayArr, {
				type = DropManager.TYPE.SIGIL,
				csv = csv,
				info = equipedMap[pos],
				color = c
			})
		end

		for pos = sigilSet.id + 1, math.min(sigilSet.id + 2, sigilMax) do
			local csv = CsvParser.getCsvData("sigil_set", pos)

			table.insert(displayArr, {
				locked = true,
				type = DropManager.TYPE.SIGIL,
				csv = csv
			})
		end
	end

	return arr, displayArr, sigilSet
end

function InfoSigil.getColorMap(heroInfo)
	local colorMap = {}

	if not empty(heroInfo.sigil_color) then
		local colorArr = string.split(heroInfo.sigil_color, ",")

		for pos, v in ipairs(colorArr) do
			local c = tonumber(v)

			if c then
				colorMap[pos] = c
			end
		end
	end

	return colorMap
end

function InfoSigil.checkEcho(sigilInfo, customHeroInfo)
	local heroInfo = customHeroInfo or InfoSigil.getEquipedHero(sigilInfo)
	local pos = sigilInfo.equip_pos

	if heroInfo and pos > 0 then
		local colorMap = InfoSigil.getColorMap(heroInfo)
		local c = colorMap[pos] or CsvParser.getCsvData("sigil_set", pos).color
		local sigilCSV = CsvParser.getCsvData("sigil", sigilInfo.base_id)

		return c == sigilCSV.color
	end

	return false
end

function InfoSigil.getSampleSigil(baseID, isMinLevel)
	local sigilInfo = {
		ran = 0,
		quality = 1,
		base_id = baseID,
		level = isMinLevel and InfoDungeon.getMinEquipLevel() or InfoDungeon.getMaxEquipLevel(),
		echo = 0,
		echo_ran = 0
	}

	for i = 1, GameConfig.sigil_affix_max do
		sigilInfo["prefix_" .. i] = 0
		sigilInfo["preran_" .. i] = 0
	end

	return sigilInfo
end

local shopList = nil
local shopRefreshIndex = 0

function InfoSigil.getShopLabels()
	return nil
end

function InfoSigil.clearOnReconnect()
	shopList = nil
end

function InfoSigil.getShopList(_callback)
	local needQuery = shopList == nil

	if needQuery then
		local function callback(rcvData)
			dump(rcvData, "sigil_shop_list")

			if rcvData.err then
				-- Nothing
			else
				shopRefreshIndex = shopRefreshIndex + 1
				shopList = rcvData.items

				if _callback then
					_callback(shopList)
				end
			end
		end

		Connection.request("sigil_shop_list", callback)
	else
		_callback(shopList)
	end
end

function InfoSigil.getShopItems()
	local abyssLevel = InfoDungeon.getAbyssMaxLevel()
	local arr = {}

	for i, v in ipairs(shopList) do
		local shopCSV = CsvParser.getCsvData("sigil_shop", v.shop_id, nil, true)

		if shopCSV and shopCSV.abyss_level_min <= abyssLevel and abyssLevel <= shopCSV.abyss_level_max and (v.soldout < shopCSV.times or not empty(shopCSV.refresh_type)) then
			table.insert(arr, v)
		end
	end

	table.sort(arr, function (a, b)
		local csvA = CsvParser.getCsvData("sigil_shop", a.shop_id)
		local csvB = CsvParser.getCsvData("sigil_shop", b.shop_id)
		local soldoutA = a.soldout < csvA.times and 1 or 0
		local soldoutB = b.soldout < csvB.times and 1 or 0

		if soldoutA == soldoutB then
			return a.shop_id < b.shop_id
		else
			return soldoutB < soldoutA
		end
	end)

	return arr
end

function InfoSigil.buy(shop_id, num, onSuccess, onFailure)
	local preIndex = shopRefreshIndex

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if rcvData.item then
				local item = rcvData.item

				if preIndex == shopRefreshIndex then
					for i, v in ipairs(shopList) do
						if v.shop_id == item.shop_id then
							for k1, v1 in pairs(item) do
								v[k1] = v1
							end
						end
					end
				end
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("sigil_shop_buy", {
		shop_id = shop_id,
		num = num
	}, callback)
end

function InfoSigil.getShopCSV()
	return "sigil_shop"
end

function InfoSigil.getCostNeed()
	return nil
end

function InfoSigil.getShopName()
	return "sigil"
end

function InfoSigil.getShopTime()
	return nil
end

function InfoSigil.getRefreshType()
	return nil
end

function InfoSigil.getRefreshDesc()
	return nil
end

function InfoSigil.getSupplyLabel(csv)
	if not empty(csv.refresh_type) then
		return RefreshManager.getDesc(csv.refresh_type)
	end

	return ""
end

function InfoSigil.count(notEquiped)
	local count = 0

	for id, sigilInfo in pairs(rawData) do
		if not notEquiped or not InfoSigil.getEquipedHero(sigilInfo) then
			count = count + 1
		end
	end

	local sigil_count_max = CsvParser.getCsvData("config", "sigil_count_max").value

	return count, sigil_count_max
end

return InfoSigil
