local InfoAbyssGift = {}
local rawData, shopList = nil
local shopRefreshIndex = 0

function InfoAbyssGift.init()
	Connection.listen("abyss_gift_sync", InfoAbyssGift.sync)
end

app:addToAppEnterCall(InfoAbyssGift.init)

function InfoAbyssGift.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			InfoAbyssGift.onQuery(rcvData)

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("abyss_gift_query", callback)
end

function InfoAbyssGift.onQuery(rcvData)
	rawData = rcvData
end

function InfoAbyssGift.sync(data)
	for k, v in pairs(data) do
		rawData[k] = v
	end

	ManagerInfo.dataChange("abyss_gift", data)
end

function InfoAbyssGift.getReward(id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("abyss_gift_get_reward", {
		id = id
	}, callback)
end

function InfoAbyssGift.getProgress()
	return rawData.progress or 0, GameConfig.abyss_gift_max
end

function InfoAbyssGift.getRewardCount()
	local rewardCount = 1

	if RefreshManager.checkTimePassed(RefreshManager.TYPE.ABYSS_GIFT, Time.now(), rawData.reward_time) then
		rewardCount = 0
	end

	return rewardCount
end

function InfoAbyssGift.getRewardList()
	local csvList = CsvParser.getCsvList("abyss_gift_reward")
	local abyssLevel = InfoDungeon.getAbyssMaxLevel()
	local arr = {}

	for i, csv in ipairs(csvList) do
		if csv.abyss_level_min <= abyssLevel and abyssLevel <= csv.abyss_level_max then
			table.insert(arr, csv)
		end
	end

	return arr
end

function InfoAbyssGift.getRewardModel()
	local csv = CsvParser.getCsvData("abyss_gift_reward", 1)

	return csv.model
end

function InfoAbyssGift.countRedot()
	local redotCount = 0

	if not InfoFunction.checkFuncOpen(10100) then
		return redotCount
	end

	local progress, max = InfoAbyssGift.getProgress()
	local rewardCount = InfoAbyssGift.getRewardCount()

	if max <= progress and rewardCount == 0 then
		redotCount = 1
	end

	return redotCount
end

function InfoAbyssGift.getShopLabels()
	local shopCSVList = CsvParser.getCsvList("abyss_gift_shop_label")

	return shopCSVList
end

function InfoAbyssGift.clearOnReconnect()
	shopList = nil
end

function InfoAbyssGift.getShopList(_callback)
	local needQuery = shopList == nil

	if not needQuery and rawData.shop_refresh_time < Time.now() then
		needQuery = true
	end

	if needQuery then
		local function callback(rcvData)
			if rcvData.err then
				-- Nothing
			else
				shopRefreshIndex = shopRefreshIndex + 1
				shopList = rcvData.items

				if _callback then
					_callback(shopList)
				end
			end
		end

		Connection.request("abyss_gift_shop_list", callback)
	else
		_callback(shopList)
	end
end

function InfoAbyssGift.getShopItems()
	local abyssLevel = InfoDungeon.getAbyssMaxLevel()
	local arr = {}
	local multiLabel = nil
	local shopCSVList = CsvParser.getCsvList("abyss_gift_shop_label")

	if #shopCSVList > 1 then
		local labelMap = {}

		for i, v in ipairs(shopList) do
			local shopCSV = CsvParser.getCsvData("abyss_gift_shop", v.shop_id, nil, true)

			if shopCSV and shopCSV.abyss_level_min <= abyssLevel and abyssLevel <= shopCSV.abyss_level_max and (shopCSV.no_supply ~= 1 or v.soldout < shopCSV.times) then
				if not labelMap[shopCSV.label] then
					labelMap[shopCSV.label] = {}
				end

				table.insert(labelMap[shopCSV.label], v)
			end
		end

		for i, v in ipairs(shopCSVList) do
			local itemArr = labelMap[v.id]

			if itemArr then
				table.sort(itemArr, function (a, b)
					return a.shop_id < b.shop_id
				end)

				local obj = {
					label = v,
					items = itemArr
				}

				table.insert(arr, obj)
			end
		end

		multiLabel = true
	else
		local abyssLevel = InfoDungeon.getAbyssMaxLevel()

		for i, v in ipairs(shopList) do
			local shopCSV = CsvParser.getCsvData("abyss_gift_shop", v.shop_id, nil, true)

			if shopCSV and shopCSV.abyss_level_min <= abyssLevel and abyssLevel <= shopCSV.abyss_level_max and (shopCSV.no_supply ~= 1 or v.soldout < shopCSV.times) then
				table.insert(arr, v)
			end
		end

		table.sort(arr, function (a, b)
			return a.shop_id < b.shop_id
		end)

		multiLabel = false
	end

	return arr, multiLabel
end

function InfoAbyssGift.buy(shop_id, num, onSuccess, onFailure)
	local preIndex = shopRefreshIndex

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if rcvData.item then
				local item = rcvData.item

				if preIndex == shopRefreshIndex then
					for i, v in ipairs(shopList) do
						if v.shop_id == item.shop_id then
							for k1, v1 in pairs(item) do
								v[k1] = v1
							end
						end
					end
				end
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("abyss_gift_shop_buy", {
		shop_id = shop_id,
		num = num
	}, callback)
end

function InfoAbyssGift.getShopCSV()
	return "abyss_gift_shop"
end

function InfoAbyssGift.getCostNeed()
	return CsvParser.getCsvData("config", "abyss_gift_shop_need").value
end

function InfoAbyssGift.getShopName()
	return "abyss_gift"
end

function InfoAbyssGift.getShopTime()
	return rawData.shop_refresh_time, RefreshManager.getNextTime(RefreshManager.TYPE.ABYSS_GIFT_SHOP, Time.now())
end

function InfoAbyssGift.getRefreshType()
	return RefreshManager.TYPE.ABYSS_GIFT_SHOP
end

return InfoAbyssGift
