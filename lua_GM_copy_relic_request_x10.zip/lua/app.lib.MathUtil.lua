local MathUtil = {
	cutDigit = function (num, len)
		num = math.floor(num)
		local _len = string.len(tostring(num))

		if len < _len then
			local cutLen = _len - len
			local num10 = math.pow(10, cutLen)
			num = math.round(num / num10) * num10
		end

		return num
	end,
	angleWithinPI = function (angle)
		while math.pi < angle do
			angle = angle - math.floor(angle / (math.pi * 2) + 1) * math.pi * 2
		end

		while angle < -math.pi do
			angle = angle + math.floor(math.abs(angle) / (math.pi * 2) + 1) * math.pi * 2
		end

		return angle
	end
}

function MathUtil.integerDivision(totalNum, weightArr)
	local weightTotal = 0

	for i, weightNum in ipairs(weightArr) do
		weightTotal = weightTotal + weightNum
	end

	local nArr = {}
	local kArr = {}
	local nTotal = 0

	for i, weightNum in ipairs(weightArr) do
		local fnum = totalNum * weightNum / weightTotal
		local inum = math.floor(fnum)

		table.insert(nArr, inum)
		table.insert(kArr, {
			index = i,
			f = (fnum - inum) * weightNum / weightTotal,
			n = inum
		})

		nTotal = nTotal + inum
	end

	table.sort(kArr, function (a, b)
		if a.f == b.f then
			if a.n == b.n then
				return a.index < b.index
			else
				return a.n < b.n
			end
		else
			return b.f < a.f
		end
	end)

	local numLeft = totalNum - nTotal

	for i, kObj in ipairs(kArr) do
		if numLeft > 0 then
			nArr[kObj.index] = nArr[kObj.index] + 1
			numLeft = numLeft - 1
		else
			break
		end
	end

	return nArr
end

return MathUtil
