local CopyAttr = {}

function CopyAttr.getScore(copy)
	local totalScore = 0
	local attr_raw = CsvParser.getCsvRaw("attr")

	for heroPos, heroInfo in pairs(copy.hero) do
		local attrs = CopyAttr.getHeroAttr(heroInfo, copy)

		CombatAttr.finalize(attrs, nil, true)

		local addTotal = 0
		local multiTotal = 0

		for k, v in pairs(attr_raw) do
			if attrs[k] then
				if v.ability_value1 ~= 0 then
					addTotal = addTotal + attrs[k] * v.ability_value1
				end

				if v.ability_value2 ~= 0 then
					multiTotal = multiTotal + attrs[k] * v.ability_value2
				end
			end
		end

		local score = math.floor(addTotal * (1 + multiTotal))
		totalScore = totalScore + score
	end

	local petScore = 0

	for petPos, petInfo in pairs(copy.pet) do
		local attrs = CopyAttr.getPetAttr(petInfo)

		CombatAttr.finalize(attrs, nil, true)

		local addTotal = 0
		local multiTotal = 0

		for k, v in pairs(attr_raw) do
			if attrs[k] then
				if v.ability_value1 ~= 0 then
					addTotal = addTotal + attrs[k] * v.ability_value1
				end

				if v.ability_value2 ~= 0 then
					multiTotal = multiTotal + attrs[k] * v.ability_value2
				end
			end
		end

		local score = math.floor(addTotal * (1 + multiTotal))
		petScore = petScore + score
	end

	local pet_ability_ratio = CsvParser.getCsvData("config", "pet_ability_ratio").value
	petScore = math.floor(petScore * pet_ability_ratio)
	totalScore = totalScore + petScore

	return totalScore
end

function CopyAttr.getHeroScore(heroInfo, copy)
	local attrs = CopyAttr.getHeroAttr(heroInfo, copy)

	CombatAttr.finalize(attrs, nil, true)

	local attr_raw = CsvParser.getCsvRaw("attr")
	local addTotal = 0
	local multiTotal = 0

	for k, v in pairs(attr_raw) do
		if attrs[k] then
			if v.ability_value1 ~= 0 then
				addTotal = addTotal + attrs[k] * v.ability_value1
			end

			if v.ability_value2 ~= 0 then
				multiTotal = multiTotal + attrs[k] * v.ability_value2
			end
		end
	end

	local score = math.floor(addTotal * (1 + multiTotal))

	return score
end

function CopyAttr.getPetScore(petInfo)
	local attrs = CopyAttr.getPetAttr(petInfo)

	CombatAttr.finalize(attrs, nil, true)

	local attr_raw = CsvParser.getCsvRaw("attr")
	local addTotal = 0
	local multiTotal = 0

	for k, v in pairs(attr_raw) do
		if attrs[k] then
			if v.ability_value1 ~= 0 then
				addTotal = addTotal + attrs[k] * v.ability_value1
			end

			if v.ability_value2 ~= 0 then
				multiTotal = multiTotal + attrs[k] * v.ability_value2
			end
		end
	end

	local score = math.floor(addTotal * (1 + multiTotal))

	return score
end

local attrLevel = 1

function CopyAttr.setAttrLevel(level)
	attrLevel = level
end

function CopyAttr.getAttrLevel()
	return CsvParser.getCsvData("attr_level", attrLevel)
end

function CopyAttr.getHeroAttr(heroInfo, copy, attrLevel)
	local data = CopyAttr.getBodyAttr(heroInfo)
	local random = Random.new(heroInfo.seed)
	local qualityData = CsvParser.getCsvData("hero_quality", heroInfo.quality)

	for i, attrKey in ipairs(CombatAttr.attrs) do
		data[attrKey] = data[attrKey] * SheetUtil.getNumber(qualityData[attrKey .. "_ratio"], random)
		data[attrKey] = data[attrKey] + SheetUtil.getNumber(qualityData[attrKey .. "_add"], random)
	end

	local affixData = CsvParser.getCsvData("hero_affix", heroInfo.affix, nil, true)

	if affixData then
		for i, attrKey in ipairs(CombatAttr.attrs) do
			data[attrKey] = data[attrKey] * SheetUtil.getNumber(affixData[attrKey .. "_ratio"], random)
			data[attrKey] = data[attrKey] + SheetUtil.getNumber(affixData[attrKey .. "_add"], random)
		end

		local attrList = SheetUtil.getColumnList(affixData, {
			"attr_id",
			"attr_value"
		}, {
			"id",
			"value"
		})

		for i, v in ipairs(attrList) do
			if data[v.id] then
				data[v.id] = data[v.id] + v.value
			end
		end
	end

	local suitArr = CopyAttr.addEquipAttr(heroInfo.equips, data)
	local cardArr = CopyAttr.addCardAttr(heroInfo.cards, data)

	if copy.manual then
		for attr, value in pairs(copy.manual) do
			if data[attr] then
				data[attr] = data[attr] + value
			end
		end
	end

	local petAttrData = CopyAttr.getPetTohero(copy)

	CopyAttr.addPetPercent(petAttrData, data)
	CombatAttr.addPropConvert(data, attrLevel, suitArr, cardArr)

	local perkLevelCache, perkLevelPointCache, perkIdPointCache, perkPointIdCache = InfoHero.getPerkLevelCache()
	local _, perkMax = InfoHero.getPerkPoints(heroInfo)
	local perkMap = {}

	if not empty(heroInfo.perks) then
		local arr = string.split(heroInfo.perks, ",")

		for i, v in ipairs(arr) do
			local id = tonumber(v)

			if id then
				local points = perkIdPointCache[id]
				perkMap[points] = id
			end
		end
	end

	for i, v in ipairs(perkLevelCache) do
		if v.points <= perkMax then
			local id = perkMap[v.points]

			if not empty(id) then
				local csv = CsvParser.getCsvData("hero_peak_perk", id)
				local attrArr = SheetUtil.getColumnList(csv, {
					"attr_",
					"attr_value_"
				}, {
					"attr",
					"value"
				})

				for i1, v1 in ipairs(attrArr) do
					data[v1.attr] = (data[v1.attr] or 0) + v1.value
				end
			end
		else
			break
		end
	end

	local sigilArr = InfoSigil.getSigilList(heroInfo, nil, true)

	for i, sigilInfo in ipairs(sigilArr) do
		local sigilAttrs = CombatAttr.getSigilAttr(sigilInfo, nil, heroInfo)

		for attr, value in pairs(sigilAttrs) do
			if data[attr] then
				data[attr] = data[attr] + value
			end
		end
	end

	local artifactInfo = heroInfo.artifact
	local artifactStarCSV = nil

	if artifactInfo then
		local artifactAttrs, _skillStarCSV = CombatAttr.getArtifactAttr(artifactInfo, heroInfo)

		for attr, value in pairs(artifactAttrs) do
			if data[attr] then
				data[attr] = data[attr] + value
			end
		end

		artifactStarCSV = _skillStarCSV
	end

	for attr, v in pairs(data) do
		if not CombatAttr.isPercentAttr(attr) then
			data[attr] = math.floor(v)
		end
	end

	local dustSkillMap = {}
	local skillChangeMap = nil
	local dustProps = {
		"skill_cd_reduce",
		"skill_buff_exist_1",
		"skill_buff_exist_2",
		"skill_ignore_def",
		"skill_ignore_res"
	}

	if artifactStarCSV then
		local csv = artifactStarCSV

		if not empty(csv.skill_filter) then
			for j, prop in ipairs(dustProps) do
				if not empty(csv[prop]) then
					if not dustSkillMap[csv.skill_filter] then
						dustSkillMap[csv.skill_filter] = {}
					end

					if not dustSkillMap[csv.skill_filter].props then
						dustSkillMap[csv.skill_filter].props = {}
					end

					dustSkillMap[csv.skill_filter].props[prop] = (dustSkillMap[csv.skill_filter].props[prop] or 0) + csv[prop]
				end
			end

			local attrArr = SheetUtil.getColumnListFull(csv, {
				"skill_attr_",
				"skill_attr_value_"
			}, {
				"attr",
				"value"
			})

			if #attrArr > 0 then
				if not dustSkillMap[csv.skill_filter] then
					dustSkillMap[csv.skill_filter] = {}
				end

				if not dustSkillMap[csv.skill_filter].attrs then
					dustSkillMap[csv.skill_filter].attrs = {}
				end

				for j, v in ipairs(attrArr) do
					dustSkillMap[csv.skill_filter].attrs[v.attr] = (dustSkillMap[csv.skill_filter].attrs[v.attr] or 0) + v.value
				end
			end

			local attrLevelArr = SheetUtil.getColumnListFull(csv, {
				"skill_attr_add_level_",
				"skill_attr_value_add_level_"
			}, {
				"attr",
				"value"
			})

			if #attrLevelArr > 0 then
				if not dustSkillMap[csv.skill_filter] then
					dustSkillMap[csv.skill_filter] = {}
				end

				if not dustSkillMap[csv.skill_filter].attrs then
					dustSkillMap[csv.skill_filter].attrs = {}
				end

				for j, v in ipairs(attrLevelArr) do
					dustSkillMap[csv.skill_filter].attrs[v.attr] = (dustSkillMap[csv.skill_filter].attrs[v.attr] or 0) + v.value * artifactInfo.level
				end
			end

			if not empty(csv.skill_change) then
				skillChangeMap = skillChangeMap or {}
				skillChangeMap[csv.skill_filter] = csv.skill_change
			end
		end
	end

	return data, petAttrData, dustSkillMap, skillChangeMap
end

function CopyAttr.getPetTohero(copy)
	local data = {}

	if #copy.pet > 0 then
		local buildingCSV = InfoBuilding.getBuildingData(InfoBuilding.TAG.PET, copy.petBlv or 1)

		for i, petInfo in ipairs(copy.pet) do
			local qualityData = CsvParser.getCsvData("pet_quality", petInfo.quality)
			local attr_tohero = qualityData.attr_tohero
			attr_tohero = attr_tohero + buildingCSV.value4
			local petAttr = CopyAttr.getPetAttr(petInfo)

			for i, attrKey in ipairs(CombatAttr.attrs) do
				if not data[attrKey] then
					data[attrKey] = 0
				end

				data[attrKey] = data[attrKey] + petAttr[attrKey] * attr_tohero / 100
			end
		end

		for attr, v in pairs(data) do
			if not CombatAttr.isPercentAttr(attr) then
				data[attr] = math.floor(v)
			end
		end
	end

	return data
end

function CopyAttr.addPetPercent(petAttrData, data)
	for attr, value in pairs(petAttrData) do
		if data[attr] then
			data[attr] = data[attr] + value
		end
	end
end

function CopyAttr.getBodyAttr(heroInfo)
	local baseData = CsvParser.getCsvData("hero", heroInfo.base_id)
	local data = CombatAttr.defaultData(baseData, true)
	local baseNum = CsvParser.getCsvData("hero_base_num", heroInfo.level)

	for k, attr in pairs(CombatAttr.attrs) do
		local value = SheetUtil.getLinearNumber(baseData[attr .. "_ratio"], heroInfo[attr .. "_seed"] / 65536)
		data[attr] = value / 100 * baseNum[attr]
	end

	return data
end

function CopyAttr.addEquipAttr(equips, data)
	local suitMap = {}
	local suitExMap = {}
	local suitArr = {}

	for i = 1, GameConfig.max_equip do
		local equipInfo = equips[i]

		if equipInfo then
			local equipAttrData = CopyAttr.getEquipAttr(equipInfo)

			for attr, value in pairs(equipAttrData) do
				if data[attr] then
					data[attr] = data[attr] + value
				end
			end

			local equipData = CsvParser.getCsvData("equip", equipInfo.base_id)

			if not empty(equipData.suit_id) then
				if not suitMap[equipData.suit_id] then
					suitMap[equipData.suit_id] = 0
				end

				suitMap[equipData.suit_id] = suitMap[equipData.suit_id] + 1
			end

			if not empty(equipData.suit_excellent_id) and equipInfo.suit_excellent and equipInfo.suit_excellent > 0 then
				if not suitExMap[equipData.suit_excellent_id] then
					suitExMap[equipData.suit_excellent_id] = 0
				end

				suitExMap[equipData.suit_excellent_id] = suitExMap[equipData.suit_excellent_id] + 1
			end
		end
	end

	for suit_id, num in pairs(suitMap) do
		local suitCSV = CsvParser.getCsvData("suit", suit_id)
		local csv = CombatAttr.getSuitLevel(suit_id, math.min(suitCSV.suit_max, num))

		if csv then
			local attrList = SheetUtil.getColumnListFull(csv, {
				"attr_",
				"value_"
			}, {
				"attr",
				"value"
			})

			for j, v in ipairs(attrList) do
				if data[v.attr] then
					data[v.attr] = data[v.attr] + v.value
				end
			end

			table.insert(suitArr, csv)
		end
	end

	for suit_id, num in pairs(suitExMap) do
		local suitCSV = CsvParser.getCsvData("suit", suit_id)
		local csv = CombatAttr.getSuitExcellentLevel(suit_id, math.min(suitCSV.suit_max, num))

		if csv then
			local attrList = SheetUtil.getColumnListFull(csv, {
				"attr_",
				"value_"
			}, {
				"attr",
				"value"
			})

			for j, v in ipairs(attrList) do
				if data[v.attr] then
					data[v.attr] = data[v.attr] + v.value
				end
			end

			table.insert(suitArr, csv)
		end
	end

	local minEnhanceLevel = nil

	for i = 1, 4 do
		local equipInfo = equips[i]

		if equipInfo then
			if not minEnhanceLevel then
				minEnhanceLevel = equipInfo.enhance_level
			else
				minEnhanceLevel = math.min(minEnhanceLevel, equipInfo.enhance_level)
			end
		else
			minEnhanceLevel = 0

			break
		end
	end

	minEnhanceLevel = minEnhanceLevel or 0
	local enhanceCSV = CsvParser.getCsvData("enhance_base_num", minEnhanceLevel)
	local attrList = SheetUtil.getColumnList(enhanceCSV, {
		"enhance_attr_",
		"enhance_value_"
	}, {
		"attr",
		"value"
	})

	for j, v in ipairs(attrList) do
		if data[v.attr] then
			data[v.attr] = data[v.attr] + v.value
		end
	end

	return suitArr
end

function CopyAttr.addCardAttr(cards, data)
	local cardArr = {}

	for i = 1, GameConfig.max_card do
		local cardInfo = cards[i]

		if cardInfo then
			local cardAttrData = CombatAttr.getCardAttr(cardInfo)

			for attr, value in pairs(cardAttrData) do
				if data[attr] then
					data[attr] = data[attr] + value
				end
			end

			local cardExtraData = CombatAttr.getCardExtra(cardInfo)

			for attr, value in pairs(cardExtraData) do
				if data[attr] then
					data[attr] = data[attr] + value
				end
			end

			table.insert(cardArr, cardInfo)
		end
	end

	return cardArr
end

function CopyAttr.getAttrIndex(attr)
	if not CopyAttr.attrIndexMap then
		CopyAttr.attrIndexMap = {}
		local csvList = CsvParser.getCsvList("attr", "__line")

		for i, v in ipairs(csvList) do
			CopyAttr.attrIndexMap[v.id] = i
		end
	end

	return CopyAttr.attrIndexMap[attr]
end

function CopyAttr.getEquipAttr(equipInfo, isDisplay)
	local data = {}
	local dataForDisplay, mainAttr = nil

	if isDisplay then
		dataForDisplay = {}
		mainAttr = {}
	end

	local equipData = CsvParser.getCsvData("equip", equipInfo.base_id)
	local agenData = CsvParser.getCsvData("affix_gen", equipInfo.quality)
	local equipBaseNum = CsvParser.getCsvData("equip_base_num", equipInfo.level)
	local baseValue = {}
	local random = Random.new(equipInfo.ran)
	local index = 1

	while not empty(equipData["attr_" .. index]) do
		local attrStr = equipData["attr_" .. index]
		local valueStr = equipData["value_" .. index]
		local value = nil

		if not empty(equipInfo.excellent) then
			value = SheetUtil.getLinearNumber(valueStr, equipInfo.ran / 65536)
		else
			value = SheetUtil.getNumber(valueStr, random)
		end

		if value then
			value = value * agenData.attr_ratio * equipBaseNum.attr_ratio
			value = math.floor(value / 100)

			table.insert(baseValue, {
				attr = attrStr,
				value = value
			})

			data[attrStr] = (data[attrStr] or 0) + value

			if isDisplay then
				dataForDisplay[attrStr] = (dataForDisplay[attrStr] or 0) + value

				table.insert(mainAttr, {
					name = attrStr,
					value = value
				})
			end
		end

		index = index + 1
	end

	if equipInfo.dust_id and equipInfo.dust_id > 0 then
		if not empty(equipInfo.dust_sp_attr) then
			local rr = Random.new(equipInfo.dust_sp_ran)
			local csv = CsvParser.getCsvData("dust_sp_attr", equipInfo.dust_sp_attr)
			local attrStr = csv.attr
			local value = SheetUtil.getNumber(csv.value, rr)

			if value then
				data[attrStr] = (data[attrStr] or 0) + value

				if isDisplay then
					-- Nothing
				end
			end
		end
	else
		local index = 1

		while not empty(equipData["special_attr_" .. index]) do
			local attrStr = equipData["special_attr_" .. index]
			local valueStr = equipData["special_value_" .. index]
			local value = nil

			if not empty(equipInfo.excellent) then
				value = SheetUtil.getLinearNumber(valueStr, equipInfo.ran / 65536)
			else
				value = SheetUtil.getNumber(valueStr, random)
			end

			if value then
				value = math.floor(value / 100)
				data[attrStr] = (data[attrStr] or 0) + value

				if isDisplay then
					dataForDisplay[attrStr] = (dataForDisplay[attrStr] or 0) + value
				end
			end

			index = index + 1
		end
	end

	local addData = {}
	local mulData = {}

	for i = 1, GameConfig.equip_affix_max do
		local prefix = equipInfo["prefix_" .. i]
		local preran = equipInfo["preran_" .. i]

		if prefix ~= 0 then
			local random = Random.new(preran)
			local affixData = CsvParser.getCsvData("affix", prefix)

			if affixData then
				local affixGen = CsvParser.getCsvData("affix_gen", affixData.quality)
				local index = 1

				while not empty(affixData["attr_add_" .. index]) do
					local attrStr = affixData["attr_add_" .. index]
					local equipAffixLevel = CsvParser.getCsvData("affix_add_level", equipInfo.level)[attrStr]
					local value = nil

					if not empty(equipInfo.excellent) then
						value = SheetUtil.getLinearNumber(affixGen.affix_attr_range, preran / 65536)
					else
						value = SheetUtil.getNumber(affixGen.affix_attr_range, random)
					end

					local valueAdd = equipAffixLevel * value * affixGen.affix_quality_ratio / 100
					addData[attrStr] = (addData[attrStr] or 0) + valueAdd
					index = index + 1
				end

				local index = 1

				while not empty(affixData["attr_mul_" .. index]) do
					local attrStr = affixData["attr_mul_" .. index]
					local equipAffixLevel = CsvParser.getCsvData("affix_mul_level", equipInfo.level)[attrStr]
					local value = nil

					if not empty(equipInfo.excellent) then
						value = SheetUtil.getLinearNumber(affixGen.affix_attr_range, preran / 65536)
					else
						value = SheetUtil.getNumber(affixGen.affix_attr_range, random)
					end

					local valueMul = equipAffixLevel * value * affixGen.affix_quality_ratio / 100
					mulData[attrStr] = (mulData[attrStr] or 0) + valueMul
					index = index + 1
				end
			end
		end
	end

	for i = 1, GameConfig.equip_affix_max do
		local suffix = equipInfo["suffix_" .. i]
		local sufran = equipInfo["sufran_" .. i]

		if suffix ~= 0 then
			local random = Random.new(sufran)
			local affixData = CsvParser.getCsvData("affix", suffix)

			if affixData then
				local affixGen = CsvParser.getCsvData("affix_gen", affixData.quality)
				local index = 1

				while not empty(affixData["attr_add_" .. index]) do
					local attrStr = affixData["attr_add_" .. index]
					local equipAffixLevel = CsvParser.getCsvData("affix_add_level", equipInfo.level)[attrStr]
					local value = nil

					if not empty(equipInfo.excellent) then
						value = SheetUtil.getLinearNumber(affixGen.affix_attr_range, sufran / 65536)
					else
						value = SheetUtil.getNumber(affixGen.affix_attr_range, random)
					end

					local valueAdd = equipAffixLevel * value * affixGen.affix_quality_ratio / 100
					addData[attrStr] = (addData[attrStr] or 0) + valueAdd
					index = index + 1
				end

				local index = 1

				while not empty(affixData["attr_mul_" .. index]) do
					local attrStr = affixData["attr_mul_" .. index]
					local equipAffixLevel = CsvParser.getCsvData("affix_mul_level", equipInfo.level)[attrStr]
					local value = nil

					if not empty(equipInfo.excellent) then
						value = SheetUtil.getLinearNumber(affixGen.affix_attr_range, sufran / 65536)
					else
						value = SheetUtil.getNumber(affixGen.affix_attr_range, random)
					end

					local valueMul = equipAffixLevel * value * affixGen.affix_quality_ratio / 100
					mulData[attrStr] = (mulData[attrStr] or 0) + valueMul
					index = index + 1
				end
			end
		end
	end

	for attr, mulValue in pairs(mulData) do
		if data[attr] then
			data[attr] = math.ceil(data[attr] * (1 + mulValue / 100))
		end

		if isDisplay and dataForDisplay[attr] then
			dataForDisplay[attr] = math.ceil(dataForDisplay[attr] * (1 + mulValue / 100))
		end
	end

	for attr, addValue in pairs(addData) do
		data[attr] = math.ceil((data[attr] or 0) + addValue)

		if isDisplay and dataForDisplay[attr] then
			dataForDisplay[attr] = math.ceil((dataForDisplay[attr] or 0) + addValue)
		end
	end

	for i = 1, GameConfig.equip_gem_max do
		if not empty(equipInfo["gem" .. i]) then
			local itemData = CsvParser.getCsvData("item", equipInfo["gem" .. i])
			local gemData = CsvParser.getCsvData("gem", itemData.use_value1)
			local attrList = SheetUtil.getColumnList(gemData, {
				"attr_",
				"value_"
			}, {
				"attr",
				"value"
			})

			for j, v in ipairs(attrList) do
				data[v.attr] = (data[v.attr] or 0) + v.value
			end
		end
	end

	local enhanceLevel = equipInfo.enhance_level or 0

	if enhanceLevel > 0 then
		local enhanceCSV = CsvParser.getCsvData("enhance_base_num", enhanceLevel)

		for i, v in ipairs(baseValue) do
			local attrStr = v.attr
			local value = v.value
			value = math.floor(enhanceCSV.attr_ratio * value - value)
			data[attrStr] = (data[attrStr] or 0) + value
		end
	end

	if isDisplay then
		local attrsForDisplay = {}

		for k, v in pairs(dataForDisplay) do
			table.insert(attrsForDisplay, {
				attr = k,
				value = v
			})
		end

		table.sort(attrsForDisplay, function (a, b)
			return CopyAttr.getAttrIndex(a.attr) < CopyAttr.getAttrIndex(b.attr)
		end)

		return data, attrsForDisplay, mainAttr
	else
		return data
	end
end

function CopyAttr.getPetAttr(petInfo)
	local data = CopyAttr.getPetBodyAttr(petInfo)
	local random = Random.new(petInfo.seed)
	local qualityData = CsvParser.getCsvData("pet_quality", petInfo.quality)

	for i, attrKey in ipairs(CombatAttr.attrs) do
		data[attrKey] = data[attrKey] * SheetUtil.getNumber(qualityData[attrKey .. "_ratio"], random)
		data[attrKey] = data[attrKey] + SheetUtil.getNumber(qualityData[attrKey .. "_add"], random)
	end

	CopyAttr.addPetEquipAttr(petInfo.equips, data)

	for attr, v in pairs(data) do
		if not CombatAttr.isPercentAttr(attr) then
			data[attr] = math.floor(v)
		end
	end

	return data
end

function CopyAttr.getPetBodyAttr(petInfo)
	local baseData = CsvParser.getCsvData("pet", petInfo.base_id)
	local data = CombatAttr.defaultData(baseData, true)
	local baseNum = CsvParser.getCsvData("pet_base_num", petInfo.level)

	for k, attr in pairs(CombatAttr.attrs) do
		local value = SheetUtil.getLinearNumber(baseData[attr .. "_ratio"], petInfo[attr .. "_seed"] / 65536)
		data[attr] = value / 100 * baseNum[attr]
	end

	local attrList = SheetUtil.getColumnList(baseNum, {
		"attr_",
		"attr_value_"
	}, {
		"attr",
		"value"
	})

	for i, v in ipairs(attrList) do
		if data[v.attr] then
			data[v.attr] = data[v.attr] + v.value
		else
			data[v.attr] = v.value
		end
	end

	return data
end

function CopyAttr.addPetEquipAttr(equips, data)
	local suitMap = {}

	for i = 1, GameConfig.max_pet_equip do
		local equipID = equips[i]

		if equipID then
			local equipAttrData = CopyAttr.getPetEquipAttr(equipID)

			for attr, value in pairs(equipAttrData) do
				if data[attr] then
					data[attr] = data[attr] + value
				end
			end

			local equipData = CsvParser.getCsvData("pet_equip", equipID)

			if not empty(equipData.suit_id) then
				if not suitMap[equipData.suit_id] then
					suitMap[equipData.suit_id] = 0
				end

				suitMap[equipData.suit_id] = suitMap[equipData.suit_id] + 1
			end
		end
	end

	for suit_id, num in pairs(suitMap) do
		local suitCSV = CsvParser.getCsvData("suit", suit_id)
		local csv = CombatAttr.getSuitLevel(suit_id, math.min(suitCSV.suit_max, num))

		if csv then
			local attrList = SheetUtil.getColumnList(csv, {
				"attr_",
				"value_"
			}, {
				"attr",
				"value"
			})

			for j, v in ipairs(attrList) do
				if data[v.attr] then
					data[v.attr] = data[v.attr] + v.value
				end
			end
		end
	end
end

function CopyAttr.getPetEquipAttr(equipID, isDisplay)
	local data = {}
	local dataForDisplay, mainAttr = nil

	if isDisplay then
		dataForDisplay = {}
		mainAttr = {}
	end

	local equipData = CsvParser.getCsvData("pet_equip", equipID)
	local index = 1

	while not empty(equipData["attr_" .. index]) do
		local attrStr = equipData["attr_" .. index]
		local value = equipData["value_" .. index]

		if value then
			data[attrStr] = (data[attrStr] or 0) + value

			if isDisplay then
				dataForDisplay[attrStr] = (dataForDisplay[attrStr] or 0) + value

				table.insert(mainAttr, {
					name = attrStr,
					value = value
				})
			end
		end

		index = index + 1
	end

	if isDisplay then
		local attrsForDisplay = {}

		for k, v in pairs(dataForDisplay) do
			table.insert(attrsForDisplay, {
				attr = k,
				value = v
			})
		end

		table.sort(attrsForDisplay, function (a, b)
			return CopyAttr.getAttrIndex(a.attr) < CopyAttr.getAttrIndex(b.attr)
		end)

		return data, attrsForDisplay, mainAttr
	else
		return data
	end
end

function CopyAttr.calculateAttr(type, baseFilename, level, baseData, seed)
	local max_level = CsvParser.getMaxID(baseFilename)
	local data = CombatAttr.defaultData(baseData)

	if baseData then
		local random = nil

		if seed then
			random = Random.new(seed)
		end

		if not empty(baseData.ex_level) then
			level = level + baseData.ex_level
		end

		level = math.max(1, math.min(level, max_level))
		local baseNumData = CsvParser.getCsvData(baseFilename, level)

		for i = 1, #CombatAttr.attrs do
			local attr = CombatAttr.attrs[i]
			local ratio = nil

			if random then
				ratio = SheetUtil.getNumber(baseData[attr .. "_ratio"], random) / 100
			else
				ratio = baseData[attr .. "_ratio"]
			end

			local base = baseNumData[attr]
			local value = math.floor(base * ratio)
			data[attr] = value
		end
	else
		local baseNumData = CsvParser.getCsvData(baseFilename, level)

		for i = 1, #CombatAttr.attrs do
			local attr = CombatAttr.attrs[i]
			local base = baseNumData[attr]
			local value = math.floor(baseNumData[attr])
			data[attr] = value
		end
	end

	return data
end

return CopyAttr
