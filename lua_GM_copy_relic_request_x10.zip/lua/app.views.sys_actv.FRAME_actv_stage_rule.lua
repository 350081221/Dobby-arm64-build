local UI_base = import("..UI_base")
local FRAME_actv_stage_rule = class("FRAME_actv_stage_rule", UI_base)

function FRAME_actv_stage_rule.open(csv)
	local ui = FRAME_actv_stage_rule.new(csv)

	PopManager.open(ui)
end

function FRAME_actv_stage_rule:ctor(csv)
	FRAME_actv_stage_rule.super.ctor(self, "frame_actv_stage_rule", UIManager.BIG_TYPE.POP)

	self.csv = csv

	self:init()
end

function FRAME_actv_stage_rule:init()
	self:initUI()

	local csvList = CsvParser.getCsvList("actv_stage_rank", nil, {
		rank_reward_id = self.csv.rank_reward_id
	})
	local arr = {}

	for i, v in ipairs(csvList) do
		table.insert(arr, {
			csv = v
		})
	end

	self.list:setItems(arr)
end

function FRAME_actv_stage_rule:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local desc = Localization.getLoneText("FRAME_actv_stage_rule") or ""
	local textArea = self:createTextAreaOnFlag("flag_desc")

	textArea:setUbbEnabled(true)
	textArea:setSpace(5, 5)
	textArea:setText(desc)

	local function tapListener(ui, data, index, x, y)
		local csv = data.csv
		local reward_arr = SheetUtil.getColumnList(csv, {
			"reward_id_",
			"reward_num_"
		}, {
			"base_id",
			"num"
		})
		local worldPos = self.list:convertToWorldSpace(cc.p(x, y))

		for i, info in ipairs(reward_arr) do
			if ui.slots[i] and ui.slots[i]:hitTestByComponent("bg", worldPos.x, worldPos.y, true) then
				UIManager.callTapGroup("slot_click", ui.slots[i], function ()
					DropManager.popDetail(DropManager.TYPE.ITEM, info)
				end)
			end
		end
	end

	self.list = self:createListOnFlag("flag_list", LIST_actv_stage_rule, tapListener, touchListener)
	local holder = self:getComponentByTag("holder")

	self.list:setHolders({
		holder
	}, nil, 5)
end

return FRAME_actv_stage_rule
