local UI_base = import("..UI_base")
local FRAME_abyss_akasa = class("FRAME_abyss_akasa", UI_base)
local TEAM_MAX = 3
local ptPerTile = 140
local heroIso = {
	{
		x = 2,
		y = 2
	},
	{
		x = 2,
		y = 1
	},
	{
		x = 2,
		y = 0
	}
}
local petIsoMap = {}
local isoDragThreshold = 10

function FRAME_abyss_akasa.open(areaCSV, bossCSV, akasaCSV)
	local ui = FRAME_abyss_akasa.new(areaCSV, bossCSV, akasaCSV)

	PopManager.open(ui, nil, , , 200)
end

function FRAME_abyss_akasa:ctor(areaCSV, bossCSV, akasaCSV)
	self.areaCSV = areaCSV
	self.bossCSV = bossCSV
	self.akasaCSV = akasaCSV

	FRAME_abyss_akasa.super.ctor(self, "frame_abyss_akasa", UIManager.BIG_TYPE.POP)
	self:init()
end

function FRAME_abyss_akasa:init()
	local akasaInfo = InfoDungeon.getAkasaInfo(self.areaCSV.id)
	self.maxLevel = math.max(1, math.min(akasaInfo.overLayer, InfoDungeon.getAbyssMaxLayer() + 1) - akasaInfo.startLayer)
	self.superMaxLevel = math.max(1, akasaInfo.overLayer - akasaInfo.startLayer - MiscConfig.akasa_last_level)
	self.level = math.min(self.maxLevel, InfoAbyssArea.getAkasaLevel(self.areaCSV.id) + 1)

	self:initUI()
	self:initAkasa()
	self:initScore()
	self:refreshLevel()
	self:refreshAutopick()
	ManagerInfo.onDataChange(self, "dungeon", nil, function ()
		self:refreshAutopick()
	end)
end

function FRAME_abyss_akasa:initUI()
	local bg2 = self:getComponentByTag("bg2")

	bg2:toTouchable()
end

function FRAME_abyss_akasa:initAkasa()
	local function tapListener(ui, data, index)
		DropManager.popDetail(data.type, data.info)
	end

	local rewardList = self:createListOnFlag("flag_reward", function (rect)
		return LIST_abyss_prepare.new(rect)
	end, tapListener)

	rewardList:setCols(6)
	rewardList:setSpace(0, 0)
	rewardList:setTapGroup("list_click")

	local enterBt = self:getComponentByTag("bt_enter")

	enterBt:toTouchable()
	enterBt:setTapGroup("button_click")
	enterBt:addTap(function ()
		if InfoHero.countTeam() < GameConfig.hero_team_num then
			Alert.open(StringUtil.replace(Localization.getSrcText("队伍不满{1}人"), GameConfig.hero_team_num))

			return
		end

		local function onSuccess(rcvData)
			DungeonScene.enterDungeon(DungeonScene.ENTER_TYPE.NEW, rcvData)
		end

		local speedup = self.speedup and 1 or 0
		local akasaLevel = self.level - 1

		InfoDungeon.enter(InfoDungeon.TYPE.ABYSS, {
			layer = self.akasaCSV.layer + akasaLevel,
			akasa_level = akasaLevel,
			dungeon_id = self.akasaCSV.id,
			speedup = speedup
		}, onSuccess)
	end)

	local funcCSV = InfoFunction.checkFuncOpen(10160)

	if funcCSV then
		local speedup_item = CsvParser.getCsvData("config", "speedup_item").value
		local item_csv = CsvParser.getCsvData("item", speedup_item)
		local slot = DropSlot.new(self:getFlagByTag("flag_speedup_slot"), "slot_04")

		slot:setDetailEnabled(true)
		slot:setAlwaysShowNumber(true)
		self:addChild(slot, 100)
		slot:setDrop(DropManager.TYPE.ITEM, {
			base_id = speedup_item,
			num = InfoItem.getNum(speedup_item)
		})

		local label_yes = self:getComponentByTag("label_speedup_yes")
		local label_no = self:getComponentByTag("label_speedup_no")
		local selected_speedup = self:getComponentByTag("selected_speedup")

		local function refreshOpen()
			selected_speedup:setVisible(self.speedup)
			label_yes:setVisible(self.speedup)
			label_no:setVisible(not self.speedup)
		end

		refreshOpen()

		local bg = self:getComponentByTag("speedup_bg")

		bg:toTouchable()
		bg:setOpacity(0)
		bg:setTapGroup("bg_click")
		bg:addTap(function ()
			if self.speedup then
				self.speedup = nil
			else
				if InfoItem.getNum(speedup_item) <= 0 then
					Alert.open(item_csv.name .. Localization.getSrcText("不足"))

					return
				end

				self.speedup = true
			end

			refreshOpen()
		end)

		local slot = DropSlot.new(self:getFlagByTag("flag_autopick_slot"), "slot_04")

		slot:setDetailEnabled(true)
		slot:setAlwaysShowNumber(true)
		self:addChild(slot, 100)

		self.autopickSlot = slot
		local autopick_bg = self:getComponentByTag("autopick_bg")

		autopick_bg:toTouchable()
		autopick_bg:setOpacity(0)
		autopick_bg:setTapGroup("bg_click")
		autopick_bg:addTap(function ()
			FRAME_autopick.open()
		end)
	end

	self:createLabelOnFlag("flag_name", self.akasaCSV.name)

	local info = InfoDungeon.getAbyssInfo(self.akasaCSV.layer)

	if info then
		local itemArr = {}
		local arr = string.split(info.reward_item, ";")

		for i, v in ipairs(arr) do
			if not empty(v) then
				local itemID = tonumber(v)

				if InfoItem.getNum(itemID) == 0 then
					table.insert(itemArr, {
						type = DropManager.TYPE.ITEM,
						info = {
							num = 1,
							base_id = itemID
						}
					})
				end
			end
		end

		local arr = string.split(info.item_display, ";")

		for i, v in ipairs(arr) do
			if not empty(v) then
				local itemID = tonumber(v)
				local itemCSV = CsvParser.getCsvData("item", itemID)

				if itemCSV.drop_level_min <= info.level + 3 and info.level <= itemCSV.drop_level_max then
					table.insert(itemArr, {
						type = DropManager.TYPE.ITEM,
						info = {
							num = 1,
							base_id = itemID
						}
					})
				end
			end
		end

		rewardList:setAbyssLevel(self.akasaCSV.level)
		rewardList:setItems(itemArr)
	end

	local akasaInfo = InfoDungeon.getAkasaInfo(self.areaCSV.id)
	local bg_level = self:getComponentByTag("bg_level")

	bg_level:toTouchable()
	bg_level:setTapGroup("button_click")
	bg_level:addTap(function ()
		local titleStr = Localization.getSrcText("进入层数：{1}")
		local hintStr = Localization.getSrcText("可进入最大层数：{1}层")
		local hint2Str = Localization.getSrcText("每通关{1}层，可从下一层开始挑战，但距离终点需大于{2}层")
		local stepLevel = MiscConfig.akasa_step_level
		local maxLevel = POP_level_select.fixLevel(self.maxLevel, 1, self.maxLevel, self.superMaxLevel, stepLevel)

		print("$$$ self.superMaxLevel", self.superMaxLevel, self.maxLevel)
		POP_level_select.open(titleStr, StringUtil.replace(hintStr, maxLevel), self.level, 1, self.maxLevel, function (level)
			if not level or level < 1 or self.maxLevel < level then
				Alert.open(Localization.getSrcText("层数错误"))

				return
			end

			self.level = level

			self:refreshLevel()
		end, stepLevel, self.superMaxLevel, StringUtil.replace(hint2Str, stepLevel, MiscConfig.akasa_last_level))
	end)
end

function FRAME_abyss_akasa:refreshLevel()
	self:replaceLabelGroupOnFlag("flag_level", {
		self.level,
		self.maxLevel
	}, {
		{
			color = Style.font3
		}
	})
end

function FRAME_abyss_akasa:initScore()
	local teamScore = InfoHero.getTeamScore()

	self:replaceLabelGroupOnFlag("flag_score", {
		teamScore
	}, {
		{
			color = Style.font3
		}
	})

	local info = InfoDungeon.getAbyssInfo(self.akasaCSV.layer)
	local style = {
		color = Style.font3
	}

	if teamScore < info.standard_score then
		style.color = Style.disableColor
	end

	self:replaceLabelGroupOnFlag("flag_score_standard", {
		info.standard_score
	}, {
		style
	})
end

function FRAME_abyss_akasa:refreshAutopick()
	local autopick_item = CsvParser.getCsvData("config", "autopick_item").value

	self.autopickSlot:setDrop(DropManager.TYPE.ITEM, {
		base_id = autopick_item,
		num = InfoItem.getNum(autopick_item)
	})

	local label_yes = self:getComponentByTag("label_autopick_yes")
	local label_no = self:getComponentByTag("label_autopick_no")

	local function refreshTime()
		local nowTime = math.floor(Time.now())
		local time = InfoDungeon.autoPickTime()

		if time <= nowTime then
			label_no:setVisible(true)
			label_yes:setVisible(false)
			self:removeEnterFrame("refreshTime_autopick")

			self.autopickTimeStr = nil
		else
			label_no:setVisible(false)

			local timeLeft = time - nowTime
			local timeStr = Time.showMin(timeLeft)

			if self.autopickTimeStr ~= timeStr then
				self.autopickTimeStr = timeStr

				self:replaceLabelOnFlag("label_autopick_yes", nil, timeStr)
			end
		end
	end

	self:addEnterFrame("refreshTime_autopick", refreshTime)
	refreshTime()
end

function FRAME_abyss_akasa:onExit()
	local currentLevel = InfoAbyssArea.getAkasaLevel(self.areaCSV.id)
	local newLevel = self.level - 1

	if currentLevel ~= newLevel then
		InfoAbyssArea.saveAkasaLevel(self.areaCSV.id, newLevel)
	end

	FRAME_abyss_akasa.super.onExit(self)
end

return FRAME_abyss_akasa
