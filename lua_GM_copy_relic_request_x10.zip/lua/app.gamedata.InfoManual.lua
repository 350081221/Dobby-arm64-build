local InfoManual = {}
local rawData = {}

function InfoManual.init()
	Connection.listen("manual_sync", InfoManual.sync)
end

app:addToAppEnterCall(InfoManual.init)

local TYPE = {
	WEAPON = 2,
	SP = 1,
	ARTIFACT = 5,
	AVATAR = 4,
	PET = 3
}
InfoManual.TYPE = TYPE
local CSV_ARR = {
	"manual_sp",
	"manual_weapon",
	"manual_pet",
	"manual_avatar",
	"manual_artifact"
}

function InfoManual.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoManual.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("manual_query", callback)
end

function InfoManual.onQuery(rcvData)
	dump(rcvData, "manual_query")

	rawData = {}

	for k, type in pairs(TYPE) do
		rawData[type] = {}
	end

	for i, data in ipairs(rcvData.list) do
		local type = data.type
		local base_id = data.base_id
		rawData[type][base_id] = data
	end

	dump(rawData, "$$$ rawData")
end

function InfoManual.sync(data)
	dump(data, "$$$ InfoManual.sync")

	for i, syncData in ipairs(data.list) do
		local type = syncData.type
		local base_id = syncData.base_id
		local _data = nil
		_data = rawData[type][base_id]

		if _data then
			for k, v in pairs(syncData) do
				_data[k] = v
			end
		else
			rawData[type][base_id] = syncData
		end
	end

	ManagerInfo.dataChange("manual")
end

function InfoManual.mark(type, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("manual_mark", {
		type = type
	}, callback)
end

function InfoManual.checkRecover()
	local arr = {}

	for k, type in pairs(TYPE) do
		local csvName = CSV_ARR[type]
		local csvList = CsvParser.getCsvList(csvName)
		local dataMap = rawData[type]

		if type == TYPE.SP then
			for i, csv in ipairs(csvList) do
				if not dataMap[csv.id] then
					local baseID = InfoManual.getHeroId(csv.id)

					if baseID then
						local id = InfoHero.getIDBybaseID(baseID, true)

						if id then
							table.insert(arr, {
								type = type,
								id = id
							})
						end
					end
				end
			end
		elseif type == TYPE.WEAPON or type == TYPE.AVATAR then
			for i, csv in ipairs(csvList) do
				if not dataMap[csv.id] then
					local id = InfoEquip.getIDBybaseID(csv.id)

					if id then
						table.insert(arr, {
							type = type,
							id = id
						})
					end
				end
			end
		elseif type == TYPE.PET then
			local petExist = {}

			for i, csv in ipairs(csvList) do
				if not petExist[csv.pet_id] then
					petExist[csv.pet_id] = true

					if not dataMap[csv.pet_id] then
						local id = InfoHero.getBestQualityIDByFunc(function (petInfo)
							return InfoPet.getBaseJob(petInfo.base_id) == csv.pet_id
						end)

						if id then
							table.insert(arr, {
								type = type,
								id = id
							})
						end
					else
						local quality = dataMap[csv.pet_id].quality
						local id = InfoHero.getBestQualityIDByFunc(function (petInfo)
							if InfoPet.getBaseJob(petInfo.base_id) == csv.pet_id then
								return quality < petInfo.quality
							end

							return false
						end)

						if id then
							table.insert(arr, {
								type = type,
								id = id
							})
						end
					end
				end
			end
		elseif type == TYPE.ARTIFACT then
			for i, csv in ipairs(csvList) do
				if not dataMap[csv.id] then
					local id = InfoArtifact.getIDBybaseID(csv.id)

					if id then
						table.insert(arr, {
							type = type,
							id = id
						})
					end
				end
			end
		end
	end

	if #arr > 0 then
		local function callback(rcvData)
			if rcvData.err then
				if onFailure then
					onFailure()
				end
			elseif onSuccess then
				onSuccess()
			end
		end

		Connection.request("manual_recover", {
			list = arr
		}, callback)
	end
end

function InfoManual.countRedot(type)
	local redotCount = 0
	local csvList = CsvParser.getCsvList("manual_weapon")
	local existMap = {}
	local dataMap = rawData[type]

	for i, csv in ipairs(csvList) do
		if dataMap[csv.id] and dataMap[csv.id].is_new == 1 then
			redotCount = redotCount + 1
		end
	end

	return redotCount
end

function InfoManual.lockAttr(type)
	InfoManual.lockAttrType = type
end

function InfoManual.clearAttrLock()
	InfoManual.lockAttrType = nil
end

function InfoManual.getAttr()
	local attrMap = {}

	if InfoManual.lockAttrType ~= TYPE.SP then
		InfoManual.getAttrSp(attrMap)
	end

	if InfoManual.lockAttrType ~= TYPE.PET then
		InfoManual.getAttrPet(attrMap)
	end

	if InfoManual.lockAttrType ~= TYPE.WEAPON then
		InfoManual.getAttrWeapon(attrMap)
	end

	if InfoManual.lockAttrType ~= TYPE.AVATAR then
		InfoManual.getAttrAvatar(attrMap)
	end

	if InfoManual.lockAttrType ~= TYPE.ARTIFACT then
		InfoManual.getAttrArtifact(attrMap)
	end

	return attrMap
end

function InfoManual.getAttrUp(type)
	local fullScore = InfoHero.getTeamScore()

	InfoManual.lockAttr(type)

	local newScore = InfoHero.getTeamScore()

	InfoManual.clearAttrLock()

	return fullScore - newScore
end

function InfoManual.checkNew(type)
	local dataMap = rawData[type]

	for base_id, v in pairs(dataMap) do
		if v.is_new == 1 then
			return true
		end
	end

	return false
end

function InfoManual.checkNewAll()
	for k, type in pairs(TYPE) do
		if InfoManual.checkNew(type) then
			return true
		end
	end

	return false
end

function InfoManual.count(type)
	local dataMap = rawData[type]
	local csvName = CSV_ARR[type]
	local max = 0
	local count = 0
	local csvList = nil

	if type == TYPE.PET then
		csvList = InfoManual.getListPet()
	else
		csvList = CsvParser.getCsvList(csvName)
	end

	for i, csv in ipairs(csvList) do
		if type == TYPE.PET then
			if dataMap[csv.pet_id] then
				count = count + 1
			end

			max = max + 1
		else
			if dataMap[csv.id] then
				count = count + 1
			end

			max = max + 1
		end
	end

	return count, max
end

function InfoManual.getListSp()
	local csvList = CsvParser.getCsvList("manual_sp")

	return csvList
end

function InfoManual.getListSpLink(cols)
	local csvList = CsvParser.getCsvList("manual_sp_link")
	local items = {}

	for i, csv in ipairs(csvList) do
		local obj = {
			line = true,
			linkCSV = csv
		}

		table.insert(items, obj)

		for j = 1, cols - 1 do
			table.insert(items, {
				line = true,
				empty = true
			})
		end

		local heroArr = SheetUtil.getColumnValueList(csv, "sp_")
		local allOK = true

		for j, spID in ipairs(heroArr) do
			local spCSV = CsvParser.getCsvData("manual_sp", spID)

			table.insert(items, {
				csv = spCSV
			})

			if not InfoManual.getDataSp(spID) then
				allOK = false
			end
		end

		obj.allOK = allOK
		local moreCols = #heroArr % cols

		if moreCols > 0 then
			for j = 1, cols - moreCols do
				table.insert(items, {
					empty = true
				})
			end
		end
	end

	return items
end

function InfoManual.getDataSp(base_id)
	return rawData[TYPE.SP][base_id]
end

function InfoManual.getHeroId(sp_id)
	local manualToHeroMap = CacheData.get("InfoManual_manualToHeroMap")

	if not manualToHeroMap then
		manualToHeroMap = {}
		local csvList = CsvParser.getCsvList("hero")

		for i, csv in ipairs(csvList) do
			if not empty(csv.sp_id) and not manualToHeroMap[csv.sp_id] then
				manualToHeroMap[csv.sp_id] = csv.id
			end
		end

		CacheData.set("InfoManual_manualToHeroMap", manualToHeroMap)
	end

	return manualToHeroMap[sp_id]
end

function InfoManual.getHeroInfo(sp_id)
	local spCSV = CsvParser.getCsvData("hero_sp", sp_id)
	local randomHeroCSV = CsvParser.getCsvData("random_hero", spCSV.random_hero)
	local manualCSV = CsvParser.getCsvData("manual_sp", sp_id)
	local heroID = manualCSV.hero_id

	if empty(heroID) then
		heroID = InfoManual.getHeroId(sp_id)
	end

	local gender = SheetUtil.getNumber(randomHeroCSV.gender)
	local heroInfo = {
		level = 1,
		base_id = heroID,
		name = spCSV.name,
		gender = gender,
		quality = spCSV.quality,
		body = SheetUtil.getString(randomHeroCSV["body_" .. gender]),
		hair = SheetUtil.getString(randomHeroCSV["fixed_hair_" .. gender])
	}

	return heroInfo
end

function InfoManual.getAttrSp(originAttrMap)
	local attrMap = originAttrMap or {}
	local dataMap = rawData[TYPE.SP]

	for base_id, v in pairs(dataMap) do
		local csv = CsvParser.getCsvData("manual_sp", base_id)
		local attrList = SheetUtil.getColumnList(csv, {
			"attr_",
			"attr_value_"
		}, {
			"attr",
			"value"
		})

		for i, v in ipairs(attrList) do
			if attrMap[v.attr] then
				attrMap[v.attr] = attrMap[v.attr] + v.value
			else
				attrMap[v.attr] = v.value
			end
		end
	end

	local csvRaw = CsvParser.getCsvRaw("manual_sp_link")

	for k, csv in pairs(csvRaw) do
		local heroArr = SheetUtil.getColumnValueList(csv, "sp_")
		local allOK = true

		for j, spID in ipairs(heroArr) do
			if not InfoManual.getDataSp(spID) then
				allOK = false

				break
			end
		end

		if allOK then
			local attrList = SheetUtil.getColumnList(csv, {
				"attr_",
				"attr_value_"
			}, {
				"attr",
				"value"
			})

			for i, v in ipairs(attrList) do
				if attrMap[v.attr] then
					attrMap[v.attr] = attrMap[v.attr] + v.value
				else
					attrMap[v.attr] = v.value
				end
			end
		end
	end

	if originAttrMap then
		return
	end

	local sortArr = {}

	for attr, value in pairs(attrMap) do
		local csv = CsvParser.getCsvData("attr", attr)

		table.insert(sortArr, {
			__line = csv.__line,
			value = value,
			attr = attr
		})
	end

	table.sort(sortArr, function (a, b)
		return a.__line < b.__line
	end)

	return sortArr
end

function InfoManual.getDataWeapon(base_id)
	return rawData[TYPE.WEAPON][base_id]
end

function InfoManual.getEquipInfo(base_id)
	local equip_csv = CsvParser.getCsvData("equip", base_id)
	local equip_info = {
		quality = 0,
		enhance_level = 0,
		drop_rare = 1,
		identified = 0,
		slot_max = 0,
		slot = 0,
		best_suffix = 0,
		best_prefix = 0,
		level = 1,
		drop_level = 1,
		base_id = base_id,
		equip_pos = equip_csv.equip_pos,
		ran = math.random(1, 65535)
	}

	for i = 1, GameConfig.equip_affix_max do
		equip_info["prefix_" .. i] = 0
		equip_info["preran_" .. i] = 0
		equip_info["suffix_" .. i] = 0
		equip_info["sufran_" .. i] = 0
	end

	for i = 1, GameConfig.equip_gem_max do
		equip_info["gem" .. i] = 0
	end

	return equip_info
end

function InfoManual.getListWeapon()
	local csvList = CsvParser.getCsvList("manual_weapon")

	return csvList
end

function InfoManual.getAttrWeapon(originAttrMap)
	local attrMap = originAttrMap or {}
	local dataMap = rawData[TYPE.WEAPON]

	for base_id, v in pairs(dataMap) do
		local csv = CsvParser.getCsvData("manual_weapon", base_id)
		local attrList = SheetUtil.getColumnList(csv, {
			"attr_",
			"attr_value_"
		}, {
			"attr",
			"value"
		})

		for i, v in ipairs(attrList) do
			if attrMap[v.attr] then
				attrMap[v.attr] = attrMap[v.attr] + v.value
			else
				attrMap[v.attr] = v.value
			end
		end
	end

	if originAttrMap then
		return
	end

	local sortArr = {}

	for attr, value in pairs(attrMap) do
		local csv = CsvParser.getCsvData("attr", attr)

		table.insert(sortArr, {
			__line = csv.__line,
			value = value,
			attr = attr
		})
	end

	table.sort(sortArr, function (a, b)
		return a.__line < b.__line
	end)

	return sortArr
end

local petListCache = nil

function InfoManual.getListPet()
	if not petListCache then
		petListCache = {}
		local csvList = CsvParser.getCsvList("manual_pet")
		local existMap = {}

		for i, csv in ipairs(csvList) do
			if not existMap[csv.pet_id] then
				existMap[csv.pet_id] = true

				table.insert(petListCache, csv)
			end
		end
	end

	return petListCache
end

function InfoManual.getTypePet()
	local typeMap = {}
	local csvList = InfoManual.getListPet()

	for i, csv in ipairs(csvList) do
		local petCSV = CsvParser.getCsvData("pet", csv.pet_id)
		local type = petCSV.food_item

		if not typeMap[type] then
			typeMap[type] = {}
		end

		table.insert(typeMap[petCSV.food_item], csv)
	end

	return typeMap
end

function InfoManual.getPetTypeCount(type)
	local dataMap = rawData[TYPE.PET]
	local typeMap = {}

	for k, data in pairs(dataMap) do
		local type = data.type
		local base_id = data.base_id
		local petCSV = CsvParser.getCsvData("pet", base_id)

		if not typeMap[petCSV.food_item] then
			typeMap[petCSV.food_item] = 1
		else
			typeMap[petCSV.food_item] = typeMap[petCSV.food_item] + 1
		end
	end

	return typeMap[type] or 0
end

local petLinkCache = nil

function InfoManual.getPetLink(type, count)
	if not petLinkCache then
		petLinkCache = {}
		local csvList = CsvParser.getCsvList("manual_pet_link")

		for i, csv in ipairs(csvList) do
			if not petLinkCache[csv.type] then
				petLinkCache[csv.type] = {}
			end

			table.insert(petLinkCache[csv.type], csv)
		end

		for k, arr in pairs(petLinkCache) do
			table.sort(arr, function (a, b)
				return b.count < a.count
			end)
		end
	end

	local arr = petLinkCache[type]

	if arr then
		for i, csv in ipairs(arr) do
			if csv.count <= count then
				return csv
			end
		end
	end
end

function InfoManual.getListPetLink(cols)
	local csvList = CsvParser.getCsvList("manual_pet_link_type")
	local typePetMap = InfoManual.getTypePet()
	local items = {}

	for i, csv in ipairs(csvList) do
		local obj = {
			line = true,
			typeCSV = csv
		}

		table.insert(items, obj)

		for j = 1, cols - 1 do
			table.insert(items, {
				line = true,
				empty = true
			})
		end

		local petArr = typePetMap[csv.id] or {}
		obj.count = 0

		for j, manualCSV in ipairs(petArr) do
			table.insert(items, {
				csv = manualCSV
			})

			if InfoManual.getDataPet(manualCSV.pet_id) then
				obj.count = obj.count + 1
			end
		end

		local moreCols = #petArr % cols

		if moreCols > 0 then
			for j = 1, cols - moreCols do
				table.insert(items, {
					empty = true
				})
			end
		end
	end

	return items
end

function InfoManual.getDataPet(pet_id)
	return rawData[TYPE.PET][pet_id]
end

local petQualityCache = nil

function InfoManual.getPetQuality(pet_id)
	if not petQualityCache then
		petQualityCache = {}
		local csvList = CsvParser.getCsvList("manual_pet")

		for i, csv in ipairs(csvList) do
			if not petQualityCache[csv.pet_id] then
				petQualityCache[csv.pet_id] = {}
			end

			local obj = petQualityCache[csv.pet_id]

			if not obj.min or csv.quality < obj.min then
				obj.min = csv.quality
			end

			if not obj.max or obj.min < csv.quality then
				obj.max = csv.quality
			end
		end
	end

	local data = InfoManual.getDataPet(pet_id)
	local quality = math.max(petQualityCache[pet_id].min, math.min(petQualityCache[pet_id].max, 4))

	if data then
		quality = data.quality
	end

	return quality
end

function InfoManual.getPetInfo(pet_id)
	local quality = InfoManual.getPetQuality(pet_id)
	local petInfo = {
		level = 1,
		base_id = pet_id,
		quality = quality
	}

	return petInfo
end

local petCsvCache = nil

function InfoManual.getPetCSV(petID, quality)
	if not petCsvCache then
		petCsvCache = {}
		local csvRaw = CsvParser.getCsvRaw("manual_pet")

		for k, csv in pairs(csvRaw) do
			local code = csv.pet_id .. "_" .. csv.quality
			petCsvCache[code] = csv
		end
	end

	local code = petID .. "_" .. quality

	return petCsvCache[code]
end

function InfoManual.getAttrPet(originAttrMap)
	local attrMap = originAttrMap or {}
	local dataMap = rawData[TYPE.PET]

	for k, v in pairs(dataMap) do
		local csv = InfoManual.getPetCSV(v.base_id, v.quality)
		local attrList = SheetUtil.getColumnList(csv, {
			"attr_",
			"attr_value_"
		}, {
			"attr",
			"value"
		})

		for i, v in ipairs(attrList) do
			if attrMap[v.attr] then
				attrMap[v.attr] = attrMap[v.attr] + v.value
			else
				attrMap[v.attr] = v.value
			end
		end
	end

	local csvRaw = CsvParser.getCsvRaw("manual_pet_link_type")

	for k, csv in pairs(csvRaw) do
		local count = InfoManual.getPetTypeCount(csv.id)
		local linkCSV = InfoManual.getPetLink(csv.id, count)

		if linkCSV then
			local attrList = SheetUtil.getColumnList(linkCSV, {
				"attr_",
				"attr_value_"
			}, {
				"attr",
				"value"
			})

			for i, v in ipairs(attrList) do
				if attrMap[v.attr] then
					attrMap[v.attr] = attrMap[v.attr] + v.value
				else
					attrMap[v.attr] = v.value
				end
			end
		end
	end

	if originAttrMap then
		return
	end

	local sortArr = {}

	for attr, value in pairs(attrMap) do
		local csv = CsvParser.getCsvData("attr", attr)

		table.insert(sortArr, {
			__line = csv.__line,
			value = value,
			attr = attr
		})
	end

	table.sort(sortArr, function (a, b)
		return a.__line < b.__line
	end)

	return sortArr
end

function InfoManual.getDataAvatar(base_id)
	return rawData[TYPE.AVATAR][base_id]
end

function InfoManual.getListAvatar(cols)
	local items = {}
	local csvList = CsvParser.getCsvList("manual_avatar")
	local classMap = {}

	for i, csv in ipairs(csvList) do
		local base_id = csv.id
		local equipCSV = CsvParser.getCsvData("equip", base_id)

		if not classMap[equipCSV.class] then
			classMap[equipCSV.class] = {}
		end

		table.insert(classMap[equipCSV.class], base_id)
	end

	local classArr = {}

	for class, arr in pairs(classMap) do
		table.insert(classArr, {
			class = class,
			arr = arr
		})
	end

	table.sort(classArr, function (a, b)
		return a.class < b.class
	end)

	for i, v in ipairs(classArr) do
		local class = v.class
		local arr = v.arr
		local obj = {
			line = true,
			classCSV = CsvParser.getCsvData("equip_class", class)
		}

		table.insert(items, obj)

		for j = 1, cols - 1 do
			table.insert(items, {
				line = true,
				empty = true
			})
		end

		for j, base_id in ipairs(arr) do
			local csv = CsvParser.getCsvData("manual_avatar", base_id)

			table.insert(items, {
				csv = csv
			})
		end

		local moreCols = #arr % cols

		if moreCols > 0 then
			for j = 1, cols - moreCols do
				table.insert(items, {
					empty = true
				})
			end
		end
	end

	return items
end

function InfoManual.getAttrAvatar(originAttrMap)
	local attrMap = originAttrMap or {}
	local dataMap = rawData[TYPE.AVATAR]

	for base_id, v in pairs(dataMap) do
		local csv = CsvParser.getCsvData("manual_avatar", base_id)
		local attrList = SheetUtil.getColumnList(csv, {
			"attr_",
			"attr_value_"
		}, {
			"attr",
			"value"
		})

		for i, v in ipairs(attrList) do
			if attrMap[v.attr] then
				attrMap[v.attr] = attrMap[v.attr] + v.value
			else
				attrMap[v.attr] = v.value
			end
		end
	end

	if originAttrMap then
		return
	end

	local sortArr = {}

	for attr, value in pairs(attrMap) do
		local csv = CsvParser.getCsvData("attr", attr)

		table.insert(sortArr, {
			__line = csv.__line,
			value = value,
			attr = attr
		})
	end

	table.sort(sortArr, function (a, b)
		return a.__line < b.__line
	end)

	return sortArr
end

function InfoManual.getDataArtifact(base_id)
	return rawData[TYPE.ARTIFACT][base_id]
end

function InfoManual.getArtifactInfo(base_id)
	local artifact_info = InfoArtifact.getSample(base_id)
	artifact_info.level = nil
	artifact_info.star = nil

	return artifact_info
end

function InfoManual.getListArtifact()
	local csvList = CsvParser.getCsvList("manual_artifact")

	return csvList
end

function InfoManual.getAttrArtifact(originAttrMap)
	local attrMap = originAttrMap or {}
	local dataMap = rawData[TYPE.ARTIFACT]

	for base_id, v in pairs(dataMap) do
		local csv = CsvParser.getCsvData("manual_artifact", base_id)
		local attrList = SheetUtil.getColumnList(csv, {
			"attr_",
			"attr_value_"
		}, {
			"attr",
			"value"
		})

		for i, v in ipairs(attrList) do
			if attrMap[v.attr] then
				attrMap[v.attr] = attrMap[v.attr] + v.value
			else
				attrMap[v.attr] = v.value
			end
		end
	end

	if originAttrMap then
		return
	end

	local sortArr = {}

	for attr, value in pairs(attrMap) do
		local csv = CsvParser.getCsvData("attr", attr)

		table.insert(sortArr, {
			__line = csv.__line,
			value = value,
			attr = attr
		})
	end

	table.sort(sortArr, function (a, b)
		return a.__line < b.__line
	end)

	return sortArr
end

return InfoManual
