local LIST_relic_get = import("...ui.List")
local LIST_relic_get = class("LIST_relic_get", LIST_relic_get)

function LIST_relic_get:ctor(rect, cols)
	LIST_relic_get.super.ctor(self, rect)
	self:setCols(cols or 3)
	self:setCellName("cell_relic_get")
	self:setSpace(5, 5)
	self:setCellSize(cc.size(self.touchRect.width, 120))
end

function LIST_relic_get:onCellInit(ui, data)
	if not ui.slot then
		ui.slot = DropSlot.new(ui:getFlagByTag("flag_slot"), "slot_01")

		ui:addChild(ui.slot, 100)
	end

	ui.slot:setAlwaysShowNumber(data.type == DropManager.TYPE.ITEM)

	local isNewEquip = data.type == DropManager.TYPE.EQUIP and data.info.id == nil or data.type == DropManager.TYPE.SIGIL and data.info.id == nil
	local new = ui:getComponentByTag("new")

	new:setFrame(Localization.getNewFrame())
	new:setVisible(isNewEquip)

	if isNewEquip then
		new:setLocalZOrder(200)
		Style.makeShining(new, 128, 255, 0.5)
	else
		transition.stopTarget(new)
	end

	ui.slot:setDrop(data.type, data.info)
end

function LIST_relic_get:getPickNode(cell)
	if cell then
		return cell.slot
	end
end

function LIST_relic_get:onCellPicked(ui, data, picked)
	local new = ui:getComponentByTag("new")

	new:setFrame(Localization.getNewFrame())

	if picked then
		new:setVisible(false)
	else
		local isNewEquip = data.type == DropManager.TYPE.EQUIP and data.info.id == nil or data.type == DropManager.TYPE.SIGIL and data.info.id == nil

		new:setVisible(isNewEquip)
	end
end

return LIST_relic_get
