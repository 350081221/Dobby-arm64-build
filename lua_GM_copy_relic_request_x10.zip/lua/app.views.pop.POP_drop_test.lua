local POP_drop_test = class("POP_drop_test", UI_base)

function POP_drop_test.open()
	POP_drop_test.opening = true
	local ui = POP_drop_test.new()

	display.getRunningScene():addChild(ui, LayerConfig.curtain)
end

function POP_drop_test:ctor()
	POP_drop_test.super.ctor(self, "pop_drop_test")
	self:init()
end

function POP_drop_test:init()
	self:initUI()
end

function POP_drop_test:initUI()
	local closePB = self:getComponentByTag("close_pb")

	closePB:toTouchable()
	closePB:addTap(function ()
		self:removeSelf()
	end)

	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	self.levelEB = self:createEditBoxOnComponent("eb_equip_level")
	self.mfEB = self:createEditBoxOnComponent("eb_mf")
	self.loopEB = self:createEditBoxOnComponent("eb_loop")

	self.levelEB:setText("30")
	self.mfEB:setText("0")
	self.loopEB:setText("100000")

	local testPB = self:getComponentByTag("bt_test")

	testPB:toTouchable()
	testPB:addTap(function ()
		self:goTest()
	end)

	local clearPB = self:getComponentByTag("bt_clear")

	clearPB:toTouchable()
	clearPB:addTap(function ()
		self:clearChart()
	end)

	self.scale = 1
	self.resultStack = {}
	self.canvasStack = {}
	self.labelStack = {}

	self:replaceLabelOnFlag("flag_scale", nil, math.floor(self.scale * 100) .. "%")

	local scale_bar = self:getComponentByTag("scale_bar")
	local scale_handler = self:getComponentByTag("scale_handler")

	scale_handler:toTouchable()
	scale_handler:addTouch(function (event, x, y)
		if event == "began" then
			self.scaleDrag = {
				startMouseX = x,
				startX = scale_handler:getPositionX()
			}
		elseif event == "moved" then
			local minX = scale_bar.x + scale_handler.width / 2
			local maxX = scale_bar.x + scale_bar.width - scale_handler.width / 2
			local currentX = math.max(minX, math.min(maxX, x - self.scaleDrag.startMouseX + self.scaleDrag.startX))

			scale_handler:setPositionX(currentX)

			local percent = (currentX - minX) / (maxX - minX)
			percent = math.pow(percent, 3)
			self.scale = 1 + percent * 99

			self:replaceLabelOnFlag("flag_scale", nil, math.floor(self.scale * 100) .. "%")
			self:refreshChart()
		elseif event == "ended" then
			self:refreshChart()
		end
	end)
end

function POP_drop_test:refreshChart()
	for i, v in ipairs(self.canvasStack) do
		v:removeSelf()
	end

	for i, v in ipairs(self.labelStack) do
		v:removeSelf()
	end

	self.canvasStack = {}
	self.labelStack = {}
	local chartFlag = self:getFlagByTag("flag_chart")
	local chartBG = self:getComponentByTag("chart_bg")

	for chartIndex, results in ipairs(self.resultStack) do
		local resultMap = {}
		local totalTimes = 0

		for i, v in ipairs(results) do
			resultMap[v.id] = v.times
			totalTimes = totalTimes + v.times
		end

		local loop = tonumber(self.loopEB:getText())
		local genArray = CsvParser.getCsvList("affix_gen")
		local spaceX = chartFlag.width / #genArray
		local canvas = display.newNode()

		canvas:setCascadeOpacityEnabled(true)

		local opacity = 255 * math.pow(0.3, #self.resultStack - chartIndex)
		local preX, preY = nil

		for i, v in ipairs(genArray) do
			local x = spaceX * (i - 0.5)
			local y = resultMap[v.id] / loop * chartFlag.height * self.scale + chartFlag.y - chartBG.y
			local color = InfoHero.getQualityColor(v.id)

			if v.id == 0 then
				color = Style.black
			end

			local circle = display.newSolidCircle(5, {
				x = x,
				y = y,
				color = cc.c4f(color.r / 255, color.g / 255, color.b / 255, 1)
			})

			if i > 1 then
				local line = display.newLine({
					{
						x,
						y
					},
					{
						preX,
						preY
					}
				}, {
					borderWidth = 2
				})

				canvas:addChild(line, 99)
				line:setOpacity(100)
			end

			preX = x
			preY = y

			canvas:addChild(circle, 100)

			if chartIndex == #self.resultStack then
				local label = UIManager.getUI("pop_test_label")

				label:setPosition(x, y + 20)
				canvas:addChild(label, 200)

				local _, labelWidth = label:replaceLabelOnFlag("flag_text", nil, resultMap[v.id], math.max(resultMap[v.id] / totalTimes * 1000) / 10)
				local bg = label:getComponentByTag("bg")

				bg:setSize(labelWidth + 10, nil, true)
			end
		end

		local renderTexture = cc.RenderTexture:create(chartBG.width, chartBG.height)

		renderTexture:begin()
		canvas:visit()
		renderTexture:endToLua()

		local texture = renderTexture:getSprite():getTexture()
		local canvasSprite = display.newSprite(texture)

		canvasSprite:setScaleY(-1)
		table.insert(self.canvasStack, canvasSprite)
		canvasSprite:setPosition(chartBG.x + chartBG.width / 2, chartBG.y + chartBG.height / 2)
		canvasSprite:setOpacity(opacity)
		self:addChild(canvasSprite, 100 + chartIndex)
	end
end

function POP_drop_test:clearChart()
	self.resultStack = {}

	self:refreshChart()
end

function POP_drop_test:goTest()
	local loop = tonumber(self.loopEB:getText())

	if not loop then
		Alert.open("循环次数不对")
	end

	local mf = tonumber(self.mfEB:getText())

	if not mf then
		Alert.open("mf不对")
	end

	local equip_level = tonumber(self.levelEB:getText())

	if not equip_level then
		Alert.open("装备等级不对")
	end

	POP_mask.open(10, 100)

	local function callback(rcvData)
		table.insert(self.resultStack, rcvData.results)
		self:refreshChart()

		if rcvData.err then
			-- Nothing
		end

		POP_mask.open(10, 0)
	end

	Connection.request("gm_drop_test", {
		loop = loop,
		mf = mf,
		equip_level = equip_level
	}, callback)
end

return POP_drop_test
