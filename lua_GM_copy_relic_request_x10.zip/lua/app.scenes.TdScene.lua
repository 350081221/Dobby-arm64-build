local TdScene = class("TdScene", function ()
	return display.newScene("TdScene")
end)

function TdScene.enter(stageID)
	print("$$$ TdScene.enter", stageID)

	local stageCSV = CsvParser.getCsvData("td_stage", stageID)
	local map = stageCSV.map
	TdScene.stageID = stageID
	TdScene.currentMap = map

	Log.verbose("TdScene.enter", stageID)
	TdScene.enterMap(stageCSV.map)
end

function TdScene.enterMap(mapName)
	FRAME_wild.close()
	FRAME_union_pve.close()
	Log.verbose("TdScene.enterMap", mapName)

	local mapObj = Map.getMapData(mapName)

	Transition.setTitle(mapObj.mapData.name)
	app:enterScene("TdScene")
end

function TdScene:ctor()
	Log.debug("TdScene:ctor")
	event_listener.extendMethods(self, true)
end

function TdScene:init()
	Log.debug("TdScene:init")

	local stageCSV = CsvParser.getCsvData("td_stage", TdScene.stageID)

	CombatAttr.setAttrLevel(stageCSV.level)
	InfoTD.reset()
	self:initMap()
	Log.debug("TdScene:init initMap over")
	notify.safeRegister(self, "battle_state_change", function (isBattle)
		self.isBattle = isBattle
	end)

	self.tdUI = FRAME_td.new()

	self:addChild(self.tdUI)

	global.tdUI = self.tdUI
	global.ui = self.tdUI

	self:initModao()
	InfoModao.initDungeon(true)
end

function TdScene:initMap()
	local map = Map.new(display.width, display.height)

	self:addChild(map)
	map:setGamma(Sound.getGamma())
	map:load(TdScene.currentMap)

	global.map = map
	Map.walkOnVislble = false
	local battleCenter = MapEventManager.getEventByTagOne("td-center")
	local centerX, centerY = map:tileToMap(battleCenter.x, battleCenter.y)

	map:scrollTo(centerX, centerY)
	map:setFov(centerX, centerY)
end

function TdScene:refreshWeather()
	local showWeather = Cookie.get("showWeather") or 1

	if showWeather == 1 then
		self:initWeather()
	else
		self:clearWeather()
	end
end

function TdScene:clearWeather()
	MapEffect.rainStop()
	global.map:clearLightRGB()
end

function TdScene:initWeather()
	local random = Random.new(17)
	local perlin = Perlin.new(360, random)
	local now = Time.now() / MiscConfig.WEATHER_SCALE
	local weatherRan = math.min(1, math.max(0, perlin:noise(now, 1, 1) + 0.5))
	local weather = 0

	for i, v in ipairs(MiscConfig.WEATHERS) do
		if weatherRan <= v.ran then
			weather = v.weather

			break
		end
	end

	print("$$$ weather", weatherRan, weather, now)

	local colorDeday = 0

	if weather == 2 then
		MapEffect.rain(1, 0)

		colorDeday = 20
	elseif weather == 3 then
		MapEffect.rain(2, math.pi / 10)

		local nextLightningCount = math.random(900, 1500)

		Looper.startLoop(self, function (obj, frame, passed, sharp)
			if nextLightningCount < 0 then
				MapEffect.natureLightning(math.random(120, 200))
				self:performWithDelay(function ()
					local sound = MiscConfig.THUNDER_SOUND[math.random(1, #MiscConfig.THUNDER_SOUND)]

					Sound.playSound(sound)
				end, math.random() + 1)

				nextLightningCount = math.random(1800, 3600)
			else
				nextLightningCount = nextLightningCount - passed
			end
		end)

		colorDeday = 50
	else
		MapEffect.rainStop()
	end

	local nowHour = Time.nowHour()

	for i, v in ipairs(MiscConfig.HOUR_COLOR) do
		local nextV = MiscConfig.HOUR_COLOR[i + 1]

		if v.hour <= nowHour and nowHour < nextV.hour then
			local percent = 1 - (nowHour - v.hour) / (nextV.hour - v.hour)
			local r = math.min(255, math.max(0, math.floor(v.color[1] * percent + nextV.color[1] * (1 - percent) - colorDeday)))
			local g = math.min(255, math.max(0, math.floor(v.color[2] * percent + nextV.color[2] * (1 - percent) - colorDeday)))
			local b = math.min(255, math.max(0, math.floor(v.color[3] * percent + nextV.color[3] * (1 - percent) - colorDeday)))

			global.map:setLightRGB(cc.c3b(r, g, b))

			break
		end
	end
end

function TdScene:initModao()
	global.modao = Modao.new()
end

function TdScene:onEnter()
	app:onSceneEnter(self, nil, 1)
	self:init()
end

function TdScene:onExit()
	global.player = nil
	global.ui = nil
	global.map = nil
	global.battleUI = nil
	global.adventureUI = nil

	app:onSceneExit(self)
end

return TdScene
