local Notification = {
	refreshNotification = function ()
	end
}

return Notification
