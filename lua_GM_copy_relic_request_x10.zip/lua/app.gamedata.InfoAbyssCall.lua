local InfoAbyssCall = {}
local rawData = {}

function InfoAbyssCall.init()
	Connection.listen("abyss_call_sync", InfoAbyssCall.sync)
end

app:addToAppEnterCall(InfoAbyssCall.init)

function InfoAbyssCall.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			rawData = {}

			for i, data in ipairs(rcvData.list) do
				rawData[data.base_id] = data
			end

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("abyss_call_query", callback)
end

function InfoAbyssCall.sync(data)
	local changedIdStack = {}

	for i, syncData in ipairs(data.list) do
		local base_id = syncData.base_id

		if not rawData[base_id] then
			rawData[base_id] = syncData
		else
			for k, v in pairs(syncData) do
				rawData[base_id][k] = v
			end
		end

		changedIdStack[base_id] = rawData[base_id]
	end

	ManagerInfo.dataChange("abyss_call", changedIdStack, "base_id")
end

function InfoAbyssCall.recieve()
	local abyssLayer = InfoDungeon.getAbyssMaxLayer()
	local csvList = CsvParser.getCsvList("abyss_call")
	local arr = {}

	for i, v in ipairs(csvList) do
		if v.layer <= abyssLayer then
			if not rawData[v.id] then
				table.insert(arr, v.id)
			end
		else
			break
		end
	end

	if #arr > 0 then
		local function callback(rcvData)
			if rcvData.err then
				if onFailure then
					onFailure()
				end
			elseif onSuccess then
				onSuccess()
			end
		end

		Connection.request("abyss_call_receive", {
			list = arr
		}, callback)
	end
end

function InfoAbyssCall.read()
	if InfoAbyssCall.countRedot() > 0 then
		local function callback(rcvData)
			if rcvData.err then
				if onFailure then
					onFailure()
				end
			elseif onSuccess then
				onSuccess()
			end
		end

		Connection.request("abyss_call_read", callback)
	end
end

function InfoAbyssCall.countRedot()
	local redotCount = 0

	for base_id, v in pairs(rawData) do
		if v.is_read == 0 then
			redotCount = redotCount + 1

			break
		end
	end

	return redotCount
end

function InfoAbyssCall.getAbyssCallList()
	local arr = {}

	for base_id, v in pairs(rawData) do
		local csv = CsvParser.getCsvData("abyss_call", base_id, nil, true)

		if csv then
			table.insert(arr, {
				csv = csv,
				time = v.time,
				is_read = v.is_read
			})
		end
	end

	table.sort(arr, function (a, b)
		return b.csv.id < a.csv.id
	end)

	return arr
end

function InfoAbyssCall.showDate(time, calendar)
	local fullyear = os.date("%Y", time)
	local month = os.date("%m", time)
	local day = os.date("%d", time)
	local calendarStr = ""

	if calendar == 1 then
		fullyear = fullyear + 5585
		calendarStr = "星历"
	elseif calendar == 2 then
		fullyear = fullyear + 501
		calendarStr = "古代历"
	elseif calendar == 3 then
		fullyear = fullyear - 1347
		calendarStr = ""
	end

	return calendarStr .. " " .. fullyear .. "年" .. month .. "月" .. day .. "日"
end

return InfoAbyssCall
