local InfoCharge = {}
local data_map = {}

function InfoCharge.init()
	Connection.listen("charge_sync", InfoCharge.sync)
end

app:addToAppEnterCall(InfoCharge.init)

function InfoCharge.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoCharge.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("charge_query", callback)
end

function InfoCharge.onQuery(rcvData)
	dump(rcvData, "charge_query", 10)

	data_map = {}

	for i, v in ipairs(rcvData.list) do
		data_map[v.actv_id] = v
	end
end

function InfoCharge.sync(data)
	dump(data, "InfoCharge.sync", 10)

	if data.list then
		for i, syncData in ipairs(data.list) do
			if not data_map[syncData.actv_id] then
				data_map[syncData.actv_id] = syncData
			else
				for k, v in pairs(syncData) do
					data_map[syncData.actv_id][k] = v
				end
			end
		end
	end

	ManagerInfo.dataChange("charge")
	notify.dispatch("actv_redot")
end

function InfoCharge.getGift(actv_id, index, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "charge_get_gift")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("charge_get_gift", {
		actv_id = actv_id,
		index = index
	}, callback)
end

function InfoCharge.recoverGift(onSuccess, onFailure)
	for actv_id, dataOne in pairs(data_map) do
		local opening = InfoCharge.checkOpening(actv_id)
		local openingS = InfoCharge.checkShopOpening(actv_id)

		print("$$$ InfoCharge.recoverGift", opening, openingS)

		if openingS and not opening then
			local indexArr = {}
			local totalPay100 = InfoCharge.getTotalPay100(actv_id)

			print("$$$ total_pay", actv_id, totalPay100)

			for i, data in ipairs(dataOne.list) do
				if data.pay_100 <= totalPay100 and InfoCharge.getRecord(actv_id, i) == 0 then
					table.insert(indexArr, i)
				end
			end

			dump(indexArr, "$$$ indexArr")

			if #indexArr > 0 then
				local function callback(rcvData)
					dump(rcvData, "charge_gift_recover")

					if rcvData.err then
						if onFailure then
							onFailure(rcvData.err)
						end
					elseif onSuccess then
						onSuccess(rcvData)
					end
				end

				Connection.request("charge_gift_recover", {
					actv_id = actv_id,
					index_arr = indexArr
				}, callback)
			end
		end
	end
end

function InfoCharge.getRecord(actv_id, index)
	local dataOne = data_map[actv_id]

	if dataOne then
		return BitUtil.getBitByIndex(dataOne.gift_record, index)
	end

	return 0
end

function InfoCharge.getTotalPay100(actv_id)
	local dataOne = data_map[actv_id]

	if dataOne then
		return dataOne.total_pay_100
	end

	return 0
end

function InfoCharge.getTotalPay(actv_id)
	local dataOne = data_map[actv_id]

	if dataOne then
		return dataOne.total_pay_100 / 100
	end

	return 0
end

function InfoCharge.checkOpening(actv_id)
	local opening = InfoActv.checkBindOpening(actv_id, GameConfig.ACTV_TYPE.charge)

	return opening, actv_id
end

function InfoCharge.checkShopOpening(actv_id)
	local opening = InfoActv.checkBindShopOpening(actv_id, GameConfig.ACTV_TYPE.charge)

	return opening, actv_id
end

function InfoCharge.getList(actv_id)
	local opening = InfoCharge.checkOpening(actv_id)

	if opening and data_map[actv_id] and data_map[actv_id].list then
		return data_map[actv_id].list
	else
		return {}
	end
end

function InfoCharge.countRedot(actv_id)
	local redotCount = 0
	local opening = InfoCharge.checkOpening(actv_id)
	local totalPay100 = InfoCharge.getTotalPay100(actv_id)

	if opening then
		local dataOne = data_map[actv_id]

		if dataOne then
			for i, data in ipairs(dataOne.list) do
				if data.pay_100 <= totalPay100 and InfoCharge.getRecord(actv_id, i) == 0 then
					redotCount = redotCount + 1
				end
			end
		end
	end

	print("$$$ redotCount", redotCount)

	return redotCount
end

return InfoCharge
