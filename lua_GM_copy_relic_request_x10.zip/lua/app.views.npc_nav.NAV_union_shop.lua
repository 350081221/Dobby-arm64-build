local NAV_base = import(".NAV_base")
local NAV_union_shop = class("NAV_union_shop", NAV_base)

function NAV_union_shop.open(npc)
	local ui = NAV_union_shop.new(npc)

	return ui
end

function NAV_union_shop:ctor(npc)
	NAV_union_shop.super.ctor(self, npc, "nav_union_shop")
end

function NAV_union_shop:init()
	NAV_union_shop.super.init(self)
	self:refresh()
	ManagerInfo.onDataChange(self, "union", nil, function ()
		self:refresh()
	end)
end

function NAV_union_shop:refresh()
	local index = 2

	self:setButtonVisible(index, false)
end

function NAV_union_shop:onTap(index)
	NAV_union_shop.super.onTap(self, index)

	if index == 1 then
		FRAME_any_shop.open(InfoUnion, self.npc)
	elseif index == 2 then
		-- Nothing
	end
end

return NAV_union_shop
