local InfoGacha = {}
local rawData = nil
local groupScoreMap = {}
local openMap = {}
local shopOpenMap = {}
local shopList = nil
local shopRefreshIndex = 0

function InfoGacha.init()
	Connection.listen("gacha_sync", InfoGacha.sync)
	Connection.listen("gacha_open_sync", InfoGacha.syncOpen)
end

app:addToAppEnterCall(InfoGacha.init)

function InfoGacha.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoGacha.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("gacha_query", callback)
end

function InfoGacha.onQuery(rcvData)
	dump(rcvData, "gacha_query")

	rawData = rcvData

	if rcvData.score_group then
		for i, v in ipairs(rcvData.score_group) do
			groupScoreMap[v.group] = v.score
		end
	end

	openMap = {}

	for i, v in ipairs(rcvData.list) do
		openMap[v.id] = v.open
	end

	shopOpenMap = {}

	for i, v in ipairs(rcvData.shop_list) do
		shopOpenMap[v.id] = v.open
	end
end

function InfoGacha.syncOpen(data)
	dump(data, "$$$ InfoGacha.syncOpen")

	openMap = {}

	for i, v in ipairs(data.list) do
		openMap[v.id] = v.open
	end

	shopOpenMap = {}

	for i, v in ipairs(data.shop_list) do
		shopOpenMap[v.id] = v.open
	end

	ManagerInfo.dataChange("gacha")
end

function InfoGacha.sync(data)
	for k, v in pairs(data) do
		rawData[k] = v
	end

	if data.score_group then
		for i, v in ipairs(data.score_group) do
			groupScoreMap[v.group] = v.score
		end
	end

	ManagerInfo.dataChange("gacha", data)
end

function InfoGacha.getScore(group)
	local group_csv = CsvParser.getCsvData("gacha_group", group)

	return groupScoreMap[group_csv.score_group] or 0
end

function InfoGacha.checkOpen(id)
	if openMap[id] then
		return openMap[id] == 1
	else
		local csv = CsvParser.getCsvData("gacha", id)

		return csv.default_open == 1
	end
end

function InfoGacha.checkShopOpen(group)
	if empty(group) then
		return true
	end

	if shopOpenMap[group] then
		return shopOpenMap[group] == 1
	else
		return false
	end
end

function InfoGacha.gacha(id, cost_type, onSuccess, onFailure)
	if CONFIG.is_ta then
		local gachaCSV = CsvParser.getCsvData("gacha", id)

		if gachaCSV.type == 1 then
			TaHelper.startAsset("gacha_gacha_1")
		else
			TaHelper.startAsset("gacha_gacha_2")
		end
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if CONFIG.is_ta then
				TaHelper.endAsset()
			end

			if CONFIG.is_ta then
				local csv = CsvParser.getCsvData("gacha", id)
				local asset_info = {}
				local params = {
					cardpond_id = tostring(id),
					recruit_num = csv.times
				}

				TaHelper.taTrack("recruit", params)
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("gacha_gacha", {
		id = id,
		cost_type = cost_type
	}, callback)
end

function InfoGacha.getData()
	return rawData
end

function InfoGacha.getList(festival_id)
	local csvList = CsvParser.getCsvList("gacha", "__line")
	local nowTime = Time.now()
	local arr = {}

	for i, csv in ipairs(csvList) do
		if not empty(csv.festival_id) then
			if festival_id and festival_id == csv.festival_id then
				table.insert(arr, csv)
			end
		elseif not festival_id and InfoGacha.checkOpen(csv.id) then
			table.insert(arr, csv)
		end
	end

	return arr
end

function InfoGacha.hasScoreReward(group)
	local group_csv = CsvParser.getCsvData("gacha_group", group)

	return not empty(group_csv.score_reward)
end

function InfoGacha.getShopLabels()
	local shopCSVList = CsvParser.getCsvList("gacha_shop_label")

	return shopCSVList
end

function InfoGacha.clearOnReconnect()
	shopList = nil
end

function InfoGacha.getShopList(_callback)
	local needQuery = shopList == nil

	if not needQuery and rawData.shop_refresh_time < Time.now() then
		needQuery = true
	end

	if needQuery then
		local function callback(rcvData)
			if rcvData.err then
				-- Nothing
			else
				shopRefreshIndex = shopRefreshIndex + 1
				shopList = rcvData.items

				if _callback then
					_callback(shopList)
				end
			end
		end

		Connection.request("gacha_shop_list", callback)
	else
		_callback(shopList)
	end
end

function InfoGacha.getShopItems(tabID)
	local abyssLevel = InfoDungeon.getAbyssMaxLevel()
	local arr = {}
	local multiLabel = nil
	local shopCSVList = CsvParser.getCsvList("gacha_shop_label")
	local gacha_shop_open = InfoParams.getValue("gacha_shop_open")

	local function sortFunc(a, b)
		local csvA = CsvParser.getCsvData("gacha_shop", a.shop_id)
		local csvB = CsvParser.getCsvData("gacha_shop", b.shop_id)

		if csvA.index == csvB.index then
			return a.shop_id < b.shop_id
		else
			return csvA.index < csvB.index
		end
	end

	if #shopCSVList > 1 then
		local labelMap = {}

		for i, v in ipairs(shopList) do
			local shopCSV = CsvParser.getCsvData("gacha_shop", v.shop_id, nil, true)

			if shopCSV and InfoGacha.checkShopOpen(shopCSV.group) and shopCSV.abyss_level_min <= abyssLevel and abyssLevel <= shopCSV.abyss_level_max and (shopCSV.no_supply ~= 1 or v.soldout < shopCSV.times) then
				if not labelMap[shopCSV.label] then
					labelMap[shopCSV.label] = {}
				end

				table.insert(labelMap[shopCSV.label], v)
			end
		end

		for i, v in ipairs(shopCSVList) do
			local itemArr = labelMap[v.id]

			if itemArr then
				table.sort(itemArr, sortFunc)

				local obj = {
					label = v,
					items = itemArr
				}

				table.insert(arr, obj)
			end
		end

		multiLabel = true
	else
		local abyssLevel = InfoDungeon.getAbyssMaxLevel()

		for i, v in ipairs(shopList) do
			local shopCSV = CsvParser.getCsvData("gacha_shop", v.shop_id, nil, true)

			if shopCSV and InfoGacha.checkShopOpen(shopCSV.group) and shopCSV.abyss_level_min <= abyssLevel and abyssLevel <= shopCSV.abyss_level_max and (shopCSV.no_supply ~= 1 or v.soldout < shopCSV.times) then
				table.insert(arr, v)
			end
		end

		table.sort(arr, sortFunc)

		multiLabel = false
	end

	return arr, multiLabel
end

function InfoGacha.buy(shop_id, num, onSuccess, onFailure)
	local preIndex = shopRefreshIndex

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if rcvData.item then
				local item = rcvData.item

				if preIndex == shopRefreshIndex then
					for i, v in ipairs(shopList) do
						if v.shop_id == item.shop_id then
							for k1, v1 in pairs(item) do
								v[k1] = v1
							end
						end
					end
				end
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("gacha_shop_buy", {
		shop_id = shop_id,
		num = num
	}, callback)
end

function InfoGacha.getShopCSV()
	return "gacha_shop"
end

function InfoGacha.getCostNeed()
	return CsvParser.getCsvData("config", "gacha_shop_need").value
end

function InfoGacha.getShopName()
	return "gacha"
end

function InfoGacha.getShopTime()
	return rawData.shop_refresh_time, RefreshManager.getNextTime(RefreshManager.TYPE.GACHA_SHOP, Time.now())
end

function InfoGacha.getRefreshType()
	return RefreshManager.TYPE.GACHA_SHOP
end

function InfoGacha.countRedot()
	local redotCount = 0

	if InfoOrder.hasFreeGacha() then
		redotCount = redotCount + 1
	end

	return redotCount
end

return InfoGacha
