local InfoQn = {
	data = {}
}

function InfoQn.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoQn.data = {}

			for i, data in ipairs(rcvData.list) do
				InfoQn.data[data.qn_id] = data.content
			end

			if onSuccess then
				onSuccess()
			end
		end
	end

	Http.request("qn/query", callback)
end

function InfoQn.commit(qnID, content, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoQn.data[qnID] = content

			if onSuccess then
				onSuccess()
			end
		end
	end

	Http.request("qn/commit", {
		qn_id = qnID,
		content = content
	}, callback)
end

return InfoQn
