local InfoDustAttrManual = {}
local rawData = {}

function InfoDustAttrManual.init()
	Connection.listen("dust_attr_manual_sync", InfoDustAttrManual.sync)
end

app:addToAppEnterCall(InfoDustAttrManual.init)

function InfoDustAttrManual.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoDustAttrManual.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("dust_attr_manual_query", callback)
end

function InfoDustAttrManual.onQuery(rcvData)
	dump(rcvData, "dust_attr_manual_query")

	rawData = {}

	for i, data in ipairs(rcvData.list) do
		rawData[data.base_id] = data
	end
end

function InfoDustAttrManual.sync(data)
	dump(data, "$$$ InfoDustAttrManual.sync")

	if data.list then
		for i, syncData in ipairs(data.list) do
			local base_id = syncData.base_id

			if rawData[base_id] then
				for k, v in pairs(syncData) do
					rawData[base_id][k] = v
				end
			else
				rawData[base_id] = syncData
			end
		end
	end

	ManagerInfo.dataChange("dust_attr_manual")
end

function InfoDustAttrManual.getData(manualID)
	return rawData[manualID]
end

function InfoDustAttrManual.getReward(id, onSuccess, onFailure)
	print("$$$ InfoDustAttrManual.getReward", id)

	local function callback(rcvData)
		dump(rcvData, "dust_attr_manual_reward")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("dust_attr_manual_reward", {
		base_id = id
	}, callback)
end

function InfoDustAttrManual.getList()
	local items = {}
	local cols = 2
	local dustData = InfoDust.getDustData()
	local dustID = nil

	if dustData then
		dustID = dustData.id
	end

	local csvList = CsvParser.getCsvList("dust_attr_manual")
	local labelMap = {}

	for i, csv in ipairs(csvList) do
		if csv.dust_id == dustID then
			local base_id = csv.id

			if not labelMap[csv.manual_label] then
				labelMap[csv.manual_label] = {}
			end

			table.insert(labelMap[csv.manual_label], base_id)
		end
	end

	local labelArr = {}

	for label, arr in pairs(labelMap) do
		table.insert(labelArr, {
			label = label,
			arr = arr
		})
	end

	table.sort(labelArr, function (a, b)
		return a.label < b.label
	end)

	for i, v in ipairs(labelArr) do
		local label = v.label
		local arr = v.arr
		local obj = {
			line = true,
			labelCSV = CsvParser.getCsvData("dust_attr_manual_label", label)
		}

		table.insert(items, obj)

		for j = 1, cols - 1 do
			table.insert(items, {
				line = true,
				empty = true
			})

			v.jumpIndex = #items
		end

		local sortArr = {}

		for j, base_id in ipairs(arr) do
			local csv = CsvParser.getCsvData("dust_attr_manual", base_id)

			table.insert(sortArr, {
				csv = csv,
				sort = InfoDustAttrManual.getSort(csv)
			})
		end

		table.sort(sortArr, function (a, b)
			return b.sort < a.sort
		end)

		for index, v1 in ipairs(sortArr) do
			table.insert(items, v1)
		end

		local moreCols = #arr % cols

		if moreCols > 0 then
			for j = 1, cols - moreCols do
				table.insert(items, {
					empty = true
				})
			end
		end
	end

	return items, labelArr
end

function InfoDustAttrManual.countRedotLabel(arr)
	local redotCount = 0

	for index, base_id in ipairs(arr) do
		if rawData[base_id] and rawData[base_id].rewarded == 0 then
			redotCount = redotCount + 1

			break
		end
	end

	return redotCount
end

function InfoDustAttrManual.getSort(csv)
	local manualData = InfoDustAttrManual.getData(csv.id)
	local score = 0

	if manualData then
		if manualData.rewarded == 0 then
			score = 500
		else
			score = 400
		end
	else
		score = 300
		local attrCSV = CsvParser.getCsvData("dust_attr", csv.dust_attr_id)

		if not empty(attrCSV.dust_level_min) then
			local dustData = InfoDust.getData()

			if dustData.max_level < attrCSV.dust_level_min then
				score = 200
			end
		end
	end

	score = score - csv.star * 10
	score = score - csv.id / 100000000

	return score
end

function InfoDustAttrManual.countRedot(passID)
	local redotCount = 0

	for base_id, data in pairs(rawData) do
		local csv = CsvParser.getCsvData("dust_attr_manual", base_id)

		if csv.dust_id == passID and data.rewarded == 0 then
			redotCount = redotCount + 1
		end
	end

	return redotCount
end

return InfoDustAttrManual
