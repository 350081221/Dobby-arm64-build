local List = import(".List")
local Style = import(".Style")
local TextArea = class("TextArea", List)

function TextArea:ctor(rect, defaultStyle)
	TextArea.super.ctor(self, rect)

	self.defaultStyle = defaultStyle

	self:setCellName("text_area")
end

function TextArea:setUbbEnabled(enabled)
	self.ubbEnabled = enabled
end

local textSizeMap = {}

function TextArea:getCellSize(index)
	local data = self:getData(index)

	if not data then
		return cc.rect(0, 0, 0, 0)
	end

	if self.ubbEnabled then
		local code = data.text .. "_" .. data.style.size

		if not textSizeMap[code] then
			if not self.sampleUI then
				self.sampleUI = UIManager.getUI(self.cellName)

				self:addChild(self.sampleUI)
				self.sampleUI:setVisible(false)

				local flag = self.sampleUI:getFlagByTag("flag_text")
				flag.width = self.touchRect.width
				flag.height = 0
			end

			local ubbMap, labels, lines, totalWidth, totalHeight = self.sampleUI:createUbbOnFlag("flag_text", data.text, {
				wrap = true,
				yspace = 0,
				align = Style.left,
				valign = Style.vbottom
			}, true, data.style)
			textSizeMap[code] = {
				height = totalHeight
			}
		end

		return cc.rect(0, 0, self.touchRect.width, textSizeMap[code].height)
	else
		if not self.sampleUI then
			self.sampleUI = UIManager.getUI(self.cellName)

			self:addChild(self.sampleUI)
			self.sampleUI:setVisible(false)

			local flag = self.sampleUI:getFlagByTag("flag_text")
			flag.width = self.touchRect.width
			flag.height = 0
		end

		data.style.wrap = true
		data.style.valign = Style.vbottom
		local label, labelWidth, labelHeight = self.sampleUI:createLabelOnFlag("flag_text", data.text, data.style)

		return cc.rect(0, 0, labelWidth, labelHeight)
	end
end

function TextArea:setMax(num)
	self.maxNum = num
end

function TextArea:setText(text, style)
	self:setItems({
		{
			text = text,
			style = self:getStyle(style)
		}
	})
end

function TextArea:addText(text, style)
	self:addItems({
		{
			text = text,
			style = self:getStyle(style)
		}
	})

	if self.maxNum and self.maxNum < #self.items then
		self:removeFirst()
	end
end

function TextArea:getStyle(style)
	style = style or {}
	local __style = {}

	if self.defaultStyle then
		for k, v in pairs(self.defaultStyle) do
			__style[k] = v
		end
	end

	if style then
		for k, v in pairs(style) do
			__style[k] = v
		end
	end

	__style.valign = Style.vcenter

	return __style
end

function TextArea:onCellInit(ui, data)
	ui:removeLabelOnFlag("flag_text")
	ui:removeLabelGroupOnFlag("flag_text")

	local flag = ui:getFlagByTag("flag_text")
	flag.width = self.touchRect.width
	flag.height = 0

	if self.ubbEnabled then
		local flag = ui:getFlagByTag("flag_text")
		local ubbMap, labels, lines, totalWidth, totalHeight = ui:createUbbOnFlag("flag_text", data.text, {
			wrap = true,
			yspace = 0,
			align = Style.left,
			valign = Style.vbottom
		}, true, data.style)
	else
		data.style.wrap = true
		data.style.valign = Style.vbottom
		local label, labelWidth, labelHeight = ui:createLabelOnFlag("flag_text", data.text, data.style)
	end

	ui:setCascadeOpacityEnabled(true)
end

function TextArea:onExit()
	if not app.sceneChanging and self.sampleUI then
		self.sampleUI:removeSelf()

		self.sampleUI = nil
	end

	TextArea.super.onExit(self)
end

return TextArea
