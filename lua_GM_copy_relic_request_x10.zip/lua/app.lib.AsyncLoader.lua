local meta = class("AsyncLoader")

function meta:ctor()
	self.progress_func_array = {}
	self.progress_msg_array = {}
	self.progress_index = 1
end

function meta:add(executer, msg)
	table.insert(self.progress_func_array, executer)
	table.insert(self.progress_msg_array, msg or "")
end

function meta:count()
	return #self.progress_func_array
end

function meta:start(onSuccess, onFailure, onProgress)
	self.onSuccess = onSuccess
	self.onFailure = onFailure
	self.onProgress = onProgress

	if self.onProgress then
		self.onProgress(0, #self.progress_func_array, self.progress_msg_array[1])
	end

	self:next()
end

function meta:next()
	if self.stopped then
		return
	end

	if self.progress_index <= #self.progress_func_array then
		local function _error_callback()
			if self.onFailure then
				self.onFailure()
			end
		end

		local function _complete_callback()
			if self.onProgress then
				self.onProgress(self.progress_index, #self.progress_func_array, self.progress_msg_array[self.progress_index + 1])
			end

			self.progress_index = self.progress_index + 1

			self:next()
		end

		local async_executer = self.progress_func_array[self.progress_index]

		if async_executer then
			async_executer(_complete_callback, _error_callback)
		end
	elseif self.onSuccess then
		self.onSuccess()
	end
end

function meta:stop()
	self.stopped = true
end

return meta
