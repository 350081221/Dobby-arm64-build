local UI_base = import(".UI_base")
local FRAME_main_head = class("FRAME_main_head", UI_base)
local HERO_HEAD_HEIGHT = 64
local PET_HEAD_HEIGHT = 64

function FRAME_main_head:ctor(isBattle, onCLickHead, isArena)
	FRAME_main_head.super.ctor(self, "frame_main_head", UIManager.BIG_TYPE.TOP)

	self.isBattle = isBattle
	self.onCLickHead = onCLickHead
	self.isArena = isArena

	self:init()
end

function FRAME_main_head:init()
	self:initUI()

	if not self.isArena then
		self:refresh()
		notify.safeRegister(self, "team_refresh_team", function (data)
			self:refresh()
			self:refreshQuickQuestPosition()
		end)
		self:refreshPet()
		ManagerInfo.onDataChange(self, "pet", nil, function (idStack, idMap)
			for i, id in ipairs(idStack) do
				local petInfo = InfoPet.getPet(id)

				if petInfo and (petInfo.pos > 0 or self.petHeadMap and self.petHeadMap[petInfo.id]) then
					self:refreshPet()

					return
				end
			end
		end)
		notify.safeRegister(self, "team_refresh_pet", function (data)
			self:refreshPet()
		end)
		ManagerInfo.onDataChange(self, "main_guide", nil, function ()
			self:refreshPet()
		end)
	end

	if DEV_MODE then
		notify.safeRegister(self, "tongji_on_off", function (data)
			self:clear()
			self:refresh()
			self:refreshQuickQuestPosition()
			self:refreshPet()
		end)
	end

	if self.isBattle then
		notify.safeRegister(self, "active_pet", function (unit)
			self:onActivePet(unit)
		end)
		notify.safeRegister(self, "battle_over", function ()
			self:onBattleOver()
		end)
	end

	self:refreshLiuhai()
	notify.safeRegister(self, "liuhai_change", function ()
		self:refreshLiuhai()
	end)
end

function FRAME_main_head:refreshLiuhai()
	if UIManager.getLiuhai() == "left" then
		self:setPositionX(UIManager.LIUHAI_WIDTH)
	else
		self:setPositionX(0)
	end
end

function FRAME_main_head:initUI()
	self.petContainer = display.newNode()

	self.petContainer:setCascadeOpacityEnabled(true)
	self:addChild(self.petContainer)
end

function FRAME_main_head:ready()
	self:arrangePet()
end

function FRAME_main_head:setTeam(team)
	self.team = team

	self:refresh()
end

function FRAME_main_head:clearTeam()
	self.team = nil

	self:refresh()
end

function FRAME_main_head:setPetTeam(petTeam)
	self.petTeam = petTeam

	self:refreshPet()
end

function FRAME_main_head:clearPetTeam()
	self.petTeam = nil

	self:refreshPet()
end

function FRAME_main_head:refresh()
	if not self.teamHeads then
		self.teamHeads = {}
	end

	if global.tongji then
		self.heroHeadMap = {}
	end

	local teamUnits = self.team or TeamManager.getTeam()
	local headFlag = self:getFlagByTag("flag_head")
	local baseY = HERO_HEAD_HEIGHT

	for i, unit in ipairs(teamUnits) do
		local heroInfo = unit.info
		local headView = self.teamHeads[i]

		if not headView then
			if global.tongji then
				headView = BattleHead.new("com_battle_head_dmg")

				headView:createBarByTag("dmg_bar", cc.c3b(220, 0, 0))
				headView:setBarProgressByTag("dmg_bar", 0)
			else
				headView = BattleHead.new("com_battle_head")
			end

			headView:setPosition(headFlag.x, headFlag.y + headFlag.height - baseY)
			self:addChild(headView)

			self.teamHeads[i] = headView
		end

		if global.tongji then
			self.heroHeadMap[unit.info.id] = headView
		end

		headView:setUnit(unit)
		headView:setBattleEventEnabled(true)

		local starType, starNum = InfoHero.getStar(heroInfo)
		local stars = UIUtil.createStar(headView, "star", starNum, 8, 0, Style.center, starType == InfoHero.STAR_TYPE.PEAK and 4 or 1, 0.6666666666666666, 2000)

		if self.onCLickHead then
			headView:addTap(function ()
				if self.onCLickHead then
					self.onCLickHead(DropManager.TYPE.HERO, heroInfo)
				end
			end)
		end

		baseY = baseY + HERO_HEAD_HEIGHT
	end

	for i = #teamUnits + 1, #self.teamHeads do
		self.teamHeads[i]:removeSelf()

		self.teamHeads[i] = nil
	end

	self.petContainer:setPosition(headFlag.x, headFlag.y - HERO_HEAD_HEIGHT * (#teamUnits - 1) - 10)
end

function FRAME_main_head:refreshPet()
	if not self.petHeads then
		self.petHeads = {}
	end

	self.petHeadMap = {}
	local petInfos = self.petTeam or InfoPet.getTeam()

	if InfoDungeon.isFixedTeam() then
		petInfos = StageUtils.getFixedPet()
	end

	for i, petInfo in ipairs(petInfos) do
		local headView = self.petHeads[i]

		if not headView then
			if global.tongji then
				headView = BattleHead.new("com_battle_head_pet_dmg")

				headView:createBarByTag("dmg_bar", cc.c3b(220, 0, 0))
				headView:setBarProgressByTag("dmg_bar", 0)
			else
				headView = BattleHead.new("com_battle_head_pet")
			end

			self.petContainer:addChild(headView)

			self.petHeads[i] = headView
		end

		self.petHeadMap[petInfo.id] = headView
		headView.petInfo = petInfo

		headView:setPetInfo(petInfo)
		headView:setBattleEventEnabled(false)

		local starType, starNum = InfoPet.getStar(petInfo)
		local stars = UIUtil.createStar(headView, "star", starNum, 8, 0, Style.center, starType == InfoHero.STAR_TYPE.PEAK and 4 or 1, 0.6666666666666666, 2000)
		local beganTime = nil

		headView:addTouch(function (event, x, y)
			if event == "began" then
				beganTime = Time.time()

				self:addEnterFrame("headView_touching", function ()
					local now = Time.time()

					if now - beganTime >= 0.3 then
						self:removeEnterFrame("headView_touching")

						beganTime = nil

						if not WarMachine.on or headView:isTouchEnabledTag() then
							InfoPet.setPet(i, function ()
								UIManager.callTapGroup("button_click")
								self:arrangePet()
							end)
						end
					end
				end)
			elseif event == "ended" then
				self:removeEnterFrame("headView_touching")

				if beganTime and headView:getTouchOver(x, y) then
					if WarMachine.on then
						-- Nothing
					elseif self.onCLickHead then
						UIManager.callTapGroup("button_click")
						self.onCLickHead(DropManager.TYPE.PET, petInfo)
					end
				end
			end
		end)
	end

	for i = #petInfos + 1, #self.petHeads do
		self.petHeads[i]:removeSelf()

		self.petHeads[i] = nil
	end

	local addY = self:arrangePet()

	if self.guidePet then
		self:removeEnterFrame("guidePet_refresh")
		self.guidePet:removeSelf()

		self.guidePet = nil
	end

	if self.guideUI then
		self.guideUI:removeSelf()

		self.guideUI = nil
	end

	if self.previewUI then
		self.previewUI:removeSelf()

		self.previewUI = nil
	end

	if not self.isBattle then
		local guidePetTime = InfoGuide.getGuidePetTime()

		if guidePetTime then
			local guidePet = UIManager.getUI("com_guide_pet")

			self.petContainer:addChild(guidePet)
			guidePet:setPositionY(addY)

			addY = addY - 125
			self.guidePet = guidePet
			local bg = guidePet:getComponentByTag("bg")

			bg:toTouchable()
			bg:addTap(function ()
				if WarMachine.on then
					return
				end

				local timeLeft = math.max(0, guidePetTime - Time.now())

				if timeLeft > 0 then
					POP_msg.open(Localization.getSrcText("等待宠物孵化中……"))
				else
					InfoGuide.getGuidePet(function ()
						TeamManager.refreshBattleData()
						self:refreshPet()
					end)
				end
			end)

			local guide_pet_item = CsvParser.getCsvData("config", "guide_pet_item").value
			local icon = guidePet:createIconOnFlag("flag_icon", IconManager.getItemIcon(guide_pet_item), 100, true)

			Style.makePuyo(icon, interval, baseScale)

			local redot = guidePet:getComponentByTag("redot")

			redot:setLocalZOrder(1000)

			local function refreshTime()
				local timeLeft = math.max(0, guidePetTime - Time.now())

				if timeLeft > 0 then
					redot:setVisible(false)
					guidePet:createLabelOnFlag("flag_time", Time.format(timeLeft), {
						color = Style.font3
					})
				else
					redot:setVisible(true)
					guidePet:createLabelOnFlag("flag_time", Localization.getSrcText("可孵化"), {
						color = Style.enableColor
					})
					self:removeEnterFrame("guidePet_refresh")
				end
			end

			self:addEnterFrame("guidePet_refresh", refreshTime)
			refreshTime()
		end

		local guideCSV = nil
		local currentGuide = InfoGuide.getCurrent()

		if currentGuide then
			if currentGuide == 7040 then
				local checkBlueLevel = nil
				local team = InfoHero.getTeam()

				for i, heroInfo in ipairs(team) do
					if heroInfo.quality == 2 and heroInfo.level >= 20 then
						checkBlueLevel = true

						break
					end
				end

				local bagItems = InfoItem.getWareList(3)

				if #bagItems == 0 or checkBlueLevel then
					InfoGuide.finish(currentGuide)
					InfoGuide.setID(currentGuide)

					currentGuide = InfoGuide.getCurrent()
				end
			end

			guideCSV = CsvParser.getCsvData("guide", currentGuide)
		end

		if guideCSV then
			local guideUI = UIManager.getUI("com_main_guide")

			self.petContainer:addChild(guideUI)
			guideUI:setPositionY(addY)

			self.guideUI = guideUI
			local bg = guideUI:getComponentByTag("bg")

			bg:setOpacity(200)

			local str = guideCSV.text_camp

			if InfoDungeon.inDungeon() then
				local maxLayer = InfoDungeon.getAbyssMaxLayer()

				if guideCSV.fin_type == 4 and guideCSV.fin_value <= maxLayer then
					str = guideCSV.text_dungeon_clear
				else
					str = guideCSV.text_dungeon
				end
			end

			if not empty(str) then
				guideUI:setVisible(true)
				guideUI:createUbbOnFlag("flag_text", str, {
					wrap = true,
					yspace = 0
				}, true)
			else
				guideUI:setVisible(false)
			end
		elseif not InfoDungeon.inDungeon() and InfoGuide.isFin() then
			local previewCSV = InfoDungeon.getAbyssPreview()

			if previewCSV then
				local previewUI = UIManager.getUI("com_abyss_preview")

				self.petContainer:addChild(previewUI)
				previewUI:setPositionY(addY)

				self.previewUI = previewUI
				local bg = previewUI:getComponentByTag("bg")

				bg:setOpacity(200)

				local text = string.gsub(previewCSV.desc, "\\n", "\n")
				local label, labelWidth, labelHeight = previewUI:createLabelOnFlag("flag_text", text)

				bg:setSize(labelWidth + 80)

				local iconContainer = display.newNode()

				previewUI:addChild(iconContainer, 1000)

				local flag = previewUI:getFlagByTag("flag_icon")
				local icon = display.newSprite(IconManager.getItemIcon(previewCSV.icon), flag.x + flag.width / 2, flag.y + flag.height / 2)
				local size = icon:getContentSize()

				icon:setScaleX(flag.width / size.width)
				icon:setScaleY(flag.height / size.height)
				iconContainer:addChild(icon)
				Style.makePuyo(icon, interval, baseScale)

				local icon_bg = previewUI:getComponentByTag("icon_bg")
				local iconBgX = icon_bg:getPositionX()
				local hideDistance = labelWidth + 5
				local hiding = global.previewHiding
				local moving = nil
				local easingTime = 0.2

				local function refreshHiding()
					global.previewHiding = hiding
					moving = true

					if hiding then
						transition.moveTo(previewUI, {
							easing = "backIn",
							time = easingTime,
							x = -hideDistance,
							onComplete = function ()
								moving = false
							end
						})
						transition.moveTo(iconContainer, {
							easing = "backIn",
							time = easingTime,
							x = hideDistance
						})
						transition.moveTo(icon_bg, {
							easing = "backIn",
							time = easingTime,
							x = iconBgX + hideDistance
						})
						transition.fadeTo(label, {
							opacity = 0,
							easing = "sineOut",
							time = easingTime
						})
					else
						transition.moveTo(previewUI, {
							x = 0,
							easing = "sineOut",
							time = easingTime,
							onComplete = function ()
								moving = false
							end
						})
						transition.moveTo(iconContainer, {
							x = 0,
							easing = "sineOut",
							time = easingTime
						})
						transition.moveTo(icon_bg, {
							easing = "sineOut",
							time = easingTime,
							x = iconBgX
						})
						transition.fadeTo(label, {
							opacity = 255,
							time = easingTime
						})
					end
				end

				if hiding then
					refreshHiding()
				end

				icon_bg:setOpacity(0)

				if A_wing then
					local effect = Animation.new()

					effect:setBlendFunc(gl.DST_COLOR, gl.ONE)
					effect:load("rect_1")
					effect:setLooper(MapFrameManager.core)

					local bgSize = bg:getContentSize()
					local bgX, bgY = bg:getPosition()

					dump(bgSize, "$$$ bgSize")
					effect:setPosition(bgX, bgY)
					effect:setInnerScale(bgSize.width / 162, bgSize.height / 50)
					previewUI:addChild(effect)
					effect:setLocalZOrder(1000)
					bg:toTouchable()
					bg:setTapGroup("bg_click")
					bg:addTap(function ()
						dump(previewCSV, "$$$ previewCSV")

						if self.guideMoving then
							self.guideMoving = nil

							GuideManager.removeGuideMove()
						else
							self.guideMoving = true

							GuideManager.goPointNpc(previewCSV)
						end
					end)
				else
					icon_bg:toTouchable()
					icon_bg:setTapGroup("bg_click")
					icon_bg:addTap(function ()
						if not moving then
							hiding = not hiding

							refreshHiding()
						end
					end)
				end
			end
		end
	end
end

function FRAME_main_head:arrangePet()
	local petIndex = InfoPet.getPetIndex()
	local addY = 0

	for i, headView in ipairs(self.petHeads) do
		headView:setPositionY(addY)

		if petIndex == i then
			headView:setScale(1)

			addY = addY - PET_HEAD_HEIGHT - 1
		else
			headView:setScale(0.7)

			addY = addY - PET_HEAD_HEIGHT * 0.7 - 1
		end
	end

	return addY
end

function FRAME_main_head:resetPet()
	for i, headView in ipairs(self.petHeads) do
		headView:refillHp()
	end
end

function FRAME_main_head:refreshQuickQuestPosition()
	if self.quickQuest then
		local headFlag = self:getFlagByTag("flag_head")
		local headNum = 0

		if self.teamHeads then
			headNum = #self.teamHeads
		end

		self.quickQuest:setPositionY(headFlag.y - HERO_HEAD_HEIGHT * headNum + 40)
	end
end

function FRAME_main_head:onActivePet(unit)
end

function FRAME_main_head:onBattleOver()
	if global.tongji and self.petHeads then
		for i, headView in ipairs(self.petHeads) do
			headView:resetCD()
			headView:replaceLabelOnFlag("flag_dmg", nil, 0, 0)
			headView:replaceLabelOnFlag("flag_as", nil, 0, 0)
		end
	end

	self:refreshPet()
end

function FRAME_main_head:setHeroDmg(heroID, total, s, a)
	if self.heroHeadMap then
		local headView = self.heroHeadMap[heroID]

		if headView then
			local selfTotal = s + a

			if headView:getFlagByTag("flag_dmg") then
				headView:replaceLabelOnFlag("flag_dmg", nil, DmgCount.transNumber(selfTotal), math.round(selfTotal / total * 100))
				headView:replaceLabelOnFlag("flag_as", nil, math.round(a / selfTotal * 100), math.round(s / selfTotal * 100))
				headView:setBarProgressByTag("dmg_bar", selfTotal / total)
			end
		end
	end
end

function FRAME_main_head:setPetDmg(petID, total, s, a)
	local headView = self.petHeadMap[petID]

	if headView then
		local selfTotal = s + a

		if headView:getFlagByTag("flag_dmg") then
			headView:replaceLabelOnFlag("flag_dmg", nil, DmgCount.transNumber(selfTotal), math.round(selfTotal / total * 100))
			headView:replaceLabelOnFlag("flag_as", nil, math.round(a / selfTotal * 100), math.round(s / selfTotal * 100))
			headView:setBarProgressByTag("dmg_bar", selfTotal / total)
		end
	end
end

function FRAME_main_head:clear()
	if not self.isBattle then
		print("$$$ FRAME_main_head:clear")
	end

	for i, headView in ipairs(self.teamHeads) do
		headView:removeSelf()
	end

	for i, headView in ipairs(self.petHeads) do
		headView:removeSelf()
	end

	self.teamHeads = nil
	self.petHeads = nil
	self.petHeadMap = {}
end

return FRAME_main_head
