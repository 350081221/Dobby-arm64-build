local POP_skill_test = class("POP_skill_test", UI_base)
local instance = nil

function POP_skill_test.open(eventData, onRefresh)
	if instance then
		instance:removeSelf()

		instance = nil
	end

	instance = POP_skill_test.new(eventData, onRefresh)
	POP_skill_test.opening = true

	global.map:setPositionOffset("POP_skill_test", -150, 0)
	display.getRunningScene():addChild(instance, LayerConfig.notice)
end

function POP_skill_test.close()
	if instance then
		instance:removeSelf()

		instance = nil
	end

	POP_skill_test.opening = false

	global.map:setPositionOffset("POP_skill_test", 0, 0)
end

function POP_skill_test.isOpening()
	return instance ~= nil
end

function POP_skill_test.clearUnits()
	if instance then
		instance.attacker = nil
		instance.target = nil
		instance.otherTargets = nil
	end
end

function POP_skill_test.setUnits(attacker, target, otherTargets)
	if instance then
		instance.attacker = attacker
		instance.target = target
		instance.otherTargets = otherTargets
	end
end

function POP_skill_test:ctor(eventData, onRefresh)
	POP_skill_test.super.ctor(self, "pop_skill_test")

	self.eventData = eventData
	self.onRefresh = onRefresh

	self:init()
end

function POP_skill_test:init()
	self:initUI()
end

function POP_skill_test:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local skillEB = nil
	skillEB = self:createEditBoxOnComponent("eb_skill", function ()
		Cookie.set("POP_skill_test_skill", skillEB:getText(), true)
	end)

	if Cookie.get("POP_skill_test_skill") then
		skillEB:setText(Cookie.get("POP_skill_test_skill"))
	end

	local buffEB = nil
	buffEB = self:createEditBoxOnComponent("eb_buff", function ()
		Cookie.set("POP_skill_test_buff", buffEB:getText(), true)
	end)

	if Cookie.get("POP_skill_test_buff") then
		buffEB:setText(Cookie.get("POP_skill_test_buff"))
	end

	local pb_skill = self:getComponentByTag("pb_skill")

	pb_skill:toTouchable()
	pb_skill:addTap(function ()
		local skills = CsvParser.getCsvList("skill")

		POP_sheet_select.open("skill", skills, function (data)
			self:pushSkillHistory(data.id)
			Cookie.set("POP_skill_test_skill", data.id, true)
			skillEB:setText(Cookie.get("POP_skill_test_skill"))
		end)
	end)

	local attackPB = self:getComponentByTag("pb_attack")

	attackPB:toTouchable()
	attackPB:addTap(function ()
		if self.attacker and self.target then
			self.target:refill()

			for i, unit in ipairs(self.otherTargets) do
				unit:refill()
			end

			self.target:faceTo(self.attacker)
			self.attacker:faceTo(self.target)

			local skillID = tonumber(skillEB:getText())

			if skillID and CsvParser.getCsvData("skill", skillID, nil, true) then
				local skillPack = self.attacker:addSkill(tonumber(skillEB:getText()))

				if skillPack then
					self.attacker:castManualSkill(skillPack, self.target)
				end
			end
		end
	end)

	local attackerEB = nil
	attackerEB = self:createEditBoxOnComponent("eb_attacker", function ()
		Cookie.set("POP_skill_test_attacker", attackerEB:getText(), true)
		self:onSelectUnit()
	end)

	if Cookie.get("POP_skill_test_attacker") then
		attackerEB:setText(Cookie.get("POP_skill_test_attacker"))
	end

	local targetEB = nil
	targetEB = self:createEditBoxOnComponent("eb_target", function ()
		Cookie.set("POP_skill_test_target", targetEB:getText(), true)
		self:onSelectUnit()
	end)

	if Cookie.get("POP_skill_test_target") then
		targetEB:setText(Cookie.get("POP_skill_test_target"))
	end

	local pb_attacker_hero = self:getComponentByTag("pb_attacker_hero")

	pb_attacker_hero:toTouchable()
	pb_attacker_hero:addTap(function ()
		local heros = CsvParser.getCsvList("hero_templete")

		POP_sheet_select.open("hero_templete", heros, function (data)
			Cookie.set("POP_skill_test_attacker", "hero:" .. data.id, true)
			attackerEB:setText(Cookie.get("POP_skill_test_attacker"))
			self:onSelectUnit()
		end)
	end)

	local pb_attacker_monster = self:getComponentByTag("pb_attacker_monster")

	pb_attacker_monster:toTouchable()
	pb_attacker_monster:addTap(function ()
		local monsters = CsvParser.getCsvList("monster")

		POP_sheet_select.open("monster", monsters, function (data)
			Cookie.set("POP_skill_test_attacker", "monster:" .. data.id, true)
			attackerEB:setText(Cookie.get("POP_skill_test_attacker"))
			self:onSelectUnit()
		end)
	end)

	local pb_target_hero = self:getComponentByTag("pb_target_hero")

	pb_target_hero:toTouchable()
	pb_target_hero:addTap(function ()
		local heros = CsvParser.getCsvList("hero_templete")

		POP_sheet_select.open("hero_templete", heros, function (data)
			Cookie.set("POP_skill_test_target", "hero:" .. data.id, true)
			targetEB:setText(Cookie.get("POP_skill_test_target"))
			self:onSelectUnit()
		end)
	end)

	local pb_target_monster = self:getComponentByTag("pb_target_monster")

	pb_target_monster:toTouchable()
	pb_target_monster:addTap(function ()
		local monsters = CsvParser.getCsvList("monster")

		POP_sheet_select.open("monster", monsters, function (data)
			Cookie.set("POP_skill_test_target", "monster:" .. data.id, true)
			targetEB:setText(Cookie.get("POP_skill_test_target"))
			self:onSelectUnit()
		end)
	end)

	local pb_skill_history = self:getComponentByTag("pb_skill_history")

	pb_skill_history:toTouchable()
	pb_skill_history:addTap(function ()
		local skills = {}
		local historyArr = Cookie.get("POP_skill_test_skill_history") or {}

		for i, v in ipairs(historyArr) do
			table.insert(skills, 1, CsvParser.getCsvData("skill", v))
		end

		POP_sheet_select.open("", skills, function (data)
			self:pushSkillHistory(data.id)
			Cookie.set("POP_skill_test_skill", data.id, true)
			skillEB:setText(Cookie.get("POP_skill_test_skill"))
		end)
	end)

	local pb_buff = self:getComponentByTag("pb_buff")

	pb_buff:toTouchable()
	pb_buff:addTap(function ()
		local buffs = CsvParser.getCsvList("buff")

		POP_sheet_select.open("buff", buffs, function (data)
			self:pushBuffHistory(data.id)
			Cookie.set("POP_skill_test_buff", data.id, true)
			buffEB:setText(Cookie.get("POP_skill_test_buff"))
		end)
	end)

	local pb_buff_history = self:getComponentByTag("pb_buff_history")

	pb_buff_history:toTouchable()
	pb_buff_history:addTap(function ()
		local buffs = {}
		local historyArr = Cookie.get("POP_skill_test_buff_history") or {}

		for i, v in ipairs(historyArr) do
			table.insert(buffs, 1, CsvParser.getCsvData("buff", v))
		end

		POP_sheet_select.open("", buffs, function (data)
			self:pushBuffHistory(data.id)
			Cookie.set("POP_skill_test_buff", data.id, true)
			buffEB:setText(Cookie.get("POP_skill_test_buff"))
		end)
	end)

	local buff_enabled_1 = false
	local pb_buff_1 = self:getComponentByTag("pb_buff_1")
	local enable_buff_1 = self:getComponentByTag("enable_buff_1")

	pb_buff_1:toTouchable()
	pb_buff_1:addTap(function ()
		if buff_enabled_1 then
			buff_enabled_1 = false

			if self.attacker.testBuffObj then
				self.attacker:_removeBuff(CombatUnit.BUFF_TYPE.TEST, self.attacker.testBuffObj)

				self.attacker.testBuffObj = nil
			end
		else
			local buff_id = buffEB:getText()
			local buff_csv = CsvParser.getCsvData("buff", buff_id, nil, true)

			if not buff_csv then
				Alert.open("no buff id:" .. buff_id)

				return
			end

			local buffObj = nil

			if buff_csv.is_helpful == 1 then
				local attackPack = DamageRule.generateDotPack(self.attacker, self.attacker.attrs, buff_csv)
				buffObj = self.attacker:_addBuff(CombatUnit.BUFF_TYPE.TEST, buff_id, nil, attackPack, nil, self.attacker.id)
			else
				local attackPack = DamageRule.generateDotPack(self.target, self.target.attrs, buff_csv)
				buffObj = self.attacker:_addBuff(CombatUnit.BUFF_TYPE.TEST, buff_id, nil, attackPack, nil, self.target.id)
			end

			self.attacker.testBuffObj = buffObj
			buff_enabled_1 = true
		end

		enable_buff_1:setVisible(buff_enabled_1)
	end)

	local buff_enabled_2 = false
	local pb_buff_2 = self:getComponentByTag("pb_buff_2")
	local enable_buff_2 = self:getComponentByTag("enable_buff_2")

	pb_buff_2:toTouchable()
	pb_buff_2:addTap(function ()
		if buff_enabled_2 then
			buff_enabled_2 = false

			if self.target.testBuffObj then
				self.target:_removeBuff(CombatUnit.BUFF_TYPE.TEST, self.target.testBuffObj)

				self.target.testBuffObj = nil
			end
		else
			local buff_id = buffEB:getText()
			local buff_csv = CsvParser.getCsvData("buff", buff_id, nil, true)

			if not buff_csv then
				Alert.open("no buff id:" .. buff_id)

				return
			end

			local buffObj = nil

			if buff_csv.is_helpful == 1 then
				local attackPack = DamageRule.generateDotPack(self.target, self.target.attrs, buff_csv)
				buffObj = self.target:_addBuff(CombatUnit.BUFF_TYPE.TEST, buff_id, nil, attackPack, nil, self.target.id)
			else
				local attackPack = DamageRule.generateDotPack(self.attacker, self.attacker.attrs, buff_csv)
				buffObj = self.target:_addBuff(CombatUnit.BUFF_TYPE.TEST, buff_id, nil, attackPack, nil, self.attacker.id)
			end

			self.target.testBuffObj = buffObj
			buff_enabled_2 = true
		end

		enable_buff_2:setVisible(buff_enabled_2)
	end)
	enable_buff_1:setVisible(false)
	enable_buff_2:setVisible(false)
end

function POP_skill_test:pushBuffHistory(buffID)
	local historyArr = Cookie.get("POP_skill_test_buff_history") or {}

	for i, v in ipairs(historyArr) do
		if v == buffID then
			table.remove(historyArr, i)

			break
		end
	end

	table.insert(historyArr, buffID)

	if #historyArr > 20 then
		table.remove(historyArr, 1)
	end

	Cookie.set("POP_skill_test_buff_history", historyArr, true)
end

function POP_skill_test:pushSkillHistory(skillID)
	local historyArr = Cookie.get("POP_skill_test_skill_history") or {}

	for i, v in ipairs(historyArr) do
		if v == skillID then
			table.remove(historyArr, i)

			break
		end
	end

	table.insert(historyArr, skillID)

	if #historyArr > 20 then
		table.remove(historyArr, 1)
	end

	Cookie.set("POP_skill_test_skill_history", historyArr, true)
end

function POP_skill_test:onSelectUnit()
	if self.onRefresh then
		Looper.setTimeout(function ()
			if self.onRefresh then
				self.onRefresh()
			end
		end, 5)
	end
end

return POP_skill_test
