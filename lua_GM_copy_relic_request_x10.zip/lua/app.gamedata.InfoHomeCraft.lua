local InfoHomeCraft = {}

function InfoHomeCraft.init()
	Connection.listen("home_craft_shop_sync", InfoHomeCraft.sync)
end

app:addToAppEnterCall(InfoHomeCraft.init)

local shopList, otherShopList = nil

function InfoHomeCraft.sync(syncData)
	if syncData.item then
		local item = syncData.item

		if shopList then
			for i, v in ipairs(shopList) do
				if v.shop_id == item.shop_id then
					for k1, v1 in pairs(item) do
						v[k1] = v1
					end
				end
			end
		end
	end

	ManagerInfo.dataChange("home_craft_shop")
end

function InfoHomeCraft.getShopLabels()
	return nil
end

function InfoHomeCraft.getShopLabelCSV()
	return "home_craft_shop_label"
end

function InfoHomeCraft.clearOnReconnect()
	shopList = nil
end

function InfoHomeCraft.getShopList(_callback)
	local needQuery = shopList == nil

	if needQuery then
		local function callback(rcvData)
			if rcvData.err then
				-- Nothing
			else
				shopList = rcvData.items

				if _callback then
					_callback(shopList)
				end
			end
		end

		Connection.request("home_craft_shop_list", callback)
	else
		_callback(shopList)
	end
end

function InfoHomeCraft.getShopItems()
	local arr = {}
	local multiLabel = false
	local infoMap = {}

	for i, v in ipairs(shopList) do
		local csv = CsvParser.getCsvData("home_craft_shop", v.shop_id, nil, true)

		if csv and v.soldout < csv.times then
			infoMap[v.shop_id] = v
		end
	end

	local csvList = CsvParser.getCsvList("home_craft_shop")

	for i, csv in ipairs(csvList) do
		if csv.type == 1 and (empty(csv.building_id) or InfoBuilding.getBuildingFin(csv.building_id)) and (empty(csv.unlock_item) or InfoItem.getNum(csv.unlock_item) > 0) then
			if csv.times > 0 then
				if infoMap[csv.id] then
					table.insert(arr, infoMap[csv.id])
				end
			else
				table.insert(arr, {
					shop_id = csv.id
				})
			end
		end
	end

	table.sort(arr, function (a, b)
		return a.shop_id < b.shop_id
	end)

	return arr, multiLabel
end

function InfoHomeCraft.buy(shop_id, num, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			InfoHomeCraft.sync(rcvData)

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("home_craft_shop_buy", {
		shop_id = shop_id,
		num = num
	}, callback)
end

function InfoHomeCraft.getShopCSV()
	return "home_craft_shop"
end

function InfoHomeCraft.getShopName()
	return "home_craft_shop"
end

function InfoHomeCraft.getBuildingTag()
	return InfoBuilding.TAG.HOME_CRAFT
end

function InfoHomeCraft.getDelayItemType()
	return InfoDelayItem.TYPE.HOME_CRAFT
end

function InfoHomeCraft.clearVisitShop()
	otherShopList = nil
end

function InfoHomeCraft.getVisitShopItems()
	if not otherShopList then
		return {}
	else
		table.sort(otherShopList, function (a, b)
			return a.shop_id < b.shop_id
		end)

		return otherShopList
	end
end

function InfoHomeCraft.getVisitShopList(_callback)
	local needQuery = otherShopList == nil

	if needQuery then
		local function callback(rcvData)
			if rcvData.err then
				-- Nothing
			else
				otherShopList = rcvData.items

				if _callback then
					_callback(otherShopList)
				end
			end
		end

		Connection.request("home_craft_visit_list", callback)
	else
		_callback(otherShopList)
	end
end

function InfoHomeCraft.buyVisit(shop_id, num, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			InfoHomeCraft.sync(rcvData)

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("home_craft_visit_buy", {
		shop_id = shop_id,
		num = num
	}, callback)
end

function InfoHomeCraft.getDelayItemTypeVisit()
	return InfoDelayItem.TYPE.HOME_CRAFT_OTHER
end

function InfoHomeCraft.getOtherLimitConfig()
	return "visit_craft_limit"
end

return InfoHomeCraft
