local BitUtil = {
	split = function (sector, index)
		local section = math.floor(index / sector) + 1
		local position = index % sector

		if position == 0 then
			section = section - 1
			position = sector
		end

		return section, position
	end
}

function BitUtil.getBitByIndex(num, index)
	local b = BitUtil.lshift(1, index - 1)

	return BitUtil.band(num, b)
end

function BitUtil.setBitByIndex(num, index, v)
	local b = BitUtil.lshift(1, index - 1)

	if v > 0 then
		num = BitUtil.bor(num, b)
	else
		b = BitUtil.bnot(b)
		num = BitUtil.band(num, b)
	end

	return num
end

local function __andBit(left, right)
	return left == 1 and right == 1 and 1 or 0
end

local function __orBit(left, right)
	return (left == 1 or right == 1) and 1 or 0
end

local function __xorBit(left, right)
	return left + right == 1 and 1 or 0
end

local function __base(left, right, op)
	if left < right then
		right = left
		left = right
	end

	local res = 0
	local shift = 1

	while left ~= 0 do
		local ra = left % 2
		local rb = right % 2
		res = shift * op(ra, rb) + res
		shift = shift * 2
		left = math.modf(left / 2)
		right = math.modf(right / 2)
	end

	return res
end

function BitUtil.band(left, right)
	return __base(left, right, __andBit)
end

function BitUtil.bxor(left, right)
	return __base(left, right, __xorBit)
end

function BitUtil.bor(left, right)
	return __base(left, right, __orBit)
end

function BitUtil.bnot(left)
	return left > 0 and -(left + 1) or -left - 1
end

function BitUtil.lshift(left, num)
	return left * 2^num
end

function BitUtil.rshift(left, num)
	return math.floor(left / 2^num)
end

return BitUtil
