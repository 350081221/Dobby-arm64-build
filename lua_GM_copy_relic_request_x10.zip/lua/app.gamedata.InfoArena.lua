local InfoArena = {}
local rawData, oppList, oppSeason, shopList = nil
local shopRefreshIndex = 0
local lookCached = {}
local replayCached = {}
local replayCount = 0

function InfoArena.init()
	Connection.listen("arena_sync", InfoArena.sync)
end

app:addToAppEnterCall(InfoArena.init)

function InfoArena.clearOnScene()
	local nowTime = Time.time()
	local clearArr = {}

	for k, v in pairs(lookCached) do
		if nowTime >= v.time + 60 then
			table.insert(clearArr, k)
		end
	end

	for i, v in ipairs(clearArr) do
		lookCached[v] = nil
	end

	local clearArr = {}

	for k, v in pairs(replayCached) do
		if nowTime >= v.time + 600 then
			table.insert(clearArr, k)
		end
	end

	for i, v in ipairs(clearArr) do
		replayCached[v] = nil
	end
end

function InfoArena.clearOnReconnect()
	rawData = nil
	lookCached = {}
	replayCached = {}
	replayCount = 0
	shopList = nil
end

function InfoArena.replayAdd()
	replayCount = replayCount + 1
end

function InfoArena.replayCount()
	return replayCount
end

function InfoArena.replayClear()
	replayCount = 0
end

function InfoArena.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoArena.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("arena_query", callback)
end

function InfoArena.onQuery(rcvData)
	dump(rcvData, "$$$ arena_query")

	rawData = rcvData
end

function InfoArena.sync(data)
	dump(data, "$$$ InfoArena.sync")

	for k, v in pairs(data) do
		rawData[k] = v
	end

	ManagerInfo.dataChange("arena", data)
end

function InfoArena.serverSeason()
	return rawData.season_id
end

function InfoArena.selfSeason()
	return rawData.season
end

function InfoArena.checkSeason(force, onSuccess, onFailure)
	local needCheckSeason = true

	if not force and rawData.season_id == rawData.season then
		local section, moment = RefreshManager.getSection(RefreshManager.TYPE.ARENA_SEASON, Time.now())

		if moment == rawData.season_time then
			needCheckSeason = false
		end
	end

	local hasWeekReward = false
	local hasUpgrade = false

	if rawData.season > 0 then
		local nowTime = Time.now()

		if RefreshManager.getNextTime(RefreshManager.TYPE.ARENA_WEEK_REWARD, rawData.week_reward_time) < nowTime then
			hasWeekReward = true
		end

		if rawData.max_ranking_level < rawData.ranking_level then
			hasUpgrade = true
		end
	end

	print("$$$ InfoArena.checkSeason", needCheckSeason, hasWeekReward, hasUpgrade, rawData.ranking_level, rawData.max_ranking_level)

	if needCheckSeason or hasWeekReward or hasUpgrade then
		local function callback(rcvData)
			dump(rcvData, "$$$ arena_check_season")

			if rcvData.err then
				if onFailure then
					onFailure(rcvData.err)
				end
			else
				if rcvData.season then
					FRAME_arena_season.open(rcvData)
					InfoUser.refreshHeadFrameArena()
				end

				if rcvData.week_rewards then
					FRAME_arena_season_reward.open(rcvData)
				end

				if onSuccess then
					onSuccess(rcvData)
				end
			end
		end

		Connection.request("arena_check_season", callback)
	end
end

function InfoArena.getOppSeason()
	return oppSeason
end

function InfoArena.getOppList(isRefresh, _callback)
	local needQuery = isRefresh == true

	if not needQuery and (not oppList or #oppList <= 0) then
		needQuery = true
	end

	if not needQuery and rawData.refresh_time < Time.now() then
		needQuery = true
	end

	if needQuery then
		local function callback(rcvData)
			if rcvData.err then
				if onFailure then
					onFailure()
				end
			else
				oppList = rcvData.opp_list
				oppSeason = rcvData.season

				if _callback then
					_callback(oppList)
				end

				if onSuccess then
					onSuccess(oppList)
				end
			end
		end

		Connection.request("arena_opp_list", {
			is_refresh = isRefresh and 1 or 0
		}, callback)
	else
		_callback(oppList)
	end
end

function InfoArena.getReplayList(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ arena_replay_list")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("arena_replay_list", callback)
end

function InfoArena.isActived()
	return InfoBuilding.getBuildingLevel(InfoBuilding.TAG.ARENA) > 0
end

function InfoArena.getSeasonBattle()
	return rawData.season_battle
end

function InfoArena.selfSnapshot()
	if rawData and rawData.self_snapshot then
		return json.decode(rawData.self_snapshot)
	end
end

function InfoArena.selfRank()
	if rawData and rawData.rank then
		return rawData.rank
	end
end

function InfoArena.selfScore()
	return rawData.score
end

function InfoArena.selfPoints()
	return rawData.points
end

function InfoArena.selfVsPoints()
	return rawData.vs_points
end

function InfoArena.getMyArea()
	return rawData.ranking_level
end

function InfoArena.getData()
	return rawData
end

function InfoArena.getNextRefreshTime()
	return RefreshManager.getNextTime(RefreshManager.TYPE.ARENA_TIMES, Time.now())
end

function InfoArena.getBattleCount()
	local battle_count = rawData.battle_count

	if RefreshManager.checkTimePassed(RefreshManager.TYPE.ARENA_TIMES, Time.now(), rawData.battle_time) then
		battle_count = 0
	end

	local arena_battle_num = CsvParser.getCsvData("config", "arena_battle_num").value

	return battle_count, arena_battle_num
end

function InfoArena.getRewardCount()
	local count, max = InfoArena.getBattleCount()
	local targetCSV = InfoArena.getTargetReward()

	if targetCSV then
		max = targetCSV.point
	end

	return count, max
end

function InfoArena.getBattleBuyCount()
	local battle_buy_count = rawData.battle_buy_count

	if RefreshManager.checkTimePassed(RefreshManager.TYPE.ARENA_TIMES, Time.now(), rawData.battle_buy_time) then
		battle_buy_count = 0
	end

	return battle_buy_count
end

function InfoArena.getBattleBuyCost()
	local battle_buy_count = rawData.battle_buy_count

	if RefreshManager.checkTimePassed(RefreshManager.TYPE.ARENA_TIMES, Time.now(), rawData.battle_buy_time) then
		battle_buy_count = 0
	end

	local matArr = RefreshManager.get(RefreshManager.TYPE.ARENA_TIMES, battle_buy_count + 1)

	return matArr
end

function InfoArena.isRewardAlready()
	local reward_already = rawData.reward_already

	if reward_already > 0 and RefreshManager.checkTimePassed(RefreshManager.TYPE.ARENA_TIMES, Time.now(), rawData.reward_time) then
		reward_already = 0
	end

	return reward_already == 1
end

function InfoArena.getReward(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("arena_get_reward", callback)
end

function InfoArena.buyBattle(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("arena_buy_battle", callback)
end

local battleStartData, battleStartTeams = nil

function InfoArena.battleStart(index, type, id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if rcvData.err == "season_err" then
				InfoArena.checkSeason(true)
			end

			if onFailure then
				onFailure(rcvData.err)
			end
		else
			battleStartTeams = rcvData.teams

			InfoArena.startBattle(rcvData.seed, rcvData.attr_level, rcvData.teams)

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	battleStartData = {
		index = index,
		type = type,
		id = id
	}

	Connection.request("arena_battle_start", {
		index = index,
		type = type,
		id = id
	}, callback)
end

function InfoArena.battleConfirm(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "arena_battle_confirm")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("arena_battle_confirm", callback)
end

function InfoArena.battleOverYD(isWin, skillRecord, onSuccess, onFailure)
	InfoArena.battleOver(isWin, skillRecord, onSuccess, onFailure)

	if CONFIG.is_yd then
		YdHelper.check(1, true)
	end
end

function InfoArena.battleOver(isWin, skillRecord, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if rcvData.over_index and oppList and oppList[rcvData.over_index] then
				oppList[rcvData.over_index].over = 1
			end

			local params = InfoArena.taParams
			params.is_win = isWin
			params.running_time = math.ceil(WarMachine.preFrame / 60)
			params.get_score = InfoArena.selfPoints() - rcvData.points

			TaHelper.taTrack("pvp_battle_end", params)

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	local is_win = isWin and 1 or 0
	local recordStr = json.encode(skillRecord)
	local hash = InfoArena.getBattleHash(battleStartData, isWin)

	print("$$$ hash", hash)
	Connection.request("arena_battle_over", {
		is_win = is_win,
		skill_record = recordStr,
		hash = hash
	}, callback)
end

function InfoArena.getBattleHash(battleStartData, isWin)
	local warnCount, sumStack = WarMachine.getCheckSum()
	local attrCheckCount = 0

	for camp = 1, 2 do
		local teamData = ArenaScene.teams[camp]
		local copy = json.decode(teamData.copy)

		for heroPos, heroInfo in pairs(copy.hero) do
			local attrs = CopyAttr.getHeroAttr(heroInfo, copy)
		end
	end

	local key = crypto.md5(battleStartData.id .. "_" .. battleStartData.type)
	local hashObj = {
		a = warnCount,
		b = sumStack,
		c = attrCheckCount
	}

	if isWin then
		hashObj.w = string.sub(key, 11, 15)
	else
		hashObj.w = string.sub(key, 1, 5)
	end

	local hashstr = json.encode(hashObj)
	key = string.sub(key, 6, 10)
	local hash = crypto.encryptXXTEA(hashstr, key)

	return hash
end

function InfoArena.battleOverCheck(onSuccess, onFailure)
	if rawData.battle_index_start == rawData.battle_index_over then
		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			FRAME_arena_over.open(false, rcvData.rewards, rcvData.points)

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("arena_battle_over_check", callback)
end

function InfoArena.replayStart(id, onSuccess, onFailure)
	local function startReplay(rcvData)
		local teams = {
			{
				copy = rcvData.copy_1,
				hero_name = rcvData.hero_name
			},
			{
				copy = rcvData.copy_2
			}
		}

		InfoArena.startReplay(rcvData.seed, rcvData.attr_level, teams, rcvData.skill_record)
	end

	local code = tostring(id)

	if replayCached[code] then
		startReplay(replayCached[code].data)

		if onSuccess then
			onSuccess(replayCached[code].data)
		end

		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			replayCached[code] = {
				data = rcvData,
				time = Time.time()
			}

			startReplay(rcvData)

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("arena_replay", {
		id = id
	}, callback)
end

function InfoArena.look(type, id, onSuccess, onFailure)
	local code = type .. "_" .. id

	if lookCached[code] and Time.time() - lookCached[code].time < 60 then
		if onSuccess then
			onSuccess(lookCached[code].data)
		end

		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			lookCached[code] = {
				data = rcvData,
				time = Time.time()
			}

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("arena_look", {
		type = type,
		id = id
	}, callback)
end

function InfoArena.startBattle(seed, attr_level, teams)
	local enemyTeam = teams[2]
	local params = {
		battle_type = 1,
		target_player_id = enemyTeam.id,
		is_robot = enemyTeam.type == 1,
		self_hero = TaHelper.getHeroInfo(json.decode(teams[1].copy).hero),
		target_hero = TaHelper.getHeroInfo(json.decode(teams[2].copy).hero)
	}

	TaHelper.taTrack("pvp_battle_begin", params)

	params.battle_begin_time = Time.now()
	InfoArena.taParams = params

	ArenaScene.enterMap(ArenaScene.TYPE.ARENA, seed, attr_level, teams)
end

function InfoArena.startReplay(seed, attr_level, teams, skill_record)
	ArenaScene.enterMap(ArenaScene.TYPE.ARENA_REPLAY, seed, attr_level, teams, skill_record)
end

local ranking_map = {}
local requesting_map = {}
local request_time_map = {}
local rankingAmount, selfRank, selfArea = nil

function InfoArena.getMyRank()
	return selfRank
end

function InfoArena.getRankingAmount()
	return rankingAmount
end

function InfoArena.startRanking(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "$$$ arena_ranking_start")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			rankingAmount = rcvData.amount
			selfRank = rcvData.self_rank
			selfArea = rcvData.ranking_level

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("arena_ranking_start", callback)
end

function InfoArena.getRanking(page, onSuccess, onFailure)
	local start_index = (page - 1) * GameConfig.ranking_page + 1
	local arena_ranking_look_num = CsvParser.getCsvData("config", "arena_ranking_look_num").value

	if arena_ranking_look_num < start_index then
		return
	end

	local function callback(rcvData)
		requesting_map[page] = nil
		request_time_map[page] = Time.time()

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			local list = rcvData.list

			for i, v in ipairs(list) do
				local rank = start_index + i - 1
				ranking_map[rank] = {
					rank = rank,
					id = v.id,
					name = v.name,
					points = v.points,
					season = v.season,
					realPoints = v.realPoints,
					snapshot = json.decode(v.snapshot)
				}
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	requesting_map[page] = true

	Connection.request("arena_ranking", {
		start_index = start_index
	}, callback)
end

function InfoArena.getRankingData(rank)
	local page = math.floor((rank - 1) / GameConfig.ranking_page) + 1

	if not ranking_map[rank] or GameConfig.ranking_local_time < Time.time() - request_time_map[page] then
		if not requesting_map[page] then
			InfoArena.getRanking(page)
		end
	else
		return ranking_map[rank]
	end
end

function InfoArena.getDivision(points, customArea)
	if not points then
		local data = InfoArena.getData()
		points = data.points
	end

	local areaCSV = nil

	if customArea then
		if customArea == 0 then
			customArea = 1
		end

		areaCSV = CsvParser.getCsvData("arena_part", customArea)
	end

	local division_list = CsvParser.getCsvList("arena_division")
	local bestV, preV = nil

	for i, v in ipairs(division_list) do
		if areaCSV and areaCSV.max_division < v.id then
			bestV = preV

			break
		end

		preV = v

		if v.points == 0 or points <= v.points then
			bestV = v

			break
		end
	end

	return bestV or division_list[1]
end

local arenaTargetMap = nil

function InfoArena.getTargetReward()
	if not arenaTargetMap then
		arenaTargetMap = {}
		local csv_list = CsvParser.getCsvList("arena_target")
		local preLevel = 1

		for i, csv in ipairs(csv_list) do
			for j = preLevel, csv.level do
				arenaTargetMap[j] = csv
			end

			preLevel = csv.level + 1
		end
	end

	local abyssLevel = InfoDungeon.getAbyssMaxLevel()

	return arenaTargetMap[abyssLevel]
end

function InfoArena.getWeekReward()
	local divisionCSV = InfoArena.getDivision(nil, InfoArena.getMyArea())
	local reward_arr = SheetUtil.getColumnList(divisionCSV, {
		"reward_id_",
		"reward_num_"
	}, {
		"base_id",
		"num"
	})

	return reward_arr
end

function InfoArena.getShopLabels()
	local shopCSVList = CsvParser.getCsvList("arena_shop_label")

	return shopCSVList
end

function InfoArena.getShopList(_callback)
	local needQuery = shopList == nil

	if not needQuery and rawData.shop_refresh_time < Time.now() then
		needQuery = true
	end

	if needQuery then
		local function callback(rcvData)
			if rcvData.err then
				-- Nothing
			else
				shopRefreshIndex = shopRefreshIndex + 1
				shopList = rcvData.items

				if _callback then
					_callback(shopList)
				end
			end
		end

		Connection.request("arena_shop_list", callback)
	else
		_callback(shopList)
	end
end

function InfoArena.getShopItems()
	local abyssLevel = InfoDungeon.getAbyssMaxLevel()
	local arr = {}
	local multiLabel = nil
	local shopCSVList = CsvParser.getCsvList("arena_shop_label")

	if #shopCSVList > 1 then
		local labelMap = {}

		for i, v in ipairs(shopList) do
			local shopCSV = CsvParser.getCsvData("arena_shop", v.shop_id, nil, true)

			if shopCSV and shopCSV.abyss_level_min <= abyssLevel and abyssLevel <= shopCSV.abyss_level_max and (shopCSV.no_supply ~= 1 or v.soldout < shopCSV.times) then
				if not labelMap[shopCSV.label] then
					labelMap[shopCSV.label] = {}
				end

				table.insert(labelMap[shopCSV.label], v)
			end
		end

		for i, v in ipairs(shopCSVList) do
			local itemArr = labelMap[v.id]

			if itemArr then
				table.sort(itemArr, function (a, b)
					return a.shop_id < b.shop_id
				end)

				local obj = {
					label = v,
					items = itemArr
				}

				table.insert(arr, obj)
			end
		end

		multiLabel = true
	else
		local abyssLevel = InfoDungeon.getAbyssMaxLevel()

		for i, v in ipairs(shopList) do
			local shopCSV = CsvParser.getCsvData("arena_shop", v.shop_id, nil, true)

			if shopCSV and shopCSV.abyss_level_min <= abyssLevel and abyssLevel <= shopCSV.abyss_level_max and (shopCSV.no_supply ~= 1 or v.soldout < shopCSV.times) then
				table.insert(arr, v)
			end
		end

		table.sort(arr, function (a, b)
			return a.shop_id < b.shop_id
		end)

		multiLabel = false
	end

	return arr, multiLabel
end

function InfoArena.buy(shop_id, num, onSuccess, onFailure)
	local preIndex = shopRefreshIndex

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if rcvData.item then
				local item = rcvData.item

				if preIndex == shopRefreshIndex then
					for i, v in ipairs(shopList) do
						if v.shop_id == item.shop_id then
							for k1, v1 in pairs(item) do
								v[k1] = v1
							end
						end
					end
				end
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("arena_shop_buy", {
		shop_id = shop_id,
		num = num
	}, callback)
end

function InfoArena.getShopCSV()
	return "arena_shop"
end

function InfoArena.getCostNeed()
	return CsvParser.getCsvData("config", "arena_shop_need").value
end

function InfoArena.getShopName()
	return "arena"
end

function InfoArena.getShopTime()
	return rawData.shop_refresh_time, RefreshManager.getNextTime(RefreshManager.TYPE.ARENA_SHOP, Time.now())
end

function InfoArena.getRefreshType()
	return RefreshManager.TYPE.ARENA_SHOP
end

function InfoArena.countRedot()
	if InfoArena.isRewardAlready() then
		return 0
	end

	local targetCSV = InfoArena.getTargetReward()

	if targetCSV then
		local count, max = InfoArena.getBattleCount()

		if targetCSV.point <= count then
			return 1
		end
	end

	return 0
end

function InfoArena.getArenaMap(seed)
	local map_list = CsvParser.getCsvList("arena_map")
	local random = Random.new(seed)
	local csv = map_list[random:getInt(1, #map_list)]

	return csv.map
end

function InfoArena.isArenaFrame(frameID)
	local csvList = CsvParser.getCsvList("arena_division")

	for k, csv in pairs(csvList) do
		if csv.frame_id == frameID then
			return true
		end
	end
end

function InfoArena.getFormation(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("arena_get_formation", callback)
end

function InfoArena.setFormation(side, custom, hero_arr, pet_arr, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "arena_set_formation")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("arena_set_formation", {
		side = side,
		custom = custom,
		hero = hero_arr,
		pet = pet_arr
	}, callback)
end

return InfoArena
