local NAV_base = import(".NAV_base")
local NAV_market = class("NAV_market", NAV_base)

function NAV_market.open(npc)
	local ui = NAV_market.new(npc)

	return ui
end

function NAV_market:ctor(npc)
	NAV_market.super.ctor(self, npc, "nav_market")
end

function NAV_market:init()
	NAV_market.super.init(self)

	local index = 2
	local funcCSV = InfoFunction.checkFuncOpen(10080)

	if funcCSV then
		self:setButtonVisible(index, true)

		local ui = self.buttons[index].ui

		self:setButtonName(ui, funcCSV.name)
	else
		self:setButtonVisible(index, false)
	end

	local index = 3

	self:setButtonVisible(index, InfoDungeon.inDustPrepare())
end

function NAV_market:onTap(index)
	NAV_market.super.onTap(self, index)

	if index == 1 then
		FRAME_market.open(self.npc, 1)
	elseif index == 2 then
		if InfoGuide.isFin() then
			FRAME_sell.open(self.npc)
		else
			Alert.open(Localization.getSrcText("引导期间该功能无法使用"))
		end
	elseif index == 3 and InfoDungeon.inDustPrepare() then
		FRAME_big_shop.open(InfoDust)
	end
end

return NAV_market
