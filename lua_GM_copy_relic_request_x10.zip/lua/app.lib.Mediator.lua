local Mediator = class("Mediator")

function Mediator.init()
	if not Mediator.instance then
		Mediator.instance = Mediator.new()
	end
end

function Mediator.dispatch(event)
	Mediator.init()
	Mediator.instance:dispatchEvent(event)
end

function Mediator.addListener(eventName, listener, tag)
	Mediator.init()
	Mediator.instance:addEventListener(eventName, listener, tag)
end

function Mediator:ctor(map, center, angle, paramStr, seed)
	event_listener.extendMethods(self)
end

return Mediator
