local FrameLooper = import("..lib.FrameLooper")
local Looper = class("Looper")
Looper.core = FrameLooper.new()

Looper.core:clear()

function Looper.setMode(mode)
	Looper.core:setMode(mode)
end

function Looper.clear()
	Looper.core:clear()
end

function Looper.next()
	Looper.core:next()
end

function Looper.pause(tag)
	Looper.core:pause(tag)
end

function Looper.resume(tag)
	Looper.core:resume(tag)
end

function Looper.setOwner(_owner)
	Looper.core:setOwner(_owner)
end

function Looper.startLoop(obj, func)
	Looper.core:startLoop(obj, func)
end

function Looper.stopLoop(obj, func)
	Looper.core:stopLoop(obj, func)
end

function Looper.clearLoop(obj)
	Looper.core:clearLoop(obj)
end

function Looper.tween(time, subject, target, easing, onComplete, onUpdate)
	return Looper.core:tween(time, subject, target, easing, onComplete, onUpdate)
end

function Looper.stopTween(tweenID)
	Looper.core:stopTween(tweenID)
end

function Looper.setTimeout(func, frameTime, existingNode)
	return Looper.core:setTimeout(func, frameTime, existingNode)
end

function Looper.clearTimeout(idFunc)
	Looper.core:clearTimeout(idFunc)
end

function Looper.getSecond()
	return Looper.core:getSecond()
end

function Looper.getFrame()
	return Looper.core:getFrame()
end

function Looper.getFrameSpeed()
	return Looper.core:getFrameSpeed()
end

function Looper.setTimeRatio(r)
	return Looper.core:setTimeRatio("normal", r)
end

function Looper.printFrameTime(frameCount)
	local printPerFrame = nil
	local frameIndex = 0

	function printPerFrame(obj, frame, passed, sharp)
		print("PrintFrameTime index:", frameIndex, "passed:", passed)

		frameIndex = frameIndex + 1

		if frameCount < frameIndex then
			Looper.core:stopLoop(Looper, printPerFrame)
		end
	end

	Looper:startLoop(printPerFrame)
end

return Looper
