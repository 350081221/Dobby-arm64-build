local NAV_base = import(".NAV_base")
local NAV_farm = class("NAV_farm", NAV_base)

function NAV_farm.open(npc)
	local ui = NAV_farm.new(npc)

	return ui
end

function NAV_farm:ctor(npc)
	NAV_farm.super.ctor(self, npc, "nav_farm")
end

function NAV_farm:init()
	NAV_farm.super.init(self)
	self:setBuildingLvupIndex(2)

	local index = 3

	self:setButtonVisible(index, false)
end

function NAV_farm:onTap(index)
	NAV_farm.super.onTap(self, index)

	if index == 1 then
		FRAME_farm_shop.open(InfoFarm, self.npc)
	end
end

return NAV_farm
