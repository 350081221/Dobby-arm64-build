local NAV_base = import(".NAV_base")
local NAV_union_donate = class("NAV_union_donate", NAV_base)

function NAV_union_donate.open(npc)
	local ui = NAV_union_donate.new(npc)

	return ui
end

function NAV_union_donate:ctor(npc)
	NAV_union_donate.super.ctor(self, npc, "nav_union_donate")
end

function NAV_union_donate:init()
	NAV_union_donate.super.init(self)
end

function NAV_union_donate:onTap(index)
	NAV_union_donate.super.onTap(self, index)

	if index == 1 then
		FRAME_union_donate.open(self.npc)
	end
end

return NAV_union_donate
