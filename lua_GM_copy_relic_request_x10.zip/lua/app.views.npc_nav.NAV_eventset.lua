local NAV_base = import(".NAV_base")
local NAV_eventset = class("NAV_eventset", NAV_base)

function NAV_eventset.open(npc, npcStack)
	local ui = NAV_eventset.new(npc, npcStack)

	return ui
end

function NAV_eventset:ctor(npc, npcStack)
	self.npcStack = npcStack

	NAV_eventset.super.ctor(self, npc, "nav_eventset")
end

function NAV_eventset:getButtonUI(buttonIndex)
	return self.uiName .. "_button_1"
end

function NAV_eventset:init()
	NAV_eventset.super.init(self)

	local hasTouch = false

	for i, v in ipairs(self.buttons) do
		local npc = self.npcStack[i]

		if npc and npc:checkEventsetIndex() then
			local ui = v.ui
			local button = v.button
			local buttonName = npc.eventsetButtonName

			if empty(buttonName) then
				if npc.npcType == Npc.TYPE.SHRINE then
					buttonName = npc.data.name
				else
					buttonName = npc.data.nav_text
				end
			end

			self:setButtonName(ui, buttonName)

			if npc.npcType == Npc.TYPE.CHANCE and (npc.data.type == 13 or npc.data.type == 14) then
				local eventData = npc.eventData
				local eventInfo = InfoDungeon.getEventInfo(eventData.index)

				if not empty(npc.data.read_time) and npc.data.read_time > 0 and eventInfo.fin == 0 then
					self:openTouch()

					self.readTime = npc.data.read_time
				end
			elseif not empty(npc.data.read_time) and npc.data.read_time > 0 then
				hasTouch = true
			end
		else
			self:setButtonVisible(i, false)
		end
	end

	if hasTouch then
		self:openTouch()
	end
end

function NAV_eventset:onTouch(event, index)
	NAV_eventset.super.onTouch(self, event, index)

	local npc = self.npcStack[index]

	if npc.npcType == Npc.TYPE.SHRINE then
		if not empty(npc.data.read_time) and npc.data.read_time > 0 then
			if event == "began" and global.player then
				global.player:faceTo(npc)
			end

			self:onRead(event, npc.data.read_msg, MiscConfig.sfx_shrine_read, MiscConfig.sfx_shrine_active, function ()
				if npc then
					npc:openShrine(index)
				end
			end, npc)
		end
	elseif npc.npcType == Npc.TYPE.CHANCE then
		if npc.data.type == 13 or npc.data.type == 14 then
			local eventData = npc.eventData
			local eventInfo = InfoDungeon.getEventInfo(eventData.index)

			if self.readTime and eventInfo.fin == 0 then
				if event == "began" and global.player then
					global.player:faceTo(npc)
				end

				self:onRead(event, npc.data.read_msg, npc.data.read_sfx, npc.data.read_over_sfx, function ()
					if npc then
						npc:openChance()
					end
				end, npc)
			end
		elseif not empty(npc.data.read_time) and npc.data.read_time > 0 then
			if event == "began" then
				if global.player then
					global.player:faceTo(npc)
				end

				if not npc:checkChance() then
					return
				end
			end

			self:onRead(event, npc.data.read_msg, npc.data.read_sfx, npc.data.read_over_sfx, function ()
				if npc then
					npc:openChance()
				end
			end, npc)
		end
	end
end

function NAV_eventset:onTap(index)
	NAV_eventset.super.onTap(self, index)

	local npc = self.npcStack[index]

	if npc.npcType == Npc.TYPE.SHRINE then
		if empty(npc.data.read_time) then
			if global.player then
				global.player:faceTo(npc)
			end

			npc:openShrine(index)
		end
	elseif npc.npcType == Npc.TYPE.GATHER then
		npc:openGather(index)
	elseif npc.npcType == Npc.TYPE.CHANCE then
		if npc.data.type == 13 or npc.data.type == 14 then
			local eventData = npc.eventData
			local eventInfo = InfoDungeon.getEventInfo(eventData.index)

			if not self.readTime or eventInfo.fin == 1 then
				if global.player then
					global.player:faceTo(npc)
				end

				npc:openChance()
			end
		elseif empty(npc.data.read_time) then
			if global.player then
				global.player:faceTo(npc)
			end

			if not npc:checkChance() then
				return
			end

			npc:openChance()
		end
	end
end

return NAV_eventset
