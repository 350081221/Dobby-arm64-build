local POP_quest_finish = class("POP_quest_finish", UI_base)

function POP_quest_finish.open()
	local ui = POP_quest_finish.new()

	ui:setPositionY(-20)
	transition.moveTo(ui, {
		time = 0.2,
		y = 0,
		easing = "backOut"
	})
	Sound.playSound("level_passed")
	display.getRunningScene():addChild(ui, LayerConfig.pop)
end

function POP_quest_finish:ctor()
	POP_quest_finish.super.ctor(self, "pop_quest_finish")
	self:init()
end

function POP_quest_finish:init()
	self:initUI()
	self:fadeIn()

	local mask = self:getComponentByTag("mask")
	local outTime = 60

	Looper.setTimeout(function ()
		self:fadeOut()
		transition.fadeTo(mask, {
			easing = "sineOut",
			opacity = 0,
			time = 0.2,
			onComplete = function ()
				mask:setVisible(false)
			end
		})
	end, outTime, self)
	transition.fadeTo(mask, {
		easing = "sineIn",
		time = 0.2,
		opacity = 64
	})
end

function POP_quest_finish:initUI()
	local mask = self:getComponentByTag("mask")

	mask:setOpacity(0)

	local label_point = self:getComponentByTag("label_point")

	label_point:setVisible(false)
end

function POP_quest_finish:fadeIn()
	local line1 = self:getComponentByTag("line_1")
	local line2 = self:getComponentByTag("line_2")

	line1:setScaleX(5)
	line2:setScaleX(5)
	line1:setOpacity(0)
	line2:setOpacity(0)
	transition.scaleTo(line1, {
		time = 0.2,
		easing = "sineOut",
		scaleX = 1
	})
	transition.scaleTo(line2, {
		time = 0.2,
		easing = "sineOut",
		scaleX = 1
	})
	transition.fadeTo(line1, {
		time = 0.2,
		easing = "sineOut",
		opacity = 255
	})
	transition.fadeTo(line2, {
		time = 0.2,
		easing = "sineOut",
		opacity = 255
	})
end

function POP_quest_finish:fadeOut()
	local line1 = self:getComponentByTag("line_1")
	local line2 = self:getComponentByTag("line_2")

	transition.scaleTo(line1, {
		time = 0.3,
		easing = "sineOut",
		scaleX = 5
	})
	transition.scaleTo(line2, {
		time = 0.3,
		easing = "sineOut",
		scaleX = 5
	})
	transition.fadeTo(line1, {
		time = 0.3,
		easing = "sineOut",
		opacity = 0
	})
	transition.fadeTo(line2, {
		time = 0.3,
		easing = "sineOut",
		opacity = 0
	})

	local flag_name = self:getComponentByTag("flag_name")

	transition.fadeTo(flag_name, {
		time = 0.3,
		easing = "sineOut",
		opacity = 0
	})
	self:showPoint()
end

function POP_quest_finish:showPoint()
	local label_point = self:getComponentByTag("label_point")

	label_point:setVisible(true)
	label_point:setOpacity(0)
	transition.fadeTo(label_point, {
		easing = "sineOut",
		time = 0.3,
		opacity = 255
	})

	local baseX = label_point:getPositionX()
	local count = 6
	local goLeft, goRight = nil

	function goRight()
		count = count - 1

		if count <= 0 then
			transition.fadeTo(label_point, {
				easing = "sineOut",
				opacity = 0,
				time = 0.3,
				onComplete = function ()
					self:removeSelf()
				end
			})
		else
			transition.moveTo(label_point, {
				time = 0.2,
				easing = "sineOut",
				delay = 0.2,
				x = baseX + 20,
				onComplete = goLeft
			})
		end
	end

	function goLeft()
		transition.moveTo(label_point, {
			time = 0.2,
			easing = "sineOut",
			x = baseX,
			onComplete = goRight
		})
	end

	goRight()
end

return POP_quest_finish
