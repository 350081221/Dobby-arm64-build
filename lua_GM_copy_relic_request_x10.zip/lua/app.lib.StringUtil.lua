local utf8 = import(".utf8")
local StringUtil = {
	checkNameLegal = function (name)
		if name == "" then
			Alert.open(Localization.getSrcText("名字不能为空"))

			return false
		end

		local checkArr = {
			"'",
			"/",
			"\\",
			"^"
		}

		for i, v in ipairs(checkArr) do
			if string.find(name, v, 1, true) then
				Alert.open(Localization.getSrcText("名字不能包含特殊字符"))

				return false
			end
		end

		if string.trim(name) == "" then
			Alert.open(Localization.getSrcText("名字不能全为空格"))

			return false
		end

		return true
	end,
	ymdFormat = function (seconds, simple)
		local lang = Localization.getLang()

		if lang ~= GameConfig.default_lang then
			simple = true
		end

		simple = simple or false
		local fullyear = os.date("%Y", seconds)
		local month = tonumber(os.date("%m", seconds))
		local day = tonumber(os.date("%d", seconds))

		if simple == true then
			return fullyear .. "-" .. month .. "-" .. day
		else
			return fullyear .. "年" .. month .. "月" .. day .. "日"
		end
	end,
	ymdtFormat = function (seconds, simple)
		local lang = Localization.getLang()

		if lang ~= GameConfig.default_lang then
			simple = true
		end

		simple = simple or false
		local fullyear = os.date("%Y", seconds)
		local month = tonumber(os.date("%m", seconds))
		local day = tonumber(os.date("%d", seconds))
		local hour = os.date("%H", seconds)
		local minute = os.date("%M", seconds)

		if simple == true then
			return fullyear .. "." .. month .. "." .. day .. "  " .. hour .. ":" .. minute
		else
			return fullyear .. "年" .. month .. "月" .. day .. "日 " .. hour .. "点" .. minute .. "分"
		end
	end,
	mdtFormat = function (seconds, simple)
		local lang = Localization.getLang()

		if lang ~= GameConfig.default_lang then
			simple = true
		end

		simple = simple or false
		local fullyear = os.date("%Y", seconds)
		local month = tonumber(os.date("%m", seconds))
		local day = tonumber(os.date("%d", seconds))
		local hour = os.date("%H", seconds)
		local minute = os.date("%M", seconds)

		if simple == true then
			return month .. "." .. day .. " " .. hour .. ":" .. minute
		else
			return month .. "月" .. day .. "日 " .. hour .. "点" .. minute .. "分"
		end
	end
}
local simplifyStep = {
	{
		name = "亿",
		num = 100000000
	},
	{
		name = "万",
		num = 10000
	}
}
local simplifyStep_en = {
	{
		name = " B",
		num = 1000000000
	},
	{
		name = " M",
		num = 1000000
	},
	{
		name = " K",
		num = 1000
	}
}

function StringUtil.simplifyNumber(num)
	local lang = Localization.getLang()

	if lang == "cn" or lang == "tw" then
		for i, v in ipairs(simplifyStep) do
			if v.num <= num then
				return tostring(math.floor(num * 10 / v.num) / 10) .. Localization.getSrcText(v.name)
			end
		end
	else
		for i, v in ipairs(simplifyStep_en) do
			if v.num <= num then
				return tostring(math.floor(num * 10 / v.num) / 10) .. v.name
			end
		end
	end

	return num
end

local function chsize(char)
	if not char then
		return 0
	elseif char > 240 then
		return 4
	elseif char > 225 then
		return 3
	elseif char > 192 then
		return 2
	else
		return 1
	end
end

function StringUtil.charArray(str)
	local currentIndex = 1
	local arr = {}

	while currentIndex <= #str do
		local char = string.byte(str, currentIndex)
		local newIndex = currentIndex + chsize(char)
		local s = str:sub(currentIndex, newIndex - 1)

		table.insert(arr, s)

		currentIndex = newIndex
	end

	return arr
end

function StringUtil.utf8len(str)
	return utf8.len(str)
end

function StringUtil.utf8sub(str, startChar, numChars)
	local startIndex = 1

	while startChar > 1 do
		local char = string.byte(str, startIndex)
		startIndex = startIndex + chsize(char)
		startChar = startChar - 1
	end

	local currentIndex = startIndex

	while numChars > 0 and currentIndex <= #str do
		local char = string.byte(str, currentIndex)
		currentIndex = currentIndex + chsize(char)
		numChars = numChars - 1
	end

	return str:sub(startIndex, currentIndex - 1)
end

function StringUtil.getMinMax(value)
	if type(value) == "number" then
		return value, value
	elseif type(value) == "string" then
		local arr = string.split(value, "-")

		if #arr == 1 then
			return tonumber(arr[1]), tonumber(arr[1])
		elseif #arr > 1 then
			return tonumber(arr[1]), tonumber(arr[2])
		end
	end

	return 0, 0
end

function StringUtil.trim(s)
	if type(s) == "string" then
		return s:gsub("^%s*(.-)%s*$", "%1")
	else
		return s
	end
end

function StringUtil.replaceArr(str, ...)
	local arr = {}
	str = tostring(str)
	local params = {
		...
	}
	local found = true

	if device.platform == "windows" then
		while found do
			local tagStart = utf8.find(str, "{")
			found = false

			while tagStart and tagStart ~= -1 do
				local tagEnd = utf8.find(str, "}", tagStart)
				local nextTagStart = utf8.find(str, "{", tagStart + 1)
				local embedded = false

				while nextTagStart and nextTagStart ~= -1 and nextTagStart < tagEnd do
					embedded = true
					tagStart = nextTagStart
					nextTagStart = utf8.find(str, "{", tagStart + 1)
				end

				if tagEnd and tagEnd ~= -1 then
					found = true
					local index = tonumber(utf8.sub(str, tagStart + 1, tagEnd - 1))
					local replaceStr = params[index] or ""

					if replaceStr then
						local str1 = utf8.sub(str, 1, tagStart - 1)

						if str1 ~= "" then
							table.insert(arr, {
								str = str1
							})
						end

						table.insert(arr, {
							str = replaceStr,
							index = index
						})

						str = utf8.sub(str, tagEnd + 1)
						tagStart = utf8.find(str, "{")
					else
						break
					end
				else
					break
				end
			end
		end

		if str ~= "" then
			table.insert(arr, {
				str = str
			})
		end
	else
		while found do
			local tagStart = utils.Tinyutf8:find(str, "{")
			found = false

			while tagStart and tagStart ~= -1 do
				local tagEnd = utils.Tinyutf8:find(str, "}", tagStart)
				local nextTagStart = utils.Tinyutf8:find(str, "{", tagStart + 1)
				local embedded = false

				while nextTagStart and nextTagStart ~= -1 and nextTagStart < tagEnd do
					embedded = true
					tagStart = nextTagStart
					nextTagStart = utils.Tinyutf8:find(str, "{", tagStart + 1)
				end

				if tagEnd and tagEnd ~= -1 then
					found = true
					local index = tonumber(utils.Tinyutf8:sub(str, tagStart + 1, tagEnd - 1))
					local replaceStr = params[index] or ""

					if replaceStr then
						local str1 = utils.Tinyutf8:sub(str, 1, tagStart - 1)

						if str1 ~= "" then
							table.insert(arr, {
								str = str1
							})
						end

						table.insert(arr, {
							str = replaceStr,
							index = index
						})

						str = utils.Tinyutf8:sub(str, tagEnd + 1)
						tagStart = utils.Tinyutf8:find(str, "{")
					else
						break
					end
				else
					break
				end
			end
		end

		if str ~= "" then
			table.insert(arr, {
				str = str
			})
		end
	end

	return arr
end

function StringUtil.replace(str, ...)
	str = tostring(str)
	local params = {
		...
	}

	for i, param in ipairs(params) do
		local count = 1

		repeat
			count = string.find(str, "{" .. i .. "}", count, false)

			if count then
				str = string.sub(str, 1, count - 1) .. param .. string.sub(str, count + 3)
				count = count + string.len(param)
			end
		until count == nil
	end

	return str
end

function StringUtil.replaceTag(str, ...)
	str = tostring(str)
	local params = {
		...
	}
	local transFunc = nil

	if type(params[1]) == "function" then
		transFunc = params[1]
	end

	local found = true

	if device.platform == "windows" then
		while found do
			local tagStart = utf8.find(str, "{")
			found = false

			while tagStart and tagStart ~= -1 do
				local tagEnd = utf8.find(str, "}", tagStart)
				local nextTagStart = utf8.find(str, "{", tagStart + 1)
				local embedded = false

				while nextTagStart and nextTagStart ~= -1 and nextTagStart < tagEnd do
					embedded = true
					tagStart = nextTagStart
					nextTagStart = utf8.find(str, "{", tagStart + 1)
				end

				if tagEnd then
					if tagEnd ~= -1 then
						found = true
						local tag = utf8.sub(str, tagStart + 1, tagEnd - 1)
						local replaceStr = nil

						for i = 1, #params do
							if type(params[i]) == "table" and params[i][tag] then
								replaceStr = params[i][tag]

								if transFunc then
									replaceStr = transFunc(replaceStr, embedded, tag) or tag
								end

								break
							end
						end

						if not replaceStr and transFunc then
							replaceStr = transFunc(tag, embedded, tag) or tag
						end

						if replaceStr then
							str = utf8.sub(str, 1, tagStart - 1) .. replaceStr .. utf8.sub(str, tagEnd + 1)
							tagStart = utf8.find(str, "{", tagEnd - utf8.len(tag) + utf8.len(replaceStr) - 2)
						else
							tagStart = utf8.find(str, "{", tagEnd)

							if not tagStart then
								found = false

								break
							end
						end
					end
				else
					break
				end
			end
		end
	else
		while found do
			local tagStart = utils.Tinyutf8:find(str, "{")
			found = false

			while tagStart and tagStart ~= -1 do
				local tagEnd = utils.Tinyutf8:find(str, "}", tagStart)
				local nextTagStart = utils.Tinyutf8:find(str, "{", tagStart + 1)
				local embedded = false

				while nextTagStart and nextTagStart ~= -1 and nextTagStart < tagEnd do
					embedded = true
					tagStart = nextTagStart
					nextTagStart = utils.Tinyutf8:find(str, "{", tagStart + 1)
				end

				if tagEnd then
					if tagEnd ~= -1 then
						found = true
						local tag = utils.Tinyutf8:sub(str, tagStart + 1, tagEnd - 1)
						local replaceStr = nil

						for i = 1, #params do
							if type(params[i]) == "table" and params[i][tag] then
								replaceStr = params[i][tag]

								if transFunc then
									replaceStr = transFunc(replaceStr, embedded, tag) or tag
								end

								break
							end
						end

						if not replaceStr and transFunc then
							replaceStr = transFunc(tag, embedded, tag) or tag
						end

						if replaceStr then
							str = utils.Tinyutf8:sub(str, 1, tagStart - 1) .. replaceStr .. utils.Tinyutf8:sub(str, tagEnd + 1)
							tagStart = utils.Tinyutf8:find(str, "{", tagEnd - utils.Tinyutf8:len(tag) + utils.Tinyutf8:len(replaceStr) - 2)
						else
							tagStart = utils.Tinyutf8:find(str, "{", tagEnd)

							if not tagStart then
								found = false

								break
							end
						end
					end
				else
					break
				end
			end
		end
	end

	return str
end

function StringUtil.replaceNearestCenterSpace(str)
	local len = #str

	if len == 0 then
		return str
	end

	local center = math.floor((len + 1) / 2)
	local left = nil

	for i = center, 1, -1 do
		if str:sub(i, i) == " " then
			left = i

			break
		end
	end

	local right = nil

	for i = center + 1, len do
		if str:sub(i, i) == " " then
			right = i

			break
		end
	end

	local pos = nil

	if left and right then
		if center - left <= right - center then
			pos = left
		else
			pos = right
		end
	elseif left then
		pos = left
	elseif right then
		pos = right
	else
		return str
	end

	return str:sub(1, pos - 1) .. "\n" .. str:sub(pos + 1)
end

return StringUtil
