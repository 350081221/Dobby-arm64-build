local CombatUnit = import(".CombatUnit")
local Tile = import("..map.Tile")
local HeroCopy = class("HeroCopy", CombatUnit)

function HeroCopy:ctor()
	HeroCopy.super.ctor(self, "hero_copy")

	self.activeSkill = nil
	self.alwaysVisible = true
	self.alwaysActive = true
	self.fixedLight = 255
	self.isBlock = true
end

function HeroCopy.combineData(heroInfo)
	local jobData = CsvParser.getCsvData("hero", heroInfo.base_id, true)
	local avatarList = SheetUtil.getColumnListFull(jobData, {
		"avatar_index_",
		"avatar_id_"
	}, {
		"avatar",
		"value"
	})

	for i, v in ipairs(avatarList) do
		jobData[v.avatar] = v.value
	end

	jobData.gender = "male"

	if string.find(heroInfo.body, "female", 1, true) then
		jobData.gender = "female"
	end

	jobData.model = heroInfo.body
	jobData.avatar_1 = heroInfo.hair
	jobData.name = heroInfo.name

	return jobData
end

function HeroCopy:setInfo(heroInfo, copy)
	self.info = heroInfo
	self.copy = copy
	local heroData = HeroCopy.combineData(heroInfo)

	for i = 1, GameConfig.max_equip do
		local equipInfo = heroInfo.equips[i]

		if equipInfo then
			local equipData = CsvParser.getCsvData("equip", equipInfo.base_id)

			if not empty(equipData.avatar) then
				heroData[equipData.avatar] = equipData.avatar_id
			end
		end
	end

	if heroInfo.show_equips then
		for pos, equipInfo in pairs(heroInfo.show_equips) do
			local equipData = CsvParser.getCsvData("equip", equipInfo.base_id)

			if not empty(equipData.avatar) then
				heroData[equipData.avatar] = equipData.avatar_id
			end
		end
	end

	self:clearCardBuff()

	local cardTotal = #heroInfo.cards

	for i = 1, cardTotal do
		local cardInfo = heroInfo.cards[i]

		if cardInfo then
			local buffArr = InfoCard.getCardBuff(cardInfo)

			for j, buffID in ipairs(buffArr) do
				if not empty(buffID) then
					self:addCardBuff(buffID, cardInfo.ran)
				end
			end
		end
	end

	self:setData(heroData)

	if self:isSwitchSkill() then
		self.skillSwitchIndex = (self.info.auto_skill or 0) + 1
	end

	self:refreshBattleData()
	self:updateSkill()

	if self:isSwitchSkill() then
		self.autoManual = false
	else
		self.autoManual = true
	end

	self:dispatchEvent({
		name = "info_set"
	})
end

function HeroCopy:setAutoSkill(isAuto)
	if not self:isSwitchSkill() then
		print("$$$ setAutoSkill", self.info.name, isAuto)

		self.autoManual = isAuto
	end

	self:dispatchEvent({
		name = "set_auto_skill",
		isAuto = isAuto
	})
end

function HeroCopy:isAutoSkill()
	return self.autoManual
end

function HeroCopy:refreshHp()
	if self.battleData.die and self.isDieout then
		return
	end

	if not self.battleData.hp or not WarMachine.on then
		self.battleData.hp = self.attrs.hp

		if self.battleData.hp > 0 then
			self.battleData.die = nil
		elseif self.battleData.hp <= 0 then
			self.battleData.die = true
		end
	end
end

function HeroCopy:refreshBattleData()
	HeroCopy.super.refreshBattleData(self)

	self.customAttrLevel = CopyAttr.getAttrLevel()
	local attrData, petAttrData, dustSkillMap, skillChangeMap = CopyAttr.getHeroAttr(self.info, self.copy, self.customAttrLevel)

	self:setBattleData(attrData)

	self.dustSkillMap = dustSkillMap
	self.skillChangeMap = skillChangeMap
end

function HeroCopy:setData(data)
	HeroCopy.super.setData(self, data)
	self:updateAvatar()
	self:setAction(self.action)

	if data.class == 1 then
		if self:hasAction("atk_w") then
			self:setMappedAction("attack", "atk_w")
		end

		self.battleIdleAction = "idle_w"
	end

	if data.class == 2 then
		if self:hasAction("atk_a") then
			self:setMappedAction("attack", "atk_a")
		end

		self.battleIdleAction = "idle_a"
	end

	if data.class == 3 then
		if self:hasAction("atk_m") then
			self:setMappedAction("attack", "atk_m")
		end

		self.battleIdleAction = "idle_m"
	end
end

function HeroCopy:updateSkill()
	self:clearSkill()

	if self:isSwitchSkill() then
		self:updateSwitchSkill()
	else
		if not empty(self.data.attack_id) then
			self:addSkill(self.data.attack_id)
		end

		local skillInfo = InfoHero.getActiveSkill(self.info)
		local skillID = skillInfo.id

		if self.skillChangeMap then
			local skillData = CsvParser.getCsvData("skill", skillID)

			if self.skillChangeMap[skillData.base_id] then
				local _skillID = skillData.id + self.skillChangeMap[skillData.base_id]
				local _skillData = CsvParser.getCsvData("skill", _skillID)

				if _skillData then
					print("$$$ updateSkill 技能更换（神器）", _skillData.name, skillData.id, _skillData.id)

					skillID = _skillID
				end
			end
		end

		self.activeSkill = self:addSkill(skillID)
	end
end

function HeroCopy:updateSwitchSkill(index)
	self:clearSkill()

	self.skillSwitchIndex = index or self.skillSwitchIndex or 1

	if not empty(self.data["switch_attack_" .. self.skillSwitchIndex]) then
		self:addSkill(self.data["switch_attack_" .. self.skillSwitchIndex])
	end

	local skillInfo = InfoHero.getSwitchSkill(self.info, self.skillSwitchIndex)
	local skillID = skillInfo.id

	if self.skillChangeMap then
		local skillData = CsvParser.getCsvData("skill", skillID)

		if self.skillChangeMap[skillData.base_id] then
			local _skillID = skillData.id + self.skillChangeMap[skillData.base_id]
			local _skillData = CsvParser.getCsvData("skill", _skillID)

			if _skillData then
				print("$$$ updateSkill 技能更换（神器）", _skillData.name, skillData.id, _skillData.id)

				skillID = _skillID
			end
		end
	end

	self.activeSkill = self:addSkill(skillID)
end

function HeroCopy:switchSkill(index, noCD)
	local preCD = nil

	if self.activeSkill then
		preCD = self.activeSkill.cd
	end

	local skillSwitchIndex = self.skillSwitchIndex or 1
	local buffRemoveArr = {}
	local buffTypeArr = self.buffStackMap[CombatUnit.BUFF_TYPE.NORMAL]

	for i, obj in ipairs(buffTypeArr) do
		local buffData = CsvParser.getCsvData("buff", obj.id)

		if buffData["is_switch_buff_" .. skillSwitchIndex] == 1 then
			table.insert(buffRemoveArr, obj)
		end
	end

	for i, obj in ipairs(buffRemoveArr) do
		self:removeBuff(obj)
	end

	self:updateSwitchSkill(index or 3 - skillSwitchIndex)
	self:initSkills()
	print(11111, self.skillSwitchIndex)
	self:dispatchEvent({
		name = "switch_skill",
		index = self.skillSwitchIndex,
		noCD = noCD
	})
end

function HeroCopy:getActiveSkill()
	return self.activeSkill
end

function HeroCopy:updateAvatar()
	if self.noAvatar then
		return
	end

	for i = 1, #Unit.AVATAR_LAYERS do
		if not empty(self.data["avatar_" .. i]) then
			local avatarStr = self.data["avatar_" .. i]
			avatarStr = StringUtil.replaceTag(avatarStr, self.data)

			self:setAvatar(avatarStr, i)
		else
			self:removeAvatar(i)
		end
	end

	self:dispatchEvent({
		name = "update_avatar"
	})
end

function HeroCopy:quickCast()
	if self.battleData.die then
		return false
	end

	if self:isAutoSkill() then
		return false
	end

	if self:getState("no_skill") then
		return false
	end

	local skillPack = self:getActiveSkill()

	if not skillPack then
		return false
	end

	if skillPack == self.casting.skillPack and (self.casting.step == 1 or self.casting.step == 5) then
		return false
	end

	local fullFrameTime = WarMachine.getFrame()

	if self.battleData.target == nil then
		self:clearTarget()
		self:battleThink()
	end

	if self.battleData.target ~= nil and not self.battleData.die and skillPack.cd <= fullFrameTime and SkillManager.checkPower(skillPack, fullFrameTime) then
		local triggerOK = skillPack.trigger

		if triggerOK then
			local skillData = SkillManager.getSkillData(self, skillPack)
			local isReady, castTarget = SkillManager.findAutoSkillTarget(self, skillData, self.battleData.target)

			if isReady then
				if self.casting.step == 2 or self.casting.step == 5 then
					local castingSkillData = SkillManager.getSkillData(self, self.casting.skillPack)

					if castingSkillData.type == 2 then
						self.readyHandSkill = {
							skillPack = skillPack,
							target = castTarget
						}

						return true
					end
				end

				self:castManualSkill(skillPack, castTarget)

				return true
			end
		end
	end

	return false
end

function HeroCopy:setDieout(isDieout)
	self.isDieout = isDieout
end

function HeroCopy:die()
	if not self.battleData.die then
		if not self.isDieout then
			self:setAction("die")
		end

		self.isBlock = false

		HeroCopy.super.die(self)

		if self.isDieout then
			if self.shadow then
				self.shadow:removeSelf()

				self.shadow = nil
			end

			transition.fadeTo(self, {
				opacity = 0,
				time = 0.5,
				onComplete = function ()
					MapFrameManager.setTimeout(function ()
						self:removeSelf()
					end, MiscConfig.unit_delay_remove)
				end
			})
			self:removeFromMap()
		end

		InfoModao.addMpGetKill(self.info)
	end
end

function HeroCopy:castHandSkill(skillPack, target)
	if self.casting.step == 2 or self.casting.step == 5 then
		local castingSkillData = SkillManager.getSkillData(self, self.casting.skillPack)

		if castingSkillData.type == 2 then
			self.readyHandSkill = {
				skillPack = skillPack,
				target = target
			}

			return
		end
	end

	self:castManualSkill(skillPack, target)

	if target.battleData and not target.battleData.die then
		self.battleData.target = target
	end
end

function HeroCopy:onCastOver()
	HeroCopy.super.onCastOver(self)

	if self.readyHandSkill then
		local fullFrameTime = WarMachine.getFrame()
		local skillPack = self.readyHandSkill.skillPack

		if skillPack.cd <= fullFrameTime and SkillManager.checkPower(skillPack, fullFrameTime) then
			self:castHandSkill(skillPack, self.readyHandSkill.target)

			self.readyHandSkill = nil
		end
	end
end

function HeroCopy:interruptSkill()
	HeroCopy.super.interruptSkill(self)

	self.readyHandSkill = nil
end

function HeroCopy:onBattleStart(warSeed)
	if self:isSwitchSkill() then
		self:updateSwitchSkill()
	end

	HeroCopy.super.onBattleStart(self, warSeed)

	self.battleData.hp = self.attrs.hp

	self:dispatchEvent({
		name = "hp_changed"
	})
	CombatAttr.suitStart(self.info, self)
end

function HeroCopy:onBattleOver()
	HeroCopy.super.onBattleOver(self)

	if self.battleData.hp > 0 then
		self.battleData.die = nil
	elseif self.battleData.hp <= 0 then
		self.battleData.die = true
	end

	if self.battleData.die then
		DungeonState.setCorpse(self.info.id)
	end

	self:setHudVisible(false)
	GuideManager.stopGuideBattle()
end

function HeroCopy:getCode(key)
	return key .. "_" .. self.type .. "_" .. self.info.id
end

function HeroCopy:setBattleData(data)
	HeroCopy.super.setBattleData(self, data)
	self:refreshHp()
end

local ICON_SIZE = 13

function HeroCopy:setHudVisible(visible, color, style)
	local color = nil

	if self.camp == 1 then
		color = cc.c3b(35, 180, 28)
	else
		color = cc.c3b(248, 184, 16)
	end

	HeroCopy.super.setHudVisible(self, visible, color, style)
end

function HeroCopy:refreshSkillHud()
	if self.skillCdHandler then
		self:removeEventListener("skill_cd", self.skillCdHandler)

		self.skillCdHandler = nil
		self.skillHud = nil
	end
end

function HeroCopy:onSkillCD(event)
	local fullFrameTime = WarMachine.getFrame()

	self:setHudSkillCD(event.id, event.cd - fullFrameTime)
end

function HeroCopy:setHudSkillCD(id, cd)
	local skillPack = self:getSkillPack(id)
	local skillIconMap = self.skillHud.skillIconMap
	local iconObj = skillIconMap[id]
	local cdLeft = cd
	local cdMax = skillPack.cdMax
	local fadeStep = 1

	if iconObj then
		local container = iconObj.container
		local clip = iconObj.clip
		local clipLight = iconObj.clipLight
		local icon = iconObj.icon
		local iconLight = iconObj.iconLight
		local bg = iconObj.bg

		bg:setVisible(false)
		Shader.custom(icon, "subtract_0.5")

		local cdLoop = nil

		function cdLoop(obj, frame, passed, sharp)
			if tolua.isnull(self) or tolua.isnull(container) then
				MapFrameManager.stopLoop(self, cdLoop)

				return
			end

			cdLeft = cdLeft - passed

			if fadeStep == 1 and cdLeft <= 12 then
				iconLight:setOpacity(0)
				iconLight:setVisible(true)

				fadeStep = 2
				local tweenObj = {
					opacity = 0
				}

				return MapFrameManager.tween(3, tweenObj, {
					opacity = 255
				}, "outQuad", nil, function ()
					if tolua.isnull(self) or tolua.isnull(container) then
						return
					end

					iconLight:setOpacity(tweenObj.opacity)
				end)
			elseif fadeStep == 2 and cdLeft <= 9 then
				Shader.recover(icon)

				fadeStep = 3
				local tweenObj = {
					opacity = 255
				}

				if cdLeft > 0 then
					return MapFrameManager.tween(cdLeft, tweenObj, {
						opacity = 0
					}, "inQuad", function ()
						if tolua.isnull(self) or tolua.isnull(container) then
							return
						end

						iconLight:setVisible(false)
					end, function ()
						if tolua.isnull(self) or tolua.isnull(container) then
							return
						end

						iconLight:setOpacity(tweenObj.opacity)
					end)
				end
			end

			local percent = 1 - math.max(0, cdLeft / cdMax)

			container:setClippingRegion(cc.rect(0, 0, ICON_SIZE, ICON_SIZE * percent))

			if cdLeft <= 0 then
				bg:setVisible(true)
				iconLight:setVisible(false)
				MapFrameManager.stopLoop(self, cdLoop)
			end
		end

		MapFrameManager.startLoop(self, cdLoop)
	end
end

function HeroCopy:castSkill()
	HeroCopy.super.castSkill(self)

	if not self:isAutoSkill() then
		local skillData = self.casting.skillData

		if skillData.id == self.activeSkill.data.id then
			local target = self.casting.target

			if type(target) == "table" then
				self:dispatchEvent({
					type = "pos",
					name = "manual_cast",
					x = target.x,
					y = target.y
				})
			else
				self:dispatchEvent({
					type = "unit",
					name = "manual_cast",
					index = target.combatIndex
				})
			end
		end
	end
end

return HeroCopy
