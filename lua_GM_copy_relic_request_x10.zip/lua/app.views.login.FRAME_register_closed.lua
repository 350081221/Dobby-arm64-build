local FRAME_register_closed = class("FRAME_register_closed", UI_base)

function FRAME_register_closed.open()
	local ui = FRAME_register_closed.new()

	display.getRunningScene():addChild(ui, LayerConfig.sys)
	PopManager.popinAnim(ui, callback, PopManager.ANIM_TYPE.JUMP)
end

function FRAME_register_closed:ctor()
	FRAME_register_closed.super.ctor(self, "frame_register_closed")
	self:init()
end

function FRAME_register_closed:init()
	self:initUI()
end

function FRAME_register_closed:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local mask = self:getComponentByTag("mask")

	mask:toTouchable()

	local str = Localization.getSrcText("注册功能已关闭，您可以退出登录然后使用其他账号登录游戏")

	self:createUbbOnFlag("flag_msg", str, {
		wrap = true,
		align = Style.left,
		valign = Style.vcenter
	}, true)

	local logoutPB = self:getComponentByTag("bt_logout")

	logoutPB:toTouchable()
	logoutPB:setTapGroup("button_click")

	if CONFIG.is_sdk_logout then
		logoutPB:addTap(function ()
			POP_notice.open(Localization.getSrcText("确认退出当前账号吗？"), function ()
				LuaBridge.call("luaLogout", {}, function (result)
					dump(result, "$$$ luaLogout")

					if result.rs == "success" then
						InfoUser.doReconnect()
					else
						Alert.open(Localization.getSrcText("退出账号失败"))
					end
				end)
			end)
		end)
	else
		logoutPB:addTap(function ()
			POP_notice.open(Localization.getSrcText("确认退出当前账号吗？"), function ()
				Cookie.set("savedUsername", nil)
				Cookie.set("savedPassword", nil)
				Cookie.flush()
				InfoUser.doReconnect()
			end)
		end)
	end
end

return FRAME_register_closed
