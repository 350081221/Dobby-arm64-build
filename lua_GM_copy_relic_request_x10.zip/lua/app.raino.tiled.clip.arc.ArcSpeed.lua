local ArcSpeed = class("ArcSpeed")

function ArcSpeed:ctor(arcEffect, speedArr)
	self.container = arcEffect
	self.chaos = 0
	self.chaosSpeed = 0
	self.speed = speedArr[1]
	self.acc = speedArr[2]
	self.decay = speedArr[3]
	self.chaosValue = speedArr[4]
	self.chaosContinuous = speedArr[5]
end

function ArcSpeed:update()
	if self.acc ~= 0 then
		self.speed = self.speed + self.acc
	end

	if self.decay ~= 0 then
		self.acc = self.acc * (1 - self.decay)

		if math.abs(self.acc) < 0.01 then
			self.acc = 0
		end

		self.speed = self.speed * (1 - self.decay)

		if math.abs(self.speed) < 0.01 then
			self.speed = 0
		end
	end

	if self.chaosValue > 0 then
		if not self.chaosContinuous then
			self.chaos = self.chaosValue * 2 * (self.container.randomSpeed:next() - 0.5)
		else
			self.chaosSpeed = self.chaosSpeed + (self.chaosValue * 2 * (self.container.randomSpeed:next() - 0.5) - self.chaos) * 0.1
			self.chaos = self.chaos + self.chaosSpeed
		end

		self.speed = self.speed + self.chaos
	end
end

function ArcSpeed:clone()
	local arcSpeed = ArcSpeed.new(self.container, {
		self.speed,
		self.acc,
		self.decay,
		self.chaosValue,
		self.chaosContinuous
	})

	return arcSpeed
end

return ArcSpeed
