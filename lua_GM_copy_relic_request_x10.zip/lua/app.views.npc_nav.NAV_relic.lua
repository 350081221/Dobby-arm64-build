local NAV_base = import(".NAV_base")
local NAV_relic = class("NAV_relic", NAV_base)

function NAV_relic.open(npc)
	local ui = NAV_relic.new(npc)

	return ui
end

function NAV_relic:ctor(npc)
	NAV_relic.super.ctor(self, npc, "nav_relic")
end

function NAV_relic:init()
	NAV_relic.super.init(self)

	local index = 1

	if self.npc and self.npc.eventIndex and self.npc.relicIndex then
		local relicID = InfoDungeon.getRelicID(self.npc.eventIndex, self.npc.relicIndex)
		local relicCSV = CsvParser.getCsvData("relic", relicID)

		if relicCSV.type == Npc.RELIC_TYPE.GAP then
			local ui = self.buttons[index].ui

			self:setButtonName(ui, Localization.getSrcText("进入暗影"))
		end
	end
end

function NAV_relic:onTap(index)
	NAV_relic.super.onTap(self, index)
	print("NAV_relic:onTap", index, self.npc)

	if index == 1 then
		local relicID = InfoDungeon.getRelicID(self.npc.eventIndex, self.npc.relicIndex)
		local relicCSV = CsvParser.getCsvData("relic", relicID)

		if relicCSV.type == Npc.RELIC_TYPE.GAP and InfoParams.getValue("dungeon_gap") ~= 1 then
			ErrCode.onErr("gap_not_open")

			return
		end

		self.npc:openRelic()
	end
end

return NAV_relic
