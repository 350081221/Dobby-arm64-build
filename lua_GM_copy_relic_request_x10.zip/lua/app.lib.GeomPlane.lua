local GeomPlane = {}

function GeomPlane.distance(x1OrObj1, y1OrObj2, x2, y2)
	if type(x1OrObj1) == "number" then
		return math.sqrt(math.pow(x2 - x1OrObj1, 2) + math.pow(y2 - y1OrObj2, 2))
	else
		return math.sqrt(math.pow(y1OrObj2.x - x1OrObj1.x, 2) + math.pow(y1OrObj2.y - x1OrObj1.y, 2))
	end
end

function GeomPlane.angle(x1OrObj1, y1OrObj2, x2, y2)
	if type(x1OrObj1) == "number" then
		return math.atan2(y2 - y1OrObj2, x2 - x1OrObj1)
	else
		return math.atan2(y1OrObj2.y - x1OrObj1.y, y1OrObj2.x - x1OrObj1.x)
	end
end

function GeomPlane.intersect(x1, y1, a1, x2, y2, a2)
	local a1tan = math.tan(a1)
	local a2tan = math.tan(a2)
	local x, y = nil

	if a1 ~= a2 then
		if a1 == 0 then
			x = (y1 - y2) / a2tan + x2
			y = y1
		elseif a2 == 0 then
			x = (y2 - y1) / a1tan + x1
			y = y2
		else
			x = (a1tan * x1 - a2tan * x2 - y1 + y2) / (a1tan - a2tan)
			y = (x2 - x1 + y1 / a1tan - y2 / a2tan) / (1 / a1tan - 1 / a2tan)
		end
	end

	return x, y
end

function GeomPlane.isSegmentIntersect(pt1, pt2, pt3, pt4)
	local s = 0
	local t = 0
	local ret = false
	ret, s, t = cc.pIsLineIntersect(pt1, pt2, pt3, pt4, s, t)

	if ret and s >= 0 and s <= 1 and t >= 0 and t <= 1 then
		return true
	end

	return false
end

function GeomPlane.getIntersectPoint(pA, pB, pC, pD)
	return cc.pGetIntersectPoint(pA, pB, pC, pD)
end

return GeomPlane
