local List = import("...ui.List")
local LIST_select_lang = class("LIST_select_lang", List)

function LIST_select_lang:ctor(rect, cols)
	LIST_select_lang.super.ctor(self, rect)
	self:setCellName("cell_select_lang")

	self.isBounc = false

	self:setCols(2)
	self:setSpace(5, 5)
	self:setCellSize(cc.size(self.touchRect.width, 100))
end

function LIST_select_lang:onCellInit(ui, data, index)
	local _selected = ui:getComponentByTag("selected")
	local _unselected = ui:getComponentByTag("unselected")

	_selected:addLabel(Localization.getLangName(data.id))
	_unselected:addLabel(Localization.getLangName(data.id))
	self:onCellSelected(ui, data, self.selectedIndex == index)
end

function LIST_select_lang:onCellSelected(ui, data, selected)
	local _selected = ui:getComponentByTag("selected")
	local _unselected = ui:getComponentByTag("unselected")

	_selected:setVisible(selected)
	_unselected:setVisible(not selected)
end

return LIST_select_lang
