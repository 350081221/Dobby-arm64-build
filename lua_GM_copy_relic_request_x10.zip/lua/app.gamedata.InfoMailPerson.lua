local InfoMailPerson = {}
local rawData = {}

function InfoMailPerson.init()
	Connection.listen("mail_person_sync", InfoMailPerson.sync)
end

app:addToAppEnterCall(InfoMailPerson.init)

function InfoMailPerson.query(onSuccess, onFailure)
	rawData = {}
	local nextIndex, queryNext = nil

	function queryNext()
		local function callback(rcvData)
			if rcvData.err then
				if onFailure then
					onFailure()
				end
			else
				for i, data in ipairs(rcvData.list) do
					rawData[data.id] = data
				end

				if rcvData.next_index then
					nextIndex = rcvData.next_index

					queryNext()
				elseif onSuccess then
					onSuccess()
				end
			end
		end

		Connection.request("mail_person_query", {
			start_index = nextIndex
		}, callback)
	end

	queryNext()
end

function InfoMailPerson.sync(data)
	dump(data, "$$$ InfoMailPerson.sync")

	local changedIdStack = {}

	for i, syncData in ipairs(data.list) do
		local id = syncData.id

		if not rawData[id] then
			rawData[id] = syncData
		else
			for k, v in pairs(syncData) do
				rawData[id][k] = v
			end
		end

		changedIdStack[id] = rawData[id]
	end

	ManagerInfo.dataChange("mail_person", changedIdStack)
end

function InfoMailPerson.getRawData()
	return rawData
end

function InfoMailPerson.markRead(id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("mail_person_mark_read", {
		id = id
	}, callback)
end

function InfoMailPerson.getAward(id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("mail_person_get_award", {
		id_arr = {
			id
		}
	}, callback)
end

function InfoMailPerson.getAwardAll(onSuccess, onFailure)
	local nowTime = Time.now()
	local id_arr = {}

	for k, v in pairs(rawData) do
		if v.stime <= nowTime and nowTime <= v.etime and InfoMail.hasAward(v) and v.is_award_get == 0 then
			table.insert(id_arr, v.id)
		end
	end

	if #id_arr == 0 then
		onSuccess({})

		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("mail_person_get_award", {
		id_arr = id_arr
	}, callback)
end

function InfoMailPerson.getTitle(data)
	local mail_person_csv = CsvParser.getCsvData("mail_person", data.temp)
	local titleStr = mail_person_csv.title
	local temp_values = {}

	if data.temp_values ~= "" then
		temp_values = json.decode(data.temp_values) or {}
	end

	titleStr = StringUtil.replace(titleStr, unpack(temp_values))

	return titleStr
end

function InfoMailPerson.getContent(data)
	local mail_person_csv = CsvParser.getCsvData("mail_person", data.temp)
	local contentStr = mail_person_csv.content
	local temp_values = {}

	if data.temp_values ~= "" then
		temp_values = json.decode(data.temp_values) or {}
	end

	contentStr = StringUtil.replace(contentStr, unpack(temp_values))

	return contentStr
end

function InfoMailPerson.countRedot()
	local nowTime = Time.now()
	local redotCount = 0

	for k, v in pairs(rawData) do
		if v.stime <= nowTime and nowTime <= v.etime then
			local priority = InfoMail.getPriority(v)

			if priority > 0 then
				redotCount = redotCount + 1
			end
		end
	end

	return redotCount
end

return InfoMailPerson
