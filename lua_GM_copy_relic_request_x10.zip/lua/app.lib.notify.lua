local notify = {}
local event_listener_instance = event_listener.new("multi")

function notify.safeRegister(view, event_name, handler)
	local handler_id = notify.register(event_name, handler)

	view:addEventListener("cleanup", function ()
		notify.unregister(event_name, handler_id)
	end)

	return handler_id
end

function notify.register(event_name, handler)
	return event_listener_instance:register(event_name, handler)
end

function notify.dispatch(event_name, ...)
	event_listener_instance:dispatch(event_name, ...)
end

function notify.unregister(event_name, handler_id)
	if handler_id then
		event_listener_instance:unregister(event_name, handler_id)
	end
end

function notify.safeFunc(view, func)
	local viewInfo = {
		func = func
	}

	local function onAckMsg(...)
		if viewInfo.func ~= nil then
			local vFunc = viewInfo.func
			viewInfo.func = nil

			return vFunc(...)
		end
	end

	view:addEventListener("cleanup", function ()
		viewInfo.func = nil
	end)

	return onAckMsg
end

return notify
