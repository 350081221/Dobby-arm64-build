local InfoItemShop = {}
local TYPE = {
	SHOP = 1
}
InfoItemShop.TYPE = TYPE
local rawData = {}

function InfoItemShop.init()
	Connection.listen("item_shop_sync", InfoItemShop.sync)
end

app:addToAppEnterCall(InfoItemShop.init)

function InfoItemShop.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoItemShop.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("item_shop_query", callback)
end

function InfoItemShop.onQuery(rcvData)
	rawData = {}

	for i, data in ipairs(rcvData.list) do
		rawData[data.type_id] = data
	end
end

function InfoItemShop.sync(data, syncData)
	local syncData = data.data
	local type_id = syncData.type_id

	if not rawData[type_id] then
		rawData[type_id] = syncData
	else
		for k, v in pairs(syncData) do
			rawData[type_id][k] = v
		end
	end

	ManagerInfo.dataChange("item_shop")
end

function InfoItemShop.getRefreshTime(type, id)
	local type_id = type .. "_" .. id

	if rawData[type_id] then
		return rawData[type_id].refresh_time
	end
end

function InfoItemShop.checkRefreshTime(type, id)
	local overTime = InfoItemShop.getRefreshTime(type, id)

	if overTime then
		local now = Time.time()

		if now < overTime then
			return false
		end
	end

	return true
end

return InfoItemShop
