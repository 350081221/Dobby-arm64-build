local InfoFunction = {}
local TAGS = {
	10010,
	10020,
	10030,
	10040,
	10050,
	10060,
	10070,
	10080,
	10500
}
local rawData = {}

function InfoFunction.init()
	Connection.listen("function_sync", InfoFunction.sync)
end

app:addToAppEnterCall(InfoFunction.init)

function InfoFunction.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoFunction.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("function_query", callback)
end

function InfoFunction.onQuery(rcvData)
	rawData = {}

	for i, v in ipairs(rcvData.list) do
		rawData[v.tag] = v
	end
end

function InfoFunction.sync(data)
	dump(data, "$$$ InfoFunction.sync")

	local changedIdStack = {}

	for i, syncData in ipairs(data.list) do
		local tag = syncData.tag

		if not rawData[tag] then
			rawData[tag] = syncData
		else
			for k, v in pairs(syncData) do
				rawData[tag][k] = v
			end
		end

		changedIdStack[tag] = rawData[tag]
	end

	ManagerInfo.dataChange("function", changedIdStack)
end

function InfoFunction.setGuided(tags, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	local tag_arr = {}

	for i, tag in ipairs(tags) do
		local obj = {
			tag = tag
		}

		table.insert(tag_arr, obj)
	end

	Connection.request("function_guide", {
		tag_arr = tag_arr
	}, callback)
end

function InfoFunction.getGuideList()
	local arr = {}
	local nowTime = Time.now()

	for i, tag in ipairs(TAGS) do
		if rawData[tag].guided == 0 then
			local funcCSV = InfoFunction.checkFuncOpen(tag)

			if funcCSV and not empty(funcCSV.open_drama) then
				table.insert(arr, funcCSV)
			end
		end
	end

	return arr
end

function InfoFunction.checkFuncOpen(id)
	local funcCSV = CsvParser.getCsvData("function_open", id)

	if not funcCSV then
		return false
	end

	if not empty(funcCSV.need_building_id) and not InfoBuilding.getBuildingFin(funcCSV.need_building_id) then
		return false
	end

	if not empty(funcCSV.permit_item) and InfoItem.getNum(funcCSV.permit_item) <= 0 then
		return false
	end

	if not empty(funcCSV.need_abyss_layer) and InfoDungeon.getAbyssMaxLayer() < funcCSV.need_abyss_layer then
		return false
	end

	if not empty(funcCSV.params_code) then
		local opening = InfoParams.getValue(funcCSV.params_code)

		print("$$$ funcCSV.params_code", funcCSV.params_code, opening)

		if opening ~= 1 then
			return false
		end
	end

	return funcCSV
end

return InfoFunction
