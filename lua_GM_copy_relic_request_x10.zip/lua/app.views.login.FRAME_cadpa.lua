local FRAME_cadpa = class("FRAME_cadpa", UI_base)

function FRAME_cadpa.open()
	local ui = FRAME_cadpa.new()

	display.getRunningScene():addChild(ui, LayerConfig.aside)
end

function FRAME_cadpa:ctor()
	FRAME_cadpa.super.ctor(self, "frame_cadpa")
	self:init()
end

function FRAME_cadpa:init()
	self:initUI()
end

function FRAME_cadpa:initUI()
	local mask = self:getComponentByTag("mask")

	mask:toTouchable()
	mask:addTap(function ()
		self:removeSelf()
	end)

	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local msg = [[
1.本游戏是一款角色扮演类游戏，适用于年满16周岁及以上的用户，建议未成年人在家长监护下使用游戏产品
2.本游戏基于架空的故事背景和奇幻题材的世界观设定，剧情简单且积极向上，没有基于真实历史或现实事件改编的内容。游戏玩法基于数值判断和策略搭配，鼓励玩家通过探索收集和策略搭配来达成目标，克服难关。游戏中有基于聊天和表情的陌生人社交系统
3.本游戏中有用户实名认证系统，认证为未成年人的用户将接受以下管理：
游戏中部分玩法和道具需要付费，未满8周岁的用户不能付费；8周岁以上未满16周岁的未成年用户，单次充值金额不得超过50元人民币，每月充值金额累计不得超过200元人民币；16周岁以上的未成年用户，单次充值不得超过100元人民币，每月充值金额累计不得超过400元人民币。
未成年用户仅可在周五、周六、周日和法定节假日每日的20时至21时进行游戏，其他时间均不得使用。
4.本游戏以数值成长，收集，策略闯关为主题，在装备收集和技能搭配的过程中有助于激发玩家的探索钻研能力和发散性思维，闯关过程中的技能操作和策略选择有助于锻炼玩家的大脑反应速度和手眼协调能力，游戏体验过程中能够带给玩家积极愉悦的情绪体验和探索与成长的成就感，增强玩家自信心。]]

	self:createLabelOnFlag("flag_text", msg, {
		wrap = true
	})
end

return FRAME_cadpa
