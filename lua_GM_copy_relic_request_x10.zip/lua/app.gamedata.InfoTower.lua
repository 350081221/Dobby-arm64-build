local InfoTower = {}
local rawData = {}

function InfoTower.init()
	Connection.listen("tower_sync", InfoTower.sync)
end

app:addToAppEnterCall(InfoTower.init)

function InfoTower.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoTower.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("tower_query", callback)
end

function InfoTower.onQuery(rcvData)
	rawData = {}

	for i, data in ipairs(rcvData.list) do
		rawData[data.type] = data
	end
end

function InfoTower.sync(data)
	for i, syncData in ipairs(data.list) do
		local type = syncData.type

		if not rawData[type] then
			rawData[type] = syncData
		else
			for k, v in pairs(syncData) do
				rawData[type][k] = v
			end
		end
	end

	ManagerInfo.dataChange("tower")
end

function InfoTower.enterUI(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "tower_enter_ui")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("tower_enter_ui", callback)
end

function InfoTower.leaveUI(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("tower_leave_ui", callback)
end

function InfoTower.getRewardTimes(type)
	local rewardCount = 0
	local rewardTime = 0

	if rawData[type] then
		rewardCount = rawData[type].reward_count
		rewardTime = rawData[type].reward_time
	end

	local csv = CsvParser.getCsvData("tower_type", type)

	if RefreshManager.checkTimePassed(csv.open_time, Time.now(), rewardTime) then
		rewardCount = 0
	end

	return math.min(csv.reward_times, rewardCount), csv.reward_times
end

function InfoTower.getTotalTimes()
	local csvList = CsvParser.getCsvList("tower_type", "id", {
		chapter = InfoChapter.getID()
	})
	local times = 0
	local timesMax = 0

	for i, csv in ipairs(csvList) do
		local isOpening = InfoTower.isTypeOpening(csv.id)

		if isOpening then
			local rewardCount, rewardMax = InfoTower.getRewardTimes(csv.id)
			times = times + rewardMax - rewardCount
			timesMax = timesMax + rewardMax
		end
	end

	return times, timesMax
end

function InfoTower.getTypeList()
	local csvList = CsvParser.getCsvList("tower_type", "id", {
		chapter = InfoChapter.getID()
	})
	local sortArr = {}

	for i, csv in ipairs(csvList) do
		table.insert(sortArr, {
			csv = csv,
			opening = InfoTower.isTypeOpening(csv.id) and 1 or 0
		})
	end

	table.sort(sortArr, function (a, b)
		if a.opening == b.opening then
			return a.csv.id < b.csv.id
		else
			return b.opening < a.opening
		end
	end)

	local arr = {}

	for i, v in ipairs(sortArr) do
		table.insert(arr, v.csv)
	end

	return arr
end

function InfoTower.getTowerList(type)
	local csvList = CsvParser.getCsvList("tower", "id", {
		type = type
	})
	local arr = {}

	for i, csv in ipairs(csvList) do
		if csv.is_peak_stage == 1 then
			if InfoParams.getValue("peak") == 1 then
				table.insert(arr, csv)
			end
		else
			table.insert(arr, csv)
		end
	end

	return arr
end

function InfoTower.create(room_id, onSuccess, onFailure)
	InfoTower.enter(room_id, nil, 1, onSuccess, onFailure)
end

function InfoTower.join(room_id, inst_id, onSuccess, onFailure)
	InfoTower.enter(room_id, inst_id, nil, onSuccess, onFailure)
end

function InfoTower.match(room_id, onSuccess, onFailure)
	InfoTower.enter(room_id, nil, , onSuccess, onFailure)
end

function InfoTower.enter(room_id, inst_id, is_private, onSuccess, onFailure)
	OnlineRoom.clear()

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			OnlineRoom.setRoomID(rcvData.room_id)

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("tower_enter_room", {
		room_id = room_id,
		inst_id = inst_id,
		is_private = is_private
	}, callback)
end

function InfoTower.isTypeOpening(type)
	local csv = CsvParser.getCsvData("tower_type", type)

	if empty(csv.open_time) then
		return true
	else
		local season_step = RefreshManager.getSection(csv.open_time, Time.now())

		return season_step % 2 == 1
	end
end

function InfoTower.isTowerOpening(id)
	local csv = CsvParser.getCsvData("tower", id)

	if empty(csv.unlock_level) then
		return true
	else
		return csv.unlock_level <= InfoDungeon.getAbyssMaxLevel()
	end
end

return InfoTower
