local CombatUnit = import(".CombatUnit")
local Monster = class("Monster", CombatUnit)
Monster.wakingCount = 0
Monster.groupMap = {}
Monster.noCheckBattle = false

function Monster.clear()
	Monster.wakingCount = 0
	Monster.groupMap = {}
end

function Monster.addToGroup(unit)
	local groupID = unit.groupID

	if Monster.groupMap[groupID] == nil then
		Monster.groupMap[groupID] = {}
	end

	table.insert(Monster.groupMap[groupID], unit)
end

function Monster.removeFromGroup(unit)
	local groupID = unit.groupID

	if Monster.groupMap[groupID] ~= nil then
		for i = 1, #Monster.groupMap[groupID] do
			if unit == Monster.groupMap[groupID][i] then
				table.remove(Monster.groupMap[groupID], i)

				break
			end
		end

		if #Monster.groupMap[groupID] == 0 then
			Monster.groupMap[groupID] = nil
		end
	end
end

function Monster.clearGroup()
	Monster.groupMap = {}
end

function Monster.getGroup(groupID)
	return Monster.groupMap[groupID]
end

function Monster.getAllMonster()
	local monsters = {}

	for groupID, group in pairs(Monster.groupMap) do
		for i = 1, #group do
			table.insert(monsters, Monster.groupMap[groupID][i])
		end
	end

	return monsters
end

function Monster.getMonsterByBaseID(baseID, index)
	local monsters = Monster.getAllMonster()
	local indexCount = 1

	for i, unit in ipairs(monsters) do
		if tostring(unit.data.id) == tostring(baseID) then
			if not index or index == indexCount then
				return unit
			else
				indexCount = indexCount + 1
			end
		end
	end
end

function Monster:ctor(groupID)
	Monster.super.ctor(self, "monster")

	groupID = groupID or "non-grouped"

	if groupID then
		self.groupID = groupID

		Monster.addToGroup(self)
	end

	self.isUseHate = false
	self.negative = false
end

function Monster:setInfo(monsterInfo)
	if InfoNaraka.inNarakaBoss() then
		monsterInfo.level = monsterInfo.level + InfoNaraka.getModeExLevel()
	end

	self.info = monsterInfo

	self:setBaseID(self.info.base_id)
end

function Monster:setBaseID(base_id)
	local monsterData = CsvParser.getCsvData("monster", base_id)

	self:setData(monsterData)
	self:refreshBattleData()

	self.benefit = {}
	local level = self.info.level

	if not empty(monsterData.ex_level) then
		level = level + monsterData.ex_level
	end

	level = math.max(1, math.min(level, CsvParser.getMaxID("monster_base_num")))
	self.benefit.exp = CsvParser.getCsvData("monster_base_num", level).exp

	self:dispatchEvent({
		name = "info_set"
	})

	if not empty(monsterData.free_action) and not empty(monsterData.free_action_cd) then
		self:setFreeActionData(monsterData.free_action, monsterData.free_action_cd)
	end
end

function Monster:refreshBattleData()
	Monster.super.refreshBattleData(self)
	self:setBattleData(CombatAttr.getMonsterAttr(self.info))
end

function Monster:setData(data)
	Monster.super.setData(self, data)
	self:updateAvatar()

	self.affixArr = {}
	local affixExistMap = {}

	if not empty(data.affix) then
		local affixID = SheetUtil.getString(data.affix, self.random)
		local affixData = CsvParser.getCsvData("monster_affix", affixID, nil, true)

		table.insert(self.affixArr, affixData)

		self.bornAffix = affixID
		affixExistMap[affixID] = true
	end

	local affix_add_num = 0
	local mutateCSV = InfoDungeon.getMutateMonster()

	if mutateCSV then
		local affix_add = mutateCSV["affix_add_" .. self.data.class]

		if not empty(affix_add) then
			affix_add_num = affix_add_num + SheetUtil.getNumber(affix_add, self.random)
		end
	end

	if InfoNaraka.inNarakaBoss() then
		affix_add_num = affix_add_num + InfoNaraka.getModeAffixAdd()
	end

	for i = 1, affix_add_num do
		local affixID = SheetUtil.getString(data.mutate_affix, self.random, affixExistMap)

		if not empty(affixID) then
			local affixData = CsvParser.getCsvData("monster_affix", affixID, nil, true)

			table.insert(self.affixArr, affixData)

			affixExistMap[affixID] = true
		end
	end

	self.warn = data.warn

	if not empty(data.attack_id) then
		self:addSkill(data.attack_id)
	end

	local level = self.info.level

	if not empty(data.ex_level) then
		level = level + data.ex_level
	end

	level = math.max(1, math.min(level, CsvParser.getMaxID("monster_base_num")))

	self:clearCardBuff()

	local index = 1

	while not empty(data["skill_" .. index]) do
		local skill_level = data["skill_level_" .. index]
		local levelOK = false

		if empty(skill_level) then
			levelOK = true
		else
			local arr = string.split(skill_level, ",")

			if #arr == 1 then
				if tonumber(arr[1]) <= level then
					levelOK = true
				end
			elseif tonumber(arr[1]) <= level and level <= tonumber(arr[2]) then
				levelOK = true
			end
		end

		if levelOK then
			local skillID = data["skill_" .. index]
			local args = nil

			if not empty(data["skill_hp_" .. index]) then
				args = args or {}
				local arr = string.split(data["skill_hp_" .. index], ",")

				if #arr == 1 then
					args.hp = {
						min = -100,
						max = tonumber(arr[1])
					}
				else
					args.hp = {
						min = math.min(tonumber(arr[1]), tonumber(arr[2])),
						max = math.max(tonumber(arr[1]), tonumber(arr[2]))
					}
				end
			end

			self:addSkill(skillID, nil, args)
		end

		index = index + 1
	end

	if not empty(data.ex_skills) then
		local skills = string.split(data.ex_skills, ",")

		for i, skillID in ipairs(skills) do
			if not empty(skillID) then
				self:addSkill(skillID, false)
			end
		end
	end

	if not empty(data.skill_born) then
		self:addSkill(data.skill_born, false)
	end

	if data.hero_class == 1 then
		if self:hasAction("atk_w") then
			self:setMappedAction("attack", "atk_w")
		end

		self.battleIdleAction = "idle_w"
	end

	if data.hero_class == 2 then
		if self:hasAction("atk_a") then
			self:setMappedAction("attack", "atk_a")
		end

		self.battleIdleAction = "idle_a"
	end

	if data.hero_class == 3 then
		if self:hasAction("atk_m") then
			self:setMappedAction("attack", "atk_m")
		end

		self.battleIdleAction = "idle_m"
	end
end

function Monster:getBattleName()
	if not self.affixArr or #self.affixArr == 0 then
		return self.data.name
	else
		local str = "["

		for i, affixData in ipairs(self.affixArr) do
			if i > 1 then
				str = str .. "."
			end

			str = str .. affixData.name
		end

		str = str .. "]" .. self.data.name

		return str
	end
end

function Monster:displayVisible()
	self:setVisible(true)

	if self.shadow then
		self.shadow:setVisible(true)
	end
end

function Monster:wake()
	if self.waking ~= true then
		self.waking = true

		self:waitForPatrol(true)

		Monster.wakingCount = Monster.wakingCount + 1

		if not self.battleData.die then
			self:dispatchEvent({
				name = "wake"
			})
		end
	end
end

function Monster:sleep()
	if self.waking then
		self.waking = false

		self:stopPatrolWaiting()

		Monster.wakingCount = Monster.wakingCount - 1

		if not self.battleData.die then
			self:dispatchEvent({
				name = "sleep"
			})
		end
	end
end

function Monster:checkBattle(fixedTarget, isFromNav)
	local function printReason(reason)
	end

	if not TeamManager.ready then
		printReason(1)

		return
	end

	if self.battleData.die then
		printReason(2)

		return
	end

	if self.negative then
		printReason(3)
		Log.debug("checkBattle negative")

		return
	end

	if Monster.noCheckBattle then
		printReason(4)

		return
	end

	if self.map.isBattle then
		printReason(5)

		return
	end

	if global.ignore then
		printReason(6)

		return
	end

	if WarMachine.locked then
		printReason(7)

		return
	end

	if self.isTD then
		printReason(8)

		return
	end

	if not isFromNav and InfoDungeon.getSneakPoint() > 0 then
		printReason(9)

		return
	end

	if not self.eventPack then
		return
	end

	if not fixedTarget and self.patrolData and self.patrolData.target then
		fixedTarget = self.patrolData.target
	end

	if fixedTarget then
		local los = MapUtils.getLos(self.map, self.tile, fixedTarget.tile)
		local lineWalkable = true

		for i = 1, #los do
			local tile = los[i]

			if tile:getWalk() > 0 or tile:getBorderFull() then
				lineWalkable = false

				break
			end
		end

		if lineWalkable then
			local finCount, totalCount = InfoDungeon.getEventTimes("monster")

			if finCount == 0 then
				local eventData = self.eventPack.eventData
				local centerX = math.floor(eventData.x + (eventData.w - 1) / 2)
				local centerY = math.floor(eventData.y + (eventData.h - 1) / 2)
				local tile = self.map:getTile(centerX, centerY)
				tile = tile or self.tile
				local params = {
					tile = tile,
					eventIndex = eventData.index
				}

				if totalCount == 1 then
					InfoMission.trigger(3, 2, params)
				else
					InfoMission.trigger(2, 2, params)
				end
			end

			if not Monster.noCheckBattle then
				self:startBattle(los)
			end
		end
	end
end

function Monster:startBattle(los)
	if global.player:isGoDirectionLocked() then
		return
	end

	if not self.eventPack then
		return
	end

	local eventData = self.eventPack.eventData
	local eventInfo = ConfParser.parse(eventData.info)

	if empty(eventInfo.rush_type) then
		self:addLastingEffect(MiscConfig.effect_monsterBattle, 30)
	end

	self:stopSection()
	self:stopPatrolWaiting()

	local centerPos = math.ceil(#los / 2)
	local center = los[centerPos]
	local offset = 1
	local offsetDirection = 1

	while center:getWalk() > 0 do
		local pos = centerPos + offset * offsetDirection
		offsetDirection = offsetDirection * -1

		if offsetDirection == 1 then
			offset = offset + 1
		end

		center = los[pos]
	end

	local eventData = self.eventPack.eventData
	local eventInfo = ConfParser.parse(eventData.info)
	local centerDataArr = MapEventManager.findLinkAllOrStack(eventData, "battle-center")

	if #centerDataArr > 0 then
		local bestCenter, bestDistance = nil

		for i, centerData in ipairs(centerDataArr) do
			local distance = math.sqrt(math.pow(center.x - centerData.x, 2) + math.pow(center.y - centerData.y, 2))

			if not bestDistance or distance < bestDistance then
				bestDistance = distance
				bestCenter = centerData
			end
		end

		center = self.map:getTile(bestCenter.x, bestCenter.y)
	end

	if not empty(eventInfo.battle_drama_pre) then
		DramaManager.start(eventInfo.battle_drama_pre)
	end

	self:dispatchEvent({
		name = "battle_start",
		monster = self,
		center = center,
		eventData = eventData,
		pack = self.pack
	})
end

function Monster:onBattleStart(warSeed)
	Monster.super.onBattleStart(self, warSeed)

	self.timingBuffReady = SheetUtil.getColumnList(self.data, {
		"timing_buff_id",
		"timing_buff_start",
		"timing_buff_time",
		"loop_time"
	}, {
		"id",
		"start",
		"time",
		"loop"
	})

	if self.eventPack then
		local eventData = self.eventPack.eventData
		local eventInfo = ConfParser.parse(eventData.info)

		if not empty(eventInfo.rush_type) then
			local borderTiles = WarMachine.getBorderTiles()
			local bestTile, bestDistance = nil

			for i, tile in ipairs(borderTiles) do
				local distance = math.sqrt(math.pow(tile.x - self.tile.x, 2) + math.pow(tile.y - self.tile.y, 2))

				if not bestDistance or distance < bestDistance then
					bestTile = tile
					bestDistance = distance
				end
			end

			local currX, currY = self.map:tileToMap(self.tile)
			local mapX, mapY = self.map:tileToMap(bestTile)

			self:stop()
			self:draw(mapX, mapY, true)

			self.battleOut = true
			local speed = 10
			local distance = math.sqrt(math.pow(currX - mapX, 2) + math.pow(currY - mapY, 2))
			local jumpTime = distance / speed
			local waitTime = self.random:nextInt(10, 50)

			local function onWaitComplete()
				self:addLastingEffect(MiscConfig.effect_monsterBattle, 30)

				local effectGen = self:getEffectGen()

				if effectGen then
					effectGen:fadeTo(jumpTime / 3 * 2, 255)
				end

				self:jump({
					x = currX,
					y = currY
				}, speed, 20, function ()
					self.battleOut = false
				end)
			end

			local effectGen = self:getEffectGen()

			if effectGen then
				effectGen:fadeTo(0, 0)
			end

			MapFrameManager.setTimeout(onWaitComplete, waitTime, self)
			WarMachine.removeBorderTile(bestTile)
		end
	end

	if not empty(self.data.start_out_time) then
		self.startOut = self.warStartFrame + self.data.start_out_time
	else
		self.startOut = nil
	end

	if not empty(self.data.warn_effect) then
		local effectGen = self:getEffectGen()

		if effectGen then
			effectGen:castEffect(self.data.warn_effect, self)
		end
	end

	InfoManualMonster.meet(self.data.id, self.bornAffix)
end

function Monster:setFreeActionData(action, cd)
	self.freeAction = {
		action = action,
		cd = cd,
		count = SheetUtil.getNumber(cd)
	}
end

function Monster:playLoop(frame, passed, sharp)
	Monster.super.playLoop(self, frame, passed, sharp)

	if not WarMachine.on and self.freeAction and self.action == "idle" then
		if self.freeAction.count < 0 then
			self:setAction(self.freeAction.action, 1, function ()
				self:setAction("idle")
			end)

			self.freeAction.count = SheetUtil.getNumber(self.freeAction.cd)
		else
			self.freeAction.count = self.freeAction.count - passed
		end
	end
end

function Monster:setEventPack(pack)
	self.eventPack = pack
end

function Monster:clearBornBuff()
	self:clearCardBuff()
end

function Monster:addBornBuff()
	local random = Random.new(self.seed)
	local index = 1
	local level = self.info.level

	while not empty(self.data["buff_" .. index]) do
		local buff_level = self.data["buff_level_" .. index]
		local levelOK = false

		if empty(buff_level) then
			levelOK = true
		else
			local arr = string.split(buff_level, ",")

			if #arr == 1 then
				if tonumber(arr[1]) <= level then
					levelOK = true
				end
			elseif tonumber(arr[1]) <= level and level <= tonumber(arr[2]) then
				levelOK = true
			end
		end

		if levelOK then
			local buffID = self.data["buff_" .. index]

			self:addCardBuff(buffID, random:getInt(1, 65535))
		end

		index = index + 1
	end
end

function Monster:display(map, x, y, noVisible)
	Monster.super.display(self, map, x, y)

	if noVisible then
		self:setVisible(false)

		if self.shadow then
			self.shadow:setVisible(false)
		end
	end

	local random = Random.new(self.seed)

	for i, affixData in ipairs(self.affixArr) do
		local index = 1

		while not empty(affixData["skill_" .. index]) do
			local skillID = affixData["skill_" .. index]

			self:addSkill(skillID)

			index = index + 1
		end

		local index = 1

		while not empty(affixData["buff_" .. index]) do
			local buffID = affixData["buff_" .. index]

			self:addShrineBuff(buffID, random:getInt(1, 65535))

			index = index + 1
		end

		if not empty(affixData.aura_effect) then
			self:addAura(affixData.aura_effect)
		end
	end

	local mutateCSV = InfoDungeon.getMutateMonster()

	if mutateCSV then
		local mutate_buff = mutateCSV["buff_" .. self.data.class]

		if not empty(mutate_buff) then
			local buffID = SheetUtil.getString(mutate_buff, random)

			self:addShrineBuff(buffID, random:getInt(1, 65535))
		end

		if not empty(mutateCSV.all_buff) then
			local buffID = SheetUtil.getString(mutateCSV.all_buff, random)

			self:addShrineBuff(buffID, random:getInt(1, 65535))
		end
	end

	if InfoNaraka.inNarakaBoss() then
		local narakaBuss = InfoNaraka.getModeBuffs()

		if narakaBuss and #narakaBuss > 0 then
			for i, buffID in ipairs(narakaBuss) do
				self:addShrineBuff(buffID, random:getInt(1, 65535))
			end
		end
	end

	self:addBornBuff()
end

function Monster:die()
	if not self.battleData.die then
		if self.data.die_effect ~= "" then
			local effectGen = self:getEffectGen()

			if effectGen then
				effectGen:castEffect(self.data.die_effect, self)
			end
		end

		self:setAction("idle")
		self:stopPlay()

		if self.shadow then
			self.shadow:removeSelf()

			self.shadow = nil
		end

		Monster.removeFromGroup(self)
		transition.fadeTo(self, {
			time = 0.5,
			opacity = 0,
			onComplete = function ()
				MapFrameManager.setTimeout(function ()
					self:removeSelf()
				end, MiscConfig.unit_delay_remove)
			end
		})
		self:removeFromMap()

		if WarMachine.checkMonsterBattle(self) then
			if self.isTD and self.tdmCSV and type(self.tdmCSV.mp_kill_resume) == "number" then
				InfoModao.addMpKillTD(self.tdmCSV.mp_kill_resume)
			else
				InfoModao.addMpKill(self.info)
			end
		end

		if self.isTD then
			self:tdCheckDie()
		end
	end

	Monster.super.die(self)
end

function Monster:stop(code)
	Monster.super.stop(self, code)

	if self.map and self.map.isBattle then
		return
	end

	self:waitForPatrol()
end

function Monster:removeFromMap()
	if self.tile then
		local listenRange = self.warn

		for i = self.tile.x - listenRange, self.tile.x + listenRange do
			for j = self.tile.y - listenRange, self.tile.y + listenRange do
				self:unlistenTile(i, j)
			end
		end
	end

	Monster.super.removeFromMap(self)
end

function Monster:retile()
	local preTile = self.tile

	Monster.super.retile(self)

	local tile = self.tile

	if tile == preTile then
		return
	end

	local listenRange = self.warn
	local refresh = true

	if preTile ~= nil then
		refresh = false
		local dirtyX = preTile.x - tile.x
		local dirtyY = preTile.y - tile.y
		local minX = preTile.x - listenRange
		local maxX = preTile.x + listenRange + self.size - 1
		local minY = preTile.y - listenRange
		local maxY = preTile.y + listenRange + self.size - 1

		MapUtils.dirtyRect(dirtyX, dirtyY, minX, maxX, minY, maxY, handler(self, self.unlistenTile), refresh)
	end

	local dirtyX, dirtyY = nil

	if not refresh then
		dirtyX = tile.x - preTile.x
		dirtyY = tile.y - preTile.y
	end

	local minX = tile.x - listenRange
	local maxX = tile.x + listenRange + self.size - 1
	local minY = tile.y - listenRange
	local maxY = tile.y + listenRange + self.size - 1

	MapUtils.dirtyRect(dirtyX, dirtyY, minX, maxX, minY, maxY, handler(self, self.listenTile), refresh)

	if self.tile:getVisible() then
		self:wake()

		if self.data.is_negative ~= 1 then
			self:checkBattle()
		end
	else
		self:sleep()
	end

	if self.isTD then
		self:tdCheckRetile()
	end
end

function Monster:listenTile(x, y)
	local tile = self.map:getTile(x, y)

	if tile then
		tile:addUnitChangeListener(self, self.onTileUnitChanged)
	end
end

function Monster:unlistenTile(x, y)
	local tile = self.map:getTile(x, y)

	if tile then
		tile:removeUnitChangeListener(self, self.onTileUnitChanged)
	end
end

function Monster:onTileUnitChanged(unit, addOrRemove)
	if not self.map then
		return
	end

	if self.map.isBattle then
		return
	end

	if self.patrolData and unit.type == "hero" and not unit.battleData.die then
		if addOrRemove then
			self.patrolData.target = unit

			if self.data.is_negative ~= 1 then
				self:checkBattle()
			end
		else
			self.patrolData.target = nil
		end
	end
end

function Monster:setHudVisible(visible)
	local color = nil

	if self.battleData.camp == 1 then
		color = cc.c3b(35, 180, 28)
	else
		color = cc.c3b(248, 184, 16)
	end

	HeroCopy.super.setHudVisible(self, visible, color, style)
end

function Monster:setBattleData(data)
	Monster.super.setBattleData(self, data)

	for i, affixData in ipairs(self.affixArr) do
		local random = Random.new(self.seed)
		local attrList = SheetUtil.getColumnList(affixData, {
			"attr_",
			"mul_value_",
			"add_value_"
		}, {
			"attr",
			"mul",
			"add"
		})

		self:attrAddup(attrList, data, nil, random:getInt(1, 65535))
	end

	if InfoDungeon.isAkasa() then
		local baseData = CsvParser.getCsvData("monster_base_num", self.info.level)

		for i, attr in ipairs(CombatAttr.attrs) do
			local ratio = baseData["akasa_" .. attr .. "_ratio"]

			if not empty(ratio) then
				self.attrs[attr] = math.floor(self.attrs[attr] * ratio)
			end
		end
	end

	if InfoNaraka.inNarakaBoss() then
		local baseData = CsvParser.getCsvData("monster_base_num", self.info.level)

		for i, attr in ipairs(CombatAttr.attrs) do
			local ratio = baseData["naraka_" .. attr .. "_ratio"]

			if not empty(ratio) then
				self.attrs[attr] = math.floor(self.attrs[attr] * ratio)
			end
		end
	end

	if not self.battleData.hp then
		self.battleData.hp = self.attrs.hp
	end

	if self.isTD and self.tdmCSV then
		local tdmCSV = self.tdmCSV

		if type(tdmCSV.speed) == "number" then
			self.speed = self.speed * tdmCSV.speed
		end

		for i, attrKey in ipairs(CombatAttr.attrs) do
			if type(tdmCSV[attrKey .. "_ratio"]) == "number" then
				self.attrs[attrKey] = math.floor(self.attrs[attrKey] * tdmCSV[attrKey .. "_ratio"])
			end
		end

		if not empty(tdmCSV.hit_life) then
			self.attrs.hp = tdmCSV.hit_life
			self.attrs.hit_hp = true
		end

		if tdmCSV.team_heal ~= 1 then
			self.attrs.no_heal = true
		end
	end
end

function Monster:battleThink()
	if global.dummy then
		return
	end

	Monster.super.battleThink(self)
end

function Monster:setTDFixed(tdmCSV)
	self.isTD = true
	self.alwaysVisible = true
	self.alwaysActive = true
	self.noKnock = true
	self.tdmCSV = tdmCSV

	self:makeTDM(tdmCSV)
end

function Monster:setTD(tdData, waveData, targetTile, tdmCSV)
	self.isTD = true
	self.alwaysVisible = true
	self.alwaysActive = true
	self.tdData = tdData
	self.waveData = waveData
	self.tdmCSV = tdmCSV
	self.tdInfo = {
		targetTile = targetTile
	}

	self:makeTDM(tdmCSV)
end

function Monster:makeTDM(tdmCSV)
	if not empty(tdmCSV.buff) then
		self:addCardBuff(tdmCSV.buff, math.random(1, 65535))
	end

	self.affixArr = {}

	if not empty(tdmCSV.affix) then
		local affixData = CsvParser.getCsvData("monster_affix", tdmCSV.affix, nil, true)

		table.insert(self.affixArr, affixData)
	end

	self:refreshBattleData()

	self.battleData.hp = self.attrs.hp
end

function Monster:tdCheckRetile()
	if self.tdData and self.tdData.targetMap[self.tile.tag] then
		self:die()
		WarMachine.tdMonsterReach(self)
	end
end

function Monster:tdCheckDie()
	WarMachine.tdMonsterDie(self)
end

function Monster:battleUpdate(think)
	if #self.timingBuffReady > 0 then
		local warTime = WarMachine.getFrame() - self.warStartFrame

		for i, v in ipairs(self.timingBuffReady) do
			if v.preTime then
				if v.loop <= warTime - v.preTime then
					self:addBuff(v.id, v.time, nil, self.id)

					v.preTime = warTime
				end
			elseif v.start <= warTime then
				self:addBuff(v.id, v.time, nil, self.id)

				v.preTime = warTime
			end
		end
	end

	if self.isTD and self.tdmCSV.type ~= 3 then
		local fullFrameTime = WarMachine.getFrame()

		if self.battleData.die then
			return
		end

		if self.battleOut then
			return
		end

		if self.startOut and fullFrameTime < self.startOut then
			return
		end

		if self.battleData.hp <= 0 then
			self:die()

			return
		end

		self:updateBuff()
		self:checkCDOver()

		if self.battleData.target and self.battleData.target.battleData and self.battleData.target.battleData.die then
			self.battleData.target = nil
		end

		local isLockHate = self:getState("lock_hate")

		if (self.tdmCSV.type == 1 or isLockHate) and self.casting.step == 0 then
			local exceptMap = {}

			if self:isMelee() then
				local heros = WarMachine.getUnitsByCamp(1)

				for i, hero in ipairs(heros) do
					if hero.highStand then
						exceptMap[hero.id] = true
					end
				end
			end

			local checkOK = self:checkAutoSkill(true, exceptMap)

			if checkOK then
				self:stop(12)
				self:castSkill()

				self.battleData.target = self.casting.target
			elseif self.battleData.target and self:isMelee() then
				if self:battleFollow(self.battleData.target) then
					-- Nothing
				elseif not isLockHate then
					self.battleData.target = nil
				end
			end
		end

		self:updateCastSkill()

		if not self.battleData.die then
			self:hpResume()

			if self:isMelee() and self.battleData.target and self.casting.step == 4 and self.moving ~= true and not self:checkTileCenter() and self.tile:isMasterUnit(self) and not self:isJumping() and not self:getState("no_move") then
				self:moveToTileCenter()
			end
		end

		if think and not self.thinkFreezed and not self.thinkFreezedAI and self.tdInfo then
			local justGo = false

			if self:isMelee() then
				if not self.battleData.target and (self.casting.step == 0 or self.casting.step == 4) then
					justGo = true
				end
			elseif self.casting.step == 0 or self.casting.step == 4 then
				justGo = true
			end

			if justGo and not self.moving then
				local blockUnits = {}
				local mapX, mapY = self.map:tileToMap(self.tdInfo.targetTile)
				local goResult = self:go(mapX, mapY, function (tile, unitMap)
					for unitID, unit in pairs(unitMap) do
						if unit.isTDBlock then
							table.insert(blockUnits, unit)

							return false
						end
					end

					return true
				end)

				if not goResult then
					local blockUnit = nil

					if #blockUnits > 0 then
						local preNoUnitBLock = Map.NO_UNIT_BLOCK
						Map.NO_UNIT_BLOCK = true
						local path = self.map:findPath(self.tile, self.tdInfo.targetTile, self.walkLevel, self.size, nil, self)

						if path and #path > 0 then
							for i = 2, #path do
								local tile = path[i]

								for j, unit in ipairs(blockUnits) do
									if tile:findUnit(unit) then
										blockUnit = unit

										break
									end
								end
							end
						end

						Map.NO_UNIT_BLOCK = preNoUnitBLock
					end

					if blockUnit then
						if self.tdmCSV.type == 1 then
							local preNoUnitBLock = Map.NO_UNIT_BLOCK
							Map.NO_UNIT_BLOCK = true
							self.battleData.target = blockUnit

							if self:battleFollow(self.battleData.target) then
								-- Nothing
							elseif not isLockHate then
								self.battleData.target = nil
							end

							Map.NO_UNIT_BLOCK = preNoUnitBLock
						elseif self.tdmCSV.type == 2 then
							local preNoUnitBLock = Map.NO_UNIT_BLOCK
							Map.NO_UNIT_BLOCK = true
							local path, pathFound = self:findMeleeTile(blockUnit)

							if pathFound then
								if path == true then
									local path = self.map:findPath(self.tile, self.tdInfo.targetTile, self.walkLevel, self.size, nil, self)

									if path and #path > 0 then
										local jumpTile = nil

										for i = 2, #path do
											local tile = path[i]

											if not tile:findUnit(blockUnit) then
												jumpTile = tile

												break
											end
										end

										if jumpTile then
											local mapX, mapY = self.map:tileToMap(jumpTile)
											local time = self:getActionTotalFrameTime("walk")
											local distance = math.sqrt(math.pow(mapY - self.y, 2) + math.pow(mapX - self.x, 2))
											local jumpSpeed = distance / time

											self:jump({
												x = mapX,
												y = mapY
											}, (self.speed + jumpSpeed) / 2, 24)
										end
									end
								else
									self:goPath(path, true)
								end
							end

							Map.NO_UNIT_BLOCK = preNoUnitBLock
						end
					end
				end
			end
		end
	else
		Monster.super.battleUpdate(self, think)
	end
end

function Monster:isMelee()
	if self.isMelee == nil then
		self.isMelee = false

		if self.autoSkills and self.autoSkills[1] then
			local attackSkillData = self.autoSkills[1].data

			if attackSkillData.range ~= 0 then
				self.isMelee = true
			end
		end
	end

	return self.isMelee
end

function Monster:onExit()
	Monster.removeFromGroup(self)
	Monster.super.onExit(self)
end

return Monster
