local InfoWild = {}
local rawData = {}

function InfoWild.init()
	Connection.listen("wild_sync", InfoWild.sync)
end

app:addToAppEnterCall(InfoWild.init)

function InfoWild.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoWild.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("wild_query", callback)
end

function InfoWild.onQuery(rcvData)
	rawData = {}

	for i, data in ipairs(rcvData.list) do
		rawData[data.spot_id] = data
	end
end

function InfoWild.sync(data)
	dump(data, "$$$ InfoWild.sync")

	for i, syncData in ipairs(data.list) do
		local spot_id = syncData.spot_id

		if rawData[spot_id] then
			for k, v in pairs(syncData) do
				rawData[spot_id][k] = v
			end
		else
			rawData[spot_id] = syncData
		end
	end

	ManagerInfo.dataChange("wild")
end

function InfoWild.spotBattle(spot_id, star_id, onSuccess, onFailure)
	print("$$$ spotBattle", spot_id, star_id)

	local function callback(rcvData)
		notify.dispatch("exit_map")
		dump(rcvData, "wild_spot_battle")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if rcvData.type == 1 then
				local result = rcvData.dungeon_result

				if CONFIG.is_ta then
					local params = {
						stage_id = result.dungeon_id,
						hero_info = TaHelper.getHeroInfoAll()
					}

					TaHelper.taTrack("world_start", params)
				end

				local title, subTitle = InfoDungeon.getTitle(result.type, result.dungeon_id, result.quest_id, result.abyss_seed)

				Transition.setTitle(title, subTitle)
				Transition.leave(function ()
					if onSuccess then
						onSuccess(rcvData.type, result)
					end
				end)

				return
			end

			if rcvData.type == 2 then
				local result = rcvData.td_result

				dump(result, "$$$ result")
				Transition.setTitle("塔防")
				Transition.leave(function ()
					if onSuccess then
						onSuccess(rcvData.type, result)
					end
				end)
			end
		end
	end

	Connection.request("wild_spot_battle", {
		spot_id = spot_id,
		star_id = star_id
	}, callback)
end

function InfoWild.checkGrowth(onSuccess, onFailure)
	local starList = CsvParser.getCsvList("wild_star")
	local growthMap = {}

	for i, v in ipairs(starList) do
		local spot_id = v.spot
		local star = v.star

		if rawData[spot_id] and star <= rawData[spot_id].star then
			local gList = SheetUtil.getColumnList(v, {
				"growth_id_",
				"growth_num_"
			}, {
				"base_id",
				"num"
			})

			for j, v1 in ipairs(gList) do
				if not growthMap[v1.base_id] then
					growthMap[v1.base_id] = 0
				end

				growthMap[v1.base_id] = growthMap[v1.base_id] + v1.num
			end
		end
	end

	local errCount = 0

	for i, baseID in ipairs(GameConfig.item_growth_list) do
		local num, growth, growth_time = InfoItem.getGrowth(baseID)
		local _growth = growthMap[baseID] or 0

		if _growth ~= growth then
			errCount = errCount + 1
		end
	end

	print("$$$ errCount", errCount)

	local function callback(rcvData)
		notify.dispatch("exit_map")
		dump(rcvData, "wild_check_growth")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("wild_check_growth", callback)
end

function InfoWild.initSpot()
	local spot_star_list_map = CacheData.get("InfoWild_spot_star_list_map")

	if not spot_star_list_map then
		local spot_star_list_map = {}
		local spot_star_data_map = {}
		local chapter_tag_spot_map = {}
		local spotList = CsvParser.getCsvList("wild_spot")

		for i, v in ipairs(spotList) do
			if not chapter_tag_spot_map[v.chapter] then
				chapter_tag_spot_map[v.chapter] = {}
			end

			chapter_tag_spot_map[v.chapter][v.spot] = v.id
		end

		local starList = CsvParser.getCsvList("wild_star")

		for i, v in ipairs(starList) do
			if not spot_star_list_map[v.spot] then
				spot_star_list_map[v.spot] = {}
			end

			if not spot_star_data_map[v.spot] then
				spot_star_data_map[v.spot] = {}
			end

			spot_star_data_map[v.spot][v.star] = v

			table.insert(spot_star_list_map[v.spot], v)
		end

		for spot, v in pairs(spot_star_list_map) do
			table.sort(v, function (a, b)
				return a.star < b.star
			end)
		end

		CacheData.set("InfoWild_spot_star_list_map", spot_star_list_map)
		CacheData.set("InfoWild_spot_star_data_map", spot_star_data_map)
		CacheData.set("InfoWild_chapter_tag_spot_map", chapter_tag_spot_map)
	end
end

function InfoWild.getSpotID(chapter, spotTag)
	InfoWild.initSpot()

	local chapter_tag_spot_map = CacheData.get("InfoWild_chapter_tag_spot_map")

	if chapter_tag_spot_map[chapter] then
		return chapter_tag_spot_map[chapter][spotTag]
	end
end

function InfoWild.getSpotStarList(spotID)
	InfoWild.initSpot()

	local spot_star_list_map = CacheData.get("InfoWild_spot_star_list_map")

	return spot_star_list_map[spotID]
end

function InfoWild.getSpotStarData(spotID, star)
	InfoWild.initSpot()

	local spot_star_data_map = CacheData.get("InfoWild_spot_star_data_map")

	if spot_star_data_map[spotID] then
		return spot_star_data_map[spotID][star]
	end
end

function InfoWild.getCurrentStar(spotID)
	if rawData[spotID] then
		return rawData[spotID].star
	else
		return 0
	end
end

function InfoWild.getMaxStar(spotID)
	local maxStar = 0
	local starList = InfoWild.getSpotStarList(spotID)

	if starList then
		local abyssLevel = InfoDungeon.getAbyssMaxLevel()

		for i, v in ipairs(starList) do
			if v.star <= abyssLevel then
				maxStar = v.star
			else
				break
			end
		end
	end

	return maxStar
end

function InfoWild.getStarDisplay(spotID)
	local currentStar = InfoWild.getCurrentStar(spotID)
	local maxStar = InfoWild.getMaxStar(spotID)
	local opening = currentStar < maxStar
	local displayStar = currentStar + 1

	return opening, displayStar
end

function InfoWild.getSpotGrowth(spotID)
	local starList = InfoWild.getSpotStarList(spotID)
	local isGrowth = false
	local baseID = false
	local num = 0

	if starList then
		for i, v in ipairs(starList) do
			local spot_id = v.spot
			local star = v.star
			local gList = SheetUtil.getColumnList(v, {
				"growth_id_",
				"growth_num_"
			}, {
				"base_id",
				"num"
			})

			if #gList > 0 then
				isGrowth = true
				baseID = gList[1].base_id
			end

			if rawData[spot_id] and star <= rawData[spot_id].star then
				for j, v1 in ipairs(gList) do
					num = num + v1.num
				end
			end
		end
	end

	return isGrowth, baseID, num
end

return InfoWild
