local MapEffect = {}
local map, disabled = nil

function MapEffect.setMap(_map)
	map = _map
end

function MapEffect.setDisabled(_disabled)
	disabled = _disabled
end

function MapEffect.castEffect(effectStr)
	local effectStackArr = string.split(effectStr, ";")

	for i = 1, #effectStackArr do
		local effectArr = string.split(effectStackArr[i], ":")
		local code = effectArr[1]
		local params = string.split(effectArr[2] or "", ",")

		if code == "quake" then
			MapEffect.quake(tonumber(params[1]), tonumber(params[2]), tonumber(params[3]), tonumber(params[4]))
		elseif code == "tileLayerScroll" then
			MapEffect.tileLayerScroll(tonumber(params[1]), tonumber(params[2]), tonumber(params[3]))
		elseif code == "stopTileLayerScroll" then
			MapEffect.stopTileLayerScroll()
		elseif code == "collapseReady" then
			MapEffect.collapseReady(tonumber(params[1]), tonumber(params[2]), tonumber(params[3]), tonumber(params[4]), params[5])
		elseif code == "collapse" then
			MapEffect.collapse(tonumber(params[1]), tonumber(params[2]), tonumber(params[3]), tonumber(params[4]))
		elseif code == "lightning" then
			MapEffect.lightning(tonumber(params[1]), tonumber(params[2]))
		elseif code == "natureLightning" then
			MapEffect.natureLightning(tonumber(params[1]))
		end
	end
end

local lightningTimer = nil

function MapEffect.lightning(power, time)
	if lightningTimer then
		MapFrameManager.stopTween(lightningTimer)

		lightningTimer = nil
	end

	local tweenObj = {
		lightning = power or 255
	}

	global.map:setLightMask(tweenObj.lightning)

	lightningTimer = MapFrameManager.tween(time or 20, tweenObj, {
		lightning = 0
	}, "outQuad", function ()
		if global.map then
			global.map:clearLightMask()
		end

		lightningTimer = nil
	end, function ()
		if global.map then
			global.map:setLightMask(tweenObj.lightning)
		end
	end)
end

function MapEffect.natureLightning(power)
	power = power or 255

	MapEffect.lightning(power)

	local times = math.random(1, 3)
	local delay = 0

	for i = 1, times do
		delay = delay + math.random(5, 10)

		MapFrameManager.setTimeout(function ()
			MapEffect.lightning(power * math.pow((times + 1 - i) / (times + 2), 1.5))
		end, delay, global.map)
	end
end

local snowObj = {}

function MapEffect.snow(strong, angle, height, speed, easing)
	snowObj = {
		count = 0,
		strong = strong or 1
	}

	MapFrameManager.startLoop(MapEffect, MapEffect.snowLoop)
end

function MapEffect.snowStop()
	MapFrameManager.stopLoop(MapEffect, MapEffect.snowLoop)
end

function MapEffect.snowLoop(_, frame, passed, sharp, elapsedTime, isFirst)
	snowObj.count = snowObj.count + snowObj.strong * (1 + (math.random() - 0.5) * 2 * 0.2) * math.min(1, passed)
	local border = 50

	while snowObj.count > 0 do
		local screenX = math.random(-border, global.map.width + border)
		local screenY = global.map.height + 50
		local mapX, mapY = global.map:screenToMap(screenX, screenY, true)
		local drawX, drawY = global.map:mapToDraw(mapX, mapY)
		local effect = Animation.new()

		UI_base.extendEnterFrame(effect)
		effect:load("effect_snow_" .. math.random(1, 2))
		effect:setOpacity(math.random(30, 200))

		local scale = math.random() * 0.2 + 0.8

		effect:setScale(math.pow(scale, 2))

		local speed = math.random() * 1.2 + 1.2
		local angle = math.pi / 2 * (1.2 - math.random() * 0.4)

		global.map.hudHighLayer:addChild(effect, 1000)
		effect:setPosition(drawX, -drawY)
		effect:addEnterFrame("snow_fall", function (dt)
			local toRemove = false

			if global.map then
				local frame = dt * 60
				drawX = drawX + math.cos(angle) * speed * frame
				drawY = drawY + math.sin(angle) * speed * frame

				effect:setPosition(drawX, -drawY)

				local mapX, mapY = global.map:drawToMap(drawX, drawY)
				local screenX, screenY = global.map:mapToScreen(mapX, mapY)
				local overBorder = false

				if screenX < -50 then
					screenX = screenX + global.map.width + border * 2
					overBorder = true
				elseif screenX > global.map.width + 50 then
					screenX = screenX - (global.map.width + border * 2)
					overBorder = true
				end

				if overBorder then
					local mapX, mapY = global.map:screenToMap(screenX, screenY, true)
					drawX, drawY = global.map:mapToDraw(mapX, mapY)
				end

				if screenY < -border then
					toRemove = true
				end
			else
				toRemove = true
			end

			if toRemove then
				effect:removeEnterFrame("snow_fall")
				effect:removeSelf()
			end
		end)

		snowObj.count = snowObj.count - 1
	end
end

local rainObj = {}

function MapEffect.rain(strong, angle, height, speed, easing)
	rainObj = {
		count = 0,
		strong = strong or 5,
		height = height or display.height,
		fallTime = (height or display.height) / 10,
		easing = easing or "linear",
		angle = angle or 0
	}

	MapFrameManager.startLoop(MapEffect, MapEffect.rainLoop)
end

function MapEffect.rainStop()
	MapFrameManager.stopLoop(MapEffect, MapEffect.rainLoop)
end

function MapEffect.rainLoop(_, frame, passed, sharp, elapsedTime, isFirst)
	rainObj.count = rainObj.count + rainObj.strong * (1 + (math.random() - 0.5) * 2 * 0.2) * math.min(1, passed)

	while rainObj.count > 0 do
		local screenX = math.random(-rainObj.height * math.tan(rainObj.angle) - 100, global.map.width + 100)
		local screenY = math.random(0, global.map.height)
		local x, y = global.map:screenToMap(screenX, screenY, true)
		local effect = Effect.new()
		effect.noRetile = true

		effect:load("effect_rain")
		effect:setBlendFunc(gl.SRC_ALPHA, gl.ONE)

		effect.alwaysVisible = true

		effect:display(global.map, x, y)
		effect:setRotate(rainObj.angle + math.pi / 2)

		local effectGen = effect:getEffectGen()

		if effectGen then
			effectGen:fall(rainObj.fallTime, rainObj.height, rainObj.easing, function ()
				effect:setRotate(0)
				effect:destroy()
			end, function ()
				if rainObj.angle ~= 0 then
					effect.effectOffset = cc.p(math.sin(rainObj.angle) * effect.z, 0)
				end
			end)
		end

		rainObj.count = rainObj.count - 1
	end
end

local collapseClipMap = {}

function MapEffect.collapseReady(startTileX, startTileY, endTileX, endTileY, replaceClipName)
	for tileX = startTileX, endTileX do
		for tileY = startTileY, endTileY do
			local tile = map:getTile(tileX, tileY)
			local mapX, mapY = map:tileToMap(tile)

			tile.mapTile:setShockOffset(10000)

			local effect = Effect.new()

			effect:load(replaceClipName)
			effect:setScale(1 / map.config.scale.unit)

			effect.alwaysVisible = true

			effect:display(map, mapX, mapY, map.tileLayer)

			collapseClipMap[tile.tag] = effect
		end
	end
end

function MapEffect.collapse(tileX, tileY, time, z, easing)
	local tile = map:getTile(tileX, tileY)
	local effect = collapseClipMap[tile.tag]

	if effect and effect.getEffectGen then
		local effectGen = effect:getEffectGen()

		if effectGen then
			effectGen:zmove(time, z, easing or "inQuad")
		end
	end
end

local freezeTagMap = nil

function MapEffect.freezeTime(tag, time)
	freezeTagMap = freezeTagMap or {}
	freezeTagMap[tag] = true
	time = time or 2

	if time and time > 0 then
		Looper.setTimeout(function ()
			MapEffect.clearFreezeTime(tag)
		end, time, map)
	end

	MapEffect.updateFreezeTime()
end

local timeFreezeTweenID = nil

function MapEffect.updateFreezeTime()
	if MapEffect.isFreezed() then
		MapFrameManager.pause("MapEffect_freezeTime")
	else
		MapFrameManager.resume("MapEffect_freezeTime")
	end
end

function MapEffect.clearFreezeTime(tag)
	if not freezeTagMap then
		return
	end

	freezeTagMap[tag] = nil

	if table.nums(freezeTagMap) == 0 then
		freezeTagMap = nil
	end

	MapEffect.updateFreezeTime()
end

function MapEffect.isFreezed()
	return freezeTagMap ~= nil
end

local bulletTimeMap = {}

function MapEffect.bulletTime(tag, speed, time)
	if disabled then
		return
	end

	bulletTimeMap[tag] = speed

	if time and time > 0 then
		Looper.setTimeout(function ()
			MapEffect.removeBulletTime(tag)
		end, time, map)
	end

	MapEffect.updateBulletTime("outQuart")
end

local currentTimeRatio = 1
local timeRatioTweenID = nil

function MapEffect.updateBulletTime(easing)
	local minSpeed = 1

	for tag, speed in pairs(bulletTimeMap) do
		minSpeed = math.min(minSpeed, speed)
	end

	if timeRatioTweenID then
		Looper.stopTween(timeRatioTweenID)

		timeRatioTweenID = nil
	end

	local tweenObj = {
		timeRatio = currentTimeRatio
	}

	local function onUpdate()
		currentTimeRatio = tweenObj.timeRatio

		MapFrameManager.setTimeRatio(currentTimeRatio)
	end

	timeRatioTweenID = Looper.tween(5, tweenObj, {
		timeRatio = minSpeed
	}, easing, nil, onUpdate)
end

function MapEffect.removeBulletTime(tag)
	bulletTimeMap[tag] = nil

	MapEffect.updateBulletTime("inQuart")
end

function MapEffect.clearBulletTime()
	bulletTimeMap = {}
end

local tileLayerScrollData = nil

function MapEffect.tileLayerScroll(x, y, loopTime)
	local layerX, layerY = map.tileLayer:getPosition()
	tileLayerScrollData = {
		count = 0,
		maxX = x,
		maxY = y,
		time = loopTime,
		startX = layerX,
		startY = layerY
	}

	MapFrameManager.startLoop(MapEffect, MapEffect.tileLayerScrollLoop)
end

function MapEffect.tileLayerScrollLoop(obj, frame, passed, sharp)
	tileLayerScrollData.count = tileLayerScrollData.count + passed
	local isRefresh = false

	if tileLayerScrollData.time < tileLayerScrollData.count then
		tileLayerScrollData.count = tileLayerScrollData.count - tileLayerScrollData.time
		isRefresh = true
	end

	local percent = tileLayerScrollData.count / tileLayerScrollData.time
	local x = percent * tileLayerScrollData.maxX
	local y = percent * tileLayerScrollData.maxY

	map.tileLayer:setPosition(tileLayerScrollData.startX + x, tileLayerScrollData.startY + y)

	local mapX = (y * 2 - x) / 2
	local mapY = (x + y * 2) / 2

	map:setFovOffset(mapX, mapY * 2, isRefresh)
end

function MapEffect.stopTileLayerScroll()
	MapFrameManager.stopLoop(MapEffect, MapEffect.tileLayerScrollLoop)
	map:setFovOffset(0, 0, true)
end

local quakeData = nil

function MapEffect.quake(range, freq, lasting, decay, angleRan)
	if disabled then
		return
	end

	quakeData = {
		dis = 0,
		speed = range or 8,
		power = freq or 0.8,
		lasting = lasting or 0,
		decay = decay or 0.75,
		angle = -math.pi / 2,
		angleRan = angleRan or math.pi / 3
	}
	quakeData.initSpeed = quakeData.speed

	MapFrameManager.startLoop(MapEffect, MapEffect.quakeLoop)
end

function MapEffect.quakeLoop(obj, frame, passed, sharp)
	passed = math.min(passed, 2)
	local quakeX = 0
	local quakeY = 0

	for i = 1, sharp do
		quakeData.angle = quakeData.angle + (math.random() - 0.5) * quakeData.angleRan
		quakeData.angle = (quakeData.angle - math.pi / 2) / 2
	end

	quakeData.speed = quakeData.speed - quakeData.dis * quakeData.power * passed

	if quakeData.lasting <= 0 then
		quakeData.speed = quakeData.speed * (1 - (1 - quakeData.decay) * passed)
	else
		quakeData.lasting = quakeData.lasting - passed
	end

	if math.abs(quakeData.speed) < passed / 2 and math.abs(quakeData.dis) < passed / 2 then
		MapFrameManager.stopLoop(MapEffect, MapEffect.quakeLoop)
	else
		quakeData.dis = quakeData.dis + quakeData.speed * passed

		if quakeData.initSpeed < quakeData.dis then
			quakeData.dis = quakeData.initSpeed
		elseif quakeData.dis < -quakeData.initSpeed then
			quakeData.dis = -quakeData.initSpeed
		end

		quakeX = quakeData.dis * math.cos(quakeData.angle)
		quakeY = quakeData.dis * math.sin(quakeData.angle)
	end

	map:setPositionOffset("MapEffect.quake", quakeX, quakeY)
end

local shockDataMap = {}

function MapEffect.shock(tag, pt, range, thickness, speed, height)
	if disabled then
		return
	end

	thickness = thickness or 96
	local shockData = {
		speed = speed or 10,
		height = height or 10,
		range = range or 150,
		pt = pt,
		thickness = thickness,
		radius = thickness + map.ptPerTile / 2
	}
	shockDataMap[tag] = shockData

	MapFrameManager.startLoop(MapEffect, MapEffect.shockLoop)
end

function MapEffect.shockLoop(obj, frame, passed, sharp)
	local shockTileMap = {}

	for tag, shockData in pairs(shockDataMap) do
		shockData.radius = shockData.radius + shockData.speed * passed

		if shockData.pt and shockData.pt.x then
			local tile = map:mapToTile(shockData.pt)
			local size = math.ceil(shockData.radius / map.ptPerTile) + 1

			for m = tile.x - size, tile.x + size do
				for n = tile.y - size, tile.y + size do
					local tempTile = map:getTile(m, n)

					if tempTile ~= nil then
						local tempX, tempY = map:tileToMap(tempTile)
						local range = math.sqrt(math.pow(tempY - shockData.pt.y, 2) + math.pow(tempX - shockData.pt.x, 2))

						if range <= shockData.range then
							local height = 0

							if range >= shockData.radius - shockData.thickness and range <= shockData.radius then
								local arcPercent = (range - (shockData.radius - shockData.thickness)) / shockData.thickness
								height = math.sin(arcPercent * math.pi) * shockData.height
							end

							if shockTileMap[tempTile.tag] then
								shockTileMap[tempTile.tag] = math.max(height, shockTileMap[tempTile.tag])
							else
								shockTileMap[tempTile.tag] = height
							end
						end
					end
				end
			end

			if shockData.radius > shockData.range + shockData.thickness then
				for m = tile.x - size, tile.x + size do
					for n = tile.y - size, tile.y + size do
						local tempTile = map:getTile(m, n)

						if tempTile ~= nil then
							if shockTileMap[tempTile.tag] then
								shockTileMap[tempTile.tag] = math.max(0, shockTileMap[tempTile.tag])
							else
								shockTileMap[tempTile.tag] = 0
							end
						end
					end
				end

				shockDataMap[tag] = nil
			end
		else
			shockDataMap[tag] = nil
		end
	end

	for tag, height in pairs(shockTileMap) do
		local tile = map:getTileByTag(tag)

		tile:setShockOffset(height)
	end

	if table.nums(shockDataMap) == 0 then
		MapFrameManager.stopLoop(MapEffect, MapEffect.shockLoop)
	end
end

local groundClipMap = {}
local groundArcMap = {}

function MapEffect.getGroundClip(tag)
	return groundClipMap[tag]
end

function MapEffect.createGroundClip(tag, x, y, effectName, afterBornCallback)
	local effect = Effect.new()

	effect:load(effectName, afterBornCallback)
	effect:display(map, x, y)

	groundClipMap[tag] = effect

	return effect
end

function MapEffect.removeGroundClip(tag)
	local effect = groundClipMap[tag]

	if effect then
		effect:destroy()

		groundClipMap[tag] = nil
	end
end

function MapEffect.createGroundArc(tag, x, y, arcStr, interval, seed, total, angle)
	local interval = tonumber(interval)
	local obj = {
		count = 0,
		num = 0,
		total = total
	}
	local random = nil

	if seed then
		random = Random.new(seed)
	end

	local function arcLoop()
		if obj.count == 0 then
			local arcSeed = nil

			if random then
				arcSeed = random:getInt(1, 65535)
			end

			local arcEffect = ArcEffect.new(map, {
				x = x,
				y = y
			}, angle or 0, arcStr, arcSeed)

			arcEffect:start()

			obj.count = obj.count + 1
			obj.num = obj.num + 1

			if obj.total and obj.total ~= "" and obj.total ~= 0 and obj.total <= obj.num then
				MapEffect.removeGroundArc(tag)
			end
		else
			obj.count = obj.count + 1

			if obj.count == interval then
				obj.count = 0
			end
		end
	end

	obj.func = arcLoop

	MapFrameManager.startLoop(obj, arcLoop)

	groundArcMap[tag] = obj
end

function MapEffect.removeGroundArc(tag)
	local obj = groundArcMap[tag]

	if obj then
		MapFrameManager.stopLoop(obj, obj.func)
	end
end

local tileParticleMap = {}
local particleInstanceMap = {}

function MapEffect.addParticle(tile, param)
	tileParticleMap[tile:getTag()] = {
		param = param
	}

	tile:setHasEvent(true)

	if tile:getVisible() then
		MapEffect.tileCheckParticle(tile)
	end
end

function MapEffect.tileCheckParticle(tile)
	local particleData = tileParticleMap[tile:getTag()]

	if particleData then
		local param = particleData.param
		local particle = cc.ParticleSystemQuad:create(getFinalRes("res/particle/" .. param.name .. "/particle_texture.plist"))
		local mapX, mapY = map:tileToMap(tile)
		local drawX, drawY = map:mapToDraw(mapX, mapY)
		local offsetX = param.offsetX or 0
		local offsetY = param.offsetY or 0

		particle:setPosition(drawX + offsetX, -drawY + offsetY)
		particle:setLocalZOrder(drawY)
		particle:setPositionType(cc.POSITION_TYPE_GROUPED)
		map.baseLayer:addChild(particle)

		particleInstanceMap[tile:getTag()] = particle

		return true
	end
end

local tileSpineMap = {}
local spineInstanceMap = {}

function MapEffect.addSpine(tile, param)
	tileSpineMap[tile:getTag()] = {
		param = param
	}

	tile:setHasEvent(true)

	if tile:getVisible() then
		MapEffect.tileCheckSpine(tile)
	end
end

function MapEffect.tileCheckSpine(tile)
	local spineData = tileSpineMap[tile:getTag()]

	if spineData then
		local param = spineData.param
		local mapX, mapY = map:tileToMap(tile)
		local clip = ClipOnMap.new()

		clip:loadSpine(param.name)

		if param.no_fill and param.no_fill == 1 then
			clip.noFillTile = true
		end

		local x, y = map:tileToMap(tile)
		local xoffset = tonumber(param.xoffset) or 0
		local yoffset = tonumber(param.yoffset) or 0

		if param.alwaysVisible and param.alwaysVisible ~= "" then
			clip.alwaysVisible = param.alwaysVisible == 1
		end

		clip:display(map, x + xoffset, y + yoffset)
		MapEventManager.initClipWithInfo(clip, param)

		spineInstanceMap[tile:getTag()] = clip
	end
end

function MapEffect.onDrawTile(tile)
	MapEffect.tileCheckParticle(tile)
	MapEffect.tileCheckSpine(tile)
end

function MapEffect.onEraseTile(tile)
	if particleInstanceMap[tile:getTag()] then
		local particle = particleInstanceMap[tile:getTag()]

		particle:removeSelf()

		particleInstanceMap[tile:getTag()] = nil
	end

	if spineInstanceMap[tile:getTag()] then
		local spineSP = spineInstanceMap[tile:getTag()]

		spineSP:removeSelf()

		spineInstanceMap[tile:getTag()] = nil
	end
end

function MapEffect.clear()
	for tag, particle in pairs(particleInstanceMap) do
		if not tolua.isnull(particle) then
			particle:removeSelf()
		end
	end

	particleInstanceMap = {}

	if groundArcMap then
		for tag, obj in pairs(groundArcMap) do
			MapFrameManager.stopLoop(obj, obj.func)
		end
	end

	groundClipMap = {}
	groundArcMap = {}
	tileSpineMap = {}
	tileParticleMap = {}
	spineInstanceMap = {}
	freezeTagMap = nil

	MapEffect.clearBulletTime()
	MapEffect.rainStop()

	map = nil
end

return MapEffect
