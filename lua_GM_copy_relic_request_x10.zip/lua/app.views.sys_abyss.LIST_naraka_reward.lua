local List = import("...ui.List")
local LIST_naraka_reward = class("LIST_naraka_reward", List)

function LIST_naraka_reward:ctor(rect)
	LIST_naraka_reward.super.ctor(self, rect)
	self:setCellName("cell_gacha_preview")
	self:setSpace(0, 0)
	self:setCellSize(cc.size(self.touchRect.width, 80))
end

function LIST_naraka_reward:setStarNum(num, max)
	self.starNum = num
	self.starMax = max
end

local slotSize = 80
local slotLine = 2

function LIST_naraka_reward:getCellName(index)
	local data = self:getData(index)

	if data.title == 1 then
		return "cell_naraka_reward_title_1"
	elseif data.title == 2 then
		return "cell_naraka_reward_title_2"
	else
		return "cell_naraka_reward"
	end
end

function LIST_naraka_reward:getCellSize(index)
	local data = self:getData(index)

	if data.title then
		return cc.size(self.touchRect.width, 50)
	else
		local items = data.items
		local line = math.ceil(#items / slotLine)

		return cc.size(self.touchRect.width, line * slotSize + 2)
	end
end

function LIST_naraka_reward:onCellInit(ui, data)
	if ui.slots then
		for i, v in ipairs(ui.slots) do
			v:removeSelf()
		end

		ui.slots = nil
	end

	if data.title then
		if data.title == 2 then
			local style = {
				color = InfoHero.getHpColor(1 - self.starNum / self.starMax)
			}

			ui:replaceLabelGroupOnFlag("flag_text", {
				self.starNum
			}, {
				style
			})
		end
	else
		local items = data.items
		local line = math.ceil(#items / slotLine)
		local slotFlag = ui:getFlagByTag("flag_slot")
		ui.slots = {}

		for i, v in ipairs(items) do
			local x = slotFlag.x + (i - 1) % slotLine * slotSize
			local y = slotFlag.y + (line - 1) * slotSize - math.floor((i - 1) / slotLine) * slotSize
			local slot = DropSlot.new(slotFlag, "slot_01")

			slot:setPosition(x, y)
			ui:addChild(slot, 100)
			table.insert(ui.slots, slot)
			slot:setDrop(DropManager.TYPE.ITEM, v)
		end
	end
end

return LIST_naraka_reward
