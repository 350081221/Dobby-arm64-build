local Clip = import(".Clip")
local ClipOnMap = class("ClipOnMap", Clip)
ClipOnMap.uniqueID = 1
ClipOnMap.typeMap = {}
ClipOnMap.instanceMap = {}

function ClipOnMap.getUnit(id)
	return ClipOnMap.instanceMap[id]
end

function ClipOnMap.getUnitList(...)
	local list = {}
	local types = {
		...
	}

	for i, type in ipairs(types) do
		if ClipOnMap.typeMap[type] then
			for id, unit in pairs(ClipOnMap.typeMap[type]) do
				table.insert(list, unit)
			end
		end
	end

	return list
end

function ClipOnMap.iterateUnits(func)
	for id, unit in pairs(ClipOnMap.instanceMap) do
		func(unit)
	end
end

function ClipOnMap:ctor(type)
	ClipOnMap.super.ctor(self)

	self.type = type or "ClipOnMap"
	self.id = ClipOnMap.uniqueID
	ClipOnMap.uniqueID = ClipOnMap.uniqueID + 1
	ClipOnMap.instanceMap[self.id] = self

	if not ClipOnMap.typeMap[self.type] then
		ClipOnMap.typeMap[self.type] = {}
	end

	ClipOnMap.typeMap[self.type][self.id] = self

	self:addEventListener("cleanup", function (event)
		if ClipOnMap.typeMap[self.type] then
			ClipOnMap.typeMap[self.type][self.id] = nil
		end

		ClipOnMap.instanceMap[self.id] = nil
	end)

	self.scaleBeforeMap = 1
	self.size = 1
	self.alwaysVisible = false
	self.fixedLight = -1
	self.opacity = 255
	self.darkness = 255
	self.fixedDarkness = false
	self.visible = true
	self.noRetile = nil
	self.tag = self.type .. "_" .. self.id
end

function ClipOnMap:setHidden(tag, hidden)
	local preHidden = self:isHidden()

	if hidden then
		self.hiddenStack = self.hiddenStack or {}
		self.hiddenStack[tag] = true
	elseif self.hiddenStack then
		self.hiddenStack[tag] = nil
	end

	if self.hiddenStack and table.nums(self.hiddenStack) == 0 then
		self.hiddenStack = nil
	end

	if self:isHidden() then
		if not preHidden then
			self:refreshVisible(true)
		end
	elseif not hidden then
		self:refreshVisible(true)
	end
end

function ClipOnMap:checkHidden(tag)
	if self.hiddenStack then
		return self.hiddenStack[tag]
	end
end

function ClipOnMap:clearHidden()
	self.hiddenStack = nil

	self:refreshVisible(true)
end

function ClipOnMap:isHidden()
	return self.hiddenStack ~= nil
end

function ClipOnMap:display(map, x, y, customLayer)
	self.x = x or self.x or 0
	self.y = y or self.y or 0
	self.map = map

	if customLayer then
		customLayer:addChild(self)
	elseif self.layer == 0 then
		self.map.lowLayer:addChild(self)
	elseif self.layer == 2 then
		self.map.highLayer:addChild(self)
	else
		self.map.baseLayer:addChild(self)
	end

	if self.clipType == Clip.CLIP_TYPE.SPINE then
		self:refreshSpine()
	end

	self:setScale(self.scale)
	self:refreshShadow()
	self:draw()
	self:retile()
end

function ClipOnMap:draw(x, y, setXY)
	x = x or self.x
	y = y or self.y

	if setXY then
		self.x = x
		self.y = y

		self:retile()
	end

	x = x + (self.size - 1) * self.map.ptPerTile / 2
	y = y + (self.size - 1) * self.map.ptPerTile / 2
	local drawX, drawY = self.map:mapToDraw(x, y)
	self.drawX = drawX
	self.drawY = drawY

	self:setPosition(drawX, -drawY)
	self:setLocalZOrder(drawY + (self.zorderOffset or 0))

	if self.skeletons then
		for i, skeleton in ipairs(self.skeletons) do
			skeleton:setPosition(drawX, -drawY)
			skeleton:setLocalZOrder(drawY + (skeleton.zOffset or 0))
		end
	end

	self:setBmpY()

	if self.shadow ~= nil then
		self.shadow:setPosition(drawX, -drawY)
		self:refreshShadowZ()

		if self.highStand then
			self.shadow:setLocalZOrder(-1)
			self.shadow:setPosition(0, self.zOffset * global.map.config.scale.unit)
		else
			self.shadow:setPosition(drawX, -drawY)
			self:refreshShadowZ()
		end
	end

	self:refreshLight()

	return drawX, drawY
end

function ClipOnMap:setBmpX()
	local offsetX = ClipOnMap.super.setBmpX(self)

	if offsetX and self.drawX and self.skeletons then
		for i, skeleton in ipairs(self.skeletons) do
			skeleton:setPositionX(self.drawX + offsetX * self.scale)
		end
	end
end

function ClipOnMap:setBmpY()
	ClipOnMap.super.setBmpY(self)

	if self.drawY and self.skeletons then
		for i, skeleton in ipairs(self.skeletons) do
			local params = self.skeletonParams[i]
			local offsetY = nil

			if params.layer == 0 then
				offsetY = params.yoff
			else
				offsetY = params.yoff - self.z
			end

			skeleton:setPositionY(-self.drawY - offsetY * self.scale)
		end
	end
end

function ClipOnMap:setScale(scale)
	local _scale = scale
	self.scaleBeforeMap = scale

	if self.map then
		self.mapScale = scale * self.map.config.scale.unit
		scale = scale * self.map.config.scale.unit
	end

	self:refreshSpineScale()
	ClipOnMap.super.setScale(self, scale)
end

function ClipOnMap:refreshShadow(isNew)
	if isNew and self.shadow then
		self.shadow:removeSelf()

		self.shadow = nil
	end

	if self.isShadow and self.map then
		if self.shadow == nil then
			self.shadow = display.newSprite("#map_assets_shadow")

			if self.highStand then
				self:addChild(self.shadow)
			else
				self.map.shadowLayer:addChild(self.shadow)
			end
		end

		self:refreshShadowZ()
	elseif self.shadow then
		self.shadow:removeSelf()

		self.shadow = nil
	end
end

function ClipOnMap:setShadowEnabled(b)
	self.isShadow = b

	self:refreshShadow()
end

function ClipOnMap:setCustomLight(light, lightRadius, rgb)
	self.customLight = {
		light = light,
		radius = lightRadius,
		rgb = rgb or cc.c3b(255, 255, 255)
	}
end

function ClipOnMap:clearCustomLight()
	self.customLight = nil

	self:clearLight()
	self:refreshLight()
end

function ClipOnMap:refreshLight(x, y)
	if global.noEffect then
		return
	end

	if Sound.getDislayLevel() >= 2 then
		return
	end

	x = x or self.x
	y = y or self.y

	if self.size and self.size > 1 then
		local ptPerTile = 96

		if self.map then
			ptPerTile = self.map.ptPerTile
		end

		x = x + (self.size - 1) * ptPerTile / 2
		y = y + (self.size - 1) * ptPerTile / 2
	end

	self:clearLight(true)

	local light = self.customLight or self.light

	if self.map and light and not empty(light.light) and not empty(light.radius) and self.visible and not self:isHidden() then
		self.lightPreTiles = {}
		local tile = self.map:mapToTile(x, y)

		if tile then
			local maxRange = light.radius * self.map.ptPerTile * 1.4142
			local ceilRadius = math.ceil(light.radius)

			for m = tile.x - ceilRadius, tile.x + ceilRadius do
				for n = tile.y - ceilRadius, tile.y + ceilRadius do
					local tempTile = self.map:getTile(m, n)

					if tempTile then
						local tempX, tempY = self.map:tileToMap(tempTile)
						local range = math.sqrt(math.pow(tempY - y, 2) + math.pow(tempX - x, 2))
						local rangeOffset = 1 - range / maxRange

						if rangeOffset > 0 then
							tempTile:addClipLight(self.id, math.max(0, light.light * self.opacity / 255 * math.pow(1 - range / maxRange, 1.4142)), light.rgb)
							table.insert(self.lightPreTiles, tempTile)
						end
					end
				end
			end

			if not self.lightColorMask then
				self.lightColorMask = self.map:addColorMask("ClipOnMap_" .. self.id, self.x, self.y, self.light.rgb or cc.c3b(255, 255, 255), light.radius, light.light * self.opacity / 255)
			else
				self.map:changeColorMask("ClipOnMap_" .. self.id, self.x, self.y, light.light * self.opacity / 255)
			end
		end
	end
end

function ClipOnMap:clearLight(isRefresh)
	if self.lightPreTiles then
		for i = 1, #self.lightPreTiles do
			self.lightPreTiles[i]:removeClipLight(self.id)
		end

		self.lightPreTiles = nil
	end

	if not isRefresh and self.lightColorMask then
		self.map:removeColorMask("ClipOnMap_" .. self.id)
	end
end

function ClipOnMap:refreshShadowZ()
	local scalePercent = math.max(0, 32 / (self.z + 32))

	self.shadow:setScale(self:getFootWidth() / self.map.ptPerTile * scalePercent)
end

function ClipOnMap:getFootWidth()
	local footWidth = self:getTotalWidth() * self.scale * self.shadowScale

	if self.map then
		footWidth = math.min(footWidth, self.map.ptPerTile * self.size)
	end

	return footWidth
end

function ClipOnMap:getTotalWidth()
	return self.totalWidth or self.width
end

function ClipOnMap:getTotalHeight()
	return self.totalHeight or self.height
end

function ClipOnMap:setStyle(obj)
	if obj.offset then
		local offset = string.split(obj.offset, ",")

		self:draw(self.x + tonumber(offset[1]), self.y + tonumber(offset[2]), true)
	end

	if obj.color then
		local colors = string.split(obj.color, ",")

		self:setColor(cc.c3b(tonumber(colors[1]), tonumber(colors[2]), tonumber(colors[3])))
	end

	if obj.jumpword then
		local params = string.split(obj.jumpword, ",")

		self:jumpWord(params[1], params[2])
	end

	if obj.opacity then
		self:setOpacity(tonumber(obj.opacity))
	end

	if obj.mirror then
		self:setScaleX(tonumber(obj.mirror.x) or 1)
		self:setScaleY(tonumber(obj.mirror.y) or 1)
	end

	if obj.alwaysVisible then
		self.alwaysVisible = tonumber(obj.alwaysVisible) == 1
	end

	if obj.fixedLight then
		self.fixedLight = tonumber(obj.fixedLight) or -1

		self:refreshVisible(true)
	end

	if obj.syncFrame then
		self.syncFrame = tonumber(obj.syncFrame) == 1
	end

	if obj.angle then
		self.angle = tonumber(obj.angle) / 180 * math.pi
	end

	if obj.action then
		self:setAction(obj.action)
		self:refreshShadow()
	end

	if obj.actionOnce then
		self:setAction(obj.actionOnce, 1, function ()
			self:setAction("idle")
		end)
		self:refreshShadow()
	end

	if obj.scale then
		self:setScale(obj.scale)
	end

	if obj.light then
		local lightArr = string.split(obj.light, ",")
		self.light = {
			light = tonumber(lightArr[1]),
			radius = tonumber(lightArr[2])
		}

		if lightArr[3] then
			self.light.rgb = cc.c3b(255, 255, 255)
		else
			self.light.rgb = cc.c3b(tonumber(lightArr[3]), tonumber(lightArr[4]), tonumber(lightArr[5]))
		end

		self:draw()
	end

	if obj.mapAction then
		local arr = string.split(obj.mapAction, ",")

		if arr[2] == "" or arr[2] == nil then
			self:removeMappedAction(arr[1])
		else
			self:setMappedAction(arr[1], arr[2])
		end
	end

	if obj.face then
		local face = string.split(obj.face, ",")
		local x, y = self.map:tileToMap(tonumber(face[1]), tonumber(face[2]))
		self.angle = math.atan2(y - self.y, x - self.x)
	end

	if obj.rotate then
		self:setRotate(tonumber(obj.rotate * math.pi / 180))
	end

	if obj.speed then
		self.speed = tonumber(obj.speed)
	end

	if obj.zorder then
		self.zorderOffset = obj.zorder

		if self.map then
			self:draw()
		end
	end

	if obj.layer then
		self:retain()
		self:removeFromParent()

		if obj.layer == -1 then
			self.map.tileLayer:addChild(self)
		elseif obj.layer == 0 then
			self.map.lowLayer:addChild(self)
		elseif obj.layer == 2 then
			self.map.highLayer:addChild(self)
		else
			self.map.baseLayer:addChild(self)
		end

		self:release()
	end
end

function ClipOnMap:getEffectGen()
	if self.effectGen == nil then
		self.effectGen = UnitEffect.new(self)
	end

	return self.effectGen
end

function ClipOnMap:enterTile(tile)
	if tile then
		tile:addOther(self)
	end
end

function ClipOnMap:leaveTile(tile)
	if tile then
		tile:removeOther(self)
	end
end

function ClipOnMap:removeFromMap()
	if self.tile then
		for i = 0, self.size - 1 do
			for j = 0, self.size - 1 do
				self:leaveTile(self.map:getTile(self.tile.x + i, self.tile.y + j))
			end
		end

		self.tile = nil
	end

	self.alreadyRemoved = true
end

function ClipOnMap:retile()
	if self.noRetile then
		return
	end

	local tile = self.map:mapToTile(self)
	local preTile = self.tile

	if preTile ~= tile then
		if self.size == 1 then
			if preTile ~= nil then
				self:leaveTile(preTile)
			end

			self.tile = tile

			self:enterTile(tile)
		elseif preTile == nil then
			self.tile = tile

			for i = 0, self.size - 1 do
				for j = 0, self.size - 1 do
					self:enterTile(self.map:getTile(tile.x + i, tile.y + j))
				end
			end
		else
			local dirtyX = preTile.x - tile.x
			local dirtyY = preTile.y - tile.y
			local minX = preTile.x
			local maxX = preTile.x + self.size - 1
			local minY = preTile.y
			local maxY = preTile.y + self.size - 1

			if dirtyX > 0 then
				local limit = math.max(minX, maxX - dirtyX + 1)

				for i = limit, maxX do
					for j = minY, maxY do
						self:leaveTile(self.map:getTile(i, j))
					end
				end

				maxX = limit - 1
			elseif dirtyX < 0 then
				local limit = math.min(maxX, minX - dirtyX - 1)

				for i = minX, limit do
					for j = minY, maxY do
						self:leaveTile(self.map:getTile(i, j))
					end
				end

				minX = limit + 1
			end

			if dirtyY > 0 then
				local limit = math.max(minY, maxY - dirtyY + 1)

				for j = limit, maxY do
					for i = minX, maxX do
						self:leaveTile(self.map:getTile(i, j))
					end
				end
			elseif dirtyY < 0 then
				local limit = math.min(maxY, minY - dirtyY - 1)

				for j = minY, limit do
					for i = minX, maxX do
						self:leaveTile(self.map:getTile(i, j))
					end
				end
			end

			self.tile = tile
			local dirtyX = tile.x - preTile.x
			local dirtyY = tile.y - preTile.y
			local minX = tile.x
			local maxX = tile.x + self.size - 1
			local minY = tile.y
			local maxY = tile.y + self.size - 1

			if dirtyX > 0 then
				local limit = math.max(minX, maxX - dirtyX + 1)

				for i = limit, maxX do
					for j = minY, maxY do
						self:enterTile(self.map:getTile(i, j))
					end
				end

				maxX = limit - 1
			elseif dirtyX < 0 then
				local limit = math.min(maxX, minX - dirtyX - 1)

				for i = minX, limit do
					for j = minY, maxY do
						self:enterTile(self.map:getTile(i, j))
					end
				end

				minX = limit + 1
			end

			if dirtyY > 0 then
				local limit = math.max(minY, maxY - dirtyY + 1)

				for j = limit, maxY do
					for i = minX, maxX do
						self:enterTile(self.map:getTile(i, j))
					end
				end
			elseif dirtyY < 0 then
				local limit = math.min(maxY, minY - dirtyY - 1)

				for j = minY, limit do
					for i = minX, maxX do
						self:enterTile(self.map:getTile(i, j))
					end
				end
			end
		end

		self:dispatchEvent({
			name = "retile"
		})
		self:refreshVisible()
	end
end

function ClipOnMap:clearRefreshVisibleFrame()
	self.preRefreshFrame = nil
end

function ClipOnMap:setForceLight(light)
	self.forceLight = light

	self:refreshVisible(true)
end

function ClipOnMap:clearForceLight()
	self.forceLight = nil

	self:refreshVisible(true)
end

function ClipOnMap:refreshSelfLight()
	if self.visible and self.map then
		local lightTotal = 0
		local lightR = 0
		local lightG = 0
		local lightB = 0
		local lightCount = 0

		for i = 0, self.size - 1 do
			for j = 0, self.size - 1 do
				local tile = self.map:getTile(self.tile.x + i, self.tile.y + j)
				local light, r, g, b = tile:getUnitLightRGB()
				lightTotal = lightTotal + light
				lightR = lightR + r
				lightG = lightG + g
				lightB = lightB + b
				lightCount = lightCount + 1
			end
		end

		self.darkness = self.forceLight

		if not self.darkness then
			if self.fixedLight >= 0 then
				self.darkness = math.max(self.fixedLight, math.max(0, math.min(1, lightTotal / lightCount)) * 255)
			else
				self.darkness = math.max(0, math.min(1, lightTotal / lightCount)) * 255
			end
		end

		if not self.fixedDarkness then
			local darkness = self.darkness

			if self.light and self.light.selfLight and self.light.selfLight ~= 0 then
				darkness = 255 * self.light.selfLight + (1 - self.light.selfLight) * darkness
			end

			local color = Tile.getLightColor(darkness, lightR / lightCount, lightG / lightCount, lightB / lightCount)

			self:setColor(color)

			if self.shadow then
				self.shadow:setColor(color)
			end
		end
	end
end

function ClipOnMap:refreshVisible(force)
	if not self.tile then
		return
	end

	if not force and self.preRefreshFrame == MapFrameManager.getFrame() then
		return
	end

	self.preRefreshFrame = MapFrameManager.getFrame()
	local visible = false
	local lightTotal = 0
	local lightR = 0
	local lightG = 0
	local lightB = 0
	local lightCount = 0

	for i = 0, self.size - 1 do
		for j = 0, self.size - 1 do
			local tile = self.map:getTile(self.tile.x + i, self.tile.y + j)

			if tile:getVisible() and tile:getInview() then
				visible = true
			end

			local light, r, g, b = tile:getUnitLightRGB()
			lightTotal = lightTotal + light
			lightR = lightR + r
			lightG = lightG + g
			lightB = lightB + b
			lightCount = lightCount + 1
		end
	end

	if self.map.isBattle then
		visible = true
	end

	local nowVisible = not self:isHidden() and (visible or self.alwaysVisible)
	local visibleChanged = self.visible ~= nowVisible
	self.visible = nowVisible

	if self.visible then
		self.darkness = self.forceLight

		if not self.darkness then
			if self.fixedLight >= 0 then
				self.darkness = math.max(self.fixedLight, math.max(0, math.min(1, lightTotal / lightCount)) * 255)
			else
				self.darkness = math.max(0, math.min(1, lightTotal / lightCount)) * 255
			end
		end

		if not self.fixedDarkness then
			local darkness = self.darkness

			if self.light and self.light.selfLight and self.light.selfLight ~= 0 then
				darkness = 255 * self.light.selfLight + (1 - self.light.selfLight) * darkness
			end

			local color = Tile.getLightColor(darkness, lightR / lightCount, lightG / lightCount, lightB / lightCount)

			self:setColor(color)

			if self.shadow then
				self.shadow:setColor(color)
			end
		end
	end

	self:refreshLight()

	if visibleChanged then
		self:setVisible(self.visible)

		if self.skeletons then
			for i, skeleton in ipairs(self.skeletons) do
				skeleton:setVisible(self.visible)
			end
		end

		if self.shadow then
			self.shadow:setVisible(self.visible)
		end
	end

	return visibleChanged
end

function ClipOnMap:setOpacity(opacity)
	self.opacity = opacity

	ClipOnMap.super.setOpacity(self, opacity)

	if self.shadow then
		self.shadow:setOpacity(opacity)
	end

	if self.skeletons then
		for i, skeleton in ipairs(self.skeletons) do
			skeleton:setOpacity(opacity)
		end
	end

	self:refreshLight()
end

function ClipOnMap:changeLayer(layer)
	if tolua.isnull(self) then
		return
	end

	self:retain()
	self:removeFromParent()
	layer:addChild(self)
	self:release()
	self:retile()
end

function ClipOnMap:clone(class)
	local cloneClip = ClipOnMap.super.clone(self, class or ClipOnMap)

	cloneClip:setScale(1)

	if self.map then
		cloneClip:display(self.map, self.x, self.y)
		self:cloneAction(cloneClip)
	end

	return cloneClip
end

function ClipOnMap:getCenter(obj)
	local x1 = self.x
	local y1 = self.y

	if self.size ~= nil and self.size > 1 then
		x1 = x1 + (self.size - 1) * self.map.ptPerTile / 2
		y1 = y1 + (self.size - 1) * self.map.ptPerTile / 2
	end

	local x2, y2 = nil

	if obj ~= nil then
		x2 = obj.x
		y2 = obj.y

		if obj.size ~= nil and type(obj.size) == "number" and obj.size > 1 then
			x2 = x2 + (obj.size - 1) * self.map.ptPerTile / 2
			y2 = y2 + (obj.size - 1) * self.map.ptPerTile / 2
		end
	end

	return x1, y1, x2, y2
end

function ClipOnMap:getGridCenter()
	local x = (math.floor(self.x / self.map.ptPerTile) + self.size / 2) * self.map.ptPerTile
	local y = (math.floor(self.y / self.map.ptPerTile) + self.size / 2) * self.map.ptPerTile

	return x, y
end

function ClipOnMap:getCenterTile()
	local centerX, centerY = self:getCenter()

	return self.map:mapToTile(centerX, centerY)
end

function ClipOnMap:getRange(obj)
	local x1, y1, x2, y2 = self:getCenter(obj)

	return math.sqrt(math.pow(x2 - x1, 2) + math.pow(y2 - y1, 2))
end

function ClipOnMap:getAngle(obj)
	local x1, y1, x2, y2 = self:getCenter(obj)

	return math.atan2(y2 - y1, x2 - x1)
end

function ClipOnMap:loadSpine(spineName)
	ClipOnMap.super.loadSpine(self, spineName)

	self.zorderOffset = 1
	self.rotate = true
end

function ClipOnMap:setColor(color)
	cc.Node.setColor(self, color)

	if self.skeletons then
		for i, skeleton in ipairs(self.skeletons) do
			skeleton:setColor(color)
		end
	end
end

function ClipOnMap:refreshSpineScale()
	if self.skeletons then
		local angle = self.angle

		if angle > math.pi * 2 then
			angle = angle - math.floor(angle / (math.pi * 2)) * math.pi * 2
		end

		if angle < 0 then
			angle = angle + math.floor(math.abs(angle) / (math.pi * 2) + 1) * math.pi * 2
		end

		local mirror = 1

		if angle > math.pi / 4 and angle < math.pi / 4 * 3 then
			mirror = -1
		end

		for i, skeleton in ipairs(self.skeletons) do
			skeleton:setScaleX(self.scaleBeforeMap * skeleton.scale * mirror)
			skeleton:setScaleY(self.scaleBeforeMap * skeleton.scale)
		end
	end
end

function ClipOnMap:refreshSpine(map)
	map = map or self.map
	local data = self.spineData

	self:clearSpine()

	self.skeletons = {}

	if data then
		self.skeletonParams = data.spines

		for i, v in ipairs(data.spines) do
			local jsonFile = getFinalRes("res/spine/" .. v.name .. "/skeleton.json")
			local atlasFile = getFinalRes("res/spine/" .. v.name .. "/skeleton.atlas")
			local skeleton = sp.SkeletonAnimation:createWithJsonFile(jsonFile, atlasFile)
			skeleton.name = v.name
			skeleton.scale = v.scale
			skeleton.yoff = v.yoff
			skeleton.zOffset = v.zoffset
			skeleton.layer = v.layer

			if map then
				if v.layer == 0 then
					map.lowLayer:addChild(skeleton)
				elseif v.layer == 2 then
					map.highLayer:addChild(skeleton)
				else
					map.baseLayer:addChild(skeleton)
				end
			else
				self:addChild(skeleton, v.layer)
			end

			skeleton:setAnimation(0, self.rawAction or "idle", true)
			event_listener.extendMethods(skeleton, true)
			table.insert(self.skeletons, skeleton)
		end

		self:refreshSpineScale()
	else
		Log.warn("Spine.load error no data", name)
	end
end

function ClipOnMap:clearSpine()
	if self.skeletons then
		for i, skeleton in ipairs(self.skeletons) do
			skeleton:setVisible(false)
			skeleton:unregisterSpineEventHandler(sp.EventType.ANIMATION_EVENT)
			skeleton:unregisterSpineEventHandler(sp.EventType.ANIMATION_COMPLETE)

			if not tolua.isnull(skeleton) then
				MapFrameManager.setTimeout(function ()
					skeleton:removeSelf()
				end, 1, skeleton)
			end
		end

		self.skeletons = nil
	end
end

function ClipOnMap:setRotate(value)
	local rotation = ClipOnMap.super.setRotate(self, value)

	if self.skeletons then
		for i, skeleton in ipairs(self.skeletons) do
			if self.skeletonParams[i].rotate == 1 then
				skeleton:setRotation(rotation)
			end
		end
	end
end

function ClipOnMap:hasAction(action)
	if self.skeletons then
		local skeleton = self.skeletons[1]

		if skeleton:findAnimation(action) then
			return true
		end

		return false
	end

	return ClipOnMap.super.hasAction(self, action)
end

local skeletonActionTimeCache = {}

function ClipOnMap:getActionTotalFrameTime(action)
	if empty(action) then
		return 0
	end

	if self.skeletons then
		for i, skeleton in ipairs(self.skeletons) do
			local animation = skeleton:findAnimation(action)

			if animation then
				if not skeletonActionTimeCache[skeleton.name] then
					skeletonActionTimeCache[skeleton.name] = {}
				end

				if not skeletonActionTimeCache[skeleton.name][action] then
					skeletonActionTimeCache[skeleton.name][action] = math.floor(SpineHelper.getSpineEventTime(skeleton.name, action, "over") * 60)
				end

				return skeletonActionTimeCache[skeleton.name][action]
			end
		end
	end

	return ClipOnMap.super.getActionTotalFrameTime(self, action)
end

function ClipOnMap:getFrameCount(action)
	if self.skeletons then
		return self:getActionTotalFrameTime(action)
	end

	return ClipOnMap.super.getFrameCount(self, action)
end

function ClipOnMap:getSpineEventTime(action, eventName)
	if self.skeletons then
		for i, skeleton in ipairs(self.skeletons) do
			local animation = skeleton:findAnimation(action)

			if animation then
				return math.floor(SpineHelper.getSpineEventTime(skeleton.name, action, eventName) * 60)
			end
		end
	end
end

function ClipOnMap:setAction(action, loop, overFunc, startFrame)
	self.rawAction = action

	if empty(action) then
		if overFunc then
			overFunc()
		end

		return
	end

	ClipOnMap.super.setAction(self, action, loop, overFunc, startFrame)

	if self.skeletons then
		local startTime = 0

		if startFrame then
			startTime = startFrame / 60
		end

		local skeleton = self.skeletons[1]

		if overFunc then
			skeleton:registerSpineEventHandler(function (event)
				if overFunc and event.loopCount >= loop - 1 and event.event.data.name == "over" then
					overFunc(self)

					overFunc = nil
				end
			end, sp.EventType.ANIMATION_EVENT)
			skeleton:registerSpineEventHandler(function (event)
				if overFunc and loop <= event.loopCount then
					overFunc(self)

					overFunc = nil
				end
			end, sp.EventType.ANIMATION_COMPLETE)
		end

		skeleton:setAnimation(0, action, true)

		if startTime and startTime > 0 then
			skeleton:update(startTime)
		end
	end
end

function ClipOnMap:jumpWord(fontText, fontFamily, fontZ, lastingTime, yOffset, noRandomPosition, holding, jumpHeight)
	if global.noEffect then
		return
	end

	fontText = tostring(fontText)
	fontZ = fontZ or 0
	yOffset = yOffset or 0
	local fontOffsetX = math.random() * 16 - 8
	local fontOffsetY = math.random() * 10 - 5

	if noRandomPosition then
		fontOffsetX = 0
		fontOffsetY = 0
	end

	if self.noEntity then
		fontOffsetY = fontOffsetY - 15
	end

	local dmgFont = MapFont.new(fontFamily, fontText, 1)
	local drawX, drawY = self.map:mapToDraw(self:getCenter())

	dmgFont:setZOrder(fontZ)
	dmgFont:display(self.map.hudHighLayer, drawX + fontOffsetX, -drawY + self:getTotalHeight() + 30 + fontOffsetY + yOffset)
	dmgFont:jumpIn(lastingTime or 15, jumpHeight)
end

function ClipOnMap:onEnter()
	ClipOnMap.super.onEnter(self)
end

function ClipOnMap:onExit()
	if not app.sceneChanging then
		self:clearSpine()
		self:removeFromMap()

		if self.shadow then
			self.shadow:removeSelf()

			self.shadow = nil
		end

		self:clearLight()

		if self.effectGen then
			self.effectGen:destroy()

			self.effectGen = nil
		end
	end

	ClipOnMap.super.onExit(self)
end

return ClipOnMap
