local POP_hint_option = class("POP_hint_option", UI_base)

function POP_hint_option.open(id, onSelect)
	local ui = POP_hint_option.new(id, onSelect)
	local content = display.newSprite()

	content:addChild(ui)

	ui.content = content

	PopManager.open(content, nil, function ()
		ui:onClose()
	end, nil, )
end

function POP_hint_option:ctor(id, onSelect)
	POP_hint_option.super.ctor(self, "pop_hint_option", UIManager.BIG_TYPE.POP)

	self.id = id
	self.onSelect = onSelect

	self:init()
end

function POP_hint_option:init()
	self:initUI()
end

function POP_hint_option:initUI()
	local mask = self:getComponentByTag("mask")

	mask:toTouchable()
	mask:setOpacity(0)

	local hintData = CsvParser.getCsvData("hint", self.id)
	local options = SheetUtil.getColumnList(hintData, {
		"option_",
		"option_next_"
	}, {
		"name",
		"next"
	})
	local labelWidth, labelHeight, intervalSum = self:setText(hintData.text)

	self:performWithDelay(function ()
		POP_hint_option.isOver = true

		if isCenter then
			self:showArrow()
		end
	end, intervalSum + 0.2)

	local listHeight = #options * 90
	local listFlag = self:getFlagByTag("flag_list")
	listFlag.height = listHeight
	listFlag.y = listFlag.y - listHeight
	local bg1 = self:getComponentByTag("bg1")

	bg1:setSize(nil, bg1.height + listHeight)
	bg1:setPos(nil, bg1.y - listHeight)
	self:setPositionY(listHeight / 2)

	local function tapListener(ui, data, index, x, y)
		self.selectIndex = index

		print("$$$ self.content", self.content)
		PopManager.closeTo(self.content)
	end

	local list = self:createListOnFlag("flag_list", LIST_hint_option, tapListener)

	list:setItems(options)

	if hintData.emotion == 1 then
		Style.makeShock(self)
	end
end

function POP_hint_option:setText(text)
	text = StringUtil.replaceTag(text, function (tag, embedded)
		return ManagerInfo.parseTag(tag, not embedded)
	end)

	self:removeLabelGroupOnFlag("flag_text")

	local ubbMap, labels, lines, totalWidth, totalHeight = self:createUbbOnFlag("flag_text", text, {
		yspace = 5,
		wrap = true,
		align = Style.center,
		valign = Style.vcenter
	})
	local fadeTime = 0.02
	local defaultInterval = 0.025
	local defaultLineInterval = 0

	if Localization.isAlphabet() then
		defaultInterval = defaultInterval / 2
	end

	local intervalSum = self:animateUbb(ubbMap, labels, fadeTime, defaultInterval, defaultLineInterval)

	return totalWidth, totalHeight, intervalSum
end

function POP_hint_option:onClose()
	local onSelect = self.onSelect
	local selectIndex = self.selectIndex
	self.onSelect = nil

	if onSelect then
		onSelect(selectIndex)
	end
end

return POP_hint_option
