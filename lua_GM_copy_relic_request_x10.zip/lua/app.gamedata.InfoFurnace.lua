local InfoFurnace = {}
local rawData = nil

function InfoFurnace.init()
	Connection.listen("furnace_sync", InfoFurnace.sync)
end

app:addToAppEnterCall(InfoFurnace.init)

function InfoFurnace.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoFurnace.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("furnace_query", callback)
end

function InfoFurnace.onQuery(rcvData)
	rawData = rcvData
end

function InfoFurnace.sync(data)
	for k, v in pairs(data) do
		rawData[k] = v
	end

	ManagerInfo.dataChange("furnace", data)
end

function InfoFurnace.getMine(mine_index, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "furnace_get_mine")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("furnace_get_mine", {
		mine_index = mine_index
	}, callback)
end

function InfoFurnace.harvest(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			local rewards = rcvData.rewards

			if rewards and #rewards > 0 then
				POP_reward.openMixed(rewards, nil, Localization.getSrcText("额外收获"))
			end

			local params = {
				function_id = 1,
				building_id = InfoBuilding.TAG.FURNACE
			}

			TaHelper.taTrack("building_function", params)

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("furnace_harvest", callback)
end

function InfoFurnace.getData()
	return rawData
end

function InfoFurnace.getMineRecord(mine_index)
	if DEV_MODE and empty(mine_index) then
		return 0
	end

	local section, position = BitUtil.split(30, mine_index)
	local recordNum = rawData["record_" .. section]

	return BitUtil.getBitByIndex(recordNum, position)
end

function InfoFurnace.getMineNum()
	return rawData.mine_num
end

function InfoFurnace.getSpeed()
	local furnaceNum = CsvParser.getCsvData("furnace_base_num", rawData.mine_num)

	if not furnaceNum then
		local maxID = CsvParser.getMaxID("furnace_base_num")
		furnaceNum = CsvParser.getCsvData("furnace_base_num", maxID)
	end

	local speedScale = 1

	if InfoOrder.inSeason() then
		speedScale = speedScale + InfoOrder.getSeasonFunc(2) / 100
	end

	local plusData = InfoBuilding.getPlusData(InfoBuilding.TAG.FURNACE, 302)

	if plusData then
		speedScale = speedScale + plusData.value1 / 100
	end

	local goldAdd = furnaceNum.gold_add
	local plusData = InfoBuilding.getPlusData(InfoBuilding.TAG.FURNACE, 301)

	if plusData then
		goldAdd = goldAdd + plusData.value1
	end

	return goldAdd * speedScale, furnaceNum.gold_add, goldAdd - furnaceNum.gold_add
end

function InfoFurnace.getCash()
	local nowTime = Time.now()
	local time_offset = nowTime - rawData.cash_time
	local speed = InfoFurnace.getSpeed()
	local cash = rawData.cash + math.floor(time_offset * speed / 3600)
	local buildingCSV = InfoBuilding.getBuildingData(InfoBuilding.TAG.FURNACE)
	local maxStock = buildingCSV.value1

	if empty(maxStock) then
		maxStock = 0
	end

	local cashMax = maxStock
	cash = math.min(cash, cashMax)

	return cash, cashMax, speed
end

function InfoFurnace.getTime()
	local cash, cashMax, speed = InfoFurnace.getCash()
	local nowTime = Time.now()
	local time_offset = nowTime - rawData.cash_time
	local cash = rawData.cash + math.floor(time_offset * speed / 3600)
	local timeTotal = cashMax / (speed / 3600)
	local timeLeft = (cashMax - cash) / (speed / 3600)

	return timeLeft, timeTotal
end

return InfoFurnace
