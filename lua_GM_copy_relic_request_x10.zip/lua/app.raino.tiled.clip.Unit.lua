local Clip = import(".Clip")
local ClipOnMap = import(".ClipOnMap")
local MapFrameManager = import("..map.MapFrameManager")
local Tile = import("..map.Tile")
local Unit = class("Unit", ClipOnMap)
Unit.focusUnit = nil

function Unit.setFocusUnit(unit, noDraw)
	Unit.focusUnit = unit

	if not noDraw and unit then
		unit:draw()
	end
end

local AVATAR_TYPE = {
	VECTOR = 2,
	MODEL = 1,
	BASE_MODEL = 0
}
local AVATAR_LAYERS = {
	[0] = AVATAR_TYPE.BASE_MODEL,
	AVATAR_TYPE.MODEL,
	AVATAR_TYPE.MODEL,
	AVATAR_TYPE.VECTOR,
	AVATAR_TYPE.VECTOR,
	AVATAR_TYPE.VECTOR,
	AVATAR_TYPE.VECTOR,
	AVATAR_TYPE.VECTOR,
	AVATAR_TYPE.MODEL,
	AVATAR_TYPE.MODEL,
	AVATAR_TYPE.MODEL
}
Unit.AVATAR_LAYERS = AVATAR_LAYERS

function Unit.setAvatarCache(modelName, avatarInfo)
	if not Unit.avatarCache then
		Unit.avatarCache = {}
	end

	avatarInfo = ObjUtil.readonly(avatarInfo)
	Unit.avatarCache[modelName] = avatarInfo
end

function Unit.getAvatarCache(modelName)
	if Unit.avatarCache and Unit.avatarCache[modelName] then
		return Unit.avatarCache[modelName]
	end
end

function Unit:ctor(type)
	Unit.super.ctor(self, type)
	self:setCascadeColorEnabled(true)

	self.x = 0
	self.y = 0
	self.speed = 0
	self.moveType = 0
	self.walkLevel = 0
	self.moveAngle = 0
	self.moving = false
	self.isBlock = true
	self.noBlock = false
	self.effects = {}
	self.last_effects = {}
	self.avatarMap = {}
	self.avatarInfo = {}
	self.additionalUI = {}
	self.alwaysActive = false
end

function Unit:setData(data)
	self.data = data
	self.size = data.size

	if not empty(data.speed) then
		self.speed = data.speed
	end

	self.moveType = data.move_type

	self:setScale(data.scale)

	if string.sub(data.model, 1, 1) == "#" then
		local picPath = string.sub(data.model, 2)

		self:loadPic(getFinalRes(picPath))
	else
		self:load(data.model)
	end

	if data.patrol_step then
		self:setPatrolData(data.patrol_step, data.patrol_wait, data.patrol_way)
	end
end

function Unit:setPatrolData(patrolStep, patrolWait, patrolWay)
	self.patrolData = {
		step = patrolStep,
		wait = patrolWait,
		waitCount = SheetUtil.getNumber(patrolWait),
		way = patrolWay
	}
	self.patrolStep = patrolStep
	self.patrolWait = patrolWait
end

function Unit:setPatrolArea(tileMap)
	if self.patrolData then
		self.patrolData.area = tileMap
	end
end

function Unit:patrol(fleeStr, fleeTargets)
	if self.patrolData and self.patrolData.area then
		local patrolStep = self.patrolData.step
		local patrolSpeed = self.data.speed
		local patrolAction, findBestDig = nil

		if not empty(fleeStr) then
			local fleeArr = string.split(fleeStr, ",")

			if not empty(fleeArr[1]) then
				patrolAction = SheetUtil.getString(fleeArr[1])
			end

			if not empty(fleeArr[2]) then
				patrolSpeed = SheetUtil.getNumber(fleeArr[2])
			end

			if not empty(fleeArr[3]) then
				patrolStep = fleeArr[3]
			end

			if fleeTargets then
				function findBestDig(neiboursInArea)
					local bestTile, bestScore = nil

					for i, tile in ipairs(neiboursInArea) do
						local score = 0

						for j, enemy in ipairs(fleeTargets) do
							if enemy.tile then
								score = score + math.abs(enemy.tile.x - tile.x) + math.abs(enemy.tile.y - tile.y)
							end
						end

						if not bestTile or bestScore < score then
							bestTile = tile
							bestScore = score
						end
					end

					return bestTile
				end
			end
		end

		local path = self.map:digPath(self.tile, self.walkLevel, self.size, SheetUtil.getNumber(patrolStep) + 1, self.patrolData.area, self, self.patrolData.way, findBestDig)

		if patrolSpeed ~= self.data.speed then
			self.speed = patrolSpeed
		end

		local result = self:goPath(path)

		if not result then
			if patrolSpeed ~= self.data.speed then
				self.speed = self.data.speed
			end

			if patrolAction then
				self:removeMappedAction("walk")
				self:setAction("idle")
			end

			self:waitForPatrol()
		else
			if patrolAction then
				self:setMappedAction("walk", patrolAction)
				self:setAction(patrolAction)
			end

			if patrolAction or patrolSpeed ~= self.data.speed then
				self:setPathFinishedCallback(function ()
					if patrolSpeed ~= self.data.speed then
						self.speed = self.data.speed
					end

					if patrolAction then
						self:removeMappedAction("walk")
						self:setAction("idle")
					end
				end)
			end
		end
	end
end

function Unit:waitForPatrol(isInit)
	if self.map and self.map.isBattle then
		return
	end

	if self.patrolData and self.patrolData.area and self.speed > 0 then
		if isInit then
			local patrolTime = SheetUtil.getNumber(self.patrolData.step) * self.map.ptPerTile / self.speed
			local waitTime = SheetUtil.getNumber(self.patrolData.wait)

			if patrolTime > math.random() * (patrolTime + waitTime) then
				self:patrol()

				return
			end
		end

		self.patrolData.waitCount = SheetUtil.getNumber(self.patrolData.wait)

		if self.waking then
			MapFrameManager.startLoop(self, self.patrolWaitLoop)
		end
	end
end

function Unit:stopPatrolWaiting()
	MapFrameManager.stopLoop(self, self.patrolWaitLoop)
end

function Unit:patrolWaitLoop(frame, passed, sharp)
	if sharp == 0 then
		return
	end

	if self.waking then
		self.patrolData.waitCount = self.patrolData.waitCount - 1

		if self.patrolData.waitCount <= 0 then
			self:stopPatrolWaiting()
			self:patrol()
		end
	else
		self:stopPatrolWaiting()
	end
end

function Unit:stopPatrol()
	self:stop()
	self:stopPatrolWaiting()

	self.patrolData = nil
end

function Unit:onTileUnitChanged(unit, addOrRemove)
	if self.map.isBattle then
		return
	end

	if unit.type == "hero" then
		if addOrRemove then
			self.patrolData.target = unit
		else
			self.patrolData.target = nil
		end
	end
end

function Unit:checkChase()
end

function Unit:refreshTotalWidthAndHeight()
	if self.originalWidth and self.originalHeight then
		local totalWidth = self.originalWidth
		local totalHeight = self.originalHeight

		for layer, clip in pairs(self.avatarMap) do
			if AVATAR_LAYERS[layer] ~= AVATAR_TYPE.VECTOR then
				totalWidth = math.max(totalWidth, clip.originalWidth)
				totalHeight = math.max(totalHeight, clip.originalHeight)
			end
		end

		self.totalWidth = totalWidth * self.scale
		self.totalHeight = totalHeight * self.scale
	end
end

function Unit:display(map, x, y, customLayer)
	Unit.super.display(self, map, x, y, customLayer)

	if self.tile:getVisible() or self.alwaysActive then
		self.active = true
	end

	if self.readyLastingEffect then
		for i, obj in ipairs(self.readyLastingEffect) do
			self:addLastingEffect(obj.effectName, obj.frameTime, obj.noCount)
		end

		self.readyLastingEffect = nil
	end
end

function Unit:draw(x, y, setXY)
	x = x or self.x
	y = y or self.y
	local drawX, drawY = Unit.super.draw(self, x, y, setXY)

	if Unit.focusUnit == self and not self.map.isBattle then
		self.map:scrollTo(x, y)
		self.map:setFov(x, y)
	end

	if self.footsMap then
		for assetName, sprite in pairs(self.footsMap) do
			sprite:setPosition(drawX, -drawY)
		end
	end

	return drawX, drawY
end

function Unit:setScale(scale)
	Unit.super.setScale(self, scale)
	self:refreshTotalWidthAndHeight()
end

function Unit:refreshScale()
	Unit.super.refreshScale(self)

	local direction = nil
	local selfZ = self:getZ()

	for layer, clip in pairs(self.avatarMap) do
		if AVATAR_LAYERS[layer] == AVATAR_TYPE.VECTOR then
			if self:checkAvatarVector(layer) then
				direction = direction or self:getDirection()
				local vectorInfo = self:getAvatarVector(self.action, direction.d + 1, self.frame, layer)

				if vectorInfo then
					clip:setScale(self.scale * self.exScale)
					clip:setPosition(vectorInfo.x * direction.scale * self.scale * self.exScale, -vectorInfo.y * self.scale * self.exScale + selfZ * self.scale * self.exScale)
				end
			end
		else
			clip:setScale(self.scale * self.exScale)
		end
	end
end

function Unit:setActive(active)
	active = self.alwaysActive or active

	if self.active ~= active then
		self.active = active

		if active then
			if self.preMoving then
				self:go(self.desPoint.x, self.desPoint.y)
			end
		else
			self.preMoving = self.moving

			self:stop(1)
		end
	end
end

function Unit:addLastingEffect(effectName, frameTime, noCount, customLayer)
	if not self.map then
		self.readyLastingEffect = self.readyLastingEffect or {}

		table.insert(self.readyLastingEffect, {
			effectName = effectName,
			frameTime = frameTime,
			noCount = noCount
		})

		return
	end

	if self.last_effects[effectName] then
		local obj = self.last_effects[effectName]
		obj.count = obj.count + 1

		if frameTime and frameTime > 0 then
			MapFrameManager.setTimeout(function ()
				self:removeEffect(effectName)
			end, frameTime, obj.clip)
		end

		return obj.clip
	end

	local effect = Effect.new()

	effect:load(effectName)

	local spines = nil

	if effect.clipType == Clip.CLIP_TYPE.SPINE then
		spines = {}

		effect:refreshSpine(self.map)

		for i, skeleton in ipairs(effect.skeletons) do
			local obj = {
				clip = skeleton,
				overhead = effect.skeletonParams[i].overhead == 1
			}

			table.insert(spines, obj)
		end
	end

	if effect:hasAction("start") then
		effect:setAction("start", 1, function ()
			effect:setAction("idle")
		end)
	end

	if customLayer then
		customLayer:addChild(effect)
	elseif effect.layer == 0 then
		self.map.lowLayer:addChild(effect)
	elseif effect.layer == 2 then
		self.map.highLayer:addChild(effect)
	else
		self.map.baseLayer:addChild(effect)
	end

	local obj = {
		count = 1,
		clip = effect,
		overhead = effect.overhead,
		name = effectName,
		spines = spines
	}
	self.last_effects[effectName] = obj
	local bodyScale = math.max(1, self:getTotalWidth() / 96)
	local effectScale = 1

	if effect.param and effect.param.effect_scale then
		effectScale = effect.param.effect_scale
	end

	effect:setScale(math.sqrt(self.scale * bodyScale) * effectScale)
	self:draw()

	if frameTime and frameTime > 0 then
		MapFrameManager.setTimeout(function ()
			self:removeLastingEffect(effectName)
		end, frameTime, effect)
	end

	return effect
end

function Unit:removeLastingEffect(effectName, noCount)
	if self.last_effects[effectName] then
		local obj = self.last_effects[effectName]

		if not noCount and obj.count > 1 then
			obj.count = obj.count - 1
		else
			local effect = obj.clip

			if effect.hasAction and effect:hasAction("over") then
				effect:setAction("over", 1, function ()
					effect:removeSelf()
				end)
			else
				effect:removeSelf()
			end

			self.last_effects[effectName] = nil
		end
	end
end

function Unit:addEffect(effectName, customAction)
	self:removeEffect(effectName)

	local effect = Effect.new()

	effect:load(effectName)

	local spines = nil

	if effect.clipType == Clip.CLIP_TYPE.SPINE then
		spines = {}

		effect:refreshSpine(self.map)

		for i, skeleton in ipairs(effect.skeletons) do
			local obj = {
				clip = skeleton,
				overhead = effect.skeletonParams[i].overhead == 1
			}

			table.insert(spines, obj)
		end
	end

	if effect.layer == 0 then
		self.map.lowLayer:addChild(effect)
	elseif effect.layer == 2 then
		self.map.highLayer:addChild(effect)
	else
		self.map.baseLayer:addChild(effect)
	end

	local obj = {
		clip = effect,
		overhead = effect.overhead,
		spines = spines
	}
	self.effects[effectName] = obj
	local bodyScale = math.max(1, self:getTotalWidth() / 96)
	local effectScale = 1

	if effect.param and effect.param.effect_scale then
		effectScale = effect.param.effect_scale
	end

	effect:setScale(math.sqrt(self.scale * bodyScale) * effectScale)

	if not customAction then
		local effectAction = "idle"

		if effect:hasAction(self.action) then
			effectAction = self.action
		end

		effect:setAction(effectAction, 1, function ()
			if self.removeEffect then
				self:removeEffect(effectName)
			end
		end, nil, "over")
	end

	self:draw()

	return effect, obj
end

function Unit:removeEffect(effectName)
	if self.effects[effectName] then
		local obj = self.effects[effectName]

		if not tolua.isnull(obj.clip) then
			obj.clip:setOpacity(0)

			if obj.clip.delayRemove then
				obj.clip:delayRemove()
			else
				obj.clip:removeSelf()
			end
		end

		self.effects[effectName] = nil
	end
end

function Unit:clearEffect()
	if self.effects then
		for effectName, obj in pairs(self.effects) do
			local clip = obj.clip

			if not tolua.isnull(clip) then
				if clip.delayRemove then
					clip:delayRemove()
				else
					clip:removeSelf()
				end
			end
		end

		self.effects = {}
	end

	if self.last_effects then
		for effectName, obj in pairs(self.last_effects) do
			local clip = obj.clip

			if not tolua.isnull(clip) then
				if clip.delayRemove then
					clip:delayRemove()
				else
					clip:removeSelf()
				end
			end
		end

		self.last_effects = {}
	end
end

function Unit:addAura(effectName, zorder, forceScale, customLayer)
	if global.noEffect then
		return
	end

	self:removeAura(effectName)

	local effect = Effect.new()

	effect:load(effectName)

	local container = display.newNode()

	container:setCascadeOpacityEnabled(true)
	container:addChild(effect)

	container.layer = effect.layer
	container.scale = 1

	(customLayer or self.map.shadowLayer):addChild(container)

	local scale = forceScale or self:getFootWidth() / self.map.ptPerTile

	if effect.param and effect.param.effect_scale then
		scale = scale * effect.param.effect_scale
	end

	container:setScaleY(0.5 * scale)
	container:setScaleX(1 * scale)

	local obj = {
		count = 1,
		clip = container,
		effect = effect,
		name = effectName,
		zOffset = zorder
	}
	self.last_effects[effectName] = obj

	self:draw()

	return effect
end

function Unit:removeAura(effectName)
	self:removeLastingEffect(effectName)
end

function Unit:addUI(tag, ui, layer, zorder)
	self:removeUI(tag)

	local node = display.newNode()

	node:addChild(ui)

	if layer == 0 then
		self.map.lowLayer:addChild(node, zorder or 100)
	elseif layer == 2 then
		self.map.highLayer:addChild(node, zorder or 100)
	else
		self.map.baseLayer:addChild(node, zorder or 100)
	end

	self.additionalUI[tag] = node

	self:draw()
end

function Unit:removeUI(tag)
	if self.additionalUI[tag] then
		self.additionalUI[tag]:removeSelf()

		self.additionalUI[tag] = nil
	end
end

function Unit:load(modelName)
	self:clearAvatar()

	self.avatarStack = nil
	self.avatarVector = nil

	Unit.super.load(self, modelName)
	self:updateAvatar()
end

function Unit:initAvatar()
	if not self.avatarStack then
		self:setAvatarInfo(self.avatarInfo)
	end
end

function Unit:setExtraAvatar(avatarList)
	self.extraAvatar = avatarList

	self:updateAvatar()
end

function Unit:clearExtraAvatar()
	self.extraAvatar = nil

	self:updateAvatar()
end

function Unit:hasExtraAvatar()
	return self.extraAvatar ~= nil
end

function Unit:updateAvatar()
	if not self.data then
		return
	end

	if self.noAvatar then
		return
	end

	local avatarList = SheetUtil.getColumnList(self.data, {
		"avatar_index_",
		"avatar_id_"
	}, {
		"avatar",
		"value"
	})
	local avatarMap = {}

	for i, v in ipairs(avatarList) do
		avatarMap[v.avatar] = SheetUtil.getString(v.value, self.random)
	end

	if self.extraAvatar then
		for i, v in ipairs(self.extraAvatar) do
			avatarMap[v.avatar] = SheetUtil.getString(v.value, self.random)
		end
	end

	for i = 1, #Unit.AVATAR_LAYERS do
		if not empty(avatarMap["avatar_" .. i]) then
			local avatarStr = avatarMap["avatar_" .. i]

			self:setAvatar(avatarStr, i)
		else
			self:removeAvatar(i)
		end
	end
end

function Unit:setAvatar(modelName, layer)
	self:initAvatar()
	self:removeAvatar(layer)

	if AVATAR_LAYERS[layer] == AVATAR_TYPE.VECTOR then
		if self:checkAvatarVector(layer) then
			local anima = Animation.new()

			anima:load(modelName)
			anima:setLooper(MapFrameManager.core)

			self.avatarMap[layer] = anima

			self:addChild(anima)
			anima:setScale(self.scale)
		end
	elseif self.avatarStack then
		local clip = Clip.new()

		clip:load(modelName)
		clip:stopPlay()
		clip:setScale(self.scale)

		self.avatarMap[layer] = clip

		self:addChild(clip)
		self:refreshTotalWidthAndHeight()
		self:refreshShadow()
		self:updateColor()
	end

	local direction = self:getDirection(0)

	self:setFrame(self.action, direction, self:getNextFrame(direction))
end

function Unit:clearAvatar()
	self:clearBladeInfo()

	for layer, clip in pairs(self.avatarMap) do
		clip:removeSelf()
	end

	self.avatarMap = {}

	self:refreshTotalWidthAndHeight()
	self:refreshShadow()
	self:updateColor()
end

function Unit:removeAvatar(layer)
	self:clearBladeInfo()

	if self.avatarMap[layer] ~= nil then
		self.avatarMap[layer]:removeSelf()

		self.avatarMap[layer] = nil

		self:refreshTotalWidthAndHeight()
		self:refreshShadow()
		self:updateColor()
	end
end

function Unit:setAvatarInfo(avatarInfo)
	self:clearBladeInfo()

	if type(avatarInfo) == "table" then
		local avatarInfoCache = Unit.getAvatarCache(self.modelName)

		if avatarInfoCache then
			self.avatarVector = avatarInfoCache.vectors
			self.avatarStack = avatarInfoCache.stack
		else
			self.avatarVector = {}
			self.avatarStack = {}

			for action, directionArr in pairs(avatarInfo.layers) do
				self.avatarStack[action] = {}

				for direction, frameArr in ipairs(directionArr) do
					self.avatarStack[action][direction] = {}

					for frame, layerMap in ipairs(frameArr) do
						self.avatarStack[action][direction][frame] = {}

						for layer, v in pairs(layerMap) do
							local layerNum = tonumber(layer)
							self.avatarStack[action][direction][frame][layerNum] = v

							if avatarInfo.vectors and avatarInfo.vectors[action] and avatarInfo.vectors[action][direction] and avatarInfo.vectors[action][direction][frame] and avatarInfo.vectors[action][direction][frame][layer] then
								if not self.avatarVector[layerNum] then
									self.avatarVector[layerNum] = {}
								end

								if not self.avatarVector[layerNum][action] then
									self.avatarVector[layerNum][action] = {}
								end

								if not self.avatarVector[layerNum][action][direction] then
									self.avatarVector[layerNum][action][direction] = {}
								end

								if not self.avatarVector[layerNum][action][direction][frame] then
									self.avatarVector[layerNum][action][direction][frame] = avatarInfo.vectors[action][direction][frame][layer]
								end
							end
						end
					end
				end
			end

			Unit.setAvatarCache(self.modelName, {
				vectors = self.avatarVector,
				stack = self.avatarStack
			})
		end
	end
end

function Unit:checkAvatarVector(layer)
	if self.avatarVector and self.avatarVector[layer] then
		return true
	end

	return false
end

function Unit:getAvatarVector(action, direction, frame, layer, test)
	if self.avatarVector and self.avatarVector[layer] and self.avatarVector[layer][action] and self.avatarVector[layer][action][direction] and self.avatarVector[layer][action][direction][frame] then
		return self.avatarVector[layer][action][direction][frame]
	end
end

function Unit:clearBlade()
	self:clearBladePolygon()
	self:clearBladeInfo()
end

function Unit:clearBladeInfo()
	self.avatarBlade = nil
	self.preBladePts = nil
end

function Unit:setBladeInfo(vectorInfo, action, direction, frame, layer, anima)
	local nextVectorInfo = self:getAvatarVector(action, direction.d + 1, frame + 1, layer)

	if not nextVectorInfo then
		return nil
	end

	local avatarBlade = {
		anima = anima
	}
	local center = cc.p((vectorInfo.x + nextVectorInfo.x) / 2, -(vectorInfo.y + nextVectorInfo.y) / 2)
	local len1 = -anima:getSize().y * vectorInfo.sy / 100
	local len2 = -anima:getSize().y * (nextVectorInfo.sy / 100 + 1) / 2
	local angle1 = vectorInfo.a * math.pi / 180
	local x = vectorInfo.x + math.cos(angle1) * len1
	local y = -(vectorInfo.y + math.sin(angle1) * len1)
	avatarBlade.pt1 = {
		x * self.scale * direction.scale,
		y * self.scale
	}
	avatarBlade.angle1 = math.atan2(y - center.y, x - center.x)
	avatarBlade.distance1 = math.sqrt(math.pow(x - center.x, 2) + math.pow(y - center.y, 2))
	local angle2 = nextVectorInfo.a * math.pi / 180
	local x = nextVectorInfo.x + math.cos(angle2) * len2
	local y = -(nextVectorInfo.y + math.sin(angle2) * len2)
	avatarBlade.pt2 = {
		x * self.scale * direction.scale,
		y * self.scale
	}
	avatarBlade.angle2 = math.atan2(y - center.y, x - center.x)
	avatarBlade.distance2 = math.sqrt(math.pow(x - center.x, 2) + math.pow(y - center.y, 2))
	avatarBlade.center = {
		center.x * self.scale * direction.scale,
		center.y * self.scale
	}
	avatarBlade.ptStart = {
		vectorInfo.x * self.scale * direction.scale,
		-vectorInfo.y * self.scale
	}
	avatarBlade.ptEnd = {
		nextVectorInfo.x * self.scale * direction.scale,
		-nextVectorInfo.y * self.scale
	}
	avatarBlade.direction = direction

	if vectorInfo.ccw == 1 then
		if avatarBlade.angle2 < avatarBlade.angle1 then
			avatarBlade.angle2 = avatarBlade.angle2 + math.ceil((avatarBlade.angle1 - avatarBlade.angle2) / (math.pi * 2)) * math.pi * 2
		elseif avatarBlade.angle2 > avatarBlade.angle1 + math.pi * 2 then
			avatarBlade.angle2 = avatarBlade.angle2 - math.floor((avatarBlade.angle2 - avatarBlade.angle1) / (math.pi * 2)) * math.pi * 2
		end
	elseif avatarBlade.angle1 < avatarBlade.angle2 then
		avatarBlade.angle1 = avatarBlade.angle1 + math.ceil((avatarBlade.angle2 - avatarBlade.angle1) / (math.pi * 2)) * math.pi * 2
	elseif avatarBlade.angle1 > avatarBlade.angle2 + math.pi * 2 then
		avatarBlade.angle1 = avatarBlade.angle1 - math.floor((avatarBlade.angle1 - avatarBlade.angle2) / (math.pi * 2)) * math.pi * 2
	end

	self.avatarBlade = avatarBlade
end

local BLADE_TIME = 12
local BLADE_SAMPLING = 8
local BLADE_SCALE = 0.55

function Unit:makeBlade()
	if not self.map then
		return
	end

	local playSkip = self:getPlaySkip(self.action)
	local count = playSkip - self.playCount
	local total = playSkip

	if count > 0 then
		local avatarBlade = self.avatarBlade
		local direction = avatarBlade.direction
		local anima = avatarBlade.anima
		local prePercent = (count - 1) / total
		local percent = count / total
		local color1 = nil

		if anima.config.dark_color then
			color1 = string.split(anima.config.dark_color, ",")
		end

		local color2 = nil

		if anima.config.hi_color then
			color2 = string.split(anima.config.hi_color, ",")
		end

		local bladeLayers = {
			{
				inRadius = function ()
					return math.random() * 0.2 + 0.5
				end,
				color = color1 or {
					220,
					220,
					220
				}
			},
			{
				inRadius = function ()
					return math.random() * 0.2 + 0.2
				end,
				color = color2 or {
					240,
					240,
					240
				}
			}
		}
		self.preBladePts = self.preBladePts or {}
		local d1Map = {}

		for layer, bladeLayer in ipairs(bladeLayers) do
			local polygonStack = {}
			local prePts = self.preBladePts[layer]
			local startIndex = nil

			if prePercent == 0 then
				startIndex = math.floor(prePercent * BLADE_SAMPLING)
			else
				startIndex = math.floor(prePercent * BLADE_SAMPLING) + 1
			end

			for i = startIndex, math.floor(percent * BLADE_SAMPLING) do
				local per = i / BLADE_SAMPLING
				local newPts = {}
				local polygon = {}
				local angle = (avatarBlade.angle2 - avatarBlade.angle1) * (per * BLADE_SCALE + 1 - BLADE_SCALE) + avatarBlade.angle1
				local radius = (avatarBlade.distance2 - avatarBlade.distance1) * per + avatarBlade.distance1
				local d1 = nil

				if d1Map[i] then
					d1 = d1Map[i]
				else
					local ranRatio = (BLADE_SAMPLING - i) / BLADE_SAMPLING * 0.05
					d1 = radius * (ranRatio * 2 * math.random() + 1 - ranRatio)
					d1Map[i] = d1
				end

				local pt = {
					math.cos(angle) * d1 * self.scale * direction.scale + avatarBlade.center[1],
					math.sin(angle) * d1 * self.scale + avatarBlade.center[2]
				}

				table.insert(newPts, 1, pt)
				table.insert(polygon, pt)

				if i > 0 then
					local r = 1

					if type(bladeLayer.inRadius) == "number" then
						r = bladeLayer.inRadius
					elseif type(bladeLayer.inRadius) == "function" then
						r = bladeLayer.inRadius()
					end

					local d2 = radius * ((BLADE_SAMPLING - i) / BLADE_SAMPLING * r + 1 - r)
					local pt = {
						math.cos(angle) * d2 * self.scale * direction.scale + avatarBlade.center[1],
						math.sin(angle) * d2 * self.scale + avatarBlade.center[2]
					}

					table.insert(newPts, 1, pt)
					table.insert(polygon, pt)
				end

				if prePts then
					for j, v in ipairs(prePts) do
						table.insert(polygon, v)
					end

					table.insert(polygonStack, polygon)
				end

				prePts = newPts
			end

			self.preBladePts[layer] = prePts

			for i, v in ipairs(polygonStack) do
				self:addBladePolygon(v, {
					discount = 1 - i / #polygonStack,
					color = bladeLayer.color,
					layer = layer
				})
			end
		end
	end
end

function Unit:addBladePolygon(polygon, params)
	if not self.bladePolygons then
		self.bladePolygons = {}
	end

	table.insert(self.bladePolygons, {
		count = BLADE_TIME,
		polygon = polygon,
		params = params
	})

	if #self.bladePolygons == 1 then
		MapFrameManager.startLoop(self, self.bladePolygonLoop)
	end
end

function Unit:getBladeColor(i, params, alpha)
	local fillColor = nil

	if params and params.color then
		local colorArr = params.color
		fillColor = cc.c4f(colorArr[1] / 255, colorArr[2] / 255, colorArr[3] / 255, alpha)
	else
		fillColor = cc.c4f(1, 1, 1, alpha)
	end

	return fillColor
end

function Unit:bladePolygonLoop(frame, passed, sharp, elapsed_time)
	local removeCount = 0

	for i, obj in ipairs(self.bladePolygons) do
		if obj.node then
			obj.node:removeSelf()

			obj.node = nil
		end

		obj.count = obj.count - 1

		if obj.count > 0 then
			local count = obj.count

			if obj.params and obj.params.discount then
				count = count - obj.params.discount
			end

			local alpha = count / BLADE_TIME

			if obj.params and obj.params.alpha then
				alpha = alpha * obj.params.alpha
			end

			local fillColor = self:getBladeColor(obj.params.layer, obj.params, alpha)
			local polygonNode = display.newPolygon(obj.polygon, {
				borderWidth = 0,
				fillColor = fillColor
			})
			local x, y = self:getPosition()

			polygonNode:setPosition(x, y)
			self.map.highLayer:addChild(polygonNode, self:getLocalZOrder())

			obj.node = polygonNode
		else
			removeCount = removeCount + 1
		end
	end

	for i = 1, removeCount do
		table.remove(self.bladePolygons, 1)
	end

	if #self.bladePolygons == 0 then
		MapFrameManager.stopLoop(self, self.bladePolygonLoop)

		self.bladePolygons = nil
	end
end

function Unit:clearBladePolygon()
	MapFrameManager.stopLoop(self, self.bladePolygonLoop)

	if self.bladePolygons then
		for i, obj in ipairs(self.bladePolygons) do
			if obj.node then
				obj.node:removeSelf()

				obj.node = nil
			end
		end

		self.bladePolygons = nil
	end
end

function Unit:getAvatarKey()
	local str = nil

	if self.spineName then
		str = "@" .. self.spineName
	else
		str = self.modelName
	end

	if self.avatarStack ~= nil then
		for layer, clip in pairs(self.avatarMap) do
			if AVATAR_LAYERS[layer] == AVATAR_TYPE.VECTOR then
				if self:checkAvatarVector(layer) then
					str = str .. "-" .. clip.animationName
				end
			else
				str = str .. "-" .. clip.modelName
			end
		end
	end

	return str
end

function Unit:playNext()
	if not self.bladeDisabled and self.avatarBlade then
		self:makeBlade()
	end

	Unit.super.playNext(self)
end

function Unit:setFrame(action, direction, frame)
	local _action = action
	local _frame = frame
	action, direction, frame = Unit.super.setFrame(self, action, direction, frame)
	local selfZ = self:getZ()

	if self.avatarStack and self.avatarStack[action] then
		local layerMap = self.avatarStack[action][direction.d + 1][frame]

		if layerMap then
			for layer, clip in pairs(self.avatarMap) do
				clip.angle = self.angle

				if AVATAR_LAYERS[layer] == AVATAR_TYPE.VECTOR then
					if self:checkAvatarVector(layer) then
						local anima = clip

						if layerMap[layer] then
							local vectorInfo = self:getAvatarVector(_action, direction.d + 1, _frame, layer)

							if not self.currentVectorInfo then
								self.currentVectorInfo = {}
							end

							self.currentVectorInfo[layer] = vectorInfo

							if vectorInfo then
								anima:setVisible(true)
								anima:setLocalZOrder(-layerMap[layer])

								local x = vectorInfo.x * direction.scale * self.scale * self.exScale
								local y = -vectorInfo.y * self.scale * self.exScale + selfZ * self.scale * self.exScale

								anima:setPosition(x, y)

								local sx = 1
								local sy = 1

								if vectorInfo.sx and vectorInfo.sy then
									sx = vectorInfo.sx / 100
									sy = vectorInfo.sy / 100

									anima:setInnerScale(sx, sy)
								end

								local animaAction = "idle"

								if not empty(vectorInfo.action) then
									animaAction = vectorInfo.action
								end

								anima:setAction(animaAction)
								anima:setMirror(direction.scale == -1)

								local rotation = vectorInfo.a

								if direction.scale == -1 then
									rotation = 180 - vectorInfo.a
								end

								rotation = rotation + 90

								anima:setRotation(rotation)

								if vectorInfo.blade == 1 then
									self:setBladeInfo(vectorInfo, action, direction, frame, layer, anima)
								else
									self:clearBladeInfo()
								end
							else
								anima:setVisible(false)
							end
						else
							anima:setVisible(false)
						end
					end
				else
					if global.tutouCheck then
						print("$$$ tutouCheck", clip:hasAction(action), action, layer, layerMap[layer], self.type, self.modelName)
					end

					if clip:hasAction(action) then
						clip:setFrame(action, direction, frame)

						if layerMap[layer] then
							clip:setVisible(true)
							clip:setLocalZOrder(-layerMap[layer])
						else
							clip:setVisible(false)
						end
					else
						clip:setVisible(false)
					end
				end
			end

			if layerMap[0] then
				self.bmp:setLocalZOrder(-layerMap[0])
			end
		end
	end

	return action, direction, frame
end

function Unit:getSnapshot()
	local snapshoot = display.newNode()

	snapshoot:setCascadeColorEnabled(true)
	snapshoot:setCascadeOpacityEnabled(true)

	local snap = display.newSprite(self.bmp:getSpriteFrame())

	snap:setAnchorPoint(self.bmp:getAnchorPoint())
	snap:setScaleX(self.bmp:getScaleX())
	snap:setScaleY(self.bmp:getScaleY())

	local x, y = self.bmp:getPosition()

	snap:setPosition(x, y)
	snapshoot:addChild(snap, self.bmp:getLocalZOrder())

	if self.avatarStack ~= nil then
		for layer, clip in pairs(self.avatarMap) do
			if clip:isVisible() then
				local snap = nil

				if clip.animationName then
					snap = display.newNode()

					snap:setCascadeOpacityEnabled(true)

					local bmp = display.newSprite(clip.bmp:getSpriteFrame())

					bmp:setAnchorPoint(clip.bmp:getAnchorPoint())

					local x, y = clip.bmp:getPosition()

					bmp:setPosition(x, y)
					bmp:setScaleX(clip.bmp:getScaleX())
					bmp:setScaleY(clip.bmp:getScaleY())
					snap:addChild(bmp)
					snap:setRotation(clip:getRotation())
					snap:setScaleX(clip:rawGetScaleX())
					snap:setScaleY(clip:rawGetScaleY())

					local x, y = clip:getPosition()

					snap:setPosition(x, y)
				else
					snap = display.newSprite(clip.bmp:getSpriteFrame())

					snap:setAnchorPoint(clip.bmp:getAnchorPoint())
					snap:setScaleX(clip.bmp:getScaleX())
					snap:setScaleY(clip.bmp:getScaleY())

					local x, y = clip.bmp:getPosition()

					snap:setPosition(x, y)
				end

				snapshoot:addChild(snap, clip:getLocalZOrder())
			end
		end
	end

	return snapshoot
end

function Unit:jump(dest, speed, height, callback, minTime, onUpdate)
	self:stopMove()

	local distance = math.sqrt(math.pow(dest.y - self.y, 2) + math.pow(dest.x - self.x, 2))

	if distance > 1 then
		self.angle = math.atan2(dest.y - self.y, dest.x - self.x)
	end

	minTime = minTime or 10
	local startardRange = 300
	local distance = math.sqrt(math.pow(dest.y - self.y, 2) + math.pow(dest.x - self.x, 2))
	local frameTime = math.floor(distance / speed)

	if frameTime < minTime then
		frameTime = (minTime - frameTime) / 2 + frameTime
		distance = frameTime * speed
	end

	self.jumpData = {
		from = {
			x = self.x,
			y = self.y
		},
		to = dest,
		height = height,
		countTotal = frameTime,
		count = frameTime,
		callback = callback,
		onUpdate = onUpdate
	}

	if height > 0 then
		height = height * math.pow(distance / startardRange, 0.2) / 5
		local gravity = height / (frameTime / 2)
		self.jumpData.gravity = gravity
		self.jumpData.zSpeed = -math.pow(frameTime, 2) * gravity / 2 / frameTime
	elseif height == -1 then
		self.jumpData.initZ = self.z
	end

	self.moving = true

	MapFrameManager.startLoop(self, self.jumpLoop)

	local nextTile = self.map:mapToTile(dest.x, dest.y)

	if self.size == 1 then
		nextTile:setOccupied(self)

		self.preOccupiedTiles = {
			nextTile
		}
	else
		self.preOccupiedTiles = {}

		for i = nextTile.x, nextTile.x + self.size - 1 do
			for j = nextTile.y, nextTile.y + self.size - 1 do
				local tile = self.map:getTile(i, j)

				if tile then
					tile:setOccupied(self)
					table.insert(self.preOccupiedTiles, tile)
				end
			end
		end
	end

	return frameTime
end

function Unit:jumpLoop(frame, passed, sharp)
	if self.paused then
		return
	end

	self.jumpData.count = self.jumpData.count - passed

	if self.jumpData.gravity then
		self.z = self.z - self.jumpData.zSpeed * passed
		self.jumpData.zSpeed = self.jumpData.zSpeed + self.jumpData.gravity * sharp
	elseif self.jumpData.height == -1 then
		self.z = self.jumpData.initZ * self.jumpData.count / self.jumpData.countTotal
	end

	local overCallback, customCallback = nil
	local onUpdate = self.jumpData.onUpdate
	local count = self.jumpData.count
	local countTotal = self.jumpData.countTotal

	if self.jumpData.count <= 0 then
		self.x = self.jumpData.to.x
		self.y = self.jumpData.to.y
		self.z = 0

		self:clearPreOccupiedTiles()

		overCallback = self.jumpData.callback
		customCallback = self.jumpData.customCallback

		self:stopJump()
	else
		local jumpPercent = (self.jumpData.countTotal - self.jumpData.count) / self.jumpData.countTotal
		self.x = self.jumpData.from.x + (self.jumpData.to.x - self.jumpData.from.x) * jumpPercent
		self.y = self.jumpData.from.y + (self.jumpData.to.y - self.jumpData.from.y) * jumpPercent
	end

	self:draw()

	if not self.jumpNoRetile then
		self:retile()
	end

	self:setAvatarZ()

	if onUpdate then
		onUpdate(count, countTotal)
	end

	if overCallback then
		overCallback()
	end

	if customCallback then
		customCallback()
	end
end

function Unit:stopJump()
	MapFrameManager.clearTimeout(self.jumpWalkTimeoutID)
	MapFrameManager.stopLoop(self, self.jumpLoop)

	self.jumpData = nil
	self.moving = false
end

function Unit:setJumpCallback(callback)
	if self.jumpData then
		self.jumpData.customCallback = callback

		return true
	end

	return false
end

function Unit:setJumpWalkCallback(callback)
end

function Unit:isJumping()
	return self.jumpData ~= nil
end

function Unit:removeFromMap()
	Unit.super.removeFromMap(self)

	if self.preOccupiedTiles then
		for i = 1, #self.preOccupiedTiles do
			self.preOccupiedTiles[i]:clearOccupied(self)
		end

		self.preOccupiedTiles = nil
	end
end

function Unit:go(x, y, occupiedCheckUnit)
	if self.active ~= true then
		if global.debugGoFail then
			Log.debug("Unit:go failure self.active")
		end

		return
	end

	if self.jumpData then
		if global.debugGoFail then
			Log.debug("Unit:go failure self.jumpData")
		end

		return
	end

	local endTile = self.map:mapToTile(x, y)

	if not endTile then
		return
	end

	x, y = self:fixPt(x, y)
	self.desPoint = {
		x = x,
		y = y
	}
	local startTile = self.map:mapToTile(self)

	if startTile == endTile then
		local distance = math.sqrt(math.pow(y - self.y, 2) + math.pow(x - self.x, 2))

		if distance < 1 then
			if global.debugGoFail then
				Log.debug("Unit:go failure the same position")
			end

			self:stop(20)

			return
		end
	end

	local path = self.map:findPath(startTile, endTile, self.walkLevel, self.size, nil, occupiedCheckUnit or self)
	local result = self:movePath(path, nil, occupiedCheckUnit)

	return result
end

function Unit:goToUnitByMHD(unit, mhdRange)
	local function checkRange(tile)
		if math.abs(tile.y - unit.tile.y) + math.abs(tile.x - unit.tile.x) <= mhdRange then
			return true
		end

		return false
	end

	local path = self.map:findPath(self.tile, unit.tile, self.walkLevel, self.size, checkRange, self)

	if path then
		return self:goPath(path)
	else
		return false
	end
end

function Unit:getGoTime(path)
	path = path or self.path

	if path and self.speed > 0 then
		if self.moveType == 1 then
			local time = self:getActionTotalFrameTime("walk")
			local interval = math.max(0, math.floor(self.map.ptPerTile / self.speed - time))

			return (time + interval) * #path
		else
			local distance = self:getPathDistance(path)

			return math.ceil(distance / self.speed)
		end
	end

	return 0
end

function Unit:getPathDistance(path)
	local distance = 0
	local prePos = {
		x = self.x,
		y = self.y
	}

	for i = 1, #path do
		local x, y = self.map:tileToMap(path[i])
		local curPos = {
			x = x,
			y = y
		}
		distance = distance + math.sqrt(math.pow(prePos.y - curPos.y, 2) + math.pow(prePos.x - curPos.x, 2))
		prePos = curPos
	end

	return distance
end

function Unit:goPath(path, alwaysWalkable)
	if self.jumpData then
		return
	end

	local desTile = path[#path]

	if not desTile then
		if self.isPlayer then
			Log.debug("goPath failed desTile:", debug.traceback())
		end

		return false
	end

	local x, y = self.map:tileToMap(desTile)
	self.desPoint = {
		x = x,
		y = y
	}
	local result = self:movePath(path, alwaysWalkable)

	if not result and self.isPlayer then
		Log.debug("goPath failed result:", result)
	end

	return result
end

function Unit:fixPt(x, y)
	local tile = self.map:mapToTile(x, y)

	if not tile then
		return x, y
	end

	local sampleX, sampleY = self.map:tileToMap(tile)
	local preBlock = self.isBlock
	self.isBlock = false

	if self.map.config.pathfinding.smoothLevel < 2 then
		x = sampleX
		y = sampleY
	else
		if self.map:isLegalTile(tile.x - 1, tile.y) then
			if x < sampleX and not self.map:getTile(tile.x - 1, tile.y):getWalkable(self.walkLevel) then
				x = sampleX
			end
		else
			x = sampleX
		end

		if self.map:isLegalTile(tile.x + 1, tile.y) then
			if sampleX < x and not self.map:getTile(tile.x + 1, tile.y):getWalkable(self.walkLevel) then
				x = sampleX
			end
		else
			x = sampleX
		end

		if self.map:isLegalTile(tile.x, tile.y - 1) then
			if y < sampleY and not self.map:getTile(tile.x, tile.y - 1):getWalkable(self.walkLevel) then
				y = sampleY
			end
		else
			y = sampleY
		end

		if self.map:isLegalTile(tile.x, tile.y + 1) then
			if sampleY < y and not self.map:getTile(tile.x, tile.y + 1):getWalkable(self.walkLevel) then
				y = sampleY
			end
		else
			y = sampleY
		end

		if self.map:isLegalTile(tile.x - 1, tile.y - 1) and x < sampleX and y < sampleY and not self.map:getTile(tile.x - 1, tile.y - 1):getWalkable(self.walkLevel) then
			x = sampleX
			y = sampleY
		end

		if self.map:isLegalTile(tile.x - 1, tile.y + 1) and x < sampleX and sampleY < y and not self.map:getTile(tile.x - 1, tile.y + 1):getWalkable(self.walkLevel) then
			x = sampleX
			y = sampleY
		end

		if self.map:isLegalTile(tile.x + 1, tile.y + 1) and sampleX < x and sampleY < y and not self.map:getTile(tile.x + 1, tile.y + 1):getWalkable(self.walkLevel) then
			x = sampleX
			y = sampleY
		end

		if self.map:isLegalTile(tile.x + 1, tile.y - 1) and sampleX < x and y < sampleY and not self.map:getTile(tile.x + 1, tile.y - 1):getWalkable(self.walkLevel) then
			x = sampleX
			y = sampleY
		end
	end

	self.isBlock = preBlock

	return x, y
end

function Unit:reMovePath()
	if self.moving then
		self:stopMove()

		if self.speed > 0 and self.path and #self.path > 0 then
			local pathFinishedCallback = self.pathFinishedCallback
			local result = self:movePath(self.path, alwaysWalkable)

			if result then
				self.pathFinishedCallback = pathFinishedCallback
			end
		end
	end
end

function Unit:movePath(path, alwaysWalkable, occupiedCheckUnit)
	if self.speed <= 0 then
		if global.debugGoFail then
			Log.debug("Unit:movePath failure self.speed<=0", self.speed)
		end

		return false
	end

	self.pathFinishedCallback = nil
	self.path = path
	self.alwaysWalkable = alwaysWalkable

	if #path > 0 then
		table.remove(path, 1)

		if #path <= 1 then
			self:moveSection(self.desPoint.x, self.desPoint.y, alwaysWalkable, occupiedCheckUnit)
		else
			local x, y = self.map:tileToMap(path[1])

			self:moveSection(x, y, alwaysWalkable, occupiedCheckUnit)
		end

		return true
	end

	if global.debugGoFail then
		Log.debug("Unit:movePath failure #path<=0", #path)
	end

	return false
end

function Unit:getNextWalkable(nextTile, occupiedCheckUnit)
	local walkable = nextTile:getWalkable(self.walkLevel, occupiedCheckUnit or self)

	return walkable
end

function Unit:getNextCanMove(nextTile, preTile, alwaysWalkable, occupiedCheckUnit)
	local nextCanMove = true
	local newTiles = {}

	if self.size == 1 then
		nextCanMove = alwaysWalkable or self:getNextWalkable(nextTile, occupiedCheckUnit)

		if not nextCanMove then
			-- Nothing
		end
	else
		local dirtyX = nextTile.x - preTile.x
		local dirtyY = nextTile.y - preTile.y
		local minX = nextTile.x
		local maxX = nextTile.x + self.size - 1
		local minY = nextTile.y
		local maxY = nextTile.y + self.size - 1

		if dirtyX > 0 then
			local limit = math.max(minX, maxX - dirtyX + 1)

			for i = limit, maxX do
				for j = minY, maxY do
					local tile = self.map:getTile(i, j)

					if not alwaysWalkable and not self:getNextWalkable(tile, occupiedCheckUnit) then
						nextCanMove = false

						break
					end

					table.insert(newTiles, tile)
				end

				if not nextCanMove then
					break
				end
			end

			maxX = limit - 1
		elseif dirtyX < 0 then
			local limit = math.min(maxX, minX - dirtyX - 1)

			for i = minX, limit do
				for j = minY, maxY do
					local tile = self.map:getTile(i, j)

					if not alwaysWalkable and not self:getNextWalkable(tile, occupiedCheckUnit) then
						nextCanMove = false

						break
					end

					table.insert(newTiles, tile)
				end

				if not nextCanMove then
					break
				end
			end

			minX = limit + 1
		end

		if nextCanMove then
			if dirtyY > 0 then
				local limit = math.max(minY, maxY - dirtyY + 1)

				for j = limit, maxY do
					for i = minX, maxX do
						local tile = self.map:getTile(i, j)

						if not alwaysWalkable and not self:getNextWalkable(tile, occupiedCheckUnit) then
							nextCanMove = false

							break
						end

						table.insert(newTiles, tile)
					end

					if not nextCanMove then
						break
					end
				end
			elseif dirtyY < 0 then
				local limit = math.min(maxY, minY - dirtyY - 1)

				for j = minY, limit do
					for i = minX, maxX do
						local tile = self.map:getTile(i, j)

						if not alwaysWalkable and not self:getNextWalkable(tile, occupiedCheckUnit) then
							nextCanMove = false

							break
						end

						table.insert(newTiles, tile)
					end

					if not nextCanMove then
						break
					end
				end
			end
		end
	end

	return nextCanMove, newTiles
end

function Unit:moveSection(x, y, alwaysWalkable, occupiedCheckUnit)
	if self.speed <= 0 then
		return
	end

	if self.preOccupiedTiles then
		for i = 1, #self.preOccupiedTiles do
			self.preOccupiedTiles[i]:clearOccupied(self)
		end

		self.preOccupiedTiles = nil
	end

	local nextTile = self.map:mapToTile(x, y)
	local preTile = self.map:mapToTile(self.x, self.y)
	local nextCanMove, newTiles = self:getNextCanMove(nextTile, preTile, alwaysWalkable, occupiedCheckUnit)

	if nextCanMove then
		self.moveAngle = math.atan2(y - self.y, x - self.x)

		if y ~= self.y or x ~= self.x then
			self.angle = self.moveAngle
		end

		local distance = math.sqrt(math.pow(y - self.y, 2) + math.pow(x - self.x, 2))
		local t = self.map:mapToTile(x, y)

		if self.moveType == 1 then
			if self:isJumping() then
				self.moving = false

				return
			end

			local mapX, mapY = self.map:tileToMap(nextTile)
			local time = self:getActionTotalFrameTime("walk")
			local jumpSpeed = distance / time
			local interval = math.max(0, math.floor(self.map.ptPerTile / self.speed - time))

			local function afterJump()
				if self.path ~= nil and #self.path > 1 then
					local function nextSectionAfterJump()
						if self.path then
							table.remove(self.path, 1)
						end

						local moved = false

						if not self.path or #self.path <= 1 then
							if self.desPoint then
								self:moveSection(self.desPoint.x, self.desPoint.y)

								moved = true
							end
						else
							self:moveSection(self.map:tileToMap(self.path[1]))

							moved = true
						end

						if not moved then
							self.moving = false
						end
					end

					MapFrameManager.clearTimeout(self.jumpWalkTimeoutID)

					if interval == 0 then
						nextSectionAfterJump()
					else
						self.moving = true
						self.jumpWalkTimeoutID = MapFrameManager.setTimeout(nextSectionAfterJump, interval)
					end
				else
					self:stop(3)
				end
			end

			self.jumpWalkLockTime = MapFrameManager.getFrame() + time + interval

			if distance == 0 then
				self:stopJump()
				afterJump()
			else
				self:jump({
					x = x,
					y = y
				}, jumpSpeed, 10, afterJump)
				self:setAction("walk", 1, function ()
					self:setAction("idle")
				end)
			end
		else
			local stepLeft = 0

			if self.moveData ~= nil and self.moveData.stepLeft ~= nil then
				stepLeft = self.moveData.stepLeft
			end

			self.moveData = {
				step = stepLeft,
				maxStep = distance / self.speed,
				startPoint = {
					x = self.x,
					y = self.y
				}
			}

			self:setAction("walk")
			MapFrameManager.startLoop(self, self.moveLoop)

			self.moving = true
		end

		if self.size == 1 then
			nextTile:setOccupied(self)

			self.preOccupiedTiles = {
				nextTile
			}
		else
			for i = 1, #newTiles do
				newTiles[i]:setOccupied(self)
			end

			self.preOccupiedTiles = newTiles
		end

		self:dispatchEvent({
			name = "move_section",
			preTile = preTile,
			nextTile = nextTile
		})
	else
		self:onPathFinished()
		self:stop(2)
	end
end

function Unit:checkTileCenter()
	local x, y = self.map:tileToMap(self.tile)
	local distance = math.sqrt(math.pow(y - self.y, 2) + math.pow(x - self.x, 2))

	return distance < 1
end

function Unit:moveToTileCenter()
	if self.speed <= 0 then
		return
	end

	local x, y = self.map:tileToMap(self.tile)

	if self.preOccupiedTiles then
		for i = 1, #self.preOccupiedTiles do
			self.preOccupiedTiles[i]:clearOccupied(self)
		end

		self.preOccupiedTiles = nil
	end

	local distance = math.sqrt(math.pow(y - self.y, 2) + math.pow(x - self.x, 2))

	if distance < 1 then
		self:stop(4)
	else
		self.moveAngle = math.atan2(y - self.y, x - self.x)
		self.angle = self.moveAngle
		local stepLeft = 0

		if self.moveData ~= nil and self.moveData.stepLeft ~= nil then
			stepLeft = self.moveData.stepLeft
		end

		self.moveData = {
			step = stepLeft,
			maxStep = distance / self.speed,
			startPoint = {
				x = self.x,
				y = self.y
			}
		}
		self.path = nil

		self:setAction("walk")
		MapFrameManager.startLoop(self, self.moveLoop)

		self.desPoint = {
			x = x,
			y = y
		}
		self.moving = true
	end
end

function Unit:moveLoopCheck(nextTile, preTile)
	return true
end

function Unit:moveLoop(frame, passed, sharp)
	if self.paused then
		return
	end

	if self.speed <= 0 then
		return
	end

	local moveData = self.moveData
	local step = math.min(moveData.step + passed, moveData.maxStep)
	local x = moveData.startPoint.x + math.cos(self.moveAngle) * self.speed * step
	local y = moveData.startPoint.y + math.sin(self.moveAngle) * self.speed * step

	if self.tile then
		local tile = self.map:mapToTile(x, y)

		if not self:moveLoopCheck(tile, self.tile) then
			self:reMovePath()

			return
		end
	end

	self.x = x
	self.y = y

	self:draw()
	self:retile()

	if moveData.maxStep <= step then
		moveData.stepLeft = moveData.step + passed - moveData.maxStep

		if self.path ~= nil and #self.path > 1 then
			table.remove(self.path, 1)

			if #self.path <= 1 then
				self:moveSection(self.desPoint.x, self.desPoint.y)
			else
				self:moveSection(self.map:tileToMap(self.path[1]))
			end
		else
			self:stop(3)
			self:onPathFinished()
		end
	else
		moveData.step = step
	end
end

function Unit:setPathFinishedCallback(callback)
	self.pathFinishedCallback = callback
end

function Unit:onPathFinished()
	local pathFinishedCallback = self.pathFinishedCallback

	if pathFinishedCallback then
		pathFinishedCallback()
	end

	self.pathFinishedCallback = nil
end

function Unit:stopSection()
	self.path = nil
end

function Unit:stop(code)
	MapFrameManager.clearTimeout(self.jumpWalkTimeoutID)

	if self.moving then
		self:setAction("idle")
		MapFrameManager.stopLoop(self, self.moveLoop)

		self.moveData = nil
		self.moving = false

		self:clearPreOccupiedTiles()
	end
end

function Unit:stopMove()
	MapFrameManager.clearTimeout(self.jumpWalkTimeoutID)
	MapFrameManager.stopLoop(self, self.moveLoop)

	self.moveData = nil
	self.moving = false

	self:clearPreOccupiedTiles()
end

function Unit:clearPreOccupiedTiles()
	if self.preOccupiedTiles then
		for i = 1, #self.preOccupiedTiles do
			self.preOccupiedTiles[i]:clearOccupied(self)
		end

		self.preOccupiedTiles = nil
	end
end

function Unit:faceTo(obj)
	if not obj or not obj.x then
		return
	end

	local distance = math.sqrt(math.pow(obj.y - self.y, 2) + math.pow(obj.x - self.x, 2))

	if distance > 1 then
		self.angle = self:getAngle(obj)
	end
end

function Unit:faceToTile(tile)
	local mapX, mapY = self.map:tileToMap(tile)

	self:faceTo({
		x = mapX,
		y = mapY
	})
end

function Unit:say(str, frameTime, style, offset)
	self:removeSay(true)

	local ballon = display.newNode()

	ballon:setCascadeOpacityEnabled(true)

	local xSpace = 20
	local ySpace = 10
	local _style = {
		size = 20,
		outline = 0,
		offsetY = 2,
		color = cc.c4b(79, 55, 42, 255)
	}

	if style then
		for k, v in pairs(style) do
			_style[k] = v
		end
	end

	local text, ubbMap = Ubb.parse(str)
	local label, labels, labelWidth, labelHeight = nil

	if text == str then
		local _label, _labelWidth, _labelHeight = UIManager.createLabel(0, 4, 0, 0, str, _style)
		labelWidth = _labelWidth
		labelHeight = _labelHeight
		label = _label
	else
		local len = utf8.len(text)
		local textArray = {}
		local styleArray = {}
		local defaultStyle = _style
		local style = ObjUtil.copy(defaultStyle)

		for i = 1, len do
			Ubb.style(ubbMap[i], style, defaultStyle)
			table.insert(textArray, utf8.sub(text, i, i))
			table.insert(styleArray, Style.getTTFStyle(style))
		end

		local flag = {
			width = 0,
			height = 0,
			y = 3,
			x = 0
		}
		local _labels, lines, _labelWidth, _labelHeight = UIManager.createLabelGroup(flag, textArray, styleArray, {
			yspace = 15,
			align = Style.left_in_center,
			valign = Style.vtop
		})
		labelWidth = _labelWidth
		labelHeight = _labelHeight
		labels = _labels
	end

	local border = display.newScale9Sprite("#map_assets_say_ballon")

	border:setCascadeOpacityEnabled(true)

	local tail = display.newSprite("#map_assets_say_ballon_tail")
	local size = border:getContentSize()

	border:setCapInsets(cc.rect(20, 20, 2, 2))

	local w = math.max(labelWidth + xSpace, 60)
	local h = math.max(labelHeight + ySpace, 40)

	border:setContentSize(cc.size(w, h))
	tail:setAnchorPoint(cc.p(0.5, 1))
	tail:setPosition(w / 2 + 10, 5)
	border:addChild(tail)
	ballon:addChild(border)

	if text == str then
		ballon:addChild(label)
	else
		for i, label in ipairs(labels) do
			ballon:addChild(label)
		end
	end

	if self.map then
		self.map.highLayer:addChild(ballon)
	else
		self:addChild(ballon)
	end

	self.sayBallon = {
		ballon = ballon,
		border = border,
		width = labelWidth + xSpace,
		height = labelHeight + ySpace,
		offset = offset
	}

	if self.map then
		self:refreshSayBallon(self.drawX, self.drawY)
	else
		self.sayBallon.ballon:setPosition(0, self.totalHeight + self.sayBallon.height / 2 + 5)
	end

	ballon:setOpacity(0)
	transition.fadeTo(ballon, {
		time = 0.2,
		opacity = 255
	})

	if frameTime and frameTime > 0 then
		if self.map then
			self.sayBallon.closeFunc = MapFrameManager.setTimeout(function ()
				self:removeSay()
			end, frameTime, self)
		else
			self.sayBallon.closeFunc = Looper.setTimeout(function ()
				self:removeSay()
			end, frameTime, self)
		end
	end
end

function Unit:refreshSayBallon(drawX, drawY)
	if not self.map then
		return
	end

	if self.sayBallon then
		local sayBallon = self.sayBallon
		local ballonY = -drawY + self:getTotalHeight()
		local selfAngle = MathUtil.angleWithinPI(self.angle)

		if sayBallon.offset == nil or sayBallon.angle ~= selfAngle then
			sayBallon.angle = selfAngle

			if selfAngle <= math.pi / 4 and selfAngle >= -math.pi / 4 * 3 then
				sayBallon.border:setScaleX(1)
			else
				sayBallon.border:setScaleX(-1)
			end
		end

		local x = drawX
		local y = ballonY + sayBallon.height / 2 + self.z + 5 + (self.zOffset or 0) * global.map.config.scale.unit

		if sayBallon.offset then
			x = x + sayBallon.offset.x
			y = y + sayBallon.offset.y
		end

		sayBallon.ballon:setPosition(x, y)
		sayBallon.ballon:setLocalZOrder(drawY)
	end
end

function Unit:removeSay(noEasing)
	if self.sayBallon then
		local sayBallon = self.sayBallon
		self.sayBallon = nil

		if sayBallon.closeFunc then
			if self.map then
				MapFrameManager.clearTimeout(sayBallon.closeFunc)
			else
				Looper.clearTimeout(sayBallon.closeFunc)
			end
		end

		local ballon = sayBallon.ballon

		if noEasing then
			ballon:removeSelf()
		else
			transition.fadeTo(ballon, {
				time = 0.2,
				opacity = 0,
				onComplete = function ()
					ballon:removeSelf()
				end
			})
		end
	end
end

function Unit:isSaying()
	return self.sayBallon ~= nil
end

function Unit:setBmpY()
	Unit.super.setBmpY(self)

	local selfZ = self:getZ()

	if self.effects then
		for effectName, obj in pairs(self.effects) do
			local effectY = -self.drawY

			if obj.overhead then
				effectY = effectY + self.height
			end

			if obj.clip.layer == 0 and not obj.overhead then
				obj.clip:setPosition(self.drawX, effectY)
			else
				obj.clip:setPosition(self.drawX, effectY + selfZ * obj.clip.scale)
			end

			obj.clip:setLocalZOrder(self.drawY + (obj.zOffset or 0))

			if obj.spines then
				for i, spineObj in ipairs(obj.spines) do
					local effectY = -self.drawY

					if spineObj.overhead then
						effectY = effectY + self.height
					end

					if spineObj.clip.layer == 0 and not spineObj.overhead then
						spineObj.clip:setPosition(self.drawX, effectY - spineObj.clip.yoff)
					else
						spineObj.clip:setPosition(self.drawX, effectY + selfZ * spineObj.clip.scale - spineObj.clip.yoff)
					end

					spineObj.clip:setLocalZOrder(self.drawY + (spineObj.clip.zOffset or 0))
				end
			end
		end
	end

	if self.last_effects then
		for effectName, obj in pairs(self.last_effects) do
			local effectY = -self.drawY

			if obj.overhead then
				effectY = effectY + self.height
			end

			if obj.clip.layer == 0 and not obj.overhead then
				obj.clip:setPosition(self.drawX, effectY)
			else
				obj.clip:setPosition(self.drawX, effectY + selfZ * obj.clip.scale)
			end

			obj.clip:setLocalZOrder(self.drawY + (obj.zOffset or 0))

			if obj.spines then
				for i, spineObj in ipairs(obj.spines) do
					local effectY = -self.drawY

					if spineObj.overhead then
						effectY = effectY + self.height
					end

					if spineObj.clip.layer == 0 and not spineObj.overhead then
						spineObj.clip:setPosition(self.drawX, effectY - spineObj.clip.yoff)
					else
						spineObj.clip:setPosition(self.drawX, effectY + selfZ * spineObj.clip.scale - spineObj.clip.yoff)
					end

					spineObj.clip:setLocalZOrder(self.drawY + (spineObj.clip.zOffset or 0))
				end
			end
		end
	end

	for tag, ui in pairs(self.additionalUI) do
		ui:setPosition(self.drawX, -self.drawY + selfZ)
		ui:setLocalZOrder(self.drawY)
	end

	self:refreshSayBallon(self.drawX, self.drawY)
end

function Unit:setAvatarZ(frame)
	local direction = nil
	local selfZ = self:getZ()

	for layer, clip in pairs(self.avatarMap) do
		if AVATAR_LAYERS[layer] == AVATAR_TYPE.VECTOR then
			if self:checkAvatarVector(layer) then
				direction = direction or self:getDirection()
				local vectorInfo = nil

				if self.currentVectorInfo and self.currentVectorInfo[layer] then
					vectorInfo = self.currentVectorInfo[layer]
				else
					vectorInfo = self:getAvatarVector(self.action, direction.d + 1, frame or self.frame, layer)
				end

				if vectorInfo then
					clip:setPosition(vectorInfo.x * direction.scale * self.scale * self.exScale, -vectorInfo.y * self.scale * self.exScale + selfZ * self.scale * self.exScale)
				end
			end
		else
			clip.z = selfZ

			clip:setBmpY()
		end
	end
end

function Unit:setOpacity(opacity)
	Unit.super.setOpacity(self, opacity)

	for layer, clip in pairs(self.avatarMap) do
		clip:setOpacity(opacity)
	end

	if self.effects then
		for effectName, obj in pairs(self.effects) do
			obj.clip:setOpacity(opacity)
		end
	end

	if self.last_effects then
		for effectName, obj in pairs(self.last_effects) do
			obj.clip:setOpacity(opacity)
		end
	end
end

function Unit:getMugshot()
	local action = "idle"
	local direction = self:getDirection(0)
	local layerModels = {}

	table.insert(layerModels, {
		model = self.modelName,
		z = -layerMap[0]
	})

	if self.avatarStack ~= nil then
		local layerMap = self.avatarStack[action][direction.d + 1][frame]

		for layer, clip in pairs(self.avatarMap) do
			if layer ~= 3 and clip:hasAction(action) then
				table.insert(layerModels, {
					model = clip.modelName,
					z = -layerMap[layer]
				})
			end
		end
	end

	local mugshotNode = display.newNode()

	for i = 1, #layerModels do
		local layerObj = layerModels[i]
		local clip = Clip.new()

		clip:loadModel(layerObj.model)
		clip:stopPlay()
		mugshotNode:addChild(clip, layerObj.z)
	end

	return mugshotNode
end

function Unit:addColor(tag, colorArr)
	if not self.colorStack then
		self.colorStack = {}
	end

	if not self.colorStack[tag] then
		for i = 1, #colorArr do
			colorArr[i] = tonumber(colorArr[i])
		end

		self.colorStack[tag] = colorArr

		self:updateColor()
	end
end

function Unit:removeColor(tag)
	if not self.colorStack then
		return
	end

	if self.colorStack[tag] then
		self.colorStack[tag] = nil

		self:updateColor()
	end
end

function Unit:updateColor()
	if not self.colorStack then
		return
	end

	local color3b = nil

	if table.nums(self.colorStack) == 0 then
		color3b = cc.c3b(255, 255, 255)
	else
		local color = {
			0,
			0,
			0
		}

		for _, colorArr in pairs(self.colorStack) do
			for i = 1, 3 do
				color[i] = color[i] + colorArr[i]
			end
		end

		local colorCount = table.nums(self.colorStack)

		for i = 1, 3 do
			color[i] = math.round(math.pow(color[i] / colorCount / 255, 1 / colorCount) * 255)
		end

		color3b = cc.c3b(color[1], color[2], color[3])
	end

	self.bmp:setColor(color3b)

	for layer, clip in pairs(self.avatarMap) do
		clip.bmp:setColor(color3b)
	end
end

function Unit:bornEffect()
	if self:hasAction("start") then
		self:setAction("start", 1, function ()
			self:setAction("idle")
		end)
	end

	if not empty(self.data.born_effect) then
		local effectGen = self:getEffectGen()

		if effectGen then
			effectGen:castEffect(self.data.born_effect, self)
		end
	end

	if not empty(self.data.born_static) then
		self.battleData.thinkStartTime = WarMachine.getFrame() + self.data.born_static
	end

	if not empty(self.data.born_type) then
		if self.data.born_type == 1 or self.data.born_type == 2 then
			local effectGen = self:getEffectGen()

			if effectGen then
				effectGen:zmove(0, 300)
				effectGen:fadeTo(0, 0)
				effectGen:fadeTo(15, 255)
			end

			local jumpTime = 30
			local easing = nil

			if self.data.born_type == 1 then
				easing = "inQuad"
			elseif self.data.born_type == 2 then
				easing = "inOutQuad"
			end

			if effectGen then
				effectGen:zmove(jumpTime, 0, easing)
			end

			self.thinkStartTime = math.max(self.thinkStartTime or 0, WarMachine.getFrame()) + jumpTime
			self.godTime = WarMachine.getFrame() + jumpTime
		elseif self.data.born_type == 3 or self.data.born_type == 4 then
			local borderTiles = WarMachine.getBorderTiles()
			local tiles = {}

			for i, tile in ipairs(borderTiles) do
				if tile:isEmpty() then
					table.insert(tiles, tile)
				end
			end

			if #tiles > 0 then
				local tile = tiles[math.random(1, #tiles)]
				local mapX, mapY = self.map:tileToMap(tile)
				local effectGen = self:getEffectGen()

				if effectGen then
					effectGen:fadeTo(0, 0)
					effectGen:fadeTo(15, 255)
				end

				local centerTile = WarMachine.getCenterTile()

				local function findBestDig(neiboursInArea)
					local bestDistance, bestTile = nil

					for i, tile in ipairs(neiboursInArea) do
						local distance = math.sqrt(math.pow(centerTile.x - tile.x, 2) + math.pow(centerTile.y - tile.y, 2))

						if not bestTile or distance < bestDistance then
							bestTile = tile
							bestDistance = distance
						end
					end

					return bestTile
				end

				local function checkUnit()
					return true
				end

				Map.NO_BORDER = true
				local path = self.map:digPath(tile, self.walkLevel, self.size, 3, WarMachine.getAreaTileMap(), checkUnit, nil, findBestDig, self.warRandom)
				Map.NO_BORDER = nil

				if #path > 0 then
					self:draw(mapX, mapY, true)

					local tile = path[#path]
					local x, y = self.map:tileToMap(tile)

					self:setAction("walk")

					local jumpTime = self:jump(cc.p(x, y), 8, 25, function ()
						self:setAction("idle")
					end)
					self.thinkStartTime = math.max(self.thinkStartTime or 0, WarMachine.getFrame()) + jumpTime * 2
					self.godTime = WarMachine.getFrame() + jumpTime * 2
				end
			end
		end
	end
end

function Unit:enterTile(tile)
	tile:addUnit(self)
end

function Unit:leaveTile(tile)
	tile:removeUnit(self)
end

function Unit:refreshVisible(force)
	local visibleChanged = Unit.super.refreshVisible(self, force)

	if visibleChanged then
		if self.effects then
			for effectName, obj in pairs(self.effects) do
				obj.clip:setVisible(self.visible)
			end
		end

		if self.last_effects then
			for effectName, obj in pairs(self.last_effects) do
				obj.clip:setVisible(self.visible)
			end
		end
	end
end

function Unit:clone(class)
	local cloneClip = Unit.super.clone(self, class or Unit)

	for layer, clip in pairs(self.avatarMap) do
		if AVATAR_LAYERS[layer] == AVATAR_TYPE.VECTOR then
			if self:checkAvatarVector(layer) then
				cloneClip:setAvatar(clip.animationName, layer)
			end
		else
			cloneClip:setAvatar(clip.modelName, layer)
		end
	end

	self:cloneAction(cloneClip)

	return cloneClip
end

function Unit:openSkillSelect(params, isFriend)
	local newSprite = self:openFoot("skill_pointer")

	if newSprite then
		newSprite:setColor(cc.c3b(255, 97, 0))
		newSprite:setOpacity(200)

		local scale = newSprite:getScaleX()

		newSprite:setScale(scale * 1.5)
		transition.scaleTo(newSprite, {
			time = 0.1,
			easing = "sineOut",
			scale = scale
		})

		local effect = self:addLastingEffect(MiscConfig.effect_targetMark, 0)

		effect:playNext()
	end

	local snapshoot = self:getSnapshot()

	if isFriend then
		Shader.custom(snapshoot, "add_red_1")
	else
		Shader.custom(snapshoot, "add_1")
	end

	local x, y = self:getPosition()

	snapshoot:setPosition(x, y)
	self:getParent():addChild(snapshoot)
	snapshoot:setLocalZOrder(self:getLocalZOrder() + 1)

	self.skillSelectSnapshoot = snapshoot

	Looper.startLoop(self, self.snapshootShining)
	self:dispatchEvent({
		name = "select",
		value = true,
		params = params
	})
end

function Unit:snapshootShining(frame, passed, sharp)
	local interval = 16
	local opacity = 0
	local n = math.floor(frame / interval)
	local std = math.pow(interval / 2, 2)

	if n % 2 == 0 then
		opacity = (-math.pow(frame - interval / 2 - n * interval, 2) + std) / std
	else
		opacity = (math.pow(frame - interval / 2 - n * interval, 2) - std) / std
	end

	opacity = (opacity + 1) * 100 + 20

	self.skillSelectSnapshoot:setOpacity(opacity)
end

function Unit:closeSkillSelect(params)
	self:closeFoot("skill_pointer")
	self:removeLastingEffect(MiscConfig.effect_targetMark)

	if self.skillSelectSnapshoot then
		Looper.stopLoop(self, self.snapshootShining)
		self.skillSelectSnapshoot:removeSelf()

		self.skillSelectSnapshoot = nil
	end

	self:dispatchEvent({
		name = "select",
		value = false,
		params = params
	})
end

Unit.footsZOrders = {
	skill_pointer = 100
}

function Unit:openFoot(assetName)
	if not self.footsMap then
		self.footsMap = {}
	end

	local newSprite = nil

	if self.footsMap[assetName] == nil then
		local sprite = display.newSprite("#map_assets_" .. assetName)

		sprite:setScale(self:getFootWidth() / self.map.ptPerTile * 1.2)
		self.map.lowLayer:addChild(sprite, Unit.footsZOrders[assetName])

		self.footsMap[assetName] = sprite

		self:draw()

		newSprite = sprite
	end

	return newSprite
end

function Unit:closeFoot(assetName)
	if self.footsMap then
		if self.footsMap[assetName] then
			local sprite = self.footsMap[assetName]

			sprite:removeSelf()

			self.footsMap[assetName] = nil
		end

		if table.nums(self.footsMap) == 0 then
			self.footsMap = nil
		end
	end
end

function Unit:onExit()
	MapFrameManager.clearLoop(self)

	if not app.sceneChanging then
		self:clearBlade()
		self:clearEffect()
		self:removeSay()
		self:removeFromMap()

		if self.footsMap then
			for assetName, sprite in pairs(self.footsMap) do
				sprite:removeSelf()
			end

			self.footsMap = nil
		end
	end

	Unit.super.onExit(self)
end

return Unit
