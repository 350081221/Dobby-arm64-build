local UI_base = import("..UI_base")
local Weakpoint = class("Weakpoint", UI_base)

function Weakpoint:ctor(maxTime, maxValue)
	Weakpoint.super.ctor(self, "com_weakpoint")

	self.maxTime = maxTime
	self.maxValue = maxValue

	self:init()
end

function Weakpoint:close(isBreak, onComplete)
	self:setColor(cc.c3b(255, 255, 255))

	local circle = self:getComponentByTag("circle")
	local core = self:getComponentByTag("core")
	local _break = self:getComponentByTag("break")
	local weak = self:getComponentByTag("weak")

	transition.stopTarget(self)

	if isBreak then
		circle:setVisible(false)
		core:setVisible(false)
		weak:setVisible(false)

		if self.cdPolygon then
			self.cdPolygon:setVisible(false)
		end

		_break:setVisible(true)
		self:setOpacity(0)
		self:setScale(10)
		transition.fadeTo(self, {
			time = 0.05,
			opacity = 255
		})
		transition.scaleTo(self, {
			easing = "sineIn",
			scale = 2,
			time = 0.05,
			onComplete = function ()
				transition.scaleTo(self, {
					easing = "sineOut",
					scale = 2,
					time = 0.3,
					onComplete = function ()
						transition.moveTo(self, {
							time = 0.1,
							x = self:getPositionX() + 20,
							y = self:getPositionY() + 50
						})
						transition.scaleTo(self, {
							time = 0.1,
							scale = 0
						})
						transition.fadeTo(self, {
							time = 0.1,
							opacity = 0,
							onComplete = onComplete
						})
					end
				})
			end
		})
	else
		transition.scaleTo(self, {
			easing = "sineIn",
			scale = 0,
			time = 0.1,
			onComplete = onComplete
		})
	end
end

function Weakpoint:init()
	self:initUI()
	self:setScale(0)
	transition.scaleTo(self, {
		easing = "sineOut",
		scale = 1,
		time = 0.1
	})
end

function Weakpoint:initUI()
	local circle = self:getComponentByTag("circle")
	self.width = circle.width
	self.height = circle.height

	self:setContentSize(cc.size(self.width, self.height))
	self:setAnchorPoint(cc.p(0.5, 0.5))

	local core = self:getComponentByTag("core")

	core:setScale(0)

	local _break = self:getComponentByTag("break")

	_break:setVisible(false)

	local weak = self:getComponentByTag("weak")

	weak:setAnchorPoint(cc.p(1, 0))
	weak:setPos(weak.x + weak.width / 2, weak.y - weak.height / 2)
end

function Weakpoint:shock()
	self:setColor(cc.c3b(128, 0, 0))
	transition.stopTarget(self)
	self:setScale(1)
	transition.scaleTo(self, {
		easing = "sineOut",
		scale = 1.5,
		time = 0.05,
		onComplete = function ()
			self:setColor(cc.c3b(255, 255, 255))
			transition.scaleTo(self, {
				easing = "sineIn",
				scale = 1,
				time = 0.1
			})
		end
	})

	local weak = self:getComponentByTag("weak")

	transition.stopTarget(weak)
	weak:setScale(1)
	transition.scaleTo(weak, {
		easing = "sineOut",
		scale = 1.2,
		time = 0.05,
		onComplete = function ()
			transition.scaleTo(weak, {
				easing = "sineIn",
				scale = 1,
				time = 0.1
			})
		end
	})
end

function Weakpoint:setValue(value)
	local core = self:getComponentByTag("core")

	core:setScale(math.min(1, value / self.maxValue))
end

local function makeVertexs(radius, params)
	params = params or {}
	local scale = params.scale or 1
	local segments = params.segments or 32
	local startRadian = params.startAngle or 0
	local endRadian = params.endAngle or math.pi * 2
	local posX = params.x or 0
	local posY = params.y or 0
	local radianPerSegm = 2 * math.pi / segments
	local points = {}

	for i = 1, segments do
		local radii = startRadian + i * radianPerSegm

		if endRadian < radii then
			break
		end

		points[#points + 1] = cc.p(posX + radius * math.cos(radii) * scale, posY + radius * math.sin(radii) * scale)
	end

	return points
end

local circleRadius = 27
local bigColor = {
	244,
	236,
	171
}
local littleColor = {
	236,
	161,
	16
}
local circleColors = {}

function Weakpoint:setTime(time)
	local percent = math.max(0, math.min(1, 1 - time / self.maxTime))
	local circle = self:getComponentByTag("circle")

	if percent > 0 then
		local newPolygon = self.cdPolygon == nil

		if self.cdPolygon then
			self.cdPolygon:setVisible(true)
			self.cdPolygon:clear()
		else
			self.cdPolygon = cc.DrawNode:create()
			local x, y = circle:getPosition()

			self.cdPolygon:setPosition(x, y)
			self.cdPolygon:setRotation(-90)
			self:addChild(self.cdPolygon, -1)
		end

		local pts = makeVertexs(circleRadius, {
			startAngle = 0,
			endAngle = percent * 2 * math.pi
		})

		for i = 1, #pts - 1 do
			if not circleColors[i] then
				local ratio = (pts[i].x + circleRadius) / circleRadius / 2
				local r = (bigColor[1] - littleColor[1]) * ratio + littleColor[1]
				local g = (bigColor[2] - littleColor[2]) * ratio + littleColor[2]
				local b = (bigColor[3] - littleColor[3]) * ratio + littleColor[3]
				local color = cc.c4f(r / 255, g / 255, b / 255, 1)
				circleColors[i] = color
			end

			self.cdPolygon:drawSegment(pts[i], pts[i + 1], 2, circleColors[i])
		end
	elseif self.cdPolygon then
		self.cdPolygon:setVisible(false)
	end
end

return Weakpoint
