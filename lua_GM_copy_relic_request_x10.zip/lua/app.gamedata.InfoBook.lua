local InfoBook = {}
local rawData = nil

function InfoBook.init()
	Connection.listen("book_sync", InfoBook.sync)
end

app:addToAppEnterCall(InfoBook.init)

function InfoBook.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoBook.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("book_query", callback)
end

function InfoBook.onQuery(rcvData)
	rawData = {}

	for i = 1, #rcvData.list do
		local data = rcvData.list[i]
		rawData[data.base_id] = data
	end
end

function InfoBook.sync(data)
	dump(data, "$$$ book_sync")

	for i, syncData in ipairs(data.list) do
		local base_id = syncData.base_id

		if not rawData[base_id] then
			rawData[base_id] = syncData
		else
			for k, v in pairs(syncData) do
				rawData[base_id][k] = v
			end
		end
	end

	ManagerInfo.dataChange("book")
end

function InfoBook.getReward(base_id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "book_get_reward")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("book_get_reward", {
		base_id = base_id
	}, callback)
end

function InfoBook.read(base_id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "book_read")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	local count, total = InfoBook.getProgress(base_id)

	Connection.request("book_read", {
		base_id = base_id,
		read_count = count
	}, callback)
end

function InfoBook.getRecord(base_id, id)
	local data = rawData[base_id]

	if data then
		local section, position = BitUtil.split(30, id)
		local recordNum = data["record_" .. section]

		return BitUtil.getBitByIndex(recordNum, position)
	else
		return 0
	end
end

function InfoBook.getRandomID()
	local abyssLevel = InfoDungeon.getLevel()
	local catalogList = CsvParser.getCsvRaw("books_catalog")
	local arr = {}

	for k, v in pairs(catalogList) do
		local pageList = CsvParser.getCsvRaw(v.file)

		for k1, v1 in pairs(pageList) do
			if v1.abyss_level_min <= abyssLevel and (empty(v1.abyss_level_max) or abyssLevel <= v1.abyss_level_max) and InfoBook.getRecord(v.id, v1.id) == 0 then
				table.insert(arr, {
					base_id = v.id,
					id = v1.id
				})
			end
		end
	end

	if #arr > 0 then
		local obj = arr[math.random(1, #arr)]

		return obj.base_id, obj.id
	end
end

function InfoBook.getCatalog()
	local arr = {}

	for k, v in pairs(rawData) do
		local csv = CsvParser.getCsvData("books_catalog", v.base_id)

		if csv then
			table.insert(arr, v)
		end
	end

	table.sort(arr, function (a, b)
		local rewardedA = InfoBook.isRewarded(a.base_id) and 1 or 0
		local rewardedB = InfoBook.isRewarded(b.base_id) and 1 or 0

		if rewardedA == rewardedB then
			local _, _, isFullA = InfoBook.getProgress(a.base_id)
			local _, _, isFullB = InfoBook.getProgress(b.base_id)
			isFullA = isFullA and 1 or 0
			isFullB = isFullB and 1 or 0

			if isFullA == isFullB then
				return b.create_time < a.create_time
			else
				return isFullB < isFullA
			end
		else
			return rewardedA < rewardedB
		end
	end)

	return arr
end

function InfoBook.getPageList(file)
	local pageList = CsvParser.getCsvList(file)

	return pageList
end

function InfoBook.getProgress(base_id)
	local count = 0
	local total = 0
	local bookCSV = CsvParser.getCsvData("books_catalog", base_id)
	local pages = CsvParser.getCsvRaw(bookCSV.file)

	for k, v in pairs(pages) do
		total = total + 1

		if InfoBook.getRecord(base_id, v.id) > 0 then
			count = count + 1
		end
	end

	return count, total, total <= count
end

function InfoBook.isRewarded(base_id)
	local data = rawData[base_id]

	if not data then
		return false
	end

	return data.reward_already == 1
end

function InfoBook.countRedot()
	local redotCount = 0

	for k, v in pairs(rawData) do
		local csv = CsvParser.getCsvData("books_catalog", v.base_id)

		if csv then
			local count, total, isFull = InfoBook.getProgress(v.base_id)
			local isRewarded = InfoBook.isRewarded(v.base_id)

			if not isRewarded and isFull then
				redotCount = redotCount + 1
			end
		end
	end

	return redotCount
end

return InfoBook
