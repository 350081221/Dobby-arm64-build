local InfoActv = {}
local rawData = {}
local bindData = {}

function InfoActv.init()
	Connection.listen("actv_sync", InfoActv.sync)
end

app:addToAppEnterCall(InfoActv.init)

function InfoActv.query(onSuccess, onFailure)
	rawData = {}
	bindData = {}
	local nextIndex, queryNext = nil

	function queryNext()
		local function callback(rcvData)
			if rcvData.err then
				if onFailure then
					onFailure()
				end
			else
				for i, v in ipairs(rcvData.list) do
					rawData[v.id] = v
				end

				if rcvData.next_index then
					nextIndex = rcvData.next_index

					queryNext()
				else
					if rcvData.bind_list then
						for i, v in ipairs(rcvData.bind_list) do
							bindData[v.actv_id] = bindData[v.actv_id] or {}
							bindData[v.actv_id][v.type] = true
						end
					end

					notify.dispatch("actv_redot")

					if onSuccess then
						onSuccess()
					end
				end
			end
		end

		Connection.request("actv_query", {
			start_index = nextIndex
		}, callback)
	end

	queryNext()
end

function InfoActv.sync(data)
	dump(data, "$$$ InfoActv.sync")

	if data.is_all == 1 then
		rawData = {}

		for i, v in ipairs(data.list) do
			rawData[v.id] = v
		end

		if data.bind_list then
			bindData = {}

			if data.bind_list then
				for i, v in ipairs(data.bind_list) do
					bindData[v.actv_id] = bindData[v.actv_id] or {}
					bindData[v.actv_id][v.type] = true
				end
			end
		end
	else
		for i, v in ipairs(data.list) do
			if not rawData[v.id] then
				rawData[v.id] = v
			else
				for k, v in pairs(v) do
					rawData[v.id][k] = v
				end
			end
		end
	end

	notify.dispatch("actv_redot")
	ManagerInfo.dataChange("actv")
end

function InfoActv.checkIgnore(id)
	local data = rawData[id]

	if data and data.ignore_time then
		local day = Time.getDay(data.ignore_time or 0)
		local nowDay = Time.getDay()

		print("$$$ checkIgnore", day, nowDay)

		return nowDay < day + 7
	end
end

function InfoActv.setIgnore(id)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("actv_set_ignore", {
		id = id
	}, callback)
end

function InfoActv.get(id)
	return rawData[id]
end

function InfoActv.getTabList()
	local arr = {}
	local nowTime = Time.now()

	for k, v in pairs(rawData) do
		if v.close ~= 1 and v.stime <= nowTime and nowTime < v.etime then
			table.insert(arr, v)
		end
	end

	table.sort(arr, function (a, b)
		return a.id < b.id
	end)

	return arr
end

function InfoActv.getJumpList()
	local arr = {}
	local nowTime = Time.now()
	local abyssLevel = InfoDungeon.getAbyssMaxLevel()

	for k, v in pairs(rawData) do
		if v.close ~= 1 and v.limit_level <= abyssLevel and v.jump == 1 and v.stime <= nowTime and nowTime < v.etime and (v.buy_limit == 0 or v.buy_count < v.buy_limit) then
			table.insert(arr, v)
		end
	end

	table.sort(arr, function (a, b)
		return b.id < a.id
	end)

	return arr
end

function InfoActv.checkBindOpening(actv_id, type)
	if bindData[actv_id] and bindData[actv_id][type] and not empty(actv_id) then
		return InfoActv.checkOpening(actv_id)
	end

	return false
end

function InfoActv.checkBindShopOpening(actv_id, type)
	if bindData[actv_id] and bindData[actv_id][type] and not empty(actv_id) then
		return InfoActv.checkShopOpening(actv_id)
	end

	return false
end

function InfoActv.afterBindOpening(actv_id, type)
	if bindData[actv_id] and bindData[actv_id][type] and not empty(actv_id) then
		return InfoActv.afterOpening(actv_id)
	end

	return false
end

function InfoActv.afterOpening(actv_id)
	local data = rawData[actv_id]

	if not data then
		return false
	end

	local nowTime = Time.now()

	if data.stime <= nowTime and data.etime <= nowTime then
		return true
	else
		return false
	end
end

function InfoActv.checkOpening(actv_id)
	local data = rawData[actv_id]

	if not data then
		return false
	end

	local abyssLevel = InfoDungeon.getAbyssMaxLevel()

	if abyssLevel < data.limit_level then
		return false
	end

	local nowTime = Time.now()

	if data.close == 0 and data.stime <= nowTime and nowTime <= data.etime then
		return true
	else
		return false
	end
end

function InfoActv.checkShopOpening(actv_id)
	local data = rawData[actv_id]

	if not data then
		return false
	end

	local abyssLevel = InfoDungeon.getAbyssMaxLevel()

	if abyssLevel < data.limit_level then
		return false
	end

	local nowTime = Time.now()

	if data.close == 0 and data.stime <= nowTime and nowTime <= data.shop_time then
		return true
	else
		return false
	end
end

function InfoActv.checkViewing(actv_id)
	local data = rawData[actv_id]

	if not data then
		return false
	end

	local abyssLevel = InfoDungeon.getAbyssMaxLevel()

	if abyssLevel < data.limit_level then
		return false
	end

	local nowTime = Time.now()

	if data.close == 0 and data.pre_time <= nowTime and nowTime <= data.shop_time then
		return true
	else
		return false
	end
end

function InfoActv.getViewList()
	local arr = {}

	for k, v in pairs(rawData) do
		if InfoActv.checkViewing(v.id) then
			table.insert(arr, v)
		end
	end

	table.sort(arr, function (a, b)
		return a.id < b.id
	end)

	return arr
end

function InfoActv.getTime(actv_id)
	local data = rawData[actv_id]

	if data then
		return data.stime, data.etime, data.shop_time
	end
end

function InfoActv.getName(actv_id)
	local data = rawData[actv_id]

	if data then
		return Localization.getTextByLang(data.title)
	end

	return ""
end

return InfoActv
