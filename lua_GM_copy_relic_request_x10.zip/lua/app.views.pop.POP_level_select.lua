local POP_level_select = class("POP_level_select", UI_base)

function POP_level_select.open(msg, hintStr, defaultLevel, minLevel, maxLevel, confirmFunc, stepLevel, superMaxLevel, hint2Str, buttonStr)
	local ui = POP_level_select.new("pop_level_select", msg, hintStr, defaultLevel, minLevel, maxLevel, confirmFunc, stepLevel, superMaxLevel, hint2Str, buttonStr)

	PopManager.open(ui)
end

function POP_level_select:ctor(uiName, msg, hintStr, defaultLevel, minLevel, maxLevel, confirmFunc, stepLevel, superMaxLevel, hint2Str, buttonStr)
	POP_level_select.super.ctor(self, uiName, UIManager.BIG_TYPE.POP)

	self.msg = msg
	self.hintStr = hintStr or ""
	self.level = defaultLevel
	self.minLevel = minLevel
	self.maxLevel = maxLevel
	self.confirmFunc = confirmFunc
	self.stepLevel = stepLevel or 1
	self.superMaxLevel = superMaxLevel
	self.hint2Str = hint2Str
	self.buttonStr = buttonStr

	self:init()
end

function POP_level_select:init()
	self:initUI()
	self:refreshLevel()
end

function POP_level_select:refreshLevel()
	local percent = 0

	if self.minLevel < self.maxLevel then
		percent = (self.level - self.minLevel) / (self.maxLevel - self.minLevel)
	end

	self:setScollerProgressByTag("flag_bar", percent)
	self:createLabelOnFlag("flag_msg", StringUtil.replace(self.msg, self.level))

	local bg = self:getComponentByTag("bg")

	self:createLabelOnFlag("flag_hint", StringUtil.replace(self.hintStr, self.level))

	if self.hint2Str then
		local label, labelWidth, labelHeight = self:createLabelOnFlag("flag_hint2", StringUtil.replace(self.hint2Str, self.level), {
			wrap = true,
			valign = Style.vtop
		})
		local offset = labelHeight

		bg:setSize(nil, bg.originalHeight + offset)
		bg:setPos(nil, bg.originalY - offset)

		local bg1 = self:getComponentByTag("bg1")

		bg1:setSize(nil, bg1.originalHeight + offset)
		bg1:setPos(nil, bg1.originalY - offset)

		local confirmPB = self:getComponentByTag("confirm_pb")

		confirmPB:setPos(nil, confirmPB.originalY - offset)
	end
end

function POP_level_select.fixLevel(level, minLevel, maxLevel, superMaxLevel, stepLevel)
	local _maxLevel = maxLevel

	if superMaxLevel then
		_maxLevel = math.min(_maxLevel, superMaxLevel)
	end

	if stepLevel > 1 then
		level = math.round((level - minLevel) / stepLevel) * stepLevel + minLevel

		while _maxLevel < level do
			level = level - stepLevel
		end

		while level < minLevel do
			level = level + stepLevel
		end
	else
		level = math.max(minLevel, math.min(level, _maxLevel))
	end

	return level
end

function POP_level_select:fixStep(level)
	return POP_level_select.fixLevel(level, self.minLevel, self.maxLevel, self.superMaxLevel, self.stepLevel)
end

function POP_level_select:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()
	self:createScrollerByTag("bar", "flag_bar", function (percent, isEnd)
		local level = math.floor((self.maxLevel - self.minLevel) * percent) + self.minLevel
		self.level = self:fixStep(level)

		self:refreshLevel()
	end)

	local addButton = self:getComponentByTag("bt_add")

	addButton:toTouchable()
	addButton:addTap(function ()
		self.level = self:fixStep(self.level + self.stepLevel)

		self:refreshLevel()
	end)
	addButton:setTapGroup("button_click")

	local minusButton = self:getComponentByTag("bt_minus")

	minusButton:toTouchable()
	minusButton:addTap(function ()
		self.level = self:fixStep(self.level - self.stepLevel)

		self:refreshLevel()
	end)
	minusButton:setTapGroup("button_click")

	local confirmPB = self:getComponentByTag("confirm_pb")

	confirmPB:toTouchable()
	confirmPB:setTapGroup("button_click")

	local function handleConfirm()
		local confirmFunc = self.confirmFunc
		local level = self.level

		PopManager.close()

		if confirmFunc ~= nil then
			confirmFunc(level)
		end
	end

	confirmPB:addTap(handleConfirm)

	if self.buttonStr then
		confirmPB:addLabel(self.buttonStr)
	end
end

return POP_level_select
