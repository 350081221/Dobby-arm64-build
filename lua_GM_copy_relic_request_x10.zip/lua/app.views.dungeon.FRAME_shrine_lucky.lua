local FRAME_shrine_lucky = class("FRAME_shrine_lucky", UI_base)

function FRAME_shrine_lucky.open(shrineArr)
	local ui = FRAME_shrine_lucky.new(shrineArr)

	PopManager.open(ui)
end

function FRAME_shrine_lucky:ctor(shrineArr)
	FRAME_shrine_lucky.super.ctor(self, "frame_shrine_lucky", UIManager.BIG_TYPE.POP)

	self.shrineArr = shrineArr

	self:init()
end

function FRAME_shrine_lucky:init()
	self:initUI()
	self.list:setItems(self.shrineArr)
end

function FRAME_shrine_lucky:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	self.list = self:createListOnFlag("flag_list", LIST_shrine_lucky)
end

return FRAME_shrine_lucky
