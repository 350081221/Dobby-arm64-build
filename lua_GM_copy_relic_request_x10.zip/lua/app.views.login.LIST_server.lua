local LIST_server = class("LIST_server", List)

function LIST_server:ctor(rect)
	LIST_server.super.ctor(self, rect)
	self:setSpace(5, 5)
	self:setCellName("cell_server")
	self:setCellSize(cc.size(self.touchRect.width, 70))
	self:setSelectEnabled(true)
end

function LIST_server:onCellInit(ui, data, index)
	if data.empty then
		ui:setVisible(false)

		return
	end

	ui:setVisible(true)
	ui:createLabelOnFlag("flag_name", data.server_name)

	local status, labelObj = WorldUtils.getStatus(data)

	if labelObj then
		ui:createLabelOnFlag("flag_status", labelObj.name, labelObj.style)
	else
		ui:removeLabelOnFlag("flag_status")
	end

	self:onCellSelected(ui, data, self.selectedIndex == index)
end

function LIST_server:onCellSelected(ui, data, _selected)
	local selected = ui:getComponentByTag("selected")

	selected:setVisible(_selected)
end

return LIST_server
