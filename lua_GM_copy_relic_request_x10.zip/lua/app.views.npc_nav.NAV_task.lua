local NAV_base = import(".NAV_base")
local NAV_task = class("NAV_task", NAV_base)

function NAV_task.open(npc, taskData)
	local ui = NAV_task.new(npc, taskData)

	return ui
end

function NAV_task:ctor(npc, taskData)
	self.taskData = taskData
	self.noAddTask = true

	NAV_task.super.ctor(self, npc, "nav_task", true)
end

function NAV_task:init()
	NAV_task.super.init(self)

	local ui = self.buttons[1].ui
	local icon = Animation.new()

	icon:load(InfoTaskQuest.getIconName(self.taskData))

	local iconFlag = ui:getFlagByTag("flag_task_icon")

	icon:setPosition(iconFlag.x + iconFlag.width / 2, iconFlag.y + iconFlag.height / 2)
	icon:setLooper(Looper.core)
	icon:setLastFrameFreeze(10)
	ui:addChild(icon, 300)
end

function NAV_task:onTap(index)
	NAV_task.super.onTap(self, index)

	local npc = self.npc
	local taskData = self.taskData

	if index == 1 then
		if global.player then
			global.player:faceTo(npc)
		end

		local taskCSV = CsvParser.getCsvData("task", taskData.base_id)
		local dungeonID = taskData.dungeon_id
		local mapData = CsvParser.getCsvData("task_quest_map", dungeonID .. "_" .. taskCSV.quest_id)

		if taskData.fin == 0 then
			local function onOpenTask()
				local function onEnter()
					if InfoHero.countTeam() < GameConfig.hero_team_num then
						Alert.open(StringUtil.replace(Localization.getSrcText("队伍不满{1}人"), GameConfig.hero_team_num))

						return
					end

					local function onSuccess(rcvData)
						DungeonScene.enterDungeon(DungeonScene.ENTER_TYPE.NEW, rcvData)
					end

					InfoDungeon.enter(InfoDungeon.TYPE.TASK, taskData, onSuccess)
				end

				local function onReject(_ui)
					InfoTaskQuest.reject(taskData.id, function ()
						InfoTaskQuest.snapshotReset()
						PopManager.closeTo(_ui)
					end)
				end

				local openType = FRAME_task_start.OPEN_TYPE.ENTER

				if taskCSV.type == 1 then
					openType = FRAME_task_start.OPEN_TYPE.ENTER_REJECT
				end

				FRAME_task_start.open(taskData, openType, onEnter, onReject)
			end

			local talk_start = mapData.talk_start

			if empty(talk_start) then
				talk_start = taskCSV.talk_start
			end

			if not empty(talk_start) then
				POP_dialog.open(talk_start, onOpenTask)
			else
				onOpenTask()
			end
		elseif taskData.fin == 1 then
			local function onFinishTask()
				InfoTaskQuest.finish(taskData.id, function (rcvData)
					InfoTaskQuest.removeDataForNPC(npc.baseID)
					npc:removeTask()
					global.player:npcChanged(true)
					notify.dispatch("InfoTaskQuest_snapshot")

					local rewards = rcvData.rewards

					if rewards and #rewards > 0 then
						POP_reward.openMixed(rewards, nil, Localization.getSrcText("任务完成"))
					else
						Alert.open(Localization.getSrcText("任务完成"))
					end
				end)
			end

			local talk_over = mapData.talk_over

			if empty(talk_over) then
				talk_over = taskCSV.talk_over
			end

			if not empty(talk_over) then
				POP_dialog.open(talk_over, onFinishTask)
			else
				onFinishTask()
			end
		end
	end
end

return NAV_task
