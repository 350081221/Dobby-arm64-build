local NAV_base = import(".NAV_base")
local NAV_gladiator_relic = class("NAV_gladiator_relic", NAV_base)

function NAV_gladiator_relic.open(npc, relicIndex)
	local ui = NAV_gladiator_relic.new(npc, relicIndex)

	return ui
end

function NAV_gladiator_relic:ctor(npc, relicIndex)
	self.relicIndex = relicIndex

	NAV_gladiator_relic.super.ctor(self, npc, "nav_gladiator_relic")
end

function NAV_gladiator_relic:init()
	NAV_gladiator.super.init(self)

	local eventData = self.npc.eventData
	local eventInfo = InfoDungeon.getEventInfo(eventData.index)
	local gladiatorCSV = CacheData.chance_getGladiator(self.npc.baseID, eventInfo.fin)

	if not empty(gladiatorCSV.text) then
		self.npc:say(gladiatorCSV.text)
	end
end

function NAV_gladiator_relic:onTap(index)
	NAV_gladiator_relic.super.onTap(self, index)

	local eventData = self.npc.eventData
	local eventIndex = eventData.index

	print("NAV_gladiator_relic:onTap", index, self.npc, self.relicIndex)

	if index == 1 then
		self.npc:openRelic(eventIndex, self.relicIndex)
	end
end

function NAV_gladiator_relic:close(immediately)
	self.npc:removeSay()
	NAV_gladiator_relic.super.close(self, immediately)
end

return NAV_gladiator_relic
