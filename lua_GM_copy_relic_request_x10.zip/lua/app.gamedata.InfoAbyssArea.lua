local InfoAbyssArea = {}
local rawData = {}

function InfoAbyssArea.init()
	Connection.listen("abyss_area_sync", InfoAbyssArea.sync)
end

app:addToAppEnterCall(InfoAbyssArea.init)

function InfoAbyssArea.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoAbyssArea.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("abyss_area_query", callback)
end

function InfoAbyssArea.onQuery(rcvData)
	dump(rcvData, "abyss_area_query")

	rawData = {}

	for i = 1, #rcvData.list do
		local data = rcvData.list[i]
		rawData[data.base_id] = data
	end
end

function InfoAbyssArea.sync(data)
	for i, syncData in ipairs(data.list) do
		local base_id = syncData.base_id

		if not rawData[base_id] then
			rawData[base_id] = syncData
		else
			for k, v in pairs(syncData) do
				rawData[base_id][k] = v
			end
		end
	end

	ManagerInfo.dataChange("abyss_area")
end

function InfoAbyssArea.checkGift(onSuccess, onFailure)
	local worldID = InfoWorld.getAbyssArea()
	local abyssLevel = InfoDungeon.getAbyssMaxLevel()
	local csvRaw = CsvParser.getCsvRaw("abyss_area")
	local ids = {}

	for k, areaCSV in pairs(csvRaw) do
		if not empty(areaCSV.area_gift) then
			local data = rawData[areaCSV.id]

			if not data or data.gift_open_day == 0 then
				local giftCSV = CsvParser.getCsvData("abyss_area_gift", areaCSV.area_gift)
				local onceCSV = CsvParser.getCsvData("once_order", giftCSV.once_order)

				if giftCSV.abyss_area <= worldID and onceCSV.level_min <= abyssLevel then
					table.insert(ids, areaCSV.id)
				end
			end
		end
	end

	dump(ids, "$$$ InfoAbyssArea.checkGift")

	if #ids > 0 then
		local function callback(rcvData)
			dump(rcvData, "abyss_area_gift_check")

			if rcvData.err then
				if onFailure then
					onFailure()
				end
			elseif onSuccess then
				onSuccess()
			end
		end

		Connection.request("abyss_area_gift_check", {
			ids = ids
		}, callback)
	end
end

function InfoAbyssArea.getFirstScore(areaID, neoIndex)
	local scoreColumn = "first_score"

	if neoIndex then
		scoreColumn = "first_score_" .. neoIndex
	end

	if rawData[areaID] then
		return rawData[areaID][scoreColumn]
	end

	return 0
end

local firstAverageCache = {}

function InfoAbyssArea.getFirstAverage(areaID, neoIndex, callback)
	local nowTime = Time.now()
	local code = areaID .. "_" .. (neoIndex or "")

	if firstAverageCache[code] then
		local score = firstAverageCache[code].score
		local time = firstAverageCache[code].time

		if nowTime < time + Time.SECONDS_PER_HOUR then
			callback(score)

			return
		end
	end

	local function _callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			if callback then
				firstAverageCache[code] = {
					time = nowTime,
					score = rcvData.first_score
				}

				callback(firstAverageCache[code].score)
			end

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("abyss_area_first_average", {
		base_id = areaID,
		neo_index = neoIndex
	}, _callback)
end

function InfoAbyssArea.getGift(areaID)
	local worldID = InfoWorld.getAbyssArea()
	local abyssLevel = InfoDungeon.getAbyssMaxLevel()
	local nowDay = Time.getToday()
	local abyss_area_gift_days = CsvParser.getCsvData("config", "abyss_area_gift_days").value
	local areaCSV = CsvParser.getCsvData("abyss_area", areaID)

	if not empty(areaCSV.area_gift) then
		local data = rawData[areaCSV.id]

		if data and data.gift_open_day then
			local dayLeft = abyss_area_gift_days - (nowDay - data.gift_open_day)

			if dayLeft > 0 then
				local giftCSV = CsvParser.getCsvData("abyss_area_gift", areaCSV.area_gift)
				local onceCSV = CsvParser.getCsvData("once_order", giftCSV.once_order)

				if giftCSV.abyss_area <= worldID and onceCSV.level_min <= abyssLevel then
					return giftCSV, onceCSV, dayLeft
				end
			end
		end
	end
end

function InfoAbyssArea.getBossNeoList(areaID)
	local csvList = CsvParser.getCsvList("abyss_neo", nil, {
		area = areaID
	})

	return csvList
end

function InfoAbyssArea.getBossNeoCurrent(areaID)
	local csvList = CsvParser.getCsvList("abyss_neo", nil, {
		area = areaID
	})
	local index = 1
	local currentCSV = csvList[1]

	for i, csv in ipairs(csvList) do
		if InfoAbyssArea.checkNeoOpen(areaID, i) then
			currentCSV = csv
			index = i
		end
	end

	return currentCSV, index
end

function InfoAbyssArea.checkNeoOpen(areaID, index)
	local data = rawData[areaID]

	if data and index <= data.neo_index then
		return true
	end

	return false
end

function InfoAbyssArea.checkNeoPre(areaID, index)
	local neoList = InfoAbyssArea.getBossNeoList(areaID)
	local passedIndex = 1
	local maxLevel = InfoDungeon.getAbyssMaxLevel()

	for i, csv in ipairs(neoList) do
		local abyssCSV = CsvParser.getCsvData("abyss", csv.abyss)

		if abyssCSV.level <= maxLevel then
			passedIndex = i
		else
			break
		end
	end

	return index <= passedIndex
end

function InfoAbyssArea.neoOpen(id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("abyss_area_neo_open", {
		id = id
	}, callback)
end

function InfoAbyssArea.getAkasaLevel(areaID)
	local data = rawData[areaID]

	if data then
		return data.akasa_level
	end

	return 0
end

function InfoAbyssArea.saveAkasaLevel(areaID, level, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "abyss_area_akasa_level")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("abyss_area_akasa_level", {
		base_id = areaID,
		level = level
	}, callback)
end

return InfoAbyssArea
