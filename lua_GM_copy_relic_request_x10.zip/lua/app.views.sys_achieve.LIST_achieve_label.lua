local List = import("...ui.List")
local LIST_achieve_label = class("LIST_achieve_label", List)

function LIST_achieve_label:ctor(rect)
	LIST_achieve_label.super.ctor(self, rect)
	self:setCellName("cell_achieve_label")
	self:setSpace(5, 5)

	self.isBounc = false

	self:setCellSize(cc.size(self.touchRect.width, 90))
	self:setSelectEnabled(true)
end

function LIST_achieve_label:onCellInit(ui, data)
	local csv = data.csv
	local redotCount = data.redot

	ui:createLabelOnFlag("flag_name", csv.text)

	local _selected = ui:getComponentByTag("selected")
	local _unselected = ui:getComponentByTag("unselected")

	_selected:addLabel(csv.text)
	_unselected:addLabel(csv.text)

	local redot = ui:getComponentByTag("redot")

	redot:setVisible(redotCount > 0)
end

function LIST_achieve_label:onCellSelected(ui, data, selected)
	local _selected = ui:getComponentByTag("selected")
	local _unselected = ui:getComponentByTag("unselected")

	_selected:setVisible(selected)
	_unselected:setVisible(not selected)
end

return LIST_achieve_label
