local UILayout = import("..ui.UILayout")
local UI_base = class("UI_base", UILayout)

function UI_base:getBigOffset()
	local bigScale = self:getBigScale()
	local bigX = 0
	local bigY = 0
	local isBig = false

	if bigScale ~= 1 then
		local scale = (1 / bigScale - 1) / 2
		bigX = display.width * scale
		bigY = self:getBigY()
		isBig = true
	end

	return isBig, bigX, bigY
end

function UI_base:setTouchDisableTag(node, tag, enabled)
	if enabled then
		if not node._touchEnabledStateMap then
			node._touchEnabledStateMap = {}
		end

		node._touchEnabledStateMap[tag] = 1
	else
		if node._touchEnabledStateMap then
			node._touchEnabledStateMap[tag] = nil
		end

		if node._touchEnabledStateMap and table.nums(node._touchEnabledStateMap) == 0 then
			node._touchEnabledStateMap = nil
		end
	end

	if node._touchEnabledStateMap then
		node:removeTouchable()
	else
		node:toTouchable()
	end
end

function UI_base:addEnterFrame(name, func)
	if self.enterFrameStack == nil then
		self.enterFrameStack = {}
	end

	self.enterFrameStack[name] = func

	if table.nums(self.enterFrameStack) == 1 then
		self:unscheduleUpdate()
		self:addNodeEventListener(cc.NODE_ENTER_FRAME_EVENT, function (dt)
			self:onEnterFrame(dt)
		end)
		self:scheduleUpdate()
	end
end

function UI_base:removeEnterFrame(name)
	if self.enterFrameStack == nil then
		return
	end

	self.enterFrameStack[name] = nil

	if table.nums(self.enterFrameStack) == 0 then
		self:unscheduleUpdate()
	end
end

function UI_base:clearEnterFrame()
	self.enterFrameStack = nil

	self:unscheduleUpdate()
end

function UI_base:onEnterFrame(dt)
	for name, func in pairs(self.enterFrameStack) do
		func(dt)
	end
end

function UI_base.extendEnterFrame(node)
	node.addEnterFrame = UI_base.addEnterFrame
	node.removeEnterFrame = UI_base.removeEnterFrame
	node.onEnterFrame = UI_base.onEnterFrame
end

function UI_base:delayCall(name, func)
	self:removeEnterFrame(name)
	self:addEnterFrame(name, function ()
		self:removeEnterFrame(name)

		if func then
			func()
		end
	end)
end

function UI_base:safeFunc(func)
	local viewInfo = {
		func = func
	}

	local function onAckMsg(...)
		if viewInfo.func ~= nil then
			local vFunc = viewInfo.func
			viewInfo.func = nil

			return vFunc(...)
		end
	end

	self:addEventListener("cleanup", function (event)
		viewInfo.func = nil
	end)

	return onAckMsg
end

function UI_base:safeListen(target, eventName, listener)
	local handler = target:addEventListener(eventName, listener)

	self:addEventListener("cleanup", function ()
		if target.removeEventListener then
			target:removeEventListener(handler)
		end
	end)

	return handler
end

return UI_base
