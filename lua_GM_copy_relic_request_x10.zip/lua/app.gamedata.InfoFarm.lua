local InfoFarm = {}
local rawData, tileSort, tilePosMap, tilesCount, posGroupMap, groupPosMap, posEventMap, harvestLocked, shopList = nil
local shopRefreshIndex = 0
local currentSortSeed = 0

function InfoFarm.init()
	Connection.listen("farm_sync", InfoFarm.sync)
end

app:addToAppEnterCall(InfoFarm.init)

function InfoFarm.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoFarm.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("farm_query", callback)
end

function InfoFarm.onQuery(rcvData)
	rawData = rcvData

	InfoFarm.makeSort()
end

function InfoFarm.sync(data)
	for k, v in pairs(data) do
		rawData[k] = v
	end

	InfoFarm.makeSort()
	ManagerInfo.dataChange("farm", data)
end

function InfoFarm.resetSort()
	currentSortSeed = rawData.sort_seed
end

function InfoFarm.makeSort()
	local random = Random.new(currentSortSeed)
	local tileSort = {}

	if rawData.sort_arr ~= "" then
		tileSort = string.split(rawData.sort_arr, ",")
	end

	local existMap = {}

	for i, v in ipairs(tileSort) do
		tileSort[i] = tonumber(v)
		existMap[tileSort[i]] = true
	end

	local startIndex = #tileSort + 1
	local posArr = {}

	for i = 1, rawData.tile_num do
		if not existMap[i] then
			table.insert(posArr, i)
		end
	end

	for i = startIndex, rawData.tile_num do
		local pos = table.remove(posArr, random:getInt(1, #posArr))

		table.insert(tileSort, pos)
	end

	tilePosMap = {}

	for i, v in ipairs(tileSort) do
		tilePosMap[v] = i
	end
end

function InfoFarm.harvest(amount, sortArr, harvestArr, onSuccess, onFailure)
	if harvestLocked then
		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end

		harvestLocked = nil
	end

	Connection.request("farm_harvest", {
		amount = amount,
		sort_arr = sortArr,
		harvest_arr = harvestArr
	}, callback)
end

function InfoFarm.putSeed(farmSeed, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "farm_put_seed")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if rawData.tile_num == 0 then
				InfoFarm.checkTileNum()
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("farm_put_seed", {
		farm_seed = farmSeed
	}, callback)
end

function InfoFarm.checkTileNum(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "farm_check_tile_num")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("farm_check_tile_num", callback)
end

function InfoFarm.initTiles()
	if not tilesCount then
		local eventArr = {}
		tilesCount = 0
		local eventList = MapEventManager.getEventByTagArray("npc")
		local npcCSV = InfoBuilding.getBuildingNPC(InfoBuilding.TAG.FARM_TILE)

		if npcCSV then
			local npcID = npcCSV.id

			for i, v in ipairs(eventList) do
				local info = ConfParser.parse(v.info)

				if info.id == npcID then
					tilesCount = tilesCount + 1

					table.insert(eventArr, {
						pos = info.pos,
						event = v
					})
				end
			end
		end

		table.sort(eventArr, function (a, b)
			return a.pos < b.pos
		end)

		local function checkNeibour(a, b)
			if math.abs(a.x - b.x) <= 1 and math.abs(a.y - b.y) <= 1 then
				return true
			end

			return false
		end

		posGroupMap = {}
		groupPosMap = {}
		posEventMap = {}

		if #eventArr > 0 then
			local tileGroupIndex = 1
			local pre = eventArr[1]
			posGroupMap[pre.pos] = tileGroupIndex
			posEventMap[pre.pos] = pre.event
			groupPosMap[1] = {
				pre.pos
			}

			for i, v in ipairs(eventArr) do
				if i > 1 then
					if not checkNeibour(pre.event, v.event) then
						tileGroupIndex = tileGroupIndex + 1
					end

					posGroupMap[v.pos] = tileGroupIndex
					posEventMap[v.pos] = v.event

					if not groupPosMap[tileGroupIndex] then
						groupPosMap[tileGroupIndex] = {}
					end

					table.insert(groupPosMap[tileGroupIndex], v.pos)

					pre = v
				end
			end
		end
	end
end

function InfoFarm.clear(isReconnect)
	tilesCount = nil
	posGroupMap = nil
	groupPosMap = nil
	posEventMap = nil
	harvestLocked = nil

	if isReconnect then
		rawData = nil
		shopList = nil
	end
end

function InfoFarm.isHarvestLocked()
	return harvestLocked
end

function InfoFarm.getData()
	return rawData
end

function InfoFarm.getFarmSeed()
	return rawData.farm_seed
end

function InfoFarm.getFarmTiles()
	local tileNum = rawData.tile_num
	local eventArr = {}
	local eventList = MapEventManager.getEventByTagArray("npc")
	local npcCSV = InfoBuilding.getBuildingNPC(InfoBuilding.TAG.FARM_TILE)

	if npcCSV then
		local npcID = npcCSV.id

		for i, v in ipairs(eventList) do
			local info = ConfParser.parse(v.info)

			if info.id == npcID and info.pos <= tileNum then
				table.insert(eventArr, {
					pos = info.pos,
					event = v
				})
			end
		end
	end

	table.sort(eventArr, function (a, b)
		return a.pos < b.pos
	end)

	local newArr = {}

	for i, v in ipairs(eventArr) do
		table.insert(newArr, v.event)
	end

	return newArr
end

function InfoFarm.getNewSeed()
	local csvList = CsvParser.getCsvList("farm_seed")
	local betterSeed = nil

	for i, v in ipairs(csvList) do
		if rawData.farm_seed < v.id and InfoItem.getNum(v.permit_item) > 0 then
			betterSeed = v.id
		end
	end

	return betterSeed
end

function InfoFarm.getMaxStock()
	local tileNum = rawData.tile_num
	local farm_seed_csv = CsvParser.getCsvData("farm_seed", rawData.farm_seed)
	local farmPerTile = farm_seed_csv.farm_num
	local growTime = farm_seed_csv.grow_time

	return farmPerTile * tileNum, farmPerTile, growTime, farmPerTile / growTime
end

function InfoFarm.countHarvest()
	if not rawData or rawData.farm_seed == 0 or rawData.tile_num == 0 then
		return 0, 0
	end

	local nowTime = Time.now()
	local time_offset = nowTime - rawData.cash_time
	local cashMax, farmPerTile, growTime, speed = InfoFarm.getMaxStock()
	local cash = rawData.cash + farmPerTile * time_offset / growTime
	local speedTime = rawData.speedup_time

	if speedTime > 0 then
		if time_offset < speedTime then
			speedTime = speedTime - time_offset
			cash = cash + farmPerTile * (speedup_time - 1) * time_offset / growTime
		else
			speedTime = 0
			cash = cash + farmPerTile * (speedup_time - 1) * speedTime / growTime
		end
	end

	cash = math.min(math.floor(cash), cashMax)
	local trueCash = math.floor(cash / farmPerTile) * farmPerTile
	speed = math.floor(speed * 3600)

	return trueCash, cashMax, speed
end

local harvestResultMap = {}

function InfoFarm.getHarvestResult(pos)
	if harvestResultMap[pos] then
		return harvestResultMap[pos].time, harvestResultMap[pos].farmPerTile
	else
		return 1
	end
end

function InfoFarm.tryHarvest(pos)
	if harvestLocked then
		return
	end

	if rawData.farm_seed == 0 or rawData.tile_num == 0 then
		return
	end

	InfoFarm.initTiles()

	local cashMax, farmPerTile, growTime = InfoFarm.getMaxStock()
	local group = posGroupMap[pos]
	local groupPosArr = groupPosMap[group]
	local farmInfoCache = {}
	local harvestDelayArr = {}
	local centerX = global.player.x
	local centerY = global.player.y
	local harvestPosMap = {}
	local amount = 0
	local harvestArr = ""
	local farm_seed_csv = CsvParser.getCsvData("farm_seed", rawData.farm_seed)

	for i, pos in ipairs(groupPosArr) do
		local farmInfo, tileSeed = nil

		if farmInfoCache[pos] then
			farmInfo = farmInfoCache[pos].farmInfo
			tileSeed = farmInfoCache[pos].tileSeed
		else
			local _info, _, __, _tileSeed = InfoFarm.getTileInfo(pos)
			farmInfo = _info
			tileSeed = _tileSeed
			farmInfoCache[pos] = {
				farmInfo = farmInfo,
				tileSeed = tileSeed
			}
		end

		if farmInfo.isHarvest then
			local farmRanID = SheetUtil.getString(farm_seed_csv.ran, Random.new(tileSeed))
			amount = amount + farmPerTile
			harvestPosMap[pos] = true
			local event = posEventMap[pos]
			local mapX, mapY = global.map:tileToMap(event.x, event.y)
			local distance = math.sqrt(math.pow(mapY - centerY, 2) + math.pow(mapX - centerX, 2))

			table.insert(harvestDelayArr, {
				pos = pos,
				distance = distance
			})

			if harvestArr ~= "" then
				harvestArr = harvestArr .. ","
			end

			harvestArr = harvestArr .. farmRanID
		end
	end

	table.sort(harvestDelayArr, function (a, b)
		return a.distance < b.distance
	end)

	local nowTime = Time.time()

	for i, v in ipairs(harvestDelayArr) do
		harvestResultMap[v.pos] = {
			index = i,
			time = nowTime + 0.15 * i,
			farmPerTile = farmPerTile
		}
	end

	local newSortArr = {}

	for pos, index in pairs(tilePosMap) do
		local farmInfo = farmInfoCache[pos] or InfoFarm.getTileInfo(pos)
		farmInfoCache[pos] = farmInfo

		if farmInfo.isHarvest and not harvestPosMap[pos] then
			table.insert(newSortArr, pos)
		end
	end

	newSortArr = Random.randomOrder(newSortArr)
	local newSortStr = ""

	for i, v in ipairs(newSortArr) do
		if newSortStr ~= "" then
			newSortStr = newSortStr .. ","
		end

		newSortStr = newSortStr .. v
	end

	if amount > 0 then
		InfoFarm.harvest(amount, newSortStr, harvestArr, onSuccess, onFailure)
	end
end

function InfoFarm.countTiles()
	if not tilesCount then
		InfoFarm.initTiles()
	end

	return tilesCount
end

function InfoFarm.getTileInfo(pos)
	if harvestLocked then
		return nil
	end

	if not rawData then
		return nil
	end

	local index = tilePosMap[pos]
	local info = {}

	if not index then
		info.ready = false
	else
		info.ready = index <= rawData.tile_num
	end

	if info.ready and rawData.farm_seed ~= 0 then
		local trueCash = InfoFarm.countHarvest()
		local cashMax, farmPerTile, growTime = InfoFarm.getMaxStock()

		if index <= rawData.tile_num then
			info.isHarvest = trueCash >= index * farmPerTile
		end
	end

	local farmSeed = rawData.farm_seed
	local tileSeed = currentSortSeed + pos

	return info, farmSeed, index, tileSeed
end

function InfoFarm.getShopLabels()
	return nil
end

function InfoFarm.getShopList(_callback)
	local needQuery = shopList == nil

	if not needQuery and rawData.shop_refresh_time < Time.now() then
		needQuery = true
	end

	if needQuery then
		local function callback(rcvData)
			if rcvData.err then
				-- Nothing
			else
				shopRefreshIndex = shopRefreshIndex + 1
				shopList = rcvData.items

				if _callback then
					_callback(shopList, true)
				end
			end
		end

		Connection.request("farm_shop_list", callback)
	else
		_callback(shopList)
	end
end

function InfoFarm.getShopItems(tabID)
	local itemArr = {}
	local buildingLevel = InfoBuilding.getBuildingLevel(InfoBuilding.TAG.FARM)

	for i, v in ipairs(shopList) do
		local shopCSV = CsvParser.getCsvData("farm_shop", v.shop_id, nil, true)

		if shopCSV and shopCSV.building_level_min <= buildingLevel and buildingLevel <= shopCSV.building_level_max then
			table.insert(itemArr, v)
		end
	end

	table.sort(itemArr, function (a, b)
		return a.shop_id < b.shop_id
	end)

	return itemArr
end

function InfoFarm.getShopCost(itemID)
	local shopCostCache = CacheData.get("InfoFarm_shopCostCache")

	if not shopCostCache then
		shopCostCache = {}
		local csvRaw = CsvParser.getCsvRaw("farm_shop")

		for k, csv in pairs(csvRaw) do
			shopCostCache[csv.product_id] = csv
		end

		CacheData.set("InfoFarm_shopCostCache", shopCostCache)
	end

	local csv = shopCostCache[itemID]

	return csv
end

function InfoFarm.buy(buyList, onSuccess, onFailure)
	local preIndex = shopRefreshIndex

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if rcvData.items then
				for j, item in ipairs(rcvData.items) do
					if preIndex == shopRefreshIndex then
						for i, v in ipairs(shopList) do
							if v.shop_id == item.shop_id then
								for k1, v1 in pairs(item) do
									v[k1] = v1
								end
							end
						end
					end
				end
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("farm_shop_buy", {
		shops = buyList
	}, callback)
end

function InfoFarm.getShopCSV()
	return "farm_shop"
end

function InfoFarm.getCostNeed()
	return nil
end

function InfoFarm.getShopName()
	return "farm"
end

function InfoFarm.getShopTime()
	return rawData.shop_refresh_time, RefreshManager.getNextTime(RefreshManager.TYPE.FARM_SHOP, Time.now())
end

function InfoFarm.getRefreshType()
	return RefreshManager.TYPE.FARM_SHOP
end

return InfoFarm
