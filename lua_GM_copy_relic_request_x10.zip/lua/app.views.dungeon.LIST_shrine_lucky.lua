local List = import("...ui.List")
local LIST_shrine_lucky = class("LIST_shrine_lucky", List)

function LIST_shrine_lucky:ctor(rect)
	LIST_shrine_lucky.super.ctor(self, rect)
	self:setCellName("cell_shrine_lucky")
	self:setSpace(5, 5)
	self:setCellSize(cc.size(self.touchRect.width, 110))
end

function LIST_shrine_lucky:onCellInit(ui, data)
	if not ui.slot then
		local slotFlag = ui:getFlagByTag("flag_slot")
		ui.slot = DropSlot.new(slotFlag, "slot_01")

		ui:addChild(ui.slot, 100)
	end

	local shrineData = CsvParser.getCsvData("shrine", data.id)

	ui:createLabelOnFlag("flag_name", shrineData.name)
	ui:createLabelOnFlag("flag_desc", shrineData.desc)

	if data.life_time then
		ui:replaceLabelOnFlag("flag_life", nil, data.life_time)
	else
		ui:removeLabelOnFlag("flag_life")
	end

	ui.slot:setDrop(DropManager.TYPE.SHRINE, data)
end

return LIST_shrine_lucky
