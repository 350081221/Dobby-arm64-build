local SpineHelper = class("SpineHelper")
local skeletonActionEventTimeCache = {}

function SpineHelper.getSpineEventTime(name, action, eventName)
	if not skeletonActionEventTimeCache[name] then
		skeletonActionEventTimeCache[name] = {}
	end

	if not skeletonActionEventTimeCache[name][action] then
		skeletonActionEventTimeCache[name][action] = {}
	end

	if not skeletonActionEventTimeCache[name][action][eventName] then
		local time = 0
		local jsonFile = getFinalRes("res/spine/" .. name .. "/skeleton.json")
		local jsonData = JsonParser.parse(jsonFile)

		if jsonData and jsonData.animations and jsonData.animations[action] then
			local events = jsonData.animations[action].events

			if events then
				for i, event in ipairs(events) do
					if event.name == eventName then
						time = event.time

						break
					end
				end
			end
		end

		skeletonActionEventTimeCache[name][action][eventName] = time
	end

	return skeletonActionEventTimeCache[name][action][eventName]
end

function SpineHelper.createUI(spineName)
	local data = JsonParser.parse("res/spine_set/" .. spineName .. ".json")
	local skeletons = {}

	for i, v in ipairs(data.spines) do
		local jsonFile = getFinalRes("res/spine/" .. v.name .. "/skeleton.json")
		local atlasFile = getFinalRes("res/spine/" .. v.name .. "/skeleton.atlas")
		local skeleton = sp.SkeletonAnimation:createWithJsonFile(jsonFile, atlasFile)
		skeleton.name = v.name
		skeleton.scale = v.scale
		skeleton.yoff = v.yoff
		skeleton.zOffset = v.zoffset
		skeleton.layer = v.layer

		skeleton:setScale(v.scale)
		skeleton:setAnimation(0, "idle", true)
		table.insert(skeletons, skeleton)
	end

	return skeletons
end

return SpineHelper
