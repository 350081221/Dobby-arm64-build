local NAV_base = import(".NAV_base")
local NAV_exchange_sell = class("NAV_exchange_sell", NAV_base)

function NAV_exchange_sell.open(npc)
	local ui = NAV_exchange_sell.new(npc)

	return ui
end

function NAV_exchange_sell:ctor(npc)
	NAV_exchange_sell.super.ctor(self, npc, "nav_exchange_sell")
end

function NAV_exchange_sell:init()
	NAV_exchange_sell.super.init(self)
end

function NAV_exchange_sell:onTap(index)
	NAV_exchange_sell.super.onTap(self, index)

	if index == 1 then
		if InfoExchange.isApprEmpty() then
			Alert.open(Localization.getSrcText("请先装饰店铺"))

			return
		end

		InfoExchange.getPrice(function ()
			FRAME_exchange_sell.open(self.npc)
		end)
	elseif index == 2 then
		FRAME_appr.open(self.npc)
	elseif index == 3 then
		FRAME_exchange_buy.open(self.npc)
	end
end

return NAV_exchange_sell
