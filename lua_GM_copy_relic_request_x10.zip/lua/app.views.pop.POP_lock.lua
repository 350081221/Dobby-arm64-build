local POP_lock = class("POP_lock", UI_base)

function POP_lock.open()
	print("$$$ POP_lock.open()")

	if not POP_lock.ui then
		POP_lock.ui = POP_lock.new()

		display.getRunningScene():addChild(POP_lock.ui, LayerConfig.lock)
	end
end

function POP_lock.close()
	print("$$$ POP_lock.close()")

	if POP_lock.ui then
		POP_lock.ui:removeSelf()

		POP_lock.ui = nil
	end
end

function POP_lock:ctor()
	POP_lock.super.ctor(self, "pop_lock")
	self:init()
end

function POP_lock:init()
	self:initUI()
end

function POP_lock:initUI()
	local mask = self:getComponentByTag("mask")

	mask:toTouchable()
	mask:setOpacity(0)
end

function POP_lock:onExit()
	POP_lock.super.onExit(self)

	POP_lock.ui = nil
end

return POP_lock
