local InfoCard = {}
local rawData = {}
local cardBaseMap, cardBaseStarMap, cardMaxLevelMap, cardMaxStarMap, cardMaxLimitMap = nil

function InfoCard.init()
	cardBaseMap = {}
	cardBaseStarMap = {}
	cardMaxLevelMap = {}
	cardMaxStarMap = {}
	cardMaxLimitMap = {}
	local csvRaw = CsvParser.getCsvRaw("card_base_exp")

	for k, v in pairs(csvRaw) do
		local code = v.quality .. "_" .. v.limit .. "_" .. v.level
		cardBaseMap[code] = v
		local code = v.quality .. "_" .. v.limit
		cardMaxLevelMap[code] = math.max(cardMaxLevelMap[code] or 0, v.level)
		local code = tostring(v.quality)
		cardMaxLimitMap[code] = math.max(cardMaxLimitMap[code] or 0, v.limit)
	end

	local csvRaw = CsvParser.getCsvRaw("card_base_star")

	for k, v in pairs(csvRaw) do
		local code = v.quality .. "_" .. v.star
		cardBaseStarMap[code] = v
		local code = tostring(v.quality)
		cardMaxStarMap[code] = math.max(cardMaxStarMap[code] or 0, v.star)
	end

	Connection.listen("card_sync", InfoCard.sync)
	Connection.listen("card_sync_remove", InfoCard.syncRemove)
end

app:addToAppEnterCall(InfoCard.init)

function InfoCard.query(onSuccess, onFailure)
	rawData = {}
	local nextIndex, queryNext = nil

	function queryNext()
		local function callback(rcvData)
			if rcvData.err then
				if onFailure then
					onFailure()
				end
			else
				for i, data in ipairs(rcvData.list) do
					if data.base_id ~= 0 then
						rawData[data.id] = data
					end
				end

				if rcvData.next_index then
					nextIndex = rcvData.next_index

					queryNext()
				elseif onSuccess then
					onSuccess()
				end
			end
		end

		Connection.request("card_query", {
			start_index = nextIndex
		}, callback)
	end

	queryNext()
end

function InfoCard.sync(data)
	local changedIdStack = {}

	for i, syncData in ipairs(data.list) do
		if syncData.base_id ~= 0 then
			local id = syncData.id

			if not rawData[id] then
				rawData[id] = syncData
			else
				for k, v in pairs(syncData) do
					rawData[id][k] = v
				end
			end

			changedIdStack[id] = rawData[id]
		end
	end

	ManagerInfo.dataChange("card", changedIdStack)
	notify.dispatch("equip_up_change")
end

function InfoCard.syncRemove(data)
	local teamChanged = false
	local changedIdStack = {}

	for i, id in ipairs(data.list) do
		if rawData[id] then
			changedIdStack[id] = rawData[id]
			rawData[id] = nil
		end
	end

	ManagerInfo.dataChange("card", changedIdStack)
	notify.dispatch("equip_up_change")
end

function InfoCard.getMaxStar(cardInfo)
	local cardCSV = CsvParser.getCsvData("card", cardInfo.base_id)
	local code = tostring(cardCSV.quality)

	return cardMaxStarMap[code] or 1
end

function InfoCard.getMaxLevel(cardInfo)
	local cardCSV = CsvParser.getCsvData("card", cardInfo.base_id)
	local code = cardCSV.quality .. "_" .. cardInfo.level_limit

	return cardMaxLevelMap[code] or 1
end

function InfoCard.getMaxLimit(cardInfo)
	local cardCSV = CsvParser.getCsvData("card", cardInfo.base_id)
	local code = tostring(cardCSV.quality)

	return cardMaxLimitMap[code] or 1
end

function InfoCard.getBase(cardInfo, customLevel)
	customLevel = customLevel or cardInfo.level
	local cardCSV = CsvParser.getCsvData("card", cardInfo.base_id)
	local code = cardCSV.quality .. "_" .. cardInfo.level_limit .. "_" .. customLevel

	return cardBaseMap[code]
end

function InfoCard.getBaseStar(cardInfo, customStar)
	customStar = customStar or cardInfo.star
	local cardCSV = CsvParser.getCsvData("card", cardInfo.base_id)
	local code = cardCSV.quality .. "_" .. customStar

	return cardBaseStarMap[code]
end

function InfoCard.getCardInfo(cardID)
	return rawData[cardID]
end

function InfoCard.getCardBuff(cardInfo)
	local cardCSV = CsvParser.getCsvData("card", cardInfo.base_id)
	local buffArr = SheetUtil.getColumnValueList(cardCSV, "buff_id_")
	local buffStr = buffArr[math.min(#buffArr, cardInfo.star)]
	local arr = {}
	local buffStrArr = string.split(buffStr, ",")

	for i, v in ipairs(buffStrArr) do
		local buffID = tonumber(v)

		table.insert(arr, buffID)
	end

	return arr
end

function InfoCard.getAuraBuffCopy(heroInfo)
	local cardArr = heroInfo.cards or {}
	local allBuffs = {}

	for i, cardInfo in ipairs(cardArr) do
		local cardCSV = CsvParser.getCsvData("card", cardInfo.base_id)

		if cardCSV then
			local buffStr = cardCSV["aura_buff_" .. cardInfo.star]
			local targetStr = cardCSV["aura_target_" .. cardInfo.star]
			local timeStr = cardCSV["aura_time_" .. cardInfo.star]

			if not empty(buffStr) and not empty(targetStr) and not empty(timeStr) then
				local buffArr = string.split(buffStr, ",")
				local targetArr = string.split(targetStr, ",")
				local timeArr = string.split(timeStr, ",")
				local total = math.min(#buffArr, #targetArr, #timeArr)

				for j = 1, total do
					local id = tonumber(buffArr[j])
					local target = tonumber(targetArr[j])
					local time = tonumber(timeArr[j])

					if id and target and time then
						table.insert(allBuffs, {
							id = id,
							target = target,
							time = time
						})
					end
				end
			end
		end
	end

	return allBuffs
end

function InfoCard.getAuraBuff(heroID)
	local cardArr = InfoCard.getCardListOnHero(heroID)
	local allBuffs = {}

	for i, cardInfo in ipairs(cardArr) do
		local cardCSV = CsvParser.getCsvData("card", cardInfo.base_id)

		if cardCSV then
			local buffStr = cardCSV["aura_buff_" .. cardInfo.star]
			local targetStr = cardCSV["aura_target_" .. cardInfo.star]
			local timeStr = cardCSV["aura_time_" .. cardInfo.star]

			if not empty(buffStr) and not empty(targetStr) and not empty(timeStr) then
				local buffArr = string.split(buffStr, ",")
				local targetArr = string.split(targetStr, ",")
				local timeArr = string.split(timeStr, ",")
				local total = math.min(#buffArr, #targetArr, #timeArr)

				for j = 1, total do
					local id = tonumber(buffArr[j])
					local target = tonumber(targetArr[j])
					local time = tonumber(timeArr[j])

					if id and target and time then
						table.insert(allBuffs, {
							id = id,
							target = target,
							time = time
						})
					end
				end
			end
		end
	end

	return allBuffs
end

function InfoCard.checkCardsOnHero(heroID, idMap)
	for id, cardInfo in pairs(rawData) do
		if cardInfo.hero_id == heroID and idMap[cardInfo.id] then
			return true
		end
	end

	return false
end

function InfoCard.checkCardForHero(heroInfo, cardInfo)
	local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)
	local cardCSV = CsvParser.getCsvData("card", cardInfo.base_id)
	local card_class_arr = string.split(cardCSV.class, ",")

	for i, v in ipairs(card_class_arr) do
		if tonumber(v) == heroCSV.class then
			return true
		end
	end
end

function InfoCard.getCardListOnHero(heroID)
	local arr = {}

	if type(heroID) == "table" then
		heroID = heroID.id
	end

	for id, cardInfo in pairs(rawData) do
		if cardInfo.hero_id == heroID and cardInfo.pos > 0 then
			table.insert(arr, cardInfo)
		end
	end

	table.sort(arr, function (a, b)
		return a.pos < b.pos
	end)

	return arr
end

function InfoCard.getCardOnHero(heroID, pos)
	if type(heroID) == "table" and heroID.cards then
		local heroInfo = heroID

		for i, v in ipairs(heroInfo.cards) do
			if v.pos == pos then
				return v
			end
		end
	else
		if type(heroID) == "table" then
			heroID = heroID.id
		end

		for id, cardInfo in pairs(rawData) do
			if cardInfo.hero_id == heroID and cardInfo.pos == pos then
				return cardInfo
			end
		end
	end
end

function InfoCard.cardon(cardID, heroID, pos, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("card_on", {
		hero_id = heroID,
		card_id = cardID,
		pos = pos
	}, callback)
end

function InfoCard.cardoff(cardID, bag_index, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("card_off", {
		card_id = cardID,
		bag_index = bag_index
	}, callback)
end

function InfoCard.getNameDisplay(cardInfo)
	local cardData = CsvParser.getCsvData("card", cardInfo.base_id)
	local name = cardData.name

	return name
end

function InfoCard.getEquipedHero(cardInfo)
	if not empty(cardInfo.hero_id) then
		return InfoHero.getHero(cardInfo.hero_id)
	end
end

function InfoCard.getQuality(cardInfo)
	local cardData = CsvParser.getCsvData("card", cardInfo.base_id)

	return cardData.quality
end

function InfoCard.getAllList(filterFunc, sortFunc)
	local arr = {}

	for id, cardInfo in pairs(rawData) do
		local tempData = {
			type = DropManager.TYPE.CARD,
			info = cardInfo
		}

		if not filterFunc or filterFunc(tempData) then
			table.insert(arr, tempData)
		end
	end

	local function getEquiped(info)
		local equiped = 0
		local heroInfo = InfoCard.getEquipedHero(info)

		if heroInfo then
			equiped = heroInfo.pos

			if equiped > 0 then
				equiped = 100 - heroInfo.pos
			else
				equiped = 1
			end
		end

		return equiped
	end

	local sortMethod = sortFunc or function (a, b)
		local equipedA = getEquiped(a.info)
		local equipedB = getEquiped(b.info)

		if equipedA == equipedB then
			local qualityA = InfoCard.getQuality(a.info)
			local qualityB = InfoCard.getQuality(b.info)

			if qualityA == qualityB then
				if a.info.level == b.info.level then
					if a.info.base_id == b.info.base_id then
						return a.info.id < b.info.id
					else
						return a.info.base_id < b.info.base_id
					end
				else
					return b.info.level < a.info.level
				end
			else
				return qualityB < qualityA
			end
		else
			return equipedB < equipedA
		end
	end

	table.sort(arr, sortMethod)

	return arr
end

function InfoCard.getWareList(filterFunc, sortFunc)
	local arr = {}

	for id, cardInfo in pairs(rawData) do
		if not InfoCard.getEquipedHero(cardInfo) then
			local tempData = {
				type = DropManager.TYPE.CARD,
				info = cardInfo
			}

			if not filterFunc or filterFunc(tempData) then
				table.insert(arr, tempData)
			end
		end
	end

	local sortMethod = sortFunc or function (a, b)
		local qualityA = InfoCard.getQuality(a.info)
		local qualityB = InfoCard.getQuality(b.info)

		if qualityA == qualityB then
			if a.info.level == b.info.level then
				if a.info.base_id == b.info.base_id then
					return a.info.id < b.info.id
				else
					return a.info.base_id < b.info.base_id
				end
			else
				return b.info.level < a.info.level
			end
		else
			return qualityB < qualityA
		end
	end

	table.sort(arr, sortMethod)

	return arr
end

function InfoCard.getMatList(filterFunc, sortFunc)
	local arr = {}

	for id, cardInfo in pairs(rawData) do
		if not InfoCard.getEquipedHero(cardInfo) then
			local tempData = {
				type = DropManager.TYPE.CARD,
				info = cardInfo
			}

			if not filterFunc or filterFunc(tempData) then
				table.insert(arr, tempData)
			end
		end
	end

	local function sortMethod(a, b)
		if a.info.quality == b.info.quality then
			if a.info.base_id == b.info.base_id then
				return a.info.id < b.info.id
			else
				return a.info.base_id < b.info.base_id
			end
		else
			return b.info.quality < a.info.quality
		end
	end

	table.sort(arr, sortMethod)

	return arr
end

function InfoCard.getShowList()
	local arr = {}

	for id, cardInfo in pairs(rawData) do
		local tempData = {
			type = DropManager.TYPE.CARD,
			info = cardInfo
		}

		table.insert(arr, tempData)
	end

	table.sort(arr, function (a, b)
		local cardInfoA = a.info
		local cardInfoB = b.info
		local equipedA = InfoCard.getEquipedHero(cardInfoA) ~= nil and 1 or 0
		local equipedB = InfoCard.getEquipedHero(cardInfoB) ~= nil and 1 or 0

		if equipedA == equipedB then
			if cardInfoA.locked == cardInfoB.locked then
				local qualityA = InfoCard.getQuality(cardInfoA)
				local qualityB = InfoCard.getQuality(cardInfoB)

				if qualityA == qualityB then
					if cardInfoA.level == cardInfoB.level then
						return cardInfoA.id < cardInfoB.id
					else
						return cardInfoB.level < cardInfoA.level
					end
				else
					return qualityB < qualityA
				end
			else
				return cardInfoB.locked < cardInfoA.locked
			end
		else
			return equipedB < equipedA
		end
	end)

	return arr
end

function InfoCard.getExpAdded(cardInfo, exp)
	local cardBase = InfoCard.getBase(cardInfo)
	local maxLevel = InfoCard.getMaxLevel(cardInfo)
	local startLevel = cardInfo.level
	local startExp = cardInfo.exp
	local expLeft = startExp + exp
	local level = startLevel
	local expUpg = cardBase.exp
	local isMax = false

	if maxLevel <= level then
		expLeft = 0
		isMax = true
	end

	while expUpg <= expLeft do
		expLeft = expLeft - expUpg
		level = level + 1

		if maxLevel <= level then
			level = maxLevel
			expLeft = 0
			isMax = true

			break
		end

		local cardBase = InfoCard.getBase(cardInfo, level)
		expUpg = cardBase.exp
	end

	return level, expLeft, expUpg, isMax
end

function InfoCard.levelup(card_id, mats, mats_item, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("card_levelup", {
		card_id = card_id,
		mats = mats,
		mats_item = mats_item
	}, callback)
end

function InfoCard.starup(card_id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("card_starup", {
		card_id = card_id
	}, callback)
end

function InfoCard.limitup(card_id, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("card_limitup", {
		card_id = card_id
	}, callback)
end

function InfoCard.growthup(card_id, mat_card_id, mat_item_id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "card_growthup")

		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess()
		end
	end

	Connection.request("card_growthup", {
		card_id = card_id,
		mat_card_id = mat_card_id,
		mat_item_id = mat_item_id
	}, callback)
end

function InfoCard.getNeedSaveList()
	local arr = {}

	for id, cardInfo in pairs(rawData) do
		if cardInfo.saved ~= 1 then
			local tempData = {
				type = DropManager.TYPE.CARD,
				info = cardInfo
			}

			table.insert(arr, tempData)
		end
	end

	table.sort(arr, function (a, b)
		local cardInfoA = a.info
		local cardInfoB = b.info
		local equipedA = InfoCard.getEquipedHero(cardInfoA) ~= nil and 1 or 0
		local equipedB = InfoCard.getEquipedHero(cardInfoB) ~= nil and 1 or 0

		if equipedA == equipedB then
			if cardInfoA.enhance_level == cardInfoB.enhance_level then
				local qualityA = InfoCard.getQuality(cardInfoA)
				local qualityB = InfoCard.getQuality(cardInfoB)

				if qualityA == qualityB then
					return cardInfoA.id < cardInfoB.id
				else
					return qualityB < qualityA
				end
			else
				return cardInfoB.enhance_level < cardInfoA.enhance_level
			end
		else
			return equipedB < equipedA
		end
	end)

	return arr
end

function InfoCard.getUnsaved()
	local arr = {}

	for id, cardInfo in pairs(rawData) do
		if cardInfo.saved ~= 1 then
			table.insert(arr, cardInfo)
		end
	end

	return arr
end

function InfoCard.count(notEquiped)
	local count = 0

	for id, cardInfo in pairs(rawData) do
		if not notEquiped or not InfoCard.getEquipedHero(cardInfo) then
			count = count + 1
		end
	end

	local card_count_max = CsvParser.getCsvData("config", "card_count_max").value

	return count, card_count_max
end

function InfoCard.lock(cardID, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("card_lock", {
		card_id = cardID
	}, callback)
end

local cardLimitLevelMap = nil

function InfoCard.getLimitByLevel(cardInfo)
	if not cardLimitLevelMap then
		cardLimitLevelMap = {}
		local csvRaw = CsvParser.getCsvRaw("card_base_exp")

		for k, v in pairs(csvRaw) do
			local code = v.quality .. "_" .. v.level
			cardLimitLevelMap[code] = v.limit
		end
	end

	local cardCSV = CsvParser.getCsvData("card", cardInfo.base_id)
	local code = cardCSV.quality .. "_" .. cardInfo.level

	return cardLimitLevelMap[code]
end

function InfoCard.exchange(card_id_1, card_id_2, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "card_exchange")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("card_exchange", {
		card_id_1 = card_id_1,
		card_id_2 = card_id_2
	}, callback)
end

return InfoCard
