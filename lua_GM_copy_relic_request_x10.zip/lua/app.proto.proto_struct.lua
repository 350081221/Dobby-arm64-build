local struct = [[

.package {
	type 0 : integer
	session 1 : integer
}

#服务器信息
.LineData {
	line_id 0 : integer
	line_addr 1 : string
	line_stat 2 : integer     # 0 正常可切换  1 人满了不可以切  2后台设置为忽略不可以切
}

#佣兵信息
.HeroData {
	id 0 : integer
	base_id 1 : integer
	gender 2 : integer
	pos 3 : integer
	level 4 : integer
	exp 5 : integer
	name 6 : string
	body 7 : string
	hair 8 : string

	affix 10 : integer
	star 11 : integer
	seed 12 : integer
	quality 13 : integer
	skill_enc_1 14 : integer
	skill_enc_2 15 : integer
	skill_enc_3 16 : integer
	skill_enc_4 17 : integer
	skill_enc_5 18 : integer
	auto_skill 19 : integer
	hp_seed 20 : integer
	atk_seed 21 : integer
	def_seed 22 : integer
	avatar_hide 23 : string

	locked 30 : integer
	perks 31 : string
	sigil_color 32 : string
}

#道具信息
.ItemData {
	base_id 0 : integer
	num 1 : integer
	growth 2 : integer
	growth_time 3 : integer
}

#道具限量信息
.ItemLimitData {
	base_id 0 : integer
	abyss_drop_count 4 : integer
	abyss_drop_time 5 : integer
}

#装备信息
.EquipData {
	id 0 : integer
	base_id 1 : integer
	hero_id 2 : integer
	ran 3 : integer
	prefix_1 4 : integer
	preran_1 5 : integer
	prefix_2 6 : integer
	preran_2 7 : integer
	prefix_3 8 : integer
	preran_3 9 : integer
	prefix_4 10 : integer
	preran_4 11 : integer
	prefix_5 12 : integer
	preran_5 13 : integer
	suffix_1 14 : integer
	sufran_1 15 : integer
	suffix_2 16 : integer
	sufran_2 17 : integer
	suffix_3 18 : integer
	sufran_3 19 : integer
	suffix_4 20 : integer
	sufran_4 21 : integer
	suffix_5 22 : integer
	sufran_5 23 : integer
	slot 24 : integer
	gem1 25 : integer
	gem2 26 : integer
	gem3 27 : integer
	gem4 28 : integer
	gem5 29 : integer
	gem6 30 : integer
	identified 31 : integer
	saved 32 : integer
	quality 33 : integer
	best_prefix 34 : integer
	best_suffix 35 : integer
	enhance_level 36 : integer
	enhance_fire 37 : integer
	fire 38 : integer
	drop_level 39 : integer
	locked 40 : integer
	illusion 41 : integer
	level 42 : integer
	show_hero_id 43 : integer
	
	dust_id 44 : integer
	dust_level 45 : integer
	dust_sp_attr 46 : integer
	dust_sp_ran 47 : integer

	dust_id_1 51 : integer
	dust_ran_1 52 : integer
	dust_level_1 54 : integer
	dust_exp_1 55 : integer

	dust_id_2 61 : integer
	dust_ran_2 62 : integer
	dust_level_2 64 : integer
	dust_exp_2 65 : integer

	dust_id_3 71 : integer
	dust_ran_3 72 : integer
	dust_level_3 74 : integer
	dust_exp_3 75 : integer

	excellent 80 : integer
	is_new 81 : integer
	suit_excellent 82 : integer
}

#看板任务信息
.QuestData {
	id 0 : integer
	base_id 1 : integer
	dungeon_id 2 : string
	seed 3 : integer
	fin 4 : integer

	reward_item_1 5 : integer
	reward_num_1 6 : integer
	reward_item_2 7 : integer
	reward_num_2 8 : integer
	reward_item_3 9 : integer
	reward_num_3 10 : integer
}

#酒馆佣兵信息
.TavernHeroData {
	hired 0 : integer
	base_id 1 : integer
	gender 2 : integer
	name 3 : string
	body 4 : string
	hair 5 : string
	seed 6 : integer
	affix 7 : integer
	quality 8 : integer
	level 9 : integer
	star 10 : integer
	hash 11 : string
	hp_seed 12 : integer
	atk_seed 13 : integer
	def_seed 14 : integer
}

#背包信息
.BagData {
	bag_index 0 : integer
	type 1 : integer
	item_id 2 : integer
	item_num 3 : integer
	equip_id 4 : integer
	card_id 5 : integer
	sigil_id 6 : integer
	artifact_id 7 : integer
}

#背包拾取信息
.GetBagData {
	bag_index 0 : integer
	type 1 : integer
	item_id 2 : integer
	item_num 3 : integer
	equip_id 4 : integer
	new_equip_index 5 : integer
	card_id 6 : integer
	new_card_index 7 : integer
	sigil_id 8 : integer
	new_sigil_index 9 : integer
	artifact_id 10 : integer
	new_artifact_index 11 : integer
}

#怪物卡信息
.CardData {
	id 0 : integer
	base_id 1 : integer
	hero_id 2 : integer
	pos 3 : integer
	ran 4 : integer
	saved 5 : integer
	level 6 : integer
	level_limit 7 : integer
	exp 8 : integer
	star 9 : integer
	growth_1 10 : integer
	growth_2 11 : integer
	growth_3 12 : integer
	limit_1 13 : integer
	limit_2 14 : integer
	limit_3 15 : integer
	locked 16 : integer
}

#邮件信息（运营邮件）
.MailData {
	id 0 : integer
	title 1 : string
	content 2 : string
	award 3 : string
	stime 4 : integer
	etime 5 : integer
    is_read 6 : integer
    is_award_get 7 : integer
	limit_level 8 : integer
}

#个人邮件信息（系统邮件）
.PersonMailData {
	id 0 : integer
	temp 1 : integer
	temp_values 2 : string
	award 3 : string
	stime 4 : integer
	etime 5 : integer
    is_read 6 : integer
    is_award_get 7 : integer
}

#奖励信息
.RewardData {
	type 0 : integer
	item_id 1 : integer
	item_num 2 : integer
	equip_id 3 : integer
	card_id 4 : integer
	sigil_id 5 : integer
	artifact_id 6 : integer
}



#宠物孵化信息
.PetHatchData {
	pos 0 : integer
	base_id 1 : integer
	start_time 2 : integer
	end_time 3 : integer
	quality 4 : integer
}

#宠物信息
.PetData {
	id 0 : integer
	base_id 1 : integer
	seed 2 : integer
	name 3 : string
	pos 4 : integer
	level 5 : integer
	exp 6 : integer
	food_count_1 7 : integer
	food_time_1 8 : integer
	food_count_2 9 : integer
	food_time_2 10 : integer
	quality 11 : integer
	hp_seed 12 : integer
	atk_seed 13 : integer
	def_seed 14 : integer
	passive_level 15 : integer

	equip_1 21 : integer
	equip_2 22 : integer
	equip_3 23 : integer
	equip_4 24 : integer

	locked 30 : integer
}


#建筑信息
.BuildingData {
	tag 0 : integer
	level 1 : integer
	guided 2 : integer
	plus_1 3 : integer
	plus_2 4 : integer
	plus_3 5 : integer
	plus_4 6 : integer
}

#采集品信息（道中宝箱）
.GatherData {
	gather_id 0 : integer
}

#神龛信息
.ShrineData {
	index 0 : integer
	id 1 : integer
	life_type 2 : integer
	life_time 3 : integer
	seed 4 : integer
}

#NPC任务信息
.TaskQuestData {
	id 0 : integer
	base_id 1 : integer
	dungeon_id 2 : string
	seed 3 : integer
	fin 4 : integer
}

#调律信息
.MirrorData {
	type 0 : integer
	level 1 : integer
}

#战利品信息
.RelicData {
	id 0 : integer
	fin 1 : integer
	time 2 : integer
	is_final 3 : integer
}

#神秘商人信息
.EquipShop {
	index 0 : integer
	id 1 : integer
	fin 2 : integer
}

#功能引导信息
.FunctionData {
	tag 0 : integer
	guided 1 : integer
}

#派遣信息
.TravelData {
	base_id 0 : integer
	start_time 1 : integer
	hour_len 2 : integer
	hero_1 3 : integer
	hero_2 4 : integer
	hero_3 5 : integer
	prob_up 6 : integer
}

#竞技场对手
.ArenaOpp {
	type 0 : integer
	id 1 : integer
	points 2 : integer
	name 3 : string
	snapshot 4 : string
	over 5 : integer
	season 6 : integer
	realPoints 7 : integer
}

#竞技场战斗队伍
.ArenaTeam {
	type 0 : integer
	id 1 : integer
	name 2 : string
	hero_name 3 : string
	copy 4 : string
	pet_name 5 : string
}

#竞技场回放信息
.ArenaReplayList {
	id 0 : integer
	time 1 : integer
	camp 2 : integer
	is_win 3 : integer
	name 4 : string
	arena_type 5 : integer
	arena_id 6 : integer
	pointChange 7 : integer
}

#竞技场自定义阵容信息（读取）
.ArenaFormation {
	custom 0 : integer
	formation 1 : string
}

.ArenaFormationCopy {
	copy 0 : string
	hero_name 1 : string
	pet_name 2 : string
	custom 3 : integer
}


#出售物品信息
.SellData {
	item_id 0 : integer
	item_num 1 : integer
	equip_id 2 : integer
	card_id 3 : integer
	sigil_id 4 : integer
	artifact_id 5 : integer
}

#成就信息
.AchieveData {
	achieve_id 0 : integer
	count 1 : integer
	step 2 : integer
}

#装备信息（拾取）
.InfoEquipData {
	index 0 : integer
	base_id 1 : integer
	ran 2 : integer
	prefix_1 3 : integer
	preran_1 4 : integer
	prefix_2 5 : integer
	preran_2 6 : integer
	prefix_3 7 : integer
	preran_3 8 : integer
	prefix_4 9 : integer
	preran_4 10 : integer
	prefix_5 11 : integer
	preran_5 12 : integer
	suffix_1 13 : integer
	sufran_1 14 : integer
	suffix_2 15 : integer
	sufran_2 16 : integer
	suffix_3 17 : integer
	sufran_3 18 : integer
	suffix_4 19 : integer
	sufran_4 20 : integer
	suffix_5 21 : integer
	sufran_5 22 : integer
	slot 23 : integer
	gem1 24 : integer
	gem2 25 : integer
	gem3 26 : integer
	gem4 27 : integer
	gem5 28 : integer
	gem6 29 : integer
	identified 30 : integer
	quality 31 : integer
	best_prefix	32 : integer
	best_suffix	33 : integer
	drop_level 34 : integer
	drop_rare 35 : integer
	level 36 : integer

	dust_id 44 : integer
	dust_level 45 : integer
	dust_sp_attr 46 : integer
	dust_sp_ran 47 : integer

	dust_id_1 51 : integer
	dust_ran_1 52 : integer
	dust_level_1 54 : integer
	dust_exp_1 55 : integer

	dust_id_2 61 : integer
	dust_ran_2 62 : integer
	dust_level_2 64 : integer
	dust_exp_2 65 : integer

	dust_id_3 71 : integer
	dust_ran_3 72 : integer
	dust_level_3 74 : integer
	dust_exp_3 75 : integer

	saved 79 : integer
	excellent 80 : integer
	is_new 81 : integer
	suit_excellent 82 : integer
}

#道具信息（拾取）
.InfoItemData {
	base_id 0 : integer
	num 1 : integer
}

#怪物卡信息（拾取）
.InfoCardData {
	index 0 : integer
	base_id 1 : integer
	hero_id 2 : integer
	pos 3 : integer
	ran 4 : integer
	saved 5 : integer
	level 6 : integer
	level_limit 7 : integer
	exp 8 : integer
	star 9 : integer
	growth_1 10 : integer
	growth_2 11 : integer
	growth_3 12 : integer
	limit_1 13 : integer
	limit_2 14 : integer
	limit_3 15 : integer
}

#深渊回响信息
.AbyssCallData {
	id 0 : integer
	base_id 1 : integer
	time 2 : integer
	is_read 3 : integer
}

#交易所出售物品信息
.ExchangeData {
	id 0 : integer
	sell_index 1 : integer
	item_id 2 : integer
	item_num 3 : integer
	price 4 : integer
	create_time 5 : integer
	sys_time 6 : integer
	open 7 : integer
}

#交易所购买物品信息
.ExchangeListData {
	open 0 : integer
	type 1 : integer
	id 2 : integer
	item_id 3 : integer
	item_num 4 : integer
	price 5 : integer
	user_name 6 : string
}

#野外副本信息
.WildData {
	spot_id 0 : integer
	star 1 : integer
	star_guide 2 : integer
}

#怪物图鉴信息
.ManualMonsterData {
	base_id 0 : integer
	win_count 1 : integer
	affix_arr 2 : string
	is_new 3 : integer
}

#钓鱼信息
.FishingData {
	id 0 : integer
	base_id 1 : integer
	count 2 : integer
	best_weight 3 : integer
}

#鱼塘信息
.FishingPondData {
	base_id 0 : integer
	amount_count 1 : integer
	amount_time 2 : integer
}

#联机队伍（其他玩家）
.OnlineTeam {
	hero_name 0 : string
	copy 1 : string
}

#通用商品信息
.ShopItem {
	shop_id 0 : integer
	soldout 1 : integer
	sold_time 2 : integer
	actv_id 3 : integer
}

#活动概率提升
.Probup {
	type 0 : integer
	id 1 : integer
	value 2 : integer
}

#活动刷怪
.ActvMonster {
	id 0 : integer
	prob_1000 1 : integer
	num 2 : integer
}

#玩家外观信息
.UserInfo {
	user_id 0 : integer
	nickname 1 : string
	nicklang 2 : string
	head 3 : integer
	head_frame 4 : integer
	abyss_max_level 5 : integer
}

#玩家外观公会信息
.UserUnionInfo {
	union_id 0 : integer				#公会ID
	union_icon 1 : UnionIcon			#公会头像
	union_name 2 : string				#公会名称
	lang 3 : string 					#公会名称和公告 使用的语言
}

#聊天信息
.ChatData {
	index 0 : integer
	user_info 1 : UserInfo
	type 2 : integer
	msg 3 : string
	id 4 : integer
	level 5 : integer
	pack 6 : string
	count 7 : integer
	room_id 8 : integer
	lang 9 : string
	channel 10 : integer

	.UserUnionInfo {
		union_name 2 : string				#公会名称
		lang 3 : string 					#公会名称和公告 使用的语言
	}
	union_info 11 : UserUnionInfo

	poc 20 : integer
}

# 聊天黑名单 玩家结构 
.BlackUserInfo {
	user_info 0 : UserInfo			# --玩家信息
	join_time 1 : integer			# --加入黑名单的时间
}

#联机副本信息
.TowerData {
	type 0 : integer
	reward_count 1 : integer
	reward_time 2 : integer
}

#战中道具使用信息
.ItemUsed {
	item_id 0 : integer
	num 1 : integer
	bag_index 2 : integer
}

#道具商店
.ItemShop {
	type_id 1 : string
	refresh_time 2 : integer
}

#家园信息
.HomeData {
	map_id 0 : integer
	version 1 : integer
	device_str 2 : string
	music_str 3 : string
	name 4 : string
	user_name 5 : string
}

#装备库信息
.ArmoryData {
	id 0 : integer
	armory_index 1 : integer
	hero_class 2 : integer
	name 3 : string

	equip_1 11 : integer
	equip_2 12 : integer
	equip_3 13 : integer
	equip_4 14 : integer

	card 21 : integer
}

#通用图鉴信息
.ManualData {
	type 0 : integer
	base_id 1 : integer
	is_new 2 : integer
	quality 3 : integer
}

#特殊武器图鉴信息
#.ManualWeaponData {
#	base_id 0 : integer
#	add_count 1 : integer
#	is_new 3 : integer
#}

#自定义礼包信息
.MygiftData {
    close 0 : integer
    jump 1 : integer
	id 2 : integer
	rmb_id 3 : integer
	title 4 : string
	page 5 : string
	award 6 : string
	stime 7 : integer
	etime 8 : integer
    limit_level 9 : integer
    buy_limit 10 : integer
    buy_count 11 : integer
    ignore_time 12 : integer
}

#活动信息
.ActvData {
    close 0 : integer
    jump 1 : integer
	id 2 : integer
	title 3 : string
	info 4 : string
	page 5 : string
	banner 6 : string
	pre_time 7 : integer
	stime 8 : integer
	etime 9 : integer
	shop_time 10 : integer
    limit_level 11 : integer
    ignore_time 12 : integer
}

#活动绑定信息
.ActvBindData {
    type 0 : integer
    actv_id 1 : integer
}

#副本队伍信息
.TeamState {
	map_index 0 : integer

	.TrainInfo {
		d 0 : integer
		x 1 : integer
		y 2 : integer
	}
	train_info 1 : TrainInfo

	.TopInfo {
		name 0 : string
		already 1 : *integer
		view 2 : *integer
	}
	top_info 2 : *TopInfo

	.Corpse {
		hero_id 0 : integer
		map_index 1 : integer
		x 2 : integer
		y 3 : integer
		d 4 : integer
	}
	corpse 3 : *Corpse

}

#活动概率提升开启状态
.ProbupData{
	id 0 : integer
	open 1 : integer
	actv_id 2 : integer
}

#尘封副本信息
.DustData {
	base_id 0 : integer
	curr_level 1 : integer
	max_level 2 : integer
	sp_cd 3 : integer
	seed 4 : integer
	speedup_life 5 : integer
	remake_count 6 : integer
	remake_time 7 : integer
	level_time 8 : integer
	season_rewarded 9 : integer
	exp 10 : integer
	boss_level 11 : integer
	boss_daily 12 : integer
	shop_refresh_time 13 : integer

	hero_1 21 : integer
	hero_2 22 : integer
	hero_3 23 : integer

	hero1_1 111 : integer
	hero1_2 112 : integer
	hero2_1 121 : integer
	hero2_2 122 : integer
	hero3_1 131 : integer
	hero3_2 132 : integer
	
	hero_hp1_1 211 : integer
	hero_hp1_2 212 : integer
	hero_hp2_1 221 : integer
	hero_hp2_2 222 : integer
	hero_hp3_1 231 : integer
	hero_hp3_2 232 : integer

	mirror_1 301 : integer
	mirror_2 302 : integer
	mirror_3 303 : integer
	mirror_4 304 : integer
	mirror_5 305 : integer
	mirror_6 306 : integer
}

#尘封配置信息
.DustGM {
	id 0 : integer
	stime 1 : integer
	etime 2 : integer
	pre_etime 3 : integer
}

#通用排行信息
.StdRanking {
	id 1 : integer
	level 2 : integer
	name 3 : string
	lang 4 : string
	head 5 : integer
	head_frame 6 : integer
	snapshot 7 : string
	score 8 : integer
	level_time 9 : integer
	user_id 10 : integer
	points 11 : integer

	best_wave 21 : integer
	best_time 22 : integer
}


#排行信息1
.RankingSeasonData {
	type 0 : integer

	season 11 : integer
	season_time 12 : integer

	first_points 13 : integer
	first_id 14 : integer
	first_name 15 : string
	first_lang 16 : string
	first_head 17 : integer
	first_head_frame 18 : integer
}

#排行信息1
.RankingData {
	type 0 : integer
	season 1 : integer
	season_time 2 : integer
	points 3 : integer
}





# -----------------------自定义活动相关结构----------------------------------
# 每日，周期目标
# full_count 4 : integer
# actv_id_full 5 : integer
# day_count 2 : integer
.ActvAchieveData {
	type 0 : integer
	id 1 : integer
	base_id 2 : integer
	count 3 : integer
	day_time 4 : integer
	actv_id 5 : integer
}

# 每日，周期目标配置
.ActvAchieveConfig {
	.Target {
		id 0 : integer
		num 1 : integer
	}
	.Award {
		id 0 : integer
		num 1 : integer
	}
	
	actv_id 0 : integer
	target 1 : *Target
	award 2 : *Award
}



# 活动怪物
.ActvMonsterData {
	base_id 0 : integer
	day_time 1 : integer
	day_count 2 : integer
	actv_id 3 : integer
}

# 活动怪物配置
.ActvMonsterConfig {
	.Monster {
		id 0 : integer
		prob_1000 1 : integer
		daily_num 2 : integer
	}

	actv_id 0 : integer
	monster 1 : *Monster
}



# 活动累充配置
.ChargeData {
	.Award {
		id 0 : integer
		num 1 : integer
	}
	.Charge {
		pay_100 0 : integer
		award 1 : *Award
	}
	actv_id 0 : integer
	total_pay_100 1 : integer
	gift_record 2 : integer
	list 3 : *Charge
}


# 活动副本
.ActvStageData {
	current 0 : integer
	award_num 1 : integer

	actv_id 2 : integer
	reward_time 3 : integer
	reward_count 4 : integer

	current_level 5 : integer
	passed_level 6 : integer
	passed_actv_id 7 : integer
	
	sp_index 8 : integer
	sp_reward_record 9 : integer
	
	level_time 10 : integer
	level_time_mark 11 : integer

	rewarded 12 : integer
	final_hour 13 : integer

	.Award {
		id 0 : integer
		num 1 : integer
	}
	award 20 : *Award
}


# 活动副本
.ActvRecordData {
	actv_id 0 : integer
	pic 1 : string
	is_recover 2 : integer
	.Item {
		id 0 : integer
		num 1 : integer
	}
	award 3 : *Item
	cost 4 : *Item

	sign_record 11 : integer
	reward_record 12 : integer
}

# 活动轮盘数据
.ActvTurntableData {
	actv_id 0 : integer
	config_id 1 : integer 		# 对应 tunrtable.csv的id
	curr_turn 2 : integer		# 当前轮次
	turn_data 3 : integer 		# 二进制位表示，从低位开始 位值1表示已领取
}


# 战令信息
.BpData {
    close 0 : integer
	id 1 : integer
	base_id 2 : integer
	session 3 : integer
	stime 4 : integer
	etime 5 : integer
	paid 6 : integer
	exp 7 : integer
	free_record_1 11 : integer
	free_record_2 12 : integer
	free_record_3 13 : integer
	free_record_4 14 : integer
	pay_record_1 21 : integer
	pay_record_2 22 : integer
	pay_record_3 23 : integer
	pay_record_4 24 : integer
}


# 尘封委托
.DustAchieveData {
	base_id 0 : integer
	type 1 : integer
	count 2 : integer
	count_time 3 : integer
	rewarded 4 : integer
}

# 战令任务
.BpAchieveData {
	base_id 0 : integer
	type 1 : integer
	count 2 : integer
	count_time 3 : integer
	rewarded 4 : integer
	closed 5 : integer
}



# 魔纹信息
.SigilData {
	id 0 : integer
	base_id 1 : integer
	hero_id 2 : integer
	equip_pos 3 : integer
	quality 4 : integer
	level 5 : integer
	ran 6 : integer
	echo 7 : integer
	echo_ran 8 : integer

	prefix_1 11 : integer
	preran_1 12 : integer
	prefix_2 13 : integer
	preran_2 14 : integer

	saved 21 : integer
	locked 22 : integer
	is_new 23 : integer
}


#魔纹信息信息（拾取）
.InfoSigilData {
	index 0 : integer
	base_id 1 : integer
	ran 2 : integer
	quality 3 : integer
	level 4 : integer
	echo 5 : integer
	echo_ran 6 : integer
	
	prefix_1 11 : integer
	preran_1 12 : integer
	prefix_2 13 : integer
	preran_2 14 : integer

	saved 21 : integer
	is_new 22 : integer
}

#深渊领域信息
.AbyssAreaData {
	base_id 0 : integer
	first_score 1 : integer
	gift_open_day 2 : integer
	neo_index 3 : integer
	akasa_level 4 : integer
	first_score_1 11 : integer
	first_score_2 12 : integer
	first_score_3 13 : integer
	first_score_4 14 : integer
	first_score_5 15 : integer
}


# 回归信息
.BackData {
	id 1 : integer
	
	base_id 2 : integer
	open 3 : integer
	level 4 : integer
	lasting_days 5 : integer
	back_days 6 : integer

	create_time 11 : integer
	achieve_refresh 12 : integer
	achieve_rewarded 13 : integer
	stage_refresh 14 : integer
	stage_rewarded 15 : integer
}

# 回归签到信息
.BackRecordData {
	back_id 0 : integer
	reward_record 1 : integer
	login_time 2 : integer
	login_days 3 : integer
}

# 回归成就信息
.BackAchieveData {
	id 0 : integer
	back_id 1 : integer
	type 2 : integer
	achieve_type 3 : integer
	base_id 4 : integer
	count 5 : integer
	day_time 6 : integer
	rewarded 7 : integer
}

#宠物放养信息
.PetFeedData {
	id 0 : integer
	start_time 1 : integer
	pos 2 : integer
	pet_id 3 : integer
	feed 4 : integer
	reward_time 5 : integer
	reward_feed 6 : integer
	reward_pet_id 7 : integer
	reward_seed 8 : integer
	visit_feed 9 : integer
}

#宠物放养信息（家园）
.PetFeedHome {
	id 0 : integer
	pos 1 : integer
	feed 2 : integer
	pet_base_id 11 : integer
	pet_name 12 : string
	pet_quality 13 : integer
}


# 神器信息
.ArtifactData {
	id 0 : integer
	base_id 1 : integer
	hero_id 2 : integer
	level 3 : integer
	star 4 : integer
	ran 5 : integer
	saved 6 : integer
	locked 7 : integer
	is_new 8 : integer

	attr_1 11 : string
	attr_2 12 : string
	attr_3 13 : string
}


# 神器信息（拾取）
.InfoArtifactData {
	index 0 : integer
	base_id 1 : integer
	hero_id 2 : integer
	level 3 : integer
	star 4 : integer
	ran 5 : integer
	saved 6 : integer
	locked 7 : integer
	is_new 8 : integer

	attr_1 11 : string
	attr_2 12 : string
	attr_3 13 : string
}


# 守护核心信息
.CoreData {
	id 0 : integer
	week_id 1 : integer
	wave 2 : integer
	time 3 : integer
	buffs 4 : string
	best_wave 5 : integer
	best_time 6 : integer
	timestamp 7 : integer
	rewarded 8 : integer
}






# -----------------------公会相关结构----------------------------------
#公会头像
.UnionIcon {
	icon1 0 : integer			#旗子形状
	icon2 1 : integer			#旗子底色
	icon3 2 : integer			#旗子图案
	icon4 4 : integer			#图案颜色
}

#公会基础信息
.UnionBaseInfo {
	union_id 0 : integer				#公会ID
	union_name 1 : string				#公会名称
	union_notice 2 : string				#公会公告
	union_icon 3 : UnionIcon			#公会头像
	union_type 4 : integer				#公会类型（偏好）对应策划配置表
	union_level 5 : integer				#公会等级
	union_member_num 6 : integer		#公会人数
	union_money 7 : integer				#公会资金
	union_res 8 : integer				#公会资源
	join_need_check 9 : integer			#加入公会是否审批 
	last_change_name_time 10 : integer	#上次修改公会名称的时间（用于前端显示CD）
	lang 11 : string 					#公会名称和公告 使用的语言
}

#公会关于自己的私有信息
.UnionPrivateInfo {
	last_exit_union_time 0 : integer			#上次离开公会的时间
	contribution_info 1 : *UnionContribution	#自己的捐献信息
	official_title 2 : integer					#自己的官衔
	contribution 3 : integer					#自己的贡献度
}

#公会建筑等级
.UnionBuildingInfo {
	building_tag 0 : integer				#建筑ID
	building_level 1 : integer			#等级
}

#公会BUFF（已经学会的BUFF）
.UnionBuffInfo {
	buff_id 0 : *integer					#已研究完成的BUFF，等级就是研究所有等级
	opening_buff 1 : *UnionOpeningBuffInfo	#已开启的BUFF信息
}

#正在开启的BUFF
.UnionOpeningBuffInfo {
	buff_id 0 : integer					#正在开启的 buff id
	expiration 2 : integer				#过期时间(秒)
}

#公会LOG
.UnionLog {
	log_type 0 : integer        	# 对应配置表 union_log.xlsx 的id
	user_info 1 : UserInfo			# 这条log的执行者是谁
	target_user 2 : UserInfo		# 被操作的目标是谁
	log_data 3 : string				# json数据
	create_time 4 : integer			# log 生成的时间
}

#公会成员
.UnionMember {
	user_info 0 : UserInfo			#玩家基础信息
	abyss_max_level 1 : integer		#深渊等级
	contribution 2 : integer		#公会贡献度
	is_online 3 : integer			# 1在线 0不在线
	logout_time 4 : integer			#上次退出游戏的时间 
	official_title 5 : integer		# 职位 
}

#捐献结构
.UnionContribution {
	res_type 0 : integer			#捐献物资的类型 
	res_num 1 : integer				#捐献的数量
	create_time 2 : integer				#捐献的时间
}

#公会建筑结构
.UnionBuilding {
	id 0 : integer
	level 1 : integer
}

#公会商店
.UnionShopItem {
	goods_id 0 : integer					#对应 union_shop配置的id
	refresh_time 1 : integer				#刷新时间，>0 表示不能买，正处于CD中
}



#***********************************************************
#公会战 公会信息
.UnionWarSingleUnionInfo {
	union_info 0 : UserUnionInfo	#公会外观
	
	# group_id 2 : integer			#所属小组
	# total_power 3 : integer			#总战力

	hot_val 4 : integer				#当前热度值（下注用, 只有巅峰赛区的公会有这个值）
}

#公会战 单个英雄信息 (详细)
.UnionWarSingleHeroData {
	uid 0 : integer						#唯一ID （表 gs_union_war_formation 的 id 字段）
	user_id 1 : integer					#所属玩家ID
	hero_id 2 : integer					#hero_id
	flag 3 : integer					# 0表示预备队 1 表示上阵 
	position 4 : integer				# 上阵位置

	base_id 10 : integer
	name 11 : string
	body 12 : string
	hair 13 : string
	quality 14 : integer
	level 15 : integer

	equip_1 20 : integer
	equip_5 21 : integer
	equip_6 22 : integer
	equip_7 23 : integer
	equip_8 24 : integer
	equip_9 25 : integer
	equip_10 26 : integer
	
	attr_hp 30 : integer
	attr_atk 31 : integer
	attr_def 32 : integer

	score 40 : integer
}


.HeroInBattle {
	uid 0 : integer
	position 1 : integer
}

#公会战 对阵信息 a vs b
.UnionWarSingleBattleInfo {
	battle_id 0 : integer 			
	union_id_A 1 : integer
	union_id_B 2 : integer
	who_is_win 3 : integer			#值为2个公会ID的其中之一，就表示哪个公会赢了，如果为0 表示还没有开打
}

# 对阵 单方数据
.UnionWarBattleSideInfo {

	.HeroNum {
		hero_type 0 : integer 		#对应hero 表的 class 字段 
		hero_num 1 : integer
	}

	union_info 1 : UserUnionInfo 			#id，公会徽章，名称，语言全有
	hot_val 2 : integer						#当前热度值
	formation 3 : *HeroNum 					#数组 （战士、法师、弓手）的数量
	support 4 : *integer 					#支援BUFF
	heros 5 : *UnionWarSingleHeroData		#公会上阵的英雄快照数据
	union_leader 6 : UserInfo				#会长信息
	
}



#*************************************************************
# FAQ
.FAQ_dir {
	id 0 : integer
	parent_id 1 : integer		
	name 2 : string
}

.FAQ_content {
	id 0 : integer
	title 1 : string
	content 2 : string
}

#*************************************************************



# 公会PVE 普通关卡结构
.UnionPVENormalStageInfo {
	stage_id 1 : integer			#关卡ID(对应gwar_stage表的ID)
	pass_flag 2 : integer			#关卡是否通关
}

# 公会PVE BOSS关卡结构
.UnionPVEBossStageInfo {
	stage_id 1 : integer			#BOSS关卡ID(对应gwar_boss表的ID)
	score 2 : integer				#历史最高分
	ranking 3 : integer				#当前排名 nil 表示未上榜
}

# 公会PVE BOSS排行榜中，单个公会的信息
.UnionPVEBossRankingSingleUnion {
	union_info 1 : UserUnionInfo	#公会信息
	union_leader 2 : UserInfo		#会长信息
	score 3 : integer				#评分
	challenge_time 4 : integer		#挑战时间
}

# 公会PVE 总榜中，单个公会的信息
.UnionPVETotalRankingSingleUnion {
	union_info 1 : UserUnionInfo	#公会信息
	union_leader 2 : UserInfo		#会长信息
	.BossScore {
		stage_id 1 : integer
		score 2 : integer
	}
	score 3 : *BossScore			#三个BOSS的评分
}

]]

return struct
