local InfoChapter = {}
local rawData = {}

function InfoChapter.init()
	Connection.listen("function_sync", InfoChapter.sync)
end

app:addToAppEnterCall(InfoChapter.init)

function InfoChapter.sync(data)
	for k, v in pairs(data) do
		rawData[k] = v
	end

	ManagerInfo.dataChange("chapter")
end

function InfoChapter.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			rawData = rcvData

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("chapter_query", callback)
end

function InfoChapter.getChapterData()
	return CsvParser.getCsvData("chapter", rawData.chapter_id)
end

function InfoChapter.getID()
	return rawData.chapter_id
end

function InfoChapter.getMaxID()
	return rawData.max_id
end

function InfoChapter.checkCampMap(mapName)
	local csv = CsvParser.getCsvData("chapter", rawData.chapter_id)

	if csv.camp_map == mapName then
		return true
	end

	local fcampArr = SheetUtil.getColumnValueList(csv, "festival_camp_")

	for i, v in ipairs(fcampArr) do
		if v == mapName then
			return true
		end
	end

	return false
end

function InfoChapter.getCampMap()
	local csv = CsvParser.getCsvData("chapter", rawData.chapter_id)
	local festivalCamp = InfoFestival.getCampMap()

	if festivalCamp then
		local map = csv["festival_camp_" .. festivalCamp]

		if not empty(map) then
			return map
		end
	end

	return csv.camp_map
end

function InfoChapter.getCampName()
	return CsvParser.getCsvData("chapter", rawData.chapter_id).camp_name
end

function InfoChapter.getWildMap()
	return CsvParser.getCsvData("chapter", rawData.chapter_id).wild_map
end

return InfoChapter
