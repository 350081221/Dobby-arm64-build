local POP_msg = class("POP_msg", UI_base)

function POP_msg.open(msg, style, isBig)
	local ui = POP_msg.new(msg, style, isBig)

	PopManager.open(ui)

	return ui
end

function POP_msg.openTextArea(msg, style)
	local ui = POP_msg.new(msg, style, nil, true)

	PopManager.open(ui)

	return ui
end

function POP_msg:ctor(msg, style, isBig, isTextArea)
	local uiName = "pop_msg"

	if isTextArea then
		uiName = "pop_msg_textarea"
	elseif isBig then
		uiName = "pop_msg_big"
	end

	POP_msg.super.ctor(self, uiName, UIManager.BIG_TYPE.POP)

	self.isTextArea = isTextArea
	self.msg = msg
	self.style = style

	self:init()
end

function POP_msg:init()
	self:initUI()
end

function POP_msg:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	if self.isTextArea then
		local textArea = self:createTextAreaOnFlag("flag_msg")

		textArea:setSpace(5, 5)

		local holder = self:getComponentByTag("holder")

		textArea:setHolders({
			holder
		}, nil, 5)

		local style = {
			wrap = true,
			align = Style.left
		}

		if self.style then
			for k, v in pairs(self.style) do
				style[k] = v
			end
		end

		textArea:setText(self.msg, style)
	else
		local style = {
			wrap = true,
			align = Style.center,
			valign = Style.vcenter
		}

		if Localization.isAlphabet() then
			style.align = Style.left
		end

		if self.style then
			for k, v in pairs(self.style) do
				style[k] = v
			end
		end

		local ubbMap, labels, lines, totalWidth, totalHeight = self:createUbbOnFlag("flag_msg", self.msg, style, true)
		local flag = self:getFlagByTag("flag_msg")
		local bg = self:getComponentByTag("bg")

		if flag.height < totalHeight then
			local yOffset = totalHeight - flag.height

			bg:setSize(nil, bg.height + yOffset)
			bg:setPos(nil, bg.y - yOffset / 2)
		end
	end
end

return POP_msg
