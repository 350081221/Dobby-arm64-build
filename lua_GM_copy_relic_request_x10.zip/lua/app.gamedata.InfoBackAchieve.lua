local InfoBackAchieve = {}
local rawData = nil

function InfoBackAchieve.init()
	Connection.listen("back_achieve_sync", InfoBackAchieve.sync)
end

app:addToAppEnterCall(InfoBackAchieve.init)

function InfoBackAchieve.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoBackAchieve.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("back_achieve_query", callback)
end

function InfoBackAchieve.onQuery(rcvData)
	dump(rcvData, "back_achieve_query")

	rawData = {}

	for i = 1, #rcvData.list do
		local data = rcvData.list[i]
		rawData[data.id] = data
	end
end

function InfoBackAchieve.sync(data)
	dump(data, "InfoBackAchieve.sync")

	for i, syncData in ipairs(data.list) do
		local id = syncData.id

		if not rawData[id] then
			rawData[id] = syncData
		else
			for k, v in pairs(syncData) do
				rawData[id][k] = v
			end
		end
	end

	notify.dispatch("campaign_changed")
	ManagerInfo.dataChange("back_achieve")
end

function InfoBackAchieve.getDayReward(backData, onSuccess, onFailure)
	print("$$$ InfoBackAchieve.getDayReward", backData.id)

	local function callback(rcvData)
		dump(rcvData, "back_achieve_get_day_reward")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("back_achieve_get_day_reward", {
		back_id = backData.id
	}, callback)
end

function InfoBackAchieve.getReward(id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "back_achieve_get_reward")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("back_achieve_get_reward", {
		id = id
	}, callback)
end

function InfoBackAchieve.getAchieveDayReady(backData)
	local existMap = {}

	for id, data in pairs(rawData) do
		if data.back_id == backData.id then
			local csv = CsvParser.getCsvData("back_achieve", data.base_id)

			if csv.type == 1 then
				local count, countMax, rewarded = InfoBackAchieve.getCount(data)

				if countMax <= count then
					existMap[csv.id] = true
				end
			end
		end
	end

	local isReady = true
	local csvArr = CsvParser.getCsvList("back_achieve")

	for i, csv in ipairs(csvArr) do
		if csv.type == 1 and not existMap[csv.id] then
			isReady = false

			break
		end
	end

	return isReady
end

function InfoBackAchieve.getAchieveDayReward(backData)
	if backData then
		local csv = CsvParser.getCsvData("back", backData.base_id)
		local nowTime = Time.now()
		local rewarded = backData.achieve_rewarded

		if RefreshManager.checkTimePassed(RefreshManager.TYPE.BACK_ACHIEVE_DAY, nowTime, backData.achieve_refresh) then
			rewarded = 0
		end

		local rewardArr = SheetUtil.getColumnList(csv, {
			"daily_reward_",
			"reward_num_"
		}, {
			"base_id",
			"num"
		})

		return rewardArr, rewarded
	end
end

function InfoBackAchieve.getCount(data)
	local nowTime = Time.now()
	local csv = CsvParser.getCsvData("back_achieve", data.base_id)
	local count = data.count

	if csv.type == 1 and RefreshManager.checkTimePassed(RefreshManager.TYPE.BACK_ACHIEVE_DAY, nowTime, data.day_time) then
		count = 0
	end

	local rewarded = 0

	if csv.type == 2 then
		rewarded = data.rewarded
	end

	return count, csv.num, rewarded
end

function InfoBackAchieve.getList(backData, type)
	local csvList = {}
	local existMap = {}
	local csvArr = CsvParser.getCsvList("back_achieve")

	for i, csv in ipairs(csvArr) do
		if csv.type == type then
			local base_id_arr = string.split(csv.back_id, ",")

			for j, base_id_str in ipairs(base_id_arr) do
				local base_id = tonumber(base_id_str)

				if base_id == backData.base_id then
					local obj = existMap[csv.achieve_type]

					if not obj then
						obj = {
							achieve_type = csv.achieve_type,
							csvArr = {
								csv
							}
						}
						existMap[csv.achieve_type] = obj

						table.insert(csvList, obj)

						break
					end

					table.insert(obj.csvArr, csv)

					break
				end
			end
		end
	end

	local nowTime = Time.now()
	local existMap = {}

	for id, data in pairs(rawData) do
		if data.back_id == backData.id then
			local csv = CsvParser.getCsvData("back_achieve", data.base_id)

			if csv.type == type then
				local count, countMax, rewarded = InfoBackAchieve.getCount(data)
				local fin = math.min(1, count / countMax)
				existMap[data.achieve_type] = {
					id = data.id,
					csv = csv,
					count = count,
					rewarded = rewarded,
					fin = fin
				}
			end
		end
	end

	local arr = {}

	for i, obj in ipairs(csvList) do
		if existMap[obj.achieve_type] then
			for k, v in pairs(existMap[obj.achieve_type]) do
				obj[k] = v
			end

			table.insert(arr, obj)
		else
			obj.count = 0
			obj.rewarded = 0
			obj.fin = 0
			obj.csv = obj.csvArr[1]

			table.insert(arr, obj)
		end
	end

	table.sort(arr, function (a, b)
		if a.rewarded == b.rewarded then
			if a.fin == b.fin then
				return a.csv.id < b.csv.id
			else
				return b.fin < a.fin
			end
		else
			return a.rewarded < b.rewarded
		end
	end)

	return arr
end

function InfoBackAchieve.countRedot(backData)
	local redotCount = 0
	local existMap = {}

	for id, data in pairs(rawData) do
		if data.type == 2 and data.back_id == backData.id then
			local count, countMax, rewarded = InfoBackAchieve.getCount(data)

			if countMax <= count and rewarded == 0 then
				existMap[data.base_id] = true
			end
		end
	end

	local csvRaw = CsvParser.getCsvRaw("back_achieve")

	for k, csv in pairs(csvRaw) do
		if csv.type == 2 then
			local base_id_arr = string.split(csv.back_id, ",")

			for j, base_id_str in ipairs(base_id_arr) do
				local base_id = tonumber(base_id_str)

				if base_id == backData.base_id then
					if existMap[csv.id] then
						redotCount = redotCount + 1
					end

					break
				end
			end
		end
	end

	return redotCount
end

function InfoBackAchieve.countRedotDay(backData)
	local redotCount = 0
	local rewardArr, rewarded = InfoBackAchieve.getAchieveDayReward(backData)

	if InfoBackAchieve.getAchieveDayReady(backData) and rewarded == 0 then
		redotCount = redotCount + 1
	end

	return redotCount
end

return InfoBackAchieve
