local POP_setup = class("POP_setup", UI_base)

function POP_setup.open()
	local ui = POP_setup.new()

	PopManager.open(ui, nil, , , 100)
end

function POP_setup:ctor()
	POP_setup.super.ctor(self, "pop_setup", UIManager.BIG_TYPE.POP)
	self:init()
end

function POP_setup:init()
	self:initUI()
	self:refreshNickname()
	ManagerInfo.onDataChange(self, "user", nil, function ()
		self:refreshNickname()
		self:refreshCredit()

		if global.player then
			global.player:refreshTitle()
		end
	end)
	self:refreshBind()
	notify.safeRegister(self, "guest_change", function ()
		self:refreshBind()
	end)
	self:refreshRedot()
	ManagerInfo.onDataChange(self, "service", nil, function (data)
		self:refreshRedot()
	end)

	if CONFIG.dafu then
		self:refreshLine()
	end
end

function POP_setup:refreshRedot()
	local redot_service = self:getComponentByTag("redot_service")

	redot_service:setVisible(InfoService.countRedot() > 0)
end

function POP_setup:refreshNickname()
	local nickname, nicklang = InfoUser.getNickAndLang()
	local style = {
		noLocal = true
	}

	if not empty(nicklang) then
		style.lang = nicklang
		style.font = Localization.getFont(nicklang)
	end

	self:createLabelOnFlag("flag_nickname", nickname, style)
end

function POP_setup:refreshBind()
	local bindPB = self:getComponentByTag("bt_bind")
	local bt_float = self:getComponentByTag("bt_float")
	local bt_zhuxiao = self:getComponentByTag("bt_zhuxiao")

	bindPB:setVisible(false)
	bt_float:setVisible(false)
	bt_zhuxiao:setVisible(false)

	if CONFIG.is_sdk_login and global.isGuest then
		bindPB:setVisible(true)
	elseif A_zhuxiao then
		bt_zhuxiao:setVisible(true)
	elseif CONFIG.hide_float then
		bt_float:setVisible(true)

		if Cookie.get("hide_float") == 1 then
			bt_float:addLabel(Localization.getSrcText("显示浮窗"))
		else
			bt_float:addLabel(Localization.getSrcText("关闭浮窗"))
		end
	end
end

function POP_setup:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local label_music = self:getComponentByTag("label_music")
	local label_sound = self:getComponentByTag("label_sound")

	self:createScrollerByTag("music_vol", "flag_music", function (percent, isEnd)
		Sound.setMusicVolume(percent, isEnd)
		self:refreshMusicAndSoundVolume()
	end)
	self:createScrollerByTag("sound_vol", "flag_sound", function (percent, isEnd)
		if isEnd then
			UIManager.callTapGroup("button_click")
		end

		Sound.setSoundVolume(percent, isEnd)
		self:refreshMusicAndSoundVolume()
	end)
	self:createScrollerByTag("gamma_vol", "flag_gamma", function (percent, isEnd)
		Sound.setGamma(percent, isEnd)

		if global.map then
			global.map:setGamma(Sound.getGamma())
		end
	end)
	self:refreshMusicAndSoundVolume()
	self:setScollerProgressByTag("flag_music", Sound.getMusicVolume())
	self:setScollerProgressByTag("flag_sound", Sound.getSoundVolume())
	self:setScollerProgressByTag("flag_gamma", Sound.getGamma())
	self:createScrollerByTag("display_vol", "flag_display", function (percent, isEnd)
		if isEnd then
			UIManager.callTapGroup("button_click")
			self:setScollerProgressByTag("flag_display", Sound.getDislayVolume())
		end

		Sound.setDislayLevel(percent, isEnd)
		self:refreshDisplayVolume()
	end)
	self:refreshDisplayVolume()
	self:setScollerProgressByTag("flag_display", Sound.getDislayVolume())
	self:createLabelOnFlag("flag_user_id", InfoUser.getID())

	local bt_other = self:getComponentByTag("bt_other")

	bt_other:toTouchable()
	bt_other:setTapGroup("button_click")
	bt_other:addTap(function ()
		POP_setup_other.open()
	end)

	local bt_service = self:getComponentByTag("bt_service")

	bt_service:toTouchable()
	bt_service:setTapGroup("button_click")
	bt_service:addTap(function ()
		FRAME_service.open()
	end)

	local redot_service = self:getComponentByTag("redot_service")
	local redeemPB = self:getComponentByTag("bt_redeem")
	local iosCheckVersion = InfoParams.getValue("ios_version")
	local isIosCheck = false

	if not empty(iosCheckVersion) and device.platform == "ios" and iosCheckVersion == CONFIG.appVersion then
		isIosCheck = true
	end

	if InfoParams.getValue("redeem_on") == 1 and not isIosCheck then
		redeemPB:toTouchable()
		redeemPB:setTapGroup("button_click")
		redeemPB:addTap(function ()
			FRAME_redeem.open()
		end)
	else
		redeemPB:setVisible(false)
		bt_service:setPos(nil, bt_service.y + 40)
		redot_service:setPos(nil, redot_service.y + 40)
	end

	local bindPB = self:getComponentByTag("bt_bind")

	bindPB:toTouchable()
	bindPB:setTapGroup("button_click")
	bindPB:addTap(function ()
		FRAME_bind.open()
	end)

	local bt_float = self:getComponentByTag("bt_float")

	bt_float:toTouchable()
	bt_float:setTapGroup("button_click")
	bt_float:addTap(function ()
		if Cookie.get("hide_float") == 1 then
			Cookie.set("hide_float", 0, true)
			LuaBridge.call("luaOpenFloat", {}, function (result)
			end)
		else
			Cookie.set("hide_float", 1, true)
			LuaBridge.call("luaCloseFloat", {}, function (result)
			end)
		end

		self:refreshBind()
	end)

	local bt_zhuxiao = self:getComponentByTag("bt_zhuxiao")

	bt_zhuxiao:toTouchable()
	bt_zhuxiao:setTapGroup("button_click")
	bt_zhuxiao:addTap(function ()
		POP_notice.open(Localization.getSrcText("点击玩家服务>客户服务\n点击“转接人工” 将由客服为您处理"), nil, function ()
			local params = {
				user_id = tostring(InfoUser.getID()),
				user_name = tostring(InfoUser.getNickName()),
				server_id = tostring(InfoUser.getServerID())
			}

			LuaBridge.call("luaService", params)
		end, Localization.getSrcText("知道了"), Localization.getSrcText("直接前往"))
	end)

	local logoutPB = self:getComponentByTag("bt_logout")

	logoutPB:toTouchable()
	logoutPB:setTapGroup("button_click")

	if CONFIG.is_sdk_logout then
		logoutPB:addTap(function ()
			POP_notice.open(Localization.getSrcText("确认退出当前账号吗？"), function ()
				LuaBridge.call("luaLogout", {}, function (result)
					dump(result, "$$$ luaLogout")

					if result.rs == "success" then
						InfoUser.doReconnect()
					else
						Alert.open(Localization.getSrcText("退出账号失败"))
					end
				end)
			end)
		end)
	else
		logoutPB:addTap(function ()
			POP_notice.open(Localization.getSrcText("确认退出当前账号吗？"), function ()
				Cookie.set("savedUsername", nil)
				Cookie.set("savedPassword", nil)
				Cookie.flush()
				InfoUser.doReconnect()
			end)
		end)
	end

	self:createLabelOnFlag("flag_user_id", InfoUser.getID())
	self:refreshTotalTime()
	self:addEnterFrame("refresh_total_time", function ()
		self:refreshTotalTime()
	end)

	local button_weather = self:getComponentByTag("button_weather")

	button_weather:toTouchable()
	button_weather:setTapGroup("button_click")
	button_weather:addTap(function ()
		local showWeather = Cookie.get("showWeather") or 1
		showWeather = 1 - showWeather

		Cookie.set("showWeather", showWeather, true)
		self:refreshWeather()
		notify.dispatch("show_weather_changed")
	end)
	self:refreshWeather()

	local button_online_camp = self:getComponentByTag("button_online_camp")

	button_online_camp:toTouchable()
	button_online_camp:setTapGroup("button_click")
	button_online_camp:addTap(function ()
		local isOnlineCamp = Cookie.get("isOnlineCamp") or 1
		isOnlineCamp = 1 - isOnlineCamp

		Cookie.set("isOnlineCamp", isOnlineCamp, true)
		self:refreshOnlineCamp()

		if OnlineCamp.isOnline() and global.player then
			OnlineCamp.clearAll()

			if isOnlineCamp == 1 and InfoGuide.isFin() then
				OnlineCamp.tryEnter()
			else
				OnlineCamp.tryExit()
			end
		end
	end)
	self:refreshOnlineCamp()

	local button_chat = self:getComponentByTag("button_chat")

	button_chat:toTouchable()
	button_chat:setTapGroup("button_click")
	button_chat:addTap(function ()
		local isOnlineChat = OnlineChat.isOnlineChat()
		isOnlineChat = 1 - isOnlineChat

		Cookie.set("isOnlineChat", isOnlineChat, true)
		self:refreshOnlineChat()
		OnlineChat.refreshOnlineSetup()
	end)
	self:refreshOnlineChat()

	local button_emu = self:getComponentByTag("button_emu")

	button_emu:toTouchable()
	button_emu:setTapGroup("button_click")
	button_emu:addTap(function ()
		local emuMode = Cookie.get("emuMode") or 0
		emuMode = 1 - emuMode

		Cookie.set("emuMode", emuMode, true)
		self:refreshEmuMode()
	end)
	self:refreshEmuMode()

	local button_marquee = self:getComponentByTag("button_marquee")

	button_marquee:toTouchable()
	button_marquee:setTapGroup("button_click")
	button_marquee:addTap(function ()
		local isShowMarquee = Cookie.get("isShowMarquee") or 1
		isShowMarquee = 1 - isShowMarquee

		Cookie.set("isShowMarquee", isShowMarquee, true)
		self:refreshShowMarquee()
	end)
	self:refreshShowMarquee()

	local hintButtons = {
		"hint_emu",
		"hint_weather",
		"hint_online_camp",
		"hint_chat",
		"hint_display",
		"hint_marquee",
		"hint_gamma"
	}
	local hints = {
		Localization.getSrcText("模拟器模式下，战斗为全屏操作"),
		Localization.getSrcText("开启、关闭天气和昼夜效果（关闭可提升营地显示效率）"),
		Localization.getSrcText("是否在营地和钓鱼地图开启联机"),
		Localization.getSrcText("是否在主界面显示聊天信息"),
		Localization.getSrcText("高特效：战斗动画帧率优先\n低特效：战斗动画速度优先"),
		Localization.getSrcText("是否显示节日跑马灯"),
		Localization.getSrcText("调整地图明暗度")
	}

	for i, v in ipairs(hintButtons) do
		local button = self:getComponentByTag(v)

		button:setOpacity(0)
		button:toTouchable()
		button:addTap(function ()
			local x, y = button:getPosition()
			local pos = self:convertToWorldSpace(cc.p(x, y))

			TinyHint.open(cc.p(pos.x, pos.y), hints[i])
		end)
	end

	if CONFIG.lang_multi then
		local lang_bg = self:getComponentByTag("lang_bg")

		lang_bg:toTouchable()
		lang_bg:setTapGroup("bg_click")
		lang_bg:addTap(function ()
			FRAME_select_lang.open()
		end)
	else
		local label_change_lang = self:getComponentByTag("label_change_lang")

		label_change_lang:setVisible(false)
	end

	local nameChange = self:getComponentByTag("name_change")

	nameChange:setOpacity(0)
	nameChange:setTapGroup("button_click")
	nameChange:toTouchable()
	nameChange:addTap(function ()
		local lenStr = Localization.getSrcText("输入{1}-{2}位字符")
		local user_name_cost = CsvParser.getCsvData("config", "user_name_cost").value
		local costItem = {
			base_id = GameConfig.zuan_item,
			num = user_name_cost
		}
		local str = Localization.getSrcText("是否花费[color={1}][{2}x{3}][/color]更改昵称？")
		local matCSV = CsvParser.getCsvData("item", GameConfig.zuan_item)
		local costStr = StringUtil.replace(str, Style.goldenStr, matCSV.name, user_name_cost)
		local currentName = InfoUser.getNickName()

		POP_notice_input.openCost(costItem, costStr, Localization.getSrcText("更改昵称"), StringUtil.replace(lenStr, GameConfig.user_nickname_len_min, GameConfig.user_nickname_len_max), currentName, function (inputStr)
			local len = utf8.len(inputStr)

			if currentName == inputStr then
				Alert.open(Localization.getSrcText("昵称没有变动"))

				return false
			end

			if not StringUtil.checkNameLegal(inputStr) then
				return false
			end

			if len < GameConfig.user_nickname_len_min or GameConfig.user_nickname_len_max < len then
				Alert.open(Localization.getSrcText("名字长度超出范围"))

				return false
			end

			return true
		end, function (inputStr)
			InfoUser.setName(inputStr)
		end)
	end)

	if CONFIG.dafu then
		local line_change = self:getComponentByTag("line_change")

		line_change:setOpacity(0)
		line_change:setTapGroup("button_click")
		line_change:toTouchable()
		line_change:addTap(function ()
			FRAME_select_line.open()
		end)
	else
		self:removeComponentByTag("line_change")
		self:removeComponentByTag("line_change_icon")
		self:removeLabelOnFlag("label_line")
	end

	self:refreshCredit()
end

function POP_setup:refreshCredit()
	local label = self:getComponentByTag("label_credit")
	local icon = self:getComponentByTag("icon_credit")

	label:setVisible(InfoUser.isCredit())
	icon:setVisible(InfoUser.isCredit())

	if InfoUser.isCredit() then
		self:createLabelOnFlag("flag_credit", InfoUser.getCredit())
	else
		self:removeLabelOnFlag("flag_credit")
	end
end

function POP_setup:refreshLine()
	self:createLabelOnFlag("flag_line", InfoUser.gateLine)
end

function POP_setup:refreshEmuMode()
	local selected_emu = self:getComponentByTag("selected_emu")
	local emuMode = Cookie.get("emuMode") or 0

	selected_emu:setVisible(emuMode == 1)
end

function POP_setup:refreshStepSound()
	local selected_step = self:getComponentByTag("selected_step")

	selected_step:setVisible(Sound.isStepSound())
end

function POP_setup:refreshWeather()
	local selected_weather = self:getComponentByTag("selected_weather")
	local showWeather = Cookie.get("showWeather") or 1

	selected_weather:setVisible(showWeather == 1)
end

function POP_setup:refreshOnlineCamp()
	local selected_online_camp = self:getComponentByTag("selected_online_camp")
	local isOnlineCamp = Cookie.get("isOnlineCamp") or 1

	selected_online_camp:setVisible(isOnlineCamp == 1)
end

function POP_setup:refreshOnlineChat()
	local selected_chat = self:getComponentByTag("selected_chat")
	local isOnlineChat = OnlineChat.isOnlineChat()

	selected_chat:setVisible(isOnlineChat == 1)
end

function POP_setup:refreshShowDmg()
	local selected_show_dmg = self:getComponentByTag("selected_show_dmg")
	local isShowDmg = Cookie.get("isShowDmg") or 1

	selected_show_dmg:setVisible(isShowDmg == 1)
end

function POP_setup:refreshShowMarquee()
	local selected_marquee = self:getComponentByTag("selected_marquee")
	local isShowMarquee = Cookie.get("isShowMarquee") or 1

	selected_marquee:setVisible(isShowMarquee == 1)
end

function POP_setup:refreshMusicAndSoundVolume()
	local label_music = self:getComponentByTag("label_music")
	local label_sound = self:getComponentByTag("label_sound")

	label_music:setOpacity(Sound.getMusicVolume() == 0 and 150 or 255)
	label_sound:setOpacity(Sound.getSoundVolume() == 0 and 150 or 255)
end

function POP_setup:refreshDisplayVolume()
	local labels = {
		"高",
		"中",
		"低"
	}

	self:replaceLabelOnFlag("label_display_level", nil, Localization.getSrcText(labels[Sound.getDislayLevel() + 1]))
end

function POP_setup:refreshTotalTime()
	local totalTime = InfoUser.getTotalTime()

	if self.totalTime ~= totalTime then
		self.totalTime = totalTime

		self:createLabelOnFlag("flag_total_time", Time.showMin(totalTime))
	end
end

return POP_setup
