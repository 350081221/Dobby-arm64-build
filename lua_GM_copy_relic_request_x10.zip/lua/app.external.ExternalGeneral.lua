local ExternalGeneral = {
	exit = function ()
		if device.platform == "android" then
			local javaClassName = "com.gasura.general.Basic"
			local javaMethodName = "exit"
			local javaParams = {}
			local javaMethodSig = "()V"

			luaj.callStaticMethod(javaClassName, javaMethodName, javaParams, javaMethodSig)
		end
	end,
	gameReview = function ()
		print("$$$ ExternalGeneral.gameReview")

		if not A_mbcn_new then
			return
		end

		local function tucao()
			FRAME_tucao.open(function (inputStr)
				if not empty(inputStr) then
					Alert.open(Localization.getSrcText("感谢您的反馈"))
				end
			end)
		end

		POP_notice.open(Localization.getSrcText("是否愿意给个好评？"), function ()
			print("选了好评")

			local params = {}

			LuaBridge.call("lua_game_review", params, function (result)
				InfoService.reviewMark()
				Alert.open(Localization.getSrcText("感谢您的评价"))
			end)
		end, function ()
			print("选了吐槽")
			tucao()
		end, Localization.getSrcText("好评"), Localization.getSrcText("吐槽"))
	end
}

return ExternalGeneral
