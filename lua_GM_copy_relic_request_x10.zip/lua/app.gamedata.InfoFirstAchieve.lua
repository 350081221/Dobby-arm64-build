local InfoFirstAchieve = {}
local rawData = {}
local start_time, reward_record, paid, paid_reward_record = nil

function InfoFirstAchieve.init()
	Connection.listen("first_achieve_sync", InfoFirstAchieve.sync)
end

app:addToAppEnterCall(InfoFirstAchieve.init)

function InfoFirstAchieve.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		else
			InfoFirstAchieve.onQuery(rcvData)

			if onSuccess then
				onSuccess()
			end
		end
	end

	Connection.request("first_achieve_query", callback)
end

function InfoFirstAchieve.onQuery(rcvData)
	dump(rcvData, "first_achieve_query")

	rawData = {}

	for i, data in ipairs(rcvData.list) do
		rawData[data.base_id] = data
	end

	start_time = rcvData.start_time
	reward_record = rcvData.reward_record
	paid = rcvData.paid
	paid_reward_record = rcvData.paid_reward_record
end

function InfoFirstAchieve.sync(data)
	dump(data, "$$$ InfoFirstAchieve.sync")

	if data.list then
		for i, syncData in ipairs(data.list) do
			local base_id = syncData.base_id

			if rawData[base_id] then
				for k, v in pairs(syncData) do
					rawData[base_id][k] = v
				end
			else
				rawData[base_id] = syncData
			end
		end
	end

	if data.start_time then
		start_time = data.start_time
	end

	if data.reward_record then
		reward_record = data.reward_record
	end

	if data.paid then
		paid = data.paid
	end

	if data.paid_reward_record then
		paid_reward_record = data.paid_reward_record
	end

	notify.dispatch("campaign_changed")
	ManagerInfo.dataChange("first_achieve")
end

function InfoFirstAchieve.isOpening()
	local first_achieve_reward_days = CsvParser.getCsvData("config", "first_achieve_reward_days").value
	local endDay = Time.getDay(start_time) + first_achieve_reward_days

	if Time.getDay() < endDay then
		return true
	end
end

local maxDay = nil

function InfoFirstAchieve.getDay()
	if not maxDay then
		maxDay = 0
		local csvRaw = CsvParser.getCsvRaw("first_achieve")

		for k, csv in pairs(csvRaw) do
			maxDay = math.max(maxDay, csv.day)
		end
	end

	return Time.getDay() - Time.getDay(start_time) + 1, maxDay
end

function InfoFirstAchieve.getTargetDayLeft()
	local first_achieve_reward_days = CsvParser.getCsvData("config", "first_achieve_reward_days").value
	local endDay = Time.getDay(start_time) + first_achieve_reward_days

	return endDay - Time.getDay()
end

function InfoFirstAchieve.getAchieveList(day)
	local csvList = CsvParser.getCsvList("first_achieve", nil, {
		day = day
	})
	local arr = {}

	for i, csv in ipairs(csvList) do
		table.insert(arr, {
			csv = csv
		})
	end

	return arr
end

function InfoFirstAchieve.getProgress(base_id)
	local count = 0
	local rewarded = 0

	if rawData[base_id] then
		count = rawData[base_id].count or count
		rewarded = rawData[base_id].rewarded or rewarded
	end

	local csv = CsvParser.getCsvData("first_achieve", base_id)
	count = math.min(count, csv.num)

	return count, csv.num, rewarded
end

function InfoFirstAchieve.getDayProgress(day)
	local dayCount = 0
	local csvList = CsvParser.getCsvList("first_achieve", nil, {
		day = day
	})

	for i, csv in ipairs(csvList) do
		local count, max, rewarded = InfoFirstAchieve.getProgress(csv.id)

		if max <= count then
			dayCount = dayCount + 1
		end
	end

	return dayCount, 4
end

function InfoFirstAchieve.countRedot()
	local redotCount = 0
	local currDay, maxDay = InfoFirstAchieve.getDay()

	for i = 1, maxDay do
		if i <= currDay then
			local count = InfoFirstAchieve.countRedotDay(i)
			redotCount = redotCount + count
		end
	end

	local csvList = CsvParser.getCsvList("first_achieve_reward")
	local maxPoint = csvList[#csvList].point
	local currentPoint = InfoFirstAchieve.getTargetPoint()

	for i, csv in ipairs(csvList) do
		local rewarded = InfoFirstAchieve.getRecord(csv.id)

		if rewarded == 0 and csv.point <= currentPoint then
			redotCount = redotCount + 1
		end

		if InfoFirstAchieve.isPaid() then
			local paidRewarded = InfoFirstAchieve.getPaidRecord(csv.id)

			if paidRewarded == 0 and csv.point <= currentPoint then
				redotCount = redotCount + 1
			end
		end
	end

	return redotCount
end

function InfoFirstAchieve.countRedotDay(day)
	local redotCount = 0
	local csvList = CsvParser.getCsvList("first_achieve", nil, {
		day = day
	})

	for i, csv in ipairs(csvList) do
		local count, max, rewarded = InfoFirstAchieve.getProgress(csv.id)

		if rewarded == 0 and max <= count then
			redotCount = redotCount + 1
		end
	end

	return redotCount
end

function InfoFirstAchieve.getTargetPoint()
	local point = 0
	local currDay = InfoFirstAchieve.getDay()
	local csvRaw = CsvParser.getCsvRaw("first_achieve")

	for k, csv in pairs(csvRaw) do
		if csv.day <= currDay then
			local count, max, rewarded = InfoFirstAchieve.getProgress(csv.id)

			if max <= count then
				point = point + csv.point
			end
		end
	end

	return point
end

function InfoFirstAchieve.getReward(id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "first_achieve_get_reward")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("first_achieve_get_reward", {
		id = id
	}, callback)
end

function InfoFirstAchieve.getRecord(index)
	return BitUtil.getBitByIndex(reward_record, index)
end

function InfoFirstAchieve.getTargetReward(id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "first_achieve_get_target_reward")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("first_achieve_get_target_reward", {
		id = id
	}, callback)
end

function InfoFirstAchieve.getTypeList(active_type, values)
	local csvByTypeCache = CacheData.get("InfoFirstAchieve_csvByTypeCache")

	if not csvByTypeCache then
		csvByTypeCache = {}
		local csvRaw = CsvParser.getCsvRaw("first_achieve")

		for k, csv in pairs(csvRaw) do
			if not csvByTypeCache[csv.active_type] then
				csvByTypeCache[csv.active_type] = {}
			end

			table.insert(csvByTypeCache[csv.active_type], csv.id)
		end

		CacheData.set("InfoFirstAchieve_csvByTypeCache", csvByTypeCache)
	end

	return csvByTypeCache[active_type]
end

function InfoFirstAchieve.fxxkCheck(id, value, ...)
	local count, max, rewarded = InfoFirstAchieve.getProgress(id)

	print("$$$ fxxkCheck", id, value, count)

	if value < count then
		return
	end

	local params = {
		...
	}

	local function callback(rcvData)
		dump(rcvData, "first_achieve_fxxk_check")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("first_achieve_fxxk_check", {
		id = id,
		params = params
	}, callback)
end

function InfoFirstAchieve.fxxkCheck300(heroID)
	local base_id_arr = InfoFirstAchieve.getTypeList(300)

	if base_id_arr then
		for i, base_id in ipairs(base_id_arr) do
			local count, max, rewarded = InfoFirstAchieve.getProgress(base_id)

			if rewarded == 1 then
				return
			end

			if max <= count then
				return
			end

			local minEnhanceLevel = 1000

			for i = 1, 4 do
				local equipInfo = InfoEquip.getEquipOnHero(heroID, i)
				local equipLevel = 0

				if equipInfo then
					equipLevel = equipInfo.enhance_level
				end

				minEnhanceLevel = math.min(minEnhanceLevel, equipLevel)
			end

			print("$$$ fxxkCheck300", base_id, minEnhanceLevel, heroID)
			InfoFirstAchieve.fxxkCheck(base_id, minEnhanceLevel, heroID)
		end
	end
end

function InfoFirstAchieve.fxxkCheck380(petID)
	local base_id_arr = InfoFirstAchieve.getTypeList(380)

	if base_id_arr then
		for i, base_id in ipairs(base_id_arr) do
			local count, max, rewarded = InfoFirstAchieve.getProgress(base_id)

			if rewarded == 1 then
				return
			end

			if max <= count then
				return
			end

			local equips = InfoPet.getEquipListOnPet(petID)
			local minLevel = 1000

			for i = 1, GameConfig.max_pet_equip do
				local equipLevel = 0
				local equipID = InfoPet.getEquipOnPet(petID, i)

				if equipID then
					local equipData = CsvParser.getCsvData("pet_equip", equipID)
					equipLevel = equipData.level
				end

				minLevel = math.min(minLevel, equipLevel)
			end

			print("$$$ fxxkCheck380", base_id, minLevel, petID)
			InfoFirstAchieve.fxxkCheck(base_id, minLevel, petID)
		end
	end
end

function InfoFirstAchieve.getPaidRecord(index)
	return BitUtil.getBitByIndex(paid_reward_record, index)
end

function InfoFirstAchieve.getTargetPaidReward(id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "first_achieve_get_paid_reward")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("first_achieve_get_paid_reward", {
		id = id
	}, callback)
end

function InfoFirstAchieve.isPaid()
	return paid > 0
end

return InfoFirstAchieve
