local NAV_base = import(".NAV_base")
local NAV_dust_forge = class("NAV_dust_forge", NAV_base)

function NAV_dust_forge.open(npc)
	local ui = NAV_dust_forge.new(npc)

	return ui
end

function NAV_dust_forge:ctor(npc)
	NAV_dust_forge.super.ctor(self, npc, "nav_dust_forge")
end

function NAV_dust_forge:init()
	NAV_dust_forge.super.init(self)

	if not DEV_MODE then
		self:setButtonVisible(5, false)
	end
end

function NAV_dust_forge:onTap(index)
	NAV_dust_forge.super.onTap(self, index)

	if index == 1 then
		FRAME_dust_remake.open(self.npc)
	elseif index == 2 then
		FRAME_dust_replace.open(self.npc)
	elseif index == 3 then
		FRAME_dust_displace_enhance.open(self.npc)
	elseif index == 4 then
		FRAME_dust_refine.open(self.npc)
	elseif index == 5 and DEV_MODE then
		FRAME_dust_gm.open(self.npc)
	end
end

return NAV_dust_forge
