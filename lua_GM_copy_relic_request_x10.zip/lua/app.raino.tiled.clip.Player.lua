local Hero = import(".Hero")
local Player = class("Player", Hero)
Player.normalSpeed = 12
Player.fixedLight = 255

function Player:ctor()
	Player.super.ctor(self)

	self.isPlayer = true
	self.mapTouchEnabled = true
	self.fixedLight = Player.fixedLight
	self.isBlock = true
	self.train = {
		tail = 0,
		points = {},
		units = {},
		exUnits = {},
		prePos = {
			y = 0,
			x = 0
		}
	}
end

function Player:display(map, x, y)
	Player.super.display(self, map, x, y)
	Unit.setFocusUnit(self)

	self.train.prePos = {
		x = x,
		y = y
	}

	notify.dispatch("player_display", x, y)

	if OnlineCamp.isOnline() then
		self:refreshTitle()
	end
end

function Player:refreshTitle()
	local abyss_level = InfoDungeon.getAbyssMaxLevel()
	local medalArr = InfoUserShow.getMedals()
	local unionInfo = InfoUnion.getUnionInfo()

	self:setTitle(InfoUser.getNickName(), nil, abyss_level, nil, medalArr, unionInfo)
end

function Player:goFreeDirection(freeDirection)
	self.freeDirectionOrdered = freeDirection

	if self:isGoDirectionLocked() then
		return
	end

	self.inFreeDirectionMove = true
	self.moveAngle = freeDirection
	self.angle = self.moveAngle

	self:setAction("walk")
	MapFrameManager.startLoop(self, self.moveFreeDirection)

	self.moving = true

	self:changeTrainMoving()
end

function Player:stopFreeDirection(fromControl)
	if fromControl then
		self.freeDirectionOrdered = nil
	end

	self.inFreeDirectionMove = nil

	MapFrameManager.stopLoop(self, self.moveFreeDirection)
	self:setAction("idle")

	self.moving = false

	self:changeTrainMoving()
	self:stop(28)
end

function Player:moveFreeDirection(frame, passed, sharp)
	local x = self.x + math.cos(self.moveAngle) * self.speed * passed
	local y = self.y + math.sin(self.moveAngle) * self.speed * passed
	local tile = self.map:mapToTile(x, y)
	local trainUnits = self.train.units
	local preBlocks = {}

	if #trainUnits > 0 then
		for i = 1, #trainUnits do
			preBlocks[i] = trainUnits[i].isBlock
			trainUnits[i].isBlock = false
		end
	end

	if not tile or not tile:getWalkable(self.walkLevel, self) then
		x = self.x
		y = self.y
	end

	if #trainUnits > 0 then
		for i = 1, #trainUnits do
			trainUnits[i].isBlock = preBlocks[i]
		end
	end

	notify.dispatch("player_move", x, y)

	self.angle = math.atan2(y - self.y, x - self.x)
	self.x = x
	self.y = y

	self:draw()
	self:retile()
	self:checkTrain()
end

function Player:stopMoveAngle()
	MapFrameManager.stopLoop(self, self.moveAngle)
end

function Player:setGoDirectionLocked(tag, locked)
	local preLocked = self:isGoDirectionLocked()

	if locked then
		self.goDirectionLocked = self.goDirectionLocked or {}
		self.goDirectionLocked[tag] = true
	elseif self.goDirectionLocked then
		self.goDirectionLocked[tag] = nil
	end

	if self.goDirectionLocked and table.nums(self.goDirectionLocked) == 0 then
		self.goDirectionLocked = nil
	end

	if not preLocked and self:isGoDirectionLocked() then
		MapFrameManager.stopLoop(self, self.moveDirection)

		local preDirectionOrdered = self.directionOrdered

		self:stopDirection()

		self.directionOrdered = preDirectionOrdered
	end

	if not locked and not self:isGoDirectionLocked() then
		self:recoverGoDirection()
	end
end

function Player:checkGoDirectionLocked(tag)
	if self.goDirectionLocked then
		return self.goDirectionLocked[tag]
	end
end

function Player:clearGoDirectionLocked()
	self.goDirectionLocked = nil

	self:recoverGoDirection()
end

function Player:isGoDirectionLocked()
	return self.goDirectionLocked ~= nil
end

function Player:recoverGoDirection()
	if self.directionOrdered then
		self:goDirection(self.directionOrdered)
	end

	notify.dispatch("recover_godirection")
end

function Player:goDirection(direction)
	self.directionOrdered = direction

	if self:isGoDirectionLocked() then
		return
	end

	self.inDirectionMove = true
	local x, y = self:getDirectionPoint(direction)

	if not self.map.isBattle and not x then
		local trainUnits = self.train.units

		if #trainUnits > 0 then
			local preBlocks = {}

			for i, trainUnit in ipairs(trainUnits) do
				preBlocks[i] = trainUnit.isBlock
				trainUnit.isBlock = false
			end

			x, y = self:getDirectionPoint(direction)

			for i, trainUnit in ipairs(trainUnits) do
				trainUnit.isBlock = preBlocks[i]
			end
		end
	end

	if x then
		notify.dispatch("player_move", x, y)

		self.moveAngle = math.atan2(y - self.y, x - self.x)
		self.angle = self.moveAngle
		local distance = math.sqrt(math.pow(y - self.y, 2) + math.pow(x - self.x, 2))
		self.moveDirectionData = {
			step = 0,
			direction = direction,
			maxStep = distance / self.speed,
			startPoint = {
				x = self.x,
				y = self.y
			}
		}

		self:setAction("walk")
		MapFrameManager.startLoop(self, self.moveDirection)

		self.moving = true

		self:changeTrainMoving()
	end
end

function Player:stopDirection(fromControl)
	if fromControl then
		self.directionOrdered = nil
	end

	self.inDirectionMove = nil

	if self.moveDirectionData then
		self.moveDirectionData.direction = nil
	end
end

local directionTiles = {
	{
		1,
		1
	},
	{
		0,
		1
	},
	{
		-1,
		1
	},
	{
		-1,
		0
	},
	{
		-1,
		-1
	},
	{
		0,
		-1
	},
	{
		1,
		-1
	},
	{
		1,
		0
	}
}

function Player:checkSlipWalkPoint(direction)
	local legalDirection = nil

	if direction == 1 then
		legalDirection = self:compareSlipWalk({
			{
				2,
				2
			},
			{
				8,
				8
			}
		})
	elseif direction == 2 then
		legalDirection = self:compareSlipWalk({
			{
				8,
				2
			},
			{
				4,
				2
			}
		})
	elseif direction == 3 then
		legalDirection = self:compareSlipWalk({
			{
				4,
				4
			},
			{
				2,
				2
			}
		})
	elseif direction == 4 then
		legalDirection = self:compareSlipWalk({
			{
				6,
				4
			},
			{
				2,
				4
			}
		})
	elseif direction == 5 then
		legalDirection = self:compareSlipWalk({
			{
				6,
				6
			},
			{
				4,
				4
			}
		})
	elseif direction == 6 then
		legalDirection = self:compareSlipWalk({
			{
				4,
				6
			},
			{
				8,
				6
			}
		})
	elseif direction == 7 then
		legalDirection = self:compareSlipWalk({
			{
				6,
				6
			},
			{
				8,
				8
			}
		})
	elseif direction == 8 then
		legalDirection = self:compareSlipWalk({
			{
				6,
				8
			},
			{
				2,
				8
			}
		})
	end

	if legalDirection then
		local tileOffset = directionTiles[legalDirection[1]]
		local tile = self.map:getTile(self.tile.x + tileOffset[1], self.tile.y + tileOffset[2])

		return tile
	end
end

function Player:compareSlipWalk(directionArrayStack)
	local legalOne = nil

	for i, directionArray in ipairs(directionArrayStack) do
		if self:checkChainWalkable(self.tile, directionArray) then
			if legalOne then
				return nil
			else
				legalOne = directionArray
			end
		end
	end

	if not legalOne then
		for i, directionArray in ipairs(directionArrayStack) do
			if self:checkChainWalkable(self.tile, directionArray) then
				if legalOne then
					return nil
				else
					legalOne = directionArray
				end
			end
		end
	end

	return legalOne
end

function Player:checkChainWalkable(tile, directionArray, index)
	index = index or 1
	local direction = directionArray[index]

	if not self:checkCanMoveDirection(direction, tile) and not self:checkCanTeleportDirection(direction, tile) then
		return false
	end

	if #directionArray == index then
		return true
	else
		local tileOffset = directionTiles[direction]
		local checkTile = self.map:getTile(tile.x + tileOffset[1], tile.y + tileOffset[2])

		return self:checkChainWalkable(checkTile, directionArray, index + 1)
	end
end

function Player:checkCanTeleportDirection(direction, curTile)
	local eventData = MapEventManager.getEventByTile(curTile.x, curTile.y, "teleport")

	if eventData then
		local finData = MapEventManager.findLinkOne(eventData, "teleport")
		finData = finData or MapEventManager.findLinkOne(eventData, "go_next")

		if finData then
			local tileOffset = directionTiles[direction]
			local angle = math.atan2(finData.y - eventData.y, finData.x - eventData.x) * 180 / math.pi

			if angle < 0 then
				angle = angle + 360
			end

			local offsets = nil

			if angle >= 45 and angle < 135 then
				offsets = {
					0,
					1
				}
			elseif angle >= 135 and angle < 225 then
				offsets = {
					-1,
					0
				}
			elseif angle >= 225 and angle < 315 then
				offsets = {
					0,
					-1
				}
			else
				offsets = {
					1,
					0
				}
			end

			if tileOffset[1] == offsets[1] and tileOffset[2] == offsets[2] then
				return true
			end
		end
	end

	return false
end

function Player:checkCanMoveDirection(direction, curTile)
	curTile = curTile or self.tile
	local tileOffset = directionTiles[direction]

	if tileOffset[1] ~= 0 then
		local tile = self.map:getTile(curTile.x + tileOffset[1], curTile.y)

		if not tile or not tile:getWalkable(self.walkLevel, self) then
			return false, tile
		end

		if tileOffset[1] == -1 then
			if curTile:getBorder(0) then
				return false, tile
			end
		elseif tileOffset[1] == 1 and curTile:getBorder(2) then
			return false, tile
		end
	end

	if tileOffset[2] ~= 0 then
		local tile = self.map:getTile(curTile.x, curTile.y + tileOffset[2])

		if not tile or not tile:getWalkable(self.walkLevel, self) then
			return false, tile
		end

		if tileOffset[2] == -1 then
			if curTile:getBorder(3) then
				return false, tile
			end
		elseif tileOffset[2] == 1 and curTile:getBorder(1) then
			return false, tile
		end
	end

	if tileOffset[1] ~= 0 and tileOffset[2] ~= 0 then
		local tile = self.map:getTile(curTile.x + tileOffset[1], curTile.y + tileOffset[2])

		if not tile or not tile:getWalkable(self.walkLevel, self) then
			return false, tile
		end

		if tileOffset[1] == -1 then
			if tile:getBorder(2) then
				return false, tile
			end
		elseif tileOffset[1] == 1 and tile:getBorder(0) then
			return false, tile
		end

		if tileOffset[2] == -1 then
			if tile:getBorder(1) then
				return false, tile
			end
		elseif tileOffset[2] == 1 and tile:getBorder(3) then
			return false, tile
		end
	end

	return true
end

function Player:getDirectionPoint(direction)
	local tileOffset = directionTiles[direction]
	local can, blockTile = self:checkCanMoveDirection(direction)

	if can then
		local tile = self.map:getTile(self.tile.x + tileOffset[1], self.tile.y + tileOffset[2])

		if tile then
			local mapX, mapY = self.map:tileToMap(tile)

			return mapX, mapY
		end
	else
		if MapEventManager.checkTileHasTrigger(self.tile, "stand") then
			return
		end

		if blockTile then
			for k, unit in pairs(blockTile.unitMap) do
				if unit.type == "npc" and unit:isInteractive() then
					return
				end
			end
		end

		local tile = self:checkSlipWalkPoint(direction)

		if tile then
			local mapX, mapY = self.map:tileToMap(tile)

			return mapX, mapY
		end
	end

	return nil
end

function Player:moveDirection(frame, passed, sharp)
	local moveData = self.moveDirectionData
	local step = math.min(moveData.step + passed, moveData.maxStep)
	self.x = moveData.startPoint.x + math.cos(self.moveAngle) * self.speed * step * (global.speedPercent or 1)
	self.y = moveData.startPoint.y + math.sin(self.moveAngle) * self.speed * step * (global.speedPercent or 1)

	self:draw()
	self:retile()

	if moveData.maxStep <= step then
		local stopped = true

		if moveData.direction then
			local x, y = self:getDirectionPoint(moveData.direction)

			if x then
				notify.dispatch("player_move", x, y)

				self.moveAngle = math.atan2(y - self.y, x - self.x)
				self.angle = self.moveAngle
				local distance = math.sqrt(math.pow(y - self.y, 2) + math.pow(x - self.x, 2))
				moveData.step = moveData.step + passed - moveData.maxStep
				moveData.maxStep = distance / self.speed
				moveData.startPoint = {
					x = self.x,
					y = self.y
				}
				stopped = false
			end
		end

		if stopped then
			self.moveDirectionData = nil

			MapFrameManager.stopLoop(self, self.moveDirection)
			self:setAction("idle")

			self.moving = false

			self:changeTrainMoving()
			self:stop(28)
		end
	else
		moveData.step = step
	end

	self:checkTrain()
end

function Player:stopMoveDirection()
	MapFrameManager.stopLoop(self, self.moveDirection)
end

function Player:moveSection(x, y, alwaysWalkable)
	Player.super.moveSection(self, x, y, alwaysWalkable)
	notify.dispatch("player_move", x, y)
end

function Player:setMapTouchEnabled(enabled)
	self.mapTouchEnabled = enabled
end

function Player:onMapTouch(event, x, y)
	if self.map.isBattle then
		return
	end

	if not self.mapTouchEnabled then
		return
	end

	local mapX, mapY = self.map:screenToMap(x, y)
	local tile = self.map:mapToTile(mapX, mapY)

	if tile:getWalkable(self.walkLevel) and self:go(mapX, mapY) then
		self:createMoveMark(tile)
	end
end

function Player:createMoveMark(tile)
	self:removeMoveMark()

	local fixedX, fixedY = self.map:tileToMap(tile)
	local effect = Effect.new()

	effect:load("tap_arrow")

	effect.alwaysVisible = true

	effect:display(self.map, fixedX, fixedY)

	self.moveMark = effect
end

function Player:removeMoveMark()
	if self.moveMark then
		self.moveMark:destroy()

		self.moveMark = nil
	end
end

function Player:setData(data)
	Player.super.setData(self, data)

	self.speed = Player.normalSpeed
end

function Player:checkAutoSkill()
	if self.inDirectionMove then
		return false
	end

	return Player.super.checkAutoSkill(self)
end

function Player:battleThink()
	if self.inDirectionMove then
		return
	end

	return Player.super.battleThink(self)
end

function Player:moveLoop(frame, passed, sharp)
	Player.super.moveLoop(self, frame, passed, sharp)
	self:checkTrain()
end

function Player:jumpLoop(frame, passed, sharp)
	Player.super.jumpLoop(self, frame, passed, sharp)
	self:checkTrain()
end

function Player:setActive(active)
	Player.super.setActive(self, active)
end

function Player:go(x, y)
	if self.inDirectionMove then
		if global.debugGoFail then
			Log.debug("Player:go failure self.inDirectionMove")
		end

		return false
	end

	local result = Player.super.go(self, x, y)

	if not self.map.isBattle then
		if not result then
			local trainUnits = self.train.units

			if #trainUnits > 0 then
				local preBlocks = {}

				for i = 1, #trainUnits do
					preBlocks[i] = trainUnits[i].isBlock
					trainUnits[i].isBlock = false
				end

				result = Player.super.go(self, x, y)

				for i = 1, #trainUnits do
					trainUnits[i].isBlock = preBlocks[i]
				end
			end
		end

		local targetNpc, targetTile = nil

		if not result then
			targetTile = self.map:mapToTile(x, y)

			if targetTile and not targetTile:getWalkable(self.walkLevel, self, true) then
				for unitID, unit in pairs(targetTile.unitMap) do
					if unit.isBlock then
						if unit.type == "npc" then
							targetNpc = unit
						else
							targetNpc = nil

							break
						end
					end
				end
			end

			if targetNpc then
				local path, pathFound = self.map:findPath(self.tile, targetTile, self.walkLevel, self.size, function (tile)
					return self:checkMeleeTile(targetNpc, tile)
				end, self)

				if pathFound then
					result = self:goPath(path)
				end
			end
		end

		if not result and targetNpc then
			local trainUnits = self.train.units

			if #trainUnits > 0 then
				local preBlocks = {}

				for i = 1, #trainUnits do
					preBlocks[i] = trainUnits[i].isBlock
					trainUnits[i].isBlock = false
				end

				local path, pathFound = self.map:findPath(self.tile, targetTile, self.walkLevel, self.size, function (tile)
					return self:checkMeleeTile(targetNpc, tile)
				end, self)

				if pathFound then
					result = self:goPath(path)
				end

				for i = 1, #trainUnits do
					trainUnits[i].isBlock = preBlocks[i]
				end
			end
		end
	end

	self:changeTrainMoving()

	return result
end

function Player:goPath(path, alwaysWalkable)
	if self.inDirectionMove then
		Log.debug("goPath failed self.inDirectionMove:", self.inDirectionMove)

		return false
	end

	local result = Player.super.goPath(self, path, alwaysWalkable)

	if result then
		self.moving = true
	end

	self:changeTrainMoving()

	return result
end

function Player:stop(code)
	self:removeMoveMark()
	Player.super.stop(self, code)
	self:stopDirection()

	if self.map and not self.map.isBattle then
		self:changeTrainMoving()

		if self.tile and code ~= "beforeMove" then
			MapEventManager.tileTriggerStop(self.tile)
		end
	end

	self:syncOnlineMove(true)
end

local syncTimeThreshold = 1

function Player:syncOnlineMove(isStop)
	if not self.onlineSync then
		self.onlineSync = {
			time = 0
		}
	end

	if OnlineCamp.inRoom() then
		local now = Time.time()

		if (isStop or syncTimeThreshold <= now - self.onlineSync.time) and (self.tile.x ~= self.onlineSync.preX or self.tile.y ~= self.onlineSync.preY) then
			self.onlineSync.preX = self.tile.x
			self.onlineSync.preY = self.tile.y
			self.onlineSync.time = now

			OnlineCamp.move(self.tile.x, self.tile.y)
		end
	end
end

local TRAIN_MAX = 3

function Player:lockTrain(locked)
	self.trainLocked = locked or nil
end

function Player:setTrain(posArray)
	if not posArray or #posArray <= 1 then
		self:fillTrain()
	else
		self.train.tail = 0
		self.train.prePos = {
			x = posArray[1].x,
			y = posArray[1].y
		}
		self.train.points = posArray
	end
end

function Player:fillTrain()
	self.train.tail = 0
	self.train.prePos = {
		x = self.x,
		y = self.y
	}
	self.train.points = {}
	local step = Player.normalSpeed
	local trainRange = math.floor(self.map.ptPerTile / Player.normalSpeed)
	local trainAngle = self.angle + math.pi
	local cosValue = math.cos(trainAngle)
	local sinValue = math.sin(trainAngle)

	for i = 1, TRAIN_MAX * trainRange + 2 do
		local x = self.x + cosValue * step * i
		local y = self.y + sinValue * step * i
		local tile = self.map:mapToTile(x, y)

		if tile then
			local point = {
				x = x,
				y = y,
				d = self:getDir()
			}

			table.insert(self.train.points, point)
		end
	end
end

function Player:getTrainPoints()
	return self.train.points
end

function Player:checkTrain()
	local step = Player.normalSpeed
	local tail = self.train.tail
	local prePos = self.train.prePos
	local pos = {
		x = self.x,
		y = self.y
	}
	local distance = math.sqrt(math.pow(pos.y - prePos.y, 2) + math.pow(pos.x - prePos.x, 2))
	local angle = math.atan2(pos.y - prePos.y, pos.x - prePos.x)
	local allDis = tail + distance
	local addon = step - tail

	while step <= allDis do
		local ptX = math.floor(prePos.x + math.cos(angle) * addon)
		local ptY = math.floor(prePos.y + math.sin(angle) * addon)

		table.insert(self.train.points, 1, {
			x = ptX,
			y = ptY,
			d = self:getDir(angle)
		})

		allDis = allDis - step
		addon = addon + step
	end

	self.train.prePos = pos
	self.train.tail = allDis
	local trainRange = math.floor(self.map.ptPerTile / Player.normalSpeed)

	while #self.train.points > TRAIN_MAX * trainRange + 2 do
		table.remove(self.train.points, #self.train.points)
	end

	if self.trainLocked then
		return
	end

	self:moveTrain()
end

function Player:changeTrainMoving()
	if self.trainLocked then
		return
	end

	if self.map.isBattle then
		return
	end

	local units = self:getFullTrain()

	for i = 1, #units do
		local unit = units[i]
		local preAction = unit.action

		if self.moving then
			unit:setAction("walk")
		else
			unit:setAction("idle")
		end

		if preAction ~= unit.action then
			unit:randomizeFrame()
		end
	end
end

function Player:moveTrain()
	if self.trainLocked then
		return
	end

	if self.map.isBattle then
		return
	end

	local units = self:getFullTrain()

	for i = 1, #units do
		local unit = units[i]
		local trainRange = (self.map.ptPerTile * i - self.train.tail) / Player.normalSpeed
		local pointIndex = math.floor(trainRange)
		local offsetPercent = trainRange - pointIndex
		local point = self.train.points[math.min(#self.train.points, pointIndex)]
		local nextPoint = self.train.points[math.min(#self.train.points, pointIndex + 1)]

		if point == nil then
			point = {
				x = self.x,
				y = self.y,
				d = self:getDir()
			}
		end

		if nextPoint == nil then
			nextPoint = point
		end

		local x = point.x + (nextPoint.x - point.x) * offsetPercent
		local y = point.y + (nextPoint.y - point.y) * offsetPercent
		unit.x = x
		unit.y = y

		unit:setDir(point.d)
		unit:draw()
		unit:retile()
	end
end

function Player:cutTrain(length)
	while length < #self.train.units do
		table.remove(self.train.units, #self.train.units)
	end
end

function Player:removeDead()
	local deadArr = {}
	local loop = #self.train.units
	local i = 1

	while loop >= i do
		local unit = self.train.units[i]

		if unit.battleData.die then
			table.remove(self.train.units, i)

			loop = loop - 1

			table.insert(deadArr, unit)
		else
			i = i + 1
		end
	end

	return deadArr
end

function Player:regroupTrain(onComplete)
	local trainRange = math.floor(self.map.ptPerTile / Player.normalSpeed)
	local preSmooth = self.map.config.pathfinding.smoothLevel
	self.map.config.pathfinding.smoothLevel = 2
	Map.NO_UNIT_BLOCK = true
	local units = self:getFullTrain()

	for i, unit in ipairs(units) do
		unit.speed = Player.normalSpeed
		local point = self.train.points[math.min(#self.train.points, trainRange * i)]

		if point == nil then
			point = {
				x = self.x,
				y = self.y,
				d = self:getDir()
			}
		end

		if unit:go(point.x, point.y) then
			local function afterPathFinished()
				unit:setDir(point.d)
			end

			unit:setPathFinishedCallback(afterPathFinished)
		end
	end

	self.map.config.pathfinding.smoothLevel = preSmooth

	self:setGoDirectionLocked("regroupTrain", true)

	local testRegroupComplete = nil

	function testRegroupComplete(obj, frame, passed, sharp)
		local allStopped = true

		for i, unit in ipairs(units) do
			if units[i].moving then
				allStopped = false

				break
			end
		end

		if allStopped then
			self:clearGoDirectionLocked()

			Map.NO_UNIT_BLOCK = false

			MapFrameManager.stopLoop(self, testRegroupComplete)

			if onComplete then
				onComplete()
			end
		end
	end

	MapFrameManager.startLoop(self, testRegroupComplete)
end

function Player:resetTrain()
	local trainRange = math.floor(self.map.ptPerTile / Player.normalSpeed)
	local units = self:getFullTrain()

	for i, unit in ipairs(units) do
		unit.speed = Player.normalSpeed
		local point = self.train.points[math.min(#self.train.points, trainRange * i)]

		if point == nil then
			point = {
				x = self.x,
				y = self.y,
				d = self:getDir()
			}
		end

		unit:draw(point.x, point.y, true)
		unit:setDir(point.d)
	end
end

function Player:getFullTrain()
	local list = {}

	for i = 1, #self.train.units do
		table.insert(list, self.train.units[i])
	end

	for i = 1, #self.train.exUnits do
		table.insert(list, self.train.exUnits[i])
	end

	return list
end

function Player:addToTrain(unit, noMove)
	unit.inTrain = true

	table.insert(self.train.units, unit)

	if not noMove then
		self:moveTrain()
		self:changeTrainMoving()
	end
end

function Player:addToTrainEx(unit, noMove)
	unit.inTrain = true

	table.insert(self.train.exUnits, unit)

	if not noMove then
		self:moveTrain()
		self:changeTrainMoving()
	end
end

function Player:removeFromTrainEx(unit)
	for i = 1, #self.train.exUnits do
		if self.train.exUnits[i] == unit then
			unit.inTrain = false

			table.remove(self.train.exUnits, i)
		end
	end
end

function Player:getTrainUnits()
	local trainList = {
		self
	}

	for i = 1, #self.train.units do
		local unit = self.train.units[i]

		table.insert(trainList, unit)
	end

	return trainList
end

function Player:getTrainTails()
	return self.train.units
end

function Player:removeTrainTails()
	for i = 1, #self.train.units do
		local unit = self.train.units[i]

		unit:removeSelf()
	end

	self.train.units = {}
end

function Player:removeFromTrain(unit)
	for i = 1, #self.train.units do
		if unit == self.train.units[i] then
			table.remove(self.train.units, i)
			unit:removeSelf()

			return
		end
	end
end

function Player:onBattleOver()
	Player.super.onBattleOver(self)
	MapEventManager.tileTriggerRetile(self, nil, self.tile)
end

function Player:retile()
	local preTile = self.tile

	Player.super.retile(self)

	if preTile ~= self.tile and not self.map.isBattle then
		MapEventManager.tileTriggerRetile(self, preTile, self.tile)
	end

	local tile = self.tile

	if preTile == tile then
		return
	end

	local listenRange = 1
	local refresh = true

	if preTile ~= nil then
		refresh = false
		local dirtyX = preTile.x - tile.x
		local dirtyY = preTile.y - tile.y
		local minX = preTile.x - listenRange
		local maxX = preTile.x + listenRange
		local minY = preTile.y - listenRange
		local maxY = preTile.y + listenRange

		MapUtils.dirtyRect(dirtyX, dirtyY, minX, maxX, minY, maxY, handler(self, self.unlistenTile), refresh)
	end

	local dirtyX, dirtyY = nil

	if not refresh then
		dirtyX = tile.x - preTile.x
		dirtyY = tile.y - preTile.y
	end

	local minX = tile.x - listenRange
	local maxX = tile.x + listenRange
	local minY = tile.y - listenRange
	local maxY = tile.y + listenRange

	MapUtils.dirtyRect(dirtyX, dirtyY, minX, maxX, minY, maxY, handler(self, self.listenTile), refresh)
	notify.dispatch("player_retile", x, y)

	if InfoDungeon.isCamp() then
		self:checkFarmHarvest()
	elseif not InfoDungeon.isHome() then
		self:checkDropItem()
	end

	self:syncOnlineMove()
end

function Player:checkFarmHarvest()
	if not self.tile then
		return
	end

	if DramaManager.opening then
		return
	end

	if InfoFarm.isHarvestLocked() then
		return
	end

	local harvestPos = nil

	for x = self.tile.x - 1, self.tile.x + 1 do
		for y = self.tile.y - 1, self.tile.y + 1 do
			local tile = self.map:getTile(x, y)

			if tile then
				for k, unit in pairs(tile.unitMap) do
					if unit.type == "npc" and unit.data.building == InfoBuilding.TAG.FARM_TILE and unit.farmPos and unit.farmInfo and unit.farmInfo.isHarvest then
						harvestPos = unit.farmPos

						break
					end
				end
			end

			if harvestPos then
				break
			end
		end

		if harvestPos then
			break
		end
	end

	if harvestPos then
		global.resource:lockResource(GameConfig.farm_item)
		InfoFarm.tryHarvest(harvestPos)
	end
end

function Player:autopickDropItem(delay)
	Looper.setTimeout(function ()
		self:delayAutopickDropItem()
	end, delay or 15, global.map)
end

function Player:delayAutopickDropItem()
	local dropItems = ClipOnMap.getUnitList("dropItem")
	local pickItems = {}

	for i, dropItem in ipairs(dropItems) do
		if dropItem.dropInfo then
			local itemID = dropItem.dropInfo.base_id
			local itemCSV = CsvParser.getCsvData("item", itemID)

			if itemCSV.is_precious ~= 1 then
				table.insert(pickItems, dropItem)
			end
		end
	end

	if #pickItems > 0 then
		self:pickDropItems(pickItems, true)
	end
end

function Player:checkDropItem()
	if WarMachine.event_on then
		return
	end

	if WarMachine.mapLocked then
		return
	end

	if not self.tile then
		return
	end

	if DramaManager.opening then
		return
	end

	local dropItems = {}

	for x = self.tile.x - 1, self.tile.x + 1 do
		for y = self.tile.y - 1, self.tile.y + 1 do
			local tile = self.map:getTile(x, y)

			if tile then
				for k, unit in pairs(tile.unitMap) do
					if unit.type == "npc" then
						if unit.npcType == Npc.TYPE.RELIC then
							if unit.data.auto_pick == 1 and not unit:isHidden() then
								unit:openRelic()
							end
						elseif unit.npcType == Npc.TYPE.GATHER and unit.data.auto_pick == 1 and unit.data.is_bag ~= 1 and unit:isInteractive() then
							unit:openGather()
						end
					end
				end

				for k, dropItem in pairs(tile.otherMap) do
					if dropItem.type == "dropItem" then
						table.insert(dropItems, dropItem)
					end
				end
			end
		end
	end

	if #dropItems > 0 then
		self:pickDropItems(dropItems)
	end
end

function Player:pickDropItems(dropItems, isAuto)
	local dropItemMapByEvent = {}

	for i, dropItem in ipairs(dropItems) do
		if dropItem.type == "dropItem" and not dropItem.getLocked then
			dropItem.getLocked = true
			local dropInfo = dropItem.dropInfo
			local eventIndex = dropItem.eventIndex

			if eventIndex then
				if not dropItemMapByEvent[eventIndex] then
					dropItemMapByEvent[eventIndex] = {
						itemMap = {},
						units = {}
					}
				end

				table.insert(dropItemMapByEvent[eventIndex].units, dropItem)

				local dropItemMap = dropItemMapByEvent[eventIndex].itemMap

				if not dropItemMap[dropInfo.base_id] then
					dropItemMap[dropInfo.base_id] = 0
				end

				dropItemMap[dropInfo.base_id] = dropItemMap[dropInfo.base_id] + dropInfo.num
			end
		end
	end

	for eventIndex, v in pairs(dropItemMapByEvent) do
		local itemMap = v.itemMap
		local units = v.units

		for i, dropItem in ipairs(units) do
			local dropInfo = dropItem.dropInfo
			local true_id = InfoItem.getConvertID(dropInfo.base_id)

			global.resource:lockResource(true_id)
			global.resource:prepareTempResource(true_id)
		end

		local function onSuccess()
			local flyIndex = 0

			for i, dropItem in ipairs(units) do
				local dropInfo = dropItem.dropInfo

				if InfoItem.isPrecious(dropInfo.base_id) then
					self:stop()
					dropItem:flyToPrecious()
				else
					Looper.setTimeout(function ()
						dropItem:flyToResource(function ()
							global.resource:unlockResource(InfoItem.getConvertID(dropInfo.base_id))
						end)

						local effectGen = dropItem:getEffectGen()

						if effectGen then
							local effect = effectGen:addEffect(MiscConfig.effect_itemFly)

							effect:setScale(0.5)

							effect.playSkip = 0
						end
					end, flyIndex * (isAuto and 2 or 5), self)

					flyIndex = flyIndex + 1
				end

				dropItem:removeFromMap()
			end
		end

		local function onFailure()
			for i, dropItem in ipairs(units) do
				dropItem.getLocked = nil
				local dropInfo = dropItem.dropInfo

				global.resource:unlockResource(InfoItem.getConvertID(dropInfo.base_id))
			end
		end

		InfoDungeon.getDropItem(eventIndex, itemMap, onSuccess, onFailure)
	end
end

function Player:listenTile(x, y)
	local tile = self.map:getTile(x, y)

	if tile and not MapEventManager.isNpcDisable(tile) then
		tile:addUnitChangeListener(self, self.onTileNpcChanged, true)
	end
end

function Player:unlistenTile(x, y)
	local tile = self.map:getTile(x, y)

	if tile and not MapEventManager.isNpcDisable(tile) then
		tile:removeUnitChangeListener(self, self.onTileNpcChanged, true)
	end
end

function Player:checkNpc(npc)
	local listenRange = 1

	if math.abs(npc.tile.x - self.tile.x) <= listenRange and math.abs(npc.tile.y - self.tile.y) <= listenRange then
		self:onTileNpcChanged(npc, true)
	end
end

function Player:checkNearNpc()
	if self.nearNpcStack then
		for i, npc in ipairs(self.nearNpcStack) do
			if npc.focusRelease then
				npc:focusRelease()
			else
				print("$$$ err focusRelease", npc.type, npc.name)
			end
		end
	end

	self.nearNpcStack = {}
	self.nearNpcCount = {}

	for x = self.tile.x - 1, self.tile.x + 1 do
		for y = self.tile.y - 1, self.tile.y + 1 do
			local tile = self.map:getTile(x, y)

			if tile and not MapEventManager.isNpcDisable(tile) then
				for k, unit in pairs(tile.unitMap) do
					if unit.type == "npc" and unit:isInteractive() and not unit:isHidden() then
						if not self.nearNpcCount[unit.id] then
							table.insert(self.nearNpcStack, unit)
							unit:focusTo(self)
							unit:onNear()

							self.nearNpcCount[unit.id] = 1
						else
							self.nearNpcCount[unit.id] = self.nearNpcCount[unit.id] + 1
						end
					elseif unit.type == "monster" and (unit.data.is_negative == 1 or InfoDungeon.getSneakPoint() > 0) then
						if not self.nearNpcCount[unit.id] then
							table.insert(self.nearNpcStack, unit)

							self.nearNpcCount[unit.id] = 1
						else
							self.nearNpcCount[unit.id] = self.nearNpcCount[unit.id] + 1
						end
					end
				end
			end
		end
	end

	self:npcChanged(true)
end

function Player:onTileNpcChanged(unit, addOrRemove)
	if unit.type == "npc" and not unit.inTrain then
		self.nearNpcStack = self.nearNpcStack or {}
		self.nearNpcCount = self.nearNpcCount or {}

		if addOrRemove and unit:isInteractive() and not unit:isHidden() then
			if not self.nearNpcCount[unit.id] then
				table.insert(self.nearNpcStack, unit)
				unit:focusTo(self)
				unit:onNear()

				self.nearNpcCount[unit.id] = 1
			else
				self.nearNpcCount[unit.id] = self.nearNpcCount[unit.id] + 1
			end
		elseif self.nearNpcCount[unit.id] and self.nearNpcCount[unit.id] > 1 then
			self.nearNpcCount[unit.id] = self.nearNpcCount[unit.id] - 1
		else
			if self.nearNpcStack then
				for i = 1, #self.nearNpcStack do
					if self.nearNpcStack[i] == unit then
						table.remove(self.nearNpcStack, i)

						break
					end
				end
			end

			if unit.focusRelease then
				unit:focusRelease()
			end

			self.nearNpcCount[unit.id] = nil
		end

		self:npcChanged()
	elseif unit.type == "monster" and (unit.data.is_negative == 1 or InfoDungeon.getSneakPoint() > 0) then
		self.nearNpcStack = self.nearNpcStack or {}
		self.nearNpcCount = self.nearNpcCount or {}

		if addOrRemove then
			if not self.nearNpcCount[unit.id] then
				table.insert(self.nearNpcStack, unit)

				self.nearNpcCount[unit.id] = 1
			else
				self.nearNpcCount[unit.id] = self.nearNpcCount[unit.id] + 1
			end
		elseif self.nearNpcCount[unit.id] and self.nearNpcCount[unit.id] > 1 then
			self.nearNpcCount[unit.id] = self.nearNpcCount[unit.id] - 1
		else
			if self.nearNpcStack then
				for i = 1, #self.nearNpcStack do
					if self.nearNpcStack[i] == unit then
						table.remove(self.nearNpcStack, i)

						break
					end
				end
			end

			self.nearNpcCount[unit.id] = nil
		end

		self:npcChanged()
	end
end

function Player:addNearNpc(unit)
	self:onTileNpcChanged(unit, true)
end

function Player:onNpcDisable(unit)
	if unit.eventsetArr then
		self:npcChanged(true)

		return
	end

	if self.nearNpcStack then
		for i = 1, #self.nearNpcStack do
			if self.nearNpcStack[i] == unit then
				table.remove(self.nearNpcStack, i)
			end
		end
	end

	if unit.focusRelease then
		unit:focusRelease()
	end

	if self.nearNpcCount and self.nearNpcCount[unit.id] then
		self.nearNpcCount[unit.id] = nil
	end

	self:npcChanged()
end

function Player:setNpcNavDisabled(disabled)
	if disabled == false then
		disabled = nil
	end

	if self.npcNavDisabled ~= disabled then
		self.npcNavDisabled = disabled

		if not self.npcNavDisabled then
			self:npcChanged(true)
		else
			notify.dispatch("near_npc_change", {}, true)
		end
	end
end

function Player:npcChanged(force)
	Looper.clearTimeout(self.delayNpcChangedID)

	self.delayNpcChangedID = Looper.setTimeout(function ()
		self:delayNpcChanged(force)
	end, 1, self)
end

function Player:delayNpcChanged(force)
	local preDispatched = ""

	if self.dispatchedNpcStack then
		for i = 1, #self.dispatchedNpcStack do
			if self.dispatchedNpcStack[i].id then
				preDispatched = preDispatched .. "_" .. self.dispatchedNpcStack[i].id
			end
		end
	end

	local toDispatched = ""
	local toDispatchedStack = {}

	if not MapEventManager.isNpcDisable(self.tile) and not self.npcNavDisabled and self.nearNpcStack then
		for i, npc in ipairs(self.nearNpcStack) do
			if npc.id then
				toDispatched = toDispatched .. "_" .. npc.id

				table.insert(toDispatchedStack, npc)
			end
		end
	end

	if force or preDispatched ~= toDispatched then
		self.dispatchedNpcStack = toDispatchedStack

		notify.dispatch("near_npc_change", toDispatchedStack, force)
	end
end

function Player:setFrame(action, direction, frame)
	action, direction, frame = Player.super.setFrame(self, action, direction, frame)

	if Sound.isStepSound() and self.map and not self.map.isBattle and action == "walk" then
		if frame == 1 then
			Sound.playSound("step")
		elseif frame == 4 then
			Sound.playSound("step")
		end
	end
end

return Player
