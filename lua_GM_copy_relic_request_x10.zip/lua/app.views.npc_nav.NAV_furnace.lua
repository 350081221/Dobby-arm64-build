local NAV_base = import(".NAV_base")
local NAV_furnace = class("NAV_furnace", NAV_base)

function NAV_furnace.open(npc)
	local ui = NAV_furnace.new(npc)

	return ui
end

function NAV_furnace:ctor(npc)
	NAV_furnace.super.ctor(self, npc, "nav_furnace")
end

function NAV_furnace:init()
	NAV_furnace.super.init(self)
	self:setBuildingLvupIndex(3)

	local index = 1
	local ui = self.buttons[index].ui

	ui:createBarByTag("progress", NAV_base.COLOR.HIGH, true)

	local index = 2
	local ui = self.buttons[index].ui
	local bg1 = ui:getComponentByTag("bg1")

	bg1:setOpacity(100)
	ui:createLabelOnFlag("flag_mine", InfoFurnace.getMineNum())

	local costPic = IconManager.getItemIcon(GameConfig.coin_item)
	local icon = ui:createIconOnFlag("flag_icon", costPic, 100, true)
	local shadow = ui:createIconOnFlag("flag_shadow", costPic, 90, true)

	shadow:setColor(cc.c3b(0, 0, 0))
	shadow:setOpacity(100)

	local style = {}
	local speedup = 0

	if InfoOrder.inSeason() then
		speedup = speedup + InfoOrder.getSeasonFunc(2) / 100
		style.color = cc.c4b(16, 120, 47, 255)
	end

	local plusData = InfoBuilding.getPlusData(InfoBuilding.TAG.FURNACE, 302)

	if plusData then
		speedup = speedup + plusData.value1 / 100
	end

	local speed = InfoFurnace.getSpeed()
	local texts = {
		speed,
		"(+" .. speedup * 100 .. "%)"
	}
	local speedStyle = nil

	if speedup > 0 then
		speedStyle = {
			size = 16,
			color = Style.deepGreen
		}
	end

	local styles = {
		[2] = speedStyle
	}

	ui:createLabelGroupOnFlag("flag_speed", texts, styles, {
		align = Style.right
	})
	self:addEnterFrame("fresh", function ()
		self:refresh()
	end)

	local index = 4
	local funcCSV = InfoFunction.checkFuncOpen(10070)

	if funcCSV then
		self:setButtonVisible(index, true)

		local ui = self.buttons[index].ui

		self:setButtonName(ui, funcCSV.name)
	else
		self:setButtonVisible(index, false)
	end
end

function NAV_furnace:refresh()
	local index = 2
	local ui = self.buttons[index].ui
	local timeLeft, timeTotal = InfoFurnace.getTime()
	local cash, cashMax = InfoFurnace.getCash()

	ui:createLabelOnFlag("flag_cash", StringUtil.simplifyNumber(math.max(0, cash)))

	local index = 1
	local ui = self.buttons[index].ui

	if cashMax > 0 then
		ui:setBarProgressByTag("progress", math.min(1, cash / cashMax))
	else
		ui:setBarProgressByTag("progress", 0)
	end

	local timeLeft, timeTotal = InfoFurnace.getTime()

	if timeLeft > 0 then
		ui:createLabelOnFlag("flag_time", Time.format(timeLeft))
	else
		ui:createLabelOnFlag("flag_time", Localization.getSrcText("已满"))
	end
end

function NAV_furnace:onTap(index)
	NAV_furnace.super.onTap(self, index)

	if index == 1 then
		local cash, cashMax = InfoFurnace.getCash()

		if cash > 0 then
			InfoBuilding.playOpenSfx(InfoBuilding.TAG.FURNACE)
			global.resource:lockResource(GameConfig.coin_item)
			InfoFurnace.harvest(function (rcvData)
				if rcvData.num > 0 then
					self:flyCoins(rcvData.num)
				end
			end)
		else
			Alert.open(Localization.getSrcText("没有可提取的金币"))
		end
	elseif index == 2 then
		FRAME_furnace_detail.open()
	elseif index == 4 then
		FRAME_building_plus.open(self.npc)
	end
end

local furnaceAnimationHandler = nil

function NAV_furnace:flyCoins(num)
	local showNum = math.pow(num, 0.6)
	showNum = math.ceil(math.max(1, math.pow(showNum / 100, 0.5)) * 10)
	showNum = math.min(showNum, num)
	local centerX, centerY = self.npc:getCenter()
	local items = {}
	local fper = num / showNum
	local nPer = math.floor(fper)
	local fAdd = 0
	local nAdd = 0

	for i = 1, showNum do
		local value = nPer
		fAdd = fAdd + fper - nPer

		if fAdd > 1 then
			value = value + 1
			fAdd = fAdd - 1
		end

		nAdd = nAdd + value

		if i == showNum then
			value = num - nAdd
		end

		table.insert(items, {
			type = DropManager.TYPE.ITEM,
			info = {
				base_id = GameConfig.coin_item,
				num = value
			}
		})
	end

	local npc = self.npc

	local function delayIdle()
		if furnaceAnimationHandler then
			Looper.clearTimeout(furnaceAnimationHandler)
		end

		furnaceAnimationHandler = Looper.setTimeout(function ()
			npc:setAction("idle")
		end, 12)
	end

	local isOver = false
	local isOpened = false

	npc:setAction("open", 1, function ()
		isOpened = true

		npc:setAction("opened")

		if isOver then
			delayIdle()
		end
	end)
	global.ui:flyCoins(cc.p(centerX, centerY), items, function ()
		isOver = true

		if isOpened then
			delayIdle()
		end
	end)
end

return NAV_furnace
