local LIST = import("...ui.List")
local LIST_bag = class("LIST_bag", LIST)

function LIST_bag:ctor(rect, cols, direction)
	direction = direction or List.DIRECTION_VERTICAL

	LIST_bag.super.ctor(self, rect, direction or List.DIRECTION_VERTICAL)
	self:setCols(cols or 5)
	self:setCellName("cell_bag")
	self:setSpace(5, 5)

	self.alwaysShowNumber = true

	if direction == List.DIRECTION_VERTICAL then
		self:setCellSize(cc.size(self.touchRect.width, 100))
	else
		self:setCellSize(cc.size(100, self.touchRect.height))
	end

	self.compareEquipScore = {}
end

function LIST_bag:setAlwaysShowNumber(b)
	self.alwaysShowNumber = b
end

function LIST_bag:setItems(datas, keepOffset, compareHero)
	self.compareHero = compareHero

	if compareHero then
		self.compareEquipScore = {}
	end

	LIST_bag.super.setItems(self, datas, keepOffset)
end

function LIST_bag:onCellInit(ui, data)
	if not ui.slot then
		ui.slot = DropSlot.new(ui:getFlagByTag("flag_slot"), "slot_01")

		ui:addChild(ui.slot, 100)
	end

	ui.slot:setAlwaysShowNumber(self.alwaysShowNumber and data.type == DropManager.TYPE.ITEM)

	local isNewEquip = data.type == DropManager.TYPE.EQUIP and data.info.id == nil or data.type == DropManager.TYPE.SIGIL and data.info.id == nil
	local new = ui:getComponentByTag("new")

	new:setFrame(Localization.getNewFrame())
	new:setVisible(isNewEquip)

	if isNewEquip then
		new:setLocalZOrder(200)
		Style.makeShining(new, 128, 255, 0.5)
	else
		transition.stopTarget(new)
	end

	self:refreshEquipUp(ui, data)
	ui.slot:setDrop(data.type, data.info)
	ui.slot:setVisible(not empty(data.type))

	local locker = ui:getComponentByTag("locker")

	locker:setVisible(data.locked)
	self:onCellSelected(ui, data, false)
end

function LIST_bag:refreshEquipUp(ui, data)
	if data.type == DropManager.TYPE.EQUIP and self.compareHero and InfoEquip.checkEquipForHero(self.compareHero, data.info) then
		local equipCSV = CsvParser.getCsvData("equip", data.info.base_id)
		local compareScore = self.compareEquipScore[equipCSV.equip_pos]

		if compareScore == nil then
			local compareEquip = InfoEquip.getEquipOnHero(self.compareHero.id, equipCSV.equip_pos)

			if compareEquip then
				compareScore = InfoEquip.getScore(compareEquip, global.compareBase)
			else
				compareScore = -1
			end

			self.compareEquipScore[equipCSV.equip_pos] = compareScore
		end

		local upPercent = 0

		if compareScore ~= -1 then
			local selfScore = InfoEquip.getScore(data.info, global.compareBase)
			upPercent = (selfScore - compareScore) / compareScore
		else
			upPercent = 1
		end

		local max = math.min(3, math.ceil(upPercent / MiscConfig.UP_PERCENT))

		for i = 1, 3 do
			local up = ui:getComponentByTag("up" .. i)
			local isVisible = upPercent > (i - 1) * MiscConfig.UP_PERCENT

			transition.stopTarget(up)
			up:setVisible(isVisible)

			if isVisible then
				up:setLocalZOrder(200)

				local posY = ui:getComponentByTag("up" .. i + 3 - max).originalY

				up:setPos(nil, posY)
				Style.makeShining(up, 50, nil, 0.2, 1.3, 0.2 * (i - 1))
			end
		end
	else
		local isOver = false

		if data.type == DropManager.TYPE.ITEM and self.compareHero and self.compareHero.food_count_1 then
			local itemCSV = CsvParser.getCsvData("item", data.info.base_id)

			if itemCSV.type == GameConfig.pet_equip_type then
				isOver = true
				local equipSV = CsvParser.getCsvData("pet_equip", data.info.base_id)
				local compareScore = self.compareEquipScore[equipSV.class]

				if compareScore == nil then
					local compareEquip = InfoPet.getEquipOnPet(self.compareHero, equipSV.class)

					if compareEquip then
						compareScore = InfoPet.getEquipScore(compareEquip)
					else
						compareScore = -1
					end

					self.compareEquipScore[equipSV.class] = compareScore
				end

				local upPercent = 0

				if compareScore ~= -1 then
					local selfScore = InfoPet.getEquipScore(data.info.base_id)
					upPercent = (selfScore - compareScore) / compareScore
				else
					upPercent = 1
				end

				local max = math.min(3, math.ceil(upPercent / MiscConfig.UP_PERCENT))

				for i = 1, 3 do
					local up = ui:getComponentByTag("up" .. i)
					local isVisible = upPercent > (i - 1) * MiscConfig.UP_PERCENT

					transition.stopTarget(up)
					up:setVisible(isVisible)

					if isVisible then
						up:setLocalZOrder(200)

						local posY = ui:getComponentByTag("up" .. i + 3 - max).originalY

						up:setPos(nil, posY)
						Style.makeShining(up, 50, nil, 0.2, 1.3, 0.2 * (i - 1))
					end
				end
			end
		end

		if not isOver then
			for i = 1, 3 do
				local up = ui:getComponentByTag("up" .. i)

				transition.stopTarget(up)
				up:setVisible(false)
			end
		end
	end
end

function LIST_bag:onCellSelected(ui, data, selected)
	ui.slot:setSelected(selected)
	ui:getComponentByTag("selected"):setVisible(selected)
end

function LIST_bag:checkPickable(ui, data, x, y)
	if HintManager.opening then
		return false
	end

	return data.type ~= nil and data.type ~= DropManager.TYPE.NONE
end

function LIST_bag:getPickNode(cell)
	if cell then
		return cell.slot
	end
end

function LIST_bag:onCellPicked(ui, data, picked)
	local new = ui:getComponentByTag("new")

	if picked then
		new:setVisible(false)

		for i = 1, 3 do
			local up = ui:getComponentByTag("up" .. i)

			transition.stopTarget(up)
			up:setVisible(false)
		end
	else
		local isNewEquip = data.type == DropManager.TYPE.EQUIP and data.info.id == nil or data.type == DropManager.TYPE.SIGIL and data.info.id == nil

		new:setVisible(isNewEquip)
		self:refreshEquipUp(ui, data)
	end
end

return LIST_bag
