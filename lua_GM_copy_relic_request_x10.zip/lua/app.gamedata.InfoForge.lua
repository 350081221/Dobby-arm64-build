local InfoForge = {
	getForgeList = function (class)
		local list = CsvParser.getCsvList("forge", nil, {
			class = class
		})
		local groupList = {}
		local groupMap = {}

		for i, row in ipairs(list) do
			if Condition.checkSheet(row, "cond_type_", "cond_value_") then
				if not groupMap[row.group_id] then
					groupMap[row.group_id] = {
						row
					}

					table.insert(groupList, groupMap[row.group_id])
				else
					table.insert(groupMap[row.group_id], row)
				end
			end
		end

		return groupList
	end
}

function InfoForge.forge(forgeID, onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Http.request("forge/forge", {
		forge_id = forgeID
	}, callback)
end

function InfoForge.rune(equipID, runeID1, runeID2, onSuccess, onFailure)
	if empty(runeID1) and empty(runeID2) then
		Log.warn("InfoForge.rune need rune")

		return
	end

	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure()
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Http.request("forge/rune", {
		equip_id = equipID,
		rune_id_1 = runeID1 or 0,
		rune_id_2 = runeID2 or 0
	}, callback)
end

function InfoForge.getRuneCost(runeID1, runeID2)
	local runeArr = {
		runeID1,
		runeID2
	}
	local costArr = {}
	local costMap = {}

	for i, runeID in ipairs(runeArr) do
		local runeData = CsvParser.getCsvData("item", runeID)
		local arr = SheetUtil.getColumnList(runeData, {
			"rune_cost_id_",
			"rune_cost_num_"
		}, {
			"id",
			"num"
		})

		for j, cost in ipairs(arr) do
			if not costMap[cost.id] then
				costMap[cost.id] = cost.num

				table.insert(costArr, {
					id = cost.id
				})
			else
				costMap[cost.id] = costMap[cost.id] + cost.num
			end
		end
	end

	for i, v in ipairs(costArr) do
		v.num = costMap[v.id]
	end

	return costArr
end

function InfoForge.getForgeByEquip(equipID)
	local list = CsvParser.getCsvList("forge")

	for i, row in ipairs(list) do
		if row.product_id == equipID then
			return row
		end
	end
end

function InfoForge.getRuneList(existedMap)
	local list = InfoItem.getBagList(2, 6)
	local newList = {}

	for i = 1, #list do
		local id = list[i].base_id
		local num = InfoItem.getNum(id)

		if existedMap and existedMap[id] then
			num = num - existedMap[id]
		end

		if num > 0 then
			table.insert(newList, {
				id = id,
				num = num
			})
		end
	end

	return newList
end

function InfoForge.getCookList()
	local list = CsvParser.getCsvList("forge", nil, {
		catalog = 2
	})
	local cookList = {}

	for i, row in ipairs(list) do
		if Condition.checkSheet(row, "cond_type_", "cond_value_") then
			table.insert(cookList, row)
		end
	end

	return cookList
end

return InfoForge
