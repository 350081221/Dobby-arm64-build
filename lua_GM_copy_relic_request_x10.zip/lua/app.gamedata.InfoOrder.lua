local InfoOrder = {}
local ONCE = {
	FIRST = 1
}
InfoOrder.ONCE = ONCE
local rawData, requestLocked = nil
local createOrderSpMap = {}

function InfoOrder.init()
	Connection.listen("order_sync", InfoOrder.sync)
	Connection.listen("order_done", InfoOrder.done)
end

app:addToAppEnterCall(InfoOrder.init)

function InfoOrder.getCurrencyIso()
	local data = CsvParser.getCsvData("rmb_currency", global.currency)

	return data.iso
end

function InfoOrder.getCurrencyCode()
	local data = CsvParser.getCsvData("rmb_currency", global.currency)

	return data.code
end

function InfoOrder.getCost(rmb_type, id)
	local data = CsvParser.getCsvData("rmb_cost", rmb_type .. "_" .. id)

	if not empty(global.fixed_currency) then
		local fixedCost = data[global.fixed_currency]

		if not empty(fixedCost) then
			return fixedCost
		end
	end

	return data[global.currency]
end

function InfoOrder.getCost2(goodsID)
	local data = CsvParser.getCsvData("rmb_cost", goodsID)

	if not empty(global.fixed_currency) then
		local fixedCost = data[global.fixed_currency]

		if not empty(fixedCost) then
			return fixedCost
		end
	end

	return data[global.currency]
end

function InfoOrder.getCostOrigin(rmb_type, id)
	local data = CsvParser.getCsvData("rmb_cost_origin", rmb_type .. "_" .. id, nil, true)

	if data and not empty(data[global.currency]) then
		return data[global.currency]
	end
end

function InfoOrder.getGiftCost(sheet, id)
	local data = CsvParser.getCsvData("rmb_gift", sheet .. "_" .. id)

	return data[global.currency]
end

function InfoOrder.getAfSum(total_pay_100)
	local csvList = CsvParser.getCsvList("af_track_sum", "__line", nil, function (a, b)
		return b.__line < a.__line
	end)

	for i, csv in ipairs(csvList) do
		if csv.amount <= total_pay_100 / 100 then
			return csv.id
		end
	end
end

function InfoOrder.getSkadSum(total_pay_100)
	local csvList = CsvParser.getCsvList("skad_sum", "__line", nil, function (a, b)
		return b.__line < a.__line
	end)

	for i, csv in ipairs(csvList) do
		if csv.amount <= total_pay_100 / 100 then
			return csv.id
		end
	end
end

function InfoOrder.sync(data)
	local preTotalPay100 = rawData.total_pay_100

	dump(data, "$$$ InfoOrder.sync")

	for k, v in pairs(data) do
		rawData[k] = v
	end

	local currentTotalPay100 = rawData.total_pay_100

	if preTotalPay100 < currentTotalPay100 then
		local preSum = InfoOrder.getAfSum(preTotalPay100)
		local currentSum = InfoOrder.getAfSum(currentTotalPay100)

		if currentSum and currentSum ~= preSum then
			LuaBridge.call("luaAfEvent", {
				eventName = currentSum
			})
		end
	end

	if device.platform == "ios" and preTotalPay100 < currentTotalPay100 then
		local preSum = InfoOrder.getSkadSum(preTotalPay100)
		local currentSum = InfoOrder.getSkadSum(currentTotalPay100)

		if currentSum and currentSum ~= preSum then
			print("$$$ luaSkadPost", currentSum, preTotalPay100, currentTotalPay100)
			LuaBridge.call("luaSkadPost", {
				id = currentSum
			})
		end
	end

	notify.dispatch("campaign_changed")
	ManagerInfo.dataChange("order", data)
end

function InfoOrder.done(data)
	dump(data, "$$$ InfoOrder.done")

	if data.purchase_id and data.token then
		InfoOrder.sdkOrderConsume(data.purchase_id, data.token)
	end

	if data.goods_id then
		createOrderSpMap[data.goods_id] = nil
	end

	if CONFIG.is_ta then
		TaHelper.endAsset()
		TaHelper.onOrderDone(data)
	end

	if CONFIG.is_ultra_sdk and data.currency and data.order_id and data.amount_100 then
		dump({
			currency = data.currency,
			order_id = data.order_id,
			amount = data.amount_100 / 100
		}, "$$$ luaUltraPurchase")
		LuaBridge.call("luaUltraPurchase", {
			currency = data.currency,
			order_id = data.order_id,
			amount = data.amount_100 / 100
		})
	end

	InfoOrder.onGetReward()

	local rewards = data.rewards

	if #rewards > 0 then
		POP_reward.openMixed(rewards, nil, Localization.getSrcText("购买成功"))
	end

	local currencyCSV = CsvParser.getCsvData("rmb_currency", data.currency)
	local costCSV = CsvParser.getCsvData("rmb_cost", data.goods_id)

	if CONFIG.is_solar then
		local solarParams = {
			failReason = "",
			payStatus = 1,
			productNum = 1,
			payType = "",
			orderId = data.order_id,
			payAmount = data.amount_100 / 100,
			currencyType = currencyCSV.iso,
			productId = data.goods_id,
			productName = costCSV.name
		}

		dump(solarParams, "$$$ luaSolarPurchase")
		LuaBridge.call("luaSolarPurchase", solarParams)
	end
end

function InfoOrder.query(onSuccess, onFailure)
	local function callback(rcvData)
		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			InfoOrder.onQuery(rcvData)

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("order_query", callback)
end

function InfoOrder.onQuery(rcvData)
	rawData = rcvData
end

function InfoOrder.checkChannel(goodsID)
	local appBuild = CONFIG.appBuild
	local channel_type = global.channel_type

	if channel_type and appBuild then
		local csv = CsvParser.getCsvData("channel_rmb_ban", goodsID, nil, true)

		if csv then
			local channelArr = string.split(csv.channels, ",")

			for i, channel in ipairs(channelArr) do
				if channel == tostring(channel_type) then
					appBuild = tonumber(appBuild)

					if appBuild and appBuild < csv.version then
						return false
					end
				end
			end
		end
	end

	return true
end

function InfoOrder.create(goodsID, mygiftID, onSuccess, onFailure, onCreditSuccess, onCreditFailure)
	if global.pay_open ~= 1 then
		POP_msg.open(Localization.getSrcText("未开启充值"))
		onFailure(Localization.getSrcText("未开启充值"))

		requestLocked = nil

		return
	end

	if A_is_gs and goodsID and not InfoOrder.checkChannel(goodsID) then
		POP_msg.open(Localization.getSrcText("当前版本过低，请前往应用商店重新下载安装"))

		requestLocked = nil

		return
	end

	local function orderSDK()
		local function callback(rcvData)
			dump(rcvData, "order_create")

			if rcvData.err then
				if onFailure then
					onFailure(rcvData.err)
				end
			elseif onSuccess then
				onSuccess(rcvData)
			end
		end

		Connection.request("order_create", {
			goods_id = goodsID,
			mygift_id = mygiftID
		}, callback)

		if CONFIG.is_yd then
			YdHelper.check(4)
		end
	end

	if InfoUser.isCredit() then
		local rmb_cost = InfoOrder.getCost2(goodsID)

		if rmb_cost <= InfoUser.getCredit() then
			local function orderCredit()
				local function callback(rcvData)
					dump(rcvData, "order_credit")

					if rcvData.err then
						if onCreditFailure then
							onCreditFailure(rcvData.err)
						end
					elseif onCreditSuccess then
						onCreditSuccess(rcvData)
					end
				end

				Connection.request("order_credit", {
					goods_id = goodsID,
					mygift_id = mygiftID
				}, callback)
			end

			local str = Localization.getSrcText("是否使用[color=238,199,111]{2}[/color]代金券购买？\n（当前拥有[color=254,174,14]{1}[/color]代金券）")

			POP_notice.open(StringUtil.replace(str, InfoUser.getCredit(), rmb_cost), orderCredit, orderSDK, Localization.getSrcText("使用代金券"), Localization.getSrcText("普通支付"))

			return
		end
	end

	orderSDK()
end

function InfoOrder.recover(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "order_recover")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			if rcvData.order_info then
				for i, data in ipairs(rcvData.order_info) do
					if not empty(data.purchase_id) and not empty(data.token) then
						InfoOrder.sdkOrderConsume(data.purchase_id, data.token)
					end
				end
			end

			InfoOrder.onGetReward()

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("order_recover", callback)
end

function InfoOrder.onGetReward()
	if Npc.mooncardChest then
		Npc.mooncardChest:refreshMooncardChest()
	end
end

function InfoOrder.getMoonToday(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "order_moon_today")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		else
			local rewards = rcvData.rewards

			if #rewards > 0 then
				POP_reward.openMixed(rewards, nil, Localization.getSrcText("每日领取"))
			end

			if onSuccess then
				onSuccess(rcvData)
			end
		end
	end

	Connection.request("order_moon_today", callback)
end

function InfoOrder.sdkOrderConsume(purchase_id, token, onResult)
	local params = {
		purchase_id = purchase_id,
		token = token
	}

	Log.debug("$$$ sdkOrderConsume", purchase_id, token)
	LuaBridge.call("luaOrderConsume", params, function (result)
		dump(result, "$$$ InfoOrder.sdkOrderConsume")

		if onResult then
			onResult(result)
		end
	end)
end

function InfoOrder.sdkOrder(order_id, goods_id, data, onResult)
	local goods_arr = string.split(goods_id, "_")
	local product_id = goods_arr[1] .. goods_arr[2]
	local rmb_cost = InfoOrder.getCost(data.rmb_type, data.id)

	print("$$$ rmb_cost", rmb_cost)

	local goods_count = data.goods_count

	if empty(goods_count) then
		goods_count = 1
	end

	local goodsName = data.goods_name

	if data.__file == "abyss_pass" or data.__file == "payment_gift" then
		goodsName = data.name
	end

	local params = {
		friendlist = "无",
		profession = "无",
		professionId = "0",
		partyRoleName = "无",
		partyRoleId = "0",
		gameRoleGender = "无",
		partyId = "0",
		partyName = "无",
		vipLevel = "0",
		serverID = tostring(global.server_id),
		serverName = "server" .. tostring(global.server_id),
		gameRoleName = tostring(InfoUser.getNickName()),
		gameRoleID = tostring(InfoUser.getID()),
		gameBalance = tostring(InfoItem.getNum(GameConfig.zuan_item)),
		gameUserLevel = tostring(InfoDungeon.getAbyssMaxLevel()),
		roleCreateTime = tostring(InfoUser.getCreateTime()),
		gameRolePower = tostring(InfoHero.getMaxScore()),
		totalPay = tostring(InfoOrder.getTotalPay()),
		totalPay100 = tostring(InfoOrder.getTotalPay100()),
		qudaoUserId = tostring(global.qudao_user_id or ""),
		version = tostring(version),
		inpackVersion = tostring(inpackVersion),
		appVersion = tostring(CONFIG.appVersion or ""),
		appBuild = tostring(CONFIG.appBuild or ""),
		goods_id = goods_id,
		order_id = order_id,
		amount = rmb_cost,
		amount_str = tostring(rmb_cost),
		goods_name = goodsName,
		count = goods_count,
		goods_desc = data.goods_desc,
		product_id = product_id,
		iso_currency = InfoOrder.getCurrencyIso()
	}
	local costCSV = CsvParser.getCsvData("rmb_cost", data.rmb_type .. "_" .. data.id)

	for k, v in pairs(costCSV) do
		if k:sub(1, 7) == "sdk_id_" then
			params[k] = v
		end
	end

	if device.platform == "ios" and not empty(costCSV.sdk_id_1_ios) then
		params.sdk_id_1 = costCSV.sdk_id_1_ios
	end

	if device.platform == "android" and CONFIG.server_host then
		print("InfoOrder.sdkOrder levistory-ea", CONFIG.server_host, string.find(CONFIG.server_host, "levistory-ea", 1, true))

		if string.find(CONFIG.server_host, "levistory-ea", 1, true) and not empty(costCSV.sdk_id_iqyea_google) then
			print("$$$ levistory-ea 替换")

			params.sdk_id_1 = costCSV.sdk_id_iqyea_google
		end
	end

	dump(params, "$$$ InfoOrder.sdkOrder")

	if CONFIG.is_solar then
		local solarParams = {
			status = "",
			payType = "",
			orderId = params.order_id,
			payAmount = params.amount,
			currencyType = params.iso_currency
		}

		dump(solarParams, "$$$ luaSolarOrder")
		LuaBridge.call("luaSolarOrder", solarParams)
	end

	WingHelper.ghw_initiated_purchase()
	LuaBridge.call("luaOrder", params, function (result)
		dump(result, "$$$ InfoOrder.sdkOrder")

		if onResult then
			onResult(result)
		end
	end)
end

local zuanReadyList = nil

function InfoOrder.getRmbZuanList()
	if not zuanReadyList then
		local zuanMap = {}
		local zuanRaw = CsvParser.getCsvRaw("rmb_shop")

		for k, v in pairs(zuanRaw) do
			if not zuanMap[v.commodity] then
				zuanMap[v.commodity] = {}
			end

			zuanMap[v.commodity][v.product_replace] = v
		end

		local sortArr = {}

		for k, products in pairs(zuanMap) do
			table.insert(sortArr, {
				index = k,
				products = products
			})
		end

		table.sort(sortArr, function (a, b)
			return a.index < b.index
		end)

		zuanReadyList = sortArr
	end

	local arr = {}

	for i, v in ipairs(zuanReadyList) do
		if rawData["first_" .. v.index] == 0 then
			table.insert(arr, v.products[1])
		else
			table.insert(arr, v.products[2])
		end
	end

	return arr
end

function InfoOrder.getRmbMoonList()
	local arr = CsvParser.getCsvList("rmb_member")

	return arr
end

function InfoOrder.clearCache()
	zuanReadyList = nil
end

function InfoOrder.getMoonDayLeft()
	return rawData.mooncard_day + 1 - Time.getDay()
end

function InfoOrder.getSeasonDayLeft()
	return rawData.seasoncard_day + 1 - Time.getDay()
end

function InfoOrder.inMoon()
	return Time.getDay() <= rawData.mooncard_day
end

function InfoOrder.inSeason()
	return Time.getDay() <= rawData.seasoncard_day
end

function InfoOrder.getSeasonFunc(index)
	local csv = CsvParser.getCsvData("rmb_member", GameConfig.seasonID)

	return csv["func_" .. index]
end

function InfoOrder.moonToday()
	if InfoOrder.inMoon() and rawData.mooncard_zuan_day < Time.getDay() then
		return true
	end

	return false
end

function InfoOrder.countRedotMoon()
	local redotCount = 0

	if InfoOrder.moonToday() then
		redotCount = redotCount + 1
	end

	return redotCount
end

function InfoOrder.getTotalPay()
	if rawData then
		return rawData.total_pay_100 / 100
	end

	return 0
end

function InfoOrder.getTotalPay100()
	if rawData then
		return rawData.total_pay_100
	end

	return 0
end

function InfoOrder.getFirstPayTime()
	if rawData then
		return rawData.first_pay_time
	end
end

function InfoOrder.getGift(id, onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "order_moon_today")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("order_get_gift", {
		id = id
	}, callback)
end

function InfoOrder.getGiftRecord(id)
	local recordNum = rawData.gift_record

	return BitUtil.getBitByIndex(recordNum, id)
end

function InfoOrder.getGiftList()
	local csvList = CsvParser.getCsvList("order_gift")
	local total_pay = InfoOrder.getTotalPay()
	local arr = {}

	for i, csv in ipairs(csvList) do
		if empty(csv.unlock) then
			table.insert(arr, csv)
		else
			local rmb_cost = InfoOrder.getGiftCost("order_gift", csv.unlock)

			if rmb_cost <= total_pay then
				table.insert(arr, csv)
			end
		end
	end

	return arr
end

function InfoOrder.countRedot()
	local redotCount = 0
	local csvRaw = CsvParser.getCsvRaw("order_gift")

	for k, csv in pairs(csvRaw) do
		if InfoOrder.getGiftRecord(csv.id) == 0 then
			local rmb_cost = InfoOrder.getGiftCost("order_gift", csv.id)

			if rmb_cost <= InfoOrder.getTotalPay() then
				redotCount = redotCount + 1
			end
		end
	end

	print("$$$ InfoOrder.countRedot", redotCount)

	return redotCount
end

function InfoOrder.isOpen()
	local csvRaw = CsvParser.getCsvRaw("order_gift")

	for k, csv in pairs(csvRaw) do
		if InfoOrder.getGiftRecord(csv.id) == 0 then
			return true
		end
	end

	return false
end

function InfoOrder.checkFreeGacha(gachaID)
	if InfoOrder.inMoon() then
		local csv = CsvParser.getCsvData("rmb_member", GameConfig.moonID)
		local nowDay = Time.getDay()

		if rawData.free_gacha_day < nowDay then
			local idArr = string.split(csv.func_5, ",")

			for i, v in ipairs(idArr) do
				if tostring(gachaID) == v then
					return true
				end
			end
		end
	end

	return false
end

function InfoOrder.hasFreeGacha()
	if InfoOrder.inMoon() then
		local nowDay = Time.getDay()

		if rawData.free_gacha_day < nowDay then
			return true
		end
	end

	return false
end

function InfoOrder.checkMoonSafe()
	if InfoOrder.inMoon() then
		local csv = CsvParser.getCsvData("rmb_member", GameConfig.moonID)
		local safe_return_used = rawData.safe_return_used
		local nowDay = Time.getDay()

		if rawData.safe_return_day < nowDay then
			safe_return_used = 0
		end

		local max = csv.func_6
		local left = math.max(0, max - safe_return_used)

		return left, max
	end

	return 0, 0
end

function InfoOrder.getHomeShopLimit()
	if InfoOrder.inMoon() then
		local csv = CsvParser.getCsvData("rmb_member", GameConfig.moonID)

		return csv.func_8
	end

	return 0
end

local createOrderTimeMap = {}

function InfoOrder.order(data, onComplete, customInterval)
	print("$$$ InfoOrder.order customInterval:", customInterval)

	if requestLocked then
		return
	end

	requestLocked = true

	if CONFIG.is_ta then
		TaHelper.startAsset("order_gift")
	end

	local goodsID = data.rmb_type .. "_" .. data.id
	local now = Time.time()

	if customInterval and createOrderSpMap[goodsID] then
		print("等待上一笔支付完成", goodsID, createOrderSpMap[goodsID])

		createOrderSpMap[goodsID] = nil
		local waitTime = 3

		if device.platform == "ios" then
			waitTime = 10
		end

		local resetTime = now - (customInterval - waitTime)

		if not createOrderTimeMap[goodsID] or createOrderTimeMap[goodsID] < resetTime then
			createOrderTimeMap[goodsID] = resetTime
		end
	end

	local orderInterval = customInterval or MiscConfig.create_order_interval

	if createOrderTimeMap[goodsID] then
		local timeOffset = now - createOrderTimeMap[goodsID]

		if orderInterval >= timeOffset then
			print("创建订单间隔", timeOffset, orderInterval)

			local str = Localization.getSrcText("防止重复购买，请等待{1}秒")

			Alert.open(StringUtil.replace(str, math.floor((orderInterval - timeOffset) * 10) / 10))

			requestLocked = nil

			return
		end
	end

	if customInterval then
		createOrderSpMap[goodsID] = true
	end

	createOrderTimeMap[goodsID] = now

	local function onSuccess(rcvData)
		print("$$$ InfoOrder.order onSuccess")

		requestLocked = nil

		InfoOrder.sdkOrder(rcvData.order_id, goodsID, data, function (result)
			dump(result, "$$$ InfoOrder.order")

			if onComplete then
				onComplete()
			end
		end)
	end

	local function onFailure(err)
		print("$$$ InfoOrder.order onFailure")

		requestLocked = nil

		if global.pay_open == 1 then
			Alert.open(Localization.getSrcText("生成订单失败"))
		end
	end

	local function onCreditSuccess(rcvData)
		print("$$$ InfoOrder.order onCreditSuccess")

		requestLocked = nil

		if onComplete then
			onComplete()
		end
	end

	local function onCreditFailure(err)
		print("$$$ InfoOrder.order onCreditFailure")

		requestLocked = nil

		if global.pay_open == 1 then
			Alert.open(Localization.getSrcText("支付失败"))
		end
	end

	print("$$$ InfoOrder.order", goodsID)
	InfoOrder.create(goodsID, nil, onSuccess, onFailure, onCreditSuccess, onCreditFailure)
end

function InfoOrder.orderMygift(rmb_id, mygift_id, onComplete, customInterval)
	print("$$$ InfoOrder.orderMygift", rmb_id, mygift_id, customInterval)

	if requestLocked then
		return
	end

	requestLocked = true

	if CONFIG.is_ta then
		TaHelper.startAsset("order_gift")
	end

	local rmb_type = "mygift"
	local goodsID = rmb_type .. "_" .. rmb_id
	local orderInterval = customInterval or MiscConfig.create_order_interval
	local now = Time.time()

	if createOrderTimeMap[goodsID] then
		local timeOffset = now - createOrderTimeMap[goodsID]

		if orderInterval >= timeOffset then
			print("创建订单间隔", timeOffset, orderInterval)

			local str = Localization.getSrcText("防止重复购买，请等待{1}秒")

			Alert.open(StringUtil.replace(str, math.floor((orderInterval - timeOffset) * 10) / 10))

			requestLocked = nil

			return
		end
	end

	createOrderTimeMap[goodsID] = now
	local costCSV = CsvParser.getCsvData("rmb_cost", rmb_type .. "_" .. rmb_id)
	local mygiftData = InfoMygift.get(mygift_id)
	local goods_name = costCSV.name

	if mygiftData and mygiftData.title then
		goods_name = Localization.getTextByLang(mygiftData.title)
	end

	local data = {
		count = 1,
		goods_count = 1,
		rmb_type = rmb_type,
		id = rmb_id,
		rmb_id = rmb_id,
		goods_name = goods_name,
		goods_desc = costCSV.name
	}

	dump(data, "$$$ orderMygift")

	local function onSuccess(rcvData)
		print("$$$ InfoOrder.order onSuccess")

		requestLocked = nil

		InfoOrder.sdkOrder(rcvData.order_id, goodsID, data, function (result)
			dump(result, "$$$ InfoOrder.orderMygift")

			if onComplete then
				onComplete()
			end
		end)
	end

	local function onFailure(err)
		print("$$$ InfoOrder.order onFailure")

		requestLocked = nil

		if global.pay_open == 1 then
			Alert.open(Localization.getSrcText("生成订单失败"))
		end
	end

	local function onCreditSuccess(rcvData)
		print("$$$ InfoOrder.order onCreditSuccess")

		requestLocked = nil

		if onComplete then
			onComplete()
		end
	end

	local function onCreditFailure(err)
		print("$$$ InfoOrder.order onCreditFailure")

		requestLocked = nil

		if global.pay_open == 1 then
			Alert.open(Localization.getSrcText("支付失败"))
		end
	end

	print("$$$ InfoOrder.order", goodsID)
	InfoOrder.create(goodsID, mygift_id, onSuccess, onFailure, onCreditSuccess, onCreditFailure)
end

function InfoOrder.checkDailyLevel(onSuccess, onFailure)
	local nowTime = Time.now()
	local passed = RefreshManager.checkTimePassed(RefreshManager.TYPE.DAILY_ORDER, nowTime, rawData.daily_level_time)

	if passed then
		local function callback(rcvData)
			if rcvData.err then
				if onFailure then
					onFailure()
				end
			else
				rawData.daily_level = rcvData.daily_level
				rawData.daily_level_time = rcvData.daily_level_time

				if onSuccess then
					onSuccess()
				end
			end
		end

		Connection.request("order_daily_level", callback)
	elseif onSuccess then
		onSuccess()
	end
end

function InfoOrder.checkDailyPaid()
	local payTime = rawData.last_pay_time
	local nowTime = Time.now()
	local dayPassed = RefreshManager.checkTimePassedDays(RefreshManager.TYPE.DAILY_ORDER, nowTime, payTime)

	return dayPassed == 0
end

function InfoOrder.checkDailyRewardReady()
	local preTime = rawData.daily_order_reward_time
	local nowTime = Time.now()
	local passed = RefreshManager.checkTimePassed(RefreshManager.TYPE.DAILY_ORDER, nowTime, preTime)

	return passed
end

function InfoOrder.checkDailyReady(index)
	local preTime = rawData["daily_" .. index]
	local nowTime = Time.now()
	local passed = RefreshManager.checkTimePassed(RefreshManager.TYPE.DAILY_ORDER, nowTime, preTime)

	return passed
end

function InfoOrder.getDailyOrderItems()
	local daily_level = rawData.daily_level
	local csvList = CsvParser.getCsvList("daily_order")
	local groupMap = {}

	for i, csv in ipairs(csvList) do
		if (empty(csv.level_min) or csv.level_min <= daily_level) and (empty(csv.level_max) or daily_level <= csv.level_max) then
			if not groupMap[csv.price_type] then
				groupMap[csv.price_type] = {}
			end

			table.insert(groupMap[csv.price_type], csv)
		end
	end

	local random = Random.new(Time.getToday())
	local csvArr = {}

	for index, arr in pairs(groupMap) do
		local powerIndex = SheetUtil.getPowerRandomIndex(arr, random, "weight")
		local csv = arr[powerIndex]

		table.insert(csvArr, {
			rmb_type = "daily",
			index = index,
			csv = csv
		})
	end

	table.sort(csvArr, function (a, b)
		return a.index < b.index
	end)

	return csvArr
end

function InfoOrder.getDailyOrderRewardItems()
	local csvList = CsvParser.getCsvList("daily_order_reward")
	local random = Random.new(Time.getToday())
	local powerIndex = SheetUtil.getPowerRandomIndex(csvList, random, "weight")
	local csv = csvList[powerIndex]
	local itemList = SheetUtil.getColumnList(csv, {
		"product_id",
		"product_num"
	}, {
		"base_id",
		"num"
	})

	return itemList, csv
end

function InfoOrder.getDailyOrderReward(onSuccess, onFailure)
	local function callback(rcvData)
		dump(rcvData, "order_get_daily_order_reward")

		if rcvData.err then
			if onFailure then
				onFailure(rcvData.err)
			end
		elseif onSuccess then
			onSuccess(rcvData)
		end
	end

	Connection.request("order_get_daily_order_reward", callback)
end

function InfoOrder.countRedotDailyOrderReward()
	if InfoOrder.checkDailyPaid() and InfoOrder.checkDailyRewardReady() then
		return 1
	else
		return 0
	end
end

function InfoOrder.getNewgiftList(isJump, season)
	local arr = {}
	local indexArr = {}
	local csvList = CsvParser.getCsvList("newgift", nil, {
		group = season
	})

	for i, csv in ipairs(csvList) do
		table.insert(indexArr, csv.once_index)

		local onceArr = InfoOrder.getOnceList(csv.once_index)
		local count = 0
		local avlbCount = 0

		for j, csv in ipairs(onceArr) do
			if InfoOrder.getOnce(csv.id) == 0 then
				count = count + 1

				if #InfoOrder.getCondition(csv.id) == 0 then
					avlbCount = avlbCount + 1
				end
			end
		end

		if isJump then
			if not InfoVars.checkIgnore(InfoVars.IGNORE["FIRST_" .. season .. "_" .. i]) and avlbCount > 0 then
				table.insert(arr, csv)
			end
		elseif count > 0 then
			table.insert(arr, csv)
		end
	end

	return arr
end

function InfoOrder.getOnce(id)
	local section, position = BitUtil.split(30, id)
	local recordNum = rawData["once_" .. section]

	return BitUtil.getBitByIndex(recordNum, position)
end

function InfoOrder.getOnceList(index_type)
	local arr = CsvParser.getCsvList("once_order", nil, {
		index_type = index_type
	})

	return arr
end

function InfoOrder.getCondition(id)
	local conArr = {}
	local csv = CsvParser.getCsvData("once_order", id)

	if not empty(csv.pre_id) and InfoOrder.getOnce(csv.pre_id) == 0 then
		local str = Localization.getSrcText("购买前置礼包")

		table.insert(conArr, {
			pre_id = csv.pre_id,
			msg = str
		})
	end

	if not empty(csv.level_min) then
		local abyssLevel = InfoDungeon.getAbyssMaxLevel()

		if abyssLevel < csv.level_min then
			local str = Localization.getSrcText("深渊达到{1}")

			table.insert(conArr, {
				abyss_level = csv.level_min,
				msg = StringUtil.replace(str, csv.level_min)
			})
		end
	end

	if not empty(csv.building_unlock) and not InfoBuilding.getBuildingFin(csv.building_unlock) then
		local buildingCSV = CsvParser.getCsvData("building", csv.building_unlock)
		local str = Localization.getSrcText("{1}达到{2}级")

		table.insert(conArr, {
			building_unlock = csv.building_unlock,
			msg = StringUtil.replace(str, buildingCSV.name, buildingCSV.level)
		})
	end

	return conArr
end

function InfoOrder.isNewgiftNew(id)
	local conArr = InfoOrder.getCondition(id)

	if #conArr == 0 then
		local newMap = UserCookie.get("newgift_new")

		if newMap and newMap[tostring(id)] == 1 then
			return false
		end

		return true
	end

	return false
end

function InfoOrder.isNewgiftNewPage(index_type)
	local csvArr = InfoOrder.getOnceList(index_type)

	for i, csv in ipairs(csvArr) do
		if InfoOrder.isNewgiftNew(csv.id) then
			return true
		end
	end

	return false
end

function InfoOrder.isNewgiftNewAll(isJump, season)
	local giftArr = InfoOrder.getNewgiftList(isJump, season)

	for i, csv in ipairs(giftArr) do
		if InfoOrder.isNewgiftNewPage(csv.once_index) then
			return true
		end
	end

	return false
end

function InfoOrder.markNewgiftPage(index_type)
	local newMap = UserCookie.get("newgift_new") or {}
	local changed = false
	local csvArr = InfoOrder.getOnceList(index_type)

	for i, csv in ipairs(csvArr) do
		if InfoOrder.isNewgiftNew(csv.id) then
			local conArr = InfoOrder.getCondition(csv.id)

			if #conArr == 0 then
				newMap[tostring(csv.id)] = 1
				changed = true
			end
		end
	end

	if changed then
		UserCookie.set("newgift_new", newMap, true)
		notify.dispatch("campaign_changed")
	end
end

function InfoOrder.clearNewgiftNew()
	UserCookie.set("newgift_new", nil, true)
	notify.dispatch("campaign_changed")
end

return InfoOrder
