local CombatUnit = import(".CombatUnit")
local Tile = import("..map.Tile")
local Hero = class("Hero", CombatUnit)

function Hero:ctor(customType)
	Hero.super.ctor(self, customType or "hero")

	self.activeSkill = nil
	self.alwaysVisible = true
	self.alwaysActive = true
	self.fixedLight = 255
	self.isBlock = true

	notify.safeRegister(self, "hero_add_exp", function (data)
		if self.info and data.id == self.info.id then
			self:onAddExp(data)
		end
	end)
	ManagerInfo.onDataChange(self, "hero", nil, function (idStack, idMap)
		if self.info and idMap[self.info.id] then
			local heroInfo = InfoHero.getHero(self.info.id)

			if heroInfo then
				self:setInfo(heroInfo)
			end

			return
		end
	end)
	ManagerInfo.onDataChange(self, "equip", nil, function (idStack, idMap)
		local equipExist = false

		if self.currentEquipMap then
			for equipID, v in pairs(self.currentEquipMap) do
				for id, data in pairs(idMap) do
					if equipID == id then
						equipExist = true

						break
					end
				end

				if equipExist then
					break
				end
			end
		end

		if equipExist or InfoEquip.checkEquipsOnHero(self.info.id, idMap) then
			local heroInfo = InfoHero.getHero(self.info.id)

			if heroInfo then
				self:setInfo(heroInfo)
			end
		end
	end)
	ManagerInfo.onDataChange(self, "card", nil, function (idStack, idMap)
		local exist = false

		if self.currentCardMap then
			for equipID, v in pairs(self.currentCardMap) do
				for id, data in pairs(idMap) do
					if equipID == id then
						exist = true

						break
					end
				end

				if exist then
					break
				end
			end
		end

		if exist or InfoCard.checkCardsOnHero(self.info.id, idMap) then
			local heroInfo = InfoHero.getHero(self.info.id)

			if heroInfo then
				self:setInfo(heroInfo)
			end
		end
	end)
end

function Hero.combineData(heroInfo)
	local jobData = CsvParser.getCsvData("hero", heroInfo.base_id, true)
	local avatarList = SheetUtil.getColumnListFull(jobData, {
		"avatar_index_",
		"avatar_id_"
	}, {
		"avatar",
		"value"
	})

	for i, v in ipairs(avatarList) do
		jobData[v.avatar] = v.value
	end

	jobData.gender = "male"

	if string.find(heroInfo.body, "female", 1, true) then
		jobData.gender = "female"
	end

	jobData.model = heroInfo.body
	jobData.avatar_1 = heroInfo.hair
	jobData.name = heroInfo.name

	return jobData
end

function Hero:onAddExp(data)
	if data.pre_level < data.level then
		local effectGen = self:getEffectGen()

		if effectGen then
			effectGen:castEffect(MiscConfig.effect_levelup, self)
		end

		self:dispatchEvent({
			name = "level_changed"
		})
	end

	if not empty(data.max_type) then
		local str = nil

		if data.max_type == 1 then
			str = Localization.getSrcText("到达职业上限")
		elseif data.max_type == 2 then
			str = Localization.getSrcText("到达集会所上限")
		end

		if str then
			self:flyWord(str, {
				color = Style.red
			}, 90)
		end
	elseif data.exp_add > 0 then
		local str = Localization.getSrcText("经验+{1}")

		self:flyWord(StringUtil.replace(str, data.exp_add), {
			color = Style.golden
		}, 90)
		self:dispatchEvent({
			name = "exp_changed"
		})
	end
end

function Hero:setHeroTempleteID(id, exData, isBattle)
	self.isTemplete = true
	self.baseID = id
	local random = Random.new(math.random(1, 65535))
	local templeteData = CsvParser.getCsvData("hero_templete", id)
	local heroInfo = {
		id = 1,
		quality = SheetUtil.getNumber(templeteData.quality, random),
		base_id = SheetUtil.getString(templeteData.base_id, random),
		gender = SheetUtil.getString(templeteData.gender, random),
		body = SheetUtil.getString(templeteData.body, random),
		hair = SheetUtil.getString(templeteData.hair, random),
		affix = SheetUtil.getString(templeteData.affix, random)
	}

	if not empty(templeteData.level) then
		heroInfo.level = SheetUtil.getNumber(templeteData.level, random)
	else
		heroInfo.level = 1
	end

	if exData then
		for k, v in pairs(exData) do
			heroInfo[k] = v
		end
	end

	local genderCode = {
		"male",
		"female"
	}
	local heroData = CsvParser.getCsvData("hero", heroInfo.base_id, true)
	local avatarList = SheetUtil.getColumnListFull(heroData, {
		"avatar_index_",
		"avatar_id_"
	}, {
		"avatar",
		"value"
	})

	for i, v in ipairs(avatarList) do
		heroData[v.avatar] = StringUtil.replaceTag(v.value, {
			gender = genderCode[tonumber(heroInfo.gender) + 1]
		})
	end

	local avatarList = SheetUtil.getColumnListFull(templeteData, {
		"avatar_index_",
		"avatar_id_"
	}, {
		"avatar",
		"value"
	})

	for i, v in ipairs(avatarList) do
		heroData[v.avatar] = StringUtil.replaceTag(v.value, {
			gender = genderCode[tonumber(heroInfo.gender) + 1]
		})
	end

	assert(heroData, "hero miss id:" .. id)

	heroData.model = heroInfo.body
	heroData.avatar_1 = heroInfo.hair
	self.info = heroInfo

	if isBattle then
		self.currentCardMap = {}

		for i = 1, GameConfig.max_card do
			local cardInfo = InfoCard.getCardOnHero(heroInfo.id, i)

			if cardInfo then
				self.currentCardMap[cardInfo.id] = true
			end
		end

		self:clearCardBuff()

		local cardTotal = InfoHero.getCardTotal(self.info)

		for i = 1, cardTotal do
			local cardInfo = InfoCard.getCardOnHero(self.info, i)

			if cardInfo then
				local buffArr = InfoCard.getCardBuff(cardInfo)

				for j, buffID in ipairs(buffArr) do
					if not empty(buffID) then
						self:addCardBuff(buffID, cardInfo.ran)
					end
				end
			end
		end
	end

	self:setData(heroData)
	self:refreshBattleData()

	if isBattle then
		self:updateSkill()
	end

	if self:isSwitchSkill() then
		self.autoManual = false
	else
		self.autoManual = true
	end
end

function Hero:setInfo(heroInfo, blank, noDust)
	if not noDust and InfoDungeon.inDust() then
		heroInfo = InfoDust.cloneSample(heroInfo) or heroInfo
	end

	self.info = heroInfo
	local heroData = Hero.combineData(heroInfo)
	local avatarHideMap = InfoHero.getAvatarHideMap(heroInfo)

	if heroInfo.equips then
		for i, equipInfo in ipairs(heroInfo.equips) do
			local avatar, avatar_id = InfoEquip.getAvatar(equipInfo)

			if not empty(avatar) then
				local equipCSV = CsvParser.getCsvData("equip", equipInfo.base_id)

				if not avatarHideMap[equipCSV.equip_pos] then
					heroData[avatar] = avatar_id
				end
			end
		end

		if heroInfo.showEquips then
			for i, equipInfo in ipairs(heroInfo.showEquips) do
				local avatar, avatar_id = InfoEquip.getAvatar(equipInfo)

				if not empty(avatar) then
					local equipCSV = CsvParser.getCsvData("equip", equipInfo.base_id)

					if not avatarHideMap[equipCSV.equip_pos] then
						heroData[avatar] = avatar_id
					end
				end
			end
		end
	else
		self.currentEquipMap = {}

		for i = 1, GameConfig.max_equip do
			local equipInfo = InfoEquip.getEquipOnHero(heroInfo.id, i)

			if equipInfo then
				self.currentEquipMap[equipInfo.id] = true
				local avatar, avatar_id = InfoEquip.getAvatar(equipInfo)

				if not empty(avatar) then
					local equipCSV = CsvParser.getCsvData("equip", equipInfo.base_id)

					if not avatarHideMap[equipCSV.equip_pos] then
						heroData[avatar] = avatar_id
					end
				end
			end

			local equipInfo = InfoEquip.getShowEquipOnHero(heroInfo.id, i)

			if equipInfo then
				self.currentEquipMap[equipInfo.id] = true
				local avatar, avatar_id = InfoEquip.getAvatar(equipInfo)

				if not empty(avatar) then
					local equipCSV = CsvParser.getCsvData("equip", equipInfo.base_id)

					if not avatarHideMap[equipCSV.equip_pos] then
						heroData[avatar] = avatar_id
					end
				end
			end
		end
	end

	self.currentCardMap = {}

	for i = 1, GameConfig.max_card do
		local cardInfo = InfoCard.getCardOnHero(heroInfo.id, i)

		if cardInfo then
			self.currentCardMap[cardInfo.id] = true
		end
	end

	self:clearCardBuff()

	local cardTotal = InfoHero.getCardTotal(self.info)

	for i = 1, cardTotal do
		local cardInfo = InfoCard.getCardOnHero(self.info.id, i)

		if cardInfo then
			local buffArr = InfoCard.getCardBuff(cardInfo)

			for j, buffID in ipairs(buffArr) do
				if not empty(buffID) then
					self:addCardBuff(buffID, cardInfo.ran)
				end
			end
		end
	end

	self:setData(heroData)
	self:refreshBattleData()
	self:updateSkill()

	if self:isSwitchSkill() then
		self.autoManual = false
	else
		self.autoManual = self.info.auto_skill == 1
	end

	self:dispatchEvent({
		name = "info_set"
	})
end

function Hero:setAutoSkill(isAuto)
	if self:isSwitchSkill() then
		self.autoManual = false
	else
		self.autoManual = isAuto
	end

	notify.dispatch("auto_skill_on")

	if not self.isTemplete then
		InfoHero.setAutoSkill(self.info.id, isAuto)
	end
end

function Hero:refreshAutoSkill()
	if self:isSwitchSkill() then
		self.autoManual = false
	else
		self.autoManual = self.info.auto_skill == 1
	end
end

function Hero:isAutoSkill()
	return self.autoManual
end

function Hero:refreshHp()
	if TeamManager.heroHPLocked then
		return
	end

	if not self.battleData.hp or not WarMachine.on then
		if self.isTemplete then
			self.battleData.hp = self.attrs.hp
		else
			local dungeonHeroHp = InfoDungeon.getHeroHP(self.info.id)

			if dungeonHeroHp then
				self.battleData.hp = math.min(self.attrs.hp, dungeonHeroHp)
			else
				self.battleData.hp = self.attrs.hp
			end
		end

		if self.battleData.hp > 0 then
			self.battleData.die = nil
		elseif self.battleData.hp <= 0 then
			self.battleData.die = true
		end
	end
end

function Hero:refreshBattleData()
	Hero.super.refreshBattleData(self)

	local attrData, petAttrData, dustSkillMap, dustBuffArr, skillChangeMap = CombatAttr.getHeroAttr(self.info)

	if DEV_MODE and self.info.id then
		local debugAttr = InfoHero.getDebugAttr(self.info.id)

		if debugAttr then
			for k, v in pairs(debugAttr) do
				attrData[k] = v
			end
		end
	end

	self:setBattleData(attrData)

	self.dustSkillMap = dustSkillMap
	self.dustBuffArr = dustBuffArr
	self.skillChangeMap = skillChangeMap
end

function Hero:setData(data)
	Hero.super.setData(self, data)
	self:updateAvatar()
	self:setAction(self.action)

	if data.class == 1 then
		if self:hasAction("atk_w") then
			self:setMappedAction("attack", "atk_w")
		end

		self.battleIdleAction = "idle_w"
	end

	if data.class == 2 then
		if self:hasAction("atk_a") then
			self:setMappedAction("attack", "atk_a")
		end

		self.battleIdleAction = "idle_a"
	end

	if data.class == 3 then
		if self:hasAction("atk_m") then
			self:setMappedAction("attack", "atk_m")
		end

		self.battleIdleAction = "idle_m"
	end
end

function Hero:updateSkill()
	self:clearSkill()

	if self:isSwitchSkill() then
		self:updateSwitchSkill()
	else
		if not empty(self.data.attack_id) then
			self:addSkill(self.data.attack_id)
		end

		local skillInfo = InfoHero.getActiveSkill(self.info)
		local skillID = skillInfo.id

		if self.info.name == "沃尔德伦" then
			dump(self.skillChangeMap, "$$$ self.skillChangeMap")
		end

		if self.skillChangeMap then
			local skillData = CsvParser.getCsvData("skill", skillID)

			if self.skillChangeMap[skillData.base_id] then
				local _skillID = skillData.id + self.skillChangeMap[skillData.base_id]
				local _skillData = CsvParser.getCsvData("skill", _skillID)

				if _skillData then
					print("$$$ updateSkill 技能更换（神器）", _skillData.name, skillData.id, _skillData.id)

					skillID = _skillID
				end
			end
		end

		self.activeSkill = self:addSkill(skillID)
	end
end

function Hero:updateSwitchSkill(index)
	self:clearSkill()

	self.skillSwitchIndex = index or (self.info.auto_skill or 0) + 1

	print("$$$ self.skillSwitchIndex", self.skillSwitchIndex)

	if not empty(self.data["switch_attack_" .. self.skillSwitchIndex]) then
		self:addSkill(self.data["switch_attack_" .. self.skillSwitchIndex])
	end

	local skillInfo = InfoHero.getSwitchSkill(self.info, self.skillSwitchIndex)
	local skillID = skillInfo.id

	if self.skillChangeMap then
		local skillData = CsvParser.getCsvData("skill", skillID)

		if self.skillChangeMap[skillData.base_id] then
			local _skillID = skillData.id + self.skillChangeMap[skillData.base_id]
			local _skillData = CsvParser.getCsvData("skill", _skillID)

			if _skillData then
				print("$$$ updateSkill 技能更换（神器）", _skillData.name, skillData.id, _skillData.id)

				skillID = _skillID
			end
		end
	end

	self.activeSkill = self:addSkill(skillID)
end

function Hero:switchSkill()
	local preCD = nil

	if self.activeSkill then
		preCD = self.activeSkill.cd
	end

	local buffRemoveArr = {}
	local buffTypeArr = self.buffStackMap[CombatUnit.BUFF_TYPE.NORMAL]

	for i, obj in ipairs(buffTypeArr) do
		local buffData = CsvParser.getCsvData("buff", obj.id)

		if buffData["is_switch_buff_" .. self.skillSwitchIndex] == 1 then
			table.insert(buffRemoveArr, obj)
		end
	end

	for i, obj in ipairs(buffRemoveArr) do
		self:removeBuff(obj)
	end

	self:updateSwitchSkill(3 - self.skillSwitchIndex)
	self:initSkills()
	self:dispatchEvent({
		name = "switch_skill",
		index = self.skillSwitchIndex
	})
end

function Hero:getActiveSkill()
	return self.activeSkill
end

function Hero:updateAvatar()
	if self.noAvatar then
		return
	end

	local extraAvatarMap = {}

	if self.extraAvatar then
		for i, v in ipairs(self.extraAvatar) do
			extraAvatarMap[v.avatar] = SheetUtil.getString(v.value, self.random)
		end
	end

	for i = 1, #Unit.AVATAR_LAYERS do
		if extraAvatarMap["avatar_" .. i] then
			local avatarStr = extraAvatarMap["avatar_" .. i]
			avatarStr = StringUtil.replaceTag(avatarStr, self.data)

			self:setAvatar(avatarStr, i)
		elseif not empty(self.data["avatar_" .. i]) then
			local avatarStr = self.data["avatar_" .. i]
			avatarStr = StringUtil.replaceTag(avatarStr, self.data)

			self:setAvatar(avatarStr, i)
		else
			self:removeAvatar(i)
		end
	end

	self:dispatchEvent({
		name = "update_avatar"
	})
end

function Hero:quickCast()
	if self.battleData.die then
		return false
	end

	if self:isAutoSkill() then
		return false
	end

	if self:getState("no_skill") then
		return false
	end

	local skillPack = self:getActiveSkill()

	if not skillPack then
		return false
	end

	if skillPack == self.casting.skillPack and (self.casting.step == 1 or self.casting.step == 5) then
		return false
	end

	local fullFrameTime = WarMachine.getFrame()

	if self.battleData.target == nil then
		self:clearTarget()
		self:battleThink()
	end

	if self.battleData.target ~= nil and not self.battleData.die and skillPack.cd <= fullFrameTime and SkillManager.checkPower(skillPack, fullFrameTime) then
		local triggerOK = skillPack.trigger

		if triggerOK then
			local skillData = SkillManager.getSkillData(self, skillPack)
			local isReady, castTarget = SkillManager.findAutoSkillTarget(self, skillData, self.battleData.target)

			if isReady then
				if self.casting.step == 2 or self.casting.step == 5 then
					local castingSkillData = SkillManager.getSkillData(self, self.casting.skillPack)

					if castingSkillData.type == 2 then
						self.readyHandSkill = {
							skillPack = skillPack,
							target = castTarget
						}

						return true
					end
				end

				self:castManualSkill(skillPack, castTarget)

				return true
			end
		end
	end

	return false
end

function Hero:die()
	if not self.battleData.die then
		self:clearBuff()
		self:setAction("die")

		self.isBlock = false

		Hero.super.die(self)
		InfoModao.addMpGetKill(self.info)

		if self.isTD then
			self:setVisible(false)
			self:setShadowEnabled(false)
		end
	end
end

function Hero:recoverDead()
	self.battleData.die = false

	self:setAction("die")

	self.isBlock = false
	self.battleData.die = true
end

function Hero:castHandSkill(skillPack, target)
	if self.casting.step == 2 or self.casting.step == 5 then
		local castingSkillData = SkillManager.getSkillData(self, self.casting.skillPack)

		if castingSkillData.type == 2 then
			self.readyHandSkill = {
				skillPack = skillPack,
				target = target
			}

			return
		end
	end

	self:castManualSkill(skillPack, target)

	if target.battleData and not target.battleData.die then
		self.battleData.target = target
	end
end

function Hero:onCastOver()
	Hero.super.onCastOver(self)

	if self.readyHandSkill then
		local fullFrameTime = WarMachine.getFrame()
		local skillPack = self.readyHandSkill.skillPack

		if skillPack.cd <= fullFrameTime and SkillManager.checkPower(skillPack, fullFrameTime) then
			self:castHandSkill(skillPack, self.readyHandSkill.target)

			self.readyHandSkill = nil
		end
	end
end

function Hero:interruptSkill()
	Hero.super.interruptSkill(self)

	self.readyHandSkill = nil
end

function Hero:fakeHp(hp)
	self.battleData.hp = math.min(hp, self.attrs.hp)

	self:dispatchEvent({
		name = "hp_changed"
	})
end

function Hero:onBattleStart(warSeed)
	if self:isSwitchSkill() then
		self:updateSwitchSkill()
	end

	Hero.super.onBattleStart(self, warSeed)

	if not self.isTestBattle and not self.isTemplete then
		local dungeonHeroHp = InfoDungeon.getHeroHP(self.info.id)

		if dungeonHeroHp then
			self.battleData.hp = math.min(self.attrs.hp, dungeonHeroHp) or self.attrs.hp
		else
			self.battleData.hp = self.attrs.hp
		end

		self:dispatchEvent({
			name = "hp_changed"
		})
	end

	WarMachine.addCheckSum(self.info.id, self.battleData.hp)
	CombatAttr.suitStart(self.info.id, self)

	if self.dustBuffArr then
		dump(self.dustBuffArr, "$$$ self.dustBuffArr")

		for i, v in ipairs(self.dustBuffArr) do
			local typeOK = false

			if empty(v.type) then
				typeOK = true
			elseif v.type == 1 then
				local idArr = string.split(v.value, ",")
				local skillData = self:getActiveSkill().data

				for i1, v1 in ipairs(idArr) do
					if v1 == tostring(skillData.base_id) then
						typeOK = true

						break
					end
				end
			end

			print("添加尘封属性buff typeOK:" .. tostring(typeOK) .. " id:" .. v.id)

			if typeOK then
				self:addBuff(v.id, nil, , , true)
			end
		end
	end

	local perkLevelCache, perkLevelPointCache, perkIdPointCache, perkPointIdCache = InfoHero.getPerkLevelCache()
	local perkLeft, perkMax = InfoHero.getPerkPoints(self.info)
	local perkMap = {}

	if not empty(self.info.perks) then
		local arr = string.split(self.info.perks, ",")

		for i, v in ipairs(arr) do
			local id = tonumber(v)

			if id then
				local points = perkIdPointCache[id]
				perkMap[points] = id
			end
		end
	end

	for i, v in ipairs(perkLevelCache) do
		if v.points <= perkMax then
			local id = perkMap[v.points]

			if not empty(id) then
				local csv = CsvParser.getCsvData("hero_peak_perk", id)
				local buffArr = SheetUtil.getColumnValueList(csv, "buff_")

				for j, buffID in ipairs(buffArr) do
					self:addBuff(buffID, nil, , , true)
				end
			end
		else
			break
		end
	end

	local mutateCSV = InfoDungeon.getMutateMonster()

	if mutateCSV and not empty(mutateCSV.hero_buff) then
		local buffID = SheetUtil.getString(mutateCSV.hero_buff)

		print("添加乱流佣兵buff buffID:" .. buffID)
		self:addBuff(buffID, nil, , , true)
	end
end

function Hero:onBattleOver()
	Hero.super.onBattleOver(self)

	if not self.isTD then
		if self.battleData.hp > 0 then
			self.battleData.die = nil
		elseif self.battleData.hp <= 0 then
			self.battleData.die = true
		end

		if self.battleData.die then
			DungeonState.setCorpse(self.info.id)
		end
	end

	self:setHudVisible(false)

	if not self.isTD then
		GuideManager.stopGuideBattle()
	end
end

function Hero:getCode(key)
	return key .. "_" .. self.type .. "_" .. self.info.id
end

function Hero:setBattleData(data)
	Hero.super.setBattleData(self, data)
	self:refreshHp()
end

local ICON_SIZE = 13

function Hero:getHudSkillIcon(baseID)
	local mask = display.newSprite("#map_assets_hud_skill_mask"):align(display.LEFT_BOTTOM)
	local iconPath = IconManager.getSkillIcon(baseID)
	local node = display.newNode()
	local icon = display.newSprite(iconPath):align(display.LEFT_BOTTOM)

	icon:setScale(ICON_SIZE / DropSlot.ICON_DESIGN_SIZE)

	local clipNode = cc.ClippingNode:create()

	clipNode:setStencil(mask)
	clipNode:setAlphaThreshold(0)
	clipNode:addChild(icon)

	return clipNode, icon
end

function Hero:setHudVisible(visible, color, style)
	Hero.super.setHudVisible(self, visible, cc.c3b(35, 180, 28), style)
end

function Hero:refreshSkillHud()
	if self.skillCdHandler then
		self:removeEventListener("skill_cd", self.skillCdHandler)

		self.skillCdHandler = nil
		self.skillHud = nil
	end
end

function Hero:onSkillCD(event)
	local fullFrameTime = WarMachine.getFrame()

	self:setHudSkillCD(event.id, event.cd - fullFrameTime)
end

function Hero:setHudSkillCD(id, cd)
	local skillPack = self:getSkillPack(id)
	local skillIconMap = self.skillHud.skillIconMap
	local iconObj = skillIconMap[id]
	local cdLeft = cd
	local cdMax = skillPack.cdMax
	local fadeStep = 1

	if iconObj then
		local container = iconObj.container
		local clip = iconObj.clip
		local clipLight = iconObj.clipLight
		local icon = iconObj.icon
		local iconLight = iconObj.iconLight
		local bg = iconObj.bg

		bg:setVisible(false)
		Shader.custom(icon, "subtract_0.5")

		local cdLoop = nil

		function cdLoop(obj, frame, passed, sharp)
			if tolua.isnull(self) or tolua.isnull(container) then
				MapFrameManager.stopLoop(self, cdLoop)

				return
			end

			cdLeft = cdLeft - passed

			if fadeStep == 1 and cdLeft <= 12 then
				iconLight:setOpacity(0)
				iconLight:setVisible(true)

				fadeStep = 2
				local tweenObj = {
					opacity = 0
				}

				return MapFrameManager.tween(3, tweenObj, {
					opacity = 255
				}, "outQuad", nil, function ()
					if tolua.isnull(self) or tolua.isnull(container) then
						return
					end

					iconLight:setOpacity(tweenObj.opacity)
				end)
			elseif fadeStep == 2 and cdLeft <= 9 then
				Shader.recover(icon)

				fadeStep = 3
				local tweenObj = {
					opacity = 255
				}

				if cdLeft > 0 then
					return MapFrameManager.tween(cdLeft, tweenObj, {
						opacity = 0
					}, "inQuad", function ()
						if tolua.isnull(self) or tolua.isnull(container) then
							return
						end

						iconLight:setVisible(false)
					end, function ()
						if tolua.isnull(self) or tolua.isnull(container) then
							return
						end

						iconLight:setOpacity(tweenObj.opacity)
					end)
				end
			end

			local percent = 1 - math.max(0, cdLeft / cdMax)

			container:setClippingRegion(cc.rect(0, 0, ICON_SIZE, ICON_SIZE * percent))

			if cdLeft <= 0 then
				bg:setVisible(true)
				iconLight:setVisible(false)
				MapFrameManager.stopLoop(self, cdLoop)
			end
		end

		MapFrameManager.startLoop(self, cdLoop)
	end
end

function Hero:clearTitle()
	if self.titleLabel then
		self.titleLabel:removeSelf()

		self.titleLabel = nil
	end

	if self.titleMedals then
		for i, v in ipairs(self.titleMedals) do
			v:removeSelf()
		end

		self.titleMedals = nil
	end

	if self.titleUnion then
		self.titleUnion:removeSelf()

		self.titleUnion = nil
	end
end

function Hero:setTitle(nickname, nicklang, abyssLevel, height, medalArr, union_info)
	local str = Localization.getSrcText("{1}层·{2}")

	self:setTitleStr(StringUtil.replace(str, abyssLevel, nickname), height, medalArr, nicklang, union_info)
end

function Hero:setTitleStr(str, height, medalArr, lang, union_info)
	self:clearTitle()

	local titleHeight = self:getTotalHeight() + (height or 20)
	local xOffset = 0
	local unionFlag = nil

	if union_info and not empty(union_info.union_id) then
		local iconSize = 52
		unionFlag = UnionFlag.new({
			x = 0,
			y = titleHeight + iconSize / 2 - 51,
			width = iconSize,
			height = iconSize
		})

		unionFlag:setNoFrame(true)
		unionFlag:setFlag(union_info.union_icon)
		self:addChild(unionFlag, 100)

		self.titleUnion = unionFlag
		xOffset = 5
	end

	local style = {
		size = 16,
		outline = 1,
		align = Style.center,
		color = cc.c4b(238, 199, 111, 255),
		outlineColor = cc.c4b(0, 0, 0, 255)
	}

	if not empty(lang) then
		style.lang = lang
		style.font = Localization.getFont(lang)
	end

	local label, labelWidth, labelHeight = UIManager.createLabel(xOffset, titleHeight, 0, 0, str, style)

	self:addChild(label, 100)

	self.titleLabel = label

	if unionFlag then
		unionFlag:setPositionX(-labelWidth / 2 - 34)
	end

	if medalArr and #medalArr > 0 then
		local iconSize = 35
		local spaceX = -2
		local startX = -(#medalArr * iconSize + (#medalArr - 1) * spaceX) / 2
		self.titleMedals = {}

		for i, itemID in ipairs(medalArr) do
			local texture = IconManager.getItemIcon(itemID)
			local icon = display.newSprite(texture)
			local size = icon:getContentSize()

			icon:setScale(iconSize / size.width, iconSize / size.height)
			icon:setPosition(startX + (i - 1) * (iconSize + spaceX) + iconSize / 2, titleHeight + iconSize / 2 + 10)
			self:addChild(icon, 100)
			table.insert(self.titleMedals, icon)
		end

		titleHeight = titleHeight + 30
	end
end

return Hero
