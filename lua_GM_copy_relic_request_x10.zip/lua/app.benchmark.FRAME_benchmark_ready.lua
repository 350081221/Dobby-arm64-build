local FRAME_benchmark_ready = class("FRAME_benchmark_ready", UI_base)

function FRAME_benchmark_ready:ctor(benchmark)
	FRAME_benchmark_ready.super.ctor(self, "frame_benchmark_ready")

	self.benchmark = benchmark

	self:init()
end

function FRAME_benchmark_ready:init()
	self:initUI()
	self:refresh()
end

function FRAME_benchmark_ready:test()
	local conn, battleTime = nil
	local battleInterval = 1

	local function battleLoop()
		local now = Time.time()

		if not battleTime or now >= battleTime + battleInterval then
			battleTime = now

			conn:request("bench_fight", function (rcvData)
			end)
		end
	end

	local function battleStart()
		self:addEnterFrame("battleLoop", battleLoop)
	end

	local tavernTime = nil
	local tavernInterval = 1

	local function tavernLoop()
		local now = Time.time()

		if not tavernTime or now >= tavernTime + tavernInterval then
			tavernTime = now

			conn:request("bench_tavern_refresh", function (rcvData)
			end)
		end
	end

	local function tavernStart()
		self:addEnterFrame("tavernLoop", tavernLoop)
	end

	local gachaTime = nil
	local gachaInterval = 1

	local function gachaLoop()
		local now = Time.time()

		if not gachaTime or now >= gachaTime + gachaInterval then
			gachaTime = now

			conn:request("bench_gacha", function (rcvData)
			end)
		end
	end

	local function gachaStart()
		self:addEnterFrame("gachaLoop", gachaLoop)
	end

	local function newCallback(rcvData1)
		if not rcvData1.err then
			local serverArr = string.split(rcvData1.gateAddr, ":")
			local SERVER_HOST = serverArr[1]
			local SERVER_PORT = tonumber(serverArr[2])
			conn = ConnBench.new()

			conn:init(SERVER_HOST, SERVER_PORT)

			local params = {
				type = InfoUser.AUTH_TYPE.GATE,
				token = tostring(rcvData1.token),
				sys_lang = CONFIG.lang_sys,
				sys_country = CONFIG.country_sys,
				ta_device_id = CONFIG.ta_device_id,
				ta_distinct_id = CONFIG.ta_distinct_id,
				appsflyer_id = CONFIG.appsflyer_id,
				client_os = CONFIG.os,
				lang = Localization.getLang(),
				pack_tag = PACK_TAG
			}

			local function loginCallback(rcvData2)
				if not rcvData2.err then
					local function initCallback(rcvData3)
						if not rcvData3.err then
							battleStart()
							tavernStart()
							gachaStart()
						end
					end

					conn:request("bench_init", initCallback)
				end
			end

			conn:request("auth_login_gate", params, loginCallback)
		end
	end

	Http.request("http://" .. CONFIG.center_addr .. "/?cmd=bench_new", {}, newCallback)
end

function FRAME_benchmark_ready:initUI()
	local codeEB = self:createEditBoxOnComponent("eb_code", onEditFunc)

	codeEB:setText("Ben" .. math.floor(Time.time()) .. "_")

	local startBt = self:getComponentByTag("bt_start")

	startBt:toTouchable()
	startBt:addTap(function ()
		local code = codeEB:getText()

		if code ~= "" then
			local params = {
				code = code,
				max = tonumber(self.maxEB:getText()) or 1000,
				speed = tonumber(self.speedEB:getText()) or 1,
				logInterval = tonumber(self.logIntervalEB:getText()) or 10,
				logMax = tonumber(self.logMaxEB:getText()) or 100
			}
			local eventMap = {}
			local eventArr = {}

			for i, data in ipairs(Benchmark.events) do
				local cookieOpen = Cookie.get("benchmark_open_" .. data.id)
				local isOpen = nil

				if cookieOpen == nil then
					isOpen = true
				else
					isOpen = cookieOpen
				end

				if isOpen then
					local cookieValue = Cookie.get("benchmark_interval_" .. data.id)
					data.interval = cookieValue or data.defaultInterval
					eventMap[data.id] = data
				end
			end

			for i, data in ipairs(Benchmark.events) do
				if data.with then
					if eventMap[data.with] then
						table.insert(eventArr, data)
					end
				elseif eventMap[data.id] then
					table.insert(eventArr, data)
				end
			end

			self.benchmark:start(params, eventMap, eventArr)
		else
			Alert.open("需要设置名字")
		end
	end)

	local function tapListener(ui, data, index, x, y)
		local worldPos = self.list:convertToWorldSpace(cc.p(x, y))

		if ui:hitTestByComponent("bt_open", worldPos.x, worldPos.y, true) then
			local cookieOpen = Cookie.get("benchmark_open_" .. data.id)
			local isOpen = nil

			if cookieOpen == nil then
				isOpen = true
			else
				isOpen = cookieOpen
			end

			Cookie.set("benchmark_open_" .. data.id, not isOpen, true)
			self:delayRefresh()
		end
	end

	self.list = self:createListOnFlag("flag_list", LIST_benchmark_event, tapListener)
	local holder = self:getComponentByTag("holder")

	holder:setOpacity(100)
	self.list:setHolders({
		holder
	}, true)
	self.list:setOnModify(function (data, text)
		local value = tonumber(text) or data.defaultInterval

		Cookie.set("benchmark_interval_" .. data.id, value, true)
		self:delayRefresh()
	end)

	self.maxEB = self:createEditBoxOnComponent("eb_max", function (event, editbox)
		if event == "ended" then
			local text = editbox:getText()

			Cookie.set("benchmark_params_max", tonumber(text) or 1000, true)
		end
	end)

	self.maxEB:setText(Cookie.get("benchmark_params_max") or 1000)

	self.speedEB = self:createEditBoxOnComponent("eb_speed", function (event, editbox)
		if event == "ended" then
			local text = editbox:getText()

			Cookie.set("benchmark_params_speed", tonumber(text) or 1, true)
		end
	end)

	self.speedEB:setText(Cookie.get("benchmark_params_speed") or 1)

	self.logIntervalEB = self:createEditBoxOnComponent("eb_log_interval", function (event, editbox)
		if event == "ended" then
			local text = editbox:getText()

			Cookie.set("benchmark_params_log_interval", tonumber(text) or 10, true)
		end
	end)

	self.logIntervalEB:setText(Cookie.get("benchmark_params_log_interval") or 10)

	self.logMaxEB = self:createEditBoxOnComponent("eb_log_max", function (event, editbox)
		if event == "ended" then
			local text = editbox:getText()

			Cookie.set("benchmark_params_log_max", tonumber(text) or 100, true)
		end
	end)

	self.logMaxEB:setText(Cookie.get("benchmark_params_log_max") or 100)
end

function FRAME_benchmark_ready:delayRefresh()
	self:addEnterFrame("delayRefresh", function ()
		self:refresh()
	end)
end

function FRAME_benchmark_ready:refresh()
	self:removeEnterFrame("delayRefresh")

	local arr = {}

	for i, v in ipairs(Benchmark.events) do
		if not v.with then
			table.insert(arr, v)
		end
	end

	self.list:setItems(arr)
end

return FRAME_benchmark_ready
