import("..lib.BEZ")

local ScrollMap = class("ScrollMap", function (rect, isClipping)
	local node = nil

	if isClipping then
		node = display.newClippingRectangleNode(cc.rect(0, 0, rect.width, rect.height))

		node:setPosition(rect.x, rect.y)
		node:setContentSize(cc.size(rect.width, rect.height))
	else
		node = display.newNode()
	end

	return node
end)
ScrollMap.LAYER = {
	ICON = 1
}
local BLOCK_WIDTH = 100
local BLOCK_HEIGHT = 100

function ScrollMap:ctor(rect)
	event_listener.extendMethods(self, true)
	self:setNodeEventEnabled(true)
	self:setTouchSwallowEnabled(false)
	self:setCascadeOpacityEnabled(true)

	self.bgLayer = display.newNode()

	self.bgLayer:setContentSize(cc.size(rect.width, rect.height))
	self:addChild(self.bgLayer, 1)
	self.bgLayer:setTouchSwallowEnabled(false)
	self.bgLayer:setCascadeOpacityEnabled(true)

	self.containerLayer = display.newNode()

	self.containerLayer:setContentSize(cc.size(rect.width, rect.height))
	self:addChild(self.containerLayer, 2)
	self.containerLayer:setTouchSwallowEnabled(false)
	self.containerLayer:setCascadeOpacityEnabled(true)

	self.bg = display.newNode()

	display.align(self.bg, display.LEFT_TOP, 0, 0)
	self.bgLayer:addChild(self.bg)
	self.bg:setTouchSwallowEnabled(false)
	self.bg:setCascadeOpacityEnabled(true)

	self.container = display.newNode()

	self.containerLayer:addChild(self.container)
	self.container:setTouchSwallowEnabled(false)
	self.container:setCascadeOpacityEnabled(true)

	self.containers = {}
	self.viewRect = rect
	self.stdDragTime = 2
	self.speed = 0
	self.speedDecay = 0.9
	self.angle = 0
	self.inertialThreshold = 5
	self.dragThreshold = 10
	self.zoom = 1
	self.viewZoom = 1
	self.gridVisibleMap = {}
	self.iconInfoGrid = {}
	self.iconInfoMap = {}
	self.iconMap = {}
	self.tagMap = {}
	self.routeSamplingMap = {}
	self.positionOffset = {
		x = 0,
		y = 0
	}
end

function ScrollMap:mapToScreen(mapX, mapY)
	local x, y = self:_mapToScreen(mapX, mapY)

	if self.cameraFlag then
		x, y = self:transToScreen(x, y)
	end

	return x, y
end

function ScrollMap:mapToScale(mapX, mapY)
	local zoom = self.zoom * self.viewZoom

	if self.cameraFlag then
		local x, y = self:_mapToScreen(mapX, mapY)
		local l = math.tan(self.perspective / 180 * math.pi)
		y = (y - display.height / 2) / 0.92 + display.height / 2
		local a = l / 500
		local b = -0.86
		local c = y
		y = (-b - math.sqrt(b * b - 4 * a * c)) / (2 * a)
		local z = 430 - math.tan(self.perspective / 180 * math.pi) * y

		return 485 / z * zoom
	else
		return zoom
	end
end

function ScrollMap:transToPlane(x, y)
	local l = math.tan(self.perspective / 180 * math.pi)
	local z = 430 - l * y
	y = y * z / 500
	y = (y - display.height / 2) * 0.92 + display.height / 2
	x = x - display.width / 2
	x = x * z / 485
	x = x + display.width / 2

	return x, y
end

function ScrollMap:transToScreen(x, y)
	local l = math.tan(self.perspective / 180 * math.pi)
	y = (y - display.height / 2) / 0.92 + display.height / 2
	local a = l / 500
	local b = -0.86
	local c = y
	y = (-b - math.sqrt(b * b - 4 * a * c)) / (2 * a)
	local z = 430 - math.tan(self.perspective / 180 * math.pi) * y
	x = x - display.width / 2
	x = x * 485 / z
	x = x + display.width / 2

	return x, y
end

function ScrollMap:setPerspective(perspective)
	self.cameraFlag = 2
	self.perspective = perspective

	if not self.camera then
		local camera = cc.Camera:createPerspective(60, display.width / display.height, 1, 2000)

		camera:setCameraFlag(self.cameraFlag)
		camera:setPosition3D(cc.Vertex3F(display.width / 2, display.height / 2, 500))
		self.containerLayer:setCameraMask(self.cameraFlag)
		self.bgLayer:setCameraMask(self.cameraFlag)
		camera:lookAt(cc.Vertex3F(display.width / 2, display.height / 2, 0), cc.Vertex3F(0, 1, 0))
		display.getRunningScene():addChild(camera)

		self.camera = camera
	end

	self.containerLayer:setRotation3D(cc.Vertex3F(perspective, 0, 0))
	self.bgLayer:setRotation3D(cc.Vertex3F(perspective, 0, 0))

	for idx, icon in pairs(self.iconMap) do
		local iconInfo = self.iconInfoMap[idx]
		local iconData = self.resData.icons[idx]

		if iconData.plane ~= 1 then
			icon:setRotation3D(cc.Vertex3F(-self.perspective, 0, 0))
		end
	end

	if self.containerChildren then
		for i, v in ipairs(self.containerChildren) do
			local node = v.node
			local isPlane = v.isPlane

			if not isPlane then
				node:setRotation3D(cc.Vertex3F(-self.perspective, 0, 0))
			end
		end
	end
end

function ScrollMap:getContainer(layer)
	if not self.containers[layer] then
		local container = display.newNode()

		display.align(container, display.LEFT_TOP, 0, 0)
		container:setTouchSwallowEnabled(false)
		container:setCascadeOpacityEnabled(true)

		if self.cameraFlag then
			container:setCameraMask(self.cameraFlag)
		end

		self.container:addChild(container, layer)

		self.containers[layer] = container
	end

	return self.containers[layer]
end

function ScrollMap:setTouchListener(func)
	self.additionalTouchListener = func
end

function ScrollMap:load(mapName)
	local path = "res/scrollmap/" .. mapName
	local resPath = path
	local data = JsonParser.parse(path .. "/data.json")
	self.data = data
	local resData = data

	if not empty(data.shared) then
		resPath = "res/scrollmap/" .. data.shared
		resData = JsonParser.parse(resPath .. "/data.json")
	end

	self.resData = resData
	self.bgGrid = {}

	for i = 1, resData.background.width do
		for j = 1, resData.background.height do
			self.bgGrid[i - 1 .. "_" .. j - 1] = getFinalRes(resPath .. "/_background_" .. (j - 1) * resData.background.width + i - 1 .. ".png")
		end
	end

	self.bgSpriteGrid = {}
	self.gridW = resData.background.width
	self.gridH = resData.background.height
	self.gridWidth = resData.background.gridWidth
	self.gridHeight = resData.background.gridHeight
	self.size = {
		x = 0,
		y = 0,
		width = self.gridW * self.gridWidth,
		height = self.gridH * self.gridHeight
	}
	self.border = resData.border
	self.blockRect = {
		x = 0,
		y = 0,
		width = math.floor(self.size.width / BLOCK_WIDTH),
		height = math.floor(self.size.height / BLOCK_HEIGHT)
	}
	self.tagIconBlockMap = {}
	self.tagIndexMap = {}

	for idx, iconData in pairs(resData.icons) do
		iconData.idx = idx

		if iconData.tag ~= "" then
			self.tagMap[iconData.tag] = iconData
			self.tagIndexMap[iconData.tag] = idx
			local blockX = math.floor(iconData.x / BLOCK_WIDTH)
			local blockY = math.floor(iconData.y / BLOCK_HEIGHT)

			if not self.tagIconBlockMap[blockX .. "_" .. blockY] then
				self.tagIconBlockMap[blockX .. "_" .. blockY] = {}
			end

			table.insert(self.tagIconBlockMap[blockX .. "_" .. blockY], iconData)
		end

		if iconData.pic then
			self:addIcon(idx, getFinalRes(resPath .. "/icon_" .. iconData.pic .. ".png"))
		end
	end

	if not empty(data.shared) then
		self.tagMap = {}
		self.tagIconBlockMap = {}
		self.tagIndexMap = {}

		for idx, iconData in pairs(data.icons) do
			iconData.idx = idx

			if iconData.tag ~= "" then
				self.tagMap[iconData.tag] = iconData
				self.tagIndexMap[iconData.tag] = idx
				local blockX = math.floor(iconData.x / BLOCK_WIDTH)
				local blockY = math.floor(iconData.y / BLOCK_HEIGHT)

				if not self.tagIconBlockMap[blockX .. "_" .. blockY] then
					self.tagIconBlockMap[blockX .. "_" .. blockY] = {}
				end

				table.insert(self.tagIconBlockMap[blockX .. "_" .. blockY], iconData)
			end
		end
	end

	self.polygonBlockMap = {}

	if self.data.polygon then
		for i = 1, #self.data.polygon do
			local polygon = self.data.polygon[i]
			local nodes = polygon.nodes
			local minX = self.size.width
			local maxX = 0
			local minY = self.size.height
			local maxY = 0

			for j = 1, #nodes do
				nodes[j].y = self.size.height - nodes[j].y
				minX = math.min(minX, nodes[j].x)
				maxX = math.max(maxX, nodes[j].x)
				minY = math.min(minY, nodes[j].y)
				maxY = math.max(maxY, nodes[j].y)
			end

			local minBlockX = math.floor(minX / BLOCK_WIDTH)
			local maxBlockX = math.floor(maxX / BLOCK_WIDTH)
			local minBlockY = math.floor(minY / BLOCK_HEIGHT)
			local maxBlockY = math.floor(maxY / BLOCK_HEIGHT)

			for ii = minBlockX, maxBlockX do
				for jj = minBlockY, maxBlockY do
					if not self.polygonBlockMap[ii .. "_" .. jj] then
						self.polygonBlockMap[ii .. "_" .. jj] = {}
					end

					table.insert(self.polygonBlockMap[ii .. "_" .. jj], polygon)
				end
			end
		end
	end
end

function ScrollMap:setDraggable(b, onlyDragEvent)
	self.draggable = b
	self.onlyDragEvent = onlyDragEvent
end

function ScrollMap:onTouch(event, x, y)
	if UIManager.isLocked() then
		return false
	end

	if self.cameraFlag then
		x, y = self:transToPlane(x, y)
	end

	if event == "began" then
		return self:onTouchBegan(x, y)
	elseif event == "moved" then
		self:onTouchMoved(x, y)
	elseif event == "ended" then
		self:onTouchEnded(x, y)
	else
		self:onTouchCancelled(x, y)
	end

	return true
end

function ScrollMap:onTouchBegan(x, y)
	x = x / self.zoom
	y = y / self.zoom

	self:stopScrolling()

	local mapX, mapY = self:_screenToMap(x, y)
	self.selectedTag = self:getCurrentSelectTag(mapX, mapY)
	self.drag = {
		angle = 0,
		speed = 0,
		mapX = self.x,
		mapY = self.y,
		startX = x,
		startY = y,
		preX = x,
		preY = y,
		preTime = os.clock(),
		prePositions = {
			{
				x = x,
				y = y
			}
		},
		isTap = self.selectedTag ~= nil
	}

	return true
end

function ScrollMap:onTouchMoved(x, y)
	if not self.drag then
		return
	end

	x = x / self.zoom
	y = y / self.zoom
	local distance = math.sqrt(math.pow(x - self.drag.startX, 2) + math.pow(y - self.drag.startY, 2))

	if self.drag.isTap and self.dragThreshold <= distance then
		self.drag.isTap = false
		local angle = math.atan2(y - self.drag.startY, x - self.drag.startX)
		self.drag.startX = self.drag.startX + self.dragThreshold * math.cos(angle)
		self.drag.startY = self.drag.startY + self.dragThreshold * math.sin(angle)
	end

	if not self.drag.isTap and self.draggable then
		local scrollX = self.drag.mapX - (x - self.drag.startX) / self.viewZoom
		local scrollY = self.drag.mapY - (y - self.drag.startY) / self.viewZoom

		if self.onlyDragEvent then
			self:dispatchEvent({
				name = "drag",
				x = scrollX,
				y = scrollY
			})
		else
			self:scrollTo(scrollX, scrollY)
		end

		local clock = os.clock()
		local offsetTime = clock - self.drag.preTime

		if offsetTime > 0 then
			local standardTime = self.stdDragTime / 100
			local distance = math.sqrt(math.pow(x - self.drag.preX, 2) + math.pow(y - self.drag.preY, 2))
			self.drag.speed = (self.drag.speed * standardTime + distance * standardTime / offsetTime * offsetTime) / (offsetTime + standardTime)
			self.drag.angle = math.atan2(y - self.drag.prePositions[1].y, x - self.drag.prePositions[1].x)
		end

		self.drag.preTime = clock
		self.drag.preX = x
		self.drag.preY = y

		table.insert(self.drag.prePositions, {
			x = x,
			y = y
		})

		if #self.drag.prePositions > 3 then
			table.remove(self.drag.prePositions, 1)
		end
	end
end

function ScrollMap:onTouchEnded(x, y)
	if not self.drag then
		return
	end

	x = x / self.zoom
	y = y / self.zoom
	local clock = os.clock()
	local offsetTime = clock - self.drag.preTime

	if offsetTime > 0 then
		local standardTime = self.stdDragTime / 100
		local distance = math.sqrt(math.pow(x - self.drag.preX, 2) + math.pow(y - self.drag.preY, 2))
		self.drag.speed = (self.drag.speed * standardTime + distance * standardTime / offsetTime * offsetTime) / (offsetTime + standardTime)
		self.drag.angle = math.atan2(y - self.drag.prePositions[1].y, x - self.drag.prePositions[1].x)
	end

	if self.draggable and self.inertialThreshold < math.abs(self.drag.speed) then
		self.speed = self.drag.speed
		self.angle = self.drag.angle

		self:addEnterFrame("inertialScroll", handler(self, self.inertialScroll))
	else
		self.speed = 0
	end

	if self.drag.isTap then
		self:dispatchEvent({
			name = "onTapTag",
			tagData = self.selectedTag
		})
	end

	self.drag = nil
end

function ScrollMap:_screenToMap(x, y)
	x = x - self.positionOffset.x
	y = y - self.positionOffset.y
	local zoom = self.zoom * self.viewZoom
	local xOffset = x / zoom - (self.viewRect.width / zoom / 2 - self.x)
	local yOffset = y / zoom - (self.viewRect.height / zoom / 2 - self.y)

	return xOffset, self.size.height - yOffset
end

function ScrollMap:_mapToScreen(xOffset, yOffset)
	local zoom = self.zoom * self.viewZoom
	local x = (xOffset + self.viewRect.width / zoom / 2 - self.x) * zoom
	local y = (yOffset + self.viewRect.height / zoom / 2 - self.y) * zoom
	x = x + self.positionOffset.x
	y = y + self.positionOffset.y
	y = self.size.height - y

	return x, y
end

function ScrollMap:onTouchCancelled(x, y)
	self.drag = nil
end

function ScrollMap:inertialScroll()
	self.speed = self.speed * self.speedDecay

	if math.abs(self.speed) < 0.1 then
		self:removeEnterFrame("inertialScroll")
	end

	local x = self.x - math.cos(self.angle) * self.speed
	local y = self.y - math.sin(self.angle) * self.speed

	if self.onlyDragEvent then
		self:dispatchEvent({
			name = "drag",
			x = x,
			y = y
		})
	else
		self:scrollTo(x, y)
	end
end

local TOUCH_RADIUS = 60

function ScrollMap:getCurrentSelectTag(x, y)
	local blockX = math.floor(x / BLOCK_WIDTH)
	local blockY = math.floor(y / BLOCK_HEIGHT)
	local minBlockX = math.max(0, blockX - 1)
	local maxBlockX = math.min(self.blockRect.width, blockX + 1)
	local minBlockY = math.max(0, blockY - 1)
	local maxBlockY = math.min(self.blockRect.height, blockY + 1)
	local sortArr = {}

	for bx = minBlockX, maxBlockX do
		for by = minBlockY, maxBlockY do
			local tag = bx .. "_" .. by
			local tagArr = self.tagIconBlockMap[tag]

			if tagArr then
				for i, iconData in ipairs(tagArr) do
					local checkOK = false

					if iconData.checkTouch then
						checkOK = iconData.checkTouch(x, y)
					end

					local distance = nil

					if not checkOK then
						distance = math.sqrt(math.pow(iconData.x - x, 2) + math.pow(iconData.y - y, 2))
						checkOK = distance <= TOUCH_RADIUS
					end

					if checkOK then
						distance = distance or math.sqrt(math.pow(iconData.x - x, 2) + math.pow(iconData.y - y, 2))

						table.insert(sortArr, {
							distance = distance,
							iconData = iconData
						})
					end
				end
			end
		end
	end

	if #sortArr > 0 then
		table.sort(sortArr, function (a, b)
			return a.distance < b.distance
		end)

		return sortArr[1].iconData
	end
end

function ScrollMap:addToContainer(node, layer, isPlane, x, y)
	self.containerChildren = self.containerChildren or {}

	node:setPosition(x, y)
	self:getContainer(layer):addChild(node, -y)
	table.insert(self.containerChildren, {
		node = node,
		isPlane = isPlane
	})

	if self.cameraFlag then
		self:setCameraMaskRecursive(node)

		if not isPlane then
			node:setRotation3D(cc.Vertex3F(-self.perspective, 0, 0))
		end
	end
end

function ScrollMap:addToTag(node, layer, isPlane, tag)
	local tagData = self:getIconData(tag)

	if tagData then
		self:addToContainer(node, layer, isPlane, tagData.x, self.size.height - tagData.y)
	end
end

function ScrollMap:setCameraMaskRecursive(node)
	node:setCameraMask(self.cameraFlag)

	if node.getChildren then
		local children = node:getChildren()

		for i = 1, #children do
			self:setCameraMaskRecursive(children[i])
		end
	end
end

function ScrollMap:addIcon(idx, iconPath, layer, callback)
	layer = layer or ScrollMap.LAYER.ICON
	local iconData = self.resData.icons[idx]
	local size = nil

	if empty(iconPath) then
		size = cc.size(0, 0)
	else
		local icon = display.newSprite(iconPath)

		self:getContainer(layer):addChild(icon)

		size = icon:getContentSize()

		icon:removeSelf()
	end

	local xRatio = 0.5
	local yRatio = 0.5

	if iconData.offset.x ~= 0 or iconData.offset.y ~= 0 then
		xRatio = 0.5 - iconData.offset.x / size.width
		yRatio = 0.5 + iconData.offset.y / size.height
	end

	local maxX = math.floor((size.width * xRatio + iconData.x) / self.gridWidth)
	local minX = math.floor(((1 - size.width) * xRatio + iconData.x) / self.gridWidth)
	local maxY = math.floor((size.height * yRatio + iconData.y) / self.gridHeight)
	local minY = math.floor(((1 - size.height) * yRatio + iconData.y) / self.gridHeight)
	local iconInfo = {
		idx = idx,
		iconPath = iconPath,
		layer = layer,
		callback = callback
	}
	self.iconInfoMap[idx] = iconInfo
	iconInfo.minX = minX
	iconInfo.maxX = maxX
	iconInfo.minY = minY
	iconInfo.maxY = maxY
	local needDraw = false

	for i = minX, maxX do
		for j = minY, maxY do
			local tag = i .. "_" .. j

			if not self.iconInfoGrid[tag] then
				self.iconInfoGrid[tag] = {}
			end

			table.insert(self.iconInfoGrid[i .. "_" .. j], iconInfo)

			if self.bgSpriteGrid[tag] then
				needDraw = true
			end
		end
	end

	if needDraw then
		self:drawIconInfo(iconInfo, true)
	end
end

function ScrollMap:drawIconGrid(x, y)
	local tag = x .. "_" .. y
	local icons = self.iconInfoGrid[tag]

	if icons then
		for i = 1, #icons do
			self:drawIconInfo(icons[i])
		end
	end
end

function ScrollMap:drawIconInfo(iconInfo, force)
	local idx = iconInfo.idx

	if not self.iconMap[idx] or force then
		if self.iconMap[idx] then
			self.iconMap[idx]:removeSelf()

			self.iconMap[idx] = nil
		end

		local layer = iconInfo.layer
		local iconPath = iconInfo.iconPath
		local callback = iconInfo.callback
		local iconData = self.resData.icons[idx]
		local icon = nil

		if empty(iconPath) then
			icon = display.newNode()
		else
			icon = display.newSprite(iconPath)
		end

		local size = icon:getContentSize()

		if iconData.offset.x ~= 0 or iconData.offset.y ~= 0 then
			icon:setAnchorPoint(cc.p(0.5 - iconData.offset.x / size.width, 0.5 + iconData.offset.y / size.height))
		end

		local y = self.size.height - iconData.y

		icon:setPosition(iconData.x, y)

		if self.cameraFlag then
			icon:setCameraMask(self.cameraFlag)
		end

		self:getContainer(layer):addChild(icon, -y)

		if not iconData.plane ~= 1 and self.cameraFlag then
			icon:setRotation3D(cc.Vertex3F(-self.perspective, 0, 0))
		end

		if callback then
			callback(icon)
		end

		self.iconMap[idx] = icon
	end
end

function ScrollMap:eraseIconGrid(x, y)
	local tag = x .. "_" .. y
	local icons = self.iconInfoGrid[tag]

	if icons then
		for i = 1, #icons do
			local iconInfo = icons[i]
			local minX = iconInfo.minX
			local maxX = iconInfo.maxX
			local minY = iconInfo.minY
			local maxY = iconInfo.maxY
			local canErase = true

			for i = minX, maxX do
				for j = minY, maxY do
					local tag = i .. "_" .. j

					if self.gridVisibleMap[tag] then
						canErase = false

						break
					end
				end

				if not canErase then
					break
				end
			end

			if canErase then
				local idx = iconInfo.idx

				if self.iconMap[idx] then
					self.iconMap[idx]:removeSelf()

					self.iconMap[idx] = nil
				end
			end
		end
	end
end

function ScrollMap:getIcon(idx)
	return self.iconMap[idx]
end

function ScrollMap:getTagPosition(tag)
	local iconData = self.tagMap[tag]

	if iconData then
		return iconData.x - (iconData.offset.x or 0), self.size.height - (iconData.y + (iconData.offset.y or 0))
	end
end

function ScrollMap:getIconData(tag)
	return self.tagMap[tag]
end

function ScrollMap:getIconDatas()
	return self.resData.icons
end

function ScrollMap:getNearTag(x, y, range, filter)
	y = self.size.height - y
	local minBlockX = math.floor((x - range) / BLOCK_WIDTH)
	local maxBlockX = math.floor((x + range) / BLOCK_WIDTH)
	local minBlockY = math.floor((y - range) / BLOCK_HEIGHT)
	local maxBlockY = math.floor((y + range) / BLOCK_HEIGHT)
	local bestDistance, bestTag = nil

	for i = minBlockX, maxBlockX do
		for j = minBlockY, maxBlockY do
			local tagIcons = self.tagIconBlockMap[i .. "_" .. j]

			if tagIcons then
				for i = 1, #tagIcons do
					local iconData = tagIcons[i]
					local is = false

					if filter == nil then
						is = true
					elseif type(filter) == "string" then
						is = string.find(iconData.tag, filter)
					elseif type(filter) == "function" then
						is = filter(iconData.tag)
					end

					if is then
						local distance = math.sqrt(math.pow(iconData.x - x, 2) + math.pow(iconData.y - y, 2))

						if distance <= range and (not bestDistance or distance < bestDistance) then
							bestDistance = distance
							bestTag = iconData.tag
						end
					end
				end
			end
		end
	end

	return bestTag
end

function ScrollMap:getBorder()
	if self.border then
		return self.border
	else
		return self.size
	end
end

function ScrollMap:scrollTo(x, y)
	local halfWidth = self.viewRect.width / 2 / self.zoom
	local halfHeight = self.viewRect.height / 2 / self.zoom
	local minX = halfWidth - self.viewRect.x
	local minY = halfHeight - self.viewRect.y
	local maxX = self.size.width - halfWidth - self.viewRect.x
	local maxY = self.size.height - halfHeight - self.viewRect.y

	if self.border then
		minX = minX + self.border.x / self.zoom
		minY = minY + (self.size.height - self.border.height - self.border.y) / self.zoom
		maxX = maxX - (self.size.width - self.border.width - self.border.x) / self.zoom
		maxY = maxY - self.border.y / self.zoom
	end

	x = math.min(maxX, math.max(minX, x or self.x))
	y = math.min(maxY, math.max(minY, y or self.y))

	if x < minX then
		x = (x - minX) / 2 + minX
	end

	if y < minY then
		y = (y - minY) / 2 + minY
	end

	x = x or self.x
	y = y or self.y
	local preX = self.x
	local preY = self.y
	self.x = x
	self.y = y
	local localX = -self.x * self.zoom * self.viewZoom + self.viewRect.width / 2
	local localY = -self.y * self.zoom * self.viewZoom + self.viewRect.height / 2

	self.bg:setPosition(localX + self.positionOffset.x, localY + self.size.height * self.zoom * self.viewZoom + self.positionOffset.y)
	self.container:setPosition(localX + self.positionOffset.x, localY + self.positionOffset.y)

	local cameraBorder = 150
	local gridX = math.floor((x - halfWidth - cameraBorder) / self.gridWidth)
	local gridY = math.floor((y - halfHeight - cameraBorder) / self.gridHeight)
	local gridXMax = math.floor((x + halfWidth + cameraBorder) / self.gridWidth)
	local gridYMax = math.floor((y + halfHeight + cameraBorder) / self.gridHeight)
	local newRect = {
		x = gridX,
		y = gridY,
		width = gridXMax - gridX + 1,
		height = gridYMax - gridY + 1
	}
	local oldRect = nil

	if preX then
		local preGridX = math.floor((preX - halfWidth - cameraBorder) / self.gridWidth)
		local preGridY = math.floor((preY - halfHeight - cameraBorder) / self.gridHeight)
		local preGridXMax = math.floor((preX + halfWidth + cameraBorder) / self.gridWidth)
		local preGridYMax = math.floor((preY + halfHeight + cameraBorder) / self.gridHeight)
		oldRect = {
			x = preGridX,
			y = preGridY,
			width = preGridXMax - preGridX + 1,
			height = preGridYMax - preGridY + 1
		}
	end

	local newArr, oldArr = MapUtils.compareRect(newRect, oldRect)

	for i = 1, #newArr do
		self:drawGrid(newArr[i].x, newArr[i].y)
	end

	for i = 1, #oldArr do
		self:eraseGrid(oldArr[i].x, oldArr[i].y)
	end

	if self.additionalScrollListener then
		self.additionalScrollListener(x, y)
	end
end

function ScrollMap:setScrollListener(func)
	self.additionalScrollListener = func
end

function ScrollMap:drawGrid(x, y)
	y = self.gridH - 1 - y
	local tag = x .. "_" .. y
	self.gridVisibleMap[tag] = true

	if self.bgGrid[tag] and not self.bgSpriteGrid[tag] then
		local sprite = display.newSprite(self.bgGrid[tag])

		if self.cameraFlag then
			sprite:setCameraMask(self.cameraFlag)
		end

		display.align(sprite, display.TOP_LEFT)
		sprite:setPosition(x * self.gridWidth, -y * self.gridHeight)
		self.bg:addChild(sprite)

		self.bgSpriteGrid[tag] = sprite

		self:drawIconGrid(x, y)
	end
end

function ScrollMap:eraseGrid(x, y)
	y = self.gridH - 1 - y
	local tag = x .. "_" .. y
	self.gridVisibleMap[tag] = nil

	if self.bgSpriteGrid[tag] then
		self.bgSpriteGrid[tag]:removeSelf()

		self.bgSpriteGrid[tag] = nil

		self:eraseIconGrid(x, y)
	end
end

function ScrollMap:scrollToTag(tag, xOffset, yOffset)
	local iconData = self.tagMap[tag]
	xOffset = xOffset or 0
	yOffset = yOffset or 0

	self:scrollTo(iconData.x - self.viewRect.x / self.zoom + xOffset, self.size.height - iconData.y + self.viewRect.y / self.zoom + yOffset)
end

function ScrollMap:tweenTo(x, y, time, easing, onComplete, onUpdate)
	self:stopScrolling()

	local startObj = {
		x = self.x,
		y = self.y
	}
	local endObj = {
		x = x,
		y = y
	}

	local function _onComplete()
		self:scrollTo(startObj.x, startObj.y)

		if onComplete then
			onComplete()
		end

		if onUpdate then
			onUpdate(true)
		end
	end

	local function _onUpdate()
		self:scrollTo(startObj.x, startObj.y)

		if onUpdate then
			onUpdate()
		end
	end

	self.tweenID = Looper.tween(time, startObj, endObj, easing or "linear", _onComplete, _onUpdate)
end

function ScrollMap:tweenToTag(tag, time, easing, onComplete)
	local iconData = self.tagMap[tag]

	self:tweenTo(iconData.x - self.viewRect.x / self.zoom, self.size.height - iconData.y + self.viewRect.y / self.zoom, time, easing, onComplete)
end

function ScrollMap:stopScrolling()
	self.xBeforZoom = nil
	self.yBeforZoom = nil
	self.scrollX = nil
	self.scrollY = nil

	self:removeEnterFrame("inertialScroll")

	if self.tweenID then
		Looper.stopTween(self.tweenID)

		self.tweenID = nil
	end
end

function ScrollMap:setPositionOffset(x, y)
	self.positionOffset.x = x
	self.positionOffset.y = y

	if self.data and self.x then
		self:scrollTo(self.x, self.y)
	end
end

function ScrollMap:setZoom(zoom)
	self.zoom = zoom

	self.bg:setScale(self.zoom * self.viewZoom)
	self.container:setScale(self.zoom * self.viewZoom)

	if self.data then
		self:scrollTo(self.x, self.y)
	end
end

function ScrollMap:setViewZoom(viewZoom)
	self.viewZoom = viewZoom

	self.bg:setScale(self.zoom * self.viewZoom)
	self.container:setScale(self.zoom * self.viewZoom)

	if self.data then
		self:scrollTo(self.x, self.y)
	end
end

function ScrollMap:tweenViewZoom(viewZoom, time, easing)
	if self.tweenViewZoomID then
		Looper.stopTween(self.tweenViewZoomID)

		self.tweenViewZoomID = nil
	end

	local startObj = {
		zoom = self.viewZoom
	}
	local endObj = {
		zoom = viewZoom
	}

	local function onUpdate()
		self:setViewZoom(startObj.zoom)
	end

	self.tweenViewZoomID = Looper.tween(time, startObj, endObj, easing or "linear", onUpdate, onUpdate)
end

ScrollMap.FIT_NO_BORDER = 1
ScrollMap.FIT_SHOW_ALL = 2
ScrollMap.FIT_FIXED_WIDTH = 3
ScrollMap.FIT_FIXED_HEIGHT = 4

function ScrollMap:fitZoom(size, policy)
	local zoom = 1

	if policy == ScrollMap.FIT_NO_BORDER then
		zoom = math.max(size.width / self.size.width, size.height / self.size.height)
	elseif policy == ScrollMap.FIT_SHOW_ALL then
		zoom = math.min(size.width / self.size.width, size.height / self.size.height)
	elseif policy == ScrollMap.FIT_FIXED_WIDTH then
		zoom = size.width / self.size.width
	elseif policy == ScrollMap.FIT_FIXED_HEIGHT then
		zoom = size.height / self.size.height
	end

	self:setZoom(zoom)
end

function ScrollMap:inPolygons(x, y)
	if self.data.polygon then
		local blockX = math.floor(x / BLOCK_WIDTH)
		local blockY = math.floor(y / BLOCK_HEIGHT)
		local blockPolygons = self.polygonBlockMap[blockX .. "_" .. blockY]

		if blockPolygons then
			for i = 1, #blockPolygons do
				local polygon = blockPolygons[i]

				if self:insidePolygon(x, y, polygon) then
					return true, polygon
				end
			end
		end
	end

	return false
end

function ScrollMap:inPolygonsAll(x, y, exceptPolygon, checkFunc)
	local result = false
	local polygons = {}

	if self.data.polygon then
		local blockX = math.floor(x / BLOCK_WIDTH)
		local blockY = math.floor(y / BLOCK_HEIGHT)
		local blockPolygons = self.polygonBlockMap[blockX .. "_" .. blockY]

		if blockPolygons then
			for i = 1, #blockPolygons do
				local polygon = blockPolygons[i]

				if exceptPolygon ~= polygon and (not checkFunc or checkFunc(polygon)) and self:insidePolygon(x, y, polygon) then
					result = true

					table.insert(polygons, polygon)
				end
			end
		end
	end

	return result, polygons
end

function ScrollMap:insidePolygon(x, y, polygon)
	local oddNodes = false
	local nodes = polygon.nodes
	local j = #nodes

	for i = 1, #nodes do
		if y <= nodes[i].y ~= (y <= nodes[j].y) and x <= (nodes[j].x - nodes[i].x) * (y - nodes[i].y) / (nodes[j].y - nodes[i].y) + nodes[i].x then
			oddNodes = not oddNodes
		end

		j = i
	end

	return oddNodes
end

function ScrollMap:hasRoute(fromTag, toTag)
	local code = self:getRouteCode(fromTag, toTag)

	return self.data.bez[code] ~= nil
end

function ScrollMap:findPath(fromTag, toTag, checkOpen)
	local fromIndex = tonumber(self.tagIndexMap[fromTag])
	local toIndex = tonumber(self.tagIndexMap[toTag])
	local fromNode = {
		index = fromIndex
	}
	local openArr = {
		fromNode
	}
	local closedMap = {
		[fromIndex] = fromNode
	}
	local toNode = nil

	while #openArr > 0 do
		local currNode = table.remove(openArr, 1)
		local currIndex = currNode.index
		local links = self.resData.icons[tostring(currNode.index)].link

		for i, linkIndex in ipairs(links) do
			linkIndex = tonumber(linkIndex)

			if not closedMap[linkIndex] then
				local node = {
					index = linkIndex,
					parent = currIndex
				}

				if linkIndex == toIndex then
					toNode = node

					break
				end

				if not checkOpen or checkOpen(linkIndex) then
					table.insert(openArr, node)

					closedMap[linkIndex] = node
				end
			end
		end

		if toNode then
			break
		end
	end

	if toNode then
		local node = toNode
		local path = {
			self.resData.icons[tostring(node.index)].tag
		}

		while node.parent do
			node = closedMap[node.parent]

			table.insert(path, 1, self.resData.icons[tostring(node.index)].tag)
		end

		return path
	end
end

local samplingNum = 100
local samplingRouteLengthMap = nil

function ScrollMap:samplingRouteLength(fromTag, toTag)
	local code = self:getRouteCode(fromTag, toTag)

	if not samplingRouteLengthMap then
		samplingRouteLengthMap = {}
	end

	if not samplingRouteLengthMap[code] then
		local totalDistance = 0

		if not self.routeSamplingMap[code] then
			local prePos = self:bez(code, 0)

			for i = 1, samplingNum do
				local pos = self:bez(code, i / samplingNum)
				local distance = math.sqrt(math.pow(pos.y - prePos.y, 2) + math.pow(pos.x - prePos.x, 2))
				totalDistance = totalDistance + distance
				prePos = pos
			end
		end

		samplingRouteLengthMap[code] = totalDistance
	end

	return samplingRouteLengthMap[code]
end

function ScrollMap:samplingRoute(fromTag, toTag, percent)
	local code, percent = self:getRouteCode(fromTag, toTag, percent)

	if not self.routeSamplingMap[code] then
		local totalDistance = 0
		local preX, preY = self:getTagPosition(fromTag)

		for i = 0, samplingNum do
			local currPercent = i / samplingNum
			local pos = self:bez(code, currPercent)
			local distance = math.sqrt(math.pow(-pos.y - preY, 2) + math.pow(pos.x - preX, 2))
			preX = pos.x
			preY = -pos.y
			totalDistance = totalDistance + distance
		end

		local preX, preY = self:getTagPosition(fromTag)
		local prePercent = 0
		local addonDistance = 0
		local samplingMap = {
			[0] = 0
		}

		for i = 0, samplingNum do
			local currPercent = i / samplingNum
			local pos = self:bez(code, currPercent)
			local distance = math.sqrt(math.pow(-pos.y - preY, 2) + math.pow(pos.x - preX, 2))
			local nextDistance = addonDistance + distance
			local nextDisPer = nextDistance / totalDistance
			local addonDisPer = addonDistance / totalDistance
			local nextDisPerD = math.floor(nextDisPer * samplingNum)
			local addonDisPerD = math.floor(addonDisPer * samplingNum)

			if addonDisPerD < nextDisPerD then
				for i = addonDisPerD + 1, nextDisPerD do
					local samplingPercent = (i - addonDisPer * samplingNum) / (nextDisPer * samplingNum - addonDisPer * samplingNum) * (currPercent - prePercent) + prePercent
					samplingMap[i] = samplingPercent
				end
			end

			addonDistance = nextDistance
			preX = pos.x
			preY = -pos.y
			prePercent = currPercent
		end

		self.routeSamplingMap[code] = samplingMap
	end

	local samplingMap = self.routeSamplingMap[code]
	local index = math.floor(percent * samplingNum)
	local samplingPercent1 = samplingMap[index]
	local samplingPercent2 = samplingMap[math.min(samplingNum, index + 1)]
	local samplingPercent = (samplingPercent2 - samplingPercent1) * (percent - index / samplingNum) + samplingPercent1
	local pos = self:bez(code, samplingPercent)

	return pos.x, -pos.y
end

function ScrollMap:route(fromTag, toTag, percent)
	local code, percent = self:getRouteCode(fromTag, toTag, percent)
	local pos = self:bez(code, percent)

	return pos.x, self.size.height - pos.y
end

function ScrollMap:bez(code, percent)
	local pos = P_BEZ(percent, self.data.bez[code])

	return pos
end

function ScrollMap:getRouteCode(fromTag, toTag, percent)
	local fromIndex = tonumber(self.tagIndexMap[fromTag])
	local toIndex = tonumber(self.tagIndexMap[toTag])
	percent = percent and math.max(0, math.min(percent, 1))
	local code = nil

	if fromIndex < toIndex then
		code = fromIndex .. "_&_" .. toIndex
	else
		code = toIndex .. "_&_" .. fromIndex
		percent = percent and 1 - percent
	end

	return code, percent
end

function ScrollMap:checkNeibourInAngle(tag, angle, angleThrehold)
	angleThrehold = angleThrehold or math.pi / 3
	local tagData = self.resData.icons[tag]
	local bestNeibour, bestAngle = nil
	local neibours = tagData.link

	for i = 1, #neibours do
		local neibourTag = neibours[i]
		local neibourData = self.resData.icons[neibourTag]
		local neibourAngle = math.atan2(-(neibourData.y - tagData.y), neibourData.x - tagData.x)
		local angleOffset = math.abs(angle - neibourAngle)

		if math.pi < angleOffset then
			angleOffset = math.pi * 2 - angleOffset
		end

		if not bestAngle and angleOffset <= angleThrehold or bestAngle and angleOffset < bestAngle then
			bestAngle = angleOffset
			bestNeibour = neibourTag
		end
	end

	return bestNeibour
end

function ScrollMap:addEnterFrame(name, func)
	if self.enterFrameStack == nil then
		self.enterFrameStack = {}
	end

	self.enterFrameStack[name] = func

	if table.nums(self.enterFrameStack) == 1 then
		self:unscheduleUpdate()
		self:addNodeEventListener(cc.NODE_ENTER_FRAME_EVENT, function ()
			self:onEnterFrame()
		end)
		self:scheduleUpdate()
	end
end

function ScrollMap:removeEnterFrame(name)
	if self.enterFrameStack == nil then
		return
	end

	self.enterFrameStack[name] = nil

	if table.nums(self.enterFrameStack) == 0 then
		self:unscheduleUpdate()
	end
end

function ScrollMap:onEnterFrame()
	for name, func in pairs(self.enterFrameStack) do
		func()
	end
end

function ScrollMap:onExit()
	if not app.sceneChanging then
		if self.tweenViewZoomID then
			Looper.stopTween(self.tweenViewZoomID)

			self.tweenViewZoomID = nil
		end

		self:stopScrolling()
		self:removeAllEventListeners()
		self.bgLayer:removeNodeEventListener(cc.NODE_TOUCH_EVENT)

		if self.camera then
			self.camera:removeSelf()

			self.camera = nil
		end
	end
end

return ScrollMap
