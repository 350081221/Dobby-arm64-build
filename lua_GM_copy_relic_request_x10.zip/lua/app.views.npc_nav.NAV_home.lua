local NAV_base = import(".NAV_base")
local NAV_home = class("NAV_home", NAV_base)

function NAV_home.open(npc)
	local ui = NAV_home.new(npc)

	return ui
end

function NAV_home:ctor(npc)
	NAV_home.super.ctor(self, npc, "nav_home")
end

function NAV_home:init()
	NAV_pet.super.init(self)

	local index = 4
	local ui = self.buttons[index].ui

	ui:createBarByTag("progress", NAV_base.COLOR.HIGH, true)
	self:refresh()
	ManagerInfo.onDataChange(self, "delay_item", nil, function (data)
		self:refresh()
	end)
end

function NAV_home:refresh()
	local index = 4
	local ui = self.buttons[index].ui
	local redotCount = InfoDelayItem.countReady(InfoHome.DELAY_TYPES)
	local redot = ui:getComponentByTag("redot")

	redot:setVisible(redotCount > 0)

	local percent = InfoDelayItem.getBestProgress(InfoHome.DELAY_TYPES)

	if percent > 0 then
		ui:setBarProgressByTag("progress", math.min(1, percent))
	else
		ui:setBarProgressByTag("progress", 0)
	end
end

function NAV_home:onTap(index)
	NAV_home.super.onTap(self, index)

	if index == 1 then
		local mapItem = InfoHome.getCurrentMapItem()

		if mapItem then
			InfoHome.enter(mapItem)
		else
			Alert.open(Localization.getSrcText("没有可用的地契"))
		end
	elseif index == 2 then
		POP_notice_input.open(Localization.getSrcText("输入玩家代码"), Localization.getSrcText("大小写不敏感"), "", nil, function (code)
			local inst_id = InfoUser.decodeID(code)

			if inst_id then
				InfoHome.visit(inst_id)
			else
				Alert.open(Localization.getSrcText("玩家不存在"))
			end
		end)
	elseif index == 3 then
		FRAME_big_shop.open(InfoHome, self.npc)
	elseif index == 4 then
		FRAME_delay_item.open(InfoHome.DELAY_TYPES)
	end
end

return NAV_home
