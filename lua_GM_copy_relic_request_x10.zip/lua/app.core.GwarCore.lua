local GwarCore = class("GwarCore")
local JOBS = {
	1,
	2,
	3
}
GwarCore.JOBS = JOBS
local TYPE = {
	PVE = 2,
	PVP = 1
}
GwarCore.TYPE = TYPE
local TEAM_TYPE = {
	PLAYER = 1,
	MONSTER = 2
}
GwarCore.TEAM_TYPE = TEAM_TYPE
local JOB = {
	S = 10,
	M = 3,
	A = 2,
	W = 1
}
GwarCore.JOB = JOB
local UNIT_SORT = {
	[JOB.W] = 1,
	[JOB.A] = 3,
	[JOB.M] = 2
}
GwarCore.UNIT_SORT = UNIT_SORT
local TURN_TYPE = {
	FORWARD = 2,
	ATTACK = 1
}
GwarCore.TURN_TYPE = TURN_TYPE
local TURNS = {
	{
		type = TURN_TYPE.FORWARD
	},
	{
		turn = 1,
		type = TURN_TYPE.ATTACK
	},
	{
		type = TURN_TYPE.FORWARD
	},
	{
		type = TURN_TYPE.ATTACK,
		job = JOB.M
	},
	{
		type = TURN_TYPE.FORWARD
	},
	{
		turn = 2,
		type = TURN_TYPE.ATTACK
	},
	{
		type = TURN_TYPE.FORWARD
	},
	{
		type = TURN_TYPE.ATTACK,
		job = JOB.A
	},
	{
		type = TURN_TYPE.FORWARD
	},
	{
		turn = 3,
		type = TURN_TYPE.ATTACK
	},
	{
		type = TURN_TYPE.FORWARD
	},
	{
		type = TURN_TYPE.ATTACK,
		job = JOB.W
	},
	{
		type = TURN_TYPE.FORWARD
	},
	{
		turn = 4,
		type = TURN_TYPE.ATTACK
	}
}
local RAW_ARR = {
	3,
	2,
	4,
	1,
	5
}
GwarCore.RAW_ARR = RAW_ARR
local CAMP_ARR = {
	{
		1,
		2
	},
	{
		2,
		1
	}
}
local UNIT_KEY = {
	[JOB.W] = "w",
	[JOB.A] = "a",
	[JOB.M] = "m",
	[JOB.S] = "s"
}
GwarCore.UNIT_KEY = UNIT_KEY

function GwarCore.makeHero(heroInfo)
	heroInfo.attrs = {}

	for i, attrKey in ipairs(CombatAttr.attrs) do
		heroInfo.attrs[attrKey] = heroInfo["attr_" .. attrKey]
	end

	local heroCSV = CsvParser.getCsvData("hero", heroInfo.base_id)
	heroInfo.job = heroCSV.class
end

function GwarCore.getTestUnit(heroInfo)
	local data = {
		base_id = heroInfo.base_id,
		name = heroInfo.name,
		body = heroInfo.body,
		hair = heroInfo.hair
	}
	local heroCSV = CsvParser.getCsvData("hero", data.base_id)
	local equipArr = InfoEquip.getEquipListOnHero(heroInfo.id)

	for i, equipInfo in ipairs(equipArr) do
		local equipCSV = CsvParser.getCsvData("equip", equipInfo.base_id)

		if GameConfig.display_equip_pos[equipCSV.equip_pos] then
			if not empty(equipInfo.illusion) then
				data["equip_" .. equipCSV.equip_pos] = equipInfo.illusion
			else
				data["equip_" .. equipCSV.equip_pos] = equipInfo.base_id
			end
		end
	end

	local showEquipArr = InfoEquip.getShowEquipListOnHero(heroInfo.id)

	for i, equipInfo in ipairs(showEquipArr) do
		local equipCSV = CsvParser.getCsvData("equip", equipInfo.base_id)
		data["equip_" .. equipCSV.equip_pos] = equipInfo.base_id
	end

	local attrs = CombatAttr.getHeroAttr(heroInfo, nil, , , , true)

	CombatAttr.finalize(attrs, nil, true)

	local attr_raw = CsvParser.getCsvRaw("attr")
	local addTotal = 0
	local multiTotal = 0

	for k, v in pairs(attr_raw) do
		if attrs[k] then
			if v.ability_value1 ~= 0 then
				addTotal = addTotal + attrs[k] * v.ability_value1
			end

			if v.ability_value2 ~= 0 then
				multiTotal = multiTotal + attrs[k] * v.ability_value2
			end
		end
	end

	local score = math.floor(addTotal * (1 + multiTotal))
	data.score = score
	data.attrs = {}
	local value1 = 0

	for i, attrKey in ipairs(CombatAttr.attrs) do
		local attrCSV = CsvParser.getCsvData("attr", attrKey)
		value1 = value1 + attrs[attrKey] * attrCSV.ability_value1
	end

	local baseAttrs = CombatAttr.getBaseHeroAttr(heroInfo, nil, , , , true)
	local union_war_attr_ratio = InfoUnion.getConfig("union_war_attr_ratio")
	local union_war_attr_power = InfoUnion.getConfig("union_war_attr_power")

	print("战力：", score, "倍数：", union_war_attr_ratio, "指数：", union_war_attr_power)

	for i, attrKey in ipairs(CombatAttr.attrs) do
		local value = score * attrs[attrKey] / value1
		local baseValue = math.floor(baseAttrs[attrKey] * union_war_attr_ratio)
		local finalValue = baseValue

		if baseValue < value then
			finalValue = math.floor(baseValue + math.pow(value - baseValue, union_war_attr_power))
		end

		print("公会战属性：", attrKey, "换算前:" .. attrs[attrKey], "换算后:" .. value, "基础:" .. baseAttrs[attrKey], "最终:" .. finalValue)

		data.attrs[attrKey] = math.floor(finalValue)
	end

	return data
end

function GwarCore:ctor()
end

function GwarCore:pve(team1, pveID, seed, buff1)
	self.pveID = pveID
	self.type = TYPE.PVE
	self.level = 1
	self.pveScore = 0
	self.teamTypeMap = {
		TEAM_TYPE.PLAYER,
		TEAM_TYPE.MONSTER
	}
	self.teamArrMap = {}
	self.teamCountMap = {}
	self.teamInitCountMap = {}
	self.jobAttrMap = {}
	self.buffMap = {
		buff1 or {},
		{}
	}
	local teamMap = {
		team1
	}
	local idMap = {}

	for camp = 1, 1 do
		local team = teamMap[camp]
		local preType = nil
		local line = 1
		local row = 1
		self.teamArrMap[camp] = {}
		local teamArr = self.teamArrMap[camp]
		self.teamInitCountMap[camp] = #team
		self.teamCountMap[camp] = #team
		self.jobAttrMap[camp] = {}

		table.sort(team, function (a, b)
			local sortA = UNIT_SORT[a.job]
			local sortB = UNIT_SORT[b.job]

			if sortA == sortB then
				return a.id < b.id
			else
				return sortA < sortB
			end
		end)

		for i, teamOne in ipairs(team) do
			if preType and teamOne.job ~= preType or row > #RAW_ARR then
				row = 1
				line = line + 1
			end

			preType = teamOne.job
			local x = line
			local y = RAW_ARR[row]
			teamOne.x = y
			teamOne.y = x

			table.insert(teamArr, teamOne)

			row = row + 1
			idMap[teamOne.id] = true
		end
	end

	local camp = 2
	self.jobAttrMap[camp] = {}
	self.teamArrMap[camp] = {}
	local teamArr = self.teamArrMap[camp]
	local pveCSV = CsvParser.getCsvData("gwar_monster_create", pveID)
	local monList = SheetUtil.getColumnList(pveCSV, {
		"monster_",
		"location_"
	}, {
		"monster",
		"location"
	})
	self.monsterMap = {}
	local team = {}
	local monID = 0

	for j, v in ipairs(monList) do
		local monsterID = v.monster
		local location = v.location
		local lArr = string.split(location, ";")

		for i, pos in ipairs(lArr) do
			if not empty(pos) then
				local posArr = string.split(pos, ",")
				local x = tonumber(posArr[1])
				local y = tonumber(posArr[2])
				local teamOne = {
					camp = camp,
					base_id = monsterID,
					type = TEAM_TYPE.MONSTER
				}
				monID = monID + 1

				while idMap[monID] do
					monID = monID + 1
				end

				teamOne.id = monID
				teamOne.x = #RAW_ARR + 1 - y
				teamOne.y = x

				self:makeMonster(teamOne, self.level)

				teamOne.battleData = {
					hp = teamOne.attrs.hp,
					hpMax = teamOne.attrs.hp
				}
				self.monsterMap[teamOne.id] = {
					camp = camp,
					base_id = monsterID,
					type = TEAM_TYPE.MONSTER,
					x = teamOne.x,
					y = teamOne.y
				}

				table.insert(teamArr, teamOne)
			end
		end
	end

	self.teamInitCountMap[camp] = #teamArr
	self.teamCountMap[camp] = #teamArr
	self.over = nil
	self.round = 1
	self.turn = 1
	self.seed = seed
	self.random = Random.new(self.seed)

	self:onTeamChange()
end

function GwarCore:makeMonster(teamOne, level)
	level = math.min(CsvParser.getMaxID("gwar_base_num"), level)
	local monCSV = CsvParser.getCsvData("gwar_monster", teamOne.base_id)
	teamOne.job = monCSV.type
	teamOne.turn = monCSV.turn
	teamOne.size = monCSV.size

	if monCSV.class == 3 then
		self.bossID = teamOne.id
		teamOne.isBoss = true
	end

	self:makeMonsterAttrs(teamOne, level)
end

function GwarCore:makeMonsterAttrs(teamOne, level)
	level = math.min(CsvParser.getMaxID("gwar_base_num"), level)
	local monCSV = CsvParser.getCsvData("gwar_monster", teamOne.base_id)
	local baseCSV = CsvParser.getCsvData("gwar_base_num", level)

	if not teamOne.attrs then
		teamOne.attrs = {}
	end

	local attrs = teamOne.attrs

	for _, attrKey in ipairs(CombatAttr.attrs) do
		local value = baseCSV["class" .. monCSV.class .. "_" .. attrKey] * monCSV[attrKey .. "_ratio"]
		attrs[attrKey] = math.floor(value)
	end
end

function GwarCore:onBossDmg(teamOne, preHP)
	local pveScore = 0

	for level = 1, self.level - 1 do
		local baseCSV = CsvParser.getCsvData("gwar_base_num", level)
		pveScore = pveScore + baseCSV.class3_score
	end

	local baseCSV = CsvParser.getCsvData("gwar_base_num", self.level)
	local score = (teamOne.attrs.hp - math.max(teamOne.battleData.hp, 0)) / teamOne.attrs.hp * baseCSV.class3_score
	pveScore = pveScore + math.floor(score)
	self.pveScore = pveScore

	if teamOne.battleData.hp <= 0 then
		local maxLevel = CsvParser.getMaxID("gwar_base_num")

		if self.level < maxLevel then
			self.level = self.level + 1
		end

		self:makeMonsterAttrs(teamOne, self.level)

		teamOne.battleData.hp = teamOne.attrs.hp
		teamOne.battleData.hpMax = teamOne.attrs.hp
		self.bossUpedRound = true
	end
end

function GwarCore:pvp(team1, team2, seed, buff1, buff2)
	self.type = TYPE.PVP
	self.teamTypeMap = {
		TEAM_TYPE.PLAYER,
		TEAM_TYPE.PLAYER
	}
	self.teamArrMap = {}
	self.teamCountMap = {}
	self.teamInitCountMap = {}
	self.jobAttrMap = {}
	self.buffMap = {
		buff1 or {},
		buff2 or {}
	}
	local teamMap = {
		team1,
		team2
	}

	for camp = 1, 2 do
		local team = teamMap[camp]
		local preType = nil
		local line = 1
		local row = 1
		self.teamArrMap[camp] = {}
		local teamArr = self.teamArrMap[camp]
		self.teamInitCountMap[camp] = #team
		self.teamCountMap[camp] = #team
		self.jobAttrMap[camp] = {}

		table.sort(team, function (a, b)
			local sortA = UNIT_SORT[a.job]
			local sortB = UNIT_SORT[b.job]

			if sortA == sortB then
				return a.id < b.id
			else
				return sortA < sortB
			end
		end)

		for i, teamOne in ipairs(team) do
			if preType and teamOne.job ~= preType or row > #RAW_ARR then
				row = 1
				line = line + 1
			end

			preType = teamOne.job
			local x = line
			local y = RAW_ARR[row]
			teamOne.x = y
			teamOne.y = x

			table.insert(teamArr, teamOne)

			row = row + 1
		end
	end

	self.over = nil
	self.round = 1
	self.turn = 1
	self.seed = seed
	self.random = Random.new(self.seed)

	self:onTeamChange()
end

function GwarCore:getTeamArr(camp)
	return self.teamArrMap[camp]
end

function GwarCore:onTeamChange()
	if self.teamCountMap[1] == 0 and self.teamCountMap[2] == 0 then
		self.winCamp = self.random:getInt(1, 2)
		self.over = true
	elseif self.teamCountMap[1] == 0 then
		self.winCamp = 2
		self.over = true
	elseif self.teamCountMap[2] == 0 then
		self.winCamp = 1
		self.over = true
	end
end

function GwarCore:isOver()
	return self.over, self.winCamp
end

function GwarCore:getHash()
	local hashArr = {
		self.round,
		self.turn,
		self.winCamp,
		self.seed
	}

	if self.type == TYPE.PVE then
		table.insert(hashArr, self.pveScore)
	end

	for camp = 1, 2 do
		local teamArr = self.teamArrMap[camp]

		for i, teamOne in ipairs(teamArr) do
			table.insert(hashArr, teamOne.battleData.hp)
		end
	end

	local hashStr = table.concat(hashArr, "_")
	local hash = crypto.md5(hashStr)

	print("------ hash", hash, hashStr)

	return hash, hashStr
end

function GwarCore:start()
	self.currRound = 0

	while true do
		self:next()

		if self.over then
			print("$$$ self.over", self.round, self.turn)

			break
		end
	end

	print("$$$ self.winCamp", self.winCamp)

	local initCount = self.teamInitCountMap[self.winCamp]
	local count = self.teamCountMap[self.winCamp]

	return self.winCamp, self.round, (initCount - count) / initCount
end

function GwarCore:damage(attacker, target, times)
	if self.over then
		return {
			isShield = false,
			isBlock = false,
			isCritical = false,
			isDodge = false,
			dmg = 0
		}
	end

	local attackerJobAttrs = self.jobAttrMap[attacker.camp][attacker.job]
	local targetJobAttrs = self.jobAttrMap[target.camp][target.job]
	local isCritical = false
	local isDodge = false
	local isBlock = false
	local isShield = false
	local dmg = attacker.attrs.atk * attacker.attrs.atk / (attacker.attrs.atk + target.attrs.def) / times

	if target.battleData.shield and target.battleData.shield > 0 then
		target.battleData.shield = target.battleData.shield - 1
		isShield = true
		dmg = 0
	end

	if not isShield then
		if self.random:next() < targetJobAttrs.dodge / 100 then
			isDodge = true
			dmg = 0
		end

		if not isDodge then
			if self.random:next() < attackerJobAttrs.critical / 100 then
				isCritical = true
				dmg = dmg * attackerJobAttrs.criticalmp / 100
			end

			if self.random:next() < targetJobAttrs.block / 100 then
				isBlock = true
				dmg = dmg * (1 - targetJobAttrs.block_dmgresis / 100)
			end

			local vsRatio = 1

			if attacker.job == JOB.S then
				local csv = CsvParser.getCsvData("gwar_monster", attacker.base_id)
				vsRatio = csv["dmg_" .. UNIT_KEY[target.job]]
			else
				vsRatio = InfoUnion.getConfig("gwar_" .. UNIT_KEY[attacker.job] .. "_" .. UNIT_KEY[target.job])
			end

			local gwar_damage_add = InfoUnion.getConfig("gwar_damage_add")
			local gwar_damage_ratio = InfoUnion.getConfig("gwar_damage_ratio")
			local dmgRatio = gwar_damage_ratio

			if self.type == TYPE.PVP then
				local addArr = string.split(gwar_damage_add, ",")
				local ratioAdd = tonumber(addArr[math.min(#addArr, self.round)])
				dmgRatio = gwar_damage_ratio + ratioAdd
			end

			local dmgAdd = attackerJobAttrs.dmgadd + attackerJobAttrs["dmgadd_" .. UNIT_KEY[target.job]]
			dmg = math.max(0, math.floor(dmg * vsRatio * dmgRatio * (100 + dmgAdd) / 100))
			dmg = math.floor(dmg)
			local preHP = target.battleData.hp
			target.battleData.hp = target.battleData.hp - dmg

			if self.type == TYPE.PVE and self.bossID == target.id then
				self:onBossDmg(target, preHP)
			elseif preHP > 0 and target.battleData.hp <= 0 then
				self.teamCountMap[target.camp] = self.teamCountMap[target.camp] - 1

				self:onTeamChange()
			end
		end
	end

	return {
		dmg = dmg,
		isDodge = isDodge,
		isCritical = isCritical,
		isBlock = isBlock,
		isShield = isShield
	}
end

function GwarCore:onNewRound(isPlay)
	print("$$$ onNewRound", self.round, self.level, self.pveScore, self.seed, self.bossUpedRound)

	local roundData = {}
	local newTeam = {}

	for camp = 1, 2 do
		local teamType = self.teamTypeMap[camp]
		local jobAttrsJob = self.jobAttrMap[camp]
		local attrCsvRaw = CsvParser.getCsvRaw("gwar_attr")

		for key, job in pairs(JOB) do
			jobAttrsJob[job] = {}
			local jobAttrs = jobAttrsJob[job]

			for id, csv in pairs(attrCsvRaw) do
				jobAttrs[csv.id] = csv.default
			end
		end

		if teamType == TEAM_TYPE.PLAYER then
			local buffs = self.buffMap[camp]

			for j, buffID in ipairs(buffs) do
				local buffCSV = CsvParser.getCsvData("union_battle_buff", buffID)

				if buffCSV.round_start <= self.round and self.round <= buffCSV.round_end then
					local attrList = SheetUtil.getColumnList(buffCSV, {
						"attr_",
						"add_value_"
					}, {
						"attr",
						"add"
					})

					if buffCSV.job == 0 then
						for key, job in pairs(JOB) do
							local jobAttrs = jobAttrsJob[job]

							for ii, obj in ipairs(attrList) do
								jobAttrs[obj.attr] = jobAttrs[obj.attr] + obj.add
							end
						end
					else
						local jobAttrs = jobAttrsJob[buffCSV.job]

						for ii, obj in ipairs(attrList) do
							jobAttrs[obj.attr] = jobAttrs[obj.attr] + obj.add
						end
					end
				end
			end
		end

		local monsterExist = {}
		local teamArr = self.teamArrMap[camp]

		for i, teamOne in ipairs(teamArr) do
			local jobAttrs = jobAttrsJob[teamOne.job]

			if self.round == 1 then
				teamOne.battleData.hpMax = math.floor(teamOne.attrs.hp * (1 + jobAttrs.hp_percent / 100))
				teamOne.battleData.hp = teamOne.battleData.hpMax
			elseif teamOne.battleData.hp > 0 and jobAttrs.heal > 0 then
				local preHp = teamOne.battleData.hp
				teamOne.battleData.hp = math.min(teamOne.battleData.hpMax, math.floor(teamOne.battleData.hp + teamOne.battleData.hpMax * jobAttrs.heal / 100))
				local hpChange = teamOne.battleData.hp - preHp

				if hpChange ~= 0 then
					roundData[teamOne.id] = roundData[teamOne.id] or {}
					roundData[teamOne.id].hp = teamOne.battleData.hp
					roundData[teamOne.id].heal = hpChange
				end
			end

			teamOne.battleData.shield = jobAttrs.shield

			if teamType == TEAM_TYPE.MONSTER then
				monsterExist[teamOne.id] = teamOne
			end
		end

		if teamType == TEAM_TYPE.MONSTER and self.bossUpedRound then
			local _camp = 2
			local _teamArr = self.teamArrMap[_camp]
			local fuhuoCount = 0
			local fuhuoArr = {}

			for id, data in pairs(self.monsterMap) do
				local currentTeamone = monsterExist[id]

				if not monsterExist[id] then
					fuhuoCount = fuhuoCount + 1

					table.insert(fuhuoArr, id)
				else
					self:makeMonsterAttrs(currentTeamone, self.level)
				end
			end

			if #fuhuoArr > 0 then
				table.sort(fuhuoArr, function (a, b)
					return a < b
				end)

				for i, id in ipairs(fuhuoArr) do
					local data = self.monsterMap[id]
					local teamOne = {
						camp = data.camp,
						base_id = data.base_id,
						type = TEAM_TYPE.MONSTER,
						id = id,
						x = data.x,
						y = data.y
					}

					self:makeMonster(teamOne, self.level)

					teamOne.battleData = {
						hp = teamOne.attrs.hp,
						hpMax = teamOne.attrs.hp
					}

					table.insert(_teamArr, teamOne)

					if isPlay then
						table.insert(newTeam, teamOne)
					end
				end
			end

			print("$$$ fuhuoCount", fuhuoCount, #_teamArr)

			self.teamCountMap[_camp] = #_teamArr
		end
	end

	self.bossUpedRound = nil

	table.sort(newTeam, function (a, b)
		return a.id < b.id
	end)

	return roundData, newTeam
end

function GwarCore:getAttackTimes(camp, job)
	local originalTimes = nil

	if self.type == TYPE.PVE and camp == 2 then
		local pveCSV = CsvParser.getCsvData("gwar_monster_create", self.pveID)
		originalTimes = pveCSV["gwar_attack_times_" .. GwarCore.UNIT_KEY[job]]
	else
		originalTimes = InfoUnion.getConfig("gwar_attack_times_" .. GwarCore.UNIT_KEY[job])
	end

	local jobAttrs = self.jobAttrMap[camp][job]
	local newTimes = originalTimes + jobAttrs.attack_times

	return newTimes, originalTimes
end

function GwarCore:getArcherWeight(camp, job)
	local jobAttrs = self.jobAttrMap[camp][job]

	return InfoUnion.getConfig("gwar_archer_weight_" .. GwarCore.UNIT_KEY[job]) + jobAttrs.archer_weight
end

function GwarCore:getAffectTarget(attacker, targetArr)
	local csv = CsvParser.getCsvData("gwar_monster", attacker.base_id)
	local _targets = {}
	local targetTile = {}

	for i, target in ipairs(targetArr) do
		if target.battleData.hp > 0 then
			table.insert(_targets, target)

			targetTile[target.x .. "_" .. target.y] = target
		end
	end

	local targets = {}

	if csv.affect_target == 1 then
		if csv.affect_type == 1 then
			for x = 1, #RAW_ARR do
				for y = 1, csv.affect_range do
					if targetTile[x .. "_" .. y] then
						table.insert(targets, targetTile[x .. "_" .. y])
					end
				end
			end
		elseif csv.affect_type == 2 then
			for x = attacker.x - (attacker.size - 1), attacker.x do
				for y = 1, csv.affect_range do
					local _x = #RAW_ARR + 1 - x

					if targetTile[_x .. "_" .. y] then
						table.insert(targets, targetTile[_x .. "_" .. y])
					end
				end
			end
		elseif csv.affect_type == 3 then
			for i, target in ipairs(targetArr) do
				if target.battleData.hp > 0 then
					table.insert(targets, target)
				end
			end
		end
	elseif csv.affect_target == 2 then
		local target = _targets[self.random:getInt(1, #_targets)]

		if csv.target_type == 1 then
			targets = {
				target
			}
		elseif csv.target_type == 2 then
			for x1 = -csv.affect_range, csv.affect_range do
				for y1 = -csv.affect_range, csv.affect_range do
					local x = attacker.x + x1
					local y = attacker.y + y1
					local _x = #RAW_ARR + 1 - x

					if targetTile[_x .. "_" .. y] then
						table.insert(targets, targetTile[_x .. "_" .. y])
					end
				end
			end
		elseif csv.target_type == 3 then
			for x1 = -csv.affect_range, csv.affect_range do
				for y1 = -csv.affect_range, csv.affect_range do
					if math.abs(x1) + math.abs(y1) <= csv.affect_range then
						local x = attacker.x + x1
						local y = attacker.y + y1
						local _x = #RAW_ARR + 1 - x

						if targetTile[_x .. "_" .. y] then
							table.insert(targets, targetTile[_x .. "_" .. y])
						end
					end
				end
			end
		end
	end

	return targets
end

function GwarCore:next(isPlay)
	local turnData = TURNS[self.turn]
	local playData, newTeam = nil

	if isPlay then
		playData = {
			turnData = turnData
		}
	end

	if self.currRound ~= self.round then
		self.currRound = self.round
		local roundData, _newTeam = self:onNewRound(isPlay)
		newTeam = _newTeam

		if isPlay then
			playData.roundData = roundData
		end
	end

	local campArr = CAMP_ARR[self.random:getInt(1, 2)]

	if turnData.type == TURN_TYPE.FORWARD then
		if isPlay then
			playData.dieArr = {}
		end

		local teamArrMap = {}

		for _, camp in ipairs(campArr) do
			local teamType = self.teamTypeMap[camp]
			local oldArr = self.teamArrMap[camp]
			teamArrMap[camp] = {}
			local teamArr = teamArrMap[camp]
			local lineArr = {}
			local maxLine = 0

			for i, teamOne in ipairs(oldArr) do
				if teamOne.battleData.hp > 0 then
					lineArr[teamOne.y] = (lineArr[teamOne.y] or 0) + 1
					maxLine = math.max(teamOne.y)

					table.insert(teamArr, teamOne)
				elseif isPlay then
					table.insert(playData.dieArr, teamOne.id)
				end
			end

			if teamType == TEAM_TYPE.PLAYER then
				local moveArr = {}
				local moveValue = 0

				for line = 1, maxLine do
					if not lineArr[line] then
						moveValue = moveValue + 1
					end

					moveArr[line] = moveValue
				end

				for i, teamOne in ipairs(teamArr) do
					local value = moveArr[teamOne.y]
					teamOne.y = teamOne.y - value
				end
			end
		end

		self.teamArrMap = teamArrMap
	elseif turnData.type == TURN_TYPE.ATTACK then
		if isPlay then
			playData.attackData = {}
		end

		if turnData.turn then
			if isPlay then
				playData.attackData = {}
			end

			for _, camp in ipairs(campArr) do
				local _attackerArr = self.teamArrMap[camp]
				local targetArr = self.teamArrMap[3 - camp]
				local attackerArr = {}
				local actionSortMap = {}

				for i, attacker in ipairs(_attackerArr) do
					if attacker.type == TEAM_TYPE.MONSTER then
						local csv = CsvParser.getCsvData("gwar_monster", attacker.base_id)

						if csv.turn == turnData.turn then
							table.insert(attackerArr, attacker)

							actionSortMap[attacker.base_id] = csv.action_sort
						end
					end
				end

				table.sort(attackerArr, function (a, b)
					if actionSortMap[a.base_id] == actionSortMap[b.base_id] then
						return a.id < b.id
					else
						return actionSortMap[a.base_id] < actionSortMap[b.base_id]
					end
				end)

				local combineData = {}

				for i, attacker in ipairs(attackerArr) do
					local csv = CsvParser.getCsvData("gwar_monster", attacker.base_id)
					local _targets = self:getAffectTarget(attacker, targetArr)

					if #_targets > 0 then
						local actionObj = nil

						if isPlay then
							if csv.action_combine == 1 then
								actionObj = combineData[csv.id]

								if not actionObj then
									actionObj = {}
									combineData[csv.id] = actionObj

									table.insert(playData.attackData, actionObj)
								end

								actionObj[attacker.id] = {}
							else
								actionObj = {}

								table.insert(playData.attackData, actionObj)

								actionObj[attacker.id] = {}
							end
						end

						for j, target in ipairs(_targets) do
							local dmgPack = self:damage(attacker, target, 1)

							if isPlay then
								table.insert(actionObj[attacker.id], {
									target = target.id,
									dmgPack = dmgPack
								})
							end
						end
					end
				end
			end
		elseif turnData.job == JOB.M then
			local yF = 0.1

			if self.random:next() < 0.5 then
				yF = -0.1
			end

			for _, camp in ipairs(campArr) do
				local times, originalTimes = self:getAttackTimes(camp, turnData.job)

				for index = 1, times do
					local attackerArr = self.teamArrMap[camp]
					local targetArr = self.teamArrMap[3 - camp]

					for i, attacker in ipairs(attackerArr) do
						if attacker.job == JOB.M then
							local _targets = {}

							for j, target in ipairs(targetArr) do
								if target.battleData.hp > 0 then
									local xOffset = math.abs(#RAW_ARR + 1 - target.x - attacker.x - yF)
									local yOffset = target.y

									if target.type == TEAM_TYPE.MONSTER then
										local monCSV = CsvParser.getCsvData("gwar_monster", target.base_id)
										local size = monCSV.size or 1

										if size > 1 then
											for ii = 1, size do
												local _xOffset = math.abs(#RAW_ARR + 1 - target.x + ii - 1 - attacker.x - yF)
												xOffset = math.min(xOffset, _xOffset)
											end
										end

										yOffset = target.y - (size - 1)
									end

									table.insert(_targets, {
										target = target,
										score = xOffset * 100 + yOffset
									})
								end
							end

							if #_targets > 0 then
								table.sort(_targets, function (a, b)
									return a.score < b.score
								end)

								local target = _targets[1].target
								local dmgPack = self:damage(attacker, target, originalTimes)

								if isPlay then
									playData.attackData[attacker.id] = playData.attackData[attacker.id] or {}

									table.insert(playData.attackData[attacker.id], {
										target = target.id,
										dmgPack = dmgPack
									})
								end
							end
						end
					end
				end
			end
		elseif turnData.job == JOB.A then
			if isPlay then
				playData.attackData = {}
			end

			for _, camp in ipairs(campArr) do
				local times, originalTimes = self:getAttackTimes(camp, turnData.job)

				for index = 1, times do
					local attackerArr = self.teamArrMap[camp]
					local targetArr = self.teamArrMap[3 - camp]

					for i, attacker in ipairs(attackerArr) do
						if attacker.job == JOB.A then
							local _targets = {}

							for j, target in ipairs(targetArr) do
								if target.battleData.hp > 0 then
									table.insert(_targets, {
										target = target,
										power = self:getArcherWeight(3 - camp, target.job)
									})
								end
							end

							if #_targets > 0 then
								local randomIndex = SheetUtil.getPowerRandomIndex(_targets, self.random, "power")
								local target = _targets[randomIndex].target
								local dmgPack = self:damage(attacker, target, originalTimes)

								if isPlay then
									playData.attackData[attacker.id] = playData.attackData[attacker.id] or {}

									table.insert(playData.attackData[attacker.id], {
										target = target.id,
										dmgPack = dmgPack
									})
								end
							end
						end
					end
				end
			end
		elseif turnData.job == JOB.W then
			if isPlay then
				playData.attackData = {}
			end

			local yF = 0.1

			if self.random:next() < 0.5 then
				yF = -0.1
			end

			local times1, originalTimes1 = self:getAttackTimes(1, turnData.job)
			local times2, originalTimes2 = self:getAttackTimes(2, turnData.job)
			local campTimes = {
				times1,
				times2
			}
			local campOriginalTimes = {
				originalTimes1,
				originalTimes2
			}
			local maxTimes = math.max(times1, times2)

			for index = 1, maxTimes do
				campArr = CAMP_ARR[self.random:getInt(1, 2)]

				for _, camp in ipairs(campArr) do
					local times = campTimes[camp]
					local originalTimes = campOriginalTimes[camp]

					if index <= times then
						if isPlay then
							playData.attackData[index] = playData.attackData[index] or {}
						end

						local attackerArr = self.teamArrMap[camp]
						local targetArr = self.teamArrMap[3 - camp]
						local firstMap = {}
						local refineArr = {}

						for i, attacker in ipairs(attackerArr) do
							if attacker.job == JOB.W and not attacker.battleData.die then
								if not firstMap[attacker.x] or attacker.y < firstMap[attacker.x] then
									firstMap[attacker.x] = attacker.y
								end

								table.insert(refineArr, attacker)
							end
						end

						for i, attacker in ipairs(refineArr) do
							if attacker.y == firstMap[attacker.x] then
								local _targets = {}

								for j, target in ipairs(targetArr) do
									if target.battleData.hp > 0 then
										table.insert(_targets, {
											target = target,
											score = target.y * 100 + math.abs(#RAW_ARR + 1 - target.x - attacker.x - yF)
										})
									end
								end

								if #_targets > 0 then
									table.sort(_targets, function (a, b)
										return a.score < b.score
									end)

									local target = _targets[1].target
									local dmgPack = self:damage(attacker, target, originalTimes)

									if target.battleData.hp <= 0 then
										target.battleData.die = true
									end

									if isPlay then
										table.insert(playData.attackData[index], {
											attacker = attacker.id,
											target = target.id,
											dmgPack = dmgPack
										})
									end
								end
							end
						end
					end
				end
			end
		end
	end

	self.turn = self.turn + 1

	if self.turn > #TURNS then
		self.turn = 1
		self.round = self.round + 1
	end

	if isPlay then
		return playData, newTeam
	end
end

return GwarCore
