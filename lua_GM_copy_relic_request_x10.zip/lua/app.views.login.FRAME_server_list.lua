local UI_base = import("..UI_base")
local FRAME_server_list = class("FRAME_server_list", UI_base)

function FRAME_server_list.open(server_list, onSelect, isChange, currentData)
	local ui = FRAME_server_list.new(server_list, onSelect, isChange, currentData)

	PopManager.open(ui)
end

function FRAME_server_list:ctor(server_list, onSelect, isChange, currentData)
	FRAME_server_list.super.ctor(self, "frame_server_list")

	self.server_list = server_list
	self.onSelect = onSelect
	self.isChange = isChange
	self.currentData = currentData

	self:init()
end

function FRAME_server_list:init()
	self.noCloseByKey = true

	self:initUI()

	local server_list = self.server_list
	local arr = {}

	for k, v in pairs(server_list) do
		table.insert(arr, v)
	end

	table.sort(arr, function (a, b)
		if a.recommend == b.recommend then
			return b.open_time < a.open_time
		else
			return b.recommend < a.recommend
		end
	end)
	self.list:setItems(arr)

	if #arr > 0 then
		local index = 1

		if self.currentData then
			for i, v in ipairs(arr) do
				if v.server_id == self.currentData.server_id then
					index = i

					break
				end
			end
		end

		self.list:setSelectedIndex(index)
	end

	self:refresh()
end

function FRAME_server_list:initUI()
	local mask = self:getComponentByTag("mask")

	if not self.isChange then
		mask:toTouchable()
	end

	mask:setOpacity(0)

	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local function tapListener(ui, data, index)
		self:refresh()
	end

	self.list = self:createListOnFlag("flag_list", LIST_server, tapListener)

	self.list:setTapGroup("list_click")
	self.list:setEmptyText(Localization.getSrcText("没有可选服务器"))

	local holder = self:getComponentByTag("holder")

	self.list:setHolders({
		holder
	}, nil, 5)

	local function onEnter()
		local serverData = self.list:getSelectedItem()

		if serverData then
			local status, labelObj, isClosing = WorldUtils.getStatus(serverData)

			if status == 3 and not isClosing then
				Alert.open(Localization.getSrcText("服务器维护中"))

				return
			end

			local onSelect = self.onSelect

			PopManager.closeTo(self)

			if onSelect then
				onSelect(serverData)
			end
		else
			Alert.open(Localization.getSrcText("未选择服务器"))
		end
	end

	local bt_enter = self:getComponentByTag("bt_enter")

	bt_enter:toTouchable()
	bt_enter:setTapGroup("button_click")
	bt_enter:addTap(onEnter)

	local bt_enter_disabled = self:getComponentByTag("bt_enter_disabled")

	bt_enter_disabled:toTouchable()
	bt_enter_disabled:setTapGroup("button_click")
	bt_enter_disabled:addTap(onEnter)
end

function FRAME_server_list:refresh()
	local bt_enter = self:getComponentByTag("bt_enter")
	local bt_enter_disabled = self:getComponentByTag("bt_enter_disabled")
	local serverData = self.list:getSelectedItem()
	local ok = false

	if serverData then
		local status, labelObj = WorldUtils.getStatus(serverData)

		if status ~= 3 then
			ok = true
		end
	end

	bt_enter:setVisible(ok)
	bt_enter_disabled:setVisible(not ok)
end

return FRAME_server_list
