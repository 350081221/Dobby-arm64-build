local POP_gacha_test = class("POP_gacha_test", UI_base)

function POP_gacha_test.open()
	POP_gacha_test.opening = true
	local ui = POP_gacha_test.new()

	display.getRunningScene():addChild(ui, LayerConfig.curtain)
end

function POP_gacha_test:ctor()
	POP_gacha_test.super.ctor(self, "pop_gacha_test")
	self:init()
end

function POP_gacha_test:init()
	self:initUI()
end

function POP_gacha_test:initUI()
	local closePB = self:getComponentByTag("close_pb")

	closePB:toTouchable()
	closePB:addTap(function ()
		self:removeSelf()
	end)

	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	self.idEB = self:createEditBoxOnComponent("eb_gacha_id")
	self.loopEB = self:createEditBoxOnComponent("eb_loop")
	self.adjEB = self:createEditBoxOnComponent("eb_adj")

	self.idEB:setText("1002")
	self.loopEB:setText("1000")
	self.adjEB:setText("100")

	local testPB = self:getComponentByTag("bt_test")

	testPB:toTouchable()
	testPB:addTap(function ()
		self:goTest()
	end)

	local clearPB = self:getComponentByTag("bt_clear")

	clearPB:toTouchable()
	clearPB:addTap(function ()
		self:clearChart()
	end)

	local adjPB = self:getComponentByTag("bt_adj")

	adjPB:toTouchable()
	adjPB:addTap(function ()
		self:startAdj()
	end)

	self.scale = 1
	self.resultStack = {}
	self.canvasStack = {}
	self.labelStack = {}

	self:replaceLabelOnFlag("flag_scale", nil, math.floor(self.scale * 100) .. "%")

	local scale_bar = self:getComponentByTag("scale_bar")
	local scale_handler = self:getComponentByTag("scale_handler")

	scale_handler:toTouchable()
	scale_handler:addTouch(function (event, x, y)
		if event == "began" then
			self.scaleDrag = {
				startMouseX = x,
				startX = scale_handler:getPositionX()
			}
		elseif event == "moved" then
			local minX = scale_bar.x + scale_handler.width / 2
			local maxX = scale_bar.x + scale_bar.width - scale_handler.width / 2
			local currentX = math.max(minX, math.min(maxX, x - self.scaleDrag.startMouseX + self.scaleDrag.startX))

			scale_handler:setPositionX(currentX)

			local percent = (currentX - minX) / (maxX - minX)
			percent = math.pow(percent, 3)
			self.scale = 1 + percent * 99

			self:replaceLabelOnFlag("flag_scale", nil, math.floor(self.scale * 100) .. "%")
			self:refreshChart()
		elseif event == "ended" then
			self:refreshChart()
		end
	end)
end

function POP_gacha_test:refreshChart(scale)
	for i, v in ipairs(self.canvasStack) do
		v:removeSelf()
	end

	for i, v in ipairs(self.labelStack) do
		v:removeSelf()
	end

	self.canvasStack = {}
	self.labelStack = {}
	local chartFlag = self:getFlagByTag("flag_chart")
	local chartBG = self:getComponentByTag("chart_bg")

	for chartIndex, results in ipairs(self.resultStack) do
		local resultMap = {}
		local totalTimes = 0

		for i, v in ipairs(results) do
			resultMap[v.id] = v.times
			totalTimes = totalTimes + v.times
		end

		local loop = tonumber(self.loopEB:getText())
		local genArray = CsvParser.getCsvList("affix_gen")
		local spaceX = chartFlag.width / #genArray
		local canvas = display.newNode()

		canvas:setCascadeOpacityEnabled(true)

		local opacity = 255 * math.pow(0.3, #self.resultStack - chartIndex)
		local preX, preY = nil

		for i, v in ipairs(genArray) do
			local x = spaceX * (i - 0.5)
			local y = resultMap[v.id] / loop / scale * chartFlag.height * self.scale + chartFlag.y - chartBG.y
			local color = InfoHero.getQualityColor(v.id)

			if v.id == 0 then
				color = Style.black
			end

			local circle = display.newSolidCircle(5, {
				x = x,
				y = y,
				color = cc.c4f(color.r / 255, color.g / 255, color.b / 255, 1)
			})

			if i > 1 then
				local line = display.newLine({
					{
						x,
						y
					},
					{
						preX,
						preY
					}
				}, {
					borderWidth = 2
				})

				canvas:addChild(line, 99)
				line:setOpacity(100)
			end

			preX = x
			preY = y

			canvas:addChild(circle, 100)

			if chartIndex == #self.resultStack then
				local label = UIManager.getUI("pop_test_label")

				label:setPosition(x, y + 20)
				canvas:addChild(label, 200)

				local _, labelWidth = label:replaceLabelOnFlag("flag_text", nil, resultMap[v.id], math.max(resultMap[v.id] / totalTimes * 1000) / 10)
				local bg = label:getComponentByTag("bg")

				bg:setSize(labelWidth + 10, nil, true)
			end
		end

		local renderTexture = cc.RenderTexture:create(chartBG.width, chartBG.height)

		renderTexture:begin()
		canvas:visit()
		renderTexture:endToLua()

		local texture = renderTexture:getSprite():getTexture()
		local canvasSprite = display.newSprite(texture)

		canvasSprite:setScaleY(-1)
		table.insert(self.canvasStack, canvasSprite)
		canvasSprite:setPosition(chartBG.x + chartBG.width / 2, chartBG.y + chartBG.height / 2)
		canvasSprite:setOpacity(opacity)
		self:addChild(canvasSprite, 100 + chartIndex)
	end
end

function POP_gacha_test:clearChart()
	self.resultStack = {}

	self:refreshChart()
end

function POP_gacha_test:clearGacha(onComplete)
	local gacha_id = tonumber(self.idEB:getText())

	if not gacha_id then
		Alert.open("抽卡id不对")
	end

	local function callback(rcvData)
		if onComplete then
			onComplete()
		end
	end

	Connection.request("gm_gacha_test_clear", {
		gacha_id = gacha_id
	}, callback)
end

function POP_gacha_test:goTest()
	local loop = tonumber(self.loopEB:getText())

	if not loop then
		Alert.open("循环次数不对")
	end

	local gacha_id = tonumber(self.idEB:getText())

	if not gacha_id then
		Alert.open("抽卡id不对")
	end

	local csv = CsvParser.getCsvData("gacha", gacha_id)

	if not csv then
		Alert.open("抽卡id不对")
	end

	local function testGacha()
		POP_mask.open(10, 100)

		local function callback(rcvData)
			table.insert(self.resultStack, rcvData.results)
			self:refreshChart(rcvData.per_gacha)

			if rcvData.err then
				-- Nothing
			end

			local total = rcvData.per_gacha * loop

			for k, v in ipairs(rcvData.results) do
				local id = v.id
				local label = self:getComponentByTag("v_" .. id)

				if label then
					local times = v.times
					local prob = times / total
					local stdV = (1 - prob) / math.pow(prob, 2)
					local resultV = v.variance / 10000
					stdV = math.floor(stdV * 100) / 100
					resultV = math.floor(resultV * 100) / 100
					local color = InfoHero.getQualityColor(v.id)

					label:addLabel("方差:" .. stdV .. "，修正方差:" .. resultV, {
						color = color
					})
				end
			end

			local card_result = rcvData.card_result

			table.sort(card_result, function (a, b)
				return a.num < b.num
			end)

			local total_card = 0

			for i, v in ipairs(card_result) do
				total_card = total_card + v.num
			end

			print("= 抽卡测试 = 总数:" .. total_card)

			for i, v in ipairs(card_result) do
				local csv = CsvParser.getCsvData("card", v.id)

				print("id:" .. v.id, "name:" .. csv.name, "数量:" .. v.num)
			end

			POP_mask.open(10, 0)
		end

		Connection.request("gm_gacha_test", {
			loop = loop,
			gacha_id = gacha_id
		}, callback)
	end

	self:clearGacha(function ()
		testGacha()
	end)
end

function POP_gacha_test:startAdj()
	local loop = tonumber(self.loopEB:getText())

	if not loop then
		Alert.open("循环次数不对")
	end

	local gacha_id = tonumber(self.idEB:getText())

	if not gacha_id then
		Alert.open("抽卡id不对")
	end

	local csv = CsvParser.getCsvData("gacha", gacha_id)

	if not csv then
		Alert.open("抽卡id不对")
	end

	local adj_times = self:getComponentByTag("adj_times")
	local adjTimes = tonumber(self.adjEB:getText())
	local adjCount = 0
	local weight_arr = SheetUtil.getColumnValueList(csv, "std_weight_")
	local std_arr = SheetUtil.getColumnValueList(csv, "std_")

	for i, v in ipairs(weight_arr) do
		local adj = self:getComponentByTag("adj_" .. i)
		local color = InfoHero.getQualityColor(i)

		adj:addLabel("修正权重:" .. v, {
			color = color
		})
	end

	local nestGacha = nil

	local function nestGacha()
		POP_mask.open(10, 100)

		local function callback(rcvData)
			table.insert(self.resultStack, rcvData.results)
			self:refreshChart(rcvData.per_gacha)

			if rcvData.err then
				-- Nothing
			end

			local total = rcvData.per_gacha * loop

			for k, v in ipairs(rcvData.results) do
				local id = v.id
				local label = self:getComponentByTag("v_" .. id)

				if label then
					local times = v.times
					local prob = times / total
					local stdV = (1 - prob) / math.pow(prob, 2)
					local resultV = v.variance / 10000
					stdV = math.floor(stdV * 100) / 100
					resultV = math.floor(resultV * 100) / 100
					local color = InfoHero.getQualityColor(v.id)

					label:addLabel("方差:" .. stdV .. "，修正方差:" .. resultV, {
						color = color
					})
				end
			end

			for k, v in ipairs(rcvData.results) do
				local id = v.id
				local times = v.times
				local prob = times / total
				local stdProb = std_arr[id]
				local weight = weight_arr[id]

				if stdProb and weight then
					stdProb = stdProb / 100

					if id > 1 then
						if prob < stdProb then
							weight = weight * math.pow(stdProb / prob, 0.5)
							weight = math.max(1, math.round(weight))
							weight_arr[id] = weight
						elseif stdProb < prob then
							weight = weight * math.pow(stdProb / prob, 0.5)
							weight = math.max(1, math.round(weight))
							weight_arr[id] = weight
						end
					end

					local adj = self:getComponentByTag("adj_" .. v.id)
					local color = InfoHero.getQualityColor(v.id)

					adj:addLabel("修正权重:" .. weight, {
						color = color
					})
				end
			end

			adjCount = adjCount + 1

			if adjCount < adjTimes then
				self:clearGacha(function ()
					nestGacha()
				end)
			else
				POP_mask.open(10, 0)
			end
		end

		adj_times:addLabel("逼近次数:" .. adjCount)
		Connection.request("gm_gacha_test", {
			loop = loop,
			gacha_id = gacha_id,
			weight_arr = weight_arr
		}, callback)
	end

	self:clearGacha(function ()
		nestGacha()
	end)
end

return POP_gacha_test
