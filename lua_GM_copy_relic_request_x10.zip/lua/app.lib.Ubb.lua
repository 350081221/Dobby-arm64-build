local Ubb = {
	style = function (ubbStack, style, defaultStyle)
		if not ubbStack then
			return
		end

		for i, ubb in ipairs(ubbStack) do
			if utf8.sub(ubb, 1, 7) == "[color=" then
				local colorArr = string.split(utf8.sub(ubb, 8, -2), ",")
				style.color = cc.c4b(tonumber(colorArr[1]), tonumber(colorArr[2]), tonumber(colorArr[3]), 255)
			elseif utf8.sub(ubb, 1, 9) == "[quality=" then
				local quality = tonumber(utf8.sub(ubb, 10, -2))

				if quality then
					style.color = InfoHero.getQualityColor(quality)
				end
			elseif utf8.sub(ubb, 1, 6) == "[size=" then
				style.size = tonumber(utf8.sub(ubb, 7, -2))
			elseif ubb == "[/size]" then
				style.size = defaultStyle.size
			elseif ubb == "[/color]" then
				style.color = defaultStyle.color
			elseif ubb == "[/quality]" then
				style.color = defaultStyle.color
			end
		end
	end,
	insert = function (ubbStack, style, defaultStyle)
		if not ubbStack then
			return
		end

		local text = nil
		local _style = style
		local onTouch = nil

		for i, ubb in ipairs(ubbStack) do
			if utf8.sub(ubb, 1, 6) == "[item=" then
				local id = utf8.sub(ubb, 7, -2)
				local csv = CsvParser.getCsvData("item", id, nil, true)

				if csv then
					text = csv.name
					_style = ObjUtil.copy(style)
					_style.color = InfoHero.getQualityColor(csv.quality)

					function onTouch()
						DropManager.popDetail(DropManager.TYPE.ITEM, {
							base_id = id
						})
					end
				else
					text = ubb
				end
			elseif utf8.sub(ubb, 1, 5) == "[url=" then
				local str = utf8.sub(ubb, 6, -2)
				local arr1 = string.split(str, "|")
				local url = arr1[1]
				text = arr1[2]
				_style = ObjUtil.copy(style)
				_style.color = Style.mana

				function onTouch()
					print("$$$ url", url)
					LuaBridge.call("luaOpenURL", url)
				end
			elseif utf8.sub(ubb, 1, 11) == "[item_name=" then
				local id = utf8.sub(ubb, 12, -2)
				local csv = CsvParser.getCsvData("item", id, nil, true)

				if csv then
					text = csv.name
					_style = ObjUtil.copy(style)
					_style.color = InfoHero.getQualityColor(csv.quality)
				else
					text = ubb
				end
			elseif utf8.sub(ubb, 1, 12) == "[actv_stage=" then
				local id = utf8.sub(ubb, 13, -2)
				local csv = CsvParser.getCsvData("actv_stage", id, nil, true)

				if csv then
					text = csv.name
					_style = ObjUtil.copy(style)
					_style.color = Style.font2
				else
					text = ubb
				end
			elseif utf8.sub(ubb, 1, 7) == "[sheet:" then
				local splitIndex = utf8.find(ubb, "=", 1, true)
				local strSheet = utf8.sub(ubb, 8, splitIndex - 1)
				local indexSheet = utf8.find(strSheet, ".", 1, true)
				local sheetName = utf8.sub(strSheet, 1, indexSheet - 1)
				local sheetColumn = utf8.sub(strSheet, indexSheet + 1)
				local id = utf8.sub(ubb, splitIndex + 1, -2)
				local csv = CsvParser.getCsvData(sheetName, id, nil, true)

				if csv and csv[sheetColumn] then
					text = csv[sheetColumn]
					_style = ObjUtil.copy(style)
					_style.color = Style.font2
				else
					text = ubb
				end
			elseif utf8.sub(ubb, 1, 6) == "[time=" then
				local timeSec = utf8.sub(ubb, 7, -2)
				text = StringUtil.mdtFormat(tonumber(timeSec))
			elseif utf8.sub(ubb, 1, 13) == "[charge_name=" then
				local id = utf8.sub(ubb, 14, -2)
				local csv = CsvParser.getCsvData("charge", id, nil, true)

				if csv then
					text = csv.name
					_style = ObjUtil.copy(style)
					_style.color = Style.font2
				else
					text = ubb
				end
			end
		end

		return text, _style, onTouch
	end
}

function Ubb.interval(ubbStack, defaultInterval)
	if not ubbStack then
		return
	end

	for n = 1, #ubbStack do
		local ubb = ubbStack[n]

		if utf8.sub(ubb, 1, 10) == "[interval=" then
			return tonumber(utf8.sub(ubb, 11, -2))
		elseif ubb == "[/interval]" then
			return defaultInterval
		end
	end
end

function Ubb.sleep(ubbStack)
	if not ubbStack then
		return 0
	end

	for n = 1, #ubbStack do
		local ubb = ubbStack[n]

		if utf8.sub(ubb, 1, 7) == "[sleep=" then
			return tonumber(utf8.sub(ubb, 8, -2))
		end
	end

	return 0
end

local ubbHeads = {
	"[color=",
	"[/color]",
	"[quality=",
	"[/quality]",
	"[size=",
	"[/size]",
	"[interval=",
	"[/interval]",
	"[sleep=",
	"]",
	"[item=",
	"]",
	"[item_name=",
	"]",
	"[actv_stage=",
	"]",
	"[sheet:",
	"]",
	"[charge_name=",
	"]",
	"[time=",
	"]",
	"[url=",
	"]"
}
local ubbHeadsClause = {
	"[qa=",
	"[/qa]",
	"[dialog="
}

function Ubb.parse(str)
	str = string.gsub(str, "\\n", "\n")
	local ubbMap = {}
	local startIndex = 1

	while true do
		local newStr, nextIndex = Ubb.parseOne(str, ubbMap, ubbHeads, startIndex)
		startIndex = nextIndex

		if newStr then
			str = newStr
		else
			break
		end
	end

	return str, ubbMap
end

function Ubb.parseClause(str)
	if not str then
		return
	end

	str = string.gsub(str, "\\n", "\n")
	local ubbMap = {}
	local startIndex = 1

	while true do
		local newStr, nextIndex = Ubb.parseOne(str, ubbMap, ubbHeadsClause, startIndex)
		startIndex = nextIndex

		if newStr then
			str = newStr
		else
			break
		end
	end

	local sectionArr = {}

	for index, tag in pairs(ubbMap) do
		table.insert(sectionArr, {
			index = index,
			tag = tag[1]
		})
	end

	table.sort(sectionArr, function (a, b)
		return a.index < b.index
	end)
	table.insert(sectionArr, {
		tag = "",
		index = utf8.len(str) + 1
	})

	local stack = {}
	local qaStack = nil
	local isQA = false
	local answers = nil
	local preIndex = 1

	for _, obj in ipairs(sectionArr) do
		local index = obj.index
		local tag = obj.tag
		local txt = utf8.sub(str, preIndex, index - 1)
		preIndex = index

		if isQA then
			local txts = string.split(txt, "^")

			for i = 1, #txts do
				table.insert(qaStack, txts[i])
			end
		else
			local txts = string.split(txt, "|")

			for j, t in ipairs(txts) do
				if t ~= "" then
					table.insert(stack, t)
				end
			end
		end

		if tag == "[/qa]" then
			isQA = false
		elseif utf8.sub(tag, 1, 4) == "[qa=" then
			local qaStr = utf8.sub(tag, 5, utf8.len(tag) - 1)
			answers = string.split(qaStr, "^")
			isQA = true
			local obj = {
				answers = answers,
				stack = {}
			}
			qaStack = obj.stack

			table.insert(stack, obj)
		elseif utf8.sub(tag, 1, 8) == "[dialog=" then
			local dialogID = utf8.sub(tag, 9, utf8.len(tag) - 1)
			local obj = {
				dialog = dialogID
			}

			table.insert(stack, obj)
		end
	end

	return stack
end

function Ubb.parseOne(str, ubbMap, heads, startIndex)
	local ubbStart = utf8.find(str, "%[", startIndex or 1)

	if ubbStart then
		local ubbEnd = utf8.find(str, "%]", ubbStart)

		if not ubbEnd then
			return nil
		end

		local ubb = utf8.sub(str, ubbStart, ubbEnd)
		local found = false

		for i = 1, #heads do
			local ubbHead = heads[i]

			if utf8.sub(str, ubbStart, ubbStart + #ubbHead - 1) == ubbHead then
				if not ubbMap[ubbStart] then
					ubbMap[ubbStart] = {}
				end

				table.insert(ubbMap[ubbStart], ubb)

				found = true

				break
			end
		end

		local nextIndex = ubbEnd

		if found then
			nextIndex = nextIndex - (ubbEnd - ubbStart)
			str = utf8.sub(str, 1, ubbStart - 1) .. utf8.sub(str, ubbEnd + 1)
		end

		return str, nextIndex
	end

	return nil
end

return Ubb
