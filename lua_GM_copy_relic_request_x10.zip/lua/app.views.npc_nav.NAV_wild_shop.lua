local NAV_base = import(".NAV_base")
local NAV_wild_shop = class("NAV_wild_shop", NAV_base)

function NAV_wild_shop.open(npc)
	local ui = NAV_wild_shop.new(npc)

	return ui
end

function NAV_wild_shop:ctor(npc)
	NAV_wild_shop.super.ctor(self, npc, "nav_wild_shop")
end

function NAV_wild_shop:init()
	NAV_wild_shop.super.init(self)
end

function NAV_wild_shop:onTap(index)
	NAV_wild_shop.super.onTap(self, index)

	if index == 1 then
		FRAME_big_shop.open(InfoFishing, self.npc)
	end
end

return NAV_wild_shop
