local List = import("...ui.List")
local LIST_show_item = class("LIST_show_item", List)

function LIST_show_item:ctor(rect)
	LIST_show_item.super.ctor(self, rect, List.DIRECTION_HORIZONTAL)
	self:setSpace(10, 10)
	self:setCellName("cell_show_item")
	self:setCellSize(cc.size(120, self.touchRect.height))
end

function LIST_show_item:onCellInit(ui, itemInfo)
	if not ui.slot then
		ui.slot = DropSlot.new(ui:getFlagByTag("flag_slot"), "slot_01")

		ui:addChild(ui.slot, 100)
	end

	ui.slot:setDrop(DropManager.TYPE.ITEM, itemInfo)
end

return LIST_show_item
