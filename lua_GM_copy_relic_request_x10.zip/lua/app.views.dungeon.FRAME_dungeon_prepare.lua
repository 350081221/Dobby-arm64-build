local UI_base = import("..UI_base")
local FRAME_dungeon_prepare = class("FRAME_dungeon_prepare", UI_base)
local TEAM_MAX = 3
local ptPerTile = 140
local heroIso = {
	{
		x = 2,
		y = 2
	},
	{
		x = 2,
		y = 1
	},
	{
		x = 2,
		y = 0
	}
}
local petIsoMap = {}
local isoDragThreshold = 10

function FRAME_dungeon_prepare.open(questInfo)
	local ui = FRAME_dungeon_prepare.new(questInfo)

	PopManager.open(ui)
end

function FRAME_dungeon_prepare:ctor(questInfo)
	self.questInfo = questInfo

	FRAME_dungeon_prepare.super.ctor(self, "frame_dungeon_prepare", UIManager.BIG_TYPE.POP)
	self:init()
end

function FRAME_dungeon_prepare:init()
	self:initUI()
	self:refreshInfo()
end

function FRAME_dungeon_prepare:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	self.rewardList = self:createListOnFlag("flag_reward", RewardList)
	local enterBt = self:getComponentByTag("bt_enter")

	enterBt:toTouchable()
	enterBt:setTapGroup("button_click")
	enterBt:addTap(function ()
		if InfoHero.countTeam() < GameConfig.hero_team_num then
			Alert.open(StringUtil.replace(Localization.getSrcText("队伍不满{1}人"), GameConfig.hero_team_num))

			return
		end

		TaHelper.taGuideDetail(12800)

		local function onSuccess(rcvData)
			DungeonScene.enterDungeon(DungeonScene.ENTER_TYPE.NEW, rcvData)
		end

		InfoDungeon.enter(InfoDungeon.TYPE.QUEST, self.questInfo, onSuccess)
	end)

	local textArea = self:createTextAreaOnFlag("flag_desc")

	textArea:setSpace(13, 13)

	self.textArea = textArea
end

function FRAME_dungeon_prepare:refreshInfo()
	local questInfo = self.questInfo
	local dungeonID = questInfo.dungeon_id
	local questData = CsvParser.getCsvData("quest", questInfo.base_id)
	local dungeonData = CsvParser.getCsvData("quest_dungeon", dungeonID)
	local mapData = CsvParser.getCsvData("quest_map", dungeonID .. "_" .. questInfo.base_id)

	self:createLabelOnFlag("flag_quest_name", questData.name)

	local desc = string.gsub(mapData.desc, "\\n", "\n")

	self.textArea:setText(desc)

	local label, labelWidth = self:createLabelOnFlag("flag_dungeon_name", dungeonData.name)
	local star = self:getComponentByTag("star")

	star:setPos(label:getPositionX() + labelWidth / 2 + 20)
	self:duplicateComponent("star", questData.star - 1, 25, 0)

	local reward_arr = InfoQuest.getQuestReward(questInfo)
	local rewards = {}

	for i, v in ipairs(reward_arr) do
		table.insert(rewards, {
			type = DropManager.TYPE.ITEM,
			info = v
		})
	end

	self.rewardList:setItems(rewards)
end

return FRAME_dungeon_prepare
