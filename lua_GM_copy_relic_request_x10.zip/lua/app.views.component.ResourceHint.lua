local UI_base = import("..UI_base")
local ResourceHint = class("ResourceHint", UI_base)

function ResourceHint.open(pos, itemID, isBottom)
	local ui = ResourceHint.new(itemID)
	local bigScale = UIManager.getBigScale()

	if isBottom then
		ui:setPosition(pos.x * bigScale - ui.width * bigScale, pos.y + (ui.finalHeight + 50) * bigScale)
	else
		ui:setPosition(pos.x * bigScale - ui.width * bigScale, pos.y * bigScale)
	end

	local container = display.newNode()

	container:addChild(ui)
	container:setCascadeOpacityEnabled(true)
	PopManager.replace(container, ResourceHint.ui, nil, function ()
		ResourceHint.ui = nil
	end, nil, 200)

	ResourceHint.ui = container
end

function ResourceHint:ctor(itemID)
	ResourceHint.super.ctor(self, "pop_hint_resource", UIManager.BIG_TYPE.BOTTOM)

	self.itemID = itemID

	self:init()
end

function ResourceHint:init()
	self:initUI()
end

function ResourceHint:onClick(npcID)
	if global.player then
		local mapX, mapY = CampUtils.getNpcGo(npcID)

		if mapX and mapY then
			local path = MapUtils.getPathClose(mapX, mapY)

			if path then
				global.player:goPath(path, true)
			end
		end
	end
end

function ResourceHint:initUI()
	local bg = self:getComponentByTag("bg")

	bg:toTouchable()

	local itemCSV = CsvParser.getCsvData("item", self.itemID)
	local label = self:replaceLabelGroupOnFlag("flag_name", {
		itemCSV.name,
		InfoItem.getNum(self.itemID)
	}, {
		{
			color = Style.font2
		},
		{
			color = Style.font3
		}
	})
	local bg = self:getComponentByTag("bg")
	local line2 = self:getComponentByTag("line2")
	local line3 = self:getComponentByTag("line3")
	local startY = 0

	if InfoItem.isGrowth(self.itemID) then
		local percent, progressArr = InfoBuilding.getProgressByMat(self.itemID)
		local num, growth, growth_time = InfoItem.getGrowth(self.itemID)
		local growthMax = InfoItem.getGrowthMax(self.itemID)
		local label, labelWidth, labelHeight = self:replaceLabelGroupOnFlag("flag_growth", {
			Localization.getSrcText("成长速度"),
			growth
		}, {
			{},
			{
				color = Style.font3
			}
		})
		local label, labelWidth, labelHeight = self:replaceLabelGroupOnFlag("flag_growth_max", {
			Localization.getSrcText("最大储量"),
			growthMax
		}, {
			{},
			{
				color = Style.font3
			}
		})
		startY = -120

		line3:setPos(nil, startY)

		local descFlag = self:getFlagByTag("flag_desc")
		descFlag.y = startY - 25
		local label, labelWidth, labelHeight = self:createLabelOnFlag("flag_desc", itemCSV.desc, {
			wrap = true
		})
		startY = startY - (labelHeight + 15)

		line2:setPos(nil, startY)

		startY = startY - 10

		for i, data in ipairs(progressArr) do
			local buildingUI = UIManager.getUI("hint_resource_building")

			self:addChild(buildingUI, 100)
			buildingUI:setPosition(15, startY)
			buildingUI:createLabelOnFlag("flag_name", data.csv.name)

			local bar = buildingUI:getComponentByTag("bar")

			if data.isMax then
				buildingUI:createLabelOnFlag("flag_state", Localization.getSrcText("已满级"))
				bar:setVisible(false)
			elseif data.isEmpty then
				buildingUI:createLabelOnFlag("flag_state", Localization.getSrcText("未建造"))
				bar:setVisible(false)
			else
				buildingUI:createBarByTag("bar")
				buildingUI:setBarProgressByTag("bar", data.percent)

				if data.percent >= 1 then
					buildingUI:createLabelOnFlag("flag_state", Localization.getSrcText("可升级"), {
						color = Style.golden
					})
					bar:setColor(NAV_base.COLOR.READY)
					bar:setOpacity(150)
				else
					buildingUI:removeLabelOnFlag("flag_state")
					bar:setColor(NAV_base.COLOR.PROGRESS)
					bar:setOpacity(50)
				end
			end

			local bg = buildingUI:getComponentByTag("bg")

			bg:toTouchable()
			bg:addTap(function ()
				local npcID = CampUtils.findBuldingNpc(data.tag)

				if npcID then
					self:onClick(npcID)
					PopManager.close()
				end
			end)
			bg:setTapGroup("bg_click")

			startY = startY - 50
		end

		if InfoMirror.checkLvupResource(self.itemID) then
			local mirrorCount = InfoMirror.countLvup()

			if mirrorCount ~= nil then
				local buildingUI = UIManager.getUI("hint_resource_building")

				self:addChild(buildingUI, 100)
				buildingUI:setPosition(15, startY)
				buildingUI:createLabelOnFlag("flag_name", Localization.getSrcText("调律"))

				if mirrorCount > 0 then
					buildingUI:createLabelOnFlag("flag_state", mirrorCount .. Localization.getSrcText("x可升级"), {
						color = Style.golden
					})
				else
					buildingUI:createLabelOnFlag("flag_state", Localization.getSrcText("无可升级"))
				end

				local bar = buildingUI:getComponentByTag("bar")

				bar:setVisible(false)

				local bg = buildingUI:getComponentByTag("bg")

				bg:toTouchable()
				bg:addTap(function ()
					local npcID = CampUtils.findBuldingNpc(InfoBuilding.TAG.ABYSS)

					if npcID then
						self:onClick(npcID)
						PopManager.close()
					end
				end)
				bg:setTapGroup("bg_click")

				startY = startY - 50
			end
		end

		if InfoModao.checkLvupResource(self.itemID) then
			local modaoCount = InfoModao.countLvup()

			if modaoCount ~= nil then
				local buildingUI = UIManager.getUI("hint_resource_building")

				self:addChild(buildingUI, 100)
				buildingUI:setPosition(15, startY)
				buildingUI:createLabelOnFlag("flag_name", Localization.getSrcText("魔导"))

				if modaoCount > 0 then
					buildingUI:createLabelOnFlag("flag_state", modaoCount .. Localization.getSrcText("x可升级"), {
						color = Style.golden
					})
				else
					buildingUI:createLabelOnFlag("flag_state", Localization.getSrcText("无可升级"))
				end

				local bar = buildingUI:getComponentByTag("bar")

				bar:setVisible(false)

				local bg = buildingUI:getComponentByTag("bg")

				bg:toTouchable()
				bg:addTap(function ()
					local npcID = CampUtils.findBuldingNpc(InfoBuilding.TAG.MONO)

					if npcID then
						self:onClick(npcID)
						PopManager.close()
					end
				end)
				bg:setTapGroup("bg_click")

				startY = startY - 50
			end
		end

		startY = startY - 10

		bg:setSize(nil, -startY)
		bg:setPos(nil, -bg.height)
	else
		if self.itemID == GameConfig.farm_item then
			local trueCash, cashMax, speed = InfoFarm.countHarvest()

			if speed then
				local label, labelWidth, labelHeight = self:replaceLabelGroupOnFlag("flag_growth", {
					Localization.getSrcText("生长速度"),
					speed
				}, {
					{},
					{
						color = Style.font3
					}
				})
				local label, labelWidth, labelHeight = self:replaceLabelGroupOnFlag("flag_growth_max", {
					Localization.getSrcText("最大产量"),
					cashMax
				}, {
					{},
					{
						color = Style.font3
					}
				})
				startY = -120

				line3:setPos(nil, startY)

				local descFlag = self:getFlagByTag("flag_desc")
				descFlag.y = startY - 25
			else
				self:removeLabelOnFlag("flag_growth")
				self:removeLabelOnFlag("flag_growth_max")
				self:removeComponentByTag("line3")

				startY = startY - 55
			end
		elseif self.itemID == GameConfig.coin_item then
			local cash, cashMax, speed = InfoFurnace.getCash()
			local label, labelWidth, labelHeight = self:replaceLabelGroupOnFlag("flag_growth", {
				Localization.getSrcText("收集速度"),
				speed
			}, {
				{},
				{
					color = Style.font3
				}
			})
			local label, labelWidth, labelHeight = self:replaceLabelGroupOnFlag("flag_growth_max", {
				Localization.getSrcText("最大储量"),
				cashMax
			}, {
				{},
				{
					color = Style.font3
				}
			})
			startY = -120

			line3:setPos(nil, startY)

			local descFlag = self:getFlagByTag("flag_desc")
			descFlag.y = startY - 25
		else
			self:removeLabelOnFlag("flag_growth")
			self:removeLabelOnFlag("flag_growth_max")
			self:removeComponentByTag("line3")

			startY = startY - 55
		end

		local label, labelWidth, labelHeight = self:createLabelOnFlag("flag_desc", itemCSV.desc, {
			wrap = true
		})
		startY = startY - (labelHeight + 15)

		line2:setPos(nil, startY)

		startY = startY - 10

		if self.itemID == GameConfig.coin_item and InfoBuilding.getBuildingLevel(InfoBuilding.TAG.FURNACE) > 0 then
			local buildingUI = UIManager.getUI("hint_resource_building")

			self:addChild(buildingUI, 100)
			buildingUI:setPosition(15, startY)

			local buildingCSV = InfoBuilding.getBuildingData(InfoBuilding.TAG.FURNACE)

			buildingUI:createLabelOnFlag("flag_name", buildingCSV.name)

			local bar = buildingUI:getComponentByTag("bar")

			bar:setColor(NAV_base.COLOR.HIGH)

			local cash, cashMax = InfoFurnace.getCash()
			local percent = math.min(1, math.max(0, cash / cashMax))

			buildingUI:createBarByTag("bar")
			buildingUI:setBarProgressByTag("bar", percent)
			bar:setOpacity(50 + 100 * percent)

			if percent >= 1 then
				buildingUI:createLabelOnFlag("flag_state", Localization.getSrcText("已满"))
			end

			local bg = buildingUI:getComponentByTag("bg")

			bg:toTouchable()
			bg:addTap(function ()
				local npcID = CampUtils.findBuldingNpc(InfoBuilding.TAG.FURNACE)

				if npcID then
					self:onClick(npcID)
					PopManager.close()
				end
			end)
			bg:setTapGroup("bg_click")

			startY = startY - 50
			startY = startY - 10

			bg:setSize(nil, -startY)
			bg:setPos(nil, -bg.height)
		elseif self.itemID == GameConfig.farm_item and InfoBuilding.getBuildingLevel(InfoBuilding.TAG.FARM) > 0 then
			local buildingUI = UIManager.getUI("hint_resource_building")

			self:addChild(buildingUI, 100)
			buildingUI:setPosition(15, startY)

			local buildingCSV = InfoBuilding.getBuildingData(InfoBuilding.TAG.FARM)

			buildingUI:createLabelOnFlag("flag_name", buildingCSV.name)

			local bar = buildingUI:getComponentByTag("bar")

			bar:setColor(NAV_base.COLOR.HIGH)

			local cash, cashMax = InfoFarm.countHarvest()
			local percent = math.min(1, math.max(0, cash / cashMax))

			buildingUI:createBarByTag("bar")
			buildingUI:setBarProgressByTag("bar", percent)
			bar:setOpacity(50 + 100 * percent)

			if percent >= 1 then
				buildingUI:createLabelOnFlag("flag_state", Localization.getSrcText("已满"))
			end

			local bg = buildingUI:getComponentByTag("bg")

			bg:toTouchable()
			bg:addTap(function ()
				local npcID = CampUtils.findBuldingNpc(InfoBuilding.TAG.FARM)

				if npcID then
					self:onClick(npcID)
					PopManager.close()
				end
			end)
			bg:setTapGroup("bg_click")

			startY = startY - 50
			startY = startY - 10

			bg:setSize(nil, -startY)
			bg:setPos(nil, -bg.height)
		else
			self:removeComponentByTag("line2")
			bg:setSize(nil, -startY)
			bg:setPos(nil, -bg.height)
		end
	end

	self.finalHeight = -startY
end

return ResourceHint
