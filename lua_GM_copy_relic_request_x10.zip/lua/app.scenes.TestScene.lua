local TestScene = class("TestScene", function ()
	return display.newScene("TestScene")
end)
local TEAM_1 = {
	7,
	8,
	9
}
local TEAM_2 = {
	7,
	8,
	9
}

function TestScene:ctor()
end

function TestScene:init()
	self:initMap()
	self:initUnits()

	self.ui = FRAME_test.new()

	self:addChild(self.ui)

	global.ui = self.ui

	self.gplay:setChangeCallback(function (teamCount)
		self:onTeamChange(teamCount)
	end)
end

function TestScene:initUnits()
	local heroInfo1 = GwarCore.getTestUnit(InfoHero.getHeroByPos(1))
	local heroInfo2 = GwarCore.getTestUnit(InfoHero.getHeroByPos(2))
	local heroInfo3 = GwarCore.getTestUnit(InfoHero.getHeroByPos(3))
	local team1 = TEAM_1
	local team2 = TEAM_2

	if app.sceneData then
		team1 = app.sceneData.team1 or team1
		team2 = app.sceneData.team2 or team2
	end

	local teamMap = {}
	local unitID = 1

	for camp = 1, 2 do
		teamMap[camp] = {}
		local teamQueue = camp == 1 and team1 or team2

		for i = 1, teamQueue[1] do
			table.insert(teamMap[camp], {
				heroInfo = heroInfo1
			})
		end

		for i = 1, teamQueue[2] do
			table.insert(teamMap[camp], {
				heroInfo = heroInfo2
			})
		end

		for i = 1, teamQueue[3] do
			table.insert(teamMap[camp], {
				heroInfo = heroInfo3
			})
		end

		for i, teamOne in ipairs(teamMap[camp]) do
			local heroCSV = CsvParser.getCsvData("hero", teamOne.heroInfo.base_id)
			teamOne.job = heroCSV.class
			teamOne.camp = camp
			teamOne.attrs = teamOne.heroInfo.attrs
			teamOne.battleData = {
				hp = teamOne.attrs.hp
			}
			teamOne.id = unitID
			unitID = unitID + 1
		end
	end

	local seed = math.random(1, 65535)
	self.gcore = GwarCore.new(teamMap[1], teamMap[2], seed, {}, {})
	self.gplay = GwarPlay.new(self.gcore)

	self.gplay:start()
end

function TestScene:onTeamChange(teamCount)
	self.ui:onTeamChange(teamCount)
end

function TestScene:initMap()
	local map = Map.new(display.width, display.height)

	self:addChild(map)
	map:setGamma(Sound.getGamma())
	map:load("gwar_1")

	global.map = map
	local battleCenter = MapEventManager.getEventByTagOne("battle-center")
	local centerX, centerY = map:tileToMap(battleCenter.x, battleCenter.y)

	map:scrollTo(centerX, centerY)
	map:setFov(centerX, centerY)
end

function TestScene:onEnter()
	app:onSceneEnter(self, nil, 1)
	self:init()
end

function TestScene:onExit()
	app:onSceneExit(self)
end

return TestScene
