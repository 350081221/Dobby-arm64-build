local Random = class("Random")
local a = 1103515245
local c = 12345
local m = 65536

function Random:ctor(_seed)
	_seed = _seed or 0
	self.phase = 0

	self:setSeed(_seed)
end

function Random:setSeed(_seed)
	self.seed = (a * _seed + c) % m
end

function Random:next(noBench)
	if CONFIG.isBench and not noBench then
		return 0.5
	end

	self.seed = (a * self.seed + c) % m

	return self.seed / m
end

function Random:gauss(range, notAbs)
	if notAbs then
		return self:nextGauss(range) / range
	else
		return math.abs(self:nextGauss(range)) / range
	end
end

function Random:nextGauss(max)
	max = max or 3
	local num = self:getGauss()

	while max < math.abs(num) do
		num = self:getGauss()
	end

	return math.abs(num / max)
end

function Random:order(arr)
	return Random.randomOrder(arr, function ()
		return self:next()
	end)
end

function Random:nextInt(min, max)
	return min + math.floor((max - min + 1) * self:next())
end

Random.getInt = Random.nextInt

function Random.randomOrder(arr, randomFunc)
	local newArr = {}

	for i = 1, #arr do
		table.insert(newArr, arr[i])
	end

	randomFunc = randomFunc or math.random
	local orderArr = {}

	while #newArr > 0 do
		local index = nil

		if type(randomFunc) == "table" then
			index = math.floor(#newArr * randomFunc:next()) + 1
		else
			index = math.floor(#newArr * randomFunc()) + 1
		end

		local element = table.remove(newArr, index)

		table.insert(orderArr, element)
	end

	return orderArr
end

local RAND_MAX = 1

function Random:getGauss()
	local X = nil

	if self.phase == 0 then
		local first = true

		while first or self.S >= 1 or self.S == 0 do
			first = false
			local U1 = self:next(true) / RAND_MAX
			local U2 = self:next(true) / RAND_MAX
			self.V1 = 2 * U1 - 1
			self.V2 = 2 * U2 - 1
			self.S = self.V1 * self.V1 + self.V2 * self.V2
		end

		X = self.V1 * math.sqrt(-2 * math.log(self.S) / self.S)
	else
		X = self.V2 * math.sqrt(-2 * math.log(self.S) / self.S)
	end

	self.phase = 1 - self.phase

	return X
end

return Random
